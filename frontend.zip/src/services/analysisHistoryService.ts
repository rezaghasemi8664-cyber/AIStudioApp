﻿import type { AnalysisResult } from '../types/analysis';
import { appApiFetch } from './apiConfigService';

type UnknownRecord = Record<string, unknown>;

export interface AnalysisHistoryItem {
  id?: string | number;
  userId?: string | number;
  symbol: string;
  timestamp: number;
  recommendation?: string;
  riskLevel?: string;
  summary?: string;
  fullText?: string;
  result?: AnalysisResult | UnknownRecord | null;
  parsedResult?: AnalysisResult | UnknownRecord | null;
  createdAt?: string;
  created_at?: string;
  resultJson?: string | AnalysisResult | UnknownRecord | null;
}

interface AddHistoryPayload {
  symbol: string;
  recommendation?: string;
  riskLevel?: string;
  summary?: string;
  result?: AnalysisResult;
}

interface ApiWrapped<T> {
  success?: boolean;
  data?: T;
  message?: string;
}

const MAX_HISTORY_ITEMS = 3;

function safeParseJSON<T>(value: string, fallback: T): T {
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

function isObjectLike(v: unknown): v is UnknownRecord {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}

function safeText(v: unknown): string {
  return typeof v === 'string' ? v.trim() : '';
}

function toValidTimestamp(value: unknown): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) return value;

  if (typeof value === 'string') {
    const t = value.trim();
    if (!t) return null;

    const asNum = Number(t);
    if (Number.isFinite(asNum)) return asNum;

    const asDate = new Date(t).getTime();
    if (Number.isFinite(asDate)) return asDate;
  }

  return null;
}

function unwrapApiData<T>(res: unknown): T {
  if (res == null) return res as T;

  if (isObjectLike(res) && 'success' in res) {
    const wrapped = res as ApiWrapped<unknown>;
    if (wrapped.success === false) {
      throw new Error(wrapped.message || 'خطا در دریافت داده.');
    }

    const d1 = wrapped.data as unknown;
    if (isObjectLike(d1) && 'data' in d1) {
      return (d1 as { data: T }).data;
    }
    return (d1 as T) ?? (null as T);
  }

  if (isObjectLike(res) && 'data' in res) {
    const d1 = (res as { data: unknown }).data;
    if (isObjectLike(d1) && 'data' in d1) {
      return (d1 as { data: T }).data;
    }
    return d1 as T;
  }

  return res as T;
}

function coerceParsedResult(
  resultJson: AnalysisHistoryItem['resultJson'],
  parsedResult: AnalysisHistoryItem['parsedResult'],
  result: AnalysisHistoryItem['result']
): UnknownRecord | null {
  if (typeof resultJson === 'string') {
    const parsed = safeParseJSON<unknown>(resultJson, null);
    return isObjectLike(parsed) ? parsed : null;
  }

  if (isObjectLike(resultJson)) return resultJson as UnknownRecord;
  if (isObjectLike(parsedResult)) return parsedResult as UnknownRecord;
  if (isObjectLike(result)) return result as UnknownRecord;

  return null;
}

function extractFullText(
  explicitFullText: unknown,
  parsed: UnknownRecord | null,
  fallbackSummary: unknown
): string {
  const nestedResult = isObjectLike(parsed?.result) ? (parsed.result as UnknownRecord) : null;
  const nestedParsed = isObjectLike(parsed?.parsedResult) ? (parsed.parsedResult as UnknownRecord) : null;

  const candidates: unknown[] = [
    explicitFullText,

    parsed?.fullText,
    parsed?.content,
    parsed?.analysisText,
    parsed?.text,
    parsed?.details,
    parsed?.explanation,
    parsed?.longSummary,
    parsed?.summary,

    nestedResult?.fullText,
    nestedResult?.content,
    nestedResult?.analysisText,
    nestedResult?.text,
    nestedResult?.details,
    nestedResult?.summary,

    nestedParsed?.fullText,
    nestedParsed?.content,
    nestedParsed?.analysisText,
    nestedParsed?.text,
    nestedParsed?.details,
    nestedParsed?.summary,

    fallbackSummary,
  ];

  for (const c of candidates) {
    const t = safeText(c);
    if (t) return t;
  }

  return '';
}

function normalizeSymbol(item: Partial<AnalysisHistoryItem> & { stock?: unknown }): string {
  return safeText(item.symbol) || safeText(item.stock) || 'UNKNOWN';
}

function normalizeHistoryItem(
  input: (Partial<AnalysisHistoryItem> & { stock?: unknown }) | null | undefined
): AnalysisHistoryItem {
  const item = (input ?? {}) as Partial<AnalysisHistoryItem> & { stock?: unknown };

  const parsedResult = coerceParsedResult(item.resultJson, item.parsedResult, item.result);

  const tsFromItem = toValidTimestamp(item.timestamp);
  const tsFromCreatedAt = toValidTimestamp(item.createdAt ?? item.created_at);
  const timestamp = tsFromItem ?? tsFromCreatedAt ?? Date.now();

  const symbol = normalizeSymbol(item);
  const summary = safeText(item.summary);
  const recommendation = safeText(item.recommendation) || safeText(parsedResult?.recommendation);
  const riskLevel = safeText(item.riskLevel) || safeText(parsedResult?.riskLevel);
  const fullText = extractFullText(item.fullText, parsedResult, summary);

  return {
    ...item,
    symbol,
    summary,
    recommendation: recommendation || undefined,
    riskLevel: riskLevel || undefined,
    timestamp,
    result: parsedResult,
    parsedResult,
    resultJson: parsedResult,
    fullText,
  } as AnalysisHistoryItem;
}

function assertSymbol(symbol: string): void {
  if (!symbol || typeof symbol !== 'string' || !symbol.trim()) {
    throw new Error('نماد معتبر نیست.');
  }
}

function normalizePagination(limit: number, offset: number) {
  // همراستا با بک‌اند: سقف ۳
  const safeLimit = Number.isFinite(limit)
    ? Math.max(1, Math.min(MAX_HISTORY_ITEMS, Math.floor(limit)))
    : MAX_HISTORY_ITEMS;

  const safeOffset = Number.isFinite(offset) ? Math.max(0, Math.floor(offset)) : 0;

  return { safeLimit, safeOffset };
}

function serializeResultPayload(payload: AddHistoryPayload): string | null {
  if (!payload.result) return null;
  try {
    return JSON.stringify(payload.result);
  } catch {
    return null;
  }
}

export async function addAnalysisToHistory(
  _userId: string,
  payload: AddHistoryPayload
): Promise<AnalysisHistoryItem> {
  assertSymbol(payload.symbol);

  const raw = await appApiFetch<AnalysisHistoryItem | ApiWrapped<AnalysisHistoryItem>>(
    '/analysis-history',
    {
      method: 'POST',
      body: JSON.stringify({
        symbol: payload.symbol.trim(),
        recommendation: payload.recommendation || payload.result?.recommendation || 'نامشخص',
        riskLevel: payload.riskLevel || payload.result?.riskLevel || 'نامشخص',
        summary: payload.summary || payload.result?.summary || '',
        resultJson: serializeResultPayload(payload),
      }),
    }
  );

  const saved = unwrapApiData<AnalysisHistoryItem>(raw);
  return normalizeHistoryItem(saved);
}

export async function getAnalysisHistory(
  _userId: string,
  limit: number = MAX_HISTORY_ITEMS,
  offset: number = 0
): Promise<AnalysisHistoryItem[]> {
  const { safeLimit, safeOffset } = normalizePagination(limit, offset);

  const raw = await appApiFetch<AnalysisHistoryItem[] | ApiWrapped<AnalysisHistoryItem[]>>(
    `/analysis-history?limit=${safeLimit}&offset=${safeOffset}`
  );

  const items = unwrapApiData<AnalysisHistoryItem[] | null>(raw);
  if (!Array.isArray(items)) return [];

  return items
    .map((x) => normalizeHistoryItem(x))
    .sort((a, b) => {
      const bt = b.timestamp || 0;
      const at = a.timestamp || 0;
      if (bt !== at) return bt - at;

      const bi = Number(b.id ?? 0);
      const ai = Number(a.id ?? 0);
      return bi - ai;
    });
}

export async function getAnalysisDetail(itemId: string | number): Promise<AnalysisHistoryItem | null> {
  const id = String(itemId ?? '').trim();
  if (!id) throw new Error('شناسه رکورد معتبر نیست.');

  const raw = await appApiFetch<AnalysisHistoryItem | ApiWrapped<AnalysisHistoryItem>>(
    `/analysis-history/${encodeURIComponent(id)}`
  );

  const detail = unwrapApiData<AnalysisHistoryItem | null>(raw);
  if (!detail) return null;

  return normalizeHistoryItem(detail);
}

export async function deleteAnalysisFromHistory(
  _userId: string,
  itemId: string | number
): Promise<boolean> {
  const id = String(itemId ?? '').trim();
  if (!id) throw new Error('شناسه رکورد معتبر نیست.');

  const raw = await appApiFetch<ApiWrapped<unknown> | unknown>(
    `/analysis-history/${encodeURIComponent(id)}`,
    { method: 'DELETE' }
  );

  if (isObjectLike(raw) && 'success' in raw) {
    const wrapped = raw as ApiWrapped<unknown>;
    if (wrapped.success === false) {
      throw new Error(wrapped.message || 'خطا در حذف رکورد.');
    }
  }

  return true;
}

export async function clearAnalysisHistory(_userId: string): Promise<boolean> {
  const raw = await appApiFetch<ApiWrapped<unknown> | unknown>('/analysis-history/clear', {
    method: 'DELETE',
  });

  if (isObjectLike(raw) && 'success' in raw) {
    const wrapped = raw as ApiWrapped<unknown>;
    if (wrapped.success === false) {
      throw new Error(wrapped.message || 'خطا در پاکسازی تاریخچه.');
    }
  }

  return true;
}
