<?php
/*
*
*	***** Faraz woo Scheduled sms *****
*
*	This file initializes all WTO Core components
*	
*/
if ( ! defined( 'WPINC' ) ) {
	die;
}
// Define WTO Constants
define( 'FARAZSMS_CORE_INC', dirname( __FILE__ ) . '/inc/' );
define( 'FARAZSMS_CORE_IMG', plugins_url( 'assets/img/', __FILE__ ) );
define( 'FARAZSMS_CORE_CSS', plugins_url( 'assets/css/', __FILE__ ) );
define( 'FARAZSMS_CORE_JS', plugins_url( 'assets/js/', __FILE__ ) );
/*
*
*  Register CSS
*
*/
/**
 * آیا صفحه‌ی جاریِ پیشخوان متعلق به افزونه است؟
 *
 * v3.22.155 — جایگزینِ دو فهرستِ دستیِ صفحات. آن فهرست‌ها از ۴۰ صفحه‌ی ثبت‌شده‌ی افزونه
 * فقط ۱۸ تا را می‌شناختند؛ بقیه (مثلِ «پیامک سفارشات»، «کش‌بک»، «فاکتور»، «گردونه» …)
 * بدونِ CSS/JSِ افزونه رندر می‌شدند و فونت و ظاهرشان به حالتِ خامِ وردپرس برمی‌گشت.
 * هر صفحه‌ی جدیدی هم که ثبت می‌شد همان باگ را تکرار می‌کرد.
 *
 * تشخیص بر پایه‌ی خودِ نام است، نه فهرست: هوکِ صفحه (که وردپرس از اسلاگ می‌سازد) یا
 * پارامترِ page. پیشوندِ fwss هم پوشش داده می‌شود (ماژولِ پیامکِ زمان‌بندی‌شده).
 *
 * @param string $hook هوکِ صفحه‌ی جاری (پارامترِ admin_enqueue_scripts).
 * @return bool
 */
function farazsms_is_plugin_admin_screen( $hook = '' ) {
	$hook = (string) $hook;
	if ( $hook !== '' && ( strpos( $hook, 'farazsms' ) !== false || strpos( $hook, 'fwss' ) !== false ) ) {
		return true;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- فقط تشخیصِ صفحه برای بارگذاریِ asset.
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	return ( $page !== '' && ( strpos( $page, 'farazsms' ) === 0 || strpos( $page, 'fwss' ) === 0 ) );
}

function farazsms_register_core_css( $page ) {
	// v3.22.200: دو فهرستِ دستیِ موازی (نامِ هوک و اسلاگ) حذف شدند. هر عضوشان
	// از قبل با farazsms_is_plugin_admin_screen() هم تطبیق می‌کرد، پس مرده
	// بودند — و بدتر، قالبی از نامِ هوک را مستند می‌کردند که وجود ندارد.
	$is_valid_page = farazsms_is_plugin_admin_screen( $page );

	if ( $is_valid_page ) {
		// v3.13.13 PERF: dashicons + main CSS را همه جا load می‌کنیم (سبک‌اند).
		// ولی select2 CSS (~28KB) فقط برای صفحاتی که واقعاً dropdown ساخته‌شده با
		// select2 دارند load می‌شود — صفحات «سبک» مثل dashboard/reports/feedback
		// نیازی ندارند.
		wp_enqueue_style( 'farazsms-settings', FARAZSMS_CORE_CSS . 'farazsms-settings.css', null, defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1.0', 'all' );
		// v3.18.0: استایل مشترک card-based — یک‌بار enqueue، browser cache می‌کند
		wp_enqueue_style( 'farazsms-admin-modern', FARAZSMS_CORE_CSS . 'farazsms-admin-modern.css', null, defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1.0', 'all' );
		// v3.22.153: تمِ پنلِ محصول (رنگ/فونت/فرم/جدولِ پنلِ کاربریِ فراز). آخرین شیت در صف
		// است تا روی استایل‌های قدیمی بنشیند، و همه‌ی قوانینش زیرِ ظرفِ .farazsms-app-frame
		// اسکوپ شده — نه سایتِ فروشگاه و نه صفحاتِ دیگرِ پیشخوان تحتِ تأثیر قرار نمی‌گیرند.
		wp_enqueue_style( 'farazsms-panel-theme', FARAZSMS_CORE_CSS . 'farazsms-panel-theme.css', array( 'farazsms-admin-modern' ), defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1.0', 'all' );
		wp_enqueue_style( 'dashicons' );

		$select2_pages = array(
			'farazsms', 'farazsms-settings', 'farazsms-poll', 'farazsms-comments',
			'farazsms-phonebook', 'farazsms-sms-forms', 'farazsms-automation',
			'farazsms-newsletter', 'farazsms-notify', 'farazsms-abandoned',
			'farazsms-send-sms',
		);
		$current_page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		if ( in_array( $current_page, $select2_pages, true ) ) {
			wp_enqueue_style( 'select2css', FARAZSMS_CORE_CSS . 'select2.min.css', false, '1.0', 'all' );
		}
	}
	if ( get_post_type() === 'product' || get_post_type() === 'lp_course' ) {
		wp_enqueue_style( 'farazsms-core', FARAZSMS_CORE_CSS . 'farazsms-core.css', null, defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1.0', 'all' );
	}
}

;
add_action( 'admin_enqueue_scripts', 'farazsms_register_core_css' );
/*
*
*  Register JS/Jquery Ready
*
*/
function farazsms_register_core_js( $page ) {
	// v3.22.200: فهرست‌های دستیِ مرده حذف شدند — دلیل در نسخه‌ی CSS همین فایل.
	$is_valid_page = farazsms_is_plugin_admin_screen( $page );
	
	if ( $is_valid_page ) {
		// v3.13.13 PERF: heavy scripts (jquery-validate + select2 = ~80KB) فقط
		// برای صفحاتی که فرم با validation/dropdown دارند load می‌شوند. صفحات
		// سبک مثل dashboard/reports/feedback/lead-magnet آن‌ها را نمی‌گیرند.
		$heavy_js_pages = array(
			'farazsms', 'farazsms-settings', 'farazsms-poll', 'farazsms-comments',
			'farazsms-phonebook', 'farazsms-sms-forms', 'farazsms-automation',
			'farazsms-newsletter', 'farazsms-notify', 'farazsms-abandoned',
			'farazsms-send-sms',
		);
		$current_page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
		$is_heavy_page = in_array( $current_page, $heavy_js_pages, true );

		$settings_deps = array( 'jquery' );
		if ( $is_heavy_page ) {
			wp_enqueue_script( 'jquery-validate', FARAZSMS_CORE_JS . 'jquery.validate.min.js', array( 'jquery' ), '0.0.1', true );
			wp_enqueue_script( 'select2', FARAZSMS_CORE_JS . 'select2.min.js', array( 'jquery-validate' ), '1.0', true );
			$settings_deps = array( 'jquery', 'select2', 'jquery-validate' );
		}
		// v3.21.96: نسخه به نسخه‌ی افزونه گره خورد (قبلاً '0.0.1' هاردکد بود) تا پس از تغییرِ
		// نامِ فیلدها/منطقِ ذخیره، مرورگر/CDN نسخه‌ی کهنه‌ی JS را سرو نکند (علتِ ذخیره‌نشدنِ کلید/خط).
		wp_enqueue_script( 'farazsms-settings', FARAZSMS_CORE_JS . 'farazsms-settings.js', $settings_deps, defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1.0.0', true );
		$farazsms_settings_info = array(
			'delete_button'        => FARAZSMS_CORE_IMG . 'macos-close.png',
			'create_pattern_nonce' => wp_create_nonce( 'farazsms_create_pattern' ),
			'save_nonce'           => wp_create_nonce( 'farazsms_save_settings' ),
		);
		if ( function_exists( 'is_woocommerce' ) ) {
			$farazsms_settings_info['order_statuses'] = wc_get_order_statuses();
		}
		wp_localize_script( 'farazsms-settings', 'farazsms_settings_info', $farazsms_settings_info );
	}
	if ( get_post_type() === 'product' || get_post_type() === 'lp_course' ) {
			// Use the plugin version as the asset version. time() would bust the browser cache
		// on every admin page-load, hurting performance with zero benefit.
		$farazsms_core_version = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1.0.0';
		wp_register_script( 'farazsms-core', FARAZSMS_CORE_JS . 'farazsms-core.js', 'jquery', $farazsms_core_version, true );
		$farazsms_data = [
			'delete_button'  => FARAZSMS_CORE_IMG . 'macos-close.png',
		];
		if (get_post_type() === 'product'){
			$farazsms_data['order_statuses'] = wc_get_order_statuses();
		}elseif (get_post_type() === 'lp_course'){
			$farazsms_data['order_statuses'] = learn_press_get_order_statuses();
		}
		wp_localize_script( 'farazsms-core', 'farazsms_data', $farazsms_data );
		wp_enqueue_script( 'farazsms-core' );
	}
}

add_action( 'admin_enqueue_scripts', 'farazsms_register_core_js' );

/**
 * ثبت ویجت فید فراز اس‌ام‌اس در داشبورد وردپرس
 */
function farazsms_farazsms_dashboard_feed_widget() {
	wp_add_dashboard_widget(
		'farazsms_farazsms_feed',
		__( 'آخرین مطالب فراز اس‌ام‌اس', 'farazsms' ),
		'farazsms_farazsms_dashboard_feed_content',
		null,
		null,
		'normal',
		'high'
	);
}

/**
 * بررسی وجود و معتبر بودن بنر خبری فراز اس‌ام‌اس (اگر ۲۰۰ و عکس باشد true)
 *
 * @return bool
 */
function farazsms_farazsms_banner_available() {
	$banner_url = 'https://farazsms.com/plugin/farazsms/news/banner.jpg';
	$cache_key  = 'farazsms_farazsms_banner_ok';
	$cached     = get_transient( $cache_key );
	if ( true === $cached ) {
		return true;
	}
	if ( false === $cached ) {
		return false;
	}

	$response = wp_remote_head( $banner_url, array(
		'timeout'     => 5,
		'redirection' => 2,
		'sslverify'   => true,
	) );
	if ( is_wp_error( $response ) ) {
		set_transient( $cache_key, false, 1 * HOUR_IN_SECONDS );
		return false;
	}
	$code = wp_remote_retrieve_response_code( $response );
	$type = wp_remote_retrieve_header( $response, 'content-type' );
	$ok   = ( $code === 200 && $type && strpos( strtolower( $type ), 'image/' ) === 0 );
	set_transient( $cache_key, $ok, 1 * HOUR_IN_SECONDS );
	return $ok;
}

/**
 * محتوای ویجت: بنر (در صورت وجود) + دریافت و نمایش آیتم‌های فید فراز اس‌ام‌اس
 */
function farazsms_farazsms_dashboard_feed_content() {
	$banner_url = 'https://farazsms.com/plugin/farazsms/news/banner.jpg';
	if ( farazsms_farazsms_banner_available() ) {
		echo '<p style="margin:0 0 12px 0;"><a href="https://farazsms.com/" target="_blank" rel="noopener"><img src="' . esc_url( $banner_url ) . '" alt="فراز اس‌ام‌اس" style="max-width:100%; height:auto; display:block; border:0;" /></a></p>';
	}

	$feed_url = 'https://farazsms.com/feed/';
	$cache_key = 'farazsms_farazsms_feed_items';
	$cached = get_transient( $cache_key );

	if ( false !== $cached && is_array( $cached ) ) {
		farazsms_farazsms_render_feed_items( $cached );
		return;
	}

	if ( ! function_exists( 'fetch_feed' ) ) {
		require_once ABSPATH . WPINC . '/feed.php';
	}

	$feed = fetch_feed( $feed_url );
	if ( is_wp_error( $feed ) ) {
		echo '<p>' . esc_html__( 'دریافت فید امکان‌پذیر نبود.', 'farazsms' ) . '</p>';
		return;
	}

	$maxitems = $feed->get_item_quantity( 4 );
	$items = $feed->get_items( 0, $maxitems );
	$out = array();

	foreach ( $items as $item ) {
		$out[] = array(
			'title' => $item->get_title(),
			'link'  => $item->get_permalink(),
			'date'  => $item->get_date( 'Y/m/d' ),
		);
	}

	set_transient( $cache_key, $out, 12 * HOUR_IN_SECONDS );
	farazsms_farazsms_render_feed_items( $out );
}

/**
 * چاپ لیست آیتم‌های فید در داشبورد
 *
 * @param array $items آرایه‌ای از آیتم‌ها با کلیدهای title, link, date
 */
function farazsms_farazsms_render_feed_items( $items ) {
	if ( empty( $items ) ) {
		echo '<p>' . esc_html__( 'مطلبی یافت نشد.', 'farazsms' ) . '</p>';
		return;
	}

	echo '<ul class="farazsms-farazsms-feed-list" style="margin:0; padding-right:1em;">';
	foreach ( $items as $item ) {
		$title = isset( $item['title'] ) ? $item['title'] : '';
		$link  = isset( $item['link'] ) ? $item['link'] : '';
		$date  = isset( $item['date'] ) ? $item['date'] : '';
		if ( ! $title || ! $link ) {
			continue;
		}
		echo '<li style="margin-bottom:10px;">';
		echo '<a href="' . esc_url( $link ) . '" target="_blank" rel="noopener">' . esc_html( $title ) . '</a>';
		if ( $date ) {
			echo ' <span style="color:#646970; font-size:12px;">(' . esc_html( $date ) . ')</span>';
		}
		echo '</li>';
	}
	echo '</ul>';
	echo '<p style="margin-top:10px;"><a href="https://farazsms.com/" target="_blank" rel="noopener">' . esc_html__( 'سایت فراز اس‌ام‌اس', 'farazsms' ) . '</a></p>';
}

add_action( 'wp_dashboard_setup', 'farazsms_farazsms_dashboard_feed_widget' );

/**
 * Enqueue order-review.css only on the page that actually renders [order_review].
 * Previously this CSS was loaded on every frontend page, which leaked generic
 * class names like .review-form, .product-review-info into themes and other plugins.
 */
function enqueue_order_review_styles() {
    if ( is_admin() ) {
        return;
    }
    if ( ! is_singular() ) {
        return;
    }
    $post = get_post();
    if ( ! $post || ! has_shortcode( (string) $post->post_content, 'order_review' ) ) {
        return;
    }
    wp_enqueue_style( 'order-review-style', FARAZSMS_CORE_CSS . 'order-review.css', array(), defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1.0', 'all' );
}
add_action( 'wp_enqueue_scripts', 'enqueue_order_review_styles' );

function order_review_shortcode($atts) {
    $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
    if (!$order_id) {
        return "<p>سفارش پیدا نشد.</p>";
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        return "<p>سفارش معتبر نیست.</p>";
    }

    $magic_token = function_exists( 'farazsms_survey_current_magic_token' ) ? farazsms_survey_current_magic_token() : '';
    $has_magic_access = function_exists( 'farazsms_survey_magic_token_valid' )
        && function_exists( 'farazsms_survey_magic_is_enabled' )
        && farazsms_survey_magic_is_enabled()
        && farazsms_survey_magic_token_valid( $order, $magic_token );

    // Ownership check — prevent IDOR (anyone could view any order via ?order_id=N before this).
    if ( ! is_user_logged_in() && ! $has_magic_access ) {
        // در حالتِ عادی، گیتِ template_redirect (farazsms_survey_guest_login_gate) مهمان را
        // قبل از رسیدن به اینجا به صفحه‌ی ورود فرستاده است. این یک fallback است اگر ریدایرکت
        // اجرا نشده باشد (مثلاً قالبی که زودتر هدر فرستاده): به‌جای بن‌بست، لینکِ ورود می‌دهیم.
        $back = function_exists( 'farazsms_survey_build_review_url' ) ? farazsms_survey_build_review_url( $order_id ) : '';
        $login = ( $back !== '' && function_exists( 'farazsms_survey_login_url_with_return' ) )
            ? farazsms_survey_login_url_with_return( $back )
            : wp_login_url( $back );
        return '<div class="order-review-page"><div class="orv-head"><div class="orv-emoji">🔒</div>'
            . '<h2>' . esc_html__( 'برای ثبت نظر ابتدا وارد شوید', 'farazsms' ) . '</h2>'
            . '<p>' . esc_html__( 'پس از ورود، به‌صورت خودکار به همین صفحه‌ی نظرسنجی بازمی‌گردید.', 'farazsms' ) . '</p>'
            . '<p><a class="orv-submit" style="display:inline-block;text-decoration:none;" href="' . esc_url( $login ) . '">'
            . esc_html__( 'ورود به حساب', 'farazsms' ) . '</a></p></div></div>';
    }
    if ( ! $has_magic_access
         && (int) $order->get_customer_id() !== get_current_user_id()
         && ! current_user_can( 'manage_woocommerce' ) ) {
        return '<p>دسترسی غیرمجاز.</p>';
    }

    $first_name = $order->get_billing_first_name();
    $last_name = $order->get_billing_last_name();
    $full_name = trim($first_name . ' ' . $last_name);

    $output  = '<div class="order-review-page">';
    $output .= '<div class="orv-head">';
    $output .= '<div class="orv-emoji">📝</div>';
    $output .= '<h2>' . esc_html__( 'نظر شما برای ما ارزشمند است', 'farazsms' ) . '</h2>';
    $output .= '<p>' . esc_html__( 'سفارش', 'farazsms' ) . ' <span class="orv-order-no">#' . esc_html($order_id) . '</span> — '
             . esc_html__( 'لطفاً تجربه‌ی خود را از محصولات زیر ثبت کنید.', 'farazsms' ) . '</p>';
    if ( $has_magic_access ) {
        $output .= '<p>' . esc_html__( 'با لینک اختصاصی شما را شناختیم؛ نیازی به ورود نیست و فقط فرم‌های همین سفارش نمایش داده می‌شود.', 'farazsms' ) . '</p>';
    }
    $output .= '</div>';

    foreach ($order->get_items() as $item_id => $item) {
        $product = $item->get_product();
        if (!$product) continue;

        $product_id   = $product->get_id();
        $product_name = $product->get_name();
        $thumb        = wp_get_attachment_image_src(get_post_thumbnail_id($product_id), 'medium');
        $product_image = ( $thumb && ! empty( $thumb[0] ) )
            ? $thumb[0]
            : ( function_exists('wc_placeholder_img_src') ? wc_placeholder_img_src('medium') : '' );
        $product_description = trim( wp_strip_all_tags( (string) $product->get_short_description() ) );

        $output .= '<div class="orv-product">';
        $output .= '<div class="orv-product-head">';
        if ( $product_image !== '' ) {
            $output .= '<img class="orv-thumb" src="' . esc_url($product_image) . '" alt="' . esc_attr($product_name) . '">';
        }
        $output .= '<div class="orv-product-meta">';
        $output .= '<h3>' . esc_html($product_name) . '</h3>';
        if ( $product_description !== '' ) {
            $output .= '<p class="orv-desc">' . esc_html( wp_trim_words( $product_description, 24 ) ) . '</p>';
        }
        $output .= '</div></div>';

        $comments = get_comments([
            'post_id'    => $product_id,
            'meta_key'   => 'order_id',
            'meta_value' => $order_id,
            'status'     => 'approve',
        ]);

        if (!empty($comments)) {
            $output .= '<div class="orv-reviews">';
            $output .= '<div class="orv-reviews-title">' . esc_html__( 'نظرات ثبت‌شده', 'farazsms' ) . '</div>';
            foreach ($comments as $comment) {
                $r     = (int) get_comment_meta($comment->comment_ID, 'rating', true);
                $r     = max( 0, min( 5, $r ) );
                $cname = get_comment_meta($comment->comment_ID, 'reviewer_name', true);
                $stars = str_repeat('★', $r) . str_repeat('☆', 5 - $r);
                $output .= '<div class="orv-review">';
                $output .= '<div class="orv-review-top"><strong>' . esc_html($cname) . '</strong><span class="orv-review-stars">' . $stars . '</span></div>';
                $output .= '<p>' . esc_html($comment->comment_content) . '</p>';
                $output .= '</div>';
            }
            $output .= '</div>';
        }

        $output .= '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" class="orv-form">';
        $output .= '<input type="hidden" name="action" value="farazsms_submit_review">';
        $output .= wp_nonce_field('submit_review_' . $product_id, 'review_nonce_' . $product_id, true, false);
        $output .= '<input type="hidden" name="product_id" value="' . esc_attr($product_id) . '">';
        $output .= '<input type="hidden" name="order_id" value="' . esc_attr($order_id) . '">';
        if ( $has_magic_access && $magic_token !== '' ) {
            $output .= '<input type="hidden" name="frv" value="' . esc_attr( $magic_token ) . '">';
        }

        // امتیازِ ستاره‌ای (رادیویی، name=rating — handler بدون تغییر کار می‌کند)
        $output .= '<div class="orv-field"><label class="orv-label">' . esc_html__( 'امتیاز شما', 'farazsms' ) . '</label>';
        $output .= '<div class="orv-stars">';
        for ( $v = 5; $v >= 1; $v-- ) {
            $rid = 'rate_' . (int) $product_id . '_' . $v;
            $output .= '<input type="radio" name="rating" id="' . esc_attr($rid) . '" value="' . $v . '" required>';
            $output .= '<label for="' . esc_attr($rid) . '" title="' . $v . '">★</label>';
        }
        $output .= '</div></div>';

        $output .= '<div class="orv-field"><label class="orv-label">' . esc_html__( 'نظر شما', 'farazsms' ) . '</label>';
        $output .= '<textarea name="comment" rows="4" placeholder="' . esc_attr__( 'تجربه‌ی خود را بنویسید…', 'farazsms' ) . '" required></textarea></div>';

        $output .= '<div class="orv-field"><label class="orv-label">' . esc_html__( 'نام شما', 'farazsms' ) . '</label>';
        $output .= '<input type="text" name="reviewer_name" value="' . esc_attr($full_name) . '" required></div>';

        $output .= '<button type="submit" class="orv-submit">✓ ' . esc_html__( 'ثبت نظر', 'farazsms' ) . '</button>';
        $output .= '</form>';

        $output .= '</div>'; // orv-product
    }

    $output .= '</div>'; // orv-page

    return $output;
}
add_shortcode('order_review', 'order_review_shortcode');

/**
 * Handle order-review submission via admin-post.php instead of scanning $_POST on every init.
 * Previously a closure on init scanned the entire $_POST array on every request site-wide,
 * which hurt TTFB on every page load.
 */
add_action( 'admin_post_farazsms_submit_review', 'farazsms_handle_submit_review' );
add_action( 'admin_post_nopriv_farazsms_submit_review', 'farazsms_handle_submit_review' );
function farazsms_handle_submit_review() {
    $product_id = isset( $_POST['product_id'] ) ? intval( $_POST['product_id'] ) : 0;
    $order_id   = isset( $_POST['order_id'] )   ? intval( $_POST['order_id'] )   : 0;
    if ( ! $product_id || ! $order_id ) {
        wp_die( 'پارامترهای ناقص.', '', array( 'response' => 400 ) );
    }

    check_admin_referer( 'submit_review_' . $product_id, 'review_nonce_' . $product_id );
    if ( ! is_user_logged_in() ) {
        $guard = farazsms_rate_limit_guard_public( 'survey_review_submit', (string) $order_id );
        if ( empty( $guard['allowed'] ) ) {
            wp_die( esc_html( $guard['message'] ), '', array( 'response' => 429 ) );
        }
    }

    // Ownership check — the submitter must own the order being reviewed.
    $order = wc_get_order( $order_id );
    $magic_token = function_exists( 'farazsms_survey_current_magic_token' ) ? farazsms_survey_current_magic_token() : '';
    $has_magic_access = function_exists( 'farazsms_survey_magic_token_valid' )
        && function_exists( 'farazsms_survey_magic_is_enabled' )
        && farazsms_survey_magic_is_enabled()
        && farazsms_survey_magic_token_valid( $order, $magic_token );
    if ( ! $order || ( ! $has_magic_access && ( ! is_user_logged_in() || (int) $order->get_customer_id() !== get_current_user_id() ) ) ) {
        wp_die( 'دسترسی غیرمجاز.', '', array( 'response' => 403 ) );
    }
    if ( function_exists( 'farazsms_survey_order_contains_product' ) && ! farazsms_survey_order_contains_product( $order, $product_id ) ) {
        wp_die( 'این محصول در سفارش شما وجود ندارد.', '', array( 'response' => 403 ) );
    }

    $rating        = isset( $_POST['rating'] ) ? intval( $_POST['rating'] ) : 0;
    $comment       = sanitize_textarea_field( wp_unslash( $_POST['comment'] ?? '' ) );
    $reviewer_name = sanitize_text_field( wp_unslash( $_POST['reviewer_name'] ?? '' ) );
    if ( $rating < 1 || $rating > 5 || $comment === '' ) {
        wp_die( 'مقدار امتیاز یا متن نظر نامعتبر است.', '', array( 'response' => 400 ) );
    }

    $current_user = wp_get_current_user();
    $guest_email = (string) $order->get_billing_email();
    $commentdata = array(
        'comment_post_ID'      => $product_id,
        'comment_author'       => $reviewer_name !== '' ? $reviewer_name : ( $current_user->exists() ? $current_user->display_name : trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ) ),
        'comment_author_email' => $current_user->exists() ? $current_user->user_email : $guest_email,
        'user_id'              => $current_user->exists() ? $current_user->ID : 0,
        'comment_content'      => $comment,
        // Held for moderation by default — site owner approves manually (not auto-approve).
        'comment_approved'     => 0,
        // comment_type باید 'review' باشد تا در تبِ «نقد و بررسی»ِ همان محصول بیاید و افزونه‌های
        // SEO/اسکیمای aggregateRating آن را بشمارند (UGC). خالی‌بودن باعثِ حذف از structured data می‌شد.
        'comment_type'         => 'review',
    );

    // v3.21.88: از wp_new_comment استفاده می‌کنیم (نه wp_insert_comment) تا اکشنِ comment_post
    // fire شود — این اکشن شمارنده‌ی نظرسنجی، پاداشِ آنی، و متای «خریدارِ محصول»ِ ووکامرس را
    // فعال می‌کند که با wp_insert_comment هیچ‌کدام اجرا نمی‌شدند.
    $comment_id = function_exists( 'wp_new_comment' )
        ? wp_new_comment( wp_slash( $commentdata ), true )
        : wp_insert_comment( $commentdata );
    if ( $comment_id && ! is_wp_error( $comment_id ) ) {
        add_comment_meta( $comment_id, 'rating', $rating );
        add_comment_meta( $comment_id, 'order_id', $order_id );
        add_comment_meta( $comment_id, 'reviewer_name', $reviewer_name );
        // خریدار قطعی است (نظر به سفارشِ او گره خورده) → نشانِ «خریدار محصول».
        add_comment_meta( $comment_id, 'verified', 1 );

        $referer = wp_get_referer();
        if ( ! $referer && function_exists( 'farazsms_survey_build_review_url' ) ) {
            $referer = farazsms_survey_build_review_url( $order_id );
        }
        wp_safe_redirect( add_query_arg( 'review_submitted', 'true', $referer ) );
        exit;
    }

    wp_die( 'خطا در ثبت نظر.', '', array( 'response' => 500 ) );
}



function create_order_review_page() {
    $page_title   = 'orderreview';
    $page_content = '[order_review]';

    // get_page_by_title was deprecated in WP 6.2 — use WP_Query instead.
    $query = new WP_Query( array(
        'post_type'              => 'page',
        'title'                  => $page_title,
        'posts_per_page'         => 1,
        'no_found_rows'          => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
        'fields'                 => 'ids',
    ) );
    $existing_id = ! empty( $query->posts ) ? (int) $query->posts[0] : 0;

    if ( ! $existing_id ) {
        wp_insert_post( array(
            'post_title'   => $page_title,
            'post_content' => $page_content,
            'post_status'  => 'publish',
            'post_author'  => 1,
            'post_type'    => 'page',
            // کامنت بسته تا باکسِ «دیدگاه»ِ تم زیرِ فرمِ نقد و بررسی ظاهر نشود (نظر به‌جای
            // review به دیدگاهِ عمومیِ برگه می‌رفت).
            'comment_status' => 'closed',
            'ping_status'    => 'closed',
        ) );
    }

    update_option( 'farazsms_installed_from_version', defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : 'unknown', false );

    // فعال‌سازیِ پیش‌فرض + زمان‌بندیِ ساختِ خودکارِ پترن‌ها (اگر کلید موجود باشد) — non-blocking.
    farazsms_autobuild_maybe_schedule();
}

// Activation hook is registered in the main plugin file (faraz-sms.php) using __FILE__
// so the plugin keeps working even if the directory is renamed.

/*
*
*  Includes
*
*/
// ──────────────────────────────────────────────────────────────────────────
//  بارگذاری ماژول‌ها — تقسیم به سه گروه برای بهینه‌سازی performance
//
//   1) Always — هسته‌ی افزونه که روی هر سایتی لازم است
//   2) WC-only — فقط اگر WooCommerce فعال باشد (تا سایت‌های بدون WC کند نشوند)
//   3) PWSMS-only — وابسته به افزونه پیامک ووکامرس
//
//  این فایل قبل از بارگذاری کامل پلاگین‌ها اجرا می‌شود، پس از option active_plugins
//  برای تشخیص استفاده می‌کنیم (نه class_exists که ترتیب-وابسته است).
// ──────────────────────────────────────────────────────────────────────────

// v3.21.36: گاردِ کدگذاری — باید قبل از هر فایلِ احتمالاً encode-شده بارگذاری شود
// تا farazsms_require_protected() در دسترس باشد و نبودِ loader به‌جای فاتال، اخطار بدهد.
require_once FARAZSMS_CORE_INC . 'farazsms-encoder-guard.php';

// v3.21.0: شبکه‌ی ایمنیِ مهاجرتِ نام‌گذاری (wto_ → farazsms_). باید زود ثبت شود
// تا روی plugins_loaded اولویتِ ۱، قبل از هر خواندنِ option/جدول، داده را منتقل کند.
require_once FARAZSMS_CORE_INC . 'farazsms-migration.php';

// Dependency detection helpers — load first so other modules can use them.
require_once FARAZSMS_CORE_INC . 'farazsms-deps.php';
// v3.21.17: کوتاه‌کننده‌ی لینک (شناسه‌ی وردپرس) — زود بار می‌شود تا قابلیت‌های
// اطلاع‌رسانی (کامنت/موجودی/…) لینکِ کوتاه بسازند.
require_once FARAZSMS_CORE_INC . 'farazsms-short-link.php';
// v3.22.109: امنیتِ کلیدِ دسترسی — رمزنگاریِ شفافِ option. باید پیش از config/settings
// و هر خواندنِ کلید بار شود تا فیلترهای رمزنگاری/رمزگشایی فعال باشند.
require_once FARAZSMS_CORE_INC . 'farazsms-apikey-security.php';
// کانالِ بله (MVP): لایه‌ی کانفیگِ سبک (base-URL + کلیدِ رمزنگاری‌شده‌ی بله). باید بعد از
// apikey-security بیاید تا کریپتوی مشترک در دسترس باشد. بخش‌های سنگین (سرویس/ادمین) در
// farazsms-bale-init.php به‌صورتِ مشروط (فقط وقتی کلید تنظیم است) بار می‌شوند.
require_once FARAZSMS_CORE_INC . 'farazsms-bale-config.php';
// کانالِ بله (MVP): سرویس/ترنسپورت — نقطه‌ی ورودِ واحدِ farazsms_bale_maybe_send + async.
// فراخوانی‌ها runtime-guard هستند (گِیت درونِ خودِ تابع)، پس بارگذاریِ زود بی‌اثر است؛
// بارگذاریِ کاملاً مشروط (فقط وقتی کلید تنظیم است) در استوریِ ۱.۳ روی init منتقل می‌شود.
require_once FARAZSMS_CORE_INC . 'farazsms-bale-service.php';
// کانالِ بله (MVP): بوت‌استرپ — registryِ واحدِ سرویس‌ها (AD-9) + بارگذاریِ مشروطِ بخشِ
// دیدنیِ ادمین فقط وقتی کلید تنظیم است (AD-8).
require_once FARAZSMS_CORE_INC . 'farazsms-bale-init.php';
// کانالِ بله (MVP): کارتِ «کلیدِ دسترسیِ بله» + نوارِ وضعیتِ اتصال در صفحه‌ی تنظیمات.
// همیشه بار می‌شود (فیلدِ کلید باید پیش از تنظیم‌شدنِ کلید هم دیده شود)؛ خودش با هوکِ
// admin_enqueue فقط روی صفحاتِ مرتبط دارایی بار می‌کند.
require_once FARAZSMS_CORE_INC . 'farazsms-bale-settings.php';
// v3.20.89: لایه‌ی پیکربندیِ کانونی (Config Accessor) — منبعِ حقیقتِ واحد برای
// کلید/خط/شماره‌ی مدیر/کدِ پترن. زود بارگذاری می‌شود تا هر ماژول از آن بخواند.
require_once FARAZSMS_CORE_INC . 'farazsms-config.php';
// v3.20.89: لایه‌ی سرویسِ واحدِ پیامک — تنها نقطه‌ی خروج به API فراز
// (base-URL + Api-Key + fallback + نگهبانِ اتصال، یک‌جا). فراخوانی‌ها runtime-guard
// هستند، پس بارگذاریِ زود مشکلی ندارد.
require_once FARAZSMS_CORE_INC . 'farazsms-sms-service.php';
// v3.21.91: لاگِ متمرکزِ ارسال + صفحه‌ی «تشخیص ارسال» (باید بعد از sms-service بیاید تا
// farazsms_send_diag_log برای چوک‌پوینتِ ارسال در دسترس باشد).
require_once FARAZSMS_CORE_INC . 'farazsms-diag-classify.php';
require_once FARAZSMS_CORE_INC . 'farazsms-sms-diagnostics.php';
// دیده‌بانِ سلامتِ ارسال — دانشِ خرابی نباید پشتِ بازدیدِ صفحه بماند.
require_once FARAZSMS_CORE_INC . 'farazsms-send-health.php';
// v3.20.90: کامپوننتِ تبِ مشترکِ ادمین — یک تبِ یکدست برای صفحات (به‌جای ۸ پیاده‌سازی).
require_once FARAZSMS_CORE_INC . 'farazsms-ui-tabs.php';
// v3.21.11: ویزاردِ شروع (onboarding) — کارتِ چک‌لیستِ context-aware روی داشبورد.
require_once FARAZSMS_CORE_INC . 'farazsms-onboarding.php';
// v3.21.20: اعلانِ یک‌باره‌ی «همه‌ی قابلیت‌ها فعال است، قابلِ شخصی‌سازی» در بالای پیشخوان.
require_once FARAZSMS_CORE_INC . 'farazsms-admin-hints.php';
// v3.18.0: Object cache wrapper (Redis/Memcached aware). Load early so any
// downstream module can use farazsms_cache_get/set/delete.
require_once FARAZSMS_CORE_INC . 'farazsms-cache.php';
// v3.18.0: Archive cron — هفتگی رکوردهای قدیمی log را پاک می‌کند.
// روی ۱۰۰k سایت، جلوگیری از رشد بی‌کنترل DB. قابل خاموش‌سازی با constant.
require_once FARAZSMS_CORE_INC . 'farazsms-data-archival.php';
// v3.18.0: Async task helper (Action Scheduler-aware). برای عملیات سنگین.
require_once FARAZSMS_CORE_INC . 'farazsms-async-tasks.php';
// v3.19.0: Rate-limit helper برای endpoint های public — حفاظت در برابر spam/abuse.
require_once FARAZSMS_CORE_INC . 'farazsms-rate-limit.php';

// کیف‌پولِ بومیِ مشتری — مستقل از افزونه‌ی ورود/ثبت‌نام. هدیه‌ی عضویت + مصرف سرِ checkout.
require_once FARAZSMS_CORE_INC . 'farazsms-wallet.php';
// v3.21.92: شارژِ کیف پول از طریقِ محصولِ ووکامرس + درگاه (Item 4). هوک‌های WC داخل فایل گارد شده‌اند.
require_once FARAZSMS_CORE_INC . 'farazsms-wallet-topup.php';

// v3.16.0: سیستم به‌روزرسانی خودکار از GitLab خودی — همه جا بارگذاری می‌شود.
// مستقل از WC. hook ها فقط در صفحه افزونه‌ها/cron WP فعال می‌شوند.
require_once FARAZSMS_CORE_INC . 'farazsms-self-update.php';

// v3.22.45 (#6e): اطلاعِ آپدیت به مدیر (پیامکِ یک‌باره) + صفحه‌ی «بروزرسانی‌ها» (چنج‌لاگ از گیت‌لب).
require_once FARAZSMS_CORE_INC . 'farazsms-updates-notify.php';

// v3.17.4: ویجت KPI پنل پیشخوان وردپرس — addictive داده‌محور
// (هیچ API call روی dashboard load — همه از transient cache می‌آیند)
require_once FARAZSMS_CORE_INC . 'farazsms-dashboard-kpi-widget.php';

// v3.17.4: همگام‌سازی Gravity Forms → دفترچه تلفن فراز
// hooks فقط در صورت فعال بودن GF فعال می‌شوند، خود فایل با gf_is_active() گارد دارد.
farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-gf-phonebook-sync.php' ); // encode-ready (دفترچه/گرویتی)
// کارگرِ پس‌زمینه‌ی ارسالِ گرویتی — باید همیشه بار شود تا صف بتواند صدایش بزند.
// ⚠️ عمداً require_once ساده و نه farazsms_require_protected: اگر این فایل رد
// شود، کارِ پارک‌شده‌ی صف غیرقابلِ‌فراخوان می‌شود و پیامک بی‌صدا دور می‌رود.
require_once FARAZSMS_CORE_INC . 'farazsms-gf-async-send.php';

// v3.17.6: همگام‌سازی فیلد متا اختصاصی (user_meta) → دفترچه تلفن فراز
// برای افزونه‌هایی مثل Digits که شماره را در user_meta ذخیره می‌کنند.
farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-custom-meta-phonebook.php' ); // encode-ready (دفترچه تلفن)

// ── گروه ۱: همیشه بارگذاری شود ─────────────────────────────────────────────
// Faraz SMS API helpers (وابسته به ووکامرس نیست — استفاده می‌شود همه جا)
require_once FARAZSMS_CORE_INC . 'farazsms-sms-api.php';
// نگهبانِ اتصال (تشخیصِ مسدودسازیِ درخواست‌ها) + سازگاری با WP Rocket
require_once FARAZSMS_CORE_INC . 'farazsms-connectivity-guard.php';
require_once FARAZSMS_CORE_INC . 'farazsms-wp-rocket-compat.php';
// API عمومیِ برنامه‌نویسان (توابع پایدارِ ارسال/پترن/دفترچه‌تلفن برای سایر افزونه‌ها)
require_once FARAZSMS_CORE_INC . 'farazsms-developer-api.php';
require_once FARAZSMS_CORE_INC . 'farazsms-feedback-ticket.php';
// گزارشات ارسال پیامک (Send Requests) — صفحه گزارش‌گیری از API فراز اس‌ام‌اس
require_once FARAZSMS_CORE_INC . 'farazsms-send-reports.php';
// v3.17.2: DLR Dashboard — وضعیت تحویل پیامک به مشتری.
// وابسته به farazsms_send_reports_api_get() — باید بعد از farazsms-send-reports.php load شود.
require_once FARAZSMS_CORE_INC . 'farazsms-dlr-dashboard.php';
// خبرنامه پیامکی — مشترکین، شورت‌کد، ویجت، ارسال گروهی
farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-newsletter.php' );
// ارسال پیامک از داخل سایت — صفحه ارسال + تاریخچه
require_once FARAZSMS_CORE_INC . 'farazsms-send-sms.php';
// قاب یکپارچه (Unified Dashboard Frame) — صفحه داشبورد + Frame مشترک برای همه صفحات
require_once FARAZSMS_CORE_INC . 'farazsms-unified-dashboard.php';
require_once FARAZSMS_CORE_INC . 'farazsms-ux-v2.php'; // تنها نمای افزونه (ناوبری + سایدبار)
// سازماندهی و گروه‌بندی منو + onboarding + راهنماهای صفحه‌محور
require_once FARAZSMS_CORE_INC . 'farazsms-menu-organizer.php';
// Load the admin settings
require_once FARAZSMS_CORE_INC . 'farazsms-settings.php';
// Load the Functions
require_once FARAZSMS_CORE_INC . 'farazsms-core-functions.php';
// Load the ajax Request
require_once FARAZSMS_CORE_INC . 'farazsms-ajax-request.php';
require_once FARAZSMS_CORE_INC . 'farazsms-sync-sender-to-feeds.php';
// Load comments SMS module (form field, meta, send on events)
require_once FARAZSMS_CORE_INC . 'farazsms-comments.php';
// OTP backend for form verification (Gravity Forms & Elementor)
require_once FARAZSMS_CORE_INC . 'farazsms-otp.php';
// خرید شارژ از داخل افزونه — بسته‌های پیشنهادی + مبلغ دلخواه + درگاه پرداخت فراز
require_once FARAZSMS_CORE_INC . 'farazsms-wallet-recharge.php';

// v3.13.20: ماژول ورود/ثبت‌نام — فقط در صورت فعال بودن toggle، خود فایل ماژول
// بارگذاری می‌شود. در حالت پیش‌فرض (toggle خاموش)، **هیچ کدی** از این ماژول
// اجرا نمی‌شود — تا با سایر افزونه‌های login/register تداخل نکند.
require_once FARAZSMS_CORE_INC . 'farazsms-login-module-bridge.php';

// v3.14.2: کش‌بک — admin part همیشه load می‌شود تا منو + صفحه تنظیمات قابل
// دسترسی باشد. WC hooks داخل خود فایل با function_exists('WC') گارد شده‌اند،
// پس روی سایت بدون WC هیچ side-effect ندارد و فقط نوتیس «WC نیاز است» نمایش می‌دهد.
require_once FARAZSMS_CORE_INC . 'farazsms-cashback-calc.php'; // محاسبه‌ی خالصِ کش‌بک (قابلِ تستِ واحد)
// اعتبارسنج/سنیتایزرِ متنِ پترن باید پیش از هر مصرف‌کننده‌ای بار شود
// (farazsms_sanitize_pattern_text از ۱۴ ماژول صدا زده می‌شود).
require_once FARAZSMS_CORE_INC . 'farazsms-pattern-validator.php';

farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-cashback.php' );

// v3.14.5: فراز بین — صفحه ادمین toggle. فیچر هسته‌ای (meta tags + sitemap)
// در farazsms-product-meta-tags.php است که بخشی از گروه WC-only است. این فایل
// همیشه load می‌شود تا منوی ادمین در دسترس باشد.
require_once FARAZSMS_CORE_INC . 'farazsms-farazbin.php';

// v3.14.8: گزارش پیامکی روزانه فروش — cron daily + UI inject شده در صفحه تنظیمات.
// خود فایل with function_exists('wc_get_orders') گارد شده — روی سایت بدون WC،
// cron اجرا نمی‌شود ولی UI همچنان قابل دسترس است.
require_once FARAZSMS_CORE_INC . 'farazsms-daily-sales-report.php';
require_once FARAZSMS_CORE_INC . 'farazsms-jalali-window.php';

// v3.21.88: پیامکِ بومیِ کاهش/اتمامِ موجودی به مدیر (Item 6). هوک‌های WC داخل فایل گارد شده‌اند.
require_once FARAZSMS_CORE_INC . 'farazsms-low-stock-sms.php';

// v3.21.97: فاکتورِ پیامکی — لینکِ توکن‌دار → صفحه‌ی فاکتور با چاپ/PDF (%invoice_url%).
require_once FARAZSMS_CORE_INC . 'farazsms-invoice.php';

// v3.21.98: داشبوردِ بازدهیِ پیامک (theme 6) — نمای کلیِ فعالیت + درآمدِ منتسب.
require_once FARAZSMS_CORE_INC . 'farazsms-marketing-dashboard.php';

// v3.21.99: کمپینِ هدفمند / سگمنت‌بندی (theme 4) — مخاطبِ RFM + ارسالِ دسته‌ای.
require_once FARAZSMS_CORE_INC . 'farazsms-campaign.php';

// v3.22.0: اتوماسیونِ سفرِ مشتری (theme 3) — تریگر→شرط→تأخیر→ارسالِ پترن.
require_once FARAZSMS_CORE_INC . 'farazsms-journey.php';

// v3.17.0: تبریک تولد + کوپن اختصاصی — admin part همیشه load می‌شود.
// WC-only hook ها (checkout, my-account, coupon) داخل خود فایل با
// farazsms_birthday_is_enabled() و function_exists گارد شده‌اند.
farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-birthday.php' );
require_once FARAZSMS_CORE_INC . 'farazsms-user-panel.php';
// جلوگیری از حسابِ تکراریِ هم‌شماره + گزارشِ فقط‌خواندنیِ حساب‌های تکراری (v3.22.54).
// v3.22.57: ابزارِ مخربِ ادغامِ حساب بازنشسته و حذف شد — حذفِ کاربر، نابودیِ کیف‌پول/اشتراک/دانلود،
// و ریسکِ ادغامِ اشتباهِ دو نفر (یافته‌های کدریویو). جایگزینِ امن: همین صفحه‌ی فقط‌خواندنی + گاردِ
// جلوگیری از تکراری. نامِ فایلِ حذف‌شده:
//
//   farazsms-account-merge.php
//
require_once FARAZSMS_CORE_INC . 'farazsms-account-dedupe.php';
// دکمه‌ی هوشمندِ حساب/ورود (مستقل از ماژولِ لاگین؛ شورت‌کد/بلاک/ویجت/ارتقای منو)
require_once FARAZSMS_CORE_INC . 'farazsms-account-button.php';
// گاردِ ضدِ رباتِ کدِ ورود (هانی‌پات/توکن/time-gate + سقف‌های per-number/IP/سراسری)
require_once FARAZSMS_CORE_INC . 'farazsms-login-otp-guard.php';
// شورت‌کدِ کش‌بک + زیرمنوی پیامک سفارشات (لینک به PWSMS، گیتِ ووکامرس)
farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-cashback-shortcode.php' ); // encode-ready (کش‌بک)
require_once FARAZSMS_CORE_INC . 'farazsms-orders-sms-menu.php';
// ویدیوهای آموزشیِ داخلِ افزونه (کاهشِ بارِ پشتیبانی)
require_once FARAZSMS_CORE_INC . 'farazsms-help-videos.php';
// کوتاه‌کننده‌ی لینک (Kutt.it) برای سبدِ رهاشده/نظرسنجی
require_once FARAZSMS_CORE_INC . 'farazsms-link-shortener.php';
// صفِ ارسالِ غیرمسدودِ مشترک — باید پیش از ماژول‌هایی که از آن استفاده می‌کنند بیاید
require_once FARAZSMS_CORE_INC . 'farazsms-send-queue.php';
// یکپارچه‌سازی با JetFormBuilder (فقط وقتی فعال باشد — خودِ فایل گارد دارد)
require_once FARAZSMS_CORE_INC . 'farazsms-jetformbuilder.php';
// یکپارچه‌سازیِ WPForms و MetForm (هوک‌ها از منبعِ خودشان تأیید شده — docblockِ فایل)
require_once FARAZSMS_CORE_INC . 'farazsms-form-builders.php';
// یکپارچه‌سازیِ Ultimate Member (هوک‌های اختصاصیِ وضعیت — دلیل در docblockِ فایل)
require_once FARAZSMS_CORE_INC . 'farazsms-ultimate-member.php';
// فهرستِ «سازگاری‌ها» — ماژول‌ها خودشان را در آن ثبت می‌کنند
require_once FARAZSMS_CORE_INC . 'farazsms-compatibility.php';
// یکپارچه‌سازیِ نوبت‌دهیِ بوکلی (پویشِ جدول — بوکلی هوکِ چرخه‌ی‌عمر ندارد؛ دلیل در docblockِ فایل)
require_once FARAZSMS_CORE_INC . 'farazsms-bookly.php';
// یکپارچه‌سازیِ تیکتِ پشتیبانی (Awesome Support — هوک‌ها از منبعِ ۶٫۳٫۹ تأیید شده‌اند)
require_once FARAZSMS_CORE_INC . 'farazsms-tickets.php';
// دفترچه‌تلفنِ مخصوصِ هر محصول (متاباکس + سینکِ افزایشی) — فقط با ووکامرس
if ( function_exists( 'farazsms_is_wc_active' ) ? farazsms_is_wc_active() : class_exists( 'WooCommerce' ) ) {
	farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-product-phonebook.php' ); // encode-ready (دفترچه تلفن)
}
require_once FARAZSMS_CORE_INC . 'farazsms-ui-toggle.php';
require_once FARAZSMS_CORE_INC . 'farazsms-admin-modal.php';
// دروازه‌ی تداخل: اگر افزونه‌ای روی سایت به وب‌سرویسِ نسلِ قبل درخواست بزند، تنظیماتِ افزونه بسته می‌شود
farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-conflict-gate.php' ); // encode-ready
// یکپارچه‌سازیِ افزونه‌ی پینوا (افزودنِ درگاهِ فراز به‌صورتِ self-healing)
farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-pinova-gateway.php' );
// یادآورِ هدیه‌ی لید مگنت — پیامک به کاربرانی که هدیه گرفته‌اند ولی خرید نکرده‌اند
farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-lead-magnet-reminder.php' );
farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-analytics-matomo.php' ); // encode-ready (متمو/آنالیتیکس)
require_once FARAZSMS_CORE_INC . 'farazsms-site-census.php'; // سرشماریِ افزونه‌های نصب‌شده (بعد از متمو — به توابعش وابسته است)
// پیامکِ خوش‌آمدگوییِ عضویت + اطلاع‌رسانیِ ورود (زیرمنوی ماژولِ ورود/ثبت‌نام)
require_once FARAZSMS_CORE_INC . 'farazsms-login-welcome-sms.php';
require_once FARAZSMS_CORE_INC . 'farazsms-login-security.php';
require_once FARAZSMS_CORE_INC . 'farazsms-autobuild-patterns.php';
// موتورِ اورلیِ مشترک (Overlay Engine) — پایه‌ی پاپ‌آپ‌ها/مودال‌ها (گردونه/لیدمگنت/خبرم‌کن/بازخورد/…).
// باید پیش از فیچرهایی که رویش register می‌کنند لود شود. تا فیچری ثبت نکند کاملاً بی‌اثر است.
require_once FARAZSMS_CORE_INC . 'farazsms-overlay-engine.php';
farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-spin-wheel.php' );

// ── گروه ۲: فقط در صورت فعال بودن WooCommerce ─────────────────────────────
if ( farazsms_is_wc_active() ) {
	// موجود شد خبرم کن — دکمه روی صفحه محصول ووکامرس + ارسال خودکار پیامک
	require_once FARAZSMS_CORE_INC . 'farazsms-notify-me.php';
	// سبد خرید رها‌شده — tracking + cron + dashboard آماری
	farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-abandoned-cart.php' );
	// نظرسنجی پس از خرید — رابط جدید + راهنما + ساخت الگو + آمار
	require_once FARAZSMS_CORE_INC . 'farazsms-survey.php';
	// Order SMS dedupe + meta tags + scheduled sms — همگی به سفارش/محصول WC مرتبط‌اند
	require_once FARAZSMS_CORE_INC . 'farazsms-order-sms-dedupe.php';
	// v3.21.x: «فراز بین» بازنویسی شد (افزونه = منبعِ دادهٔ موتورِ مقایسه‌ی قیمت).
	// نسخه‌ی قدیمی (meta-tag/sitemap محلی) حذف شد و دیگر بارگذاری نمی‌شود.
	// require_once FARAZSMS_CORE_INC . 'farazsms-product-meta-tags.php';
	// v3.14.10: ثبت لاگ کدهای رهگیری ارسال‌شده — وابسته به WC چون از wc_get_order
	// استفاده می‌کند. در صفحه تنظیمات (تب «گزارش ارسال‌ها») رندر می‌شود.
	require_once FARAZSMS_CORE_INC . 'farazsms-tracking-log.php';
	// v3.22.102: درجِ گروهیِ کد رهگیری — یک صفحه به‌جای بازکردنِ تک‌تکِ سفارش‌ها (WC-gated).
	require_once FARAZSMS_CORE_INC . 'farazsms-bulk-tracking.php';
	// v3.15.0: داشبورد ROI — تجمیع revenue از cashback + abandoned + survey + tracking.
	// خود فایل از جدول‌های ماژول‌های دیگر می‌خواند، پس باید بعد از آن‌ها require شود.
	// HPOS-aware و با transient cache ۳۰ دقیقه‌ای.
	require_once FARAZSMS_CORE_INC . 'farazsms-roi-dashboard.php';
	// پیامک زمان‌دار (اتومیشن مارکتینگ) — زیرمنوی فراز اس ام اس
	require_once dirname( __FILE__ ) . '/modules/faraz-woo-scheduled-sms/core-init.php';
}

// ── گروه ۳: ادغام میهن پنل — فقط در صورت فعال بودن آن ─────────────────────
if ( farazsms_is_mihanpanel_active() ) {
	require_once FARAZSMS_CORE_INC . 'farazsms-mihanpanel-provider.php';
}

// ── گروه ۴: ادغام با افزونه پیامک ووکامرس (PWSMS) ─────────────────────────
// نکته بحرانی (v3.13.14 رفع شد): این فایل filter زیر را register می‌کند:
//
//   pwoosms_sms_gateways
//
// که گیتوی‌های FarazSMSNext و IranPayamak را به افزونه «پیامک حرفه‌ای ووکامرس»
// اضافه می‌کند. در v3.13.6 این به اشتباه پشت چک farazsms_is_pwsms_active() قرار گرفت —
// که با active_plugins option detect می‌کرد و روی slug های متفاوت (mirror ها،
// نسخه pro، ...) fail می‌شد. نتیجه: گیتوی فراز از لیست افزونه PWSMS غایب می‌شد.
//
// راه‌حل: filter را همیشه register کنیم. اگر PWSMS نباشد، این filter هرگز
// fire نمی‌شود (چون pwoosms_sms_gateways فقط در PWSMS تعریف شده). پس detection
// لازم نیست و این کار بی‌خطر است.
require_once FARAZSMS_CORE_INC . 'farazsms-integration-pwsms.php';
// PWSMS onboarding bridge: bidirectional Api-Key sync + connection panel + test SMS
require_once FARAZSMS_CORE_INC . 'farazsms-pwsms-onboarding.php';
// یکپارچگی با اسپات‌پلیر — تزریقِ زیرمنو + ارسالِ لایسنس با پترنِ فراز (فقط وقتی اسپات‌پلیر نصب است)
require_once FARAZSMS_CORE_INC . 'farazsms-integration-spotplayer.php';
// یکپارچگی با افزونه‌ی «حمل و نقل ووکامرس» (تاپین) — ارسالِ خودکارِ کدِ رهگیری + رویدادهای پیامکی با پترنِ فراز
require_once FARAZSMS_CORE_INC . 'farazsms-integration-pws-tapin.php';

// Define FarazSMS Next module constants
if (!defined('FARAZSMS_NEXT_PLUGIN_DIR')) {
	define('FARAZSMS_NEXT_PLUGIN_DIR', dirname(__FILE__) . '/modules/farazsms-next/');
}
if (!defined('FARAZSMS_NEXT_PLUGIN_URL')) {
	define('FARAZSMS_NEXT_PLUGIN_URL', plugins_url('modules/farazsms-next/', __FILE__));
}
if (!defined('FARAZSMS_NEXT_VERSION')) {
	// Always mirror the main plugin version so the two constants cannot drift on release.
	define('FARAZSMS_NEXT_VERSION', defined('FARAZSMS_PLUGIN_VERSION') ? FARAZSMS_PLUGIN_VERSION : '0.0.0');
}

// v3.22.104: wrapperهای ثبتِ زودهنگامِ فیلد/اکشنِ فرمِ المنتور پرو. کلاسِ اصلی را lazy لود می‌کنند تا
// خطای «textdomain too early» رخ ندهد؛ و چون هوکشان در file-scope اضافه می‌شود، پیش از fireشدنِ
// register توسطِ المنتور پرو حاضرند (رفعِ «فیلدِ تأیید موبایل در فهرست نیست»).
if ( ! function_exists( 'farazsms_elementor_register_otp_field_early' ) ) {
	function farazsms_elementor_register_otp_field_early( $registrar ) {
		if ( ! class_exists( 'FarazSMS_Next_Elementor_SMS' ) && defined( 'FARAZSMS_NEXT_PLUGIN_DIR' ) && file_exists( FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-elementor-sms.php' ) ) {
			require_once FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-elementor-sms.php';
		}
		if ( is_callable( array( 'FarazSMS_Next_Elementor_SMS', 'register_otp_form_field' ) ) ) {
			FarazSMS_Next_Elementor_SMS::register_otp_form_field( $registrar );
		}
	}
}
if ( ! function_exists( 'farazsms_elementor_register_form_action_early' ) ) {
	function farazsms_elementor_register_form_action_early( $registrar ) {
		if ( ! class_exists( 'FarazSMS_Next_Elementor_SMS' ) && defined( 'FARAZSMS_NEXT_PLUGIN_DIR' ) && file_exists( FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-elementor-sms.php' ) ) {
			require_once FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-elementor-sms.php';
		}
		if ( is_callable( array( 'FarazSMS_Next_Elementor_SMS', 'register_farazsms_form_action' ) ) ) {
			FarazSMS_Next_Elementor_SMS::register_farazsms_form_action( $registrar );
		}
	}
}

// Load FarazSMS Next module
if (file_exists(FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-admin-menu.php')) {
	require_once FARAZSMS_NEXT_PLUGIN_DIR . 'includes/lead-magnet-helpers.php';
	require_once FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-admin-menu.php';
	require_once FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-admin-page.php';
	require_once FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-phonebook-api.php';
	require_once FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-phonebook-run.php';
	// تأییدِ واردسازی: بی‌قید بار می‌شود (هوکِ کرون و اعلانِ مدیر باید همیشه ثبت
	// شوند، حتی وقتی ووکامرس نیست — انتقالِ دستی هم همین مسیر را دارد).
	require_once FARAZSMS_CORE_INC . 'farazsms-phonebook-import-verify.php';
	// همگام‌سازی خودکار سفارش ووکامرس → دفترچه تلفن — فقط در صورت فعال بودن WC
	if ( farazsms_is_wc_active() ) {
		farazsms_require_protected( FARAZSMS_CORE_INC . 'farazsms-phonebook-wc-auto.php' ); // encode-ready (دفترچه تلفن)
	}
	require_once FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-frontend.php';
	
	// Initialize admin menu
	if (is_admin()) {
		$farazsms_next_admin_menu = new FarazSMS_Next_Admin_Menu();
		$farazsms_next_admin_menu->init();
	}
	
	// Initialize frontend
	if (!is_admin()) {
		new FarazSMS_Next_Frontend();
	}
	
	// Register AJAX handlers for Gravity Forms SMS (must be done early)
	add_action('admin_init', function() {
		if (class_exists('GFForms')) {
			// Load configurations class if not already loaded
			if (!class_exists('FarazSMS_Next_Gravity_Forms_SMS_Configurations')) {
				require_once FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-gravity-forms-sms-configurations.php';
			}
			// Register AJAX handlers
			if (class_exists('FarazSMS_Next_Gravity_Forms_SMS_Configurations')) {
				add_action('wp_ajax_farazsms_select_form', array('FarazSMS_Next_Gravity_Forms_SMS_Configurations', 'select_form_ajax'), 10);
				add_action('wp_ajax_farazsms_next_create_pattern', array('FarazSMS_Next_Gravity_Forms_SMS_Configurations', 'create_pattern_ajax'), 10);
				add_action('wp_ajax_farazsms_get_pattern', array('FarazSMS_Next_Gravity_Forms_SMS_Configurations', 'get_pattern_ajax'), 10);
			}
		}
		
		// Register AJAX handlers for Elementor SMS
		if (did_action('elementor/loaded') || class_exists('\Elementor\Plugin')) {
			// Load configurations class if not already loaded
			if (!class_exists('FarazSMS_Next_Elementor_SMS_Configurations')) {
				require_once FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-elementor-sms-configurations.php';
			}
			// Register AJAX handlers
			if (class_exists('FarazSMS_Next_Elementor_SMS_Configurations')) {
				add_action('wp_ajax_farazsms_elementor_select_form', array('FarazSMS_Next_Elementor_SMS_Configurations', 'select_form_ajax'), 10);
				add_action('wp_ajax_farazsms_elementor_create_pattern', array('FarazSMS_Next_Elementor_SMS_Configurations', 'create_pattern_ajax'), 10);
				add_action('wp_ajax_farazsms_elementor_get_pattern', array('FarazSMS_Next_Elementor_SMS_Configurations', 'get_pattern_ajax'), 10);
				// v3.22.108: ذخیره‌ی تنظیماتِ فرمِ المنتور بدونِ رفرشِ صفحه.
				add_action('wp_ajax_farazsms_elementor_save_feed', array('FarazSMS_Next_Elementor_SMS_Configurations', 'save_feed_ajax'), 10);
			}
		}
	}, 5);
	
	// v3.20.8: Load Gravity Forms / Elementor SMS classes on `init` instead of
	// `plugins_loaded` — تا WP 6.7+ Notice برای textdomain "triggered too early"
	// چاپ نشود. این Notice ها می‌توانند با AJAX responses checkout قاطی شوند.
	add_action('init', function() {
		if (class_exists('GFForms')) {
			require_once FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-gravity-forms-sms.php';
			if ( class_exists('FarazSMS_Next_Gravity_Forms_SMS') ) {
				FarazSMS_Next_Gravity_Forms_SMS::construct();
			}
		}
	}, 11);

	add_action('init', function() {
		if (did_action('elementor/loaded') || class_exists('\Elementor\Plugin')) {
			require_once FARAZSMS_NEXT_PLUGIN_DIR . 'includes/class-elementor-sms.php';
			if ( class_exists('FarazSMS_Next_Elementor_SMS') ) {
				FarazSMS_Next_Elementor_SMS::construct();
			}
		}
	}, 12);

	// v3.22.104: ثبتِ فیلدِ OTP و اکشنِ فرمِ المنتور پرو باید «زودهنگام» (پیش از fireشدنِ این اکشن‌ها
	// توسطِ المنتور پرو) حاضر باشد. قبلاً داخلِ construct روی init:12 اضافه می‌شد و روی برخی نصب‌ها دیر بود
	// → فیلدِ «تأیید موبایل با پیامک» در فهرستِ فیلدهای فرم ظاهر نمی‌شد (تیکت: «جای شماره نیست/وصل نیست»).
	// این هوک‌ها فقط وقتی المنتور پرو فعال باشد fire می‌شوند و کلاس را lazy لود می‌کنند (بدونِ خطای textdomain).
	add_action( 'elementor_pro/forms/fields/register', 'farazsms_elementor_register_otp_field_early', 10, 1 );
	add_action( 'elementor_pro/forms/actions/register', 'farazsms_elementor_register_form_action_early', 10, 1 );
}

/**
 * نمایش اعتبار پنل در نوار بالای پیشخوان (Admin Bar)
 */
function farazsms_admin_bar_credit( $wp_admin_bar ) {
	if ( ! is_admin() || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( get_option( 'farazsms_show_credit_in_admin_bar', '1' ) !== '1' ) {
		return;
	}
	$apikey = farazsms_get_apikey();
	if ( empty( $apikey ) || ! function_exists( 'farazsms_get_credit' ) ) {
		return;
	}
	$credit = farazsms_get_credit();
	if ( $credit === false || $credit === '' ) {
		return;
	}
	$wp_admin_bar->add_node( array(
		'id'     => 'farazsms-panel-credit',
		'title'  => 'اعتبار پنل فراز اس ام اس: ' . $credit . ' تومان',
		'parent' => 'top-secondary',
		'href'   => admin_url( 'admin.php?page=farazsms-settings' ),
		'meta'   => array( 'title' => 'تنظیمات فراز اس ام اس' ),
	) );
}
add_action( 'admin_bar_menu', 'farazsms_admin_bar_credit', 999 );
