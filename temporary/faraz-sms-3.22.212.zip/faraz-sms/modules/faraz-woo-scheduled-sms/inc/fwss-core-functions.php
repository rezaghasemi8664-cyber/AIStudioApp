<?php
/*
*
*	***** Faraz woo Scheduled sms *****
*
*	Core Functions
*	
*/
// If this file is called directly, abort. //
if ( ! defined( 'WPINC' ) ) {
	die;
} // end if
/*
*
* Custom Front End Ajax Scripts / Loads In WP Footer
*
*/
function fwss_frontend_ajax_form_scripts() {
	?>
    <script type="text/javascript">
        jQuery(document).ready(function ($) {
            "use strict";
            // add basic front-end ajax page scripts here
            $('#fwss_custom_plugin_form').submit(function (event) {
                event.preventDefault();
                // Vars
                var myInputFieldValue = $('#myInputField').val();
                // Ajaxify the Form
                var data = {
                    'action': 'fwss_custom_plugin_frontend_ajax',
                    'myInputFieldValue': myInputFieldValue,
                };

                // since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
                var ajaxurl = "<?php echo admin_url( 'admin-ajax.php' );?>";
                $.post(ajaxurl, data, function (response) {
                    console.log(response);
                    if (response.Status == true) {
                        console.log(response.message);
                        $('#fwss_custom_plugin_form_wrap').html(response);

                    } else {
                        console.log(response.message);
                        $('#fwss_custom_plugin_form_wrap').html(response);
                    }
                });
            });
        }(jQuery));
    </script>
<?php }

add_action( 'wp_footer', 'fwss_frontend_ajax_form_scripts' );

/**
 * استخراج متغیرهای استاندارد یک سفارش ووکامرس برای جایگذاری در متن پیامک.
 * هر متغیر هم با %name% و هم {name} پشتیبانی می‌شود (برای راحتی کاربر).
 *
 * @param WC_Order|int $order_or_id
 * @param array        $extra   متغیرهای اضافی (مثلاً برای پیامک محصول، p_name/p_price)
 * @return array  key=>value برای str_replace
 */
function fwss_get_order_variables( $order_or_id, $extra = array() ) {
	$order = ( $order_or_id instanceof WC_Order ) ? $order_or_id : wc_get_order( $order_or_id );
	if ( ! $order ) {
		return array();
	}
	$first_name = (string) $order->get_billing_first_name();
	$last_name  = (string) $order->get_billing_last_name();
	$fullname   = trim( $first_name . ' ' . $last_name );
	if ( $fullname === '' ) {
		$fullname = $order->get_formatted_billing_full_name();
	}
	$products = array();
	foreach ( $order->get_items() as $it ) {
		$products[] = $it->get_name();
	}
	$vars = array(
		'order_id'          => (string) $order->get_id(),
		'sitename'          => get_bloginfo( 'name' ),
		'customer_fullname' => $fullname,
		'first_name'        => $first_name,
		'last_name'         => $last_name,
		'b_first_name'      => $first_name,
		'b_last_name'       => $last_name,
		'billing_phone'     => (string) $order->get_billing_phone(),
		'total'             => farazsms_price_plain( $order->get_total() ),
		'products'          => implode( '، ', $products ),
		'city'              => (string) $order->get_billing_city(),
		'address'           => (string) $order->get_billing_address_1(),
	);
	return array_merge( $vars, $extra );
}

/**
 * جایگذاری متغیرها در متن — هم %name% و هم {name}.
 */
/**
 * ترمیمِ متنِ ذخیره‌شده‌ی پیامکِ زمان‌دار.
 *
 * متنِ این ماژول در post-meta می‌نشیند، پس مهاجرتِ ترمیمِ v3.22.177 (که فقط آپشن‌ها را
 * می‌گردد) هرگز به آن نمی‌رسد. تا وقتی متن دوباره ذخیره نشود، ترمیم باید هنگام مصرف
 * انجام شود.
 *
 * @param string $content
 * @return string
 */
function fwss_repair_content( $content ) {
	return farazsms_pattern_text_repair( (string) $content );
}

function fwss_replace_variables( $message, $vars ) {
	if ( ! is_array( $vars ) || empty( $vars ) ) {
		return $message;
	}
	$search  = array();
	$replace = array();
	foreach ( $vars as $k => $v ) {
		$search[]  = '%' . $k . '%';
		$replace[] = $v;
		$search[]  = '{' . $k . '}';
		$replace[] = $v;
	}
	return str_replace( $search, $replace, (string) $message );
}

function fwss_add_scheduled_sms_postbox() {
//	if(!MfnOoziKwMxcQkAbMtMe::is_activated()){return;}
	// فقط مدیرِ سایت این متاباکس را ببیند — نه فروشنده‌ها (دکان/WCFM) و نه ویرایشگرها.
	// add_meta_box پارامترِ دسترسی ندارد، پس گاردِ صریح لازم است.
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	add_meta_box(
		'fwss-scheduled-sms',
		'ارسال پیامک زماندار',
		'fwss_add_scheduled_sms_box',
		array('product','lp_course'),
		'normal',
		'core'
	);
}

add_action( 'add_meta_boxes', 'fwss_add_scheduled_sms_postbox' );

function fwss_add_scheduled_sms_box() {
	// v3.22.183 — اگر ماژول خاموش است، همین‌جا صریح بگو. متاباکس پنهان نمی‌شود چون کاربر
	// باید بتواند قوانینِ موجودش را ببیند؛ ولی نباید فکر کند این قوانین اجرا می‌شوند.
	if ( ! fwss_is_enabled() ) {
		echo '<div style="background:#fdecea;border:1px solid #d63638;color:#8a1f1d;padding:12px 16px;border-radius:8px;margin-bottom:14px;line-height:2;">'
			. '<strong>«اتومیشن مارکتینگ» در حال حاضر کاملاً خاموش است.</strong><br>'
			. 'قوانینِ زیر ذخیره می‌شوند ولی <strong>هیچ‌کدام اجرا نمی‌شوند</strong>. '
			. 'برای روشن‌کردن به <a href="' . esc_url( admin_url( 'admin.php?page=farazsms-automation' ) ) . '">تنظیماتِ اتومیشن مارکتینگ</a> بروید.'
			. '</div>';
	}
	$default_send_time = get_option( 'fwss_send_time', '16:59' );
	$p_id              = get_the_ID();
	$fwss_metas        = get_post_meta( $p_id, '_fwss_sms_metas', true ) ?? [];
	$index             = ! empty( $fwss_metas ) ? max( array_keys( $fwss_metas ) ) + 1 : 0;
	if ( get_post_type() === 'product' ):
		$statuses = wc_get_order_statuses();
    elseif ( get_post_type() === 'lp_course' ):
	    $statuses = learn_press_get_order_statuses();
	endif;
	$tip = '<h4 style="margin:0 0 8px;">متغیرهای قابل استفاده در متن پیام</h4>
                            <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:6px 16px; font-size:12px;">
                                <div><strong>اطلاعات محصول:</strong></div>
                                <div></div>
                                <div>%p_name% — نام محصول</div>
                                <div>%p_price% — قیمت</div>
                                <div>%p_link% — لینک محصول</div>
                                <div></div>
                                <div><strong>اطلاعات سفارش/خریدار:</strong></div>
                                <div></div>
                                <div>%order_id% — شماره سفارش</div>
                                <div>%customer_fullname% — نام کامل</div>
                                <div>%first_name% — نام</div>
                                <div>%last_name% — نام خانوادگی</div>
                                <div>%billing_phone% — تلفن</div>
                                <div>%total% — مبلغ سفارش</div>
                                <div>%city% — شهر</div>
                                <div>%sitename% — نام سایت</div>
                            </div>
                            <p style="margin-top:8px; font-size:11px; color:#9b9b9b;">هر متغیر را می‌توانید با هر دو قالب %نام% یا {نام} بنویسید.</p>';
	?>
    <div id="fwss_scheduled_sms_container">
        <?php wp_nonce_field( 'fwss_meta_save', 'fwss_meta_nonce' ); // v3.21.28 امنیتی (F1) ?>
        <div id="fwss_top">
            <div id="fwss_add_sms">اضافه کردن</div>
        </div>
        <div class="fwss-info-message">
		    <?php echo $tip; ?>
        </div>
        <input type="hidden" id="fwss_next_index" name="fwss_next_index" value="<?php echo $index; ?>">
        <div id="sms_container">
			<?php if ( ! empty( $fwss_metas ) ) {
				foreach ( $fwss_metas as $i => $fwss_meta ) { ?>
                    <div class="sms">
                        <div class="delete">
                            <div id="delete_row_<?php echo $i; ?>"><img
                                        src="https://img.icons8.com/windows/32/000000/macos-close.png"/></div>
                        </div>
                        <div class="active">
                            <label for="fwss_sms_active_<?php echo $i; ?>" class="toggle-control">
                                <input type="checkbox" id="fwss_sms_active_<?php echo $i; ?>"
                                       name="fwss_sms_meta[<?php echo $i; ?>][active]" <?php echo ( $fwss_meta['active'] == "on" ) ? "checked" : ''; ?>>
                                <span class="control"></span>
                            </label>
                        </div>
                        <div class="time">
                            <label for="fwss_sms_time_<?php echo $i; ?>">زمان</label>
                            <input type="number" min="0" class="fwss_time_input"
                                   name="fwss_sms_meta[<?php echo $i; ?>][time]" id="fwss_sms_time_<?php echo $i; ?>"
                                   value="<?php echo esc_attr( $fwss_meta['time'] ); ?>">
                            <span> روز بعد از</span>
                        </div>
                        <div class="order_status">
                            <label for="fwss_sms_order_status_<?php echo $i; ?>">وضعیت سفارش</label>
                            <select name="fwss_sms_meta[<?php echo $i; ?>][order_status]"
                                    id="fwss_sms_order_status_<?php echo $i; ?>">
								<?php
								foreach ( $statuses as $status => $status_name ) {
									$selected = $fwss_meta['order_status'] === $status ? "selected" : '';
									echo '<option value="' . esc_attr( $status ) . '"' . $selected . '>' . esc_html( $status_name ) . '</option>';
								}
								?>
                            </select>
                        </div>
                        <div class="hour">
                            <label for="fwss_sms_hour_<?php echo $i; ?>">ساعت</label>
                            <input type="text" placeholder="16:59" name="fwss_sms_meta[<?php echo $i; ?>][hour]"
                                   id="fwss_sms_hour_<?php echo $i; ?>"
                                   value="<?php echo esc_attr( ( isset( $fwss_meta['hour'] ) ) ? $fwss_meta['hour'] : $default_send_time ); ?>">
                        </div>
                        <div class="sms_content">
                            <label for="fwss_sms_content_0">متن پیام</label>
                            <textarea rows="5" cols="20" name="fwss_sms_meta[<?php echo $i; ?>][content]"
                                      id="fwss_sms_order_content_<?php echo $i; ?>"><?php echo esc_textarea( $fwss_meta['content'] ); ?></textarea>
                        </div>
                    </div>
				<?php }
			} ?>
        </div>
    </div>
	<?php
}

add_action( 'save_post', 'fwss_product_sms_meta_save' );
function fwss_product_sms_meta_save( $post_id ) {
    if (!isset($_POST['fwss_sms_meta'])){
        return;
    }
	// v3.21.28 امنیتی (F1) — nonce + capability + sanitize + جلوگیری از autosave.
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! isset( $_POST['fwss_meta_nonce'] ) || ! wp_verify_nonce( $_POST['fwss_meta_nonce'], 'fwss_meta_save' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	// دفاعِ لایه‌ای: نوشتنِ متای پیامکِ زماندار فقط برای مدیر (هم‌راستا با نمایشِ متاباکس).
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$raw = wp_unslash( $_POST['fwss_sms_meta'] );
	if ( ! is_array( $raw ) ) {
		return;
	}
	$clean = array();
	foreach ( $raw as $i => $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$clean[ (int) $i ] = array(
			'active'       => ( isset( $row['active'] ) && $row['active'] === 'on' ) ? 'on' : '',
			'time'         => isset( $row['time'] ) ? absint( $row['time'] ) : 0,
			'order_status' => isset( $row['order_status'] ) ? sanitize_text_field( $row['order_status'] ) : '',
			'hour'         => isset( $row['hour'] ) ? sanitize_text_field( $row['hour'] ) : '',
			// اعتبارسنجِ متنِ پترن پیش از همه‌ی مصرف‌کننده‌ها بار می‌شود (core-init)، پس
			// شاخه‌ی جایگزین فقط راهی می‌ماند که باگ از آن برگردد.
			'content'      => isset( $row['content'] ) ? farazsms_sanitize_pattern_text( $row['content'], false ) : '',
		);
	}
	if ( ! empty( $clean ) ) {
		update_post_meta( $post_id, '_fwss_sms_metas', $clean );
	}
}

add_action( 'woocommerce_order_status_changed', 'fwss_order_status_change_happened', 10, 3 );
function fwss_order_status_change_happened( $order_id, $status_changed_from, $status_changed_to ) {
	// v3.22.183 — کلیدِ خاموشیِ کلِ ماژول (بالادستِ هر چهار انبارِ قانون).
	// core-init.php فایلِ تعریفِ این تابع را پیش از همین فایل بار می‌کند (خط ۸۰ در برابر
	// ۸۴)، پس صدا زدنِ مستقیم درست است و گاردِ وجودِ تابع فقط نویز بود.
	if ( ! fwss_is_enabled() ) {
		return;
	}
	$order  = wc_get_order( $order_id );
	$mobile = $order->get_billing_phone();
       
	if ( empty( $mobile ) ) {
		return;
	}
   
	foreach ( $order->get_items() as $item_id => $item ) {
		$product_id             = $item->get_product_id();
		$registered_sms_to_send = get_post_meta( $product_id, '_fwss_sms_metas', true );
     
		if ( empty( $registered_sms_to_send ) ) {
			continue;
		}
     
		foreach ( $registered_sms_to_send as $i => $sms_meta ) {
          
			if ( $sms_meta['order_status'] === 'wc-' . $status_changed_to && $sms_meta['active'] === "on" && isset($sms_meta['time']) && ! empty( $sms_meta['content'] ) ) {
				// v3.21.28 (F4) idempotency — اگر این سفارش با ورود به همین وضعیت قبلاً برای همین
				// قانون زمان‌بندی شده، دوباره نفرست (وگرنه با تغییرِ مکررِ وضعیت، پیامکِ تکراری + هدررفتِ اعتبار).
				$fwss_sent_flag = '_fwss_sched_' . (int) $product_id . '_' . (int) $i . '_' . sanitize_key( (string) $status_changed_to );
				if ( $order->get_meta( $fwss_sent_flag ) === 'yes' ) {
					continue;
				}
				// v3.13.10: استفاده از helper یکپارچه — حالا همه متغیرهای سفارش/خریدار
				// در دسترس هستند (نه فقط p_name/p_price/p_link/sitename).
				// v3.22.143: لینکِ خوانا در متنِ پیامک (نامکِ فارسی → لینکِ شناسه‌ای، هم‌مقصد).
				$vars = fwss_get_order_variables( $order, array(
					'p_name'  => $item->get_name(),
					'p_price' => $item->get_subtotal(),
					'p_link'  => farazsms_sms_readable_post_link( $product_id ),
				) );
				$message = fwss_replace_variables( fwss_repair_content( $sms_meta['content'] ), $vars );
                

				// v3.22.202: از سازنده‌ی مشترک. پیش از این منطقه‌ی زمانی سخت
				// Asia/Tehran بود (سایتِ با تنظیمِ دیگر جابه‌جا می‌شد) و ساعتِ
				// خالی هم به مقدارِ پیش‌فرض برنمی‌گشت.
				$date_to_send = fwss_schedule_string(
					fwss_local_day( isset( $sms_meta['time'] ) ? (int) $sms_meta['time'] : 0, $order->get_date_modified( 'Y-m-d H:i:s' ) ),
					fwss_hour_or_default( isset( $sms_meta['hour'] ) ? $sms_meta['hour'] : '' )
				);

                
				fwss_send_scheduled_sms( $mobile, $date_to_send, $message );
				$order->update_meta_data( $fwss_sent_flag, 'yes' );
				$order->save();
			}
		}
	}
}

/*
 * fwss_monitor_update_user_metadata() در v3.22.202 حذف شد.
 *
 * ⚠️ هوکش سال‌ها کامنت بود، پس هرگز اجرا نمی‌شد — و خوب که اجرا نمی‌شد: بدنه‌اش
 * $order و $sms_meta را می‌خواند که در آن اسکوپ اصلاً تعریف نشده بودند. اولین
 * باری که کسی آن add_filter را از کامنت درمی‌آورد، هر به‌روزرسانیِ متای کاربر
 * با «Call to a member function get_date_modified() on null» سفید می‌شد.
 * کدِ مرده‌ای که فقط منتظرِ یک uncomment است، بدهی است نه ذخیره.
 */

add_action( 'user_register', 'fwss_after_user_registered', 99 );
function fwss_after_user_registered( $user_id ) {
	// v3.22.183 — کلیدِ خاموشیِ کلِ ماژول (بالادستِ هر چهار انبارِ قانون).
	// core-init.php فایلِ تعریفِ این تابع را پیش از همین فایل بار می‌کند (خط ۸۰ در برابر
	// ۸۴)، پس صدا زدنِ مستقیم درست است و گاردِ وجودِ تابع فقط نویز بود.
	if ( ! fwss_is_enabled() ) {
		return;
	}
	$already_sent_sms = get_user_meta( $user_id, 'fwss_sent_scheduled_sms_for_user', true );
	if ( ! empty( $already_sent_sms ) && $already_sent_sms === '1' ) {
		//return;
	}
	$fwss_active_digits          = get_option( 'fwss_active_digits', 'false' );
	$fwss_custom_phone_meta_keys = get_option( 'fwss_custom_phone_meta_keys', '' );
	if ( $fwss_active_digits === 'false' && empty( $fwss_custom_phone_meta_keys ) ) {
		return;
	}
	if ( $fwss_active_digits == 'true' ) {
		$digits_phone = get_user_meta( $user_id, 'digits_phone', true );
	} else if ( ! empty( $fwss_custom_phone_meta_keys ) ) {
		$digits_phone = get_user_meta( $user_id, $fwss_custom_phone_meta_keys, true );
	}
	if ( empty( $digits_phone ) ) {
		return;
	}
 
	$users_sms_data       = get_option( 'fwss_users_sms_data', [] );
	if ( empty( $users_sms_data ) ) {
		return;
	}
	$user         = get_userdata( $user_id );
	$display_name = $user->display_name;
	$user_name    = $user->user_login;
	foreach ( $users_sms_data as $user_sms_data ) {
		$message      = str_replace( array(
			'%display_name%',
			'%username%',
		), array(
			$display_name,
			$user_name,
		), $user_sms_data['content'] );
			// Build the scheduled send time using user_register time as the base (no $order in this scope).
			$date_to_send = fwss_schedule_string(
				fwss_local_day( isset( $user_sms_data['time'] ) ? (int) $user_sms_data['time'] : 0 ),
				fwss_hour_or_default( isset( $user_sms_data['hour'] ) ? $user_sms_data['hour'] : '' )
			);
			fwss_send_scheduled_sms( $digits_phone, $date_to_send, $message );
	}
	update_user_meta( $user_id, 'fwss_sent_scheduled_sms_for_user', '1' );
}

add_action( 'gform_entry_created', 'fwss_gf_field_filled' );
function fwss_gf_field_filled( $entry ) {
	// v3.22.183 — کلیدِ خاموشیِ کلِ ماژول (بالادستِ هر چهار انبارِ قانون).
	// core-init.php فایلِ تعریفِ این تابع را پیش از همین فایل بار می‌کند (خط ۸۰ در برابر
	// ۸۴)، پس صدا زدنِ مستقیم درست است و گاردِ وجودِ تابع فقط نویز بود.
	if ( ! fwss_is_enabled() ) {
		return;
	}
	$gf_sms_data = get_option( 'fwss_gf_sms_data', [] );
	foreach ( $gf_sms_data as $sms_data ) {
		$exploded = explode( "-", (string) ( $sms_data['gf_formatted_id'] ?? '' ) );
		// v3.21.28 (F8) — مقایسه‌ی عددی (form_id معمولاً int است و exploded رشته) + گاردِ index.
		if ( ! isset( $exploded[1] ) || (int) $exploded[0] !== (int) $entry['form_id'] ) {
			continue;
		}
		$mobile = isset( $entry[ $exploded[1] ] ) ? $entry[ $exploded[1] ] : '';
		if ( empty( $mobile ) ) {
			continue;
		}
		$result = true;
		if ( ! empty( $sms_data['condition_active'] ) && $sms_data['condition_active'] === "on" ) {
			$all_condition = $sms_data['all_or_one'];
			if ( $all_condition === 'all' ) {
				foreach ( $sms_data['condition'] as $condition ) {
					$result = fwss_matches_operation( $entry[ $condition['field'] ], $condition['value'], $condition['operator'] );
					if ( ! $result ) {
						break;
					}
				}
			} elseif ( $all_condition === 'any' ) {
				foreach ( $sms_data['condition'] as $condition ) {
					$result = fwss_matches_operation( $entry[ $condition['field'] ], $condition['value'], $condition['operator'] );
					if ( $result ) {
						break;
					}
				}
			}
		}
 	if ( $result ) {
			// v3.22.202: از همان سازنده‌ی مشترک — پیش از این این یک مسیر زمانِ
			// محلی می‌ساخت و پنج مسیرِ دیگر UTC.
			//
			// ⚠️ تاریخِ پایه با current_time گرفته می‌شود، نه date(). وردپرس
			// تایم‌زونِ PHP را UTC می‌گذارد، پس date('Y-m-d') تاریخِ UTC می‌داد در
			// حالی که سازنده تاریخِ **محلی** می‌خواهد: هر ارسالِ شبانه (پس از
			// ۲۰:۳۰ به وقتِ تهران) یک روز زودتر زمان‌بندی می‌شد.
			$date_to_send = fwss_schedule_string(
				fwss_local_day( (int) ( $sms_data['time'] ?? 0 ) ),
				fwss_hour_or_default( isset( $sms_data['hour'] ) ? $sms_data['hour'] : '' )
			);
			fwss_send_scheduled_sms( $mobile, $date_to_send, $sms_data['content'] );
		}

	}
}

add_action( 'gform_pre_submission', 'fwss_gf_pre_submission' );
function fwss_gf_pre_submission( $form ) {
	foreach ( $_POST as $name => $value ) {
		$_POST[ $name ] = fwss_tr_num( $value );
	}
}

function fwss_matches_operation( $val1, $val2, $operation ) {

	$val1 = ! rgblank( $val1 ) ? strtolower( $val1 ) : '';
	$val2 = ! rgblank( $val2 ) ? strtolower( $val2 ) : '';

	switch ( $operation ) {
		case 'is' :
			return $val1 == $val2;
			break;

		case 'isnot' :
			return $val1 != $val2;
			break;

		case 'greater_than':
		case '>' :
			$val1 = fwss_try_convert_float( $val1 );
			$val2 = fwss_try_convert_float( $val2 );

			return $val1 > $val2;
			break;

		case 'less_than':
		case '<' :
			$val1 = fwss_try_convert_float( $val1 );
			$val2 = fwss_try_convert_float( $val2 );

			return $val1 < $val2;
			break;

		case 'contains' :
			return ! rgblank( $val2 ) && strpos( $val1, $val2 ) !== false;
			break;

		case 'starts_with' :
			return ! rgblank( $val2 ) && strpos( $val1, $val2 ) === 0;
			break;

		case 'ends_with' :
			// If target value is a 0 set $val2 to 0 rather than the empty string it currently is to prevent false positives.
			if ( empty( $val2 ) ) {
				$val2 = '0';
			}

			$start = strlen( $val1 ) - strlen( $val2 );

			if ( $start < 0 ) {
				return false;
			}

			$tail = substr( $val1, $start );

			return $val2 == $tail;
			break;
	}


	return false;
}

function fwss_try_convert_float( $text ) {

	$number_format = 'decimal_dot';
	if ( GFCommon::is_numeric( $text, $number_format ) ) {
		return GFCommon::clean_number( $text, $number_format );
	}

	return 0;
}

add_action( 'init', 'fwss_wc_order_actions_sms' );
function fwss_wc_order_actions_sms() {
	// v3.22.183 — کلیدِ خاموشیِ کلِ ماژول (بالادستِ هر چهار انبارِ قانون).
	// core-init.php فایلِ تعریفِ این تابع را پیش از همین فایل بار می‌کند (خط ۸۰ در برابر
	// ۸۴)، پس صدا زدنِ مستقیم درست است و گاردِ وجودِ تابع فقط نویز بود.
	if ( ! fwss_is_enabled() ) {
		return;
	}
	if (!function_exists('is_woocommerce')){
        return;
    }
	$wc_sms = get_option( 'fwss_wc_sms_data' );
	if ( $wc_sms && is_array( $wc_sms ) ) {
		foreach ( $wc_sms as $sms ) {
			if ( ! isset( $sms['active'] ) ) {
				continue;
			}
			$status = str_replace( 'wc-', '', $sms['order_status'] );
			add_action( 'woocommerce_order_status_' . $status, function ( $order_id ) use ( $sms, $status ) {
				$order  = wc_get_order( $order_id );
				$mobile = $order->get_billing_phone();
				if ( empty( $mobile ) || empty( $sms['content'] ) || ! isset( $sms['time'] ) ) {
					return;
				}
				// v3.13.10: همه متغیرهای استاندارد سفارش (نه فقط order_id/sitename)
				$vars = fwss_get_order_variables( $order );
				$message = fwss_replace_variables( $sms['content'], $vars );
				// Build the scheduled send time. Local loop var is $sms (not $sms_meta).
				$order_modified_obj = $order->get_date_modified();
				$date_to_send       = fwss_schedule_string(
					fwss_local_day(
						isset( $sms['time'] ) ? (int) $sms['time'] : 0,
						$order_modified_obj ? $order_modified_obj->format( 'Y-m-d H:i:s' ) : null
					),
					fwss_hour_or_default( isset( $sms['hour'] ) ? $sms['hour'] : '' )
				);
				fwss_send_scheduled_sms( $mobile, $date_to_send, $message );
			}, 10, 1 );
		}
	}
}

add_action( 'learn-press/order/status-changed', 'fwss_order_lms_changed_status', 10, 3 );
function fwss_order_lms_changed_status( $order_id, $old_status, $new_status ) {
	// v3.22.183 — کلیدِ خاموشیِ کلِ ماژول (بالادستِ هر چهار انبارِ قانون).
	// core-init.php فایلِ تعریفِ این تابع را پیش از همین فایل بار می‌کند (خط ۸۰ در برابر
	// ۸۴)، پس صدا زدنِ مستقیم درست است و گاردِ وجودِ تابع فقط نویز بود.
	if ( ! fwss_is_enabled() ) {
		return;
	}
	$order = learn_press_get_order( $order_id );
    $user_id = $order->get_user_id();
	$fwss_custom_phone_meta_keys = get_option( 'fwss_custom_phone_meta_keys', '' );
	$mobile = get_user_meta( $user_id, $fwss_custom_phone_meta_keys, true );
	if ( empty( $mobile ) ) {
		return;
	}
	foreach ( $order->get_items() as $item_id => $item ) {
		$product_id             = $item['course_id'];
		$registered_sms_to_send = get_post_meta( $product_id, '_fwss_sms_metas', true );
		if ( empty( $registered_sms_to_send ) ) {
			continue;
		}
		foreach ( $registered_sms_to_send as $i => $sms_meta ) {
			if ( $sms_meta['order_status'] === 'lp-' . $new_status && $sms_meta['active'] === "on" && ! empty( $sms_meta['time'] ) && ! empty( $sms_meta['content'] ) ) {
			$message              = str_replace( array(
				'%p_name%',
				'%p_price%',
				'%sitename%',
				'%p_link%',
			), array(
				$item['name'],
				$item['subtotal'],
				get_bloginfo( "name" ),
				// v3.22.143: لینکِ خوانا (نامکِ فارسی → لینکِ شناسه‌ای، هم‌مقصد).
				farazsms_sms_readable_post_link( $product_id )), fwss_repair_content( $sms_meta['content'] ) );
			// $sms_meta and $order are defined in this scope (LP order loop).
			$order_modified_obj = method_exists( $order, 'get_date_modified' ) ? $order->get_date_modified() : null;
			$base_local         = ( is_object( $order_modified_obj ) && method_exists( $order_modified_obj, 'format' ) )
				? $order_modified_obj->format( 'Y-m-d H:i:s' )
				: null;
			$date_to_send = fwss_schedule_string(
				fwss_local_day( isset( $sms_meta['time'] ) ? (int) $sms_meta['time'] : 0, $base_local ),
				fwss_hour_or_default( isset( $sms_meta['hour'] ) ? $sms_meta['hour'] : '' )
			);
			fwss_send_scheduled_sms( $mobile, $date_to_send, $message );
			}
		}
	}
}

/**
 * فهرستِ محصولات/دوره‌هایی که قانونِ پیامکِ زمان‌دار دارند.
 *
 * ⚠️ v3.22.183 — نبودنِ همین فهرست، ریشه‌ی یکی از طولانی‌ترین تیکت‌های پشتیبانی بود:
 * قوانینِ این ماژول روی متای تک‌تکِ محصولات می‌نشینند و در صفحه‌ی تنظیمات هیچ ردی
 * از خود نشان نمی‌دادند. پشتیبان بارها در صفحه‌ی تنظیمات چیزی را «غیرفعال» کرد که
 * اصلاً منبعِ آن پیامک نبود.
 *
 * @param int $limit سقفِ تعداد (محافظت از فروشگاه‌های بزرگ).
 * @return array<int, array{id:int, title:string, edit:string, total:int, active:int}>
 */
function fwss_product_rules_index( $limit = 200, $offset = 0 ) {
	$ids = get_posts( array(
		'post_type'        => array( 'product', 'lp_course' ),
		'post_status'      => 'any',
		'posts_per_page'   => (int) $limit,
		'offset'           => (int) $offset,
		// ترتیبِ پایدار لازم است: خاموش‌سازیِ گروهی با offset صفحه‌به‌صفحه جلو می‌رود و
		// ترتیبِ متغیر یعنی جاافتادنِ محصول.
		'orderby'          => 'ID',
		'order'            => 'ASC',
		'fields'           => 'ids',
		'meta_key'         => '_fwss_sms_metas',
		'suppress_filters' => true,
		'no_found_rows'    => true,
	) );

	$out = array();
	foreach ( (array) $ids as $id ) {
		$metas = get_post_meta( $id, '_fwss_sms_metas', true );
		if ( ! is_array( $metas ) || empty( $metas ) ) {
			continue;
		}
		$active = 0;
		foreach ( $metas as $row ) {
			if ( is_array( $row ) && isset( $row['active'] ) && $row['active'] === 'on' ) {
				$active++;
			}
		}
		$out[] = array(
			'id'     => (int) $id,
			'title'  => get_the_title( $id ),
			'edit'   => get_edit_post_link( $id, 'raw' ),
			'total'  => count( $metas ),
			'active' => $active,
			// v3.22.184 — همان متایی که همین‌جا خوانده شد، تا خاموش‌سازیِ گروهی مجبور
			// نباشد برای هر محصول دوباره از دیتابیس بخواند.
			'metas'  => $metas,
		);
	}
	// پرقانون‌ترین‌ها اول — همان‌هایی که احتمالاً منبعِ پیامکِ ناخواسته‌اند.
	usort( $out, function ( $a, $b ) {
		return $b['active'] <=> $a['active'];
	} );
	return $out;
}

/**
 * تعدادِ واقعیِ محصولاتی که قانونِ پیامک دارند — بدونِ سقفِ نمایش.
 *
 * v3.22.184 (کدریویو) — فهرست سقفِ ۲۰۰ دارد، پس شمارشِ گرفته‌شده از خودِ فهرست روی
 * فروشگاه‌های بزرگ کمتر از واقعیت بود و دکمه‌ی «خاموش‌کردنِ همه» ممکن بود اصلاً نمایش
 * داده نشود در حالی که قوانینِ فعال وجود داشتند. عدد باید از دیتابیس بیاید، نه از
 * بریده‌ی نمایش (قانونِ پروژه: گزارشِ عددی به کاربر نباید حدس باشد).
 *
 * @return int
 */
function fwss_product_rules_total() {
	global $wpdb;
	return (int) $wpdb->get_var(
		$wpdb->prepare(
			"SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = %s",
			'_fwss_sms_metas'
		)
	);
}

/**
 * سقفِ هر بستهٔ خاموش‌سازی.
 *
 * v3.22.184 (کدریویو) — قبلاً تا ۱۰هزار محصول در یک ریکوئستِ admin-ajax نوشته می‌شد؛
 * روی کاتالوگِ بزرگ تایم‌اوت می‌داد و کاربر فقط «ارتباط برقرار نشد» می‌دید، در حالی که
 * بخشی از قوانین واقعاً خاموش شده بودند. حالا بسته‌بسته پیش می‌رود و JS تا پایان ادامه
 * می‌دهد.
 */
if ( ! defined( 'FWSS_DISABLE_BATCH' ) ) {
	define( 'FWSS_DISABLE_BATCH', 200 );
}

/**
 * خاموش‌کردنِ یک بستهٔ قوانینِ روی محصولات (بدونِ حذفِ متن).
 *
 * با offset صفحه‌به‌صفحه جلو می‌رود؛ خاموش‌کردن کلیدِ متا را حذف نمی‌کند، پس مجموعه‌ی
 * نتیجه پایدار می‌مانَد و offset جا نمی‌اندازد.
 *
 * @param int $offset
 * @return array{products:int, rules:int, next_offset:int, done:bool}
 */
function fwss_disable_all_product_rules( $offset = 0 ) {
	$offset   = max( 0, (int) $offset );
	$batch    = fwss_product_rules_index( FWSS_DISABLE_BATCH, $offset );
	$products = 0;
	$rules    = 0;
	foreach ( $batch as $row ) {
		$result = fwss_disable_rules_in_metas( $row['metas'] );
		if ( $result['changed'] > 0 ) {
			update_post_meta( $row['id'], '_fwss_sms_metas', $result['rules'] );
			$products++;
			$rules += $result['changed'];
		}
	}
	$seen = count( $batch );
	return array(
		'products'    => $products,
		'rules'       => $rules,
		'next_offset' => $offset + $seen,
		'done'        => ( $seen < FWSS_DISABLE_BATCH ),
	);
}
