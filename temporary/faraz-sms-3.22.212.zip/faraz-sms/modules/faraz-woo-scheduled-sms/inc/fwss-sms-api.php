<?php
if ( ! defined( 'WPINC' ) ) {
	die;
}

 

function fwss_tr_num( $str ) {
	$num_a = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.' );
	$key_a = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );

	return str_replace( $key_a, $num_a, $str );
}

// اعتبارسنجیِ نام‌کاربری/رمزِ نسلِ قبل حذف شد (v3.22.159).

function fwss_get_credit( $api_key ) {
	// v3.21.28 (F5) — کش ۱۵ دقیقه‌ای تا روی هر رندرِ صفحه‌ی تنظیمات یک HTTPِ بلاک‌کننده‌ی خارجی
	// نخورد (قانونِ no-blocking؛ زیرِ اینترنتِ ملی صفحه را hang می‌کرد). دکمه‌ی تازه‌سازی می‌تواند
	// با حذفِ این transient، مقدارِ تازه بگیرد.
	$cache_key = 'fwss_credit_' . md5( (string) $api_key );
	$cached    = get_transient( $cache_key );
	if ( $cached !== false ) {
		return $cached;
	}

	$response = wp_remote_get( 'https://api.iranpayamak.com/ws/v1/account/balance', array(
		'timeout' => 8,
		'headers' => array(
			'Accept'  => 'application/json',
			'Api-Key' => $api_key,
		),
	) );

	if ( is_wp_error( $response ) ) {
		return false;
	}

	$body = wp_remote_retrieve_body( $response );
	$data = json_decode( $body, true );

	// بررسی صحت و وجود داده‌های مورد انتظار
	if ( ! isset( $data['status'] ) || $data['status'] !== 'success' ) {
		return false;
	}

	if ( ! isset( $data['data']['balance_amount'] ) ) {
		return false;
	}

	// تبدیل به عدد صحیح و فرمت مناسب برای نمایش
	$credit    = intval( $data['data']['balance_amount'] );
	$formatted = number_format( $credit );
	set_transient( $cache_key, $formatted, 15 * MINUTE_IN_SECONDS );
	return $formatted;
}

/**
 * کلید API: اولویت با تنظیمات افزونه فراز اس ام اس، سپس fwss_apikey قدیمی.
 *
 * @return string
 */
function fwss_get_effective_apikey() {
	$k = farazsms_get_apikey();
	if ( ! empty( $k ) ) {
		return $k;
	}
	return get_option( 'fwss_apikey', '' );
}

/**
 * خطِ ارسالِ مؤثرِ این ماژول.
 *
 * ⚠️ v3.22.182 — باگِ واقعیِ گزارش‌شده: fallback قبلی به `farazsms_sender` (خطِ **خدماتی**)
 * بود. این ماژول «اتومیشن مارکتینگ» است و پیامش تبلیغاتی است، پس اپراتور آن را روی خطِ
 * خدماتی رد می‌کرد: «ارسال پیام تبلیغاتی با خط pro انجام شود». بدتر اینکه صفحه‌ی تنظیماتِ
 * همین ماژول پیش‌فرض را PRO نشان می‌داد — یعنی کاربر PRO می‌دید و کد خطِ خدماتی می‌فرستاد.
 *
 * حالا مثلِ بقیه‌ی قابلیت‌های پروموشنال از خطِ تبلیغاتی می‌رود (قانونِ ۴ پروژه).
 *
 * @return string
 */
function fwss_effective_sender() {
	$sender = trim( (string) get_option( 'fwss_sender', '' ) );
	if ( $sender !== '' ) {
		return $sender;
	}
	return farazsms_get_ad_sender();
}

/**
 * آیا کلِ ماژولِ «اتومیشن مارکتینگ» روشن است؟
 *
 * ⚠️ v3.22.183 — چرا این وجود دارد: تا پیش از این، هیچ راهی برای خاموش‌کردنِ این ماژول
 * نبود. قوانینِ آن در **چهار انبارِ جدا** نگهداری می‌شوند و یکی‌شان اصلاً در صفحه‌ی
 * تنظیمات دیده نمی‌شود (متای تک‌تکِ محصولات). نتیجه در عمل: کاربر و حتی پشتیبانی
 * چند بار «غیرفعال کردیم» گفتند و پیامک باز هم رفت، چون قانونِ فعال جای دیگری بود.
 *
 * این کلید بالادستِ هر چهار انبار می‌نشیند: وقتی خاموش است، هیچ تریگری زمان‌بندی
 * نمی‌کند و هیچ چیزی از تابعِ ارسال بیرون نمی‌رود.
 *
 * پیش‌فرض «روشن» است تا سایت‌هایی که امروز از آن استفاده می‌کنند با به‌روزرسانی
 * قابلیتشان را از دست ندهند.
 *
 * @return bool
 */
function fwss_is_enabled() {
	return get_option( 'fwss_module_enabled', '1' ) !== '0';
}

/**
 * خاموش‌کردنِ همه‌ی ردیف‌های یک آرایه‌ی قوانین (بدونِ حذفِ متن).
 *
 * جدا و خالص نگه داشته شده تا هم روی متای محصول و هم روی optionها یک رفتار داشته باشد
 * و بشود تستش کرد. حذف نمی‌کند چون کاربر ممکن است بعداً بخواهد دوباره روشن کند.
 *
 * @param mixed $rules
 * @return array{rules: array, changed: int}
 */
function fwss_disable_rules_in_metas( $rules ) {
	$changed = 0;
	if ( ! is_array( $rules ) ) {
		return array( 'rules' => array(), 'changed' => 0 );
	}
	foreach ( $rules as $i => $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		if ( isset( $row['active'] ) && $row['active'] === 'on' ) {
			$rules[ $i ]['active'] = '';
			$changed++;
		}
	}
	return array( 'rules' => $rules, 'changed' => $changed );
}

/**
 * Normalize mobile to local Iranian format where possible.
 *
 * @param string $mobile
 * @return string
 */
function fwss_normalize_mobile( $mobile ) {
	$mobile = fwss_tr_num( (string) $mobile );
	return farazsms_normalize_phone( $mobile );
}

/**
 * آیا این سررسید هنوز «امروز» است؟
 *
 * ⚠️ v3.22.202 — سومین و آخرین شکلِ این قاعده. مسیرش این بود:
 *
 *   نسخه‌ی ۲۰۱: هیچ قاعده‌ای نبود. پیامکِ سه‌روز-دیر هم می‌رفت و فروشنده
 *   نمی‌فهمید چرا مشتری پیامِ بی‌ربط گرفته.
 *
 *   تلاشِ اول: پنجره‌ی یک‌ساعته از لحظه‌ی ارسال. ولی روی هاستِ بدونِ کرون —
 *   همان هاستی که این صف برایش هست — تخلیه با سقفِ سه‌کار در هر بازدیدِ
 *   پیشخوان انجام می‌شود، پس یک ساعت یعنی حذفِ پیامکی که فقط دیر تحویل
 *   شده بود.
 *
 *   تلاشِ دوم: سنجش از لحظه‌ی صف‌گذاری. آن، قاعده را برای حالتِ اصلی
 *   بی‌اثر می‌کرد: سررسیدی که موقعِ صف‌گذاری آینده بود هرگز کهنه نمی‌شد.
 *
 * قاعده‌ی نهایی، **روزِ تقویمیِ محلی** است: تا پایانِ همان روزی که سررسید
 * در آن بوده، ارسال معنا دارد؛ از فردا نه. سه ویژگی دارد که پنجره‌ی غلتان
 * نداشت: به فروشنده در یک جمله قابلِ توضیح است، هرگز پیامکِ ساعتِ چهارِ
 * صبح نمی‌سازد (پنجره‌ی غلتانِ شش‌ساعته می‌ساخت)، و تأخیرِ چندساعته‌ی صف را
 * — که همان روز جبران می‌شود — به حذف ترجمه نمی‌کند.
 *
 * @param string   $date_to_send رشته‌ی UTC.
 * @param int|null $now
 * @return bool
 */
function fwss_schedule_within_grace( $date_to_send, $now = null ) {
	$dt = date_create_immutable( trim( (string) $date_to_send ), new DateTimeZone( 'UTC' ) );
	if ( ! $dt ) {
		return false;
	}
	$tz  = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'Asia/Tehran' );
	$now = ( $now === null ) ? time() : (int) $now;

	$due_day = $dt->setTimezone( $tz )->format( 'Y-m-d' );
	$now_day = ( new DateTimeImmutable( '@' . $now ) )->setTimezone( $tz )->format( 'Y-m-d' );

	return $due_day === $now_day;
}

/**
 * رشته‌ی زمان‌بندی برای پنل — همیشه UTC.
 *
 * ⚠️ چرا یک تابع: پنج تولیدکننده رشته را با setTimezone('UTC') می‌ساختند و
 * مسیرِ گرویتی‌فرم با date() یعنی زمانِ **محلی**. دو قرارداد برای یک رشته،
 * که هم پنل را گمراه می‌کرد و هم گاردِ «گذشته یا آینده» را.
 *
 * @param string $day_ymd تاریخِ محلی به شکلِ Y-m-d.
 * @param string $hour    ساعتِ محلی به شکلِ H:i.
 * @return string
 */
function fwss_schedule_string( $day_ymd, $hour ) {
	$tz  = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'Asia/Tehran' );
	$dt  = date_create_immutable( trim( $day_ymd ) . ' ' . trim( $hour ) . ':00', $tz );
	if ( ! $dt ) {
		return '';
	}
	return $dt->setTimezone( new DateTimeZone( 'UTC' ) )->format( 'Y-m-d\TH:i:s' );
}

/**
 * ساعتِ ارسال، یا پیش‌فرضِ ماژول.
 *
 * ⚠️ پنج تولیدکننده این چند خط را تکرار می‌کردند و **دو** تایشان با ?? نوشته
 * بودند، که فقط null را می‌گیرد نه رشته‌ی خالی. ساعتِ خالی از آن‌ها رد می‌شد،
 * رشته‌ی زمان‌بندی نامعتبر می‌شد و پایین‌دست «بی‌زمان‌بندی» تعبیر می‌گشت —
 * یعنی پیامکِ فردا، همین حالا.
 *
 * @param mixed $raw
 * @return string
 */
function fwss_hour_or_default( $raw ) {
	$hour = fwss_valid_hour( $raw );
	if ( $hour !== '' ) {
		return $hour;
	}
	$hour = fwss_valid_hour( get_option( 'fwss_send_time', '' ) );
	// ⚠️ آرگومانِ دومِ get_option فقط وقتی اثر دارد که آپشن **موجود نباشد**.
	// فیلدِ خالیِ فرم مقدارِ '' ذخیره می‌کند و آن آپشن موجود است، پس پیش‌فرض
	// دور زده می‌شد: رشته‌ی خالی → سازنده‌ی زمان‌بندی '' → پایین‌دست
	// «بی‌زمان‌بندی» → ارسالِ فوریِ **هر** پیامکِ اتومیشن. دیوارِ آخر این‌جاست،
	// مستقل از اینکه چه چیزی در دیتابیس نشسته باشد.
	return $hour !== '' ? $hour : FWSS_DEFAULT_SEND_TIME;
}

/** ساعتِ پیش‌فرضِ ماژول — یک نقطه، تا فرم و ارسال هرگز از هم جدا نشوند. */
const FWSS_DEFAULT_SEND_TIME = '16:59';

/**
 * ساعتِ معتبر به شکلِ H:i، یا رشته‌ی خالی.
 *
 * ⚠️ ورودی از فرم می‌آید و هیچ اعتبارسنجی‌ای هنگامِ ذخیره ندارد؛ پس هر چیزی
 * می‌تواند در آپشن باشد: خالی، «۱۶:۵۹» با رقمِ فارسی، «9.30»، «25:00».
 * همه‌ی این‌ها ساخت را می‌شکنند و شکستِ ساخت یعنی ارسالِ فوری.
 *
 * @param mixed $raw
 * @return string
 */
function fwss_valid_hour( $raw ) {
	$raw = is_scalar( $raw ) ? trim( (string) $raw ) : '';
	if ( $raw === '' ) {
		return '';
	}
	if ( function_exists( 'fwss_tr_num' ) ) {
		$raw = trim( (string) fwss_tr_num( $raw ) ); // ارقامِ فارسی/عربی → لاتین
	}
	if ( ! preg_match( '/^(\d{1,2}):(\d{2})$/', $raw, $m ) ) {
		return '';
	}
	$h = (int) $m[1];
	$i = (int) $m[2];
	if ( $h > 23 || $i > 59 ) {
		return '';
	}
	return sprintf( '%02d:%02d', $h, $i );
}

/**
 * تاریخِ محلیِ سایت، N روز پس از یک مبنا.
 *
 * ⚠️ مبنا اگر داده نشود «اکنونِ سایت» است، نه اکنونِ UTC. وردپرس تایم‌زونِ PHP
 * را UTC می‌گذارد، پس date('Y-m-d') روی سایتِ تهران بین ۲۰:۳۰ تا نیمه‌شب
 * تاریخِ **دیروز** می‌داد و زمان‌بندی یک روز زودتر می‌افتاد.
 *
 * @param int         $days_ahead
 * @param string|null $base_local ساعتِ دیواریِ محلی به شکلِ Y-m-d H:i:s؛ null = اکنون.
 * @return string Y-m-d
 */
function fwss_local_day( $days_ahead, $base_local = null ) {
	$tz   = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'Asia/Tehran' );
	$base = ( $base_local === null ) ? '' : trim( (string) $base_local );
	// ⚠️ date_create و نه new DateTime: مبنا از دیتابیس می‌آید (تاریخِ سفارش)، و
	// رشته‌ی خرابْ سازنده را **پرتاب** می‌کند — روی هوکِ تغییرِ وضعیتِ سفارش،
	// یعنی خطای مرگبار روی درخواستی که مشتری منتظرش است. ورودیِ بیرونی قرارداد
	// ندارد، پس بازگشتِ امن بخشی از قرارداد است.
	$dt = ( $base === '' ) ? false : date_create( $base, $tz );
	// ⚠️ «پارس شد» کافی نیست: تاریخِ صفرِ MySQL ('0000-00-00 00:00:00') را
	// date_create با موفقیت به سالِ ‎-۰۰۰۱ تبدیل می‌کند و آن‌وقت زمان‌بندی به
	// دو هزار سال پیش می‌رفت — یعنی «گذشته» و ارسالِ فوری. سالِ بی‌معنا هم
	// همان شکستِ پارس است.
	if ( ! $dt || (int) $dt->format( 'Y' ) < 2000 ) {
		$dt = new DateTime( 'now', $tz );
	}
	$dt->modify( ( (int) $days_ahead >= 0 ? '+' : '' ) . (int) $days_ahead . ' days' );
	return $dt->format( 'Y-m-d' );
}

/**
 * آیا این زمان‌بندی هنوز در آینده است؟
 *
 * منطقِ خالص تا هر مرزی آزمودنی باشد. رشته‌ی خالی یعنی «بی‌زمان‌بندی» و
 * ارسالِ بی‌درنگ، پس آینده نیست.
 *
 * ⚠️ رشته‌ی ورودی **UTC** است، نه محلی: سازنده‌اش در fwss-core-functions.php
 * پیش از format صریحاً setTimezone('UTC') می‌زند. پس مبنای مقایسه هم باید
 * لحظه‌ی واقعی باشد (time)، نه current_time('timestamp') که مهرِ زمانیِ
 * «محلی‌نما» می‌دهد و به‌اندازه‌ی gmt_offset جلوتر است.
 *
 * نسخه‌ی اولِ این تابع (v3.22.201) همان اشتباه را داشت: هر زمان‌بندیِ نزدیک‌تر
 * از gmt_offset — برای تهران ۳٫۵ ساعت — «گذشته» خوانده می‌شد و پیامک به‌جای
 * زمانِ مقرر بی‌درنگ می‌رفت. همان خانواده‌ی باگی که پیش‌تر در کش‌بک دیده شد.
 *
 * منطقه‌ی زمانی صریح پارس می‌شود تا به تنظیمِ محیط وابسته نباشد.
 *
 * @param string   $date_to_send فرمتِ ISO به وقتِ UTC.
 * @param int|null $now          لحظه‌ی واقعی (UTC)؛ null = اکنون.
 * @return bool
 */
function fwss_schedule_is_future( $date_to_send, $now = null ) {
	$date_to_send = trim( (string) $date_to_send );
	if ( $date_to_send === '' ) {
		return false;
	}
	$dt = date_create_immutable( $date_to_send, new DateTimeZone( 'UTC' ) );
	if ( ! $dt ) {
		return false;
	}
	$now = ( $now === null ) ? time() : (int) $now;
	return $dt->getTimestamp() > $now;
}

function fwss_send_scheduled_sms( $mobile, $date_to_send, $message ) {
	// ⚠️ v3.22.201 — این تابع روی هوک‌هایی صدا زده می‌شود که کاربر منتظرشان است:
	// تغییرِ وضعیتِ سفارش (بازگشت از درگاه)، ثبت‌نام، و ارسالِ فرمِ گرویتی. تا اینجا
	// یک curlِ ۱۵ثانیه‌ای روی همان درخواست بود.
	//
	// شش فراخوانی دارد و هیچ‌کدام مقدارِ بازگشتی را نمی‌خوانند، پس تعویق در همین
	// گلوگاه هر شش را می‌پوشاند — نه شش وصله‌ی جدا.
	//
	// گاردِ خاموشیِ ماژول عمداً **پیش از** صف‌گذاری می‌ماند: کارِ ماژولِ خاموش
	// نباید حتی وارد صف شود.
	if ( ! fwss_is_enabled() ) {
		farazsms_send_diag_log(
			fwss_normalize_mobile( $mobile ),
			'simple',
			'skipped:module_disabled',
			array( 'source' => 'fwss-scheduled' )
		);
		return;
	}
	// ⚠️ رشته‌ی خالی یعنی **ساختِ زمان‌بندی شکست خورده**، نه «بی‌زمان‌بندی».
	// هر پنج تولیدکننده‌ی این ماژول همیشه از fwss_schedule_string رد می‌شوند، پس
	// خالی‌بودن فقط یک معنا دارد: ساعت یا تاریخ نامعتبر بوده. پایین‌دست آن را
	// «همین حالا بفرست» می‌فهمید — یعنی یک باگِ زمان‌بندی بی‌صدا به پیامکِ در
	// زمانِ غلط تبدیل می‌شد. تنها مسیرِ گم‌شدنِ این نسخه که ردِ تشخیص نداشت.
	if ( trim( (string) $date_to_send ) === '' ) {
		farazsms_send_diag_log(
			fwss_normalize_mobile( $mobile ),
			'simple',
			'skipped:bad_schedule',
			array( 'source' => 'fwss-scheduled' )
		);
		return;
	}
	farazsms_queue_task( 'fwss-scheduled', 'fwss_send_scheduled_sms_now', array(
		(string) $mobile,
		(string) $date_to_send,
		(string) $message,
	) );
}

/**
 * کارِ واقعیِ ارسال — بیرون از درخواستی که کاربر منتظرش است.
 *
 * @param string $mobile
 * @param string $date_to_send
 * @param string $message
 * @return void
 */
function fwss_send_scheduled_sms_now( $mobile, $date_to_send, $message ) {
	// گاردِ نهایی: تنها نقطه‌ی خروجِ این ماژول. حتی اگر تریگری از قلم بیفتد یا افزونه‌ی
	// دیگری مستقیم این تابع را صدا بزند، خاموش یعنی خاموش.
	//
	// v3.22.184 (کدریویو) — ولی بی‌صدا نه. بدونِ این رد، پشتیبانی باز هم نمی‌تواند
	// «ماژول خاموش است» را از «تریگر اصلاً اجرا نشد» تفکیک کند — همان ابهامی که
	// تیکت‌های طولانی را ساخت.
	if ( ! fwss_is_enabled() ) {
		farazsms_send_diag_log(
			fwss_normalize_mobile( $mobile ),
			'simple',
			'skipped:module_disabled',
			array( 'source' => 'fwss-scheduled' )
		);
		return;
	}
	$sender = fwss_effective_sender();
	$apikey = fwss_get_effective_apikey();
	if ( empty( $message ) || empty( $apikey ) ) {
		return;
	}
	$mobile = fwss_normalize_mobile( $mobile );

	$body = array(
		'text'            => $message,
		'line_number'     => $sender,
		'recipients'      => array( $mobile ),
		'number_format'   => 'english',
	);
	// زمان‌بندیِ آینده همان‌طور می‌رود.
	if ( fwss_schedule_is_future( $date_to_send ) ) {
		$body['schedule'] = $date_to_send;
	} elseif ( trim( (string) $date_to_send ) !== '' && ! fwss_schedule_within_grace( $date_to_send ) ) {
		// ⚠️ سررسید به روزِ گذشته تعلق دارد: ارسالِ فوری غلط است. پیامکِ
		// پیگیریِ پس‌ازخرید که دیروز سررسید داشته، امروز نباید ناگهان برود.
		// بی‌صدا هم رها نمی‌شود — ردِ تشخیص می‌ماند.
		farazsms_send_diag_log( $mobile, 'simple', 'skipped:stale_schedule', array(
			'source' => 'fwss-scheduled',
			'detail' => 'due=' . $date_to_send,
		) );
		return;
	}

	// ⚠️ v3.22.202: ترنسپورت از curlِ خام به لایه‌ی HTTPِ وردپرس منتقل شد.
	// دلیلِ اول درست‌بودن است (پروکسی، فیلترها، و تایم‌اوتِ یکسان با بقیه‌ی
	// افزونه)، ولی دلیلِ دومش سنگین‌تر بود: با curlِ خام هیچ تستی نمی‌توانست
	// این مسیر را ببندد، و ادعای «روی درخواستِ کاربر هیچ HTTPی نمی‌رود» در
	// سوئیت **قابلِ‌شکست نبود** — یعنی رگرسیون به‌جای قرمزشدن، به سرویسِ
	// واقعی پیامک می‌فرستاد.
	$resp = wp_remote_post(
		'https://api.iranpayamak.com/ws/v1/sms/simple',
		array(
			// سقفِ کلِ درخواست همان ۱۵ ثانیه‌ی قبلی است. یک تفاوتِ واقعی هست و
			// پنهانش نمی‌کنیم: سقفِ جداگانه‌ی **اتصال** (۵ ثانیه) در لایه‌ی
			// HTTPِ وردپرس معادل ندارد، پس میزبانی که بسته را می‌بلعد تا پایانِ
			// همان ۱۵ ثانیه worker را نگه می‌دارد، نه ۵ ثانیه. این عدد را
			// افزونه‌های دیگر هم می‌توانند با فیلترِ http_request_timeout عوض کنند.
			'timeout'   => 15,
			'sslverify' => true,
			'headers'   => array(
				'Accept'       => 'application/json',
				'Content-Type' => 'application/json',
				'Api-Key'      => $apikey,
			),
			'body'      => wp_json_encode( $body ),
		)
	);

	// v3.22.29: نتیجه‌ی ارسال را در لاگِ «🩺 تشخیص ارسال» ثبت کن. قبلاً خروجی کاملاً دور
	// ریخته می‌شد و شکستِ پیامکِ زمان‌بندی‌شده (پس‌ازخرید) هیچ ردی نداشت.
	if ( is_wp_error( $resp ) ) {
		farazsms_send_diag_log( $mobile, 'simple', 'curl_error:' . $resp->get_error_message(), array(
			'source'    => 'fwss-scheduled',
			'http_code' => 0,
		) );
		return;
	}
	$http_code = (int) wp_remote_retrieve_response_code( $resp );
	$decoded   = json_decode( (string) wp_remote_retrieve_body( $resp ), true );
	$success   = ( ( $http_code >= 200 && $http_code < 300 )
		&& is_array( $decoded ) && isset( $decoded['status'] ) && $decoded['status'] === 'success' );
	$diag = $success ? 'success' : ( 'HTTP ' . $http_code );
	farazsms_send_diag_log( $mobile, 'simple', $diag, array( 'source' => 'fwss-scheduled', 'http_code' => $http_code ) );
}


// تابعِ ارسالِ تیکتِ ماژولِ زمان‌بندی حذف شد (v3.22.160): تنها صداکننده‌اش یک
// هندلرِ یتیم بود که فرمی نداشت؛ هر دو با هم برداشته شدند.
