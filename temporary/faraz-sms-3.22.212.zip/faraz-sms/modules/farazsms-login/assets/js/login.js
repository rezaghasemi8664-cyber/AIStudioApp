jQuery(document).ready(function($) {

    // v3.21.24 — درجِ امنِ پیام/خطا: متن را به‌صورتِ text (نه HTMLِ خام) درج می‌کند تا
    // اگر روزی پیامِ سرور شاملِ ورودیِ کاربر شد، XSS رخ ندهد.
    function farazsmsShowMsg($scope, msg) {
        var $s = ($scope && $scope.length) ? $scope : $('.farazsms-main-login-form');
        $s.prepend($('<div class="farazsms-error-text"></div>').text(msg == null ? '' : String(msg)));
    }

    // تبدیل ارقام فارسی (۰-۹) و عربی-هندی (٠-٩) به ارقام لاتین.
    // کاربر نباید مجبور باشد چیدمان صفحه‌کلید را عوض کند.
    function normalizeDigits(str) {
        if (str == null) return str;
        return String(str)
            .replace(/[۰-۹]/g, function (c) {
                return String.fromCharCode(c.charCodeAt(0) - 0x06F0 + 48);
            })
            .replace(/[٠-٩]/g, function (c) {
                return String.fromCharCode(c.charCodeAt(0) - 0x0660 + 48);
            });
    }

    function replaceDefaultForms() {
        if (!farazsms_ajax.replace_default_forms || !farazsms_ajax.replacement_form_html) {
            return false;
        }

        var replacementHtml = farazsms_ajax.replacement_form_html;
        var didReplace = false;

        $('.woocommerce-account .u-columns').each(function() {
            var $container = $(this);
            if ($container.find('.farazsms-inline-login-wrapper').length) {
                return;
            }

            if ($container.find('.woocommerce-form-login, .woocommerce-form-register').length) {
                $container.replaceWith(replacementHtml);
                didReplace = true;
            }
        });

        $('form').each(function() {
            var $form = $(this);

            if ($form.closest('.farazsms-main-login-form').length || $form.closest('.farazsms-inline-login-wrapper').length) {
                return;
            }

            if (
                $form.is('#loginform') ||
                $form.is('[name="loginform"]') ||
                ($form.attr('action') && $form.attr('action').indexOf('wp-login.php') !== -1) ||
                $form.hasClass('login') ||
                $form.hasClass('woocommerce-form-login') ||
                $form.hasClass('woocommerce-form-register')
            ) {
                $form.replaceWith(replacementHtml);
                didReplace = true;
            }
        });

        return didReplace;
    }

    replaceDefaultForms();

    // تم‌هایی مثل «وودمارت» فرمِ ورود را در پنلِ کشویی (off-canvas) دیرتر یا با AJAX
    // به صفحه اضافه می‌کنند؛ پس اجرای یک‌باره روی ready آن را از دست می‌دهد. با
    // MutationObserver هر فرمِ پیش‌فرضی که بعداً ساخته شود را هم جایگزین می‌کنیم.
    if (farazsms_ajax.replace_default_forms && farazsms_ajax.replacement_form_html && window.MutationObserver) {
        var farazReplaceTimer = null;
        var farazObserver = new MutationObserver(function(mutations) {
            var added = false;
            for (var i = 0; i < mutations.length; i++) {
                if (mutations[i].addedNodes && mutations[i].addedNodes.length) { added = true; break; }
            }
            if (!added) { return; }
            clearTimeout(farazReplaceTimer);
            farazReplaceTimer = setTimeout(replaceDefaultForms, 150);
        });
        farazObserver.observe(document.body, { childList: true, subtree: true });
    }

    $(document).on('submit', '.farazsms-main-login-form form[id="submit-identifier"]', function(e) {
        e.preventDefault();
        // ⚠️ محدود به همان فرمی که ارسال شد.
        //
        // شناسه‌های قالبِ ورود ثابت‌اند (identifier، verification_code،
        // submit-login، farazsms-timer). به‌محضِ اینکه فرم دوبار روی صفحه رندر
        // شود — پاپ‌آپِ هدر کنارِ فرمِ درون‌خطی، یا مودالِ لیدمگنت — این شناسه‌ها
        // تکراری می‌شوند و هر خواندنِ سراسری به **اولی** می‌خورد، که ممکن است
        // فرمِ دیگری باشد. روی سایتِ واقعی تکراری‌شدنِ submit-login و
        // verification_code تأیید شد.
        var $thisForm = $(this);
        var $wrap     = $thisForm.closest('.farazsms-main-login-form');
        var identifierField = $thisForm.find('#identifier, [name="identifier"]').first();
        if (!identifierField.val()) {
            $thisForm.addClass('has-error');
        } else {
            var formData = $(this).serialize();
            $.ajax({
                type: 'POST',
                url: farazsms_ajax.ajax_url,
                data: {
                    'action': 'farazsms_identifier_ajax_handler',
                    'nonce': farazsms_ajax.nonce,
                    'data': formData,
                }, beforeSend: function() {
                    $wrap.find('.farazsms-submit').hide();
                    $wrap.find('.farazsms-submit').after("<div class='btn-loading'><div><div></div><div></div><div></div><div></div></div></div>");
                }, success: function(response) {
                    $wrap.find('.btn-loading').remove();
                    $wrap.find('.farazsms-submit').show();
                    if (response && typeof response === 'object') {
                        var dm = (response.data && (response.data.message || typeof response.data === 'string')) ? (response.data.message || response.data) : 'خطای نامشخص.';
                        farazsmsShowMsg($wrap, dm);
                    } else {
                        $wrap.html(response);
                    }
                }, error: function(xhr) {
                    $wrap.find('.btn-loading').remove();
                    $wrap.find('.farazsms-submit').show();
                    var m = (xhr && xhr.responseJSON && xhr.responseJSON.data) ? xhr.responseJSON.data : ((xhr && xhr.status) ? ('خطا در ارتباط با سرور (کد ' + xhr.status + ')') : 'خطا در ارسال درخواست. دوباره تلاش کنید.');
                    farazsmsShowMsg($wrap, m);
                }
            });
        }
    });

    // v3.21.23 — رفعِ «کلیک روی دکمه‌ی ارسالِ کد در checkout هیچ واکنشی ندارد».
    // علت: روی صفحه‌ی تسویه‌حسابِ بعضی قالب‌ها، فرمِ ما (#submit-identifier) داخلِ فرمِ اصلیِ
    // checkout قرار می‌گیرد و چون HTML فرمِ تو‌در‌تو را مجاز نمی‌داند، مرورگر تگِ <form>ِ داخلی
    // را drop می‌کند؛ پس رویدادِ submit هرگز شلیک نمی‌شود (نه XHR، نه رفرش). اینجا کلیکِ دکمه را
    // مستقیم می‌گیریم و اگر فرم drop شده باشد، فیلدها را از داخلِ wrapper خوانده و درخواست را
    // دستی می‌فرستیم. اگر فرم سالم باشد، دخالت نمی‌کنیم تا هندلرِ submit کارِ خودش را بکند.
    $(document).on('click', '.farazsms-main-login-form .farazsms-submit[name="submit_login"]', function(e) {
        var $btn = $(this);
        if ($btn.closest('form#submit-identifier').length) {
            return; // فرم سالم است؛ هندلرِ submit اجرا می‌شود.
        }
        e.preventDefault();
        var $wrap = $btn.closest('.farazsms-main-login-form');
        var $idf  = $wrap.find('#identifier, [name="identifier"]').first();
        var identifier = $idf.val();
        if (!identifier) {
            $idf.addClass('has-error');
            return;
        }
        var back     = $wrap.find('[name="back_url"]').first().val() || '';
        var fz_nonce = $wrap.find('[name="farazsms_nonce"]').first().val() || '';
        // v3.22.68: توکنِ ضدِ ربات + هانی‌پات را هم ضمیمه کن (این مسیر serialize نمی‌کند)،
        // وگرنه گاردِ سمتِ سرور ورودِ واقعی روی صفحه‌ی چک‌اوت را رد می‌کند.
        var fz_tok = $wrap.find('[name="farazsms_tok"]').first().val() || '';
        var fz_hp  = $wrap.find('[name="farazsms_hp"]').first().val() || '';
        var formData = 'identifier=' + encodeURIComponent(identifier) +
                       '&back_url=' + encodeURIComponent(back) +
                       '&farazsms_nonce=' + encodeURIComponent(fz_nonce) +
                       '&farazsms_tok=' + encodeURIComponent(fz_tok) +
                       '&farazsms_hp=' + encodeURIComponent(fz_hp);
        $.ajax({
            type: 'POST',
            url: farazsms_ajax.ajax_url,
            data: { 'action': 'farazsms_identifier_ajax_handler', 'nonce': farazsms_ajax.nonce, 'data': formData },
            beforeSend: function() {
                $wrap.find('.farazsms-submit').hide();
                $wrap.find('.farazsms-submit').after("<div class='btn-loading'><div><div></div><div></div><div></div><div></div></div></div>");
            },
            success: function(response) {
                $wrap.find('.btn-loading').remove();
                $wrap.find('.farazsms-submit').show();
                if (response && typeof response === 'object') {
                    var dm = (response.data && (response.data.message || typeof response.data === 'string')) ? (response.data.message || response.data) : 'خطای نامشخص.';
                    farazsmsShowMsg($wrap, dm);
                } else {
                    $wrap.html(response);
                }
            },
            error: function(xhr) {
                $wrap.find('.btn-loading').remove();
                $wrap.find('.farazsms-submit').show();
                var m = (xhr && xhr.responseJSON && xhr.responseJSON.data) ? xhr.responseJSON.data : ((xhr && xhr.status) ? ('خطا در ارتباط با سرور (کد ' + xhr.status + ')') : 'خطا در ارسال درخواست. دوباره تلاش کنید.');
                farazsmsShowMsg($wrap, m);
            }
        });
    });

    $(document).on('submit', '.farazsms-main-login-form form[id="submit-login"]', function(e) {
        e.preventDefault();
        // ⚠️ ظرفِ **همین** فرم. با سلکتورِ سراسری، پاسخ در همه‌ی فرم‌های صفحه
        // ریخته می‌شد و روی صفحه‌ای که دو فرم دارد (لیدمگنت + فرمِ اصلی)
        // همان شناسه‌های تکراری را دوباره می‌ساخت که این ماژول رفعشان کرد.
        var $wrap = $(this).closest('.farazsms-main-login-form');
        var formData = $(this).serialize();
        $.ajax({
            type: 'POST',
            url: farazsms_ajax.ajax_url,
            data: {
                'action': 'farazsms_login_ajax_handler',
                'nonce': farazsms_ajax.nonce,
                'data': formData,
            }, beforeSend: function() {
                $wrap.find('.farazsms-submit').hide();
                $wrap.find('.farazsms-submit').after("<div class='btn-loading'><div><div></div><div></div><div></div><div></div></div></div>");
            }, success: function(response) {
                $wrap.html(response);
            }, error: function(xhr) { $wrap.find('.btn-loading').remove(); $wrap.find('.farazsms-submit').show(); var m = (xhr && xhr.responseJSON && xhr.responseJSON.data) ? xhr.responseJSON.data : ((xhr && xhr.status) ? ('خطا در ارتباط با سرور (کد ' + xhr.status + ')') : 'خطا در ارسال درخواست.'); farazsmsShowMsg($wrap, m);
            }
        });
    });

    $(document).on('submit', '.farazsms-main-login-form form[id="submit-register"]', function(e) {
        e.preventDefault();
        // ⚠️ ظرفِ **همین** فرم. با سلکتورِ سراسری، پاسخ در همه‌ی فرم‌های صفحه
        // ریخته می‌شد و روی صفحه‌ای که دو فرم دارد (لیدمگنت + فرمِ اصلی)
        // همان شناسه‌های تکراری را دوباره می‌ساخت که این ماژول رفعشان کرد.
        var $wrap = $(this).closest('.farazsms-main-login-form');
        var formData = $(this).serialize();
        $.ajax({
            type: 'POST',
            url: farazsms_ajax.ajax_url,
            data: {
                'action': 'farazsms_register_ajax_handler',
                'nonce': farazsms_ajax.nonce,
                'data': formData,
            }, beforeSend: function() {
                $wrap.find('.farazsms-submit').hide();
                $wrap.find('.farazsms-submit').after("<div class='btn-loading'><div><div></div><div></div><div></div><div></div></div></div>");
            }, success: function(response) {
                $wrap.html(response);
            }, error: function(xhr) { $wrap.find('.btn-loading').remove(); $wrap.find('.farazsms-submit').show(); var m = (xhr && xhr.responseJSON && xhr.responseJSON.data) ? xhr.responseJSON.data : ((xhr && xhr.status) ? ('خطا در ارتباط با سرور (کد ' + xhr.status + ')') : 'خطا در ارسال درخواست.'); farazsmsShowMsg($wrap, m);
            }
        });
    });

    $(document).on('click', '.farazsms-main-login-form #login-with-password', function(e) {
        e.preventDefault();
        // ⚠️ ظرفِ همین لینک — و فیلدها از داخلِ همان ظرف. با خواندنِ سراسری،
        // کاربرِ فرمِ دوم شناسه‌ی فرمِ اول را می‌فرستاد (کد به شماره‌ی اشتباه).
        var $wrap = $(this).closest('.farazsms-main-login-form');
        var identifier = $wrap.find('input[name="identifier"]').val(),
            identifier_type = $wrap.find('input[name="identifier_type"]').val(),
            back_url = $wrap.find('input[name="back_url"]').val(),
            formData = "identifier=" + identifier + "&identifier_type=" + identifier_type + "&back_url=" + back_url;
    
        $.ajax({
            type: 'POST',
            url: farazsms_ajax.ajax_url,
            data: {
                'action': 'farazsms_login_password_ajax_handler',
                'nonce': farazsms_ajax.nonce,
                'data': formData,
            }, success: function(response) {
                $wrap.html(response);
            }, error: function(xhr) { $wrap.find('.btn-loading').remove(); $wrap.find('.farazsms-submit').show(); var m = (xhr && xhr.responseJSON && xhr.responseJSON.data) ? xhr.responseJSON.data : ((xhr && xhr.status) ? ('خطا در ارتباط با سرور (کد ' + xhr.status + ')') : 'خطا در ارسال درخواست.'); farazsmsShowMsg($wrap, m);
            }
        });
    });

    $(document).on('click', '.farazsms-main-login-form #login-with-code', function(e) {
        e.preventDefault();
        // ⚠️ ظرفِ همین لینک — و فیلدها از داخلِ همان ظرف. با خواندنِ سراسری،
        // کاربرِ فرمِ دوم شناسه‌ی فرمِ اول را می‌فرستاد (کد به شماره‌ی اشتباه).
        var $wrap = $(this).closest('.farazsms-main-login-form');
        var identifier = $wrap.find('input[name="identifier"]').val(),
            identifier_type = $wrap.find('input[name="identifier_type"]').val(),
            back_url = $wrap.find('input[name="back_url"]').val(),
            formData = "identifier=" + identifier + "&identifier_type=" + identifier_type + "&back_url=" + back_url;
    
        $.ajax({
            type: 'POST',
            url: farazsms_ajax.ajax_url,
                data: {
                    'action': 'farazsms_identifier_ajax_handler',
                    'nonce': farazsms_ajax.nonce,
                    'data': formData,
                }, success: function(response) {
                $wrap.html(response);
            }, error: function(xhr) { $wrap.find('.btn-loading').remove(); $wrap.find('.farazsms-submit').show(); var m = (xhr && xhr.responseJSON && xhr.responseJSON.data) ? xhr.responseJSON.data : ((xhr && xhr.status) ? ('خطا در ارتباط با سرور (کد ' + xhr.status + ')') : 'خطا در ارسال درخواست.'); farazsmsShowMsg($wrap, m);
            }
        });
    });

    $(document).on('click', '.farazsms-main-login-form #forget-password-mobile', function(e) {
        e.preventDefault();
        // ⚠️ ظرفِ همین لینک — و فیلدها از داخلِ همان ظرف. با خواندنِ سراسری،
        // کاربرِ فرمِ دوم شناسه‌ی فرمِ اول را می‌فرستاد (کد به شماره‌ی اشتباه).
        var $wrap = $(this).closest('.farazsms-main-login-form');
        var identifier = $wrap.find('input[name="identifier"]').val(),
            identifier_type = $wrap.find('input[name="identifier_type"]').val(),
            back_url = $wrap.find('input[name="back_url"]').val(),
            formData = "identifier=" + identifier + "&identifier_type=" + identifier_type + "&back_url=" + back_url;
    
        $.ajax({
            type: 'POST',
            url: farazsms_ajax.ajax_url,
            data: {
                'action': 'farazsms_forget_mobile_password_ajax_handler',
                'nonce': farazsms_ajax.nonce,
                'data': formData,
            }, success: function(response) {
                $wrap.html(response);
            }, error: function(xhr) { $wrap.find('.btn-loading').remove(); $wrap.find('.farazsms-submit').show(); var m = (xhr && xhr.responseJSON && xhr.responseJSON.data) ? xhr.responseJSON.data : ((xhr && xhr.status) ? ('خطا در ارتباط با سرور (کد ' + xhr.status + ')') : 'خطا در ارسال درخواست.'); farazsmsShowMsg($wrap, m);
            }
        });
    });

    $(document).on('submit', '.farazsms-main-login-form form[id="submit-forget-code"]', function(e) {
        e.preventDefault();
        // ⚠️ ظرفِ **همین** فرم. با سلکتورِ سراسری، پاسخ در همه‌ی فرم‌های صفحه
        // ریخته می‌شد و روی صفحه‌ای که دو فرم دارد (لیدمگنت + فرمِ اصلی)
        // همان شناسه‌های تکراری را دوباره می‌ساخت که این ماژول رفعشان کرد.
        var $wrap = $(this).closest('.farazsms-main-login-form');
        var formData = $(this).serialize();
        $.ajax({
            type: 'POST',
            url: farazsms_ajax.ajax_url,
            data: {
                'action': 'farazsms_forget_code_ajax_handler',
                'nonce': farazsms_ajax.nonce,
                'data': formData,
            }, beforeSend: function() {
                $wrap.find('.farazsms-submit').hide();
                $wrap.find('.farazsms-submit').after("<div class='btn-loading'><div><div></div><div></div><div></div><div></div></div></div>");
            }, success: function(response) {
                $wrap.html(response);
            }, error: function(xhr) { $wrap.find('.btn-loading').remove(); $wrap.find('.farazsms-submit').show(); var m = (xhr && xhr.responseJSON && xhr.responseJSON.data) ? xhr.responseJSON.data : ((xhr && xhr.status) ? ('خطا در ارتباط با سرور (کد ' + xhr.status + ')') : 'خطا در ارسال درخواست.'); farazsmsShowMsg($wrap, m);
            }
        });
    });

    $(document).on('submit', '.farazsms-main-login-form form[id="submit-reset-password"]', function(e) {
        e.preventDefault();
        // ⚠️ ظرفِ **همین** فرم. با سلکتورِ سراسری، پاسخ در همه‌ی فرم‌های صفحه
        // ریخته می‌شد و روی صفحه‌ای که دو فرم دارد (لیدمگنت + فرمِ اصلی)
        // همان شناسه‌های تکراری را دوباره می‌ساخت که این ماژول رفعشان کرد.
        var $wrap = $(this).closest('.farazsms-main-login-form');
        var formData = $(this).serialize();
        $.ajax({
            type: 'POST',
            url: farazsms_ajax.ajax_url,
            data: {
                'action': 'farazsms_reset_password_ajax_handler',
                'nonce': farazsms_ajax.nonce,
                'data': formData,
            }, beforeSend: function() {
                $wrap.find('.farazsms-submit').hide();
                $wrap.find('.farazsms-submit').after("<div class='btn-loading'><div><div></div><div></div><div></div><div></div></div></div>");
            }, success: function(response) {
                $wrap.html(response);
            }, error: function(xhr) { $wrap.find('.btn-loading').remove(); $wrap.find('.farazsms-submit').show(); var m = (xhr && xhr.responseJSON && xhr.responseJSON.data) ? xhr.responseJSON.data : ((xhr && xhr.status) ? ('خطا در ارتباط با سرور (کد ' + xhr.status + ')') : 'خطا در ارسال درخواست.'); farazsmsShowMsg($wrap, m);
            }
        });
    });

    
    function initializeTimer() {
        // شمارنده‌ی **هر** فرمِ روی صفحه راه بیفتد، نه فقط اولی. با دو فرم،
        // نسخه‌ی قبلی همیشه شمارنده‌ی فرمِ اول را می‌گرفت و شمارنده‌ی فرمی که
        // کاربر واقعاً می‌دید هرگز نمی‌چرخید — یعنی لینکِ «ارسال دوباره» ظاهر
        // نمی‌شد.
        $('#farazsms-timer, .farazsms-timer').each(function () {
          startOneTimer(this);
        });
    }

    function startOneTimer(timerElement) {
        if (!timerElement || timerElement.getAttribute('data-fz-timer-running') === '1') {
          return;
        }
        timerElement.setAttribute('data-fz-timer-running', '1');
        var time = { minutes: parseInt(timerElement.getAttribute('data-time'), 10), seconds: 0 };
      
        var timerInterval = setInterval(function () {
          timerElement.textContent = formatTime(time);
      
          if (time.minutes === 0 && time.seconds === 0) {
            timerElement.innerHTML = "<a href='#' id='login-with-code' class='farazsms-change-link'>" + farazsms_ajax.resend_code_text + "</a>";
            $(timerElement).closest('form, .farazsms-main-login-form').find('.farazsms-timer-text').hide();
            clearInterval(timerInterval);
          } else {
            if (time.seconds > 0) {
              time.seconds--;
            } else {
              time.minutes--;
              time.seconds = 59;
            }
          }
        }, 1000);
    }
      
    function formatTime(time) {
        var formattedMinutes = time.minutes < 10 ? "0" + time.minutes : time.minutes;
        var formattedSeconds = time.seconds < 10 ? "0" + time.seconds : time.seconds;
        return formattedMinutes + ":" + formattedSeconds;
    }
      
    initializeTimer();
    $(document).ajaxComplete(function () {
        initializeTimer();
        replaceDefaultForms();
    });


    $(document).on('input', '.otp-digit', function() {
        var $this = $(this);
        // ارقام فارسی/عربی تایپ‌شده را بلافاصله به لاتین تبدیل کن.
        var normalized = normalizeDigits($this.val());
        if (normalized !== $this.val()) {
            $this.val(normalized);
        }
        var val = $this.val();

        // اگر autofillِ گوشی (آیفون) کلِ کد را داخلِ یک خانه ریخت، بینِ خانه‌ها پخش کن.
        if (val.length > 1) {
            fillOtp(val, $this);
            return;
        }

        if (val.length === 1) {
            var nextIndex = parseInt($this.data('index')) + 1;
            // ⚠️ v3.22.201: محدود به فرمِ همان خانه.
            //
            // v3.22.51 همین اشکال را در fillOtp و updateVerificationCode رفع کرد ولی
            // این سه نقطه جا ماندند. با بیش از یک فرمِ ورود روی صفحه — که پاپ‌آپِ
            // لید مگنت دقیقاً همین را می‌سازد — سلکتورِ سراسری به هر دو نسخه می‌خورد
            // و فوکوس روی نسخه‌ی نامرئی می‌نشیند. علامتش برای فروشنده این بود که
            // باید روی تک‌تکِ خانه‌ها کلیک کند.
            var $nextInput = otpSiblings($this).filter('[data-index="' + nextIndex + '"]');
            
            if ($nextInput.length) {
                $nextInput.focus();
            } else {
                $this.blur();
            }

            updateVerificationCode($this);
        }
    });
    
    $(document).on('keydown', '.otp-digit', function(e) {
        var $this = $(this);
        var key = e.key;
        
        if (key === 'Backspace' && $this.val() === '') {
            var prevIndex = parseInt($this.data('index')) - 1;
            var $prevInput = otpSiblings($this).filter('[data-index="' + prevIndex + '"]');
            
            if ($prevInput.length) {
                $prevInput.focus();
            }
        }
        
        // کلیدِ عددی فارسی/عربی را هم مجاز بشمار (بعد از نرمال‌سازی به لاتین).
        if (!/^\d$/.test(normalizeDigits(key)) &&
            key !== 'Backspace' &&
            key !== 'Delete' &&
            key !== 'ArrowLeft' &&
            key !== 'ArrowRight' &&
            key !== 'Tab') {
            e.preventDefault();
        }

        updateVerificationCode($this);
    });
    
    $(document).on('paste', '.otp-digit', function(e) {
        // دسترسی به کلیپ‌بورد سازگار با همه مرورگرها (Safariِ مک‌بوک نیز).
        var clip = (e.originalEvent || e).clipboardData || window.clipboardData;
        if (!clip) { return; }
        var raw = clip.getData('text') || clip.getData('text/plain') || '';
        // فقط ارقام را استخراج کن — حتی اگر کاربر کلِ متنِ پیامک («کد شما ۱۲۳۴۵۶ است») را
        // از iMessage کپی کند یا فاصله/نیم‌فاصله داشته باشد. ارقام فارسی/عربی → لاتین.
        var digits = normalizeDigits(raw).replace(/\D/g, '');
        if (!digits) { return; }
        e.preventDefault();
        fillOtp(digits, $(this));
    });

    // فوکوسِ اولیه روی خانه‌های **دیده‌شده**. با فرمِ دومِ مخفی روی صفحه (پاپ‌آپِ
    // لید مگنت)، «اولین .otp-digit صفحه» می‌توانست همان مخفی باشد.
    $('.otp-digit').filter(':visible').first().focus();

    /**
     * خانه‌های کدِ **همان فرم**.
     *
     * تنها نقطه‌ی تصمیم برای «کدام خانه‌ها به هم مربوط‌اند». اگر فرمی نبود
     * (مارکاپِ بدونِ form)، به کلِ صفحه برمی‌گردد — همان رفتارِ قبلی.
     */
    function otpSiblings($ctx) {
        var $form = ($ctx && $ctx.length) ? $($ctx).closest('form') : $();
        return $form.length ? $form.find('.otp-digit') : $('.otp-digit');
    }

    // پخشِ ارقامِ کد بینِ خانه‌ها — مشترکِ paste، autofillِ آیفون و WebOTPِ اندروید.
    function fillOtp(raw, $ctx) {
        var digits = normalizeDigits(String(raw)).replace(/\D/g, '');
        if (!digits) { return; }
        // v3.22.51: به خانه‌های OTPِ همان فرم محدود کن (نه همه‌ی صفحه) تا کد در پاپ‌آپِ لید مگنت
        // در فرمِ درست ریخته و همان فرم submit شود.
        var $inputs = otpSiblings($ctx);
        if (!$inputs.length) { return; }
        digits = digits.slice(0, $inputs.length); // فقط به تعدادِ خانه‌ها
        $inputs.each(function (index) {
            $(this).val(digits[index] || '');
        });
        updateVerificationCode($inputs.first());
        // فوکوس روی اولین خانه‌ی خالی (اگر کد ناقص بود) وگرنه آخرین خانه.
        var $firstEmpty = $inputs.filter(function () { return !$(this).val(); }).first();
        ($firstEmpty.length ? $firstEmpty : $inputs.last()).focus();
    }

    // دریافتِ خودکارِ کد از پیامک در اندروید/کروم (WebOTP API).
    // پیش‌نیاز: HTTPS و اینکه پیامک با خطِ «@دامنه #کد» تمام شود.
    var webOtpController = null;
    function startWebOTP() {
        if (!('OTPCredential' in window)) { return; }
        if (!$('.otp-digit').length) { return; }
        if (webOtpController) { return; } // در حالِ گوش‌دادن است.
        webOtpController = new AbortController();
        navigator.credentials.get({
            otp: { transport: ['sms'] },
            signal: webOtpController.signal
        }).then(function (otp) {
            webOtpController = null;
            if (otp && otp.code) { fillOtp(otp.code); }
        }).catch(function () {
            webOtpController = null; // کاربر رد کرد یا تایم‌اوت — بی‌اهمیت.
        });
    }
    startWebOTP();
    $(document).ajaxComplete(function () { startWebOTP(); });

    function updateVerificationCode($ctx) {
        var code = '';
        var allFilled = true;

        // v3.22.51: مبنا را «فرمِ فیلدی که کاربر در آن تایپ/paste می‌کند» بگیر — نه اولین فرمِ صفحه.
        // با بیش از یک فرمِ لاگین روی صفحه (پاپ‌آپِ لید مگنت + فرمِ هدر/جایگزین)، خواندنِ سراسریِ
        // «اولین .otp-digit» کدِ فرمِ اشتباه را می‌خواند و auto-submitِ فرمِ خالی می‌کرد → «کد
        // تأیید نمی‌شود» درحالی‌که پیامک آمده بود.
        var $form = ( $ctx && $ctx.length ) ? $( $ctx ).closest('form') : $('.otp-digit').first().closest('form');
        if (!$form.length) { $form = $('.farazsms-main-login-form form').first(); }
        var $scoped = $form.length ? $form.find('.otp-digit') : $('.otp-digit');

        $scoped.each(function() {
            var digit = normalizeDigits($(this).val());
            code += digit;
            if (digit === '') {
                allFilled = false;
            }
        });

        $form.find('#verification_code').val(normalizeDigits(code));

        // Auto-submit فقط وقتی همه‌ی خانه‌های OTP و همه‌ی فیلدهای الزامیِ همان فرم (مثلِ «نام»
        // در ثبت‌نام) پر باشند — وگرنه auto-submit کدِ ناقص/فرمِ ناقص می‌فرستد.
        if (allFilled && $scoped.length && code.length === $scoped.length) {
            var requiredMissing = false;
            $form.find('[required]').not('.otp-digit').each(function() {
                if (!$(this).val()) { requiredMissing = true; }
            });
            if (!requiredMissing && $form.length > 0) {
                $form.trigger('submit');
            }
        }
    }
});
