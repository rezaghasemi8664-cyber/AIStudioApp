<?php
// v3.22.69: گاردِ class_exists برای جلوگیری از redeclareِ fatal در صورتِ هم‌زیستی با استندالون.

$admin = FarazSMS_PATH . "admin/";
if ( ! class_exists( 'FarazSMS\\Admin\\Admin_Helper' ) )   require_once $admin . "class-admin-helper.php";
if ( ! class_exists( 'FarazSMS\\Admin\\FlashMessage' ) )   require_once $admin . "flash-message.php";
if ( ! class_exists( 'FarazSMS\\Admin\\Settings' ) )       require_once $admin . "class-main-settings.php";
if ( ! class_exists( 'FarazSMS\\Admin\\Admin_Settings' ) ) require_once $admin . "class-admin.php";
