<?php
// v3.22.69: هر require با class_exists گارد شد. اگر نسخه‌ی استندالونِ farazsms-login هم‌زمان
// حاضر باشد و همین کلاس‌ها را (با namespaceِ FarazSMS) تعریف کرده باشد، require_once که با
// «مسیرِ مطلق» dedup می‌کند نمی‌تواند جلوی بارگذاریِ دوباره را بگیرد (مسیرها فرق دارند) →
// «Cannot redeclare class» و سفیدیِ سایت. این گاردها آن fatal را غیرممکن می‌کنند.

if ( ! class_exists( 'FarazSMS\\Wallet' ) )       require_once FarazSMS_INC . 'class-wallet.php';
if ( ! class_exists( 'FarazSMS\\Helper' ) )       require_once FarazSMS_INC . 'class-helper.php';
if ( ! class_exists( 'FarazSMS\\Form_Settings' ) ) require_once FarazSMS_INC . 'class-forms.php';
if ( ! class_exists( 'FarazSMS\\Send_SMS' ) )     require_once FarazSMS_INC . 'class-send-sms.php';
if ( ! class_exists( 'FarazSMS\\OTP' ) )          require_once FarazSMS_INC . 'class-otp.php';
if ( ! class_exists( 'FarazSMS\\Main_Settings' ) ) require_once FarazSMS_INC . 'class-main.php';

// در حالت bundled داخل افزونه‌ی «فراز اس ام اس»، پیامک سفارشات ووکامرس بارگذاری نمی‌شود؛
// این کار از طریق افزونه‌ی ثالثِ «پیامک حرفه‌ای ووکامرس» (PWSMS) انجام می‌شود.
if ( ! defined( 'FARAZSMS_LOGIN_BUNDLED' ) ) {
	if ( ! class_exists( 'FarazSMS\\WooCommerce_SMS' ) ) require_once FarazSMS_INC . 'class-woocommerce-sms.php';
}
