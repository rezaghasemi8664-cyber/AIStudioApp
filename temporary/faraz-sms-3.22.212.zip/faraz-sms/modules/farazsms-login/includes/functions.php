<?php

// Global helper function for getting settings
if (!function_exists('Farazsms_Get_Setting')) {
	function Farazsms_Get_Setting($section, $id) {
		$theme_options = get_option('farazsms_login_settings', [] );
		$section_data = isset($theme_options[$section]) ? $theme_options[$section] : [];
		$value = isset($section_data[$id]) ? $section_data[$id] : '';
		return $value;
	}
}

if ( ! function_exists( 'farazsms_login_mask_mobile' ) ) {
	/**
	 * ماسکِ شماره موبایل برای نمایشِ عمومی: ۳ رقمِ اول + ۳ رقمِ آخر نگه داشته می‌شود، بقیه *.
	 * برای وقتی فیلدِ نام خاموش است و نمی‌خواهیم شماره‌ی کاملِ کاربر به‌عنوانِ نامِ نمایشی لو برود.
	 *
	 * مثال: 09123456789 → 091*****789
	 *
	 * @param string $mobile شماره (با یا بدونِ کاراکترِ غیرعددی).
	 * @return string شماره‌ی ماسک‌شده (فقط ASCII: رقم + *)؛ خالی اگر ورودی رقمی نداشت.
	 */
	function farazsms_login_mask_mobile( $mobile ) {
		$digits = preg_replace( '/\D+/', '', (string) $mobile );
		$len    = strlen( (string) $digits );
		if ( $len === 0 ) {
			return '';
		}
		if ( $len <= 6 ) {
			// نگه‌داشتنِ ۳ رقمِ اول + ۳ رقمِ آخر کلِ عدد را پوشش می‌دهد؛ چیزی برای ماسک نمی‌ماند.
			return $digits;
		}
		return substr( $digits, 0, 3 ) . str_repeat( '*', $len - 6 ) . substr( $digits, -3 );
	}
}

/**
 * طولِ کدِ تأیید — تکِ‌منبعِ حقیقت.
 *
 * v3.21.72 رفعِ باگ: قبلاً تولیدِ کد (class-send-sms::code) به ۶ کلمپ می‌شد ولی قالب‌ها
 * تعدادِ کادر را از مقدارِ خام می‌خواندند → ناهماهنگی (مثلاً ۴ کادر، کدِ ۶رقمی) که ورود
 * را می‌شکست. حالا هم تولیدِ کد و هم رندرِ کادرها از همین تابع می‌خوانند تا همیشه یکی باشند.
 * کف ۴ و سقف ۱۰ (انتخابِ ۴رقمیِ مدیر محترم است؛ دفاعِ brute-force با throttle/تک‌مصرف/انقضا
 * در class-otp تأمین می‌شود، نه با اجبارِ طول).
 */
if (!function_exists('Farazsms_Login_Otp_Length')) {
	function Farazsms_Login_Otp_Length() {
		$n = (int) Farazsms_Get_Setting('sms', 'code_length');
		if ($n < 4 || $n > 10) {
			$n = 6;
		}
		return $n;
	}
}

// آیا فیلد «نام» در فرم ثبت‌نام نمایش داده و اجباری شود؟
// منبع حقیقت: option ای که افزونه «فراز اس ام اس» (bridge) ست می‌کند.
//   farazsms_login_ask_name = 'yes' → نام نمایش داده و اجباری است (پیش‌فرض)
//   farazsms_login_ask_name = 'no'  → فیلد نام به‌کلی حذف می‌شود
// اگر افزونه فراز نصب نباشد، مقدار پیش‌فرض 'yes' رفتار قبلی را حفظ می‌کند.
if (!function_exists('Farazsms_Login_Ask_Name')) {
	function Farazsms_Login_Ask_Name() {
		return get_option('farazsms_login_ask_name', 'yes') !== 'no';
	}
}
