<?php

namespace FarazSMS;


class Send_SMS {

    /**
     * v3.22.36 (F2): طبقه‌بندیِ آخرین ارسال ('success' | 'curl_error:…' | 'api_error:…' | 'HTTP …').
     * فراخواننده می‌تواند «خطای قطعی» (کلید/پترنِ غلط) را از «مبهم/timeout» تفکیک کند
     * بدونِ اینکه قراردادِ boolِ send() تغییر کند.
     */
    public $last_send_result = '';

    public function code() {
        // v3.21.25 امنیتی (M1): به‌جای rand() (غیرِ امن/قابلِ‌پیش‌بینی) از wp_rand (CSPRNG وقتی در دسترس است).
        // v3.21.72: تکِ‌منبعِ طول (همان منبعی که قالبِ کادرها هم می‌خواند) تا پیامک و فرم
        // هرگز ناهماهنگ نشوند. کف ۴ (احترام به انتخابِ مدیر)؛ دفاعِ brute-force در class-otp
        // (throttle/تک‌مصرف/انقضا) است، نه اجبارِ طول.
        $length = function_exists('Farazsms_Login_Otp_Length')
            ? Farazsms_Login_Otp_Length()
            : max(4, min(10, (int) Farazsms_Get_Setting('sms', 'code_length') ?: 6));
        $min = (int) str_pad('1', $length, '0'); // 100000 برای ۶
        $max = (int) str_pad('9', $length, '9'); // 999999 برای ۶
        return wp_rand($min, $max);
    }

    public function send($number, $code) {

        $opt = [
            'apikey'        => Farazsms_Get_Setting('sms', 'api_key'),
            'pattern_code'  => Farazsms_Get_Setting('sms', 'pattern_code'),
            'sender'        => Farazsms_Get_Setting('sms', 'sender'),
        ];
    
        $data = [
            'code' => $opt['pattern_code'],
            'attributes' => [
                'code' => $code
            ],
            'recipient'     => $number,
            'line_number'   => $opt['sender'],
            'number_format' => 'english'
        ];
    
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => 'https://api.iranpayamak.com/ws/v1/sms/pattern',
            CURLOPT_RETURNTRANSFER => true,
            // v3.22.27: زیرِ اینترنتِ ملی/فیلترینگ، درخواست به فراز می‌رسد و پیامک ارسال
            // می‌شود، اما پاسخِ HTTP در بازگشت کند است. با ۱۵ ثانیه، curl_exec قبل از رسیدنِ
            // پاسخ time-out می‌کرد و false می‌داد → «ارسال ناموفق» درحالی‌که کد روی موبایلِ
            // کاربر آمده بود. سقف را بالا می‌بریم تا این ناهماهنگی رخ ندهد.
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Api-Key: ' . $opt['apikey'],
                'Content-Type: application/json'
            ],
        ]);

        $response   = curl_exec($curl);
        $http_code  = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curl_errno = curl_errno($curl);
        $curl_err   = curl_error($curl);
        curl_close($curl);

        // v3.21.25 (H2): فقط در صورتِ موفقیتِ واقعی true برگردان — وگرنه فراخواننده فرمِ «کد را
        // وارد کنید» را نشان می‌داد درحالی‌که پیامکی نرفته بود (پاسخِ خطای JSON هم truthy بود).
        $decoded = ( $response === false ) ? null : json_decode($response, true);
        $success = ( ($http_code >= 200 && $http_code < 300)
            && is_array($decoded) && isset($decoded['status']) && $decoded['status'] === 'success' );

        // v3.22.36 (F2): طبقه‌بندی همیشه محاسبه می‌شود (نه فقط داخلِ بلاکِ لاگ) تا در
        // last_send_result ذخیره و در دسترسِ فراخواننده باشد.
        if ( $success ) {
            $diag_result = 'success';
        } elseif ( $curl_errno ) {
            $diag_result = 'curl_error:' . $curl_err . ' (errno ' . $curl_errno . ')';
        } elseif ( is_array($decoded) && isset($decoded['status']) && $decoded['status'] === 'error' ) {
            $msg = isset($decoded['message']) ? $decoded['message'] : (isset($decoded['messages']) ? $decoded['messages'] : 'خطای نامشخص');
            $diag_result = 'api_error:' . ( is_string($msg) ? $msg : \wp_json_encode($msg, JSON_UNESCAPED_UNICODE) );
        } else {
            $diag_result = 'HTTP ' . $http_code . ' — ' . ( is_string($response) ? mb_substr($response, 0, 180) : 'no body' );
        }
        $this->last_send_result = $diag_result;

        // v3.22.27: ثبت در لاگِ متمرکزِ تشخیصِ ارسال (صفحه‌ی «🩺 تشخیص ارسال» در پیشخوانِ فراز)
        // تا وقتی پیامکِ ورود/OTP نمی‌رود، ریسپانسِ واقعیِ سرور (http_code + خطای curl) در
        // پنلِ مدیریت دیده و سریع دیباگ شود. قبلاً این مسیر به هیچ لاگی وصل نبود.
        if ( \function_exists('farazsms_send_diag_log') ) {
            \farazsms_send_diag_log( $number, (string) $opt['pattern_code'], $diag_result, array(
                'source'    => 'login-otp',
                'http_code' => $http_code,
                'detail'    => $curl_errno ? ( $curl_err . ' (errno ' . $curl_errno . ')' ) : ( is_string($response) ? mb_substr($response, 0, 180) : '' ),
            ) );
        }

        return $success;
    }

    public function send_pattern($number, $pattern_code, $attributes) {
        $opt = [
            'apikey'        => Farazsms_Get_Setting('sms', 'api_key'),
            'sender'        => Farazsms_Get_Setting('sms', 'sender'),
        ];
        if (empty($opt['apikey']) || empty($opt['sender']) || empty($pattern_code)) {
            return false;
        }
        if (!is_array($attributes)) {
            $attributes = [];
        }

        // v3.22.29: عبور از لایه‌ی سرویسِ واحد — پذیرشِ 201، timeoutِ درست، fallbackِ cURL و
        // ثبت در لاگِ «🩺 تشخیص ارسال» را یک‌جا دارد. قبلاً curl خام با TIMEOUT=15 بود، پاسخ را
        // اصلاً تفسیر نمی‌کرد (json_decode خام) و در هیچ لاگی ثبت نمی‌شد؛ پس شکستِ پیامکِ سفارشِ
        // ماژولِ لاگین کاملاً نامرئی بود.
        if (\function_exists('farazsms_sms_send_pattern')) {
            return ( \farazsms_sms_send_pattern($number, $pattern_code, $attributes, $opt['sender']) === 'success' );
        }

        // Fallback (اگر لایه‌ی سرویس در دسترس نبود): curl خام با timeoutِ اصلاح‌شده + لاگ.
        $data = [
            'code' => $pattern_code,
            'attributes' => $attributes,
            'recipient'     => $number,
            'line_number'   => $opt['sender'],
            'number_format' => 'english'
        ];
        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => 'https://api.iranpayamak.com/ws/v1/sms/pattern',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => json_encode($data),
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Api-Key: ' . $opt['apikey'],
                'Content-Type: application/json'
            ],
        ]);
        $response   = curl_exec($curl);
        $http_code  = (int) curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curl_errno = curl_errno($curl);
        $curl_err   = curl_error($curl);
        curl_close($curl);

        $decoded = ($response === false) ? null : json_decode($response, true);
        $success = ( ($http_code >= 200 && $http_code < 300)
            && is_array($decoded) && isset($decoded['status']) && $decoded['status'] === 'success' );

        if (\function_exists('farazsms_send_diag_log')) {
            $diag = $success ? 'success' : ($curl_errno ? ('curl_error:' . $curl_err . ' (errno ' . $curl_errno . ')') : ('HTTP ' . $http_code));
            \farazsms_send_diag_log($number, (string) $pattern_code, $diag, array(
                'source'    => 'login-wc-order',
                'http_code' => $http_code,
            ));
        }

        return $success;
    }
}