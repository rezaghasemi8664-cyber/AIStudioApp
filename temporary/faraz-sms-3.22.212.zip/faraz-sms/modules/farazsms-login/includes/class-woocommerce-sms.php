<?php
/**
 * پیامکِ وضعیتِ سفارشِ ماژولِ ورود.
 *
 * ⚠️ این فایل در بسته‌ی «فراز اس ام اس» بار **نمی‌شود**.
 * includes.php آن را پشتِ شرطِ نبودنِ FARAZSMS_LOGIN_BUNDLED می‌گذارد و پلِ
 * ماژول همان ثابت را همیشه تعریف می‌کند — یعنی در نسخه‌ی باندل، پیامکِ
 * سفارش کارِ مسیرِ بومیِ افزونه است، نه این کلاس. تنها جایی که این کد اجرا
 * می‌شود، افزونه‌ی مستقلِ farazsms-login است.
 *
 * پس هر تغییری این‌جا فقط وقتی به دستِ فروشنده می‌رسد که نسخه‌ی مستقل هم
 * به‌روز شود؛ در یادداشتِ انتشار نباید به‌عنوانِ رفعِ بسته‌ی اصلی ادعا شود.
 *
 * @package farazsms-login
 */

namespace FarazSMS;
use WC_Order;

class WooCommerce_SMS {
    public function __construct() {
        if (class_exists('WooCommerce')) {
            add_action('woocommerce_order_status_changed',[$this, 'handle_order_status_changed'],10,4);
        }
    }

    public function handle_order_status_changed($order_id, $old_status, $new_status, $order) {
        if (!$order instanceof WC_Order) {
            $order = wc_get_order($order_id);
        }

        if (!$order) {
            return;
        }

        $settings = get_option('farazsms_login_settings', []);
        $woo_sms  = $settings['woo_sms'] ?? [];

        $this->send_customer_sms($order, $new_status, $woo_sms);
        $this->send_admin_sms($order, $new_status, $woo_sms);
    }


    /**
     * تنها فهرستِ «آیا این پیامک مجاز است؟» — هر دو مسیر روی همین می‌روند.
     *
     * ⚠️ v3.22.202: پیش از این، مسیرِ صف‌گذاری کلیدِ enable را می‌سنجید و
     * کارگر نمی‌سنجید. یعنی مدیری که تیک را برمی‌داشت، هر سفارشی که در صف
     * مانده بود را باز هم می‌فرستاد — و روی هاستِ بدونِ کرون، ساعت‌ها بعد.
     * قاعده‌ی پروژه: شرطِ تصمیم یک‌جا باشد.
     *
     * @param array  $woo_sms
     * @param string $prefix 'customer_' | 'admin_'
     * @param string $status
     * @return string کدپترن، یا '' اگر ارسال مجاز نیست.
     */
    private static function eligible_pattern($woo_sms, $prefix, $status) {
        if (!is_array($woo_sms)) {
            return '';
        }
        $enable_key = $prefix . $status . '_enable';
        if (!isset($woo_sms[$enable_key]) || $woo_sms[$enable_key] !== '1') {
            return '';
        }
        $pattern_key = $prefix . $status . '_pattern';
        return isset($woo_sms[$pattern_key]) ? trim((string) $woo_sms[$pattern_key]) : '';
    }

    private function send_customer_sms(WC_Order $order, $status, $woo_sms) {
        $pattern_code = self::eligible_pattern($woo_sms, 'customer_', $status);
        if ($pattern_code === '') {
            return;
        }

        if (!$order->get_billing_phone()) {
            return;
        }

        // ⚠️ v3.22.202 — **کلِ** کار به تعویق می‌افتد، نه فقط ارسال.
        //
        // نسخه‌ی ۲۰۱ اینجا farazsms_queue_send صدا می‌زد و دو چیز را بی‌صدا عوض
        // می‌کرد: (۱) صف با کلیدِ سراسریِ افزونه می‌فرستد، در حالی که این ماژول
        // کلیدِ خودش را دارد — روی سایتی که این دو فرق دارند، پیامک از حسابِ
        // دیگری می‌رفت یا اصلاً نمی‌رفت. (۲) گاردِ «خطِ ارسالِ خالی» ماژول از
        // مسیر خارج می‌شد. حالا کارگر همان مسیرِ اصلیِ ماژول را طی می‌کند.
        //
        // ساختنِ متغیرهای پترن هم — که حلقه‌ی اقلامِ سفارش و ۲۵ گیرنده دارد —
        // به کارگر منتقل شد؛ در ۲۰۱ روی درخواستِ کاربر مانده بود.
        \farazsms_queue_task(
            'login-order',
            // ⚠️ نامِ کامل: این فایل namespace دارد، پس نامِ کوتاه سراسری نیست و
            // گاردِ is_callable صف ردش می‌کند (تستِ همین نسخه گرفتش).
            'FarazSMS\\farazsms_login_order_sms_worker',
            array( (int) $order->get_id(), (string) $status, 'customer' ),
            array( 'order_id' => (int) $order->get_id(), 'to' => 'customer' )
        );
    }

    private function send_admin_sms(WC_Order $order, $status, $woo_sms) {
        $admin_phone = isset($woo_sms['admin_phone']) ? trim($woo_sms['admin_phone']) : '';
        if ($admin_phone === '') {
            return;
        }

        $pattern_code = self::eligible_pattern($woo_sms, 'admin_', $status);
        if ($pattern_code === '') {
            return;
        }

        \farazsms_queue_task(
            'login-order',
            // ⚠️ نامِ کامل: این فایل namespace دارد، پس نامِ کوتاه سراسری نیست و
            // گاردِ is_callable صف ردش می‌کند (تستِ همین نسخه گرفتش).
            'FarazSMS\\farazsms_login_order_sms_worker',
            array( (int) $order->get_id(), (string) $status, 'admin' ),
            array( 'order_id' => (int) $order->get_id(), 'to' => 'admin' )
        );
    }

    /**
     * اجرای واقعیِ ارسال از صف — همان قواعدِ قبلی، فقط بیرون از درخواست.
     *
     * @param WC_Order $order
     * @param string   $status
     * @param string   $which customer|admin
     * @return void
     */
    public static function dispatch_deferred(WC_Order $order, $status, $which) {
        // همان منبعی که هوک از آن می‌خواند — تنظیمات ممکن است بینِ صف‌گذاری و
        // اجرا عوض شده باشد و آنچه معتبر است، حالِ لحظه‌ی ارسال است.
        $settings = get_option('farazsms_login_settings', []);
        $woo_sms  = is_array($settings) && isset($settings['woo_sms']) && is_array($settings['woo_sms'])
            ? $settings['woo_sms']
            : [];
        if (!$woo_sms) {
            return;
        }
        $prefix = ($which === 'admin') ? 'admin_' : 'customer_';
        // همان فهرستِ واحد: اگر مدیر بینِ صف‌گذاری و اجرا تیک را برداشته، نرود.
        $pattern_code = self::eligible_pattern($woo_sms, $prefix, $status);
        if ($pattern_code === '') {
            return;
        }
        $attributes_raw = isset($woo_sms[$prefix . $status . '_attributes']) ? $woo_sms[$prefix . $status . '_attributes'] : '';
        // ⚠️ وضعیت از **کارِ صف‌شده** می‌آید، نه از سفارش در لحظه‌ی تخلیه.
        // بینِ صف‌گذاری و اجرا وضعیت می‌تواند عوض شده باشد (تکمیلِ خودکار،
        // تغییرِ دستیِ مدیر)؛ آن‌وقت متنِ «سفارشِ شما در وضعیتِ %status% است»
        // چیزی می‌گفت که با پترنِ انتخاب‌شده نمی‌خواند.
        $attributes = self::build_attributes_from_text($attributes_raw, $order, $status);
        if (empty($attributes)) {
            return;
        }
        $phone = ($which === 'admin')
            ? (isset($woo_sms['admin_phone']) ? trim($woo_sms['admin_phone']) : '')
            : $order->get_billing_phone();
        if ($phone === '' || !$phone) {
            return;
        }
        $sender = new Send_SMS();
        $sender->send_pattern($phone, $pattern_code, $attributes);
    }

    private static function build_attributes_from_text($text, WC_Order $order, $status = null) {
        $attributes = [];
        $shortcode_map = self::get_shortcode_values($order, $status);

        $parts = preg_split('/[\s\r\n]+/', trim((string) $text));

        foreach ($parts as $part) {
            $key = trim($part);
            if ($key === '') {
                continue;
            }
            if (isset($shortcode_map[$key])) {
                $attributes[$key] = $shortcode_map[$key];
            }
        }

        return $attributes;
    }

    private static function get_shortcode_values(WC_Order $order, $status = null) {
        $items = $order->get_items();
        $all_items = [];
        $all_items_full = [];
        $all_items_qty = [];

        foreach ($items as $item) {
            $name = $item->get_name();
            $qty = $item->get_quantity();
            $all_items[] = $name;
            $all_items_full[] = $name;
            $all_items_qty[] = $name . ' x ' . $qty;
        }

        $order_id = $order->get_id();
        $total = $order->get_total();
        // v3.21.32: wc_price بینِ عدد و واحد &nbsp; می‌گذارد و wp_strip_all_tags فقط تگ را
        // حذف می‌کند؛ helperِ مشترک &nbsp; را هم decode می‌کند.
        if ( function_exists('farazsms_price_plain') ) {
            $price = farazsms_price_plain($total);
        } else {
            $price = function_exists('wc_price') ? wp_strip_all_tags(wc_price($total)) : (string) $total;
        }

        $date_created = $order->get_date_created();
        $date = $date_created ? $date_created->date_i18n(get_option('date_format')) : '';

        $map = [
            'mobile' => $order->get_billing_phone(),
            'email' => $order->get_billing_email(),
            'status' => ( is_string($status) && $status !== '' ) ? $status : $order->get_status(),
            'all_items' => implode(', ', $all_items),
            'all_items_full' => implode(', ', $all_items_full),
            'all_items_qty' => implode(' | ', $all_items_qty),
            'count_items' => (string) $order->get_item_count(),
            'price' => $price,
            'order_id' => (string) $order_id,
            'transaction_id' => (string) $order->get_transaction_id(),
            'date' => $date,
            'description' => (string) $order->get_customer_note(),
            'payment_method' => (string) $order->get_payment_method_title(),
            'shipping_method' => (string) $order->get_shipping_method(),
            'b_first_name' => $order->get_billing_first_name(),
            'b_last_name' => $order->get_billing_last_name(),
            'b_company' => $order->get_billing_company(),
            'b_country' => $order->get_billing_country(),
            'b_state' => $order->get_billing_state(),
            'b_city' => $order->get_billing_city(),
            'b_address_1' => $order->get_billing_address_1(),
            'b_address_2' => $order->get_billing_address_2(),
            'b_postcode' => $order->get_billing_postcode(),
            's_first_name' => $order->get_shipping_first_name(),
            's_last_name' => $order->get_shipping_last_name(),
            's_company' => $order->get_shipping_company(),
            's_country' => $order->get_shipping_country(),
            's_state' => $order->get_shipping_state(),
            's_city' => $order->get_shipping_city(),
            's_address_1' => $order->get_shipping_address_1(),
            's_address_2' => $order->get_shipping_address_2(),
            's_postcode' => $order->get_shipping_postcode(),
            'post_tracking_code' => (string) get_post_meta($order_id, '_tracking_code', true),
            'post_tracking_url' => (string) get_post_meta($order_id, '_tracking_url', true),
        ];

        return $map;
    }
}

function farazsms_login_boot_woocommerce_sms() {
	new WooCommerce_SMS();
}
if ( did_action( 'init' ) ) {
	farazsms_login_boot_woocommerce_sms();
} else {
	add_action( 'init', __NAMESPACE__ . '\\farazsms_login_boot_woocommerce_sms', 2 );
}

/**
 * کارگرِ پیامکِ سفارشِ ماژولِ ورود — بیرون از درخواستی که مشتری منتظرش است.
 *
 * عمداً از همان مسیرِ اصلیِ ماژول (Send_SMS) رد می‌شود تا کلیدِ اختصاصیِ ماژول
 * و گاردهایش دست‌نخورده بمانند. متغیرهای پترن هم اینجا ساخته می‌شوند.
 *
 * @param int    $order_id
 * @param string $status
 * @param string $which customer|admin
 * @return void
 */
function farazsms_login_order_sms_worker( $order_id, $status, $which ) {
	if ( ! function_exists( 'wc_get_order' ) ) {
		return;
	}
	$order = wc_get_order( (int) $order_id );
	if ( ! ( $order instanceof \WC_Order ) ) {
		\farazsms_send_diag_log( '', '', 'order_missing', array(
			'source' => 'login-order',
			'detail' => 'order=' . (int) $order_id,
		) );
		return;
	}
	// ⚠️ v3.22.202: ساختنِ نمونه ممنوع — سازنده‌ی این کلاس روی
	// woocommerce_order_status_changed هوک ثبت می‌کند و وردپرس هوک را با هشِ
	// آبجکت کلید می‌زند. تخلیه‌ی ۱۰ کارِ صف یعنی ۱۰ شنونده‌ی اضافه در همان
	// درخواست، و هر تغییرِ وضعیتِ بعدی ۱۰ پیامکِ تکراری. متد ایستا است.
	\FarazSMS\WooCommerce_SMS::dispatch_deferred( $order, (string) $status, (string) $which );
}
