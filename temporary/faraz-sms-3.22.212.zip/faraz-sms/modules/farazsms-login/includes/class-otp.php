<?php

namespace FarazSMS;


class OTP {

    /**
     * تبدیل ارقام فارسی/عربی به لاتین — دفاع لایه‌دوم سمت سرور.
     * اگر افزونه فراز اس ام اس فعال باشد از تابع مشترک آن استفاده می‌کند،
     * وگرنه به نگاشت داخلی برمی‌گردد (خوداتکا).
     */
    private function normalize_digits($str) {
        if ($str === null || $str === '') {
            return $str;
        }
        return farazsms_tr_num($str);
    }

    /**
     * v3.21.41 — تضمینِ وجودِ جدولِ verification پیش از هر عملیات.
     *
     * باگِ تکرارشونده‌ی «کد اشتباه است»: جدول فقط در activation ساخته می‌شد. اگر ماژول
     * با toggle فعال شود یا activation hook اجرا نشده باشد، جدول وجود ندارد و ذخیره‌ی کد
     * بی‌صدا fail می‌شود → ردیفی برای تأیید نیست → کدِ درست هم «اشتباه» اعلام می‌شود.
     * این متد (مثلِ الگوی class-wallet) جدول را در صورتِ نبود می‌سازد؛ latchِ هر-درخواست.
     */
    private static $table_ensured = false;
    private function ensure_table_exists() {
        if ( self::$table_ensured ) {
            return;
        }
        global $wpdb;
        $table_name = $wpdb->prefix . 'farazsms_verification';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
            $charset_collate = $wpdb->get_charset_collate();
            $sql = "CREATE TABLE $table_name (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                verification VARCHAR(100) NOT NULL,
                code VARCHAR(10) NOT NULL,
                expire_date DATETIME NULL,
                PRIMARY KEY (id),
                UNIQUE (verification)
            ) $charset_collate;";
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            dbDelta( $sql );
        }
        self::$table_ensured = true;
    }

    public function send_verification_code($verification, $verification_code) {
        global $wpdb;
        $this->ensure_table_exists();
        $table_name = $wpdb->prefix . 'farazsms_verification';
        // اعتبارِ کد: ۵ دقیقه (قبلاً ۲ دقیقه بود که با تأخیرِ تحویلِ پیامک گاهی منقضی می‌شد
        // و کدِ درست «اشتباه» اعلام می‌گشت).
        $expire_time = 5;
        $expire_date = date("Y-m-d H:i:s", strtotime("+$expire_time minutes"));

        // v3.21.41: replace به‌جای insert — اتمیک روی UNIQUE(verification). حتی اگر ردیفِ
        // قبلیِ این شماره (به هر دلیل) حذف نشده باشد، کدِ جدید جایگزین می‌شود و خطای کلیدِ
        // تکراری باعثِ ماندنِ کدِ قدیمی (و «کد اشتباه») نمی‌شود.
        $wpdb->replace(
            $table_name,
            array(
                'verification'  => $verification,
                'code'          => $verification_code,
                'expire_date'   => $expire_date,
            ),
            array('%s', '%s', '%s')
        );

        // v3.22.32: با صدورِ کدِ جدید، شمارنده‌ی تلاشِ تأیید را صفر کن. قبلاً اگر کاربر ۵ بار
        // اشتباه می‌زد و بعد «ارسالِ مجدد» می‌کرد، کدِ تازه هم به‌خاطرِ قفلِ ۱۰دقیقه‌ای همان
        // شماره باطل می‌شد و «کد اشتباه» می‌گرفت. ارسالِ مجدد خودش با نرخِ ۳بار/۵دقیقه محدود
        // است، پس این reset brute-force را باز نمی‌کند (نهایتاً ۱۵ تلاش/۵دقیقه؛ کدِ ۶رقمی امن).
        delete_transient( 'farazsms_otp_try_' . md5( (string) $verification ) );
    }
    

    public function verify_verification_code($verification, $verification_code) {
        global $wpdb;
        $this->ensure_table_exists();
        $table_name = $wpdb->prefix . 'farazsms_verification';

        // v3.21.25 امنیتی — محدودیتِ تلاشِ تأیید (ضدِ brute-force روی کدِ کوتاه). شمارنده‌ی
        // خطا per-شماره؛ بعد از ۵ تلاشِ ناموفق، کد باطل می‌شود و دیگر پذیرفته نمی‌شود.
        $attempt_key = 'farazsms_otp_try_' . md5( (string) $verification );
        $tries       = (int) get_transient( $attempt_key );
        if ( $tries >= 5 ) {
            $this->delete_user_verification_data( $verification );
            return false;
        }

        // آخرین کدِ ثبت‌شده برای این شماره ملاک است (در صورت ارسال مجدد، ردیفِ قدیمی انتخاب نشود).
        $result = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE verification = %s ORDER BY id DESC LIMIT 1", $verification));

        if ($result) {
            // trim برای حذف فاصله‌ی احتمالی + نرمال‌سازی ارقام فارسی/عربی در هر دو طرف.
            $expected_code     = trim((string) $this->normalize_digits($result->code));
            $verification_code = trim((string) $this->normalize_digits($verification_code));
            $expire_date       = strtotime($result->expire_date);
            if ($verification_code !== '' && $verification_code === $expected_code && $expire_date > time()) {
                // v3.21.25 امنیتی — تک‌مصرف: کدِ مطابقت‌یافته بلافاصله حذف می‌شود تا replay ممکن نباشد.
                $wpdb->delete( $table_name, array( 'id' => (int) $result->id ), array( '%d' ) );
                delete_transient( $attempt_key );
                return true;
            }
        }

        // تلاشِ ناموفق → افزایشِ شمارنده (پنجره‌ی ۱۰ دقیقه‌ای).
        set_transient( $attempt_key, $tries + 1, 10 * MINUTE_IN_SECONDS );
        return false;
    }
    
    public function delete_user_verification_data($verification) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'farazsms_verification';

        $expire_condition = 'expire_date < %s';
        $wpdb->query($wpdb->prepare("DELETE FROM $table_name WHERE $expire_condition", date("Y-m-d H:i:s")));
        $wpdb->delete($table_name, ['verification' => $verification], ['%s']);
    }
}