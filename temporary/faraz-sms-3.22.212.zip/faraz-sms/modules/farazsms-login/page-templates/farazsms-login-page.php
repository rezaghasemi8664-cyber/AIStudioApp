<?php
/**
 * Template Name: FarazSMS Login Page
 * Description: A clean login page template for FarazSMS plugin
 * Template: farazsms-login-page
 * Template Post Type: page
 */

if (!defined('ABSPATH')) {
    exit;
}

include FarazSMS_PATH . 'page-templates/header-farazsms-login.php';

/**
 * v3.21.19 — سازگاری با المنتور (و هر صفحه‌سازی که از the_content استفاده می‌کند).
 *
 * پیش از این، این قالب فرم را مستقیماً با do_shortcode رندر می‌کرد و the_content() را
 * هرگز صدا نمی‌زد؛ در نتیجه المنتور هنگامِ ویرایش خطای «ناحیه محتوایی یافت نشد —
 * the_content را فراخوانی کنید» می‌داد و صفحه با المنتور باز نمی‌شد.
 *
 * منطقِ جدید:
 *   - اگر صفحه با المنتور ساخته شده، یا در حالِ ویرایش/پیش‌نمایشِ المنتور است، یا محتوای
 *     واقعی/شورت‌کدِ فرم دارد → the_content() را صدا می‌زنیم (طراحیِ المنتور/محتوا رندر می‌شود).
 *   - در غیرِ این صورت (محتوای خالی یا فقط-کامنت، مثلِ برگه‌ای که پل می‌سازد) → فرمِ
 *     پیش‌فرضِ فراز را نشان می‌دهیم تا رفتارِ قبلی حفظ شود (بدونِ regression).
 */
$farazsms_lp_id        = get_queried_object_id();
$farazsms_lp_elementor = false;

if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance ) ) {
	$el = \Elementor\Plugin::$instance;
	// صفحه با المنتور ساخته شده است؟
	if ( $farazsms_lp_id && isset( $el->documents ) ) {
		$farazsms_lp_doc = $el->documents->get( $farazsms_lp_id );
		if ( $farazsms_lp_doc && method_exists( $farazsms_lp_doc, 'is_built_with_elementor' ) && $farazsms_lp_doc->is_built_with_elementor() ) {
			$farazsms_lp_elementor = true;
		}
	}
	// در حالِ ویرایش/پیش‌نمایشِ المنتور (تا ادیتور هنگامِ بازکردنِ صفحه‌ی خالی خطا ندهد).
	if ( ! $farazsms_lp_elementor ) {
		if ( isset( $_GET['elementor-preview'] ) ) {
			$farazsms_lp_elementor = true;
		} elseif ( isset( $el->preview ) && method_exists( $el->preview, 'is_preview_mode' ) && $el->preview->is_preview_mode() ) {
			$farazsms_lp_elementor = true;
		} elseif ( isset( $el->editor ) && method_exists( $el->editor, 'is_edit_mode' ) && $el->editor->is_edit_mode() ) {
			$farazsms_lp_elementor = true;
		}
	}
}

if ( have_posts() ) {
	while ( have_posts() ) {
		the_post();
		$farazsms_lp_raw          = get_the_content();
		$farazsms_lp_has_form     = has_shortcode( (string) $farazsms_lp_raw, 'farazsms_login_form' );
		$farazsms_lp_has_content  = trim( wp_strip_all_tags( (string) $farazsms_lp_raw ) ) !== '';
		if ( $farazsms_lp_elementor || $farazsms_lp_has_form || $farazsms_lp_has_content ) {
			the_content();
		} else {
			echo do_shortcode( '[farazsms_login_form]' );
		}
	}
} else {
	echo do_shortcode( '[farazsms_login_form]' );
}

// Load minimal footer
include FarazSMS_PATH . 'page-templates/footer-farazsms-login.php';
