<?php
/**
 * Custom header for FarazSMS login page - minimal header
 */

if (!defined('ABSPATH')) {
    exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php wp_title('|', true, 'right'); ?><?php bloginfo('name'); ?></title>
    <?php wp_head(); ?>
    <style id="farazsms-login-page-reset">
    /* v3.22.89: این قالب standalone است ولی wp_head/body_class استایل و کلاس‌های بادیِ تم را هم بار
       می‌کند. اگر تمِ سایت روی موبایل یک سرریزِ افقی بگذارد، فرمِ وسط‌چین به گوشه می‌رود و کاربر صفحه‌ی
       سفید می‌بیند. این ریست فقط روی همین صفحه‌ی ورود (نه سراسریِ سایت) سرریزِ افقی را می‌بندد. */
    html, body { width: 100% !important; max-width: 100% !important; overflow-x: hidden !important; }
    </style>
</head>
<body <?php body_class(); ?>>
<div id="page" class="site farazsms-login-page">
    <div id="content" class="site-content">
