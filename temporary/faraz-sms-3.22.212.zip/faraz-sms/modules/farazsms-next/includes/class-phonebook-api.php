<?php
/**
 * Phonebook API Class
 *
 * Handles API calls to FarazSMS Phonebook service
 */

if (!defined('ABSPATH')) {
    exit;
}

class FarazSMS_Next_Phonebook_API {

    /**
     * API Base URL
     */
    private $api_base_url = 'https://api.iranpayamak.com/ws/v1';

    /**
     * سقفِ آیتم در هر درخواستِ bulk-upsert.
     *
     * عددِ خودِ سرویس است (`items` => `max:500` در اعتبارسنجیِ کنترلر)، نه سلیقه‌ی ما.
     */
    const MAX_ITEMS_PER_REQUEST = 500;

    /**
     * تا این تعداد مخاطبِ بی‌نام، نام‌ها **هدفمند** پرسیده می‌شوند نه با پیمایشِ
     * کلِ دفترچه.
     *
     * ⚠️ چرا (بازبینیِ ۱۴۰۵/۰۶/۱۶): ثبتِ یک فرمِ گرویتی که فیلدِ نام ندارد، یک
     * مخاطبِ بی‌نام می‌سازد. با پیمایشِ کامل، هر ثبتِ فرم کلِ دفترچه را
     * صفحه‌به‌صفحه می‌خواند — هزینه‌ای به‌اندازه‌ی دفترچه برای یک ردیف.
     */
    const TARGETED_NAME_LOOKUP_MAX = 25;

    /**
     * سقفِ زمانیِ کلِ خواندنِ نام‌ها (ثانیه).
     *
     * ⚠️ ۲۵ جست‌وجو × مهلتِ ۳۰ ثانیه یعنی در بدترین حالت دوازده دقیقه روی یک
     * درخواست — دقیقاً همان ۵۰۳ی که این نسخه برای رفعش نوشته شد. از این سقف که
     * رد شد، خواندن «ناموفق» شمرده می‌شود (یعنی محافظه‌کارانه: مخاطبِ بی‌نام
     * فرستاده نمی‌شود تا نامِ ثبت‌شده‌اش پاک نشود).
     */
    const NAME_LOOKUP_TIME_BUDGET = 20;

    /** اندازه‌ی صفحه هنگامِ خواندنِ نام‌های موجود. */
    const EXISTING_NAMES_PER_PAGE = 500;

    /**
     * سقفِ صفحه‌های خوانده‌شده برای نام‌های موجود (۳۰هزار مخاطب).
     *
     * بالاتر از این، خواندن «ناموفق» شمرده می‌شود تا یک دفترچه‌ی غول‌پیکر
     * درخواست را تا بی‌نهایت نگه ندارد.
     */
    const EXISTING_NAMES_MAX_PAGES = 60;


    /**
     * Make API request using cURL
     *
     * @param string $url API endpoint URL
     * @param string $method HTTP method (GET, POST, PUT, DELETE)
     * @param array $data Request data
     * @param string $api_key API key
     * @return array|false Response data or false on error
     */
    protected function make_request($url, $method = 'GET', $data = array(), $api_key = '') {
        if (empty($api_key)) {
            return false;
        }

        if (!function_exists('curl_init')) {
            return false;
        }

        $curl = curl_init();

        $curl_options = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_HTTPHEADER => array(
                'Accept: application/json',
                'Api-Key: ' . $api_key,
                'Content-Type: application/json'
            ),
        );

        if ($method === 'POST') {
            $curl_options[CURLOPT_CUSTOMREQUEST] = 'POST';
            if (!empty($data)) {
                $curl_options[CURLOPT_POSTFIELDS] = json_encode($data);
            }
        } elseif ($method === 'PUT') {
            $curl_options[CURLOPT_CUSTOMREQUEST] = 'PUT';
            if (!empty($data)) {
                $curl_options[CURLOPT_POSTFIELDS] = json_encode($data);
            }
        } elseif ($method === 'DELETE') {
            $curl_options[CURLOPT_CUSTOMREQUEST] = 'DELETE';
        }

        curl_setopt_array($curl, $curl_options);

        $response = curl_exec($curl);
        $http_code = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($curl);
        
        curl_close($curl);

        if ($curl_error) {
            return array('status' => 'error', 'message' => __('خطای cURL: ', 'farazsms-next') . $curl_error);
        }

        // Decode response even if HTTP code is error
        $data = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            // اگر JSON decode نشد، پاسخ خام را برگردان
            return array('status' => 'error', 'message' => __('پاسخ نامعتبر از API: ', 'farazsms-next') . substr($response, 0, 200));
        }

        // اگر HTTP code خطا بود اما JSON decode شد، data را برگردان (شامل پیام خطا)
        if ($http_code >= 400) {
            // اگر data شامل status نبود، اضافه کن
            if (!isset($data['status'])) {
                $data['status'] = 'error';
            }
            return $data;
        }

        return $data;
    }

    /**
     * Create a new phonebook
     *
     * @param string $name Phonebook name
     * @param string $api_key API key
     * @param array $attributes Optional attributes array
     * @return array|false Phonebook data or false on error
     */
    public function create_phonebook($name, $api_key, $attributes = null) {
        if (empty($name) || empty($api_key)) {
            return false;
        }

        $url = $this->api_base_url . '/phone_book';

        $body = array(
            'title' => $name,
        );

        if ($attributes !== null && is_array($attributes)) {
            $body['attributes'] = $attributes;
        }

        $data = $this->make_request($url, 'POST', $body, $api_key);
             
        if (!$data || !is_array($data)) {
            return false;
        }

        // بررسی خطا در پاسخ
        if (isset($data['status']) && $data['status'] === 'error') {
            $error_message = isset($data['message']) ? $data['message'] : 'Unknown error';
            return array('error' => $error_message);
        }

        if (empty($data)) {
            return false;
        }

        if (isset($data['status']) && $data['status'] !== 'success') {
            $error_message = isset($data['message']) ? $data['message'] : 'Unknown error';
            return array('error' => $error_message);
        }

        if (isset($data['status']) && $data['status'] === 'success') {
            return $data;
        }

        if (isset($data['data'])) {
            return $data['data'];
        }

        return $data;
    }

    /**
     * Add contact to phonebook
     *
     * @param int $phonebook_id Phonebook ID
     * @param string $name Contact name
     * @param string $phone Contact phone number
     * @param string $api_key API key
     * @param string $prefix Optional prefix (man | woman | co | org). Default: 'man'
     * @param array $attributes Optional attributes array
     * @return array Array with 'success' (bool) and 'error' (string) keys
     */
    public function add_contact($phonebook_id, $name, $phone, $api_key, $prefix = 'man', $attributes = array()) {
        if (empty($phonebook_id) || empty($name) || empty($phone) || empty($api_key)) {
            return array('success' => false, 'error' => __('پارامترهای ورودی ناقص است.', 'farazsms-next'));
        }

        // Correct endpoint according to documentation
        $url = $this->api_base_url . '/phone_book_data';

        $phone = preg_replace('/[^0-9]/', '', $phone);
        
        // بررسی اعتبار شماره تلفن
        if (empty($phone) || strlen($phone) < 10) {
            return array('success' => false, 'error' => __('شماره تلفن نامعتبر است.', 'farazsms-next'));
        }
        
        if (empty($prefix)) {
            $prefix = 'man';
        }

        $body = array(
            'phone_book_id' => intval($phonebook_id),
            'prefix' => $prefix,
            'mobile' => $phone,
            'name' => $name,
        );

        // Add attributes if provided
        if (!empty($attributes) && is_array($attributes)) {
            $body['attributes'] = $attributes;
        }

        $data = $this->make_request($url, 'POST', $body, $api_key);

        if (!$data || !is_array($data)) {
            return array('success' => false, 'error' => __('پاسخ از API دریافت نشد.', 'farazsms-next'));
        }

        // بررسی status در پاسخ
        if (isset($data['status']) && $data['status'] === 'success') {
            return array('success' => true);
        }

        // استخراج پیام خطا از پاسخ API
        $error_message = __('خطای نامشخص از API', 'farazsms-next');
        if (isset($data['message'])) {
            $error_message = is_array($data['message']) ? json_encode($data['message'], JSON_UNESCAPED_UNICODE) : $data['message'];
        } elseif (isset($data['data']['message'])) {
            $error_message = is_array($data['data']['message']) ? json_encode($data['data']['message'], JSON_UNESCAPED_UNICODE) : $data['data']['message'];
        } elseif (isset($data['error'])) {
            $error_message = is_array($data['error']) ? json_encode($data['error'], JSON_UNESCAPED_UNICODE) : $data['error'];
        }

        return array('success' => false, 'error' => $error_message);
    }

    /**
     * نرمال‌سازی شماره برای API دفترچه (09xxxxxxxxx).
     *
     * @param string $phone
     * @return string
     */
    public function normalize_contact_mobile($phone) {
        $phone = (string) $phone;
        $phone = farazsms_normalize_phone($phone);
        $phone = preg_replace('/[^0-9]/', '', $phone);
        if (preg_match('/^09\d{9}$/', $phone)) {
            return $phone;
        }
        return '';
    }

    /**
     * استخراج پیام خطا از پاسخ API.
     *
     * @param array $response
     * @return string
     */
    protected function extract_api_error_message(array $response) {
        if (isset($response['message'])) {
            $msg = $response['message'];
            if (is_string($msg) && $msg !== '') {
                return $msg;
            }
            if (is_array($msg)) {
                return wp_json_encode($msg, JSON_UNESCAPED_UNICODE);
            }
        }
        if (isset($response['messages'])) {
            $msg = $response['messages'];
            if (is_string($msg) && $msg !== '') {
                return $msg;
            }
            if (is_array($msg)) {
                return wp_json_encode($msg, JSON_UNESCAPED_UNICODE);
            }
        }
        return __('خطای API در import گروهی', 'farazsms-next');
    }

    /**
     * واردسازیِ گروهیِ مخاطبین (POST /phone_book_data/bulk-upsert).
     *
     * ⚠️ چرا JSON و نه اکسل (۲۰۲۶-۰۹-۰۳، پس از آزمونِ زنده روی سایتِ مشتری):
     *
     * تا این نسخه، مخاطبان در یک فایلِ xlsx به `/phone_book_data/excel-upsert`
     * می‌رفتند. آن اندپوینت فایل را ذخیره و یک جابِ صف را dispatch می‌کند و
     * بی‌درنگ success می‌دهد. آزمون نشان داد آن جاب هیچ ردیفی وارد نمی‌کند:
     * چهار شکلِ مختلفِ فایل — از جمله فایلِ ۲۴هزارردیفیِ خودِ پنل که از رابطِ
     * وب سالم ایمپورت می‌شود — همگی ۲۰۰ و «success» گرفتند و صفر مخاطب.
     * در همان لحظه مسیرِ تکی (add_contact) روی همان دفترچه بی‌درنگ کار کرد.
     *
     * این اندپوینت همان سرویسِ داخلی (PhonebookDataCrudService::bulkUpsert) را
     * صدا می‌زند که ایمپورترِ پنلِ قدیم هم از آن استفاده می‌کند — **همگام**،
     * بدونِ فایل و بدونِ صف. یعنی پاسخِ success دیگر «به صف رفت» نیست، بلکه
     * «ثبت شد» است.
     *
     * قراردادِ سرویس (از کدِ کنترلر و سرویس، نه حدس):
     *   - سقفِ هر درخواست ۵۰۰ آیتم.
     *   - mobile باید با ^09\d{9}$ بخوانَد.
     *   - prefix از man|woman|co|org یا null.
     *   - هر سه کلیدِ mobile/prefix/name باید **حاضر** باشند؛ سرویس آن‌ها را
     *     بدونِ گارد می‌خواند و نبودشان خطای «Undefined array key» می‌دهد،
     *     هرچند اعتبارسنجی nullable اعلامشان کرده.
     *   - تکراری‌ها را خودِ سرویس بر پایه‌ی mobile یکتا می‌کند و رکوردِ موجود
     *     به‌روزرسانی می‌شود (upsert).
     *
     * @param int    $phonebook_id
     * @param array  $contacts آرایه‌ای از ['phone'|'mobile', 'name', 'prefix'?]
     * @param string $api_key
     * @param int    $chunk_size تعدادِ آیتم در هر درخواست (سقفِ سرویس ۵۰۰).
     * @return array success, imported, queued, failed, parts, http, error, via
     */
    public function bulk_upsert_contacts($phonebook_id, array $contacts, $api_key, $chunk_size = 500) {
        $phonebook_id = (int) $phonebook_id;
        if ($phonebook_id <= 0 || empty($api_key)) {
            // ⚠️ شمارِ جامانده باید واقعی باشد: مصرف‌کننده‌ها جمله‌ی «چند شماره
            // نرفت» را از همین می‌سازند و صفرِ ثابت آن را بی‌صدا خفه می‌کرد.
            return $this->bulk_result(false, 0, count($contacts), 0, 0, __('پارامترهای ورودی ناقص است.', 'farazsms-next'));
        }

        $by_mobile = array();
        foreach ($contacts as $c) {
            if (!is_array($c)) {
                continue;
            }
            $raw_phone = isset($c['phone']) ? $c['phone'] : (isset($c['mobile']) ? $c['mobile'] : '');
            $mobile = $this->normalize_contact_mobile($raw_phone);
            if ($mobile === '') {
                continue;
            }
            // نامِ ساختگی ساخته نمی‌شود: نامِ خالی یعنی خالی، و null به سرویس می‌رود.
            $name   = isset($c['name']) ? trim((string) $c['name']) : '';
            $prefix = isset($c['prefix']) ? (string) $c['prefix'] : '';
            if (!in_array($prefix, array('man', 'woman', 'co', 'org'), true)) {
                $prefix = '';
            }
            // ⚠️ هر سه کلید همیشه حاضرند (با مقدارِ null وقتی نداریم) — بندِ
            // بالای این docblock می‌گوید چرا نبودشان سرویس را می‌شکند.
            $by_mobile[$mobile] = array(
                'mobile' => $mobile,
                'prefix' => ($prefix === '' ? null : $prefix),
                'name'   => ($name === '' ? null : $name),
            );
        }

        $prepared   = array_values($by_mobile);
        $total_rows = count($prepared);
        unset($by_mobile);
        if ($total_rows === 0) {
            return $this->bulk_result(false, 0, count($contacts), 0, 0, __('هیچ شماره معتبری برای import یافت نشد.', 'farazsms-next'));
        }

        // ⚠️ نامِ موجود پاک نمی‌شود.
        //
        // سرویس با `DO UPDATE SET name = EXCLUDED.name` می‌نویسد، پس فرستادنِ
        // نامِ خالی برای مخاطبی که در پنل نام دارد، نامش را نابود می‌کند. برای
        // مخاطبانی که سمتِ ما نام ندارند، نامِ فعلیِ خودشان را از دفترچه
        // می‌خوانیم و همان را برمی‌گردانیم.
        //
        // هزینه فقط وقتی پرداخت می‌شود که واقعاً مخاطبِ بی‌نامی در کار باشد؛
        // در حالتِ عادیِ همگام‌سازیِ ووکامرس (که همه نام دارند) هیچ درخواستِ
        // اضافه‌ای نمی‌رود.
        $nameless = array();
        foreach ($prepared as $i => $row) {
            if ($row['name'] === null) {
                $nameless[] = $i;
            }
        }
        if (!empty($nameless)) {
            $nameless_mobiles = array();
            foreach ($nameless as $i) {
                $nameless_mobiles[] = $prepared[$i]['mobile'];
            }
            $existing = $this->fetch_existing_names($phonebook_id, $api_key, $nameless_mobiles);
            if ($existing === null) {
                // نتوانستیم نام‌های فعلی را بخوانیم. فرستادنشان یعنی ریسکِ پاک‌کردنِ
                // نامِ درست؛ ازدست‌دادنِ داده بدتر از تعویقِ افزودن است، پس این
                // ردیف‌ها این بار نمی‌روند و صریح گزارش می‌شوند.
                foreach ($nameless as $i) {
                    unset($prepared[$i]);
                }
                $prepared        = array_values($prepared);
                $errors_prefetch = __('نام‌های فعلیِ دفترچه خوانده نشد؛ مخاطبانِ بی‌نام این بار فرستاده نشدند تا نامِ ثبت‌شده‌شان پاک نشود.', 'farazsms-next');
            } else {
                foreach ($nameless as $i) {
                    $mobile = $prepared[$i]['mobile'];
                    if (isset($existing[$mobile])) {
                        $prepared[$i]['name'] = $existing[$mobile];
                    }
                }
            }
        }
        if (empty($prepared)) {
            return $this->bulk_result(false, 0, $total_rows, 0, 0, isset($errors_prefetch) ? $errors_prefetch : __('هیچ شماره معتبری برای import یافت نشد.', 'farazsms-next'));
        }

        $chunk_size = (int) $chunk_size;
        if ($chunk_size < 1 || $chunk_size > static::MAX_ITEMS_PER_REQUEST) {
            $chunk_size = static::MAX_ITEMS_PER_REQUEST;
        }

        $url       = $this->api_base_url . '/phone_book_data/bulk-upsert';
        $imported  = 0;
        $parts     = 0;
        $errors    = array();
        $last_http = 0;

        $sending = count($prepared);
        for ($offset = 0; $offset < $sending; $offset += $chunk_size) {
            $group = array_slice($prepared, $offset, $chunk_size);
            if (empty($group)) {
                continue;
            }
            $parts++;

            // ⚠️ نامِ دارای UTF-8ِ نامعتبر، wp_json_encode را false می‌کند. بدونِ این
            // گارد بدنه‌ی خالی پست می‌شد و هر بسته با خطایی بی‌ربط شکست می‌خورد.
            $body = wp_json_encode(array(
                'phone_book_id' => $phonebook_id,
                'items'         => $group,
            ));
            if ($body === false) {
                $errors[] = __('کدگذاریِ داده‌ها برای ارسال ناموفق بود (نویسه‌ی نامعتبر در نام).', 'farazsms-next');
                farazsms_send_diag_log('phonebook', 'bulk-upsert', 'api_error:' . end($errors), array(
                    'source'    => 'phonebook-bulk',
                    'http_code' => 0,
                    'detail'    => 'part=' . $parts . ' rows=' . count($group),
                ));
                continue;
            }

            $response = wp_remote_post($url, array(
                // ۵۰۰ upsert سمتِ سرور می‌تواند بیش از ۳۰ ثانیه طول بکشد؛ تایم‌اوتِ
                // زودهنگام بسته‌ی واقعاً ثبت‌شده را «شکست‌خورده» می‌شمارد و کاربر
                // دوباره می‌فرستد. (تکرار بی‌خطر است چون upsert است، ولی گمراه‌کننده.)
                'timeout' => 60,
                'headers' => array(
                    'Accept'       => 'application/json',
                    'Content-Type' => 'application/json',
                    'Api-Key'      => $api_key,
                ),
                'body'    => $body,
            ));

            $http      = 0;
            $error_msg = '';
            if (is_wp_error($response)) {
                $error_msg = $response->get_error_message();
            } else {
                $http = (int) wp_remote_retrieve_response_code($response);
                $data = json_decode((string) wp_remote_retrieve_body($response), true);
                // ⚠️ کلِ بازه‌ی ۲xx: پیاده‌سازیِ قبلی هم `>= 200 && < 300` بود و باریک‌کردنش
                // به ۲۰۰ یعنی یک ۲۰۱/۲۰۲ واردسازیِ کاملاً موفق را «شکستِ کامل» گزارش کند.
                if ($http >= 200 && $http < 300 && is_array($data) && isset($data['status']) && $data['status'] === 'success') {
                    $imported += count($group);
                } else {
                    $error_msg = is_array($data)
                        ? $this->extract_api_error_message($data)
                        : __('پاسخی از سرویس دریافت نشد.', 'farazsms-next');
                }
            }

            $is_error = ($error_msg !== '');
            if ($is_error) {
                $last_http = $http;
                // ⚠️ سقفِ نرخ: ادامه‌ی بسته‌های بعدی هم شکست می‌خورد و فقط سهمیه را
                // عمیق‌تر می‌سوزاند. پیامِ خامِ انگلیسیِ سرویس به کاربر کمکی نمی‌کند.
                if ($http === 429) {
                    $error_msg = __('سرویس به‌خاطرِ تعدادِ زیادِ درخواست موقتاً پاسخ نمی‌دهد؛ چند دقیقه بعد دوباره همگام‌سازی کنید.', 'farazsms-next');
                }
                $errors[] = $error_msg;
            }

            // لاگِ تشخیص برای هر بسته — تنها ردِ قابلِ پیگیریِ این مسیر روی سایتِ کاربر.
            // پیشوندِ api_error لازم است تا متنِ خطا در ستونِ خطای «تشخیص ارسال» بنشیند.
            farazsms_send_diag_log('phonebook', 'bulk-upsert', $is_error ? ('api_error:' . $error_msg) : 'success', array(
                'source'    => 'phonebook-bulk',
                'http_code' => $http,
                'detail'    => 'part=' . $parts . ' rows=' . count($group),
            ));

            // ⚠️ خطای **قطعی** حلقه را می‌بندد، نه فقط سقفِ نرخ. کلیدِ نامعتبر یا
            // دفترچه‌ی حذف‌شده برای هر بسته یکسان تکرار می‌شود؛ ادامه‌دادن یعنی
            // ده‌ها درخواستِ محکوم‌به‌شکست که هر کدام تا ۶۰ ثانیه صبر می‌کنند و
            // در پایان همان یک خطا را می‌دهند. خطای گذرا (۵xx یا شکستِ شبکه)
            // عمداً ادامه می‌یابد تا یک بسته‌ی بد کلِ واردسازی را قربانی نکند.
            if (in_array($http, array(429, 401, 403, 404, 422), true)) {
                break;
            }
        }

        if (isset($errors_prefetch)) {
            array_unshift($errors, $errors_prefetch);
        }
        $error_text = empty($errors) ? '' : implode(' | ', array_slice(array_values(array_unique($errors)), 0, 3));

        return $this->bulk_result(
            ($imported > 0),
            $imported,
            max(0, $total_rows - $imported),
            $parts,
            $last_http,
            ($imported > 0) ? $error_text : ($error_text !== '' ? $error_text : __('واردسازیِ گروهی انجام نشد.', 'farazsms-next'))
        );
    }

    /**
     * نگاشتِ «موبایل → نامِ فعلی» از خودِ دفترچه.
     *
     * ⚠️ چرا لازم است: سرویس با
     * `ON CONFLICT ... DO UPDATE SET name = EXCLUDED.name` می‌نویسد. یعنی
     * فرستادنِ نامِ خالی برای مخاطبی که از قبل نام دارد، نامش را **پاک
     * می‌کند**. هر همگام‌سازیِ دوباره‌ای که سمتِ ما نام نداشته باشد، دادهٔ
     * درستِ داخلِ پنل را از بین می‌برد.
     *
     * @param int    $phonebook_id
     * @param string $api_key
     * @param array  $mobiles موبایل‌هایی که نامشان را می‌خواهیم.
     * @return array<string,string>|null نگاشت، یا null اگر خواندن ناموفق بود.
     */
    protected function fetch_existing_names($phonebook_id, $api_key, array $mobiles = array()) {
        $map = array();

        // مسیرِ هدفمند: برای چند مخاطب، هرکدام را جدا می‌پرسیم. هزینه به تعدادِ
        // چیزی که لازم داریم بستگی دارد، نه به اندازه‌ی دفترچه.
        if (!empty($mobiles) && count($mobiles) <= static::TARGETED_NAME_LOOKUP_MAX) {
            $deadline = time() + static::NAME_LOOKUP_TIME_BUDGET;
            foreach ($mobiles as $mobile) {
                if (time() > $deadline) {
                    return null; // بودجه تمام شد — نگاشتِ ناقص از نبودش بدتر است.
                }
                $rows = $this->fetch_names_page($phonebook_id, $api_key, array('search' => $mobile, 'limit' => 50));
                if ($rows === null) {
                    return null;
                }

                // ⚠️ اگر سرویس پارامترِ search را نادیده بگیرد، ردیف‌های دلخواهِ
                // دفترچه برمی‌گردند و «پیدا نشد» تعبیر می‌شود — یعنی نامِ
                // ثبت‌شده‌ی همه پاک می‌شود. پس نبودِ تطابق را وقتی می‌پذیریم که
                // پاسخ کوچک باشد؛ پاسخِ پرِ بی‌تطابق نشانه‌ی بی‌اثربودنِ فیلتر است.
                $matched = false;
                foreach ($rows as $row) {
                    if (!is_array($row) || empty($row['mobile'])) {
                        continue;
                    }
                    $found = $this->normalize_contact_mobile($row['mobile']);
                    if ($found !== $mobile) {
                        continue;
                    }
                    $matched = true;
                    $name    = isset($row['name']) ? trim((string) $row['name']) : '';
                    if ($name !== '') {
                        $map[$found] = $name;
                    }
                }
                if (!$matched && count($rows) >= 50) {
                    return null; // فیلتر ظاهراً اعمال نشده؛ حدس نمی‌زنیم.
                }
            }
            return $map;
        }

        $deadline = time() + static::NAME_LOOKUP_TIME_BUDGET;
        for ($page = 1; $page <= static::EXISTING_NAMES_MAX_PAGES; $page++) {
            if (time() > $deadline) {
                return null;
            }
            $rows = $this->fetch_names_page($phonebook_id, $api_key, array(
                'page'  => $page,
                'limit' => static::EXISTING_NAMES_PER_PAGE,
            ), $page_data);
            if ($rows === null) {
                return null;
            }
            if (empty($rows)) {
                // دفترچه‌ی خالی (یا پایانِ صفحه‌ها) یعنی «نامی برای حفظ نیست» —
                // نه «خواندن ناموفق بود». تفاوتشان سرنوشتِ مخاطبانِ بی‌نام است.
                return $map;
            }

            foreach ($rows as $row) {
                if (!is_array($row) || empty($row['mobile'])) {
                    continue;
                }
                $mobile = $this->normalize_contact_mobile($row['mobile']);
                $name   = isset($row['name']) ? trim((string) $row['name']) : '';
                if ($mobile !== '' && $name !== '') {
                    $map[$mobile] = $name;
                }
            }

            $last_page = isset($page_data['last_page']) ? (int) $page_data['last_page'] : $page;
            if ($page >= $last_page) {
                return $map;
            }
        }

        // سقفِ صفحه‌ها پر شد و هنوز تمام نشده بود → نگاشت ناقص است و اتکا به آن
        // یعنی همان نام‌هایی که ندیدیم پاک شوند.
        return null;
    }

    /**
     * یک صفحه از مخاطبانِ دفترچه — تنها نقطه‌ای که این مسیر به شبکه می‌زند.
     *
     * جدا نگه داشته می‌شود تا هر دو مسیرِ «هدفمند» و «پیمایشی» یک ترنسپورت و
     * یک تفسیرِ پاسخ داشته باشند؛ وگرنه دو تعریف از «خواندن ناموفق بود» پیدا
     * می‌کردیم و همان دوگانگی، سرنوشتِ مخاطبانِ بی‌نام را دو جور می‌کرد.
     *
     * @param int    $phonebook_id
     * @param string $api_key
     * @param array  $query      پارامترهای اضافه (page/limit/search).
     * @param array  $page_data  خروجی: بلوکِ صفحه‌بندیِ پاسخ.
     * @return array|null ردیف‌ها، یا null اگر خواندن ناموفق بود.
     */
    protected function fetch_names_page($phonebook_id, $api_key, array $query = array(), &$page_data = array()) {
        $page_data = array();
        $url = add_query_arg(
            array_merge(array('phone_book_id' => (int) $phonebook_id), $query),
            $this->api_base_url . '/phone_book_data'
        );

        $response = wp_remote_get($url, array(
            'timeout' => 30,
            'headers' => array(
                'Accept'  => 'application/json',
                'Api-Key' => $api_key,
            ),
        ));
        if (is_wp_error($response)) {
            return null;
        }
        $http = (int) wp_remote_retrieve_response_code($response);
        $data = json_decode((string) wp_remote_retrieve_body($response), true);
        if ($http < 200 || $http >= 300 || !is_array($data)) {
            return null;
        }

        $page_data = isset($data['data']['phone_book_data']) && is_array($data['data']['phone_book_data'])
            ? $data['data']['phone_book_data']
            : array();

        return isset($page_data['data']) && is_array($page_data['data']) ? $page_data['data'] : array();
    }

    /**
     * شکلِ واحدِ خروجیِ واردسازیِ گروهی.
     *
     * ⚠️ کلیدِ `queued` عمداً هم‌مقدارِ `imported` می‌مانَد: سه مصرف‌کننده آن را
     * می‌خوانند و شاخه‌های «چند تا رفت» را با همان می‌سازند. حالا که مسیر همگام
     * است، این عدد واقعاً «ثبت‌شده» است، نه «به صف رفته».
     *
     * @return array
     */
    private function bulk_result($success, $imported, $failed, $parts, $http, $error) {
        return array(
            'success'  => (bool) $success,
            'imported' => (int) $imported,
            'queued'   => (int) $imported,
            'failed'   => (int) $failed,
            'parts'    => (int) $parts,
            'http'     => (int) $http,
            'error'    => (string) $error,
            'via'      => 'bulk',
        );
    }

    /**
     * متنِ هشدارِ شکستِ جزئی — تنها پیاده‌سازیِ این جمله در کلِ افزونه.
     *
     * وقتی بخشی از فهرست پذیرفته می‌شود و بخشی نه، نتیجه `success=true` است و متنِ خطا
     * در کلیدِ error می‌مانَد؛ اگر مصرف‌کننده آن را نخوانَد، ردیف‌های جامانده بی‌صدا
     * ناپدید می‌شوند. سه مصرف‌کننده قبلاً هرکدام نسخه‌ی خودشان را داشتند (دو تا حتی
     * بدونِ ترجمه‌پذیری) و یکی شاخه‌ی «خطا بدونِ ردیفِ ازدست‌رفته» را جا انداخته بود.
     *
     * @param array $result خروجیِ bulk_upsert_contacts
     * @return string رشته‌ی خالی وقتی چیزی جا نمانده و خطایی هم نبوده.
     */
    public static function partial_failure_text($result) {
        if (!is_array($result)) {
            return '';
        }
        $failed = isset($result['failed']) ? (int) $result['failed'] : 0;
        $error  = isset($result['error']) ? trim((string) $result['error']) : '';
        if ($failed <= 0 && $error === '') {
            return '';
        }
        if ($failed <= 0) {
            return ' ' . sprintf(
                /* translators: %s: متنِ خطای سرویس */
                __('⚠️ سرویس یک هشدار داد: %s', 'farazsms-next'),
                $error
            );
        }
        return ' ' . sprintf(
            /* translators: 1: تعدادِ شماره‌ی ارسال‌نشده، 2: متنِ خطای سرویس */
            __('⚠️ %1$d شماره ارسال نشد: %2$s', 'farazsms-next'),
            $failed,
            $error !== '' ? $error : __('خطای نامشخص', 'farazsms-next')
        );
    }

    /**
     * Get list of phonebooks
     *
     * @param string $api_key API key
     * @return array|false List of phonebooks or false on error
     */
    public function get_phonebooks($api_key) {
        if (empty($api_key)) {
            return false;
        }

        $per_page = 100;
        $max_pages = 20;
        $page = 1;
        $merged_data = null;
        $merged_items = array();
        $seen_ids = array();

        while ($page <= $max_pages) {
            $url = $this->api_base_url . '/phone_book?page=' . intval($page) . '&per_page=' . intval($per_page) . '&limit=' . intval($per_page);

            $data = $this->make_request($url, 'GET', array(), $api_key);

            if (!$data || !is_array($data)) {
                break;
            }

            // بررسی خطا در پاسخ
            if (isset($data['status']) && $data['status'] === 'error') {
                break;
            }

            if ($merged_data === null) {
                $merged_data = $data;
            }

            $items = $this->extract_phonebook_items_from_response($data);
            if (empty($items)) {
                break;
            }

            $new_items_count = 0;
            foreach ($items as $item) {
                if (!is_array($item)) {
                    continue;
                }

                $item_id = isset($item['id']) ? $item['id'] : (isset($item['phone_book_id']) ? $item['phone_book_id'] : null);
                $dedupe_key = $item_id !== null ? 'id:' . (string) $item_id : 'row:' . md5(wp_json_encode($item));

                if (isset($seen_ids[$dedupe_key])) {
                    continue;
                }

                $seen_ids[$dedupe_key] = true;
                $merged_items[] = $item;
                $new_items_count++;
            }

            if (!$this->phonebook_response_has_next_page($data, $page, count($items), $per_page) || $new_items_count === 0) {
                break;
            }

            $page++;
        }

        if ($merged_data === null) {
            return false;
        }

        return $this->replace_phonebook_items_in_response($merged_data, $merged_items);
    }

    /**
     * Extract phonebook rows from supported API response shapes.
     *
     * @param array $data API response.
     * @return array
     */
    protected function extract_phonebook_items_from_response($data) {
        if (isset($data['data']['items']) && is_array($data['data']['items'])) {
            return $data['data']['items'];
        }

        if (isset($data['data']['data']) && is_array($data['data']['data'])) {
            return $data['data']['data'];
        }

        if (isset($data['data']) && is_array($data['data']) && isset($data['data'][0])) {
            return $data['data'];
        }

        return array();
    }

    /**
     * Detect whether the API likely has another phonebook page.
     *
     * @param array $data API response.
     * @param int $page Current page.
     * @param int $items_count Current page item count.
     * @param int $per_page Requested page size.
     * @return bool
     */
    protected function phonebook_response_has_next_page($data, $page, $items_count, $per_page) {
        if (isset($data['data']['last_page'])) {
            return $page < intval($data['data']['last_page']);
        }

        if (isset($data['data']['meta']['last_page'])) {
            return $page < intval($data['data']['meta']['last_page']);
        }

        if (isset($data['data']['next_page_url'])) {
            return !empty($data['data']['next_page_url']);
        }

        if (isset($data['data']['links']['next'])) {
            return !empty($data['data']['links']['next']);
        }

        return $items_count >= $per_page;
    }

    /**
     * Put merged phonebook rows back into the original response shape.
     *
     * @param array $data Original API response.
     * @param array $items Merged phonebook rows.
     * @return array
     */
    protected function replace_phonebook_items_in_response($data, $items) {
        if (isset($data['data']['items']) && is_array($data['data']['items'])) {
            $data['data']['items'] = $items;
            return $data;
        }

        if (isset($data['data']['data']) && is_array($data['data']['data'])) {
            $data['data']['data'] = $items;
            return $data;
        }

        if (isset($data['data']) && is_array($data['data'])) {
            $data['data'] = $items;
        }

        return $data;
    }

    /**
     * Get list of contacts from phonebook
     *
     * @param int $phonebook_id Phonebook ID
     * @param string $api_key API key
     * @return array|false Array of normalized mobile numbers or false on error
     */
    public function get_phonebook_contacts($phonebook_id, $api_key) {
        if (empty($phonebook_id) || empty($api_key)) {
            return false;
        }

        $all_mobile_numbers = array();
        $page = 1;
        $has_more = true;

        while ($has_more) {
            $url = $this->api_base_url . '/phone_book_data';
            $url .= '?phone_book_id=' . intval($phonebook_id) . '&page=' . $page;
            
            $data = $this->make_request($url, 'GET', array(), $api_key);

            if (!$data || !is_array($data)) {
                break;
            }

            // بررسی خطا در پاسخ
            if (isset($data['status']) && $data['status'] === 'error') {
                break;
            }

            $contacts = array();
            
            if (isset($data['data']['phone_book_data']['data']) && is_array($data['data']['phone_book_data']['data'])) {
                $contacts = $data['data']['phone_book_data']['data'];
            } elseif (isset($data['data']['data']) && is_array($data['data']['data'])) {
                $contacts = $data['data']['data'];
            } elseif (isset($data['data']['items']) && is_array($data['data']['items'])) {
                $contacts = $data['data']['items'];
            }

            foreach ($contacts as $contact) {
                if (isset($contact['mobile'])) {
                    $normalized = preg_replace('/[^0-9]/', '', $contact['mobile']);
                    if (!empty($normalized)) {
                        $all_mobile_numbers[] = $normalized;
                    }
                }
            }

            $has_more = false;
            if (isset($data['data']['phone_book_data']['last_page']) && $page < intval($data['data']['phone_book_data']['last_page'])) {
                $has_more = true;
                $page++;
            } elseif (isset($data['data']['phone_book_data']['next_page_url']) && !empty($data['data']['phone_book_data']['next_page_url'])) {
                $has_more = true;
                $page++;
            } elseif (isset($data['data']['last_page']) && $page < intval($data['data']['last_page'])) {
                $has_more = true;
                $page++;
            } elseif (isset($data['data']['next_page_url']) && !empty($data['data']['next_page_url'])) {
                $has_more = true;
                $page++;
            }
        }

        return $all_mobile_numbers;
    }

    /**
     * Get phonebook contacts count
     *
     * @param int $phonebook_id Phonebook ID
     * @param string $api_key API key
     * @return int|false Contacts count or false on error
     */
    public function get_phonebook_contacts_count($phonebook_id, $api_key) {
        if (empty($phonebook_id) || empty($api_key)) {
            return false;
        }

        $url = $this->api_base_url . '/phone_book_data';
        $url .= '?phone_book_id=' . intval($phonebook_id);
        
        $data = $this->make_request($url, 'GET', array(), $api_key);

        if (!$data) {
            return false;
        }

        if (isset($data['data']['phone_book_data']['total'])) {
            return intval($data['data']['phone_book_data']['total']);
        } elseif (isset($data['data']['phone_book_data']['totalItems'])) {
            return intval($data['data']['phone_book_data']['totalItems']);
        } elseif (isset($data['data']['phone_book_data']['total_items'])) {
            return intval($data['data']['phone_book_data']['total_items']);
        } elseif (isset($data['data']['totalItems'])) {
            return intval($data['data']['totalItems']);
        } elseif (isset($data['data']['total_items'])) {
            return intval($data['data']['total_items']);
        } elseif (isset($data['data']['total'])) {
            return intval($data['data']['total']);
        }

        // ⚠️ عمداً از count()ِ آرایه‌ی نتایج استفاده نمی‌کنیم: آن آرایه فقط **یک صفحه**
        // است. اگر دفترچه بیش از یک صفحه باشد، شمارشِ قبل و بعد هر دو برابرِ اندازه‌ی
        // صفحه می‌شد و «اختلاف = صفر» می‌داد — یعنی واردسازیِ موفق، ناموفق تشخیص داده
        // می‌شد و کلِ لیست دوباره تک‌به‌تک فرستاده می‌شد (همان طوفانِ درخواست که به
        // سقفِ نرخ می‌خورد). شمارشی که «کل» نباشد، شمارش نیست: نامعلوم برمی‌گردانیم.
        return false;
    }

    /**
     * لیست خطوط ارسال (چند مسیر رایج API؛ اولین پاسخ معتبر برگردانده می‌شود)
     *
     * @param string $api_key
     * @return array آرایه‌ای از [ 'line_number' => string, 'title' => string ]
     */
    public function get_sender_lines_normalized($api_key) {
        if (empty($api_key)) {
            return array();
        }
        $paths = array('line', 'lines', 'account/lines', 'sms/lines');
        foreach ($paths as $path) {
            $data = $this->make_request($this->api_base_url . '/' . $path, 'GET', array(), $api_key);
            if (!is_array($data) || (isset($data['status']) && $data['status'] === 'error')) {
                continue;
            }
            $items = array();
            if (isset($data['data']['items']) && is_array($data['data']['items'])) {
                $items = $data['data']['items'];
            } elseif (isset($data['data']['data']) && is_array($data['data']['data'])) {
                $items = $data['data']['data'];
            } elseif (isset($data['data']) && is_array($data['data']) && !empty($data['data']) && isset($data['data'][0])) {
                $items = $data['data'];
            }
            $out = array();
            foreach ($items as $row) {
                if (!is_array($row)) {
                    continue;
                }
                $num = '';
                if (isset($row['number'])) {
                    $num = $row['number'];
                } elseif (isset($row['line_number'])) {
                    $num = $row['line_number'];
                } elseif (isset($row['line'])) {
                    $num = $row['line'];
                }
                $num = is_scalar($num) ? (string) $num : '';
                if ($num !== '') {
                    $title = isset($row['title']) ? (string) $row['title'] : $num;
                    $out[] = array('line_number' => $num, 'title' => $title);
                }
            }
            if (!empty($out)) {
                return $out;
            }
        }
        return array();
    }

    /**
     * ارسال پیامک ساده به لیست گیرندگان (خرد‌بندی خودکار)
     *
     * @param string|int $line_number
     * @param string     $message
     * @param array      $recipients شماره‌ها (فقط رقم)
     * @param string     $api_key
     * @param int        $chunk_size
     * @return array آخرین پاسخ API یا خطا
     */
    public function send_simple_sms_to_recipients($line_number, $message, array $recipients, $api_key, $chunk_size = 80) {
        if (empty($api_key) || $line_number === '' || $line_number === null) {
            return array('status' => 'error', 'message' => __('خط یا کلید API نامعتبر است.', 'farazsms-next'));
        }
        $message = (string) $message;
        if ($message === '') {
            return array('status' => 'error', 'message' => __('متن پیام خالی است.', 'farazsms-next'));
        }
        $clean = array();
        foreach ($recipients as $r) {
            $n = preg_replace('/[^0-9]/', '', (string) $r);
            if (strlen($n) >= 10) {
                $clean[$n] = $n;
            }
        }
        $clean = array_values($clean);
        if (empty($clean)) {
            return array('status' => 'error', 'message' => __('هیچ شماره معتبری یافت نشد.', 'farazsms-next'));
        }
        $chunks = array_chunk($clean, max(1, (int) $chunk_size));
        $last = null;
        foreach ($chunks as $chunk) {
            $body = array(
                'text' => $message,
                'line_number' => $line_number,
                'recipients' => $chunk,
                'number_format' => 'english',
            );
            $last = $this->make_request($this->api_base_url . '/sms/simple', 'POST', $body, $api_key);
            if (is_array($last) && isset($last['status']) && $last['status'] === 'error') {
                return $last;
            }
            usleep(100000);
        }
        return $last ? $last : array('status' => 'success');
    }

    /**
     * ارسال گروهی به همه مخاطبان یک دفترچه (از طریق خواندن مخاطبین و sms/simple)
     *
     * @param int    $phonebook_id
     * @param mixed  $line_number
     * @param string $message
     * @param string $api_key
     * @return array
     */
    public function send_simple_sms_to_phonebook($phonebook_id, $line_number, $message, $api_key) {
        $recipients = $this->get_phonebook_contacts($phonebook_id, $api_key);
        if ($recipients === false || empty($recipients)) {
            return array('status' => 'error', 'message' => __('دفترچه خالی است یا خطا در خواندن مخاطبین.', 'farazsms-next'));
        }
        return $this->send_simple_sms_to_recipients($line_number, $message, $recipients, $api_key);
    }
}
