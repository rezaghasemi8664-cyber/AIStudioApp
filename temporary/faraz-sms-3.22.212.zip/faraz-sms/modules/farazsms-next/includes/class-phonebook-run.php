<?php
/**
 * منبعِ حقیقتِ واحدِ «انتقالِ مخاطبان به دفترچه».
 *
 * چرا این فایل هست: تا پیش از این، حقیقتِ «انتقالی در جریان است و تا کجا رفته»
 * فقط در متغیرهای جاوااسکریپتِ مرورگر زندگی می‌کرد. سرور بینِ دسته‌ها هیچ
 * نمی‌دانست، و تنها نشانه‌ی سمتِ سرور یک ترنزینتِ کورِ ۱۰دقیقه‌ای بود که فقط
 * متنِ «تعداد مخاطبین» را عوض می‌کرد و بعد از شکستِ کار هم زنده می‌ماند.
 *
 * نتیجه‌اش این بود که هیچ‌کدام از این سه ممکن نبود: توقف، ادامه، و تشخیصِ
 * اینکه کار رها شده. نه به‌خاطرِ نبودِ دکمه — به‌خاطرِ نبودِ حالت.
 *
 * هر چهار مسیر (شروع، هر دسته، توقف، نمایش) از همین کلاس می‌خوانند و
 * می‌نویسند. اگر مسیرِ پنجمی اضافه شد، باید از همین رد شود.
 *
 * @package farazsms-next
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class FarazSMS_Next_Phonebook_Run {

	/** آپشنِ رکوردِ اجرا. عمداً آپشن است نه ترنزینت: ترنزینت می‌تواند بی‌صدا ناپدید شود. */
	const OPTION = 'farazsms_pb_run';

	/**
	 * مهلتِ بی‌خبری. اجرایی که بیش از این به‌روز نشده «رهاشده» است.
	 *
	 * از تایم‌اوتِ هر درخواستِ AJAX (۱۲۰ ثانیه) بزرگ‌تر است تا دسته‌ی کندِ در
	 * حالِ اجرا اشتباهاً رهاشده اعلام نشود.
	 */
	const STALE_AFTER = 300;

	/**
	 * رکوردِ خام.
	 *
	 * @return array|null
	 */
	public static function get() {
		$run = get_option( self::OPTION, null );
		return is_array( $run ) ? $run : null;
	}

	/**
	 * وضعیتِ مؤثرِ یک رکورد — با اعمالِ رهاشدگی.
	 *
	 * ⚠️ منطقِ خالص و جدا از خواندنِ آپشن، تا هر حالت در تست ساختنی باشد.
	 *
	 * @param array|null $run
	 * @param int        $now
	 * @return string idle|running|stopped|done|stale
	 */
	public static function status( $run, $now ) {
		if ( ! is_array( $run ) || empty( $run['status'] ) ) {
			return 'idle';
		}
		$status = (string) $run['status'];
		if ( $status !== 'running' ) {
			return $status;
		}
		$updated = isset( $run['updated_at'] ) ? (int) $run['updated_at'] : 0;
		if ( $updated <= 0 || ( $now - $updated ) > self::STALE_AFTER ) {
			return 'stale';
		}
		return 'running';
	}

	/**
	 * آیا اجرایی واقعاً در جریان است؟ (رابط و گاردِ شروع هر دو از همین می‌پرسند)
	 *
	 * @return bool
	 */
	public static function is_running() {
		return self::status( self::get(), time() ) === 'running';
	}

	/**
	 * آیا اصلاً کارِ ناتمامی باقی مانده؟ (بی‌اعتنا به اینکه در جریان است یا نه)
	 *
	 * @param array|null $run
	 * @param int        $now
	 * @return bool
	 */
	public static function has_unfinished_work( $run, $now ) {
		// ⚠️ گاردِ «offset و total باید باشند» برداشته شد: هیچ‌کدام دیگر خوانده
		// نمی‌شوند، و رکوردِ ناقصِ یک نسخه‌ی قدیمی را «تمام‌شده» اعلام می‌کرد —
		// که یعنی شروعِ تازه با نشانِ صفر و ارسالِ دوباره‌ی کلِ فهرست.
		if ( ! is_array( $run ) ) {
			return false;
		}
		if ( self::status( $run, $now ) === 'done' ) {
			return false;
		}
		// ⚠️ v3.22.202: معیار وضعیتِ **ثبت‌شده** است، نه مقایسه‌ی دو شمارنده.
		// شمارنده‌ی پیشرفت از شناسه‌های اسکن‌شده جلو می‌رود و total از تعدادِ
		// کاربرانِ همین سایت می‌آید؛ روی چندسایتی این دو یکی نیستند و
		// «پیشرفت ≥ کل» اجرای نیمه‌کاره را «تمام» نشان می‌داد. پیامدش بدتر از
		// نمایشِ غلط بود: کلیکِ بعدی به‌جای «ادامه» اجرای تازه می‌ساخت و نشان
		// را صفر می‌کرد — یعنی کلِ فهرست از اول ارسال می‌شد.
		return true;
	}

	/**
	 * آیا کارِ ناتمامی هست که کاربر بتواند **از نو راهش بیندازد**؟
	 *
	 * عمداً اجرای در جریان را شامل نمی‌شود: رابط برای آن «در حال انتقال» نشان
	 * می‌دهد، نه «ادامه».
	 *
	 * @param array|null $run
	 * @param int        $now
	 * @return bool
	 */
	public static function is_resumable( $run, $now ) {
		$status = self::status( $run, $now );
		if ( $status !== 'stale' && $status !== 'stopped' ) {
			return false;
		}
		return self::has_unfinished_work( $run, $now );
	}

	/**
	 * شروعِ اجرای تازه، یا ازسرگیریِ اجرای ناتمام.
	 *
	 * @param int $phonebook_id
	 * @param int $total
	 * @return array رکوردِ ذخیره‌شده.
	 */
	public static function start( $phonebook_id, $total ) {
		$now = time();
		$old = self::get();

		// ⚠️ معیار «کارِ ناتمام» است، نه «قابلِ ازسرگیری». اگر فقط حالتِ رهاشده و
		// متوقف را ادامه می‌دادیم، کلیکِ دوم روی یک اجرای **در جریان** (تبِ دوم،
		// یا کاربری که صفحه را رفرش کرده) شمارنده را صفر می‌کرد و کلِ فهرست
		// دوباره فرستاده می‌شد.
		//
		// ازسرگیری فقط وقتی همان دفترچه است؛ وگرنه شمارنده‌های دفترچه‌ی دیگر
		// با هم قاطی می‌شوند و گزارشِ کاربر دروغ می‌گوید.
		$resume = self::has_unfinished_work( $old, $now )
			&& (int) ( $old['phonebook_id'] ?? 0 ) === (int) $phonebook_id;

		$run = array(
			'phonebook_id' => (int) $phonebook_id,
			'total'        => (int) $total,
			'offset'       => $resume ? (int) $old['offset'] : 0,
			'queued'       => $resume ? (int) ( $old['queued'] ?? 0 ) : 0,
			'failed'       => $resume ? (int) ( $old['failed'] ?? 0 ) : 0,
			'no_phone'     => $resume ? (int) ( $old['no_phone'] ?? 0 ) : 0,
			'no_user_id'   => $resume ? (int) ( $old['no_user_id'] ?? 0 ) : 0,
			'invalid'      => $resume ? (int) ( $old['invalid'] ?? 0 ) : 0,
			'last_user_id' => $resume ? (int) ( $old['last_user_id'] ?? 0 ) : 0,
			// ⚠️ شمارِ پیش از شروع هم باید از اجرای قبلی بیاید.
			//
			// بدونِ آن، اجرای ازسرگرفته‌شده مبنای مقایسه ندارد و تأییدِ پایانِ کار
			// اصلاً زمان‌بندی نمی‌شود — یعنی دقیقاً همان انتقال‌های طولانی و
			// نیمه‌کاره‌ای که این شبکه‌ی ایمنی برایشان ساخته شد، بی‌شبکه می‌مانند.
			// ‎-۱ یعنی «نامعلوم» و همان‌طور منتقل می‌شود، نه صفر (که ادعای دروغِ
			// «دفترچه خالی بود» می‌ساخت).
			'count_before' => $resume ? (int) ( $old['count_before'] ?? -1 ) : -1,
			'status'       => 'running',
			'started_at'   => $resume ? (int) ( $old['started_at'] ?? $now ) : $now,
			'updated_at'   => $now,
			'resumed'      => (bool) $resume,
			// شناسه‌ی مالکِ حلقه. دو تب یا دو مدیر دو حلقه می‌سازند و هر دو روی
			// یک رکورد می‌نویسند؛ با توکن، تنها آخرین راننده اجازه‌ی ادامه دارد
			// و حلقه‌ی یتیم در همان دسته‌ی بعدی می‌ایستد.
			'token'        => self::new_token(),
		);
		update_option( self::OPTION, $run, false );
		return $run;
	}

	/**
	 * ثبتِ پیشرفتِ یک دسته.
	 *
	 * ⚠️ ورودی **افزوده‌ی همین دسته** است، نه مجموعِ کل. جمع را خودِ رکورد
	 * نگه می‌دارد: اگر مجموع را مرورگر بفرستد، همان «حالت در مرورگر است» که
	 * علتِ ریشه‌ایِ این تیکت بود، فقط این بار با ظاهرِ سمتِ سرور.
	 *
	 * @param int  $offset       شمارنده‌ی بعدی.
	 * @param int  $queued_delta شماره‌های به‌صف‌رفته‌ی همین دسته.
	 * @param int  $failed_delta شکست‌های همین دسته.
	 * @param bool  $done
	 * @param array $extra نشانِ آخرین شناسه (last_user_id) و شمارنده‌های ردشده
	 *                     (no_phone / no_user_id / invalid) — انباشته می‌شوند.
	 * @return void
	 */
	public static function progress( $offset, $queued_delta, $failed_delta, $done = false, $extra = array() ) {
		$run = self::get();
		if ( ! is_array( $run ) ) {
			return;
		}
		// ⚠️ توقفِ کاربر نباید با به‌روزرسانیِ دسته پاک شود، وگرنه دکمه‌ی توقف
		// در رقابت با دسته‌ی در حالِ اجرا بی‌اثر می‌شود.
		$run['offset']     = (int) $offset;
		$run['queued']     = (int) ( $run['queued'] ?? 0 ) + (int) $queued_delta;
		$run['failed']     = (int) ( $run['failed'] ?? 0 ) + (int) $failed_delta;
		$run['updated_at'] = time();

		// ⚠️ شمارنده‌های «رد شد» هم باید انباشته شوند، وگرنه گزارشِ پایانیِ یک
		// اجرای ازسرگرفته‌شده، «به‌صف‌رفته»ی انباشته را کنارِ «بدونِ شماره»ی
		// همین نوبت می‌گذارد و عددها با هم نمی‌خوانند.
		foreach ( array( 'no_phone', 'no_user_id', 'invalid' ) as $key ) {
			if ( isset( $extra[ $key ] ) ) {
				$run[ $key ] = (int) ( $run[ $key ] ?? 0 ) + (int) $extra[ $key ];
			}
		}
		// شمارِ مخاطبانِ دفترچه پیش از شروع — **یک‌بار** نوشته می‌شود و انباشته
		// نمی‌گردد؛ مبنای مقایسه‌ی پایانِ کار است، نه شمارنده.
		if ( isset( $extra['count_before'] ) ) {
			$run['count_before'] = (int) $extra['count_before'];
		}
		// نشانِ آب: بالاترین شناسه‌ی کاربری که پردازش شد.
		if ( isset( $extra['last_user_id'] ) && (int) $extra['last_user_id'] > 0 ) {
			$run['last_user_id'] = max( (int) ( $run['last_user_id'] ?? 0 ), (int) $extra['last_user_id'] );
		}
		// توقفِ کاربر با به‌روزرسانیِ دسته پاک نمی‌شود، وگرنه دکمه‌ی توقف در
		// رقابت با دسته‌ی در حالِ اجرا بی‌اثر می‌شود.
		if ( (string) ( $run['status'] ?? '' ) !== 'stopped' ) {
			$run['status'] = $done ? 'done' : 'running';
		}
		update_option( self::OPTION, $run, false );
	}

	/**
	 * توکنِ یکتا برای هر راهِ‌اندازی.
	 *
	 * @return string
	 */
	public static function new_token() {
		if ( function_exists( 'wp_generate_password' ) ) {
			return wp_generate_password( 12, false, false );
		}
		return (string) mt_rand( 100000, 999999 ) . (string) time();
	}

	/**
	 * آیا این راننده هنوز مالکِ اجراست؟
	 *
	 * @param string     $token
	 * @param array|null $run
	 * @return bool
	 */
	public static function owns( $token, $run ) {
		if ( ! is_array( $run ) || ! isset( $run['token'] ) ) {
			return true; // رکوردِ نسخه‌ی قبل توکن ندارد؛ حلقه‌ی در جریان نباید بشکند.
		}
		return (string) $run['token'] === (string) $token;
	}

	/**
	 * ضربانِ زنده‌بودن — بدونِ تغییرِ شمارنده‌ها.
	 *
	 * یک دسته می‌تواند از مهلتِ رهاشدگی طولانی‌تر شود (گاردِ AJAX تایم‌اوتِ PHP
	 * را برمی‌دارد). بدونِ ضربان، اجرای زنده «رهاشده» دیده می‌شد و کاربر حلقه‌ی
	 * دومِ موازی راه می‌انداخت.
	 *
	 * @return void
	 */
	public static function touch() {
		$run = self::get();
		if ( ! is_array( $run ) ) {
			return;
		}
		// شرطِ «فقط وقتی running» اینجا نبود: وضعیتِ stopped/done به سن نگاه
		// نمی‌کند، پس تازه‌کردنِ مهرِ زمان روی آن‌ها هیچ اثری ندارد و آن شرط
		// فقط یک گاردِ بی‌اثر بود.
		$run['updated_at'] = time();
		update_option( self::OPTION, $run, false );
	}

	/**
	 * بالاترین شناسه‌ی کاربرِ پردازش‌شده — مبنای صفحه‌بندی.
	 *
	 * @return int
	 */
	public static function last_user_id() {
		$run = self::get();
		return is_array( $run ) ? (int) ( $run['last_user_id'] ?? 0 ) : 0;
	}

	/**
	 * زمان‌بندیِ بررسیِ «واقعاً وارد شد؟» با دادهٔ همین اجرا.
	 *
	 * ⚠️ چرا این‌جا و نه در هندلر: شمارِ پیش از شروع و تعدادِ سپرده‌شده هر دو در
	 * رکوردِ اجرا هستند، و رکورد بلافاصله بعد پاک می‌شود. اگر فراخوانی بعد از
	 * clear بیفتد، هر دو عدد از دست رفته‌اند و بررسی بی‌معنا می‌شود.
	 *
	 * @return bool
	 */
	public static function schedule_import_verify() {
		if ( ! function_exists( 'farazsms_pb_schedule_verify' ) ) {
			return false;
		}
		$run = self::get();
		if ( ! is_array( $run ) ) {
			return false;
		}
		$before = isset( $run['count_before'] ) ? (int) $run['count_before'] : -1;
		if ( $before < 0 ) {
			return false; // شمارِ اولیه در دسترس نبود؛ مقایسه ممکن نیست.
		}
		return farazsms_pb_schedule_verify(
			(int) ( $run['phonebook_id'] ?? 0 ),
			$before,
			(int) ( $run['queued'] ?? 0 )
		);
	}

	/**
	 * پنجره‌ی بعدیِ شناسه‌های کاربر، از روی واترمارک.
	 *
	 * ⚠️ صفحه‌بندی با **شناسه** است نه شماره‌ی ترتیبی: با offsetِ عددی، هر
	 * کاربری که بینِ دو دسته اضافه یا حذف شود کلِ پنجره را جابه‌جا می‌کند و
	 * یکی جا می‌افتد یا یکی دوبار می‌رود. خانه‌اش این‌جاست چون واترمارک هم
	 * این‌جاست — یعنی «تا کجا رفته‌ایم» یک منبع دارد، نه دو.
	 *
	 * @param int $batch_size
	 * @return int[]
	 */
	public static function next_user_ids( $batch_size ) {
		global $wpdb;
		$batch_size = max( 1, (int) $batch_size );
		$ids        = $wpdb->get_col( $wpdb->prepare(
			"SELECT ID FROM {$wpdb->users} WHERE ID > %d ORDER BY ID ASC LIMIT %d",
			self::last_user_id(),
			$batch_size
		) );
		return array_map( 'intval', (array) $ids );
	}

	/**
	 * پیشرفتِ ثبت‌شده‌ی اجرای فعلی.
	 *
	 * ⚠️ v3.22.202: پیش از این، offset از خودِ درخواست خوانده می‌شد. مرورگر
	 * می‌توانست عددِ دلخواه بفرستد و رکوردِ سرور را «تمام‌شده» نشان دهد. حالا
	 * منبعِ پیشرفت همان رکوردی است که خودِ سرور می‌نویسد.
	 *
	 * @return int
	 */
	public static function offset() {
		$run = self::get();
		return is_array( $run ) ? (int) ( $run['offset'] ?? 0 ) : 0;
	}

	/**
	 * درخواستِ توقف. دسته‌ی در حالِ اجرا نیمه‌کاره رها نمی‌شود؛ فقط دسته‌ی
	 * بعدی شروع نمی‌شود.
	 *
	 * @return bool چیزی برای متوقف‌کردن بود؟
	 */
	public static function stop() {
		$run = self::get();
		if ( ! is_array( $run ) || self::status( $run, time() ) !== 'running' ) {
			return false;
		}
		$run['status']     = 'stopped';
		$run['updated_at'] = time();
		update_option( self::OPTION, $run, false );
		return true;
	}

	/**
	 * پاک‌کردنِ رکورد (پایانِ چرخه یا شروعِ کاملاً تازه توسطِ کاربر).
	 *
	 * @return void
	 */
	public static function clear() {
		delete_option( self::OPTION );
	}
}
