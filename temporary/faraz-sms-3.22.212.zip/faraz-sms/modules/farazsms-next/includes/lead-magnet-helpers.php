<?php
/**
 * Lead magnet settings helpers
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lead magnet options with defaults (enabled on when option missing or key omitted).
 *
 * @return array
 */
function farazsms_next_get_lead_magnet_settings() {
	// v3.13.15: پیش‌فرض‌های credit_amount و expiry_days اضافه شد. باگ قبلی:
	// در class-frontend.php اگر credit_amount یا expiry_days خالی بود، لید مگنت
	// رندر نمی‌شد. حالا با پیش‌فرض ۵۰,۰۰۰ تومان اعتبار + ۳ روز مهلت، فروشگاه‌های
	// تازه از همان لحظه فعال‌سازی، لید مگنت کارا دارند.
	// v3.17.4: متن‌ها هم قابل تنظیم — هر کاربری می‌تواند پیام دلخواه خود را بنویسد.
	$defaults = array(
		// v3.22.73: پیش‌فرض «خاموش» (opt-in) — لید مگنت فقط با روشن‌کردنِ صریحِ مدیر (enabled='1') نمایش داده می‌شود.
		'enabled'             => '0',
		'display_position'    => 'bottom-right',
		// محلِ نمایش: everywhere (پیش‌فرض) | home | blog | specific
		'display_location'    => 'everywhere',
		'display_pages'       => '', // شناسه‌ی برگه‌ها (با کاما) وقتی specific انتخاب شد
		// پس از ورود، کاربر به همان صفحه‌ای که بود بازگردد (نه حساب کاربری).
		'return_to_current'   => '1',
		// رفتارِ دکمه: redirect (انتقال به صفحه‌ی ورود) | popup (نمایش فرم در مودال)
		'cta_action'          => 'redirect',
		// ریسپانسیو (موبایل): نمایش در موبایل + نحوه‌ی نمایش
		'mobile_enabled'      => '1',                  // '1' نمایش در موبایل، '0' مخفی در موبایل
		'mobile_style'        => 'popup',              // popup | bar (دکمه‌ی چسبانِ پایین) | icon (آیکونِ گوشه)
		'credit_amount'       => 50000,
		'expiry_days'         => 3,
		// متن‌های قابل تنظیم — هر یک از این‌ها در template جایگزین می‌شوند
		'badge_text'          => '🔥 فقط امروز',
		'title_template'      => '{amount} تومان هدیه!',                 // {amount} placeholder
		'headline_template'   => 'با عضویت در {shop}، اعتبار رایگان بگیر و اولین خریدت رو ارزون‌تر کن.',
		'disclaimer_template' => '⏰ این هدیه فقط {days} روز اعتبار دارد',
		'cta_text'            => '🎁 دریافت اعتبار هدیه',
		// v3.21.56: پس از بستن توسطِ بازدیدکننده، تا این تعداد روز دوباره نمایش داده نشود (کوکی).
		'dismiss_days'        => 30,
	);
	$raw = get_option( 'farazsms_next_lead_magnet_settings', null );
	if ( ! is_array( $raw ) ) {
		return $defaults;
	}

	$merged = array_merge( $defaults, $raw );

	// اگر کاربر فیلدها را خالی کرد (مقدار 0 یا empty string)، باز هم defaults
	// برگردانده می‌شود تا لید مگنت غیرفعال نشود.
	if ( empty( $merged['credit_amount'] ) ) {
		$merged['credit_amount'] = $defaults['credit_amount'];
	}
	if ( empty( $merged['expiry_days'] ) ) {
		$merged['expiry_days'] = $defaults['expiry_days'];
	}
	// اگر متن خالی شد، defaults
	foreach ( array( 'badge_text', 'title_template', 'headline_template', 'disclaimer_template', 'cta_text' ) as $k ) {
		if ( empty( trim( (string) $merged[ $k ] ) ) ) {
			$merged[ $k ] = $defaults[ $k ];
		}
	}

	return $merged;
}

/**
 * آیا لید مگنت باید در صفحه‌ی فعلی نمایش داده شود؟
 * محلِ نمایش بر اساسِ تنظیمِ display_location: همه‌جا / صفحه اصلی / بلاگ / برگه‌های خاص.
 *
 * @return bool
 */
function farazsms_next_lead_magnet_should_display() {
	// v3.22.73 پیش‌فرضِ «خاموش» (opt-in): لید مگنت فقط وقتی نمایش داده می‌شود که مدیر صریحاً
	// آن را روشن کرده باشد (enabled='1'). نبودِ تنظیمات، یا هر مقدارِ دیگری جز '1'، یعنی خاموش.
	// (پیش‌تر — v3.22.5 — پیش‌فرض «روشن» بود؛ به‌درخواستِ کاربر به opt-in برگشت تا هیچ فروشگاهی
	// بدونِ انتخابِ خودش باکس نبیند.) مقدارِ خام خوانده می‌شود (نه merge با پیش‌فرض) و این گیت تنها
	// نقطه‌ی ورودِ هر دو مسیرِ enqueue و render (دسکتاپ + موبایل) است، پس خاموشی همه‌جا اعمال می‌شود.
	// اگر بعد از تغییرِ وضعیت باز هم باکس دیده شد، علت کشِ صفحه/CDN است؛ با ذخیره، کشِ داخلی پاک می‌شود.
	$lm_raw     = get_option( 'farazsms_next_lead_magnet_settings', null );
	$lm_enabled = ( is_array( $lm_raw ) && isset( $lm_raw['enabled'] ) ) ? (string) $lm_raw['enabled'] : '0';
	if ( $lm_enabled !== '1' ) {
		return false;
	}

	// v3.22.6 ساده‌سازیِ ریشه‌ای: لید مگنت فقط به بازدیدکنندگانِ مهمان (واردنشده) نمایش داده
	// می‌شود. به هیچ کاربرِ لاگین‌شده — حتی مدیر — نمایش داده نمی‌شود. این کلِ چرخهٔ گیج‌کنندهٔ
	// «پیش‌نمایشِ مدیر + بستنِ همیشگی (dismiss) + کوکیِ استثنا» را حذف می‌کند که منشأ باگِ
	// «فعال کردم ولی نمی‌بینم» بود (مدیر پیش‌نمایش را بسته بود و دیگر نمی‌دید). مدیر برای دیدنِ
	// لید مگنت از حالتِ ناشناس (incognito) یا خروج از حساب استفاده می‌کند — در راهنما نوشته شده.
	if ( is_user_logged_in() ) {
		return false;
	}

	// روی صفحاتِ ورود/ثبت‌نام و «حساب کاربری» نمایش داده نشود — آنجا مزاحم و بی‌مورد است
	// (کاربر دارد همان کاری را می‌کند که لید مگنت تشویقش می‌کند).
	if ( function_exists( 'is_account_page' ) && is_account_page() ) {
		return false;
	}
	if ( function_exists( 'is_singular' ) && is_singular() ) {
		$lm_post = get_post();
		if ( $lm_post ) {
			// صفحه‌ی ورودِ خودِ افزونه (تمپلیتِ اختصاصی).
			if ( get_page_template_slug( $lm_post->ID ) === 'farazsms-login-page.php' ) {
				return false;
			}
			// هر صفحه‌ای که شاملِ شورت‌کدِ فرمِ ورود/ثبت‌نام باشد.
			$lm_content = (string) $lm_post->post_content;
			if ( has_shortcode( $lm_content, 'farazsms_login_form' )
				|| has_shortcode( $lm_content, 'farazsms_login_modal' ) ) {
				return false;
			}
		}
	}

	// v3.22.7 بازنویسیِ کامل: گیتِ تکراریِ enabled و کلِ منطقِ کوکیِ «بستنِ همیشگی» حذف شدند.
	// خاموشی فقط از طریقِ enabled='0'ِ بالا کنترل می‌شود و دیگر هیچ کوکی‌ای مانعِ نمایش نمی‌شود
	// (اگر بازدیدکننده باکس را ببندد، فقط در همان بازدید بسته می‌شود، نه برای همیشه).
	$settings = farazsms_next_get_lead_magnet_settings();
	$loc = isset( $settings['display_location'] ) ? $settings['display_location'] : 'everywhere';

	switch ( $loc ) {
		case 'home':
			return (bool) is_front_page();

		case 'blog':
			// خانه‌ی نوشته‌ها، تکْ‌نوشته، و آرشیوها (دسته/برچسب/تاریخ/نویسنده).
			return (bool) ( is_home() || is_singular( 'post' ) || is_category() || is_tag() || is_archive() );

		case 'specific':
			$ids = array_filter( array_map( 'absint', explode( ',', (string) ( isset( $settings['display_pages'] ) ? $settings['display_pages'] : '' ) ) ) );
			return ! empty( $ids ) && is_page( $ids );

		case 'everywhere':
		default:
			return true;
	}
}

/**
 * AJAX: بستنِ دائمیِ پیش‌نمایشِ مدیر (دکمه‌ی «متوجه شدم»). per-user در user_meta.
 * v3.21.37 — برای اینکه مدیرِ لاگین‌شده هر صفحه باکس را نبیند.
 */
add_action( 'wp_ajax_farazsms_next_dismiss_lm_admin_preview', 'farazsms_next_dismiss_lm_admin_preview' );
function farazsms_next_dismiss_lm_admin_preview() {
	if ( ! current_user_can( 'manage_options' )
		|| ! check_ajax_referer( 'farazsms_next_lm_admin_preview', 'nonce', false ) ) {
		wp_send_json_error( array(), 403 );
	}
	update_user_meta( get_current_user_id(), 'farazsms_lm_admin_preview_dismissed', '1' );
	wp_send_json_success();
}

/**
 * v3.21.96: پاک‌کردنِ همه‌ی کش‌های صفحه + CDN (شاملِ نسخه‌ی موبایلِ جدا). هنگام ذخیره‌ی تنظیماتِ
 * لید مگنت صدا زده می‌شود تا خاموش‌کردن روی سایتِ کش‌دار واقعاً اعمال شود.
 */
function farazsms_next_purge_all_page_caches() {
	// آبجکت‌کش وردپرس
	if ( function_exists( 'wp_cache_flush' ) ) {
		wp_cache_flush();
	}
	// WP Rocket (هم دسکتاپ هم موبایل)
	if ( function_exists( 'rocket_clean_domain' ) ) {
		rocket_clean_domain();
	}
	// LiteSpeed Cache
	if ( has_action( 'litespeed_purge_all' ) ) {
		do_action( 'litespeed_purge_all' );
	}
	// W3 Total Cache
	if ( function_exists( 'w3tc_flush_all' ) ) {
		w3tc_flush_all();
	}
	// WP Super Cache
	if ( function_exists( 'wp_cache_clear_cache' ) ) {
		wp_cache_clear_cache();
	}
	// WP Fastest Cache
	if ( function_exists( 'wpfc_clear_all_cache' ) ) {
		wpfc_clear_all_cache( true );
	}
	// Cache Enabler
	if ( class_exists( 'Cache_Enabler' ) && method_exists( 'Cache_Enabler', 'clear_complete_cache' ) ) {
		Cache_Enabler::clear_complete_cache();
	}
	// Autoptimize
	if ( class_exists( 'autoptimizeCache' ) && method_exists( 'autoptimizeCache', 'clearall' ) ) {
		autoptimizeCache::clearall();
	}
	// هوکِ عمومی برای افزونه‌های دیگر/CDN
	do_action( 'farazsms_lead_magnet_settings_saved' );
}
