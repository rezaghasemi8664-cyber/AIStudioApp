<?php
/**
 * Admin Menu Class
 *
 * Handles the creation of admin menu and pages
 */

if (!defined('ABSPATH')) {
    exit;
}

class FarazSMS_Next_Admin_Menu {

    /**
     * Admin page class instance
     *
     * @var FarazSMS_Next_Admin_Page
     */
    private $admin_page;

    /**
     * Initialize the admin menu
     */
    public function init() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        // v3.22.25 اصلاحِ ریشه‌ایِ «ذخیره نمی‌شود»:
        // هندلرِ ذخیره‌ی فرم باید روی admin_init ثبت شود، ولی قبلاً فقط داخلِ
        // constructorِ Admin_Page ثبت می‌شد و آن شیء تازه هنگامِ رندرِ صفحه ساخته
        // می‌شد (بعد از عبورِ admin_init) — یعنی هندلر هرگز اجرا نمی‌شد و
        // تنظیماتِ پنل/لید مگنت ذخیره نمی‌شد. اینجا زودتر و مطمئن ثبتش می‌کنیم.
        add_action('admin_init', array($this, 'handle_form_submission'), 5);
    }

    /**
     * پلِ ثبتِ زودهنگامِ هندلرِ ذخیره‌ی فرم روی admin_init.
     * Admin_Page را می‌سازد (اگر لازم باشد) و ذخیره را انجام می‌دهد.
     */
    public function handle_form_submission() {
        $this->admin_page()->handle_form_submission();
    }

    private function admin_page() {
        if (!$this->admin_page) {
            $this->admin_page = new FarazSMS_Next_Admin_Page();
        }
        return $this->admin_page;
    }

    /**
     * Add admin menu items as separate submenus
     */
    public function add_admin_menu() {
        // ساخت دفترچه تلفن
        add_submenu_page(
            'farazsms',
            __('باشگاه مشتریان', 'farazsms-next'),
            __('باشگاه مشتریان', 'farazsms-next'),
            'manage_options',
            'farazsms-phonebook',
            array($this, 'render_phonebook_page')
        );
        
        // لید مگنت
        add_submenu_page(
            'farazsms',
            __('لید مگنت', 'farazsms-next'),
            __('لید مگنت', 'farazsms-next'),
            'manage_options',
            'farazsms-lead-magnet',
            array($this, 'render_lead_magnet_page')
        );
        
        // فرم ساز ها (اطلاع‌رسانیِ گرویتی/المنتور — صفحه واحد با دو دکمه و تنظیمات OTP)
        add_submenu_page(
            'farazsms',
            __('فرم ساز ها', 'farazsms-next'),
            __('فرم ساز ها', 'farazsms-next'),
            'manage_options',
            'farazsms-sms-forms',
            array($this, 'render_sms_forms_page')
        );

        // برنامه‌نویسان (مستنداتِ API عمومی) — در نوار کناری، بالای «بازخورد».
        add_submenu_page(
            'farazsms',
            __('برنامه‌نویسان', 'farazsms-next'),
            __('برنامه‌نویسان', 'farazsms-next'),
            'manage_options',
            'farazsms-developers',
            array($this, 'render_developers_page')
        );
    }

    /**
     * Render developers (API docs) page.
     */
    public function render_developers_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'farazsms-next'));
        }
        echo '<div class="wrap" style="margin-top:18px;">';
        $tab_file = FARAZSMS_CORE_INC . 'farazsms-next-tabs/tab-developers.php';
        if (file_exists($tab_file)) {
            include $tab_file;
        }
        echo '</div>';
    }

    /**
     * Render phonebook page
     */
    public function render_phonebook_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'farazsms-next'));
        }

        // Get API key for credit display
        if (function_exists('farazsms_get_apikey')) {
            $apikey = farazsms_get_apikey();
        } else {
            $apikey = get_option('farazsms_apikey', '');
        }

        // v3.17.7: تب‌بندی حذف شد — همه‌ی سه بخش (WC + GF + Custom Meta) در یک صفحه‌ی واحد
        // به ترتیب رندر می‌شوند. WC اول، GF دوم، Custom Meta سوم.
        ?>
        <section class="wrapper">
            <div id="farazsms_header">
                <div>
                    <a href="https://farazsms.com" target="_blank">
                        <img src="<?php echo FARAZSMS_CORE_IMG . 'logo-1.png'; ?>" alt="پنل ارسال اس ام اس – سامانه پیام کوتاه – سامانه ارسال پیامک">
                    </a>
                </div>
                <?php
                if (!empty($apikey)) {
                    $credit = farazsms_get_credit();
                    ?>
                    <div id="farazsms_account_info">
                        <div class="farazsms_credit_amount">
                            <span>میزان اعتبار: </span><?php echo esc_html($credit); ?>
                            <span> تومان</span>
                        </div>
                        <?php farazsms_render_profile_block(); ?>
                    </div>
                    <?php
                }
                ?>
            </div>

            <!-- v3.17.7: همه‌ی بخش‌ها در یک صفحه واحد، با divider بصری بین آن‌ها -->

            <!-- بخش ۱: مشتریان ووکامرس -->
            <div class="farazsms-pb-section">
                <div class="farazsms-pb-section__header">
                    <span class="farazsms-pb-section__icon">🛒</span>
                    <h2 class="farazsms-pb-section__title"><?php esc_html_e('مشتریان ووکامرس', 'farazsms'); ?></h2>
                </div>
                <ul class="tab__content">
                    <li class="active">
                        <div class="content__wrapper">
                            <?php $this->admin_page()->render_tab('phonebook'); ?>
                        </div>
                    </li>
                </ul>
            </div>

            <!-- بخش ۲: سینک Gravity Forms -->
            <div class="farazsms-pb-section">
                <div class="farazsms-pb-section__header">
                    <span class="farazsms-pb-section__icon">📋</span>
                    <h2 class="farazsms-pb-section__title"><?php esc_html_e('فرم‌های Gravity', 'farazsms'); ?></h2>
                </div>
                <?php
                if (function_exists('farazsms_gf_pb_render_content')) {
                    farazsms_gf_pb_render_content();
                } else {
                    echo '<div style="background:#fdeae8; border:1px solid #d52a16; color:#b32817; padding:14px; border-radius:8px;">ماژول سینک فرم در دسترس نیست.</div>';
                }
                ?>
            </div>

            <!-- بخش ۳: فیلد متا اختصاصی -->
            <div class="farazsms-pb-section">
                <div class="farazsms-pb-section__header">
                    <span class="farazsms-pb-section__icon">🔧</span>
                    <h2 class="farazsms-pb-section__title"><?php esc_html_e('سایر افزونه‌ها (فیلد متا اختصاصی)', 'farazsms'); ?></h2>
                </div>
                <?php
                if (function_exists('farazsms_custom_meta_pb_render_content')) {
                    farazsms_custom_meta_pb_render_content();
                } else {
                    echo '<div style="background:#fdeae8; border:1px solid #d52a16; color:#b32817; padding:14px; border-radius:8px;">ماژول فیلد متا اختصاصی در دسترس نیست.</div>';
                }
                ?>
            </div>

            <style>
            .farazsms-pb-section {
                margin-bottom: 32px;
                padding-bottom: 32px;
                border-bottom: 2px dashed #e1e1e1;
            }
            .farazsms-pb-section:last-child {
                border-bottom: 0;
                padding-bottom: 0;
                margin-bottom: 0;
            }
            .farazsms-pb-section__header {
                display: flex;
                align-items: center;
                gap: 12px;
                margin: 0 0 20px;
                padding: 14px 18px;
                background: linear-gradient(135deg, #f5f8fe 0%, #f5f8fe 100%);
                border-right: 4px solid #365891;
                border-radius: 10px;
            }
            .farazsms-pb-section__icon { font-size: 26px; line-height: 1; }
            .farazsms-pb-section__title {
                margin: 0;
                font-size: 17px;
                font-weight: 800;
                color: #263f67;
            }
            </style>
        </section>
        <?php
    }

    /**
     * Render lead magnet page
     */
    public function render_lead_magnet_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'farazsms-next'));
        }

        // Get API key for credit display
        if (function_exists('farazsms_get_apikey')) {
            $apikey = farazsms_get_apikey();
        } else {
            $apikey = get_option('farazsms_apikey', '');
        }
        ?>
        <section class="wrapper">
            <div id="farazsms_header">
                <div>
                    <a href="https://farazsms.com" target="_blank">
                        <img src="<?php echo FARAZSMS_CORE_IMG . 'logo-1.png'; ?>" alt="پنل ارسال اس ام اس – سامانه پیام کوتاه – سامانه ارسال پیامک">
                    </a>
                </div>
                <?php
                if (!empty($apikey)) {
                    $credit = farazsms_get_credit();
                    ?>
                    <div id="farazsms_account_info">
                        <div class="farazsms_credit_amount">
                            <span>میزان اعتبار: </span><?php echo esc_html($credit); ?>
                            <span> تومان</span>
                        </div>
                        <?php farazsms_render_profile_block(); ?>
                    </div>
                    <?php
                }
                ?>
            </div>
            
            <ul class="tabs">
                <li class="active">لید مگنت</li>
            </ul>
            
            <ul class="tab__content">
                <li class="active">
                    <div class="content__wrapper">
                        <?php $this->admin_page()->render_tab('lead-magnet'); ?>
                    </div>
                </li>
            </ul>
        </section>
        <?php
    }

    /**
     * Render SMS Forms page (Gravity / Elementor) with two buttons and OTP settings
     */
    public function render_sms_forms_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'farazsms-next'));
        }
        // v3.14.7 REWRITE: ساختار قدیمی section.wrapper + ul.tabs که با قاب
        // یکپارچه افزونه تداخل داشت، حذف شد. صفحه حالا فقط محتوای اصلی را با
        // ساختار تمیز RTL و کارت‌های مدرن رندر می‌کند — header/credit از قاب
        // یکپارچه می‌آید، نه از این صفحه.

        $elementor_url  = admin_url('admin.php?page=elementor_farazsms');
        $gravity_url    = admin_url('admin.php?page=gf_farazsms');
        $otp_message    = get_option('farazsms_otp_message', 'کد تأیید شما: %code%');
        $otp_pattern    = get_option('farazsms_otp_pattern', '');
        $gf_active      = class_exists('GFForms');
        $elementor_active = did_action('elementor/loaded') || class_exists('\\Elementor\\Plugin');
        // v3.22.166: دو فرم‌سازِ تازه در همین صفحه — تنظیماتشان در صفحه‌ی مشترکِ قانون‌هاست.
        $fb_url          = admin_url('admin.php?page=farazsms-form-builders');
        $wpforms_active  = farazsms_fb_source_active('wpforms');
        $metform_active  = farazsms_fb_source_active('metform');
        // v3.22.168: JetFormBuilder هم به همین صفحه آمد تا برای یک کار سه منو نباشد.
        $jfb_url         = admin_url('admin.php?page=farazsms-jetformbuilder');
        $jfb_active      = farazsms_jfb_is_active();
        // صفحه‌ی قانون‌ها فقط از همین کارت‌ها باز می‌شود. اگر لینک را به فعال‌بودنِ
        // فرم‌ساز گره بزنیم، غیرفعال‌کردنِ موقتِ فرم‌ساز قانون‌های ذخیره‌شده را
        // بی‌درِ‌ورودی می‌کند — نه دیدنی، نه ویرایش‌کردنی، نه پاک‌کردنی.
        $fb_rules        = farazsms_fb_get_rules();
        $fb_has          = function ( $source ) use ( $fb_rules ) {
            foreach ( (array) $fb_rules as $rule ) {
                if ( (string) ( $rule['source'] ?? '' ) === $source ) {
                    return true;
                }
            }
            return false;
        };
        $wpforms_show    = $wpforms_active || $fb_has('wpforms');
        $metform_show    = $metform_active || $fb_has('metform');
        $jfb_rules       = farazsms_jfb_get_rules();
        $jfb_show        = $jfb_active || ! empty( $jfb_rules );
        ?>
        <div style="direction:rtl; font-family:inherit; max-width:980px;">

            <!-- Hero info -->
            <div style="background:linear-gradient(135deg,#eaeff7 0%,#eaeff7 100%); border:1px solid #c1d0e8; border-radius:12px; padding:18px 22px; margin-bottom:20px;">
                <h3 style="margin:0 0 6px; font-size:16px; color:#1b3f7a; font-weight:700;">
                    📝 اطلاع‌رسانی پیامکی فرم‌سازها
                </h3>
                <p style="margin:0; color:#365891; font-size:13px; line-height:1.9;">
                    با ثبت هر فرم در سایت، می‌توانید پیامک اطلاع‌رسانی به <strong>مدیر</strong> و <strong>پرکننده فرم</strong> ارسال کنید — با متن دلخواه یا با پترن. همه‌ی فرم‌سازها از همین یک صفحه مدیریت می‌شوند.
                    همچنین <strong>OTP اعتبارسنجی موبایل</strong> روی فیلدهای فرم برای جلوگیری از اسپم پیاده شده است.
                </p>
            </div>

            <!-- Cards: dispatch to GF / Elementor settings -->
            <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:14px; margin-bottom:22px;">
                <!-- Gravity Forms card -->
                <div style="background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:20px 22px; <?php echo ! $gf_active ? 'opacity:0.65;' : ''; ?>">
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
                        <div style="width:42px; height:42px; background:#faf1da; color:#e2a916; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:22px;">📋</div>
                        <div>
                            <h4 style="margin:0; font-size:14.5px; font-weight:700; color:#263f67;">گرویتی فرم</h4>
                            <?php if ( $gf_active ) : ?>
                                <span style="display:inline-block; background:#e2f8f0; color:#096d49; font-size:10px; padding:2px 7px; border-radius:4px; margin-top:2px;">✓ نصب و فعال</span>
                            <?php else : ?>
                                <span style="display:inline-block; background:#fdeae8; color:#b32817; font-size:10px; padding:2px 7px; border-radius:4px; margin-top:2px;">✗ نصب نیست</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <p style="margin:0 0 14px; font-size:12.5px; color:#4d4d4d; line-height:1.9;">
                        تنظیمات اطلاع‌رسانی پیامکی برای هر فرم گرویتی + ارسال پیامک تکی از sidebar صفحه entry.
                    </p>
                    <?php if ( $gf_active ) : ?>
                        <a href="<?php echo esc_url($gravity_url); ?>" style="display:inline-block; background:#365891; color:#fff; padding:9px 20px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:600;">⚙️ تنظیمات گرویتی فرم</a>
                    <?php else : ?>
                        <a href="<?php echo esc_url( admin_url('plugin-install.php?s=gravity+forms&tab=search') ); ?>" style="display:inline-block; background:#f5f8fe; color:#4d4d4d; padding:9px 20px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:600;">📥 نصب گرویتی فرم</a>
                    <?php endif; ?>
                </div>

                <!-- Elementor card -->
                <div style="background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:20px 22px; <?php echo ! $elementor_active ? 'opacity:0.65;' : ''; ?>">
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
                        <div style="width:42px; height:42px; background:#eaeff7; color:#1b3f7a; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:22px;">🎨</div>
                        <div>
                            <h4 style="margin:0; font-size:14.5px; font-weight:700; color:#263f67;">المنتور فرم</h4>
                            <?php if ( $elementor_active ) : ?>
                                <span style="display:inline-block; background:#e2f8f0; color:#096d49; font-size:10px; padding:2px 7px; border-radius:4px; margin-top:2px;">✓ نصب و فعال</span>
                            <?php else : ?>
                                <span style="display:inline-block; background:#fdeae8; color:#b32817; font-size:10px; padding:2px 7px; border-radius:4px; margin-top:2px;">✗ نصب نیست</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <p style="margin:0 0 14px; font-size:12.5px; color:#4d4d4d; line-height:1.9;">
                        تنظیمات اطلاع‌رسانی پیامکی برای فرم‌های Elementor Pro + امکان ارسال هنگام ثبت فرم.
                    </p>
                    <?php if ( $elementor_active ) : ?>
                        <a href="<?php echo esc_url($elementor_url); ?>" style="display:inline-block; background:#365891; color:#fff; padding:9px 20px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:600;">⚙️ تنظیمات المنتور</a>
                    <?php else : ?>
                        <a href="<?php echo esc_url( admin_url('plugin-install.php?s=elementor&tab=search') ); ?>" style="display:inline-block; background:#f5f8fe; color:#4d4d4d; padding:9px 20px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:600;">📥 نصب المنتور</a>
                    <?php endif; ?>
                </div>
                <!-- WPForms card -->
                <div style="background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:20px 22px; <?php echo ! $wpforms_active ? 'opacity:0.65;' : ''; ?>">
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
                        <div style="width:42px; height:42px; background:#e2f8f0; color:#0c9765; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:22px;">🧩</div>
                        <div>
                            <h4 style="margin:0; font-size:14.5px; font-weight:700; color:#263f67;">WPForms</h4>
                            <?php if ( $wpforms_active ) : ?>
                                <span style="display:inline-block; background:#e2f8f0; color:#096d49; font-size:10px; padding:2px 7px; border-radius:4px; margin-top:2px;">✓ نصب و فعال</span>
                            <?php else : ?>
                                <span style="display:inline-block; background:#fdeae8; color:#b32817; font-size:10px; padding:2px 7px; border-radius:4px; margin-top:2px;">✗ نصب نیست</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <p style="margin:0 0 14px; font-size:12.5px; color:#4d4d4d; line-height:1.9;">
                        قانونِ پیامک برای هر فرمِ WPForms — به پرکنندهٔ فرم و مدیر، با نامِ فیلدهای واقعیِ همان فرم.
                    </p>
                    <?php if ( $wpforms_show ) : ?>
                        <a href="<?php echo esc_url($fb_url); ?>" style="display:inline-block; background:#365891; color:#fff; padding:9px 20px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:600;">⚙️ تنظیمات WPForms</a>
                    <?php else : ?>
                        <a href="<?php echo esc_url( admin_url('plugin-install.php?s=wpforms&tab=search') ); ?>" style="display:inline-block; background:#f5f8fe; color:#4d4d4d; padding:9px 20px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:600;">📥 نصب WPForms</a>
                    <?php endif; ?>
                </div>

                <!-- MetForm card -->
                <div style="background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:20px 22px; <?php echo ! $metform_active ? 'opacity:0.65;' : ''; ?>">
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
                        <div style="width:42px; height:42px; background:#faf1da; color:#e2a916; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:22px;">🧱</div>
                        <div>
                            <h4 style="margin:0; font-size:14.5px; font-weight:700; color:#263f67;">MetForm</h4>
                            <?php if ( $metform_active ) : ?>
                                <span style="display:inline-block; background:#e2f8f0; color:#096d49; font-size:10px; padding:2px 7px; border-radius:4px; margin-top:2px;">✓ نصب و فعال</span>
                            <?php else : ?>
                                <span style="display:inline-block; background:#fdeae8; color:#b32817; font-size:10px; padding:2px 7px; border-radius:4px; margin-top:2px;">✗ نصب نیست</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <p style="margin:0 0 14px; font-size:12.5px; color:#4d4d4d; line-height:1.9;">
                        قانونِ پیامک برای هر فرمِ MetForm — سازگار با فرم‌های ساخته‌شده در المنتور.
                    </p>
                    <?php if ( $metform_show ) : ?>
                        <a href="<?php echo esc_url($fb_url); ?>" style="display:inline-block; background:#365891; color:#fff; padding:9px 20px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:600;">⚙️ تنظیمات MetForm</a>
                    <?php else : ?>
                        <a href="<?php echo esc_url( admin_url('plugin-install.php?s=metform&tab=search') ); ?>" style="display:inline-block; background:#f5f8fe; color:#4d4d4d; padding:9px 20px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:600;">📥 نصب MetForm</a>
                    <?php endif; ?>
                </div>
                <!-- JetFormBuilder card -->
                <div style="background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:20px 22px; <?php echo ! $jfb_active ? 'opacity:0.65;' : ''; ?>">
                    <div style="display:flex; align-items:center; gap:10px; margin-bottom:10px;">
                        <div style="width:42px; height:42px; background:#eaeff7; color:#365891; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:22px;">⚡</div>
                        <div>
                            <h4 style="margin:0; font-size:14.5px; font-weight:700; color:#263f67;">JetFormBuilder</h4>
                            <?php if ( $jfb_active ) : ?>
                                <span style="display:inline-block; background:#e2f8f0; color:#096d49; font-size:10px; padding:2px 7px; border-radius:4px; margin-top:2px;">✓ نصب و فعال</span>
                            <?php else : ?>
                                <span style="display:inline-block; background:#fdeae8; color:#b32817; font-size:10px; padding:2px 7px; border-radius:4px; margin-top:2px;">✗ نصب نیست</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <p style="margin:0 0 14px; font-size:12.5px; color:#4d4d4d; line-height:1.9;">
                        قانونِ پیامک برای هر فرمِ JetFormBuilder — به پرکنندهٔ فرم و مدیر.
                    </p>
                    <?php if ( $jfb_show ) : ?>
                        <a href="<?php echo esc_url($jfb_url); ?>" style="display:inline-block; background:#365891; color:#fff; padding:9px 20px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:600;">⚙️ تنظیمات JetFormBuilder</a>
                    <?php else : ?>
                        <a href="<?php echo esc_url( admin_url('plugin-install.php?s=jetformbuilder&tab=search') ); ?>" style="display:inline-block; background:#f5f8fe; color:#4d4d4d; padding:9px 20px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:600;">📥 نصب JetFormBuilder</a>
                    <?php endif; ?>
                </div>
            </div>



            <!-- OTP Pattern settings -->
            <form id="farazsms_sms_forms_otp_form" style="background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:22px 24px; margin-bottom:18px;">
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:14px;">
                    <div style="width:38px; height:38px; background:#eaeff7; color:#365891; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:18px;">🔐</div>
                    <div>
                        <h4 style="margin:0; font-size:14.5px; font-weight:700; color:#263f67;">پترن پیامک OTP (اعتبارسنجی موبایل در فرم‌ها)</h4>
                        <p style="margin:2px 0 0; font-size:11.5px; color:#9b9b9b;">با این پترن، کد ۶ رقمی برای تأیید موبایل کاربر در فرم‌ها ارسال می‌شود — جلوگیری از اسپم فرم</p>
                    </div>
                </div>

                <?php if ( empty( $otp_pattern ) ) : ?>
                    <div style="background:#fdeae8; border:1px solid #d52a16; color:#b32d2e; border-radius:10px; padding:12px 16px; margin-bottom:16px; font-size:12.5px; line-height:1.9;">
                        ⚠️ <strong>هنوز پترن کد تأیید ساخته نشده است.</strong> تا زمانی که پترن را نسازید و در پنلِ فراز تأیید نشود، پیامکِ کد تأیید در فرم‌های گرویتی‌فرم/المنتور <strong>ارسال نمی‌شود</strong>. متن را بنویسید و دکمه‌ی «ساخت پترن خودکار» را بزنید.
                    </div>
                <?php else : ?>
                    <div style="background:#e2f8f0; border:1px solid #10c282; color:#096d49; border-radius:10px; padding:12px 16px; margin-bottom:16px; font-size:12.5px; line-height:1.9;">
                        ✅ پترن کد تأیید ساخته شده است (<code style="direction:ltr;"><?php echo esc_html( $otp_pattern ); ?></code>). اگر هنوز پیامک ارسال نمی‌شود، مطمئن شوید این پترن در <strong>پنلِ فراز تأیید</strong> شده باشد.
                    </div>
                <?php endif; ?>

                <div style="margin-bottom:14px;">
                    <label for="farazsms_sms_forms_otp_message" style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:6px;">
                        متن پیام پیش‌فرض <span style="color:#d52a16;">*</span>
                    </label>
                    <textarea class="input-field farazsms-comment-message" id="farazsms_sms_forms_otp_message" name="farazsms_otp_message" rows="3" data-section_type="otp" data-status_key="otp" style="width:100%; padding:10px 12px; border:1px solid #e1e1e1; border-radius:8px; font-family:inherit; font-size:13px; line-height:1.9; resize:vertical; direction:rtl; min-height:90px;"><?php echo esc_textarea($otp_message); ?></textarea>
                    <p style="margin:6px 0 0; font-size:11.5px; color:#9b9b9b; line-height:1.8;">
                        متغیر قابل استفاده: <code style="background:#f5f8fe; padding:1px 6px; border-radius:3px;">%code%</code> (کد تأیید ۶ رقمی)
                    </p>
                </div>

                <div style="margin-bottom:14px;">
                    <button type="button" class="farazsms-comment-create-pattern" data-target_pattern="farazsms_sms_forms_otp_pattern" data-target_message="farazsms_sms_forms_otp_message" style="background:#0c9765; color:#fff; border:none; padding:8px 18px; font-size:12.5px; font-weight:600; border-radius:6px; cursor:pointer; font-family:inherit;">
                        ⚡ ساخت پترن خودکار
                    </button>
                    <div class="farazsms-create-pattern-response farazsms-comment-pattern-response" style="display:none; margin-top:10px;"></div>
                </div>

                <div style="margin-bottom:18px;">
                    <label for="farazsms_sms_forms_otp_pattern" style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:6px;">
                        کد پترن OTP <span style="color:#d52a16;">*</span>
                    </label>
                    <input type="text" class="input-field" id="farazsms_sms_forms_otp_pattern" name="farazsms_otp_pattern" value="<?php echo esc_attr($otp_pattern); ?>" style="width:100%; max-width:360px; padding:8px 12px; border:1px solid #e1e1e1; border-radius:6px; font-size:13px; direction:ltr; text-align:left; font-family:monospace;">
                    <p style="margin:4px 0 0; font-size:11px; color:#9b9b9b;">اگر دستی پترن ساخته‌اید، کد آن را اینجا وارد کنید.</p>
                </div>

                <div class="farazsms_save_button_container" style="display:flex; align-items:center; gap:14px;">
                    <button type="submit" id="farazsms_sms_forms_otp_save_button" style="background:#365891; color:#fff; border:none; padding:10px 28px; font-size:13.5px; font-weight:600; border-radius:8px; cursor:pointer; font-family:inherit;">
                        💾 ذخیره
                    </button>
                    <div id="farazsms-sms-forms-otp-response-message" style="display:none;"></div>
                </div>
            </form>

            <!-- v3.22.69: راهنمای فعال‌سازیِ OTP روی یک فرم (رفعِ ابهامِ UX) -->
            <div style="background:#eaeff7; border:1px solid #c1d0e8; border-radius:12px; padding:20px 24px; margin-bottom:18px;">
                <h4 style="margin:0 0 4px; font-size:14.5px; font-weight:700; color:#1b3f7a;">📋 چطور روی یک فرم فعالش کنم؟</h4>
                <p style="margin:0 0 14px; font-size:12.5px; color:#365891; line-height:1.9;">
                    بعد از ساختن و <strong>تأیید‌شدنِ</strong> پترنِ بالا، احرازِ موبایل را روی <strong>هر فرمی که بخواهید</strong> این‌طور روشن می‌کنید (نیازی به تیکِ جداگانه نیست — فقط یک فیلد اضافه می‌کنید):
                </p>
                <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)); gap:14px;">
                    <div style="background:#fff; border:1px solid #eaeff7; border-radius:10px; padding:16px 18px;">
                        <div style="font-weight:700; color:#365891; margin-bottom:8px; font-size:13.5px;">🟪 اگر المنتور دارید (همه‌ی نسخه‌ها — بدونِ تغییرِ دیزاین)</div>
                        <ol style="margin:0; padding-right:18px; font-size:12.5px; color:#4d4d4d; line-height:2;">
                            <li>به منوی <strong>فراز اس ام اس ← پیامکِ فرمِ المنتور</strong> بروید و <strong>فرمِ خود</strong> را انتخاب کنید.</li>
                            <li>از دراپ‌داونِ <strong>«فیلد شماره تلفن»</strong>، فیلدِ موبایلِ همان فرم را انتخاب کنید.</li>
                            <li>تیکِ <strong>«قبل از ثبتِ این فرم، موبایل با کد پیامکی تأیید شود»</strong> را بزنید و ذخیره کنید. تمام!</li>
                        </ol>
                        <p style="margin:8px 0 0; font-size:11px; color:#9b9b9b; line-height:1.8;">کنارِ همان فیلدِ موبایل، دکمه‌ی «ارسال/تأییدِ کد» می‌آید و تا تأیید نشود فرم ثبت نمی‌شود — هم روی مرورگر هم روی سرور. نیازی به کلاسِ CSS یا تغییرِ ظاهرِ فرم نیست.</p>
                    </div>
                    <div style="background:#fff; border:1px solid #eaeff7; border-radius:10px; padding:16px 18px;">
                        <div style="font-weight:700; color:#365891; margin-bottom:8px; font-size:13.5px;">🟩 اگر گرویتی‌فرم دارید</div>
                        <ol style="margin:0; padding-right:18px; font-size:12.5px; color:#4d4d4d; line-height:2;">
                            <li>فرم را در ویرایشگرِ گرویتی‌فرم باز کنید.</li>
                            <li>از فیلدهای «فراز اس ام اس»، فیلدِ «<strong>تأیید موبایل با پیامک</strong>» را به فرم بکشید (به‌جای فیلدِ تلفن).</li>
                            <li>ذخیره کنید. فرم تا تأییدِ کد ثبت نمی‌شود.</li>
                        </ol>
                    </div>
                </div>
                <p style="margin:14px 0 0; font-size:12px; color:#9b9b9b; line-height:1.9;">
                    ✅ کد <strong>همان‌جا زیرِ فیلد</strong> نمایش داده می‌شود؛ کاربر شماره می‌زند → «ارسال کد» → کدِ پیامک‌شده را وارد می‌کند → «تأیید». اگر تأیید نشود، فرم <strong>ارسال نمی‌شود</strong> (تضمینِ شماره‌ی واقعی + جلوگیری از فرمِ اسپم/سرکاری).
                </p>
            </div>

            <!-- v3.22.106: راهنمای کاملِ خودخدمتی — پیش‌نیاز + رفعِ اشکالِ رایج (کاهشِ بارِ پشتیبانی) -->
            <div style="background:#e2f8f0; border:1px solid #10c282; border-radius:12px; padding:20px 24px; margin-bottom:18px;">
                <h4 style="margin:0 0 10px; font-size:14.5px; font-weight:700; color:#14532d;">🚦 پیش‌نیازها — قبل از هر کاری این دو را انجام دهید</h4>
                <ol style="margin:0 0 4px; padding-right:18px; font-size:12.5px; color:#4d4d4d; line-height:2.1;">
                    <li><strong>پترنِ کدِ تأیید را بسازید:</strong> دکمه‌ی «ساخت خودکارِ پترن» را بالا بزنید (یا دستی در پنلِ فراز بسازید و کدش را در فیلدِ «کد پترن OTP» بگذارید).</li>
                    <li><strong>منتظرِ تأییدِ پترن بمانید:</strong> پترن باید توسطِ مدیرِ پنلِ فراز تأیید شود (معمولاً تا حدودِ ۱ ساعت). <u>تا تأیید نشود، پیامکِ کد ارسال نمی‌شود.</u></li>
                    <li><strong>اعتبارِ پنل:</strong> مطمئن شوید حسابتان اعتبارِ کافی برای ارسالِ پیامک دارد.</li>
                </ol>
            </div>

            <div style="background:#fdeae8; border:1px solid #d52a16; border-radius:12px; padding:20px 24px; margin-bottom:18px;">
                <h4 style="margin:0 0 10px; font-size:14.5px; font-weight:700; color:#7f1d1d;">🔧 اگر کار نکرد — رفعِ اشکالِ رایج (بیشترِ مشکلات همین‌جاست)</h4>
                <div style="font-size:12.5px; color:#4d4d4d; line-height:2;">
                    <p style="margin:0 0 8px;"><strong>۱) دکمه‌ی «ارسال کد» کنارِ فیلدِ موبایل ظاهر نمی‌شود:</strong></p>
                    <ul style="margin:0 0 12px; padding-right:20px;">
                        <li>کلاسِ CSS دقیقاً <code dir="ltr" style="background:#f5f8fe;padding:1px 6px;border-radius:4px;">farazsms-otp</code> باشد — همه انگلیسی و کوچک، بدونِ فاصله‌ی اضافه یا نقطه.</li>
                        <li>کلاس روی <strong>خودِ فیلدِ موبایل</strong> باشد، نه روی ستون/باکس/گروه.</li>
                        <li>کشِ سایت و مرورگر را پاک کنید و صفحه را با <strong>Ctrl+Shift+R</strong> باز کنید.</li>
                    </ul>
                    <p style="margin:0 0 8px;"><strong>۲) دکمه هست ولی پیامکِ کد نمی‌رسد:</strong></p>
                    <ul style="margin:0 0 12px; padding-right:20px;">
                        <li>«پترنِ کدِ تأیید» ساخته و در پنلِ فراز <strong>تأیید</strong> شده است؟ (پیش‌نیازِ بالا)</li>
                        <li>اعتبارِ پنل کافی است؟ در داشبورد چک کنید.</li>
                    </ul>
                    <p style="margin:0 0 8px;"><strong>۳) پیامِ «کد اشتباه یا منقضی»:</strong></p>
                    <ul style="margin:0 0 12px; padding-right:20px;">
                        <li>کدِ ۶ رقمیِ تازه را وارد کنید؛ اگر چند دقیقه گذشته، «ارسالِ مجدد» را بزنید.</li>
                    </ul>
                    <p style="margin:0 0 8px;"><strong>۴) فرم بدونِ تأیید هم ارسال می‌شود:</strong></p>
                    <ul style="margin:0; padding-right:20px;">
                        <li>کشِ صفحه/افزونه‌ی کش را پاک کنید (فایلِ جاوااسکریپتِ افزونه باید به‌روز لود شود).</li>
                        <li>مطمئن شوید کلاسِ <code dir="ltr" style="background:#f5f8fe;padding:1px 6px;border-radius:4px;">farazsms-otp</code> واقعاً روی همان فیلدِ موبایلِ داخلِ همان فرم هست.</li>
                    </ul>
                </div>
            </div>

            <!-- Help/Tips -->
            <div style="background:#faf1da; border:1px solid #e2a916; border-radius:10px; padding:14px 18px;">
                <h4 style="margin:0 0 8px; font-size:13px; font-weight:700; color:#83620d;">💡 نکات راهنما</h4>
                <ul style="margin:0; padding-right:18px; font-size:12.5px; color:#83620d; line-height:2;">
                    <li><strong>پترن باید توسط پنل فراز تأیید شود</strong> — معمولاً ۱ تا ۲۴ ساعت طول می‌کشد. تا تأیید نشدن، ارسال OTP کار نمی‌کند.</li>
                    <li><strong>نام برند خود را به‌صورت ثابت در متن پترن بنویسید</strong> — استفاده از متغیر برای نام برند، باعث رد پترن می‌شود.</li>
                    <li><strong>چند شماره ادمین:</strong> در تنظیمات اطلاع‌رسانی هر فرم، می‌توانید چند شماره مدیر را با کاما <code>,</code> جدا کنید — افزونه به هر کدام به‌صورت جداگانه ریکوئست می‌فرستد.</li>
                </ul>
            </div>
        </div>
        <?php
    }

    /**
     * Enqueue admin assets
     *
     * @param string $hook Current admin page hook
     */
    public function enqueue_admin_assets($hook) {
        // Load assets for all new submenus.
        // v3.22.200: تصمیمِ «کدام صفحه» یک نقطه دارد. دو فهرستِ موازی (هوک و
        // اسلاگ) یعنی افزودنِ صفحه‌ی تازه باید در هر دو انجام شود و جاافتادنِ
        // یکی بی‌صدا است.
        if ( ! farazsms_is_any_admin_page( array( 'farazsms-phonebook', 'farazsms-lead-magnet', 'farazsms-sms-forms' ), $hook ) ) {
            return;
        }

        // Enqueue main plugin CSS (same as main settings page)
        wp_enqueue_style(
            'farazsms-settings',
            FARAZSMS_CORE_CSS . 'farazsms-settings.css',
            null,
            '0.0.1',
            'all'
        );

        // Enqueue FarazSMS Next admin CSS
        wp_enqueue_style(
            'farazsms-next-admin-style',
            FARAZSMS_CORE_CSS . 'admin-style.css',
            array('farazsms-settings'),
            defined('FARAZSMS_NEXT_VERSION') ? FARAZSMS_NEXT_VERSION : '1.0.0'
        );

        // Enqueue JavaScript
        wp_enqueue_script(
            'farazsms-next-admin-script',
            FARAZSMS_CORE_JS . 'admin-script.js',
            array('jquery'),
            defined('FARAZSMS_NEXT_VERSION') ? FARAZSMS_NEXT_VERSION : '1.0.0',
            true
        );

        // Localize script for AJAX
        wp_localize_script('farazsms-next-admin-script', 'farazsmsNextPhonebook', array(
            'nonce' => wp_create_nonce('farazsms_next_phonebook_ajax'),
        ));
        
        // Enqueue lead magnet CSS and JS for lead magnet page
        $is_lead_magnet = farazsms_is_admin_page( 'farazsms-lead-magnet', $hook );
        if ($is_lead_magnet) {
            wp_enqueue_style(
                'farazsms-next-lead-magnet-style',
                FARAZSMS_CORE_CSS . 'lead-magnet.css',
                array('farazsms-settings'),
                defined('FARAZSMS_NEXT_VERSION') ? FARAZSMS_NEXT_VERSION : '1.0.0'
            );
            
            wp_enqueue_script(
                'farazsms-next-lead-magnet-script',
                FARAZSMS_CORE_JS . 'lead-magnet.js',
                array('jquery'),
                defined('FARAZSMS_NEXT_VERSION') ? FARAZSMS_NEXT_VERSION : '1.0.0',
                true
            );
        }
    }
}
