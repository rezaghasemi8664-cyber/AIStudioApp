<?php
/**
 * Lead Magnet Box Template
 *
 * Security note: every translatable string is treated as untrusted. Translators
 * MUST NOT be able to inject HTML. We split static markup from translated text
 * and use esc_html_e / esc_html__ for plain strings.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = function_exists( 'farazsms_next_get_lead_magnet_settings' )
	? farazsms_next_get_lead_magnet_settings()
	: get_option( 'farazsms_next_lead_magnet_settings', array() );

$credit_amount    = isset( $settings['credit_amount'] ) ? (int) $settings['credit_amount'] : 0;
$expiry_days      = isset( $settings['expiry_days'] ) ? (int) $settings['expiry_days'] : 0;
$display_position = isset( $settings['display_position'] ) ? sanitize_html_class( $settings['display_position'] ) : 'bottom-right';
$shop_name        = isset( $settings['shop_name'] ) && ! empty( $settings['shop_name'] )
	? (string) $settings['shop_name']
	: (string) get_bloginfo( 'name' );

// v3.17.4: متن‌های قابل تنظیم با placeholder substitution
$badge_text          = isset( $settings['badge_text'] ) ? (string) $settings['badge_text'] : '🔥 فقط امروز';
$title_template      = isset( $settings['title_template'] ) ? (string) $settings['title_template'] : '{amount} تومان هدیه!';
$headline_template   = isset( $settings['headline_template'] ) ? (string) $settings['headline_template'] : 'با عضویت در {shop}، اعتبار رایگان بگیر و اولین خریدت رو ارزون‌تر کن.';
$disclaimer_template = isset( $settings['disclaimer_template'] ) ? (string) $settings['disclaimer_template'] : '⏰ این هدیه فقط {days} روز اعتبار دارد';
$cta_text            = isset( $settings['cta_text'] ) ? (string) $settings['cta_text'] : '🎁 دریافت اعتبار هدیه';

// placeholder rendering: {amount} {shop} {days} — هرکدام در template مربوطه جایگزین می‌شود.
// amount جوری render می‌شود که با span رنگی نمایش داده شود تا highlight داشته باشد.
$title_rendered = strtr( $title_template, array(
	'{amount}' => '<span class="lead-magnet-amount">' . esc_html( number_format_i18n( $credit_amount ) ) . '</span>',
) );
$headline_rendered = strtr( $headline_template, array(
	'{shop}' => '<strong>' . esc_html( $shop_name ) . '</strong>',
) );
$disclaimer_rendered = strtr( $disclaimer_template, array(
	'{days}' => (string) (int) $expiry_days,
) );

$site_domain = wp_parse_url( home_url(), PHP_URL_HOST );
$utm_source  = $site_domain ? rawurlencode( $site_domain ) : '';
$powered_by_url = 'https://farazsms.com/?utm_source=' . $utm_source . '&utm_medium=plugin&utm_campaign=leadmagnet&utm_content=free_plugin';
$mobile_enabled = isset( $settings['mobile_enabled'] ) ? $settings['mobile_enabled'] : '1';
$mobile_style   = isset( $settings['mobile_style'] ) ? $settings['mobile_style'] : 'popup';

// پیش‌نمایشِ مدیر: مدیرِ لاگین‌شده باکس را می‌بیند تا بفهمد باید مقصدِ دکمه را تنظیم کند.
// همان زنجیره‌ی اولویتِ class-frontend.php را برای نمایشِ مقصدِ فعلی بازتاب می‌دهیم.
$is_admin_preview   = is_user_logged_in() && current_user_can( 'manage_options' );
$admin_dest_label   = '';
$admin_dest_is_default = false;
if ( $is_admin_preview ) {
	if ( ! empty( $settings['target_custom_url'] ) ) {
		$admin_dest_label = esc_html__( 'لینکِ سفارشی', 'farazsms-next' );
	} elseif ( ! empty( $settings['target_page_id'] ) && get_post_status( (int) $settings['target_page_id'] ) ) {
		$admin_dest_label = get_the_title( (int) $settings['target_page_id'] );
	} elseif ( function_exists( 'wc_get_page_id' ) && (int) wc_get_page_id( 'myaccount' ) > 0 ) {
		$admin_dest_label = esc_html__( 'حساب کاربری ووکامرس (پیش‌فرضِ خودکار)', 'farazsms-next' );
		$admin_dest_is_default = true;
	} else {
		$admin_dest_label = esc_html__( 'صفحه‌ی ورودِ وردپرس (پیش‌فرضِ خودکار)', 'farazsms-next' );
		$admin_dest_is_default = true;
	}
}
?>

<div class="farazsms-lead-magnet-box" data-position="<?php echo esc_attr( $display_position ); ?>" data-mobile-enabled="<?php echo esc_attr( $mobile_enabled ); ?>" data-mobile-style="<?php echo esc_attr( $mobile_style ); ?>" data-dismiss-days="<?php echo esc_attr( (int) ( $settings['dismiss_days'] ?? 30 ) ); ?>" data-flm-trigger="<?php echo ( isset( $settings['display_trigger'] ) && $settings['display_trigger'] !== 'immediate' ) ? 'pending' : ''; ?>">
	<button class="farazsms-lead-magnet-close" aria-label="<?php esc_attr_e( 'بستن', 'farazsms-next' ); ?>">
		<span class="close-icon">×</span>
	</button>
	<div class="farazsms-lead-magnet-content">
		<?php if ( $is_admin_preview ) : ?>
		<div class="farazsms-lm-admin-preview">
			<span class="farazsms-lm-admin-disable" style="display:block;margin-bottom:6px;"><?php esc_html_e( 'غیرفعال‌سازی از: لید مگنت ← تنظیمات.', 'farazsms-next' ); ?></span>
			<a class="farazsms-lm-admin-link" href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-lead-magnet' ) ); ?>" style="display:inline-block;margin:4px 0;font-weight:700;text-decoration:underline;"><?php esc_html_e( 'رفتن به تنظیماتِ لید مگنت', 'farazsms-next' ); ?> &larr;</a>
			<strong>👁 <?php esc_html_e( 'پیش‌نمایشِ مدیر', 'farazsms-next' ); ?></strong>
			<span><?php esc_html_e( 'این پنجره را فقط شما (مدیر) می‌بینید؛ بازدیدکنندگانِ مهمان نسخه‌ی واقعی را می‌بینند.', 'farazsms-next' ); ?></span>
			<span class="farazsms-lm-admin-dest">
				<?php esc_html_e( 'مقصدِ دکمه‌ی هدیه:', 'farazsms-next' ); ?>
				<b><?php echo esc_html( $admin_dest_label ); ?></b>
			</span>
			<?php if ( $admin_dest_is_default ) : ?>
			<span class="farazsms-lm-admin-tip"><?php esc_html_e( 'برای انتخابِ صفحه‌ی دلخواه، به تنظیماتِ لید مگنت بروید.', 'farazsms-next' ); ?></span>
			<?php endif; ?>
			<button type="button" class="farazsms-lm-admin-dismiss"
				data-ajax="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>"
				data-nonce="<?php echo esc_attr( wp_create_nonce( 'farazsms_next_lm_admin_preview' ) ); ?>"
				style="display:block;margin-top:10px;width:100%;background:#0c9765;color:#fff;border:none;padding:8px 14px;font-size:12.5px;font-weight:700;border-radius:8px;cursor:pointer;">
				<?php esc_html_e( 'متوجه شدم — دیگر این پیش‌نمایش را به من (مدیر) نشان نده', 'farazsms-next' ); ?>
			</button>
			<script>
			(function(){
				var s = document.currentScript;
				var btn = s.parentNode.querySelector('.farazsms-lm-admin-dismiss');
				if (!btn) { return; }
				btn.addEventListener('click', function(){
					var fd = new FormData();
					fd.append('action', 'farazsms_next_dismiss_lm_admin_preview');
					fd.append('nonce', btn.getAttribute('data-nonce'));
					fetch(btn.getAttribute('data-ajax'), { method:'POST', credentials:'same-origin', body: fd });
					var outer = btn.closest('.farazsms-lead-magnet-box');
					if (outer) { outer.style.display = 'none'; }
				});
			})();
			</script>
		</div>
		<?php endif; ?>
		<!-- v3.17.4: تمام متن‌ها از تنظیمات افزونه قابل تنظیم هستند، با
		     placeholder های {amount}، {shop}، {days} -->
		<div class="lead-magnet-badge"><?php echo esc_html( $badge_text ); ?></div>
		<h2 class="lead-magnet-title">
			<?php
			// title_rendered شامل HTML کوچک (span رنگی) است — kses post با whitelist عمومی
			echo wp_kses(
				$title_rendered,
				array( 'span' => array( 'class' => true ), 'strong' => array(), 'br' => array() )
			);
			?>
		</h2>
		<div class="lead-magnet-main-content">
			<div class="lead-magnet-text">
				<p class="lead-magnet-headline">
					<?php
					echo wp_kses(
						$headline_rendered,
						array( 'strong' => array(), 'span' => array( 'class' => true ), 'br' => array() )
					);
					?>
				</p>
				<p class="lead-magnet-disclaimer"><?php echo esc_html( $disclaimer_rendered ); ?></p>
			</div>
			<div class="lead-magnet-countdown-circle">
				<svg class="countdown-svg" viewBox="0 0 100 100">
					<circle class="countdown-circle-bg" cx="50" cy="50" r="45"></circle>
					<circle class="countdown-circle-progress" cx="50" cy="50" r="45"></circle>
				</svg>
				<div class="countdown-time">
					<span class="countdown-seconds">00</span>
					:
					<span class="countdown-minutes">01</span>
				</div>
			</div>
		</div>
		<button class="lead-magnet-cta-button"><?php echo esc_html( $cta_text ); ?></button>
		<?php
		// v3.21.x: «قدرت گرفته از فراز اس‌ام‌اس» — در این نسخه (رایگان) غیرقابلِ‌حذف است.
		// استایل‌های inline با !important جلوی پنهان‌سازی با CSSِ شیت را می‌گیرند (inline-important
		// در آبشارِ CSS بالاترین اولویت را دارد و با هیچ rule شیتی override نمی‌شود). محافظتِ
		// نهایی در برابرِ ویرایشِ خودِ این فایل، با encode شدنِ همین فایل تأمین می‌شود.
		// در نسخه‌ی پرمیومِ آینده، امکانِ حذف اضافه خواهد شد.
		$farazsms_lm_powered_style = 'display:block!important;visibility:visible!important;opacity:1!important;height:auto!important;max-height:none!important;overflow:visible!important;position:static!important;clip:auto!important;clip-path:none!important;transform:none!important;margin-top:10px!important;font-size:11px!important;text-align:center!important;color:#9b9b9b!important;';
		$farazsms_lm_link_style    = 'color:#9b9b9b!important;text-decoration:underline!important;display:inline!important;visibility:visible!important;opacity:1!important;';
		?>
		<div class="lead-magnet-powered" style="<?php echo esc_attr( $farazsms_lm_powered_style ); ?>">
			<?php
			// Static "powered by" link — translators cannot inject HTML because we render
			// the <a> tag from PHP, not from the translation string.
			printf(
				/* translators: %s is the FarazSMS link rendered as HTML */
				esc_html__( 'قدرت گرفته از %s', 'farazsms-next' ),
				'<a href="' . esc_url( $powered_by_url ) . '" target="_blank" rel="noopener" style="' . esc_attr( $farazsms_lm_link_style ) . '">FarazSMS</a>'
			);
			?>
		</div>
	</div>
</div>
