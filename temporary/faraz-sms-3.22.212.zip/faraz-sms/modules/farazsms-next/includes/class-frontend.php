<?php
/**
 * Frontend Class
 *
 * Handles frontend display of lead magnet box
 */

if (!defined('ABSPATH')) {
    exit;
}

class FarazSMS_Next_Frontend {

    /**
     * Constructor
     */
    public function __construct() {
        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_assets'));
        
        // Render lead magnet box in footer
        add_action('wp_footer', array($this, 'render_lead_magnet_box'));
    }

    /**
     * Enqueue frontend assets
     */
    public function enqueue_assets() {
        // محلِ نمایش بر اساسِ تنظیمِ کاربر (همه‌جا/صفحه اصلی/بلاگ/برگه‌های خاص)
        if (!function_exists('farazsms_next_lead_magnet_should_display') || !farazsms_next_lead_magnet_should_display()) {
            return;
        }

        $settings = farazsms_next_get_lead_magnet_settings();

        // Enqueue CSS
        wp_enqueue_style(
            'farazsms-next-lead-magnet',
            FARAZSMS_CORE_CSS . 'lead-magnet.css',
            array(),
            FARAZSMS_NEXT_VERSION
        );

        // Enqueue JavaScript — با وابستگی به موتورِ اورلیِ مشترک (farazsms-overlay) تا از ابزارهای
        // onTrigger/lockScroll آن استفاده کند (زمانِ نمایش T2/T4 + قفلِ اسکرولِ درستِ مودالِ ورود).
        wp_enqueue_script(
            'farazsms-next-lead-magnet',
            FARAZSMS_CORE_JS . 'lead-magnet.js',
            array('jquery', 'farazsms-overlay'),
            FARAZSMS_NEXT_VERSION,
            true
        );

        // Prepare redirect URL for CTA button
        // v3.13.16: chain اولویت‌بندی:
        //   1) صفحه‌ای که کاربر در تنظیمات انتخاب کرده (target_page_id)
        //   2) صفحه my-account ووکامرس (پیش‌فرض جدید — جای ثبت‌نام طبیعی برای فروشگاه)
        //   3) صفحه ورود وردپرس به‌عنوان fallback
        $redirect_url = '';
        // اولویت ۰: لینک سفارشی (اگر مدیر وارد کرده باشد).
        if (!empty($settings['target_custom_url'])) {
            $redirect_url = esc_url_raw($settings['target_custom_url']);
        }
        if (empty($redirect_url) && !empty($settings['target_page_id'])) {
            $target_page_id = absint($settings['target_page_id']);
            $page_link      = get_permalink($target_page_id);
            if ($page_link) {
                $redirect_url = $page_link;
            }
        }

        // Fallback ۲: my-account ووکامرس (اگر ووکامرس فعال است)
        if (empty($redirect_url) && function_exists('wc_get_page_id')) {
            $myaccount_id = (int) wc_get_page_id('myaccount');
            if ($myaccount_id > 0) {
                $myaccount_link = get_permalink($myaccount_id);
                if ($myaccount_link) {
                    $redirect_url = $myaccount_link;
                }
            }
        }

        if (empty($redirect_url)) {
            // Fallback ۳: login/register page
            $redirect_url = wp_login_url(home_url());
        }

        // مبلغ/انقضای هدیه از تنظیماتِ خودِ لید مگنت خوانده می‌شود — همین مقدار هنگام
        // ثبت‌نام به کیف‌پول اضافه می‌شود (farazsms_wallet_registration_gift_config هم از همین
        // تنظیمات می‌خواند)، پس آنچه پاپ‌آپ تبلیغ می‌کند دقیقاً همان اعتباری است که تحویل می‌شود.
        // Localize script with settings
        wp_localize_script('farazsms-next-lead-magnet', 'farazsmsLeadMagnet', array(
            // v3.22.136: زمانِ شمارنده/بسته‌شدنِ خودکار قابلِ تنظیم شد (۰ = بدونِ بسته‌شدن). قبلاً هاردکدِ ۶۰ بود.
            'countdownSeconds' => isset($settings['countdown_seconds']) ? (int) $settings['countdown_seconds'] : 60,
            // v3.22.133 (T2/T4): زمانِ نمایشِ باکس (immediate|delay|scroll) + مقدارش (ثانیه یا درصدِ اسکرول).
            'displayTrigger'      => isset($settings['display_trigger']) ? $settings['display_trigger'] : 'immediate',
            'displayTriggerValue' => isset($settings['display_trigger_value']) ? (int) $settings['display_trigger_value'] : 3,
            'creditAmount'     => isset($settings['credit_amount']) ? $settings['credit_amount'] : '',
            'expiryDays'       => isset($settings['expiry_days']) ? $settings['expiry_days'] : '',
            'displayPosition'  => isset($settings['display_position']) ? $settings['display_position'] : 'bottom-right',
            'redirectUrl'      => $redirect_url,
            'returnToCurrent'  => isset($settings['return_to_current']) ? $settings['return_to_current'] : '1',
            'ctaAction'        => isset($settings['cta_action']) ? $settings['cta_action'] : 'redirect',
            'openInNewTab'     => isset($settings['target_in_new_tab']) ? $settings['target_in_new_tab'] : '0',
            // v3.21.20: در پیش‌نمایشِ مدیر، CTA خنثی می‌شود تا لوپِ رفرش (که قبلاً با
            // نمایش به مدیرِ لاگین‌شده رخ می‌داد) پیش نیاید؛ مدیر از لینکِ یادداشت به تنظیمات می‌رود.
            'isAdminPreview'   => ( is_user_logged_in() && current_user_can('manage_options') ) ? '1' : '0',
        ));
    }

    /**
     * Render lead magnet box
     */
    public function render_lead_magnet_box() {
        // محلِ نمایش بر اساسِ تنظیمِ کاربر (همه‌جا/صفحه اصلی/بلاگ/برگه‌های خاص)
        if (!function_exists('farazsms_next_lead_magnet_should_display') || !farazsms_next_lead_magnet_should_display()) {
            return;
        }

        $settings = farazsms_next_get_lead_magnet_settings();

        // Load template
        $template_path = FARAZSMS_NEXT_PLUGIN_DIR . 'includes/lead-magnet-box.php';
        if (file_exists($template_path)) {
            include $template_path;
        }

        // حالتِ پاپ‌آپ: فرمِ ورود/ثبت‌نامِ خودِ افزونه (نه iframeِ صفحه) را در یک مودال
        // آماده می‌کنیم تا با کلیک روی دکمه باز شود. فقط وقتی شورت‌کدِ ماژولِ ورود/ثبت‌نام
        // در دسترس است کار می‌کند (الزامِ کاربر). در غیرِ این صورت JS به ریدایرکت برمی‌گردد.
        // تریگرِ موبایل (دکمه‌ی چسبانِ پایین یا آیکونِ گوشه). استایلِ موقعیت به‌صورتِ
        // inline روی خودِ المان است (مصون از override و کشِ فایلِ CSS)؛ و رفتارِ
        // media-query (مخفی‌کردنِ باکس تا کلیک، نمایش فقط در موبایل) را هم به‌صورتِ
        // inline در footer چاپ می‌کنیم تا همیشه تازه و قطعی باشد. این بخش حتی در حالتِ
        // popup هم چاپ می‌شود تا «خاموش در موبایل» و «تمام‌عرض» کار کنند.
        $mobile_enabled = isset($settings['mobile_enabled']) ? $settings['mobile_enabled'] : '1';
        $mobile_style   = isset($settings['mobile_style']) ? $settings['mobile_style'] : 'popup';
        ?>
        <style id="flm-mobile-inline">
        /* v3.22.133 (T2/T4): تا شلیکِ تریگر (تأخیر/اسکرول)، باکس پنهان است تا LCPِ اولیه سبک بماند.
           JS پس از شلیک، data-flm-trigger را به "shown" تغییر می‌دهد و باکس ظاهر می‌شود. */
        html body .farazsms-lead-magnet-box[data-flm-trigger="pending"]{display:none!important;}
        @media (max-width:600px){
            html body .farazsms-lead-magnet-box[data-mobile-enabled="0"]{display:none!important;}
            html body .farazsms-lead-magnet-box[data-mobile-style="bar"]:not(.flm-mobile-open),
            html body .farazsms-lead-magnet-box[data-mobile-style="icon"]:not(.flm-mobile-open){display:none!important;}
            html body .flm-mobile-bar{display:flex!important;}
            html body .flm-mobile-icon{display:flex!important;}
            html body .flm-mobile-bar.flm-trigger-hidden,
            html body .flm-mobile-icon.flm-trigger-hidden{display:none!important;}
            html body .farazsms-lead-magnet-box[data-mobile-style="popup"]{left:8px!important;right:8px!important;width:auto!important;max-width:none!important;}
        }
        @media (min-width:601px){
            html body .flm-mobile-bar,html body .flm-mobile-icon{display:none!important;}
        }
        @keyframes flmPulse{0%,100%{transform:scale(1);}50%{transform:scale(1.08);}}
        </style>
        <?php
        if ($mobile_enabled === '1' && in_array($mobile_style, array('bar', 'icon'), true)) {
            $cta = isset($settings['cta_text']) ? (string) $settings['cta_text'] : '🎁 دریافت اعتبار هدیه';
            if ($mobile_style === 'bar') {
                echo '<button type="button" class="flm-mobile-bar" aria-label="' . esc_attr($cta) . '" '
                    . 'style="position:fixed;left:0;right:0;bottom:0;z-index:2147483600;display:none;'
                    . 'align-items:center;justify-content:space-between;gap:12px;'
                    . 'background:linear-gradient(135deg,#0c9765,#0c9765);color:#fff;border:none;'
                    . 'padding:13px 18px;font-size:14px;font-weight:700;font-family:inherit;cursor:pointer;'
                    . 'box-shadow:0 -3px 14px rgba(0,0,0,.18);direction:rtl;">'
                    . '<span class="flm-bar-text">' . esc_html($cta) . '</span>'
                    . '<span class="flm-bar-timer" aria-hidden="true" style="background:rgba(255,255,255,.22);'
                    . 'padding:4px 12px;border-radius:20px;font-size:13px;direction:ltr;min-width:58px;text-align:center;">⏳</span>'
                    . '</button>';
            } else {
                echo '<button type="button" class="flm-mobile-icon" aria-label="' . esc_attr($cta) . '" '
                    . 'style="position:fixed;right:16px;bottom:16px;z-index:2147483600;display:none;'
                    . 'width:58px;height:58px;border-radius:50%;align-items:center;justify-content:center;'
                    . 'background:linear-gradient(135deg,#0c9765,#0c9765);color:#fff;border:none;font-size:26px;'
                    . 'cursor:pointer;box-shadow:0 4px 16px rgba(0,0,0,.25);animation:flmPulse 2s infinite;font-family:inherit;">🎁</button>';
            }
        }

        $cta_action = isset($settings['cta_action']) ? $settings['cta_action'] : 'redirect';
        // v3.21.61: مودالِ ورود فقط برای مهمان معنا دارد. برای کاربرِ واردشده (از جمله
        // پیش‌نمایشِ مدیر) رندر نمی‌شود تا نه کارِ بیهوده‌ی شورت‌کد انجام شود و نه
        // ریدایرکتِ «واردشده→خانه»ی فرمِ ورود تریگر شود (لوپِ رفرشِ خانه).
        if ($cta_action === 'popup' && ! is_user_logged_in() && shortcode_exists('farazsms_login_form')) {
            $form_html = do_shortcode('[farazsms_login_form embedded="1"]');
            if (trim((string) $form_html) !== '') {
                echo '<div id="farazsms-lm-login-modal" class="flm-overlay" style="display:none;" role="dialog" aria-modal="true">'
                    . '<div class="flm-box">'
                    . '<button type="button" class="flm-close" aria-label="بستن">&times;</button>'
                    . '<div class="flm-body">' . $form_html . '</div>'
                    . '</div></div>';
            }
        }
    }
}

