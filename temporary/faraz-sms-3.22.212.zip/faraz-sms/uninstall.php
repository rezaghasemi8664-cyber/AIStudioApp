<?php
/**
 * Uninstall — پاک‌سازیِ کاملِ داده‌ها (فقط در صورتِ انتخابِ صریحِ کاربر).
 *
 * سیاستِ پیش‌فرض (طبقِ readme): داده‌ها پس از حذفِ افزونه **باقی می‌مانند** تا اگر
 * دوباره نصب شد، تنظیمات برنگردد. این فایل فقط وقتی پاک‌سازی می‌کند که کاربر
 * گزینه‌ی «حذفِ کاملِ داده‌ها هنگامِ حذفِ افزونه» را روشن کرده باشد
 * (option: farazsms_purge_on_uninstall = '1').
 *
 * ⚠️ v3.22.186 (کدریویو) — ساختار عوض شد تا **اجرایی** آزموده شود. نسخه‌ی قبل فقط با
 * اسکنِ متنِ همین فایل تست می‌شد و بازبین نشان داد دو تغییرِ ویرانگر از کنارش رد
 * می‌شوند: جابه‌جاییِ یک بند به جدولِ اشتباه، و حذفِ کاملِ فراخوانیِ پاک‌سازی برای
 * سایت‌های تک‌سایته. حالا پیشوندها داده‌اند نه رشته‌ی درون SQL، و تست کوئری‌های
 * واقعیِ تولیدشده را می‌بیند.
 *
 * @package FarazSMS
 */

// فقط از مسیرِ uninstallِ وردپرس اجرا شود.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * پیشوندهایی که **خودِ این افزونه** می‌نویسد.
 *
 * ⚠️ عمداً بسته: optionهایی مثلِ sms_gateway_* یا enable_buyer مالِ افزونه‌های دیگرند.
 * هر افزوده‌ای به این فهرست باید با «کدام فایلِ ما این را می‌نویسد؟» توجیه شود.
 *
 * @return array{options:string[], usermeta:string[], postmeta:string[], transients:string[]}
 */
function farazsms_uninstall_prefixes() {
	// پیشوندهای پایه؛ متاها هم شکلِ بدونِ زیرخط و هم شکلِ زیرخط‌دار دارند
	// (مثلِ _farazsms_journey_*، _farazsms_wallet_gift_received، _fwss_sms_metas).
	$base = array( 'farazsms_', 'wto_', 'fwss_' );

	$meta = array();
	foreach ( $base as $p ) {
		$meta[] = $p;
		$meta[] = '_' . $p;
	}

	return array(
		'options'  => $base,
		'usermeta' => $meta,
		'postmeta' => $meta,
		// farazbin_ فقط ترنزینت دارد (optionهایش زیرِ farazsms_farazbin_* هستند).
		'transients' => array( 'farazsms_', 'wto_', 'fwss_', 'farazbin_' ),
	);
}

/**
 * رویدادهای کرونِ افزونه که باید unschedule شوند.
 *
 * بدونِ این، ورودی‌هایشان در optionِ `cron` می‌مانند و وردپرس تا ابد callbackِ
 * ناموجود صدا می‌زند.
 *
 * @return string[]
 */
function farazsms_uninstall_cron_hooks() {
	return array(
		'farazsms_notify_dispatch',
		'farazsms_autobuild_patterns_event',
		'farazsms_login_security_dispatch',
		'farazsms_send_queue_drain',
		'farazsms_survey_dispatch',
		'farazsms_phonebook_verify_import',
		// دیده‌بانِ سلامتِ ارسال (v3.22.212) — کرونِ ساعتی + رویدادِ ایمیل.
		'farazsms_send_health_check',
		'farazsms_send_health_mail',
		'farazbin_push_cron',
		'farazbin_register_cron',
		'farazbin_backfill_cron',
	);
}

/**
 * ساختِ شرطِ LIKE برای یک ستون از روی فهرستِ پیشوندها.
 *
 * پیشوند با esc_like فرار داده می‌شود، پس `_` در پیشوند به‌عنوانِ wildcard خوانده
 * نمی‌شود. هیچ ورودیِ کاربری اینجا نمی‌آید؛ فهرست ثابت و درون‌کد است.
 *
 * @param string   $column
 * @param string[] $prefixes
 * @return string
 */
function farazsms_uninstall_like_clause( $column, $prefixes ) {
	global $wpdb;

	$parts = array();
	foreach ( $prefixes as $prefix ) {
		$escaped = $wpdb->esc_like( $prefix ) . '%';
		$parts[] = $wpdb->prepare( "{$column} LIKE %s", $escaped );
	}

	return implode( ' OR ', $parts );
}

/**
 * پاک‌سازیِ یک سایت (در multisite برای هر blog فراخوانی می‌شود).
 */
function farazsms_uninstall_purge_site() {
	global $wpdb;

	$prefixes = farazsms_uninstall_prefixes();

	// ۱) جداولِ سفارشی: wp_farazsms_*
	$like   = $wpdb->esc_like( $wpdb->prefix . 'farazsms_' ) . '%';
	$tables = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );
	foreach ( (array) $tables as $table ) {
		// نامِ جدول از SHOW TABLES می‌آید (نه ورودیِ کاربر) → امن برای DROP.
		$wpdb->query( "DROP TABLE IF EXISTS `{$table}`" );
	}

	// ۲) optionها
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE " . farazsms_uninstall_like_clause( 'option_name', $prefixes['options'] ) );

	// ۳) user/post meta — هر دو شکلِ زیرخط‌دار و بدونِ زیرخط.
	$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE " . farazsms_uninstall_like_clause( 'meta_key', $prefixes['usermeta'] ) );
	$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE " . farazsms_uninstall_like_clause( 'meta_key', $prefixes['postmeta'] ) );

	// ۴) transientها (در options؛ هم مقدار و هم timeout).
	$transient_prefixes = array();
	foreach ( $prefixes['transients'] as $prefix ) {
		$transient_prefixes[] = '_transient_' . $prefix;
		$transient_prefixes[] = '_transient_timeout_' . $prefix;
	}
	$wpdb->query( "DELETE FROM {$wpdb->options} WHERE " . farazsms_uninstall_like_clause( 'option_name', $transient_prefixes ) );

	// ۵) رویدادهای کرون.
	//
	// ⚠️ wp_clear_scheduled_hook رویداد را با md5(serialize(args)) پیدا می‌کند،
	// پس رویدادِ **آرگومان‌دار** را بدونِ همان آرگومان‌ها پاک نمی‌کند. سه هوک از
	// این فهرست آرگومان می‌گیرند (اعلان، هشدارِ ورود، و بررسیِ واردسازی) و
	// عملاً از پاک‌سازی جان به‌در می‌بردند — دقیقاً خلافِ چیزی که این بخش
	// می‌گوید انجام می‌دهد. wp_unschedule_hook همه‌ی رویدادهای آن هوک را
	// بی‌اعتنا به آرگومان برمی‌دارد.
	foreach ( farazsms_uninstall_cron_hooks() as $hook ) {
		if ( function_exists( 'wp_unschedule_hook' ) ) {
			wp_unschedule_hook( $hook ); // وردپرس ۴٫۹ به بعد
		} else {
			wp_clear_scheduled_hook( $hook );
		}
	}
}

/**
 * اجرای پاک‌سازی — فقط با انتخابِ صریحِ کاربر.
 *
 * جدا از تعریفِ توابع نگه داشته شده تا تست بتواند فایل را بار کند بدونِ آنکه چیزی
 * اجرا شود (ثابتِ FARAZSMS_UNINSTALL_NO_RUN).
 */
function farazsms_uninstall_run() {
	// پیش‌فرض: داده‌ها را نگه دار.
	if ( get_option( 'farazsms_purge_on_uninstall' ) !== '1' ) {
		return;
	}

	if ( is_multisite() ) {
		$site_ids = get_sites( array( 'fields' => 'ids', 'number' => 0 ) );
		foreach ( (array) $site_ids as $site_id ) {
			switch_to_blog( $site_id );
			farazsms_uninstall_purge_site();
			restore_current_blog();
		}
	} else {
		farazsms_uninstall_purge_site();
	}
}

if ( ! defined( 'FARAZSMS_UNINSTALL_NO_RUN' ) ) {
	farazsms_uninstall_run();
}
