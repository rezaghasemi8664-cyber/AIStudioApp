(function ($) {
	'use strict';

	function initOtpFields() {
		$('.farazsms-elementor-otp').each(function () {
			var $wrap = $(this);
			if ($wrap.data('farazsms-otp-inited')) return;
			$wrap.data('farazsms-otp-inited', true);

			var formId = $wrap.data('form-id') || '';
			if (!formId && $wrap.closest('form').length) {
				formId = $wrap.closest('form').attr('data-elementor-form-id') || $wrap.closest('[data-elementor-id]').attr('data-elementor-id') || '';
			}
			if (!formId) {
				formId = '';
			}

			var $mobile = $wrap.find('.elementor-field-otp-mobile, .farazsms-otp-mobile').first();
			var $sendBtn = $wrap.find('.farazsms-otp-send-btn').first();
			var $msg = $wrap.find('.farazsms-otp-msg').first();
			var $codeRow = $wrap.find('.farazsms-otp-code-row').first();
			var $code = $wrap.find('.farazsms-otp-code').first();
			var $verifyBtn = $wrap.find('.farazsms-otp-verify-btn').first();

			function showMsg(text, isError) {
				$msg.removeClass('farazsms-otp-msg-ok farazsms-otp-msg-err').addClass(isError ? 'farazsms-otp-msg-err' : 'farazsms-otp-msg-ok').text(text).show();
			}

			// v3.22.52: WebOTPِ کامل روی اندروید/کروم (مثلِ فرمِ GF). progressive — روی iOS/فایرفاکس
			// بی‌اثر و کاربر با autocomplete=one-time-code دستی می‌زند.
			var webOtpAc = null;
			function startWebOtp() {
				if (!('OTPCredential' in window) || !navigator.credentials || !navigator.credentials.get || typeof AbortController === 'undefined') return;
				if (webOtpAc) { try { webOtpAc.abort(); } catch (e) {} } // لغوِ درخواستِ قبلی (ارسالِ مجدد)
				var ac = new AbortController();
				webOtpAc = ac;
				$code.one('input', function () { try { ac.abort(); } catch (e) {} });
				navigator.credentials.get({ otp: { transport: ['sms'] }, signal: ac.signal })
					.then(function (otp) {
						if (otp && otp.code) {
							$code.val(otp.code);
							if ($verifyBtn.length) { $verifyBtn.trigger('click'); }
						}
					})
					.catch(function () { /* رد/تایم‌اوت — بی‌اهمیت */ });
			}

			$sendBtn.on('click', function () {
				var mobile = $mobile.val().trim();
				if (!mobile) {
					showMsg(typeof farazsmsElementorOtp !== 'undefined' && farazsmsElementorOtp.strings ? farazsmsElementorOtp.strings.enter_mobile : 'شماره موبایل را وارد کنید.', true);
					return;
				}
				$sendBtn.prop('disabled', true);
				showMsg(typeof farazsmsElementorOtp !== 'undefined' && farazsmsElementorOtp.strings ? farazsmsElementorOtp.strings.sending : 'در حال ارسال کد...', false);
				$.post(typeof farazsmsElementorOtp !== 'undefined' ? farazsmsElementorOtp.ajaxurl : '', {
					action: 'farazsms_otp_send',
					nonce: typeof farazsmsElementorOtp !== 'undefined' ? farazsmsElementorOtp.nonce_send : '',
					mobile: mobile
				}).done(function (r) {
					if (r.success) {
						showMsg(r.data && r.data.message ? r.data.message : (farazsmsElementorOtp && farazsmsElementorOtp.strings ? farazsmsElementorOtp.strings.sent : 'کد تأیید ارسال شد.'), false);
						$codeRow.show();
						$code.val('').focus();
						startWebOtp();
					} else {
						showMsg((r.data && r.data.message) ? r.data.message : (farazsmsElementorOtp && farazsmsElementorOtp.strings ? farazsmsElementorOtp.strings.error : 'خطا'), true);
					}
				}).fail(function () {
					showMsg(farazsmsElementorOtp && farazsmsElementorOtp.strings ? farazsmsElementorOtp.strings.error : 'خطا', true);
				}).always(function () {
					$sendBtn.prop('disabled', false);
				});
			});

			$verifyBtn.on('click', function () {
				var mobile = $mobile.val().trim();
				var code = $code.val().trim();
				if (!mobile || !code) {
					showMsg(farazsmsElementorOtp && farazsmsElementorOtp.strings ? farazsmsElementorOtp.strings.enter_code : 'کد تأیید را وارد کنید.', true);
					return;
				}
				$verifyBtn.prop('disabled', true);
				showMsg(farazsmsElementorOtp && farazsmsElementorOtp.strings ? farazsmsElementorOtp.strings.verifying : 'در حال تأیید...', false);
				$.post(farazsmsElementorOtp.ajaxurl, {
					action: 'farazsms_otp_verify',
					nonce: farazsmsElementorOtp.nonce_verify,
					mobile: mobile,
					code: code,
					context: 'elementor',
					form_id: formId
				}).done(function (r) {
					if (r.success) {
						showMsg(r.data && r.data.message ? r.data.message : (farazsmsElementorOtp.strings ? farazsmsElementorOtp.strings.verified : 'تأیید شد.'), false);
						$wrap.attr('data-otp-verified', '1');
					} else {
						showMsg((r.data && r.data.message) ? r.data.message : (farazsmsElementorOtp.strings ? farazsmsElementorOtp.strings.code_invalid : 'کد اشتباه است.'), true);
					}
				}).fail(function () {
					showMsg(farazsmsElementorOtp.strings ? farazsmsElementorOtp.strings.error : 'خطا', true);
				}).always(function () {
					$verifyBtn.prop('disabled', false);
				});
			});
		});
	}

	// ============================================================================
	// v3.22.105: مسیرِ «universal» — مستقلِ نسخه/نوعِ فرمِ المنتور (کلاسیک یا Atomic).
	// کاربر فقط کلاسِ CSSِ farazsms-otp را روی فیلدِ موبایلِ فرمش می‌گذارد؛ اینجا کنارِ آن فیلد
	// UIِ «ارسال/تأییدِ کد» تزریق می‌شود و تا تأییدِ کد، فرم submit نمی‌شود. چون به DOMِ رندرشده
	// می‌چسبد نه به API داخلیِ فرم، روی المنتور ۴ (که ثبتِ فیلدِ سفارشی را شکست) هم کار می‌کند.
	// ============================================================================
	function txt(key, fallback) {
		return (typeof farazsmsElementorOtp !== 'undefined' && farazsmsElementorOtp.strings && farazsmsElementorOtp.strings[key]) ? farazsmsElementorOtp.strings[key] : fallback;
	}
	function attachOtp($mobile) {
			if ($mobile.data('farazsms-otp-inited')) return;
			$mobile.data('farazsms-otp-inited', true);

			var $form = $mobile.closest('form');
			var formId = ($form.attr('data-elementor-form-id') || $mobile.closest('[data-elementor-id]').attr('data-elementor-id') || 'lm') + '';

			// UIِ تزریقی (وضعیتِ تأیید روی همین بلاک نگهداری می‌شود).
			var $ui = $(
				'<div class="farazsms-elementor-otp farazsms-otp-modern" data-otp-marked="1" style="margin-top:8px;">' +
					'<div class="farazsms-otp-row">' +
						'<button type="button" class="elementor-button farazsms-otp-send-btn">ارسال کد تأیید</button>' +
					'</div>' +
					'<div class="farazsms-otp-msg" role="alert"></div>' +
					'<div class="farazsms-otp-code-row" style="display:none;">' +
						'<input type="text" inputmode="numeric" pattern="[0-9]*" maxlength="6" class="elementor-field-textual farazsms-otp-code" placeholder="کد ۶ رقمی" autocomplete="one-time-code" dir="ltr">' +
						'<button type="button" class="elementor-button farazsms-otp-verify-btn">✓ تأیید کد</button>' +
					'</div>' +
				'</div>'
			);
			// بعد از field-groupِ موبایل (یا خودِ فیلد) تزریق شود.
			var $group = $mobile.closest('.elementor-field-group');
			($group.length ? $group : $mobile).after($ui);

			var $sendBtn = $ui.find('.farazsms-otp-send-btn');
			var $msg = $ui.find('.farazsms-otp-msg');
			var $codeRow = $ui.find('.farazsms-otp-code-row');
			var $code = $ui.find('.farazsms-otp-code');
			var $verifyBtn = $ui.find('.farazsms-otp-verify-btn');

			function showMsg(text, isError) {
				$msg.css('color', isError ? '#b91c1c' : '#15803d').text(text).show();
			}
			function isVerifiedFor(m) {
				return $ui.attr('data-otp-verified') === '1' && $ui.attr('data-otp-mobile') === m;
			}

			$sendBtn.on('click', function () {
				var mobile = ($mobile.val() || '').trim();
				if (!mobile) { showMsg(txt('enter_mobile', 'شماره موبایل را وارد کنید.'), true); return; }
				$sendBtn.prop('disabled', true);
				showMsg(txt('sending', 'در حال ارسال کد...'), false);
				$.post(farazsmsElementorOtp.ajaxurl, { action: 'farazsms_otp_send', nonce: farazsmsElementorOtp.nonce_send, mobile: mobile })
					.done(function (r) {
						if (r && r.success) {
							showMsg((r.data && r.data.message) ? r.data.message : txt('sent', 'کد تأیید ارسال شد.'), false);
							$codeRow.show(); $code.val('').focus();
						} else {
							showMsg((r && r.data && r.data.message) ? r.data.message : txt('error', 'خطا'), true);
						}
					})
					.fail(function () { showMsg(txt('error', 'خطا'), true); })
					.always(function () { $sendBtn.prop('disabled', false); });
			});

			$verifyBtn.on('click', function () {
				var mobile = ($mobile.val() || '').trim();
				var code = ($code.val() || '').trim();
				if (!mobile || !code) { showMsg(txt('enter_code', 'کد تأیید را وارد کنید.'), true); return; }
				$verifyBtn.prop('disabled', true);
				showMsg(txt('verifying', 'در حال تأیید...'), false);
				$.post(farazsmsElementorOtp.ajaxurl, { action: 'farazsms_otp_verify', nonce: farazsmsElementorOtp.nonce_verify, mobile: mobile, code: code, context: 'elementor', form_id: formId })
					.done(function (r) {
						if (r && r.success) {
							showMsg((r.data && r.data.message) ? r.data.message : txt('verified', 'شماره موبایل تأیید شد.'), false);
							$ui.attr('data-otp-verified', '1').attr('data-otp-mobile', mobile);
							$mobile.prop('readonly', true);
						} else {
							showMsg((r && r.data && r.data.message) ? r.data.message : txt('code_invalid', 'کد اشتباه است.'), true);
						}
					})
					.fail(function () { showMsg(txt('error', 'خطا'), true); })
					.always(function () { $verifyBtn.prop('disabled', false); });
			});

			// اگر کاربر بعد از تأیید شماره را عوض کرد، تأیید باطل شود.
			$mobile.on('input', function () {
				if ($ui.attr('data-otp-verified') === '1' && ($mobile.val() || '').trim() !== $ui.attr('data-otp-mobile')) {
					$ui.removeAttr('data-otp-verified').removeAttr('data-otp-mobile');
					$mobile.prop('readonly', false);
				}
			});

			// گِیتِ ارسال: دکمه‌ی submitِ فرم تا تأیید بلاک شود (capture تا پیش از هندلرِ المنتور اجرا شود).
			if ($form.length && !$form.data('farazsms-otp-gate')) {
				$form.data('farazsms-otp-gate', true);
				var formEl = $form.get(0);
				formEl.addEventListener('click', function (e) {
					var btn = e.target.closest('button[type="submit"], .elementor-button[type="submit"]');
					if (!btn) return;
					var mobileVal = ($mobile.val() || '').trim();
					if (!isVerifiedFor(mobileVal)) {
						e.preventDefault();
						e.stopImmediatePropagation();
						showMsg(txt('enter_code', 'برای ارسالِ فرم، ابتدا شماره موبایل را تأیید کنید.'), true);
						if (!$codeRow.is(':visible')) { $sendBtn.trigger('click'); }
					}
				}, true);
			}
	}

	// مسیرِ ۱: فیلدِ دارای کلاسِ farazsms-otp (روشِ دستی).
	function initMarkedOtpFields() {
		$('input.farazsms-otp').each(function () { attachOtp($(this)); });
	}

	// مسیرِ ۲ (اصولی): فیلدهایی که در تنظیماتِ فرمِ المنتور به‌عنوان «فیلد شماره تلفن» + تیکِ OTP
	// انتخاب شده‌اند. سرور آیدیِ آن فیلدها را localize کرده؛ اینجا فقط فیلدِ متناظر را می‌یابیم.
	function initConfigOtpFields() {
		var reqd = (typeof farazsmsElementorOtp !== 'undefined' && farazsmsElementorOtp.requiredFields) ? farazsmsElementorOtp.requiredFields : [];
		if (!reqd || !reqd.length) return;
		reqd.forEach(function (fid) {
			if (!fid) return;
			$('input[name="form_fields[' + fid + ']"], #form-field-' + fid).each(function () { attachOtp($(this)); });
		});
	}

	function initAll() { initOtpFields(); initMarkedOtpFields(); initConfigOtpFields(); }

	$(document).ready(initAll);
	$(window).on('elementor/frontend/init', function () {
		if (typeof elementorFrontend !== 'undefined' && elementorFrontend.hooks) {
			elementorFrontend.hooks.addAction('frontend/element_ready/form.default', function () {
				setTimeout(initAll, 100);
			});
		}
	});
})(jQuery);
