/**
 * ویزاردِ شروع — تعاملات (وانیلا + jQuery موجود).
 * بارگیریِ خطوط تنبل است (AJAX پس از کلیک، نه روی render) — طبقِ قانونِ no-block.
 */
(function ($) {
	'use strict';
	if (typeof farazsmsOnboard === 'undefined') { return; }
	var C = farazsmsOnboard;
	var linesLoaded = false;

	function post(action, nonce, data, cb) {
		var payload = $.extend({ action: action, nonce: nonce }, data || {});
		$.post(C.ajaxUrl, payload).done(cb).fail(function () {
			cb({ success: false, data: { message: C.i18n.error } });
		});
	}

	// — خطِ ارسال: باز/بسته کردنِ کشویی + بارگیریِ تنبلِ خطوط —
	$(document).on('click', '#farazsms-onb-sender-btn', function () {
		var box = $('#farazsms-onb-sender-box');
		box.prop('hidden', false);
		$(this).hide();
		if (linesLoaded) { return; }
		var sel = $('#farazsms-onb-sender-select');
		post(C.linesAction, C.linesNonce, {}, function (res) {
			if (res && res.success && res.data && res.data.lines && res.data.lines.length) {
				sel.empty();
				$.each(res.data.lines, function (i, ln) {
					var num = ln.number || ln;
					var title = ln.title || num;
					var label = (title === num) ? num : (title + ' — ' + num);
					sel.append($('<option>').val(num).text(label));
				});
				// پیش‌فرض: خطِ تعیین‌شده
				if (sel.find('option[value="' + C.defaultLine + '"]').length) {
					sel.val(C.defaultLine);
				}
				linesLoaded = true;
			} else {
				// fallback: فیلدِ متنی با پیش‌فرض
				sel.replaceWith('<input id="farazsms-onb-sender-select" class="farazsms-onb-select" type="text" value="' + C.defaultLine + '">');
			}
		});
	});

	// — ذخیره‌ی خط —
	$(document).on('click', '#farazsms-onb-sender-save', function () {
		var line = $('#farazsms-onb-sender-select').val();
		var msg = $('#farazsms-onb-sender-msg');
		if (!line) { msg.css('color', '#dc2626').text(C.i18n.error); return; }
		var btn = $(this).prop('disabled', true);
		post(C.saveAction, C.saveNonce, { line: line }, function (res) {
			btn.prop('disabled', false);
			if (res && res.success) {
				msg.css('color', '#16a34a').text(C.i18n.saved);
				setTimeout(function () { window.location.reload(); }, 700);
			} else {
				msg.css('color', '#dc2626').text((res && res.data && res.data.message) || C.i18n.error);
			}
		});
	});

	// — بستن (رد) —
	$(document).on('click', '#farazsms-onb-dismiss', function () {
		$('#farazsms-onb-card-host').prop('hidden', true);
		post(C.dismissAction, C.saveNonce, { state: 'dismiss' }, function () {});
		// نمایشِ pillِ بازگشت بدونِ reload
		if (!$('#farazsms-onb-relaunch').length) {
			$('<div class="farazsms-onb-relaunch"><button type="button" class="farazsms-onb-pill" id="farazsms-onb-relaunch">💡 راهنمای شروع</button></div>')
				.insertBefore('#farazsms-onb-card-host');
		} else {
			$('#farazsms-onb-relaunch').closest('.farazsms-onb-relaunch').show();
		}
	});

	// — بازکردنِ دوباره —
	$(document).on('click', '#farazsms-onb-relaunch', function () {
		$(this).closest('.farazsms-onb-relaunch').hide();
		$('#farazsms-onb-card-host').prop('hidden', false);
		post(C.dismissAction, C.saveNonce, { state: 'reopen' }, function () {});
	});

})(jQuery);
