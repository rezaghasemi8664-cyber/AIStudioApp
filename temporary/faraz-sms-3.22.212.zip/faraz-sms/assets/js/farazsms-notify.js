/**
 * «موجود شد خبرم کن» — منطقِ دکمه + فرم (باز/بسته، ارسالِ AJAX، پشتیبانیِ محصولِ متغیر).
 * v3.22.140: از inline به فایلِ enqueue‌شده منتقل شد تا کش‌پلاگین‌ها آن را حذف نکنند
 * (ریشه‌ی «دکمه در فرانت باز نمی‌شود»). event-delegation روی document، پس هر تعداد دکمه در
 * هر ترتیبی (حتی دکمه‌های بعد از اجرای اسکریپت، مثلِ شورت‌کدِ پایینِ صفحه) کار می‌کند.
 */
(function () {
	function persianToAscii(str) {
		var p = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
		var a = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
		for (var i = 0; i < p.length; i++) { str = str.split(p[i]).join(a[i]); }
		return str;
	}

	document.addEventListener('click', function (e) {
		var t = e.target;
		if (!t || !t.closest) { return; }

		var btn = t.closest('.farazsms-notify-button');
		if (btn) {
			var wrapB = btn.closest('.farazsms-notify-wrapper'); if (!wrapB) { return; }
			var formB = wrapB.querySelector('.farazsms-notify-form');
			var inpB = wrapB.querySelector('input[name="mobile"]');
			if (!formB) { return; }
			if (formB.hasAttribute('hidden')) { formB.removeAttribute('hidden'); btn.setAttribute('aria-expanded', 'true'); inpB && inpB.focus(); }
			else { formB.setAttribute('hidden', ''); btn.setAttribute('aria-expanded', 'false'); }
			return;
		}

		var sub = t.closest('.farazsms-notify-submit');
		if (sub) {
			var wrap = sub.closest('.farazsms-notify-wrapper'); if (!wrap) { return; }
			var msg = wrap.querySelector('.farazsms-notify-message');
			var inp = wrap.querySelector('input[name="mobile"]');
			var vinp = wrap.querySelector('input[name="variation_id"]');
			var btn2 = wrap.querySelector('.farazsms-notify-button');
			var form = wrap.querySelector('.farazsms-notify-form');
			var mobile = persianToAscii((inp && inp.value) || '').replace(/\D+/g, '');
			if (!/^0?9\d{9}$/.test(mobile)) {
				if (msg) { msg.className = 'farazsms-notify-message error'; msg.textContent = 'شماره موبایل معتبر نیست.'; }
				return;
			}
			var data = new FormData();
			data.append('action', 'farazsms_notify_subscribe');
			data.append('nonce', wrap.dataset.nonce);
			data.append('product_id', wrap.dataset.productId);
			data.append('variation_id', (vinp && vinp.value) || '0');
			data.append('mobile', mobile);
			sub.disabled = true;
			var oldText = sub.textContent;
			sub.textContent = 'در حال ثبت...';
			fetch(wrap.dataset.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data })
				.then(function (r) { return r.json(); })
				.then(function (json) {
					if (json.success) {
						if (msg) { msg.className = 'farazsms-notify-message success'; msg.textContent = (json.data && json.data.message) || 'انجام شد.'; }
						if (btn2) {
							var labelEl = btn2.querySelector('.farazsms-notify-button-text');
							if (labelEl) labelEl.textContent = wrap.dataset.successText || 'ثبت شد ✓';
							btn2.classList.add('is-success'); btn2.disabled = true;
						}
						if (form) setTimeout(function () { form.setAttribute('hidden', ''); btn2 && btn2.setAttribute('aria-expanded', 'false'); }, 2000);
					} else {
						if (msg) { msg.className = 'farazsms-notify-message error'; msg.textContent = (json.data && json.data.message) || 'خطا.'; }
					}
				})
				.catch(function () { if (msg) { msg.className = 'farazsms-notify-message error'; msg.textContent = 'خطا در ارتباط با سرور.'; } })
				.then(function () { sub.disabled = false; sub.textContent = oldText; });
			return;
		}
	});

	// پشتیبانیِ محصولِ متغیر — فقط wrapperهای همین محصول به‌روز شوند، و wrapperهای persist هرگز مخفی نشوند.
	if (window.jQuery) {
		jQuery(function ($) {
			function wrapsFor(form) {
				var pid = $(form).data('product_id');
				var all = document.querySelectorAll('.farazsms-notify-wrapper');
				if (!pid) return all;
				return Array.prototype.filter.call(all, function (w) {
					return String(w.getAttribute('data-product-id')) === String(pid);
				});
			}
			$(document).on('found_variation', '.variations_form', function (ev, variation) {
				Array.prototype.forEach.call(wrapsFor(this), function (wrap) {
					if (wrap.getAttribute('data-notify-persist') === '1') return;
					var vinp = wrap.querySelector('input[name="variation_id"]');
					if (vinp) vinp.value = (variation && variation.variation_id) || 0;
					wrap.style.display = (variation && variation.is_in_stock === false) ? '' : 'none';
				});
			}).on('reset_data', '.variations_form', function () {
				Array.prototype.forEach.call(wrapsFor(this), function (wrap) {
					if (wrap.getAttribute('data-notify-persist') === '1') return;
					wrap.style.display = 'none';
				});
			});
		});
	}
})();
