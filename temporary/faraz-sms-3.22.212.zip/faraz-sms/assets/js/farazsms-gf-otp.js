(function ($) {
	'use strict';

	function initOtpFields() {
		$('.farazsms-gf-otp').each(function () {
			var $wrap = $(this);
			if ($wrap.data('farazsms-otp-inited')) return;
			$wrap.data('farazsms-otp-inited', true);

			var formId = $wrap.data('form-id');
			var $mobile = $wrap.find('.farazsms-otp-mobile');
			var $sendBtn = $wrap.find('.farazsms-otp-send-btn');
			var $msg = $wrap.find('.farazsms-otp-msg');
			var $codeRow = $wrap.find('.farazsms-otp-code-row');
			var $code = $wrap.find('.farazsms-otp-code');
			var $verifyBtn = $wrap.find('.farazsms-otp-verify-btn');

			function showMsg(text, isError) {
				$msg.removeClass('farazsms-otp-msg-ok farazsms-otp-msg-err').addClass(isError ? 'farazsms-otp-msg-err' : 'farazsms-otp-msg-ok').text(text).show();
			}

			// v3.22.52: WebOTPِ کامل روی اندروید/کروم — بعد از ارسالِ کد، خودکار از پیامک بخوان و پر
			// کن (پیش‌نیاز: HTTPS + خطِ پایانیِ «@دامنه #کد» در پترن که خودکار اضافه می‌شود). روی
			// iOS/فایرفاکس بی‌اثر است (progressive) و کاربر با autocomplete=one-time-code دستی می‌زند.
			var webOtpAc = null;
			function startWebOtp() {
				if (!('OTPCredential' in window) || !navigator.credentials || !navigator.credentials.get || typeof AbortController === 'undefined') return;
				if (webOtpAc) { try { webOtpAc.abort(); } catch (e) {} } // لغوِ درخواستِ قبلی (ارسالِ مجدد)
				var ac = new AbortController();
				webOtpAc = ac;
				$code.one('input', function () { try { ac.abort(); } catch (e) {} });
				navigator.credentials.get({ otp: { transport: ['sms'] }, signal: ac.signal })
					.then(function (otp) {
						if (otp && otp.code) {
							$code.val(otp.code);
							if ($verifyBtn.length) { $verifyBtn.trigger('click'); }
						}
					})
					.catch(function () { /* رد/تایم‌اوت — بی‌اهمیت */ });
			}

			$sendBtn.on('click', function () {
				var mobile = $mobile.val().trim();
				if (!mobile) {
					showMsg(farazsmsGfOtp.strings.enter_mobile, true);
					return;
				}
				$sendBtn.prop('disabled', true);
				showMsg(farazsmsGfOtp.strings.sending, false);
				$.post(farazsmsGfOtp.ajaxurl, {
					action: 'farazsms_otp_send',
					nonce: farazsmsGfOtp.nonce_send,
					mobile: mobile
				}).done(function (r) {
					if (r.success) {
						showMsg(r.data && r.data.message ? r.data.message : farazsmsGfOtp.strings.sent, false);
						$codeRow.show();
						$code.val('').focus();
						startWebOtp();
					} else {
						showMsg((r.data && r.data.message) ? r.data.message : farazsmsGfOtp.strings.error, true);
					}
				}).fail(function () {
					showMsg(farazsmsGfOtp.strings.error, true);
				}).always(function () {
					$sendBtn.prop('disabled', false);
				});
			});

			$verifyBtn.on('click', function () {
				var mobile = $mobile.val().trim();
				var code = $code.val().trim();
				if (!mobile || !code) {
					showMsg(farazsmsGfOtp.strings.enter_code, true);
					return;
				}
				$verifyBtn.prop('disabled', true);
				showMsg(farazsmsGfOtp.strings.verifying, false);
				$.post(farazsmsGfOtp.ajaxurl, {
					action: 'farazsms_otp_verify',
					nonce: farazsmsGfOtp.nonce_verify,
					mobile: mobile,
					code: code,
					context: 'gf',
					form_id: formId
				}).done(function (r) {
					if (r.success) {
						showMsg(r.data && r.data.message ? r.data.message : farazsmsGfOtp.strings.verified, false);
						$wrap.attr('data-otp-verified', '1');
					} else {
						showMsg((r.data && r.data.message) ? r.data.message : farazsmsGfOtp.strings.code_invalid, true);
					}
				}).fail(function () {
					showMsg(farazsmsGfOtp.strings.error, true);
				}).always(function () {
					$verifyBtn.prop('disabled', false);
				});
			});
		});
	}

	$(document).ready(initOtpFields);
	$(document).on('gform_post_render', initOtpFields);
})(jQuery);
