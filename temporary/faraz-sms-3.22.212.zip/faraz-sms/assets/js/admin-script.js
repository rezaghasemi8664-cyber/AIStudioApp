/**
 * FarazSMS Next Admin Scripts
 */

jQuery(document).ready(function($) {
    "use strict";

    var clickedTab = $(".tabs > .active");
    var tabWrapper = $(".tab__content");
    var activeTab = tabWrapper.find(".active");
    var activeTabHeight = activeTab.outerHeight();
    
    // Show tab on page load
    activeTab.show();
    
    // Set height of wrapper on page load
    tabWrapper.height(activeTabHeight);
    
    $(".tabs > li").on("click", function() {
        $(".tabs > li").removeClass("active");
        $(this).addClass("active");
        clickedTab = $(".tabs .active");
        activeTab.fadeOut(150, function() {
            $(".tab__content > li").removeClass("active");
            var clickedTabIndex = clickedTab.index();
            $(".tab__content > li").eq(clickedTabIndex).addClass("active");
            activeTab = $(".tab__content > .active");
            activeTabHeight = activeTab.outerHeight();
            tabWrapper.stop().delay(10).animate({
                height: activeTabHeight
            }, 200, function() {
                activeTab.delay(10).fadeIn(150);
            });
        });
        
        // Update URL without page reload
        var tabId = $(this).data('tab');
        if (tabId) {
            var url = new URL(window.location.href);
            url.searchParams.set('tab', tabId);
            window.history.pushState({}, '', url);
        }
    });
    
    // واردسازیِ دفترچه‌ی مشتریان — دسته‌ای (بدونِ تایم‌اوت).
    // فاز ۱: prepare (ساخت/یافتنِ دفترچه + شمارشِ کاربران). فاز ۲: حلقه‌ی process_batch
    // تا done=true. هر درخواست کوچک است، پس روی فروشگاهِ پرمشتری هم 502/504 نمی‌گیرد.
    function ajaxErrorDetail(jqXHR, textStatus) {
        if (textStatus === 'timeout') {
            return ' (زمانِ پاسخ‌گویی سرور به پایان رسید؛ کمی بعد دوباره تلاش کنید.)';
        }
        if (jqXHR && jqXHR.status) {
            return ' (کدِ خطا: ' + jqXHR.status + ')';
        }
        return '';
    }

    // توکنِ اجرای جاری — سرور با آن حلقه‌ی یتیمِ تبِ قدیمی را رد می‌کند.
    var phonebookRunToken = '';

    /**
     * به سرور بگو این حلقه دیگر زنده نیست.
     *
     * بدونِ این، رکورد تا مهلتِ رهاشدگی «در جریان» می‌ماند: صفحه ادعا می‌کند
     * کاری در جریان است که مرده، و برچسبِ دکمه «ادامه» نمی‌شود — یعنی همان
     * حالتِ گیرکرده‌ای که این تیکت برایش باز شد، فقط با تایمرِ کوتاه‌تر.
     */
    function releasePhonebookRun() {
        if (!phonebookRunToken) { return; }
        $.post(ajaxurl, {
            action: 'farazsms_next_phonebook_stop',
            nonce: farazsmsNextPhonebook.nonce
        });
        phonebookRunToken = '';
    }

    function showPhonebookError($button, $responseDiv, msg) {
        $button.prop('disabled', false).removeClass('fwss_button--loading');
        $('#farazsms-stop-phonebook-btn').hide();
        releasePhonebookRun();
        // ⚠️ متن، نه HTML: بخشی از این پیام از پاسخِ سرورِ پنل می‌آید و
        // درج‌کردنش به‌صورتِ HTML یعنی هر مارک‌آپی که آن سمت برگردد در
        // پیشخوانِ مدیر اجرا می‌شود.
        $responseDiv.empty().append($('<p/>').text(msg))
            .addClass('fwss-error-message')
            .removeClass('fwss-success-message')
            .show();
    }

    function handlePhonebookAction($button, $responseDiv) {
        $button.prop('disabled', true).addClass('fwss_button--loading');
        $responseDiv.empty().hide();

        // فاز ۱ — آماده‌سازی.
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            dataType: 'json',
            timeout: 120000,
            data: {
                action: 'farazsms_next_phonebook_prepare',
                nonce: farazsmsNextPhonebook.nonce
            }
        }).done(function(response) {
            if (!response || !response.success) {
                showPhonebookError($button, $responseDiv, (response && response.data && response.data.message) || 'خطای ناشناخته در آماده‌سازی.');
                return;
            }
            var d = response.data || {};
            // شمارنده‌ها از سرور می‌آیند، نه از صفر: اگر اجرای قبلی ناتمام مانده
            // باشد، سرور همان‌جا را می‌گوید و کار از صفر تکرار نمی‌شود.
            // شمارنده‌های «رد شد» هم از سرور می‌آیند: در اجرای ازسرگرفته‌شده،
            // صفر گرفتنشان گزارشِ پایانی را ناهماهنگ می‌کرد (به‌صف‌رفته انباشته،
            // بدونِ شماره فقط همین نوبت).
            var skipped = d.skipped_so_far || {};
            var totals = {
                queued: (d.queued_so_far || 0),
                failed: (d.failed_so_far || 0),
                warnings: [],
                no_phone: (skipped.no_phone || 0),
                no_user_id: (skipped.no_user_id || 0),
                invalid: (skipped.invalid || 0),
                processed: 0
            };
            $('#farazsms-stop-phonebook-btn').show().prop('disabled', false)
                .find('.button__text').text('توقف انتقال');
            phonebookRunToken = d.run_token || '';
            if (d.resumed) {
                $responseDiv.empty().append($('<p/>').text('ادامه‌ی انتقالِ ناتمام از شماره‌ی ' + (d.start_offset || 0) + '…'))
                    .addClass('fwss-success-message').removeClass('fwss-error-message').show();
            }
            runPhonebookBatch($button, $responseDiv, d.phonebook_id, (d.start_offset || 0), (d.batch_size || 200), (d.total || 0), totals);
        }).fail(function(jqXHR, textStatus) {
            showPhonebookError($button, $responseDiv, 'خطا در ارتباط با سرور. لطفا دوباره تلاش کنید.' + ajaxErrorDetail(jqXHR, textStatus));
        });
    }

    // فاز ۲ — پردازشِ یک صفحه و ادامه‌ی حلقه.
    function runPhonebookBatch($button, $responseDiv, phonebookId, offset, batchSize, total, totals) {
        var pct = total > 0 ? Math.min(100, Math.round((offset / total) * 100)) : 0;
        $responseDiv.empty().append($('<p/>').text('در حال ارسال مخاطبین... ' + pct + '٪ (' + totals.queued + ' شماره به صف رفت)'))
            .addClass('fwss-success-message')
            .removeClass('fwss-error-message')
            .show();

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            dataType: 'json',
            timeout: 120000,
            data: {
                action: 'farazsms_next_phonebook_process_batch',
                nonce: farazsmsNextPhonebook.nonce,
                phonebook_id: phonebookId,
                offset: offset,
                batch_size: batchSize,
                run_token: phonebookRunToken
            }
        }).done(function(response) {
            if (!response || !response.success) {
                showPhonebookError($button, $responseDiv, (response && response.data && response.data.message) || 'خطا در واردسازی دسته‌ای.');
                return;
            }
            var b = response.data || {};
            totals.queued += (b.queued || 0);
            totals.failed += (b.failed || 0);
            // هشدارها باید انباشته شوند، نه جایگزین: با انتساب، از ۴۰ دسته‌ی نیمه‌شکست‌خورده
            // فقط آخری دیده می‌شد و بقیه بی‌صدا گم می‌شدند.
            if (b.warning && totals.warnings.indexOf(b.warning) === -1) { totals.warnings.push(b.warning); }
            totals.no_phone += (b.no_phone || 0);
            totals.no_user_id += (b.no_user_id || 0);
            totals.invalid += (b.invalid || 0);
            totals.processed += (b.processed || 0);
            if (b.stopped) {
                $button.prop('disabled', false).removeClass('fwss_button--loading');
                $('#farazsms-stop-phonebook-btn').hide();
                phonebookRunToken = '';
                $responseDiv.empty().append($('<p/>').text('انتقال متوقف شد. ' + totals.queued + ' شماره تا اینجا به صف رفت؛ با همان دکمه می‌توانید از همان‌جا ادامه دهید.'))
                    .addClass('fwss-success-message').removeClass('fwss-error-message').show();
                return;
            }
            if (b.done) {
                $button.prop('disabled', false).removeClass('fwss_button--loading');
                $('#farazsms-stop-phonebook-btn').hide();
                phonebookRunToken = '';
                var reasons = [];
                if (totals.no_phone > 0) { reasons.push(totals.no_phone + ' کاربر بدون شماره'); }
                if (totals.invalid > 0) { reasons.push(totals.invalid + ' شماره نامعتبر'); }
                var extra = reasons.length ? ' (' + reasons.join('، ') + ')' : '';
                // واردسازیِ سمتِ پنل ناهم‌زمان است؛ ادعای «ثبت شد» در این لحظه دروغ بود.
                var hasProblem = totals.failed > 0 || totals.warnings.length > 0;
                var warning = totals.warnings.length ? ' ' + totals.warnings.join(' ') : '';
                if (totals.failed > 0) { warning = ' ⚠️ در مجموع ' + totals.failed + ' شماره ارسال نشد.' + warning; }
                // ⚠️ warning از متنِ خطای سرورِ پنل ساخته می‌شود، پس متن است نه HTML.
                $responseDiv.empty().append($('<p/>').text('ارسال کامل شد. ' + totals.queued + ' شماره در صفِ واردسازیِ پنل قرار گرفت؛ تا چند دقیقه‌ی دیگر در دفترچه دیده می‌شود.' + extra + warning))
                    .addClass(hasProblem ? 'fwss-error-message' : 'fwss-success-message')
                    .removeClass(hasProblem ? 'fwss-success-message' : 'fwss-error-message')
                    .show();
                // تازه‌سازی لازم است تا صفحه از حالتِ «ایجاد دفترچه» به پنلِ دفترچه سوئیچ کند؛
                // عددِ کهنه دیگر دروغ نمی‌گوید، چون تا پایانِ واردسازی «در حال واردسازی…»
                // نمایش داده می‌شود. با وجودِ خطا تازه‌سازی نمی‌کنیم تا پیام خوانده شود.
                if (!hasProblem) { setTimeout(function() { window.location.reload(); }, 2500); }
                return;
            }
            // ادامه‌ی صفحه‌ی بعد.
            runPhonebookBatch($button, $responseDiv, phonebookId, (b.next_offset || (offset + batchSize)), batchSize, total, totals);
        }).fail(function(jqXHR, textStatus) {
            showPhonebookError($button, $responseDiv, 'خطا در ارتباط با سرور (دسته‌ی ' + offset + '). لطفا دوباره تلاش کنید.' + ajaxErrorDetail(jqXHR, textStatus));
        });
    }

    // Handle create phonebook button click
    $('#farazsms-create-phonebook-btn').on('click', function() {
        var $button = $(this);
        var $responseDiv = $('#farazsms-phonebook-response');
        handlePhonebookAction($button, $responseDiv);
    });

    // بستنِ تب وسطِ کار: رکورد بلافاصله قابلِ ادامه شود، نه پس از مهلتِ رهاشدگی.
    $(window).on('beforeunload', function () {
        if (phonebookRunToken) { releasePhonebookRun(); }
    });

    // توقفِ انتقال — فقط نشانه می‌گذارد؛ حلقه در ابتدای دسته‌ی بعدی می‌ایستد،
    // پس هیچ آپلودی وسطِ راه قطع نمی‌شود.
    $('#farazsms-stop-phonebook-btn').on('click', function() {
        var $stop = $(this);
        var $out  = $('#farazsms-phonebook-response');
        // توقف در ابتدای دسته‌ی بعدی اعمال می‌شود (تا ۱۲۰ ثانیه بعد)، پس دکمه
        // نباید بلافاصله «آماده» به‌نظر برسد وگرنه کاربر فکر می‌کند کار نکرد.
        $stop.prop('disabled', true).find('.button__text').text('در حالِ توقف…');
        $.post(ajaxurl, {
            action: 'farazsms_next_phonebook_stop',
            nonce: farazsmsNextPhonebook.nonce
        }).done(function(r) {
            if (!r || !r.success) {
                $stop.prop('disabled', false).find('.button__text').text('توقف انتقال');
                $out.html('<p>توقف ثبت نشد؛ صفحه را تازه کنید و دوباره تلاش کنید.</p>')
                    .addClass('fwss-error-message').removeClass('fwss-success-message').show();
            }
        }).fail(function() {
            $stop.prop('disabled', false).find('.button__text').text('توقف انتقال');
            $out.html('<p>توقف ثبت نشد؛ ارتباط با سرور برقرار نشد.</p>')
                .addClass('fwss-error-message').removeClass('fwss-success-message').show();
        });
    });

    // Handle update phonebook button click
    $('#farazsms-update-phonebook-btn').on('click', function() {
        var $button = $(this);
        var $responseDiv = $('#farazsms-phonebook-response');
        handlePhonebookAction($button, $responseDiv);
    });

    $('#farazsms-sync-custom-phonebook-btn').on('click', function() {
        var $btn = $(this);
        var $out = $('#farazsms-custom-phonebook-response');
        $btn.prop('disabled', true).addClass('fwss_button--loading');
        $out.hide().empty();
        $.post(ajaxurl, {
            action: 'farazsms_next_sync_custom_meta_phonebook',
            nonce: farazsmsNextPhonebook.nonce,
            custom_phonebook_title: $('#farazsms_custom_phonebook_title').val(),
            custom_meta_key: $('#farazsms_custom_meta_key').val(),
            custom_meta_source: $('#farazsms_custom_meta_source').val()
        }, function(response) {
            $btn.prop('disabled', false).removeClass('fwss_button--loading');
            if (response.success) {
                // ⚠️ متن، نه HTML: پیام از پاسخِ سرورِ پنل می‌آید.
                // ⚠️ .text(undefined) در جی‌کوئری **گتر** است، نه ستر: پاسخِ موفقی
                // که پیام ندارد کادر را خالی می‌گذاشت و کاربر هیچ بازخوردی
                // نمی‌دید. متنِ جایگزین لازم است.
                $out.empty().append($('<p/>').text(( response.data && response.data.message ) ? response.data.message : 'انجام شد.')).removeClass('fwss-error-message').addClass('fwss-success-message').show();
            } else {
                $out.empty().append($('<p/>').text(response.data && response.data.message ? response.data.message : 'خطا')).removeClass('fwss-success-message').addClass('fwss-error-message').show();
            }
        }).fail(function() {
            $btn.prop('disabled', false).removeClass('fwss_button--loading');
            $out.html('<p>خطا در ارتباط با سرور</p>').addClass('fwss-error-message').show();
        });
    });

    $('#farazsms-load-marketing-data-btn').on('click', function() {
        var $btn = $(this);
        $btn.prop('disabled', true);
        $.post(ajaxurl, {
            action: 'farazsms_next_phonebook_marketing_data',
            nonce: farazsmsNextPhonebook.nonce
        }, function(response) {
            $btn.prop('disabled', false);
            var $pb = $('#farazsms_bulk_phonebook').empty();
            var $ln = $('#farazsms_bulk_line').empty();
            $pb.append($('<option>').val('').text('— انتخاب کنید —'));
            $ln.append($('<option>').val('').text('— انتخاب کنید —'));
            if (!response.success) {
                alert(response.data && response.data.message ? response.data.message : 'خطا');
                return;
            }
            (response.data.phonebooks || []).forEach(function(p) {
                $pb.append($('<option>').val(p.id).text(p.title + ' (#' + p.id + ')'));
            });
            (response.data.lines || []).forEach(function(l) {
                $ln.append($('<option>').val(l.line_number).text(l.title + ' — ' + l.line_number));
            });
        }).fail(function() {
            $btn.prop('disabled', false);
            alert('خطا در ارتباط با سرور');
        });
    });

    $('#farazsms-send-bulk-phonebook-btn').on('click', function() {
        var $btn = $(this);
        var $out = $('#farazsms-bulk-response');
        var line = ($('#farazsms_bulk_line').val() || '').trim() || ($('#farazsms_bulk_line_custom').val() || '').trim();
        var pid = $('#farazsms_bulk_phonebook').val();
        var msg = $('#farazsms_bulk_message').val();
        if (!pid || !line || !msg.trim()) {
            alert('دفترچه، خط و متن را کامل کنید.');
            return;
        }
        if (!confirm('ارسال پیامک به همه مخاطبین این دفترچه؟')) {
            return;
        }
        $btn.prop('disabled', true).addClass('fwss_button--loading');
        $out.hide().empty();
        $.post(ajaxurl, {
            action: 'farazsms_next_send_bulk_phonebook_sms',
            nonce: farazsmsNextPhonebook.nonce,
            phonebook_id: pid,
            line_number: line,
            message: msg
        }, function(response) {
            $btn.prop('disabled', false).removeClass('fwss_button--loading');
            if (response.success) {
                // ⚠️ متن، نه HTML: پیام از پاسخِ سرورِ پنل می‌آید.
                // ⚠️ .text(undefined) در جی‌کوئری **گتر** است، نه ستر: پاسخِ موفقی
                // که پیام ندارد کادر را خالی می‌گذاشت و کاربر هیچ بازخوردی
                // نمی‌دید. متنِ جایگزین لازم است.
                $out.empty().append($('<p/>').text(( response.data && response.data.message ) ? response.data.message : 'انجام شد.')).removeClass('fwss-error-message').addClass('fwss-success-message').show();
            } else {
                $out.empty().append($('<p/>').text(response.data && response.data.message ? response.data.message : 'خطا')).removeClass('fwss-success-message').addClass('fwss-error-message').show();
            }
        }).fail(function() {
            $btn.prop('disabled', false).removeClass('fwss_button--loading');
            $out.html('<p>خطا در ارتباط با سرور</p>').addClass('fwss-error-message').show();
        });
    });
});
