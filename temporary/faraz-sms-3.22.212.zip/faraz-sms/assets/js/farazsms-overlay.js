/**
 * موتورِ اورلیِ مشترکِ فراز — هسته (plain JS، بدونِ build).
 *
 * وظایف: پوسته‌ی مشترک (backdrop + پنل + دکمه‌ی بستن)، قفلِ اسکرولِ ref-counted و درست
 * (ذخیره/بازگرداندنِ مقدارِ قبلی)، موتورِ تریگر (on_load/delay/scroll/exit_intent/click)،
 * بارگذارِ تنبلِ chunkِ فیچر (تزریقِ <script>)، گیتِ فرکانس، و helperِ ajax.
 *
 * قراردادِ فیچر: هر chunk صدا می‌زند FarazOverlay.define(id, { mount(root,ctx), onOpen, onClose }).
 */
(function () {
	'use strict';

	var DATA = window.farazsmsOverlayData || { ajaxUrl: '', overlays: [] };

	var impls = {};       // id -> impl فیچر (از chunk)
	var configs = {};     // id -> config
	var loading = {};     // id -> در حالِ تزریقِ chunk
	var pendingOpen = {}; // id -> open پیش از define صدا خورده
	var shells = {};      // id -> { overlay, panel, content, mounted }

	/* ---------- قفلِ اسکرولِ مرکزی (ref-counted، ذخیره/بازگرداندنِ درست) ---------- */
	var lockCount = 0, prevHtml = '', prevBody = '';
	function lockScroll() {
		if (lockCount === 0) {
			prevHtml = document.documentElement.style.overflow;
			prevBody = document.body.style.overflow;
			document.documentElement.style.overflow = 'hidden';
			document.body.style.overflow = 'hidden';
		}
		lockCount++;
	}
	function unlockScroll() {
		lockCount = Math.max(0, lockCount - 1);
		if (lockCount === 0) {
			document.documentElement.style.overflow = prevHtml;
			document.body.style.overflow = prevBody;
		}
	}

	/* ---------- گیتِ فرکانس ---------- */
	function seenKey(id) { return 'farazOverlaySeen_' + id + '_v1'; }
	function canShow(id, freq) {
		try {
			if (freq === 'session') { return !sessionStorage.getItem(seenKey(id)); }
			if (freq === 'once') { return !localStorage.getItem(seenKey(id)); }
			if (freq === 'day') {
				var last = localStorage.getItem(seenKey(id));
				return !last || last !== new Date().toDateString();
			}
			return true; // always
		} catch (e) { return true; }
	}
	function markSeen(id, freq) {
		try {
			if (freq === 'session') { sessionStorage.setItem(seenKey(id), '1'); }
			else if (freq === 'once') { localStorage.setItem(seenKey(id), '1'); }
			else if (freq === 'day') { localStorage.setItem(seenKey(id), new Date().toDateString()); }
		} catch (e) { /* storage در دسترس نیست — بی‌خیال */ }
	}

	/* ---------- تم ---------- */
	var THEME_MAP = {
		accent: '--fz-ov-accent',
		btn_bg: '--fz-ov-btn-bg',
		btn_text: '--fz-ov-btn-text',
		btn_bg_after: '--fz-ov-btn-bg-after',
		btn_text_after: '--fz-ov-btn-text-after',
		radius: '--fz-ov-radius',
		backdrop: '--fz-ov-backdrop'
	};
	function applyTheme(root, theme) {
		if (!theme || typeof theme !== 'object') { return; }
		Object.keys(THEME_MAP).forEach(function (k) {
			if (theme[k]) { root.style.setProperty(THEME_MAP[k], theme[k]); }
		});
	}

	/* ---------- helperها ---------- */
	function el(tag, cls, html) {
		var e = document.createElement(tag);
		if (cls) { e.className = cls; }
		if (html != null) { e.innerHTML = html; }
		return e;
	}

	function ajax(action, data, cb) {
		var fd = new FormData();
		fd.append('action', action);
		if (data) { Object.keys(data).forEach(function (k) { fd.append(k, data[k]); }); }
		fetch(DATA.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' })
			.then(function (r) { return r.json(); })
			.then(cb)
			.catch(function () { cb({ success: false, data: { message: 'خطای ارتباط' } }); });
	}

	/* ---------- پوسته ---------- */
	function buildShell(id) {
		var overlay = el('div', 'fz-ov-overlay');
		overlay.setAttribute('data-fz-ov', id);
		var panel = el('div', 'fz-ov-panel');
		var close = el('button', 'fz-ov-close', '&times;');
		close.setAttribute('type', 'button');
		close.setAttribute('aria-label', 'بستن');
		var content = el('div', 'fz-ov-content');

		panel.appendChild(close);
		panel.appendChild(content);
		overlay.appendChild(panel);

		close.addEventListener('click', function () { FZ.close(id); });
		overlay.addEventListener('click', function (e) { if (e.target === overlay) { FZ.close(id); } });

		applyTheme(panel, (configs[id] || {}).theme);
		document.body.appendChild(overlay);
		return { overlay: overlay, panel: panel, content: content, mounted: false };
	}

	/* ---------- بارگذاریِ تنبلِ chunk ---------- */
	function ensureChunk(id) {
		if (impls[id]) { return; }          // آماده است
		pendingOpen[id] = true;             // بعد از define باز شود
		if (loading[id]) { return; }        // در حالِ لود — منتظر بمان
		var cfg = configs[id];
		if (!cfg || !cfg.chunk) { return; }
		loading[id] = true;
		var s = document.createElement('script');
		s.src = cfg.chunk;
		s.async = true;
		s.onerror = function () { loading[id] = false; };
		document.head.appendChild(s);
		// ادامه‌ی کار را define() به عهده می‌گیرد.
	}

	/* ---------- API عمومی ---------- */
	var FZ = {
		define: function (id, impl) {
			impls[id] = impl;
			loading[id] = false;
			if (pendingOpen[id]) { pendingOpen[id] = false; FZ.open(id); }
		},

		open: function (id) {
			var cfg = configs[id];
			if (!cfg) { return; }
			if (!impls[id]) { ensureChunk(id); return; } // اول chunk، بعد دوباره open
			var shell = shells[id] || (shells[id] = buildShell(id));
			var ctx = {
				config: cfg,
				theme: cfg.theme,
				ajax: ajax,
				close: function () { FZ.close(id); }
			};
			if (!shell.mounted) {
				shell.mounted = true;
				if (typeof impls[id].mount === 'function') { impls[id].mount(shell.content, ctx); }
			}
			shell.overlay.classList.add('fz-ov-open');
			lockScroll();
			if (typeof impls[id].onOpen === 'function') { impls[id].onOpen(shell.content, ctx); }
			markSeen(id, cfg.frequency);
		},

		close: function (id) {
			var shell = shells[id];
			if (!shell || !shell.overlay.classList.contains('fz-ov-open')) { return; }
			shell.overlay.classList.remove('fz-ov-open');
			unlockScroll();
			if (impls[id] && typeof impls[id].onClose === 'function') {
				impls[id].onClose(shell.content, { config: configs[id] });
			}
		},

		// دسترسیِ فیچرها به ajaxِ مشترک بدونِ باز/بستن.
		ajax: ajax,

		// ── ابزارهای مستقل (برای فیچرهایی که DOMِ خودشان را دارند، مثلِ باکسِ گوشه‌ی لیدمگنت) ──
		// قفلِ اسکرولِ درستِ ref-counted — جایگزینِ لاک‌های دستیِ باگ‌دار در فیچرها.
		lockScroll: lockScroll,
		unlockScroll: unlockScroll,
		// نصبِ یک تریگر (delay/scroll/exit_intent/on_load) که هنگامِ شلیک، cb را یک‌بار صدا می‌زند.
		// opts: { type, value } یا { trigger:{type,value} }. فیچر خودش منطقِ «دیده‌شده» را مدیریت می‌کند.
		onTrigger: function (opts, cb) {
			opts = opts || {};
			var trigger = opts.trigger || { type: opts.type || 'on_load', value: opts.value };
			installTriggerRaw(trigger, function () { if (typeof cb === 'function') { cb(); } });
		}
	};
	window.FarazOverlay = FZ;

	/* ---------- موتورِ تریگر ---------- */
	function idle(fn) {
		if (window.requestIdleCallback) { window.requestIdleCallback(fn, { timeout: 2000 }); }
		else { setTimeout(fn, 1); }
	}

	// نصبِ خامِ یک تریگر: وقتی شرط رخ داد، fire() صدا زده می‌شود (بدونِ گیتِ فرکانس — آن را caller
	// تصمیم می‌گیرد). این هستهٔ مشترک است که هم اورلیِ shell و هم ابزارِ بیرونیِ onTrigger از آن استفاده می‌کنند.
	function installTriggerRaw(trigger, fire) {
		var t = trigger || { type: 'on_load' };
		switch (t.type) {
			case 'delay':
				idle(function () { setTimeout(fire, (parseFloat(t.value) || 0) * 1000); });
				break;
			case 'scroll':
				var pct = parseFloat(t.value) || 50;
				var onScroll = function () {
					var h = document.documentElement;
					var scrolled = h.scrollTop || document.body.scrollTop || 0;
					var max = h.scrollHeight - h.clientHeight;
					// کدریویو v3.22.152: صفحه‌ی کوتاه‌تر از پنجره اصلاً اسکرول ندارد؛ قبلاً با
					// max=1 نسبت همیشه صفر می‌ماند و تریگر هرگز شلیک نمی‌کرد (لیدمگنت روی
					// صفحه‌های کوتاه دیده نمی‌شد). حالا «قابلِ اسکرول نبودن» یعنی شرط برقرار است.
					if (max <= 0 || (scrolled / max) * 100 >= pct) {
						window.removeEventListener('scroll', onScroll);
						fire();
					}
				};
				window.addEventListener('scroll', onScroll, { passive: true });
				// ارزیابیِ اولیه: بازگشت با حافظه‌ی اسکرول (back/forward) یا صفحه‌ی کوتاه، بدونِ
				// هیچ رویدادِ scroll هم باید نتیجه بدهد.
				onScroll();
				break;
			case 'exit_intent':
				var onOut = function (e) {
					if (e.clientY <= 0) { document.removeEventListener('mouseout', onOut); fire(); }
				};
				document.addEventListener('mouseout', onOut);
				break;
			case 'click':
				// click-محور: خودِ فیچر (دکمه/لینک) fire را صدا می‌زند؛ اینجا listenerی نصب نمی‌شود.
				break;
			case 'on_load':
			default:
				idle(fire);
				break;
		}
	}

	function installTrigger(cfg) {
		installTriggerRaw(cfg.trigger, function () {
			if (canShow(cfg.id, cfg.frequency)) { FZ.open(cfg.id); }
		});
	}

	function init() {
		(DATA.overlays || []).forEach(function (cfg) {
			configs[cfg.id] = cfg;
			installTrigger(cfg);
		});
	}

	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); }
	else { init(); }
})();
