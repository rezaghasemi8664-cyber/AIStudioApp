/**
 * گردونه‌ی شانس — فرانت‌اند (وانیلا، بدونِ وابستگی).
 * جایزه سمتِ سرور تعیین می‌شود؛ این فایل فقط چرخش را تا همان تکه انیمیت می‌کند.
 */
(function () {
	'use strict';
	if (typeof farazsmsSpin === 'undefined' || !farazsmsSpin.slices || !farazsmsSpin.slices.length) { return; }

	var S = farazsmsSpin;
	var overlay, canvas, ctx, actionBtn, mobileInput, otpWrap, otpInput, msgEl, resultEl, formEl;
	var N = S.slices.length;
	var sliceAngle = 360 / N;
	var rotation = 0;
	// فونتِ کنواس را از فونتِ قالبِ سایت برمی‌داریم تا با سایت هماهنگ باشد.
	var siteFont = (function () { try { var f = getComputedStyle(document.body).fontFamily; return f && f.trim() ? f : 'Tahoma, sans-serif'; } catch (e) { return 'Tahoma, sans-serif'; } })();
	var spinning = false;
	var state = 'mobile';
	var built = false;

	function el(tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }

	function build() {
		if (built) { return; }
		built = true;
		overlay = el('div', 'farazsms-spin-overlay');
		overlay.style.display = 'none';
		var modal = el('div', 'farazsms-spin-modal');

		var close = el('button', 'farazsms-spin-close', '×');
		close.addEventListener('click', hide);
		modal.appendChild(close);

		modal.appendChild(el('h2', 'farazsms-spin-title', escapeHtml(S.title)));
		modal.appendChild(el('p', 'farazsms-spin-subtitle', escapeHtml(S.subtitle)));

		var wrap = el('div', 'farazsms-spin-wheel-wrap');
		wrap.appendChild(el('div', 'farazsms-spin-pointer'));
		canvas = el('canvas', 'farazsms-spin-canvas');
		canvas.width = 340; canvas.height = 340;
		wrap.appendChild(canvas);
		wrap.appendChild(el('div', 'farazsms-spin-hub'));
		modal.appendChild(wrap);

		formEl = el('div', 'farazsms-spin-form');
		mobileInput = el('input', 'farazsms-spin-mobile');
		mobileInput.type = 'tel'; mobileInput.placeholder = S.mobileLabel; mobileInput.setAttribute('inputmode', 'numeric'); mobileInput.maxLength = 11;
		formEl.appendChild(mobileInput);

		otpWrap = el('div', 'farazsms-spin-otp-wrap');
		otpWrap.style.display = 'none';
		otpInput = el('input', 'farazsms-spin-otp');
		otpInput.type = 'text'; otpInput.placeholder = 'کد تأیید پیامک‌شده'; otpInput.setAttribute('inputmode', 'numeric'); otpInput.maxLength = 6;
		otpWrap.appendChild(otpInput);
		formEl.appendChild(otpWrap);

		if (S.consentText) {
			var lbl = el('label', 'farazsms-spin-consent');
			var cb = el('input'); cb.type = 'checkbox'; cb.checked = true; cb.className = 'farazsms-spin-consent-cb';
			lbl.appendChild(cb); lbl.appendChild(document.createTextNode(' ' + S.consentText));
			formEl.appendChild(lbl);
		}

		actionBtn = el('button', 'farazsms-spin-action', S.requireOtp === '1' ? 'ارسال کد تأیید' : escapeHtml(S.buttonText));
		actionBtn.addEventListener('click', onAction);
		formEl.appendChild(actionBtn);

		msgEl = el('div', 'farazsms-spin-msg');
		formEl.appendChild(msgEl);
		modal.appendChild(formEl);

		resultEl = el('div', 'farazsms-spin-result');
		resultEl.style.display = 'none';
		modal.appendChild(resultEl);

		overlay.appendChild(modal);
		overlay.addEventListener('click', function (e) { if (e.target === overlay) { hide(); } });
		document.body.appendChild(overlay);

		ctx = canvas.getContext('2d');
		drawWheel();
	}

	function drawWheel() {
		var size = canvas.width, r = size / 2, cx = r, cy = r;
		ctx.clearRect(0, 0, size, size);
		for (var i = 0; i < N; i++) {
			var start = (-90 + i * sliceAngle) * Math.PI / 180;
			var end = (-90 + (i + 1) * sliceAngle) * Math.PI / 180;
			ctx.beginPath();
			ctx.moveTo(cx, cy);
			ctx.arc(cx, cy, r - 6, start, end);
			ctx.closePath();
			ctx.fillStyle = S.slices[i].color || '#64748b';
			ctx.fill();
			ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(255,255,255,.85)'; ctx.stroke();
			// label
			ctx.save();
			ctx.translate(cx, cy);
			ctx.rotate(start + (end - start) / 2);
			ctx.textAlign = 'right'; ctx.fillStyle = '#fff';
			ctx.direction = 'rtl';
			ctx.font = '700 15px ' + siteFont;
			ctx.fillText(trim(S.slices[i].label, 14), r - 18, 6);
			ctx.restore();
		}
		// outer ring
		ctx.beginPath(); ctx.arc(cx, cy, r - 5, 0, 2 * Math.PI); ctx.lineWidth = 6; ctx.strokeStyle = '#0f172a'; ctx.stroke();
	}

	function setMsg(t, ok) { msgEl.textContent = t || ''; msgEl.style.color = ok ? '#16a34a' : '#dc2626'; }

	function busy(b, txt) { actionBtn.disabled = b; actionBtn.style.opacity = b ? '.6' : '1'; if (txt != null) { actionBtn.textContent = txt; } }

	function mobileVal() { return (mobileInput.value || '').replace(/[^\d]/g, ''); }

	function onAction() {
		if (spinning) { return; }
		var cb = formEl.querySelector('.farazsms-spin-consent-cb');
		if (cb && !cb.checked) { setMsg('برای شرکت، تیکِ رضایت را بزنید.'); return; }
		var m = mobileVal();
		if (!/^09\d{9}$/.test(m)) { setMsg('شماره موبایل را درست وارد کنید (۰۹...).'); return; }

		if (S.requireOtp === '1' && state === 'mobile') {
			busy(true, 'در حال ارسال…'); setMsg('');
			req('farazsms_spin_send_otp', { mobile: m }, function (res) {
				busy(false, 'تأیید و چرخش');
				if (res && res.success) { state = 'otp'; otpWrap.style.display = 'block'; mobileInput.readOnly = true; otpInput.focus(); setMsg(res.data.message, true); }
				else { setMsg((res && res.data && res.data.message) || 'خطا'); }
			});
			return;
		}
		// spin (either no-otp, or otp entered)
		doSpin(m);
	}

	function doSpin(m) {
		var payload = { mobile: m };
		if (S.requireOtp === '1') { payload.code = (otpInput.value || '').replace(/[^\d]/g, ''); }
		spinning = true; busy(true, 'در حال چرخش…'); setMsg('');
		req('farazsms_spin_do', payload, function (res) {
			if (!res || !res.success) { spinning = false; busy(false, S.requireOtp === '1' ? 'تأیید و چرخش' : S.buttonText); setMsg((res && res.data && res.data.message) || 'خطا'); return; }
			animateTo(res.data.index, function () { showResult(res.data); });
		});
	}

	function animateTo(index, done) {
		var spins = 6;
		var center = index * sliceAngle + sliceAngle / 2; // offset clockwise from top
		var target = spins * 360 + (360 - center);
		// keep increasing rotation so it always spins forward
		rotation = target;
		canvas.style.transition = 'transform 4.2s cubic-bezier(.17,.67,.18,1)';
		canvas.style.transform = 'rotate(' + rotation + 'deg)';
		var t = setTimeout(function () { clearTimeout(t); done(); }, 4400);
	}

	function showResult(d) {
		spinning = false;
		formEl.style.display = 'none';
		resultEl.style.display = 'block';
		if (d.won) {
			var extra = '';
			if (d.type === 'coupon' && d.value) { extra = '<div class="farazsms-spin-code">' + escapeHtml(d.value) + '</div><div class="farazsms-spin-code-hint">این کد را هنگام خرید وارد کنید</div>'; }
			else if (d.type === 'link' && d.value) { extra = '<a class="farazsms-spin-link" href="' + encodeURI(d.value) + '" target="_blank" rel="noopener">دریافت جایزه</a>'; }
			resultEl.innerHTML = '<div class="farazsms-spin-win">🎉</div><h3>تبریک! برنده شدی</h3><div class="farazsms-spin-prize">' + escapeHtml(d.label) + '</div>' + extra + '<p class="farazsms-spin-sms-note">جزئیات با پیامک برایت ارسال شد.</p>';
		} else {
			resultEl.innerHTML = '<div class="farazsms-spin-lose">🌱</div><h3>' + escapeHtml(d.label || 'پوچ') + '</h3><p>' + escapeHtml(S.loseText) + '</p>';
		}
	}

	function req(action, data, cb) {
		var fd = new FormData();
		fd.append('action', action); fd.append('nonce', S.nonce);
		for (var k in data) { fd.append(k, data[k]); }
		fetch(S.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
			.then(function (r) { return r.json(); }).then(cb).catch(function () { cb({ success: false, data: { message: 'خطای ارتباط' } }); });
	}

	var prevHtmlOverflow = '', prevBodyOverflow = '';
	function show() {
		build();
		var wasHidden = !overlay.style.display || overlay.style.display === 'none';
		overlay.style.display = 'flex';
		// قفلِ اسکرولِ پس‌زمینه تا کاربر صفحه را جابه‌جا نکند و پاپ‌آپ «گم» نشود (رفتارِ استانداردِ مودال).
		// مقدارِ inlineِ قبلی ذخیره می‌شود (فقط اگر واقعاً بسته بوده، تا با نمایشِ دوباره «hidden» ذخیره نشود)
		// و در بستن دقیقاً همان بازگردانده می‌شود — نه پاک‌کردنِ overflowِ inlineِ قالب.
		try {
			if ( wasHidden ) {
				prevHtmlOverflow = document.documentElement.style.overflow;
				prevBodyOverflow = document.body.style.overflow;
			}
			document.documentElement.style.overflow = 'hidden';
			document.body.style.overflow = 'hidden';
		} catch (e) {}
	}
	function hide() {
		if (overlay) { overlay.style.display = 'none'; }
		try {
			document.documentElement.style.overflow = prevHtmlOverflow;
			document.body.style.overflow = prevBodyOverflow;
		} catch (e) {}
	}

	function trim(s, n) { s = String(s || ''); return s.length > n ? s.slice(0, n - 1) + '…' : s; }
	function escapeHtml(s) { var d = document.createElement('div'); d.textContent = String(s == null ? '' : s); return d.innerHTML; }

	// دفعاتِ نمایشِ پاپ‌آپِ خودکار — شفاف و قابلِ‌پیش‌بینی (به‌جای «یک‌بار و تمامِ» مبهمِ قبلی).
	// always=هر بار | session=یک‌بار تا بستنِ مرورگر | daily=یک‌بار در روز | once=یک‌بار برای همیشه.
	// کلیدهای «نسخه‌دار» (v2): عمداً با کلیدِ قدیمِ farazsmsSpinSeen فرق دارند تا مقدارِ
	// به‌جامانده از نسخه‌ی قبل، پاپ‌آپ را برای همیشه در همان session خفه نکند (باگِ رگرسیون).
	var K_SESSION = 'farazsmsSpinSeen_v2', K_ONCE = 'farazsmsSpinSeenEver_v2', K_DAY = 'farazsmsSpinDay_v2';
	function todayKey() { var d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
	function alreadyShown() {
		var f = S.frequency || 'session';
		try {
			if (f === 'always') { return false; }
			if (f === 'session') { return sessionStorage.getItem(K_SESSION) === '1'; }
			if (f === 'once') { return localStorage.getItem(K_ONCE) === '1'; }
			if (f === 'daily') { return localStorage.getItem(K_DAY) === todayKey(); }
		} catch (e) { return false; }
		return false;
	}
	function markShown() {
		var f = S.frequency || 'session';
		try {
			if (f === 'session') { sessionStorage.setItem(K_SESSION, '1'); }
			else if (f === 'once') { localStorage.setItem(K_ONCE, '1'); }
			else if (f === 'daily') { localStorage.setItem(K_DAY, todayKey()); }
			// always: چیزی ذخیره نمی‌شود تا هر بار نشان داده شود.
		} catch (e) {}
	}

	function init() {
		if (S.trigger === 'click') {
			var sel = S.triggerSel || '.spin-wheel-open';
			document.addEventListener('click', function (e) {
				if (e.target && e.target.closest && e.target.closest(sel)) { e.preventDefault(); show(); }
			});
		} else {
			// پاپ‌آپِ خودکار طبقِ «دفعاتِ نمایش».
			if (alreadyShown()) { return; }
			var delay = Math.max(0, (S.triggerDelay || 4)) * 1000;
			// «دیده‌شده» فقط پس از نمایشِ موفق ثبت می‌شود؛ اگر رِندر خطا داد، خفه نشود.
			setTimeout(function () { try { show(); markShown(); } catch (e) {} }, delay);
		}
	}

	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); } else { init(); }
})();
