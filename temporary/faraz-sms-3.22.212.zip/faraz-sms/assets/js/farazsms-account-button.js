/**
 * دکمه‌ی هوشمندِ حساب — سمتِ کلاینت.
 *
 * دو کار:
 *  ۱) آداپتور A: لینک‌های منو/هدر که به صفحه‌ی ورود اشاره می‌کنند را «هدف» می‌گیرد
 *     (تطبیق بر اساسِ pathnameِ نرمال‌شده، نه substring — تا لینک‌های بی‌ربط/خروج ربوده نشوند).
 *  ۲) کش‌امن: وضعیتِ واقعیِ همین کاربر را از AJAX (POST) می‌گیرد و متن/مقصدِ دکمه‌ها را
 *     تصحیح می‌کند — حتی اگر HTML کش‌شده باشد.
 *
 * vanilla، بدونِ وابستگی.
 */
( function () {
	'use strict';

	var cfg = window.farazsms_account || {};

	function normPath( p ) {
		// حساس‌نبودن به بزرگی/کوچکی؛ حذفِ اسلشِ پایانی.
		p = ( p || '/' ).toLowerCase().replace( /\/+$/, '' );
		return p === '' ? '/' : p;
	}

	/**
	 * یک الگو (URL یا مسیرِ ریشه‌دار) را به «کلیدِ تطبیق» تبدیل کن.
	 * فقط الگوهای مطلق (شروع با /) یا URLِ کامل (://) پذیرفته می‌شوند — توکنِ نسبی
	 * (مثلِ wp-login.php) رد می‌شود چون نتیجه‌اش وابسته به صفحه‌ی جاری می‌شد.
	 * کلید = pathname؛ ولی برای مسیرِ '/' با query (سایتِ بدونِ پرمالینکِ تمیز، مثلِ
	 * /?page_id=5) کلید = '/' + query تا صفحه‌ی خانه با آن اشتباه نشود.
	 */
	function toKey( u ) {
		try {
			u = String( u ).trim();
			if ( u === '' ) {
				return null;
			}
			if ( u.charAt( 0 ) !== '/' && u.indexOf( '://' ) === -1 ) {
				return null; // توکنِ نسبی/بی‌ریشه.
			}
			var a = document.createElement( 'a' );
			a.href = u;
			var pth = normPath( a.pathname );
			if ( pth === '/' ) {
				return a.search ? ( '/' + a.search.toLowerCase() ) : null; // '/'ِ خالی = صفحه‌ی خانه → کنار.
			}
			return pth;
		} catch ( e ) {
			return null;
		}
	}

	var loginKeys = ( function () {
		var out = {};
		var pats = cfg.match || [];
		for ( var i = 0; i < pats.length; i++ ) {
			var k = toKey( pats[ i ] );
			if ( k ) {
				out[ k ] = true;
			}
		}
		return out;
	} )();

	function linkKey( a ) {
		var pth = normPath( a.pathname );
		if ( pth === '/' ) {
			return a.search ? ( '/' + a.search.toLowerCase() ) : '/';
		}
		return pth;
	}

	// نشانه‌های لینکِ خروج (وردپرس/ووکامرس/عمومی) — هرگز نباید ارتقا یابند.
	function isLogoutHref( href ) {
		return /(action=logout|customer-logout|loggedout=|\/logout(\/|\?|$))/i.test( href );
	}

	/** آیا این لینک به صفحه‌ی ورود می‌خورد؟ (کلیدِ برابر + نه خروج + نه درون‌صفحه‌ای) */
	function isLoginLink( a ) {
		var raw = a.getAttribute( 'href' );
		if ( raw === null ) {
			return false;
		}
		raw = raw.trim();
		// لینکِ درون‌صفحه‌ای/فقط-هش/فقط-کوئری → دست نزن (روی خودِ صفحه‌ی ورود رایج است).
		if ( raw === '' || raw.charAt( 0 ) === '#' || raw.charAt( 0 ) === '?' ) {
			return false;
		}
		var href = a.href; // resolved مطلق
		if ( ! href || isLogoutHref( href ) ) {
			return false;
		}
		// فقط لینکِ همین دامنه؛ لینکِ بیرونی با pathnameِ مشابه نباید ربوده شود.
		// مقایسه پس از حذفِ پیشوندِ «www.» تا لینکِ www در برابرِ non-www (همان سایت) اشتباهاً رد نشود.
		if ( a.host ) {
			var stripWww = function ( h ) { return String( h || '' ).replace( /^www\./i, '' ); };
			if ( stripWww( a.host ) !== stripWww( window.location.host ) ) {
				return false;
			}
		}
		if ( ! loginKeys[ linkKey( a ) ] ) {
			return false;
		}
		// لینکِ هش‌دار به همان صفحه‌ی جاری (jump-link) → دست نزن.
		try {
			if ( a.hash && normPath( a.pathname ) === normPath( window.location.pathname ) ) {
				return false;
			}
		} catch ( e ) {}
		return true;
	}

	/** اولین گرهِ متنیِ ناتهی در هر عمقی. */
	function firstTextNode( node ) {
		for ( var i = 0; i < node.childNodes.length; i++ ) {
			var n = node.childNodes[ i ];
			if ( n.nodeType === 3 && n.nodeValue && n.nodeValue.trim() !== '' ) {
				return n;
			}
			if ( n.nodeType === 1 ) {
				var deep = firstTextNode( n );
				if ( deep ) {
					return deep;
				}
			}
		}
		return null;
	}

	/** برچسبِ لینک را عوض کن بدونِ نابودکردنِ آیکون/ساختارِ داخل. */
	function setLabel( a, text ) {
		var labelEl = a.querySelector( '.farazsms-account-btn__label' );
		if ( labelEl ) {
			labelEl.textContent = text;
			return;
		}
		var tn = firstTextNode( a );
		if ( tn ) {
			tn.nodeValue = text;
			return;
		}
		if ( a.children.length === 0 ) {
			a.textContent = text;
			return;
		}
		var span = document.createElement( 'span' );
		span.className = 'farazsms-account-btn__label';
		span.textContent = text;
		a.appendChild( span );
	}

	/** back_url را بچسبان تا بعد از ورود به همین صفحه برگردد. */
	function withBackUrl( url ) {
		try {
			if ( /[?&]back_url=/.test( url ) ) {
				return url;
			}
			var sep = url.indexOf( '?' ) === -1 ? '?' : '&';
			return url + sep + 'back_url=' + encodeURIComponent( window.location.href );
		} catch ( e ) {
			return url;
		}
	}

	/** همه‌ی هدف‌ها: رندرشده‌ی سرور + کلاسِ اختیاری + لینک‌های منو. */
	function collectTargets() {
		var set = [];
		var seen = [];
		function push( el ) {
			if ( el && seen.indexOf( el ) === -1 ) {
				seen.push( el );
				set.push( el );
			}
		}
		var explicit = document.querySelectorAll( 'a[data-fab], a.farazsms-account' );
		for ( var i = 0; i < explicit.length; i++ ) {
			push( explicit[ i ] );
		}
		if ( cfg.upgrade_menu ) {
			var links = document.getElementsByTagName( 'a' );
			for ( var j = 0; j < links.length; j++ ) {
				var a = links[ j ];
				if ( a.getAttribute( 'data-fab' ) ) {
					continue;
				}
				if ( isLoginLink( a ) ) {
					a.setAttribute( 'data-fab', 'auto' );
					push( a );
				}
			}
		}
		return set;
	}

	/** وضعیت را روی یک دکمه اعمال کن. */
	function applyTo( a, state ) {
		var isAuto = a.getAttribute( 'data-fab' ) === 'auto';
		if ( state.logged_in ) {
			a.setAttribute( 'href', state.href || cfg.account_url );
			setLabel( a, state.label );
			a.setAttribute( 'data-fab-state', 'in' );
		} else {
			a.setAttribute( 'href', withBackUrl( state.href || cfg.login_url ) );
			// لینکِ خودکارِ منو در حالتِ خروج: متنِ اصلیِ قالب را دست نزن (فقط مقصد را امن کن).
			// دکمه‌ی صریح (شورت‌کد/ویجت): متنِ اختصاصیِ خودش (data-fab-guest) اولویت دارد.
			if ( ! isAuto ) {
				var ownGuest = a.getAttribute( 'data-fab-guest' );
				setLabel( a, ( ownGuest && ownGuest !== '' ) ? ownGuest : ( state.label || cfg.guest_label ) );
			}
			a.setAttribute( 'data-fab-state', 'out' );
		}
	}

	function applyAll( state ) {
		var targets = collectTargets();
		for ( var i = 0; i < targets.length; i++ ) {
			applyTo( targets[ i ], state );
		}
	}

	/** وضعیتِ واقعی را از سرور بگیر (POST، کش‌ناپذیر) و اعمال کن؛ یک retry در صورتِ خطا. */
	function fetchState( isRetry ) {
		if ( ! cfg.ajax_url ) {
			return;
		}
		var body = 'action=farazsms_account_state';
		function ok( res ) {
			if ( res && res.success && res.data ) {
				applyAll( res.data );
			}
		}
		function fail() {
			if ( ! isRetry ) {
				window.setTimeout( function () { fetchState( true ); }, 1500 );
			}
		}
		if ( window.fetch ) {
			window.fetch( cfg.ajax_url, {
				method: 'POST',
				credentials: 'same-origin',
				cache: 'no-store',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body
			} ).then( function ( r ) {
				if ( ! r.ok ) { throw new Error( 'http' ); }
				return r.json();
			} ).then( ok ).catch( fail );
		} else {
			try {
				var x = new XMLHttpRequest();
				x.open( 'POST', cfg.ajax_url, true );
				x.withCredentials = true;
				x.setRequestHeader( 'Content-Type', 'application/x-www-form-urlencoded' );
				x.onreadystatechange = function () {
					if ( x.readyState === 4 ) {
						if ( x.status === 200 ) {
							try { ok( JSON.parse( x.responseText ) ); } catch ( e ) { fail(); }
						} else {
							fail();
						}
					}
				};
				x.send( body );
			} catch ( e ) {
				fail();
			}
		}
	}

	function boot() {
		// اگر هیچ هدفی (دکمه‌ی صریح یا لینکِ منویِ منطبق) نیست، درخواستِ کش‌ناپذیر را نزن.
		var targets = collectTargets();
		if ( targets.length === 0 ) {
			return;
		}
		fetchState( false );
	}

	if ( document.readyState !== 'loading' ) {
		boot();
	} else {
		document.addEventListener( 'DOMContentLoaded', boot );
	}
} )();
