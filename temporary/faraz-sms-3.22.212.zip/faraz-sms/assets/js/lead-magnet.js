/**
 * Lead Magnet Box JavaScript
 */

(function($) {
    'use strict';

    $(document).ready(function() {
        var $box = $('.farazsms-lead-magnet-box');
        
        if (!$box.length) {
            return;
        }

        // ── بستنِ ماندگار ─────────────────────────────────────────────────────────
        // v3.22.182: کوکیِ بستن در v3.22.7 حذف شده بود تا مشکلِ «مدیر پیش‌نمایش را بست و
        // دیگر ندید» رفع شود؛ ولی حذفِ کوکی مشکلِ بزرگ‌تری ساخت: باکس در هر صفحه دوباره
        // باز می‌شد، حتی بعد از بستن. ضمناً تنظیماتِ «چند روز نشان نده» ذخیره می‌شد ولی
        // هیچ‌کس نمی‌خواندش.
        //
        // مدیر اصلاً به اینجا نمی‌رسد: باکس فقط به مهمان نشان داده می‌شود و هر دو مسیرِ
        // enqueue و render پشتِ همان گیت‌اند —
        //
        //     lead-magnet-helpers.php → farazsms_next_lead_magnet_should_display()
        //
        var DISMISS_COOKIE = 'farazsms_lm_dismissed';
        var dismissDays = parseInt($box.attr('data-dismiss-days'), 10);
        // تنظیماتِ مدیر بین ۱ تا ۳۶۵ کلمپ می‌شود، پس مقدارِ نامعتبر فقط یعنی «چیزی ذخیره نشده».
        if (isNaN(dismissDays) || dismissDays < 1) { dismissDays = 30; }

        function hasDismissCookie() {
            return document.cookie.split(';').some(function (c) {
                return c.trim().indexOf(DISMISS_COOKIE + '=') === 0;
            });
        }

        function setDismissCookie() {
            var d = new Date();
            d.setTime(d.getTime() + dismissDays * 24 * 60 * 60 * 1000);
            document.cookie = DISMISS_COOKIE + '=1; expires=' + d.toUTCString()
                + '; path=/; SameSite=Lax' + (location.protocol === 'https:' ? '; Secure' : '');
        }

        // اگر بازدیدکننده قبلاً بسته است، اصلاً چیزی نشان نده و از DOM بردار.
        // تریگرِ موبایل هم باید برود، وگرنه نوارِ چسبانِ بی‌کار روی همه‌ی صفحات می‌ماند.
        if (hasDismissCookie()) {
            $box.remove();
            $('.flm-mobile-bar, .flm-mobile-icon').remove();
            return;
        }

        // v3.22.136: مقدارِ قابلِ تنظیم. توجه: از || استفاده نمی‌کنیم چون ۰ (یعنی «هیچ‌وقت بسته نشو»)
        // را به ۶۰ تبدیل می‌کرد. ۰ یا منفی = بدونِ شمارنده و بدونِ بسته‌شدنِ خودکار.
        var countdownSeconds = (farazsmsLeadMagnet.countdownSeconds != null) ? parseInt(farazsmsLeadMagnet.countdownSeconds, 10) : 60;
        if (isNaN(countdownSeconds)) { countdownSeconds = 60; }
        var currentSeconds = countdownSeconds;
        var $countdownMinutes = $box.find('.countdown-minutes');
        var $countdownSeconds = $box.find('.countdown-seconds');
        var $progressCircle = $box.find('.countdown-circle-progress');
        var countdownInterval = null;
        var isClosed = false;
        var totalSeconds = countdownSeconds;
        var circumference = 2 * Math.PI * 45; // radius = 45
        var initialOffset = circumference;

        // Set initial stroke-dashoffset
        $progressCircle.css('stroke-dashoffset', initialOffset);

        /**
         * Format time as MM:SS
         */
        // v3.22.104: تبدیلِ ارقامِ لاتین به فارسی تا شمارنده با مبلغِ (فارسیِ) لید مگنت هماهنگ باشد
        // (قبلاً مبلغ ۵۰,۰۰۰ فارسی بود ولی شمارنده 00:42 لاتین — ناهماهنگیِ ظاهری).
        function toFaDigits(str) {
            var fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
            return String(str).replace(/[0-9]/g, function (d) { return fa[+d]; });
        }
        function formatTime(seconds) {
            var mins = Math.floor(seconds / 60);
            var secs = seconds % 60;
            return {
                minutes: toFaDigits(mins.toString().padStart(2, '0')),
                seconds: toFaDigits(secs.toString().padStart(2, '0'))
            };
        }

        /**
         * Update countdown display
         */
        function updateCountdown() {
            if (currentSeconds <= 0) {
                closeBox();
                return;
            }

            var time = formatTime(currentSeconds);
            $countdownMinutes.text(time.minutes);
            $countdownSeconds.text(time.seconds);

            // Update progress circle
            var progress = (totalSeconds - currentSeconds) / totalSeconds;
            var offset = initialOffset - (progress * circumference);
            $progressCircle.css('stroke-dashoffset', offset);

            currentSeconds--;
        }

        /**
         * Start countdown timer
         */
        function startCountdown() {
            // v3.22.136: ۰ یا کمتر = بدونِ بسته‌شدنِ خودکار (شمارنده اجرا نمی‌شود، باکس باز می‌مانَد).
            if (countdownSeconds <= 0) {
                return;
            }
            if (countdownInterval) {
                clearInterval(countdownInterval);
            }

            // Update immediately
            updateCountdown();

            // Update every second
            countdownInterval = setInterval(function() {
                updateCountdown();
            }, 1000);
        }

        /**
         * Close the box
         */
        function closeBox(persist) {
            if (isClosed) {
                return;
            }

            isClosed = true;

            // فقط وقتی بازدیدکننده **خودش** بست، ماندگار می‌شود. پایانِ شمارنده بستنِ
            // خودکار است و نباید به‌عنوانِ «نمی‌خواهم» تفسیر شود.
            if (persist) {
                setDismissCookie();
            }

            // Clear countdown
            if (countdownInterval) {
                clearInterval(countdownInterval);
                countdownInterval = null;
            }

            // Add closing class for animation
            $box.addClass('closing');

            // Remove box after animation
            setTimeout(function() {
                $box.remove();
            }, 300);
        }

        /**
         * Handle close button click
         */
        $box.find('.farazsms-lead-magnet-close').on('click', function(e) {
            e.preventDefault();
            closeBox(true);
        });

        /**
         * Handle CTA button click - redirect to selected page (or login/register fallback)
         */
        $box.find('.lead-magnet-cta-button').on('click', function(e) {
            e.preventDefault();
            // v3.21.20: در پیش‌نمایشِ مدیر، دکمه ریدایرکت نمی‌کند (مدیر لاگین است و ریدایرکت
            // به ورود → بازگشت به خانه → نمایشِ دوباره‌ی پاپ‌آپ، لوپِ رفرش می‌ساخت). مدیر برای
            // مدیریت از لینکِ «تنظیماتِ لید مگنت» در یادداشتِ بالای باکس استفاده می‌کند.
            if (farazsmsLeadMagnet && farazsmsLeadMagnet.isAdminPreview === '1') {
                return;
            }
            var redirectUrl = (farazsmsLeadMagnet && farazsmsLeadMagnet.redirectUrl)
                ? farazsmsLeadMagnet.redirectUrl
                : window.location.origin + '/wp-login.php';
            // پس از ورود، کاربر به همان صفحه‌ای که بود برگردد (نه حساب کاربری).
            if (farazsmsLeadMagnet && farazsmsLeadMagnet.returnToCurrent === '1') {
                var here = encodeURIComponent(window.location.href);
                var sep = redirectUrl.indexOf('?') === -1 ? '?' : '&';
                redirectUrl += sep + 'back_url=' + here + '&redirect_to=' + here;
            }
            // حالت پاپ‌آپ: فرم ورود را در یک مودال نشان بده و بعد از ورود همان صفحه را تازه کن.
            if (farazsmsLeadMagnet && farazsmsLeadMagnet.ctaAction === 'popup') {
                openLeadMagnetLoginPopup(redirectUrl);
                return;
            }
            // باز شدن در تب جدید (در حالت ریدایرکت).
            if (farazsmsLeadMagnet && farazsmsLeadMagnet.openInNewTab === '1') {
                window.open(redirectUrl, '_blank', 'noopener');
                return;
            }
            window.location.href = redirectUrl;
        });

        /**
         * نمایش فرمِ ورود/ثبت‌نامِ خودِ افزونه در یک مودال (نه iframe).
         * مودال از قبل سمتِ سرور رندر شده (#farazsms-lm-login-modal) و شاملِ
         * شورت‌کدِ [farazsms_login_form] است. اگر موجود نباشد (افزونه‌ی ورود فعال
         * نیست) به ریدایرکت برمی‌گردیم.
         */
        function openLeadMagnetLoginPopup(url) {
            var modal = document.getElementById('farazsms-lm-login-modal');
            if (!modal) {
                // افزونه‌ی ورود/ثبت‌نام فعال نیست → رفتارِ ریدایرکت.
                window.location.href = url;
                return;
            }
            // پاپ‌آپِ پیشنهادِ اعتبار (لید مگنت) را ببند تا تو در تو نشود.
            var lmBox = document.querySelector('.farazsms-lead-magnet-box');
            if (lmBox) { lmBox.style.display = 'none'; }

            modal.style.display = 'flex';
            // v3.22.133: قفلِ اسکرولِ درست — از ابزارِ مشترکِ موتور (ref-counted، ذخیره/بازگردانی).
            // باگِ قبلی: overflow را در بستن به '' برمی‌گرداند و overflowِ اینلاینِ قالب را نابود می‌کرد.
            // fallback (اگر موتور نبود): مقدارِ قبلی را ذخیره و دقیقاً همان را برگردان.
            var usedEngineLock = false;
            var prevHtmlOverflow = document.documentElement.style.overflow;
            if (window.FarazOverlay && typeof window.FarazOverlay.lockScroll === 'function') {
                window.FarazOverlay.lockScroll();
                usedEngineLock = true;
            } else {
                document.documentElement.style.overflow = 'hidden';
            }

            function close() {
                // کدریویو v3.22.152: (۱) بدونِ گاردِ «باز است؟»، هر فراخوانیِ دومِ close یک
                // unlockScrollِ بی‌جفت می‌زد و قفلِ اسکرولِ اورلیِ دیگری را باز می‌کرد.
                // (۲) باکسِ لیدمگنت هنگامِ بازکردنِ مودال مخفی می‌شد ولی هرگز برنمی‌گشت؛
                // کاربری که پشیمان می‌شد، پیشنهادِ اعتبار را تا رفرشِ صفحه از دست می‌داد.
                if (modal.style.display === 'none') { return; }
                modal.style.display = 'none';
                if (usedEngineLock) { window.FarazOverlay.unlockScroll(); }
                else { document.documentElement.style.overflow = prevHtmlOverflow; }
                if (lmBox) { lmBox.style.display = ''; }
            }
            var closeBtn = modal.querySelector('.flm-close');
            if (closeBtn && !closeBtn._flmBound) {
                closeBtn._flmBound = true;
                closeBtn.addEventListener('click', close);
            }
            if (!modal._flmBound) {
                modal._flmBound = true;
                modal.addEventListener('click', function(e) { if (e.target === modal) { close(); } });
            }
        }

        /**
         * تریگرِ موبایل (دکمه‌ی چسبانِ پایین یا آیکونِ گوشه).
         * در حالت‌های bar/icon، باکس تا کلیکِ تریگر با CSS مخفی است. با کلیک:
         * باکس باز می‌شود (کلاسِ flm-mobile-open)، تریگر مخفی می‌شود و شمارش آغاز می‌شود.
         */
        var $mobileTrigger = $('.flm-mobile-bar, .flm-mobile-icon');
        if ($mobileTrigger.length) {
            var barTimerInterval = null;

            $mobileTrigger.on('click', function(e) {
                e.preventDefault();
                if (barTimerInterval) { clearInterval(barTimerInterval); barTimerInterval = null; }
                // کلاس (نه .hide) چون رولِ media با !important است و inlineِ غیر-important را می‌بازد.
                $mobileTrigger.addClass('flm-trigger-hidden');
                $box.addClass('flm-mobile-open');
                // پس از نمایشِ باکس، شمارشِ معکوسِ اصلی را شروع کن.
                if (!isClosed) { startCountdown(); }
            });

            // شمارشِ معکوسِ کوچک روی دکمه‌ی چسبان (نمایشی، برای ایجادِ حسِ فوریت).
            var $barTimer = $('.flm-bar-timer');
            if ($barTimer.length) {
                var barLeft = countdownSeconds;
                var renderBar = function() {
                    var t = formatTime(Math.max(barLeft, 0));
                    $barTimer.text(t.minutes + ':' + t.seconds);
                };
                renderBar();
                barTimerInterval = setInterval(function() {
                    barLeft--;
                    if (barLeft < 0) { clearInterval(barTimerInterval); barTimerInterval = null; return; }
                    renderBar();
                }, 1000);
            }
        }

        /**
         * v3.22.133 (تیکت T2/T4): زمانِ نمایشِ باکس. اگر تریگرِ «تأخیر/اسکرول» ست شده باشد، باکس با
         * data-flm-trigger="pending" از ابتدا پنهان است (CSS)، و با شلیکِ تریگرِ موتورِ اورلیِ مشترک
         * آشکار می‌شود و شمارش آغاز می‌گردد — تا بارگذاریِ اولیه سبک بماند (LCP). در حالتِ فوری یا اگر
         * موتور در دسترس نباشد، همان رفتارِ قبلی: نمایشِ فوری.
         */
        var lmTrigger = (farazsmsLeadMagnet && farazsmsLeadMagnet.displayTrigger) || 'immediate';
        function lmRevealAndStart() {
            $box.attr('data-flm-trigger', 'shown');
            if (!isClosed && $box.is(':visible')) { startCountdown(); }
        }
        if (lmTrigger !== 'immediate' && $box.attr('data-flm-trigger') === 'pending'
            && window.FarazOverlay && typeof window.FarazOverlay.onTrigger === 'function') {
            window.FarazOverlay.onTrigger(
                { type: lmTrigger, value: (farazsmsLeadMagnet && farazsmsLeadMagnet.displayTriggerValue) },
                lmRevealAndStart
            );
        } else {
            // فوری، یا موتور در دسترس نیست → اگر pending بود آشکارش کن و مثلِ قبل شروع کن.
            if ($box.attr('data-flm-trigger') === 'pending') { $box.attr('data-flm-trigger', 'shown'); }
            if ($box.is(':visible')) { startCountdown(); }
        }

        // Handle page visibility change (pause/resume countdown)
        document.addEventListener('visibilitychange', function() {
            if (document.hidden) {
                // Page is hidden, pause countdown
                if (countdownInterval) {
                    clearInterval(countdownInterval);
                    countdownInterval = null;
                }
            } else {
                // Page is visible, resume countdown if not closed
                if (!isClosed && $box.is(':visible')) {
                    startCountdown();
                }
            }
        });
    });

})(jQuery);

