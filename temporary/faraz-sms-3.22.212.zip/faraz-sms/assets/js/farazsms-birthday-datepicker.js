/**
 * راه‌اندازیِ تقویمِ جلالیِ پاپ‌آپ (kamaDatePicker) روی فیلدهای تاریخ تولد.
 *
 * هر <input> با کلاسِ .farazsms-birthday-datepicker یک تقویمِ شمسیِ بازشو می‌گیرد.
 * خروجی به‌شکلِ YYYY/MM/DD است که پارسرِ سمتِ سرور (farazsms_birthday_parse_jalali_input)
 * می‌پذیرد. کاربر می‌تواند هم از تقویم انتخاب کند و هم دستی تایپ کند.
 *
 * چک‌اوتِ بلوکی و صفحاتِ AJAXـی فیلد را دیرتر می‌سازند، پس بعد از رویدادهای
 * به‌روزرسانی و با یک تاخیرِ کوتاه دوباره init می‌کنیم (idempotent با data-flag).
 */
( function () {
	'use strict';

	function initOne( el ) {
		if ( ! el || el.getAttribute( 'data-fbd-init' ) === '1' ) {
			return;
		}
		if ( typeof window.kamaDatepicker !== 'function' ) {
			return;
		}
		if ( ! el.id ) {
			var now = ( window.performance && window.performance.now ) ? window.performance.now() : ( new Date() ).getTime();
			el.id = 'fbd-' + Math.floor( ( 1 + now ) * 1000 ) + '-' + ( fbdCounter++ );
		}
		el.setAttribute( 'data-fbd-init', '1' );
		el.setAttribute( 'autocomplete', 'off' );

		window.kamaDatepicker( el.id, {
			buttonsColor: '#2271b1',
			forceFarsiDigits: true,
			twodigit: true,
			closeAfterSelect: true,
			gotoToday: false,
			markToday: true,
			highlightSelectedDay: true,
			pastYearsCount: 100,   // تا ~۱۰۰ سالِ قبل → پوششِ همه‌ی سال‌های تولد
			futureYearsCount: 0,   // تاریخ تولد در آینده معنا ندارد
			placeholder: el.getAttribute( 'placeholder' ) || 'تاریخ تولد را انتخاب کنید'
		} );
	}

	var fbdCounter = 0;

	function initAll() {
		var nodes = document.querySelectorAll( '.farazsms-birthday-datepicker' );
		for ( var i = 0; i < nodes.length; i++ ) {
			initOne( nodes[ i ] );
		}
	}

	function boot() {
		initAll();
		// چک‌اوتِ بلوکی/AJAX دیرتر رندر می‌شود؛ چند تلاشِ کوتاه بدونِ حلقه‌ی بی‌پایان.
		var tries = 0;
		var t = window.setInterval( function () {
			initAll();
			if ( ++tries >= 6 ) {
				window.clearInterval( t );
			}
		}, 700 );
	}

	if ( document.readyState !== 'loading' ) {
		boot();
	} else {
		document.addEventListener( 'DOMContentLoaded', boot );
	}

	// رویدادهای ووکامرس (چک‌اوتِ کلاسیک AJAX + بلوکی) → دوباره init.
	if ( window.jQuery ) {
		window.jQuery( document.body ).on( 'updated_checkout updated_wc_div init_checkout', initAll );
	}
} )();
