/**
 * بلاکِ گوتنبرگِ «دکمه‌ی حساب فراز» — بدونِ build، با globalهای wp.
 * سرور-رندر است: پیش‌نمایشِ ویرایشگر از ServerSideRender می‌آید.
 */
( function ( blocks, element, blockEditor, components, serverSideRender, i18n ) {
	'use strict';

	var el = element.createElement;
	var InspectorControls = blockEditor.InspectorControls;
	var PanelBody = components.PanelBody;
	var SelectControl = components.SelectControl;
	var TextControl = components.TextControl;
	var ToggleControl = components.ToggleControl;
	var ServerSideRender = serverSideRender;

	blocks.registerBlockType( 'farazsms/account-button', {
		apiVersion: 2,
		title: 'دکمه‌ی حساب فراز',
		description: 'دکمه‌ی هوشمندِ ورود/حساب که با وضعیتِ لاگین عوض می‌شود.',
		icon: 'admin-users',
		category: 'widgets',
		keywords: [ 'account', 'login', 'حساب', 'ورود', 'faraz' ],
		supports: { align: [ 'left', 'center', 'right' ] },
		attributes: {
			preset: { type: 'string', default: '' },
			guestLabel: { type: 'string', default: '' },
			showIcon: { type: 'boolean', default: true },
			align: { type: 'string', default: '' }
		},

		edit: function ( props ) {
			var attrs = props.attributes;

			var inspector = el(
				InspectorControls,
				{},
				el(
					PanelBody,
					{ title: 'تنظیماتِ دکمه', initialOpen: true },
					el( TextControl, {
						label: 'متنِ حالتِ خروج',
						value: attrs.guestLabel,
						placeholder: 'ورود و ثبت‌نام',
						onChange: function ( v ) { props.setAttributes( { guestLabel: v } ); }
					} ),
					el( SelectControl, {
						label: 'استایل',
						value: attrs.preset,
						options: [
							{ label: 'پیش‌فرضِ تنظیمات', value: '' },
							{ label: 'پُر', value: 'default' },
							{ label: 'خط‌دار', value: 'outline' },
							{ label: 'قرصی', value: 'pill' },
							{ label: 'ساده', value: 'minimal' }
						],
						onChange: function ( v ) { props.setAttributes( { preset: v } ); }
					} ),
					el( ToggleControl, {
						label: 'نمایشِ آیکون',
						checked: !! attrs.showIcon,
						onChange: function ( v ) { props.setAttributes( { showIcon: v } ); }
					} )
				)
			);

			var preview = el( ServerSideRender, {
				block: 'farazsms/account-button',
				attributes: {
					preset: attrs.preset,
					guestLabel: attrs.guestLabel,
					showIcon: attrs.showIcon,
					align: attrs.align
				}
			} );

			return el( 'div', {}, inspector, preview );
		},

		save: function () {
			return null; // سرور-رندر.
		}
	} );
} )(
	window.wp.blocks,
	window.wp.element,
	window.wp.blockEditor,
	window.wp.components,
	window.wp.serverSideRender,
	window.wp.i18n
);
