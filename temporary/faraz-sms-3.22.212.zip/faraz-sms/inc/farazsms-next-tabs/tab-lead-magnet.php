<?php
/**
 * Lead Magnet Tab Content
 *
 * @var FarazSMS_Next_Admin_Page $this
 */

if (!defined('ABSPATH')) {
    exit;
}

// Get saved settings (defaults: enabled on)
$settings        = farazsms_next_get_lead_magnet_settings();
// در v3.13.11 پیش‌فرض «فعال» تضمین شد — اگر option وجود ندارد یا key مفقود است، '1' برمی‌گرداند.
// v3.22.3 رفعِ باگ: دکمه در پنل ادمین «فعال» می‌ماند در حالی که در دیتابیس خاموش است.
// علت: مقدارِ enabledِ toggle از نتیجه‌ی merge با default ('1') یا از کشِ آبجکتِ کهنه خوانده
// می‌شد، ولی گیتِ فرانت‌اند مقدارِ خام را می‌خواند — پس اختلاف پیدا می‌کردند. راهِ درست:
// toggle باید «تک‌منبعِ حقیقتِ گیت» را نشان دهد؛ یعنی همان مقدارِ خامِ ذخیره‌شده در option،
// دقیقاً مثلِ farazsms_next_lead_magnet_should_display(). حالا اگر مدیر خاموش کرد، دکمه هم خاموش.
// v3.22.73: پیش‌فرض «خاموش» (opt-in) و هم‌راستا با گیتِ فرانت‌اند — دکمه فقط وقتی روشن نشان داده
// می‌شود که مدیر صریحاً enabled='1' را ذخیره کرده باشد؛ نبودِ تنظیمات = خاموش. مقدارِ خام خوانده
// می‌شود تا دکمه بعد از ذخیره دقیقاً وضعیتِ واقعی را نشان دهد.
$lm_raw_opt      = get_option( 'farazsms_next_lead_magnet_settings', null );
$enabled         = ( is_array( $lm_raw_opt ) && isset( $lm_raw_opt['enabled'] ) && $lm_raw_opt['enabled'] === '1' )
	? '1'
	: '0';
// v3.13.15: پیش‌فرض ۵۰,۰۰۰ تومان اعتبار + ۳ روز مهلت — تا کاربر بدون پیکربندی هم
// تجربه‌ای کارا داشته باشد. helper هم همین پیش‌فرض‌ها را برمی‌گرداند.
$credit_amount   = isset($settings['credit_amount']) && $settings['credit_amount'] !== '' ? $settings['credit_amount'] : 50000;
$expiry_days     = isset($settings['expiry_days']) && $settings['expiry_days'] !== '' ? $settings['expiry_days'] : 3;
$display_position = isset($settings['display_position']) ? $settings['display_position'] : 'bottom-right';
$display_location = isset($settings['display_location']) ? $settings['display_location'] : 'everywhere';
$display_pages    = array_filter(array_map('absint', explode(',', (string) (isset($settings['display_pages']) ? $settings['display_pages'] : ''))));
// v3.13.16: اگر کاربر صفحه‌ای انتخاب نکرده، my-account ووکامرس را به‌صورت
// پیش‌فرض پیشنهاد می‌دهیم (طبیعی‌ترین جای ثبت‌نام در فروشگاه).
$target_page_id   = isset($settings['target_page_id']) ? absint($settings['target_page_id']) : 0;
$target_custom_url = isset($settings['target_custom_url']) ? (string) $settings['target_custom_url'] : '';
$target_in_new_tab = isset($settings['target_in_new_tab']) ? $settings['target_in_new_tab'] : '0';
if ( $target_page_id === 0 && function_exists( 'wc_get_page_id' ) ) {
	$wc_myaccount_id = (int) wc_get_page_id( 'myaccount' );
	if ( $wc_myaccount_id > 0 ) {
		$target_page_id = $wc_myaccount_id;
	}
}
$shop_name       = isset($settings['shop_name']) && !empty($settings['shop_name']) ? $settings['shop_name'] : get_bloginfo('name');
?>

<?php
// v3.22.51: نمایشِ پیامِ موفقیتِ ذخیره. قبلاً بعد از ذخیره هیچ بازخوردی نبود (فقط ریلود با
// settings-updated=true) — کاربر نمی‌فهمید ذخیره شده و گمان می‌کرد «دکمهٔ ذخیره کار نمی‌کند».
if ( isset( $_GET['settings-updated'] ) && $_GET['settings-updated'] === 'true' ) :
	?>
	<div class="notice notice-success is-dismissible" style="margin: 0 0 18px;">
		<p><strong><?php esc_html_e( 'تنظیماتِ لید مگنت با موفقیت ذخیره شد.', 'farazsms-next' ); ?></strong></p>
	</div>
	<?php
endif;
?>

<!-- تب‌های افقیِ لید مگنت -->
<div class="fz-lm-tabnav" style="display:flex; gap:6px; border-bottom:2px solid #e1e1e1; margin-bottom:20px; flex-wrap:wrap;">
    <button type="button" class="fz-lm-tab-btn is-active" data-pane="main" style="background:none; border:none; border-bottom:2px solid transparent; margin-bottom:-2px; padding:10px 18px; font-size:13.5px; font-weight:700; color:#365891; cursor:pointer; font-family:inherit;">⚙️ <?php esc_html_e('تنظیمات لید مگنت', 'farazsms-next'); ?></button>
    <button type="button" class="fz-lm-tab-btn" data-pane="responsive" style="background:none; border:none; border-bottom:2px solid transparent; margin-bottom:-2px; padding:10px 18px; font-size:13.5px; font-weight:600; color:#9b9b9b; cursor:pointer; font-family:inherit;">📱 <?php esc_html_e('ریسپانسیو', 'farazsms-next'); ?></button>
    <button type="button" class="fz-lm-tab-btn" data-pane="reminder" style="background:none; border:none; border-bottom:2px solid transparent; margin-bottom:-2px; padding:10px 18px; font-size:13.5px; font-weight:600; color:#9b9b9b; cursor:pointer; font-family:inherit;">⏰ <?php esc_html_e('یادآورِ هدیه‌ی عضویت', 'farazsms-next'); ?></button>
</div>

<div class="fz-lm-pane" data-pane="main">
<form method="post" action="" class="fwss_form form-style-2">
        <?php wp_nonce_field('farazsms_next_settings', 'farazsms_next_settings_nonce'); ?>
        <input type="hidden" name="current_tab" value="lead-magnet">

        <div class="fz-lm-sub" data-sub="main">

        <!-- v3.22.6: هیروِ شلوغ حذف شد؛ یک راهنمای کوتاه و ضروری جایش آمد. -->
        <div style="background:#f0f9ff; border:1px solid #bae6fd; border-radius:10px; padding:12px 16px; margin-bottom:18px; font-size:12.5px; color:#0c4a6e; line-height:1.9;">
            🎁 <strong><?php esc_html_e( 'لید مگنت', 'farazsms-next' ); ?></strong>
            <?php esc_html_e( 'یک پنجره‌ی کوچک در گوشه‌ی سایت است که به بازدیدکننده در ازای شماره موبایل، اعتبار هدیه می‌دهد.', 'farazsms-next' ); ?>
            <br>
            👁️ <strong><?php esc_html_e( 'برای دیدنِ آن، از حالتِ ناشناس (incognito) یا خروج از حساب استفاده کنید', 'farazsms-next' ); ?></strong>
            — <?php esc_html_e( 'لید مگنت فقط به بازدیدکنندگانِ واردنشده نمایش داده می‌شود، نه به شمای مدیر که وارد شده‌اید.', 'farazsms-next' ); ?>
        </div>

        <label for="lead_magnet_enabled" class="toggle-control" style="display: flex; align-items: center; gap: 12px; padding: 14px 18px; background: <?php echo $enabled === '1' ? '#e2f8f0' : '#faf1da'; ?>; border: 1px solid <?php echo $enabled === '1' ? '#10c282' : '#e2a916'; ?>; border-radius: 10px;">
            <span class="label" style="margin: 0; font-size: 14px; font-weight: 600; flex: 1;">
                <?php _e('فعال بودن نمایش لید مگنت روی صفحه اول سایت', 'farazsms-next'); ?>
                <?php if ( $enabled === '1' ) : ?>
                    <span style="display: inline-block; background: #0c9765; color: #fff; font-size: 10px; padding: 2px 8px; border-radius: 4px; margin-right: 8px; font-weight: 700;">فعال ✓</span>
                <?php else : ?>
                    <span style="display: inline-block; background: #e2a916; color: #fff; font-size: 10px; padding: 2px 8px; border-radius: 4px; margin-right: 8px; font-weight: 700;">غیرفعال</span>
                <?php endif; ?>
            </span>
            <input type="checkbox"
                   name="lead_magnet_enabled"
                   id="lead_magnet_enabled"
                   value="1"
                   <?php checked($enabled, '1'); ?>>
            <span class="control"></span>
        </label>
        <br><br>

        <label>
            <span class="label"><?php _e('نام فروشگاه', 'farazsms-next'); ?></span>
            <input type="text" 
                   name="lead_magnet_shop_name" 
                   id="lead_magnet_shop_name"
                   class="input-field"
                   value="<?php echo esc_attr($shop_name); ?>"
                   placeholder="<?php echo esc_attr(get_bloginfo('name')); ?>">
            <small class="description" style="display:block;margin-top:4px;">
                <?php _e('نام فروشگاه که در لید مگنت نمایش داده می‌شود.', 'farazsms-next'); ?>
            </small>
        </label>
        <br><br>

        <label>
            <span class="label"><?php _e('مقدار اعتبار عضویت (تومان)', 'farazsms-next'); ?><span class="required">*</span></span>
            <input type="number" 
                   name="lead_magnet_credit_amount" 
                   id="lead_magnet_credit_amount"
                   class="input-field"
                   value="<?php echo esc_attr($credit_amount); ?>"
                   placeholder="<?php _e('مثلاً 5000', 'farazsms-next'); ?>"
                   min="0"
                   step="1"
                   required>
        </label>
        <br><br>

        <label>
            <span class="label"><?php _e('مهلت استفاده (روز)', 'farazsms-next'); ?><span class="required">*</span></span>
            <input type="number" 
                   name="lead_magnet_expiry_days" 
                   id="lead_magnet_expiry_days"
                   class="input-field"
                   value="<?php echo esc_attr($expiry_days); ?>"
                   placeholder="<?php _e('مثلاً 3', 'farazsms-next'); ?>"
                   min="1"
                   step="1"
                   required>
        </label>
        <br><br>

        <!-- v3.13.16: layout fix — <label> تو در تو حذف شد (HTML نامعتبر و در RTL خراب می‌شد).
             حالا div container + label های مستقل + flexbox برای تراز صحیح. -->
        <div class="farazsms-lm-field" style="margin-bottom: 18px;">
            <div class="farazsms-lm-field-label" style="display: block; font-size: 13px; font-weight: 600; color: #4d4d4d; margin-bottom: 8px;">
                <?php _e('محل نمایش لید مگنت', 'farazsms-next'); ?>
            </div>
            <div style="display: flex; gap: 24px; flex-wrap: wrap;">
                <label style="display: inline-flex; align-items: center; gap: 6px; font-weight: normal; cursor: pointer;">
                    <input type="radio"
                           name="lead_magnet_display_position"
                           value="bottom-right"
                           <?php checked($display_position, 'bottom-right'); ?>
                           style="margin: 0;">
                    <span><?php _e('پایین راست', 'farazsms-next'); ?></span>
                </label>
                <label style="display: inline-flex; align-items: center; gap: 6px; font-weight: normal; cursor: pointer;">
                    <input type="radio"
                           name="lead_magnet_display_position"
                           value="bottom-left"
                           <?php checked($display_position, 'bottom-left'); ?>
                           style="margin: 0;">
                    <span><?php _e('پایین چپ', 'farazsms-next'); ?></span>
                </label>
            </div>
        </div>

        <!-- محل نمایش در سایت -->
        <div class="farazsms-lm-field" style="margin-bottom: 18px;">
            <div class="farazsms-lm-field-label" style="display: block; font-size: 13px; font-weight: 600; color: #4d4d4d; margin-bottom: 8px;">
                <?php _e('در کدام صفحات نمایش داده شود؟', 'farazsms-next'); ?>
            </div>
            <div style="display: flex; gap: 22px; flex-wrap: wrap;">
                <?php
                $loc_options = array(
                    'everywhere' => __('همه‌ی صفحات سایت (پیش‌فرض)', 'farazsms-next'),
                    'home'       => __('فقط صفحه اصلی', 'farazsms-next'),
                    'blog'       => __('بلاگ (نوشته‌ها و آرشیوها)', 'farazsms-next'),
                    'specific'   => __('فقط برگه‌های انتخاب‌شده', 'farazsms-next'),
                );
                foreach ($loc_options as $loc_val => $loc_label) :
                    ?>
                    <label style="display: inline-flex; align-items: center; gap: 6px; font-weight: normal; cursor: pointer;">
                        <input type="radio"
                               name="lead_magnet_display_location"
                               value="<?php echo esc_attr($loc_val); ?>"
                               class="farazsms-lm-location-radio"
                               <?php checked($display_location, $loc_val); ?>
                               style="margin: 0;">
                        <span><?php echo esc_html($loc_label); ?></span>
                    </label>
                <?php endforeach; ?>
            </div>

            <div id="farazsms-lm-specific-pages" style="margin-top: 12px; <?php echo $display_location === 'specific' ? '' : 'display:none;'; ?>">
                <label for="lead_magnet_display_pages" style="display: block; font-size: 12.5px; font-weight: 600; color: #4d4d4d; margin-bottom: 6px;">
                    <?php _e('برگه‌ها را انتخاب کنید (چند انتخابی با Ctrl/Cmd):', 'farazsms-next'); ?>
                </label>
                <select name="lead_magnet_display_pages[]" id="lead_magnet_display_pages" multiple size="6" style="max-width: 380px; width: 100%; border-radius: 8px;">
                    <?php
                    $all_pages = get_pages(array('sort_column' => 'post_title', 'sort_order' => 'ASC'));
                    foreach ($all_pages as $p) {
                        printf(
                            '<option value="%d"%s>%s</option>',
                            absint($p->ID),
                            in_array((int) $p->ID, $display_pages, true) ? ' selected' : '',
                            esc_html($p->post_title)
                        );
                    }
                    ?>
                </select>
            </div>
            <p class="description" style="margin: 6px 0 0; font-size: 12px; color: #9b9b9b;">
                <?php _e('پیش‌فرض: همه‌ی صفحات سایت. می‌توانید نمایش را به صفحه اصلی، بلاگ، یا برگه‌های خاص محدود کنید.', 'farazsms-next'); ?>
            </p>
        </div>
        <script>
        (function(){
            var radios = document.querySelectorAll('.farazsms-lm-location-radio');
            var box = document.getElementById('farazsms-lm-specific-pages');
            function sync(){
                var v = document.querySelector('.farazsms-lm-location-radio:checked');
                if (box) box.style.display = (v && v.value === 'specific') ? '' : 'none';
            }
            radios.forEach(function(r){ r.addEventListener('change', sync); });
        })();
        </script>

        <!-- v3.22.6: فیلدهای کم‌استفاده در آکاردئونِ «پیشرفته» جمع شدند تا نمای اصلی ساده بماند. -->
        <details class="farazsms-lm-advanced" style="margin: 8px 0 18px; border:1px solid #e1e1e1; border-radius:10px; padding: 2px 14px; background:#fafafa;">
        <summary style="cursor:pointer; font-size:13px; font-weight:700; color:#4d4d4d; padding:12px 0;">⚙️ <?php esc_html_e('تنظیماتِ پیشرفته (اختیاری)', 'farazsms-next'); ?></summary>
        <div style="padding-top:6px;">

        <div class="farazsms-lm-field" style="margin-bottom: 18px;">
            <label style="display:inline-flex; align-items:center; gap:10px; font-size:13px; font-weight:600; color:#4d4d4d; cursor:pointer;">
                <input type="checkbox" class="farazsms-toggle" name="lead_magnet_return_to_current" value="1" <?php checked( ( isset($settings['return_to_current']) ? $settings['return_to_current'] : '1' ), '1' ); ?>>
                <?php _e('پس از ورود، کاربر به همان صفحه‌ای که بود بازگردد', 'farazsms-next'); ?>
            </label>
            <p class="description" style="margin: 6px 0 0; font-size: 12px; color: #9b9b9b;">
                <?php _e('وقتی روشن است، کاربر بعد از ورود به جای صفحه‌ی حساب کاربری، به همان صفحه‌ای که روی آن بود برمی‌گردد.', 'farazsms-next'); ?>
            </p>
        </div>

        <div class="farazsms-lm-field" style="margin-bottom: 18px;">
            <label style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:6px;">
                <?php _e('پس از بستن توسط بازدیدکننده، تا چند روز دوباره نمایش داده نشود؟', 'farazsms-next'); ?>
            </label>
            <input type="number" name="lead_magnet_dismiss_days" min="1" max="365" value="<?php echo esc_attr( (int) ( isset($settings['dismiss_days']) ? $settings['dismiss_days'] : 30 ) ); ?>" style="width:120px; padding:8px 12px; border:1px solid #e1e1e1; border-radius:6px; direction:ltr; text-align:center;">
            <span style="font-size:12px; color:#9b9b9b;"> روز</span>
            <p class="description" style="margin: 6px 0 0; font-size: 12px; color: #9b9b9b;">
                <?php _e('اگر بازدیدکننده باکس را ببندد، تا این تعداد روز با کوکی برایش نمایش داده نمی‌شود. پیش‌فرض: ۳۰ روز.', 'farazsms-next'); ?>
            </p>
        </div>

        <?php // v3.22.133 (تیکت T2/T4): زمانِ نمایشِ باکس — فوری/بعد از چند ثانیه/بعد از اسکرول (بهبودِ LCP).
              $lm_trigger     = isset($settings['display_trigger']) ? $settings['display_trigger'] : 'immediate';
              $lm_trigger_val = isset($settings['display_trigger_value']) ? (int) $settings['display_trigger_value'] : 3; ?>
        <div class="farazsms-lm-field" style="margin-bottom: 18px;">
            <label style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:6px;">
                <?php _e('زمانِ نمایشِ باکس (برای سبک‌تر شدنِ بارگذاریِ اولیه / بهبودِ LCP)', 'farazsms-next'); ?>
            </label>
            <select name="lead_magnet_display_trigger" id="lead_magnet_display_trigger" class="select-field" style="max-width:230px; width:100%; border-radius:8px;">
                <option value="immediate" <?php selected($lm_trigger, 'immediate'); ?>><?php esc_html_e('فوری (هنگامِ باز شدنِ صفحه)', 'farazsms-next'); ?></option>
                <option value="delay" <?php selected($lm_trigger, 'delay'); ?>><?php esc_html_e('بعد از چند ثانیه', 'farazsms-next'); ?></option>
                <option value="scroll" <?php selected($lm_trigger, 'scroll'); ?>><?php esc_html_e('بعد از اسکرولِ کاربر', 'farazsms-next'); ?></option>
            </select>
            <span id="lead_magnet_trigger_value_wrap" style="<?php echo $lm_trigger === 'immediate' ? 'display:none;' : ''; ?> margin-inline-start:8px;">
                <input type="number" name="lead_magnet_display_trigger_value" min="1" max="600" value="<?php echo esc_attr($lm_trigger_val); ?>" style="width:90px; padding:8px 12px; border:1px solid #e1e1e1; border-radius:6px; direction:ltr; text-align:center;">
                <span id="lead_magnet_trigger_value_unit" style="font-size:12px; color:#9b9b9b;"><?php echo $lm_trigger === 'scroll' ? esc_html__('درصدِ اسکرول', 'farazsms-next') : esc_html__('ثانیه', 'farazsms-next'); ?></span>
            </span>
            <p class="description" style="margin:6px 0 0; font-size:12px; color:#9b9b9b;">
                <?php _e('باکس بعد از تعدادِ ثانیه یا درصدِ اسکرولِ انتخابی نمایش داده می‌شود؛ تا بارگذاریِ اولیه‌ی صفحه سبک بماند و پاپ‌آپ سرعتِ سایت را کم نکند.', 'farazsms-next'); ?>
            </p>
            <script>
            (function(){
                var sel = document.getElementById('lead_magnet_display_trigger');
                var wrap = document.getElementById('lead_magnet_trigger_value_wrap');
                var unit = document.getElementById('lead_magnet_trigger_value_unit');
                if (!sel || !wrap || !unit) { return; }
                sel.addEventListener('change', function(){
                    wrap.style.display = (sel.value === 'immediate') ? 'none' : '';
                    unit.textContent = (sel.value === 'scroll') ? 'درصدِ اسکرول' : 'ثانیه';
                });
            })();
            </script>
        </div>

        <?php // v3.22.136: زمانِ بسته‌شدنِ خودکارِ باکس (شمارندهٔ معکوس). قبلاً هاردکدِ ۶۰ ثانیه بود و
              // قابلِ تنظیم نبود؛ حالا مدیر می‌تواند مقدار را عوض کند یا ۰ بگذارد تا اصلاً بسته نشود.
              $lm_close = isset($settings['countdown_seconds']) ? (int) $settings['countdown_seconds'] : 60; ?>
        <div class="farazsms-lm-field" style="margin-bottom: 18px;">
            <label style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:6px;">
                <?php _e('بسته‌شدنِ خودکارِ باکس بعد از (ثانیه)', 'farazsms-next'); ?>
            </label>
            <input type="number" name="lead_magnet_countdown_seconds" min="0" max="600" value="<?php echo esc_attr($lm_close); ?>" style="width:120px; padding:8px 12px; border:1px solid #e1e1e1; border-radius:6px; direction:ltr; text-align:center;">
            <span style="font-size:12px; color:#9b9b9b;"> ثانیه</span>
            <p class="description" style="margin:6px 0 0; font-size:12px; color:#9b9b9b;">
                <?php _e('باکس بعد از این تعداد ثانیه به‌طورِ خودکار بسته می‌شود (همان شمارندهٔ معکوسِ روی باکس). عددِ ۰ یعنی هیچ‌وقت خودکار بسته نشود.', 'farazsms-next'); ?>
            </p>
        </div>

        <div class="farazsms-lm-field" style="margin-bottom: 18px;">
            <label style="display:inline-flex; align-items:center; gap:10px; font-size:13px; font-weight:600; color:#4d4d4d; cursor:pointer;">
                <input type="checkbox" class="farazsms-toggle" name="lead_magnet_cta_action" value="popup" <?php checked( ( isset($settings['cta_action']) ? $settings['cta_action'] : 'redirect' ), 'popup' ); ?>>
                <?php _e('نمایش فرم ورود به‌صورت پاپ‌آپ (بدون ترک صفحه)', 'farazsms-next'); ?>
            </label>
            <p class="description" style="margin: 6px 0 0; font-size: 12px; color: #9b9b9b;">
                <?php _e('وقتی روشن است، با کلیک روی دکمه‌ی لید مگنت، فرمِ ورود/ثبت‌نامِ خودِ افزونه در یک پاپ‌آپ روی همان صفحه باز می‌شود تا بازدیدکننده ثبت‌نام کند و اعتبار بگیرد. (در حالت خاموش، کاربر به صفحه‌ی ورود منتقل می‌شود.)', 'farazsms-next'); ?>
                <br><strong style="color:#83620d;">⚠️ این قابلیت نیازمندِ فعال‌بودنِ ماژولِ «ورود و ثبت‌نام» است؛ در غیرِ این صورت دکمه مثلِ حالتِ ریدایرکت عمل می‌کند.</strong>
            </p>
        </div>

        <div class="farazsms-lm-field" style="margin-bottom: 18px;">
            <label for="lead_magnet_target_page_id" style="display: block; font-size: 13px; font-weight: 600; color: #4d4d4d; margin-bottom: 8px;">
                <?php _e('صفحه مقصد دکمه لید مگنت', 'farazsms-next'); ?>
            </label>
            <select name="lead_magnet_target_page_id" id="lead_magnet_target_page_id" class="select-field" style="max-width: 380px; width: 100%;">
                <option value="0"><?php _e('— انتخاب صفحه —', 'farazsms-next'); ?></option>
                <?php
                $pages = get_pages(array('sort_column' => 'post_title', 'sort_order' => 'ASC'));
                foreach ($pages as $page) {
                    printf(
                        '<option value="%d"%s>%s</option>',
                        absint($page->ID),
                        selected($target_page_id, $page->ID, false),
                        esc_html($page->post_title)
                    );
                }
                ?>
            </select>
            <p class="description" style="margin: 6px 0 0; font-size: 12px; color: #9b9b9b;">
                <?php _e('در صورت انتخاب، با کلیک روی دکمه لید مگنت کاربر به این صفحه هدایت می‌شود. پیش‌فرض: صفحه «حساب کاربری» ووکامرس.', 'farazsms-next'); ?>
            </p>

            <label for="lead_magnet_target_custom_url" style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin:14px 0 6px;">
                <?php _e('یا لینک سفارشی (اولویت با این لینک است)', 'farazsms-next'); ?>
            </label>
            <input type="url" name="lead_magnet_target_custom_url" id="lead_magnet_target_custom_url" value="<?php echo esc_attr($target_custom_url); ?>" placeholder="https://example.com/offer" class="input-field" style="max-width:380px; width:100%; padding:8px 12px; border:1px solid #e1e1e1; border-radius:6px; font-size:13px; direction:ltr; text-align:left;">
            <p class="description" style="margin:4px 0 0; font-size:12px; color:#9b9b9b;">
                <?php _e('اگر این فیلد را پر کنید، به‌جای صفحه‌ی بالا، کاربر به این لینک هدایت می‌شود (می‌تواند هر آدرسی، حتی خارج از سایت باشد).', 'farazsms-next'); ?>
            </p>

            <label style="display:inline-flex; align-items:center; gap:10px; font-size:13px; font-weight:600; color:#4d4d4d; margin-top:14px; cursor:pointer;">
                <input type="checkbox" class="farazsms-toggle" name="lead_magnet_target_in_new_tab" value="1" <?php checked( $target_in_new_tab, '1' ); ?>>
                <?php _e('باز شدن در تب جدید', 'farazsms-next'); ?>
            </label>
            <p class="description" style="margin:4px 0 0; font-size:12px; color:#9b9b9b;">
                <?php _e('در حالت «پاپ‌آپ» این گزینه نادیده گرفته می‌شود.', 'farazsms-next'); ?>
            </p>
        </div>

        <!-- v3.17.4: متن‌های قابل تنظیم — کاربر می‌تواند هر متنی که می‌خواهد بنویسد -->
        <div style="background:linear-gradient(135deg, #f0f9ff 0%, #ecfeff 100%); border:1.5px solid #67e8f9; border-radius:12px; padding:18px 22px; margin: 24px 0 18px; direction:rtl;">
            <h3 style="margin:0 0 12px; font-size:14.5px; color:#365891; font-weight:700; display:flex; align-items:center; gap:8px;">
                ✍️ <?php _e('شخصی‌سازی متن لید مگنت', 'farazsms-next'); ?>
            </h3>
            <p style="font-size:12.5px; color:#155e75; line-height:1.7; margin:0 0 14px;">
                <?php _e('هر متن که می‌خواهید بنویسید. متغیرهای قابل استفاده:', 'farazsms-next'); ?>
                <code style="background:#fff; padding:1px 7px; border-radius:4px; font-family:Menlo,Consolas,monospace; color:#365891; direction:ltr; display:inline-block;">{amount}</code>
                <code style="background:#fff; padding:1px 7px; border-radius:4px; font-family:Menlo,Consolas,monospace; color:#365891; direction:ltr; display:inline-block;">{shop}</code>
                <code style="background:#fff; padding:1px 7px; border-radius:4px; font-family:Menlo,Consolas,monospace; color:#365891; direction:ltr; display:inline-block;">{days}</code>
            </p>

            <label style="display:block; margin-bottom:14px;">
                <span class="label" style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:5px;">🔥 <?php _e('متن نشان (badge)', 'farazsms-next'); ?></span>
                <input type="text" name="lead_magnet_badge_text" class="input-field" style="width:100%; padding:9px 12px; border:1px solid #e1e1e1; border-radius:7px;"
                       value="<?php echo esc_attr( isset($settings['badge_text']) ? $settings['badge_text'] : '🔥 فقط امروز' ); ?>"
                       placeholder="🔥 فقط امروز">
            </label>

            <label style="display:block; margin-bottom:14px;">
                <span class="label" style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:5px;">📣 <?php _e('عنوان اصلی', 'farazsms-next'); ?></span>
                <input type="text" name="lead_magnet_title_template" class="input-field" style="width:100%; padding:9px 12px; border:1px solid #e1e1e1; border-radius:7px;"
                       value="<?php echo esc_attr( isset($settings['title_template']) ? $settings['title_template'] : '{amount} تومان هدیه!' ); ?>"
                       placeholder="{amount} تومان هدیه!">
                <small style="display:block; margin-top:3px; color:#9b9b9b; font-size:11px;"><?php _e('پیشنهاد: استفاده از {amount} برای رنگی شدن مقدار.', 'farazsms-next'); ?></small>
            </label>

            <label style="display:block; margin-bottom:14px;">
                <span class="label" style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:5px;">💬 <?php _e('متن توضیح', 'farazsms-next'); ?></span>
                <textarea name="lead_magnet_headline_template" class="input-field" rows="2" style="width:100%; padding:9px 12px; border:1px solid #e1e1e1; border-radius:7px; resize:vertical; line-height:1.8;"
                          placeholder="با عضویت در {shop}، اعتبار رایگان بگیر..."><?php echo esc_textarea( isset($settings['headline_template']) ? $settings['headline_template'] : 'با عضویت در {shop}، اعتبار رایگان بگیر و اولین خریدت رو ارزون‌تر کن.' ); ?></textarea>
            </label>

            <label style="display:block; margin-bottom:14px;">
                <span class="label" style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:5px;">⏰ <?php _e('متن مهلت', 'farazsms-next'); ?></span>
                <input type="text" name="lead_magnet_disclaimer_template" class="input-field" style="width:100%; padding:9px 12px; border:1px solid #e1e1e1; border-radius:7px;"
                       value="<?php echo esc_attr( isset($settings['disclaimer_template']) ? $settings['disclaimer_template'] : '⏰ این هدیه فقط {days} روز اعتبار دارد' ); ?>"
                       placeholder="⏰ این هدیه فقط {days} روز اعتبار دارد">
            </label>

            <label style="display:block;">
                <span class="label" style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:5px;">🎁 <?php _e('متن دکمه', 'farazsms-next'); ?></span>
                <input type="text" name="lead_magnet_cta_text" class="input-field" style="width:100%; padding:9px 12px; border:1px solid #e1e1e1; border-radius:7px;"
                       value="<?php echo esc_attr( isset($settings['cta_text']) ? $settings['cta_text'] : '🎁 دریافت اعتبار هدیه' ); ?>"
                       placeholder="🎁 دریافت اعتبار هدیه">
            </label>
        </div>

        </div><!-- /padding advanced -->
        </details>

        </div><!-- /sub main -->

        <div class="fz-lm-sub" data-sub="responsive" style="display:none;">
            <div style="background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:20px; margin-bottom:18px;">
                <h4 style="margin:0 0 6px; font-size:14.5px; font-weight:700; color:#263f67;">📱 <?php esc_html_e('نمایش در موبایل (ریسپانسیو)', 'farazsms-next'); ?></h4>
                <p style="margin:0 0 16px; font-size:12.5px; color:#9b9b9b; line-height:1.9;"><?php esc_html_e('رفتارِ لید مگنت روی گوشی را تنظیم کنید تا مزاحمِ بازدیدکننده نشود.', 'farazsms-next'); ?></p>

                <label style="display:inline-flex; align-items:center; gap:10px; font-size:13px; font-weight:600; color:#4d4d4d; cursor:pointer;">
                    <input type="checkbox" class="farazsms-toggle" name="lead_magnet_mobile_enabled" value="1" <?php checked( ( isset($settings['mobile_enabled']) ? $settings['mobile_enabled'] : '1' ), '1' ); ?>>
                    <?php esc_html_e('نمایش لید مگنت در موبایل', 'farazsms-next'); ?>
                </label>
                <p style="margin:4px 0 18px; font-size:12px; color:#9b9b9b;"><?php esc_html_e('اگر خاموش باشد، روی موبایل اصلاً نمایش داده نمی‌شود (روی دسکتاپ مثلِ قبل کار می‌کند).', 'farazsms-next'); ?></p>

                <div style="font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:8px;"><?php esc_html_e('نحوه‌ی نمایش در موبایل', 'farazsms-next'); ?></div>
                <?php $ms = isset($settings['mobile_style']) ? $settings['mobile_style'] : 'popup'; ?>
                <div style="display:flex; flex-direction:column; gap:10px; max-width:520px;">
                    <label style="display:flex; align-items:flex-start; gap:8px; cursor:pointer; padding:10px 12px; border:1px solid #e1e1e1; border-radius:8px;">
                        <input type="radio" name="lead_magnet_mobile_style" value="popup" <?php checked($ms,'popup'); ?> style="margin-top:3px;">
                        <span><strong><?php esc_html_e('پاپ‌آپ (پیش‌فرض)', 'farazsms-next'); ?></strong><br><span style="font-size:11.5px;color:#9b9b9b;"><?php esc_html_e('همان پنجره، ولی تمام‌عرض و چسبیده به پایینِ صفحه (bottom sheet).', 'farazsms-next'); ?></span></span>
                    </label>
                    <label style="display:flex; align-items:flex-start; gap:8px; cursor:pointer; padding:10px 12px; border:1px solid #e1e1e1; border-radius:8px;">
                        <input type="radio" name="lead_magnet_mobile_style" value="bar" <?php checked($ms,'bar'); ?> style="margin-top:3px;">
                        <span><strong><?php esc_html_e('دکمه‌ی چسبان به پایینِ صفحه', 'farazsms-next'); ?></strong><br><span style="font-size:11.5px;color:#9b9b9b;"><?php esc_html_e('یک نوارِ باریک با «دریافت اعتبار هدیه» و شمارش‌معکوس؛ با کلیک، باکس باز می‌شود.', 'farazsms-next'); ?></span></span>
                    </label>
                    <label style="display:flex; align-items:flex-start; gap:8px; cursor:pointer; padding:10px 12px; border:1px solid #e1e1e1; border-radius:8px;">
                        <input type="radio" name="lead_magnet_mobile_style" value="icon" <?php checked($ms,'icon'); ?> style="margin-top:3px;">
                        <span><strong><?php esc_html_e('آیکونِ هدیه در گوشه‌ی صفحه', 'farazsms-next'); ?></strong><br><span style="font-size:11.5px;color:#9b9b9b;"><?php esc_html_e('یک آیکونِ کوچکِ 🎁 ثابت در گوشه؛ با کلیک، باکس باز می‌شود.', 'farazsms-next'); ?></span></span>
                    </label>
                </div>
            </div>
        </div><!-- /sub responsive -->

        <div class="fwss_save_button_container">
            <button type="submit" class="fwss_button" name="farazsms_next_settings_submit">
                <span class="button__text"><?php _e('ذخیره', 'farazsms-next'); ?></span>
            </button>
        </div>
    </form>
</div><!-- /pane main -->

<div class="fz-lm-pane" data-pane="reminder" style="display:none;">
<?php
// بخشِ یادآورِ هدیه‌ی لید مگنت (پیامک به کاربرانی که خرید نکرده‌اند).
do_action( 'farazsms_lead_magnet_extra_sections' );
?>
</div><!-- /pane reminder -->

<script>
(function(){
    var btns = document.querySelectorAll('.fz-lm-tab-btn');
    var mainPane = document.querySelector('.fz-lm-pane[data-pane="main"]');
    var reminderPane = document.querySelector('.fz-lm-pane[data-pane="reminder"]');
    var subs = document.querySelectorAll('.fz-lm-sub');
    function activate(p){
        btns.forEach(function(x){
            var on = x.getAttribute('data-pane') === p;
            x.classList.toggle('is-active', on);
            x.style.color = on ? '#365891' : '#9b9b9b';
            x.style.fontWeight = on ? '700' : '600';
            x.style.borderBottomColor = on ? '#365891' : 'transparent';
        });
        // تب‌های main و responsive هر دو در همان فرم‌اند (sub-pane)؛ reminder فرمِ جدا دارد.
        var showForm = (p === 'main' || p === 'responsive');
        if (mainPane) { mainPane.style.display = showForm ? '' : 'none'; }
        if (reminderPane) { reminderPane.style.display = (p === 'reminder') ? '' : 'none'; }
        subs.forEach(function(s){ s.style.display = (s.getAttribute('data-sub') === p) ? '' : 'none'; });
    }
    btns.forEach(function(b){ b.addEventListener('click', function(){ activate(b.getAttribute('data-pane')); }); });
    // اگر کاربر ذخیره‌ی یادآور را زد، بعد از بارگذاری همان تب باز بماند.
    if (window.location.hash === '#reminder') { activate('reminder'); }
})();
</script>
