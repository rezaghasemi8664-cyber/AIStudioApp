<?php
/**
 * سازماندهی و گروه‌بندی منوی پلاگین — Phase 5
 *
 * این فایل ساختار منوی «فراز اس‌ام‌اس» در پیشخوان وردپرس را بازچینی می‌کند
 * و گروه‌بندی بصری اضافه می‌کند. ترتیب مطلوب:
 *
 *   تنظیمات اصلی
 *   ─────────────────
 *     تنظیمات افزونه
 *     ارسال پیامک
 *     گزارشات ارسال پیامک
 *
 *   باشگاه مشتریان و افزایش فروش
 *   ─────────────────
 *     باشگاه مشتریان
 *     خبرنامه پیامکی
 *     لید مگنت
 *
 *   ووکامرس و سفارشات
 *   ─────────────────
 *     کد رهگیری سفارش
 *     نظرسنجی پس از خرید
 *     دیدگاه سایت
 *     موجود شد خبرم کن
 *     سبد خرید رها‌شده
 *
 *   ابزارها و فرم‌ها
 *   ─────────────────
 *     اطلاع‌رسانی گرویتی - المنتور
 *     ورود و ثبت نام
 *     بازخورد
 *
 * پیاده‌سازی: hook روی admin_menu با اولویت 9999 (پس از همه ثبت‌ها) و دستکاری
 * مستقیم آرایه‌ی `$submenu['farazsms']`.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'admin_menu', 'farazsms_menu_reorganize', 9999 );
function farazsms_menu_reorganize() {
	global $submenu;
	if ( ! isset( $submenu['farazsms'] ) || ! is_array( $submenu['farazsms'] ) ) {
		return;
	}

	// v3.20.90: ترتیب و گروه‌بندیِ منوی وردپرس از همان منبعِ حقیقتِ واحد
	// (farazsms_dashboard_nav_groups) مشتق می‌شود — دیگر دو فهرستِ جدا برای نگه‌داشتن.
	// تنها استثنا: slugهای «فقط سایدبارِ داخلی» که نباید منوی وردپرس را شلوغ کنند.
	$internal_only = apply_filters( 'farazsms_menu_internal_only_slugs', array(
		'farazsms-segments',   // باشگاه مشتریان (سگمنت‌بندی)
		'farazsms-spin',       // گردونه شانس
	) );

	$groups = array();
	foreach ( farazsms_dashboard_nav_groups() as $key => $ng ) {
		$items = array();
		foreach ( $ng['items'] as $item ) {
			if ( empty( $item['slug'] ) || in_array( $item['slug'], $internal_only, true ) ) {
				continue;
			}
			$items[] = $item['slug'];
		}
		if ( $items ) {
			$groups[ $key ] = array( 'label' => $ng['label'], 'items' => $items );
		}
	}
	// fallbackِ تاریخی اگر nav_groups به هر دلیل در دسترس نبود.
	if ( empty( $groups ) ) {
		$groups = array(
			'general' => array( 'label' => __( 'تنظیمات اصلی', 'farazsms' ), 'items' => array( 'farazsms-dashboard', 'farazsms-roi', 'farazsms-settings', 'farazsms-send-sms', 'farazsms-reports', 'farazsms-updates' ) ),
			'club'    => array( 'label' => __( 'باشگاه مشتریان و افزایش فروش', 'farazsms' ), 'items' => array( 'farazsms-cashback', 'farazsms-phonebook', 'farazsms-newsletter', 'farazsms-lead-magnet', 'farazsms-birthday', 'farazsms-user-panel', 'farazsms-automation' ) ),
			'woo'     => array( 'label' => __( 'ووکامرس و سفارشات', 'farazsms' ), 'items' => array( 'farazsms', 'farazsms-poll', 'farazsms-comments', 'farazsms-notify', 'farazsms-abandoned' ) ),
			'other'   => array( 'label' => __( 'ابزارها و فرم‌ها', 'farazsms' ), 'items' => array( 'farazsms-sms-forms', 'farazsms-login-register', 'farazsms-developers', 'farazsms-feedback' ) ),
		);
	}

	// Index existing $submenu entries by slug.
	$by_slug = array();
	foreach ( $submenu['farazsms'] as $entry ) {
		if ( isset( $entry[2] ) ) {
			$by_slug[ $entry[2] ] = $entry;
		}
	}

	// نکته مهم: WP برای URL منوی والد، اولین زیرمنوی قابل دسترس را انتخاب می‌کند.
	// اگر اولین آیتم یک divider (با اسلاگ #farazsms-divider-X) باشد، کلیک روی فراز اس‌ام‌اس
	// به جای صفحه واقعی، به یک URL با hash منتقل می‌شود (در عمل به /wp-admin/ می‌رود).
	// بنابراین گروه اول را بدون divider header شروع می‌کنیم تا اولین آیتم واقعی
	// (داشبورد) به‌عنوان landing کلیک روی منوی والد عمل کند.
	$new   = array();
	$first = true;
	foreach ( $groups as $key => $group ) {
		if ( ! $first ) {
			// Insert divider header (only for groups AFTER the first).
			$new[] = array(
				'<span class="farazsms-menu-divider">' . esc_html( $group['label'] ) . '</span>',
				'read',
				'#farazsms-divider-' . sanitize_key( $key ),
			);
		}
		$first = false;
		// Pull configured items in the desired order.
		foreach ( $group['items'] as $slug ) {
			if ( isset( $by_slug[ $slug ] ) ) {
				$new[] = $by_slug[ $slug ];
				unset( $by_slug[ $slug ] );
			}
		}
	}
	// Append any unmapped items at the end (so we never lose menu entries).
	foreach ( $by_slug as $entry ) {
		$new[] = $entry;
	}
	$submenu['farazsms'] = array_values( $new );

	// v3.22.109: چیدمانِ نهاییِ سایدبار طبقِ فهرستِ صریحِ کاربر.
	// آیتم‌های منتخب دقیقاً به همین ترتیب بالا می‌آیند؛ بقیه پایین می‌مانند و
	// با CSS (farazsms_menu_trim_sidebar_css) پنهان می‌شوند. ترتیب و visibility
	// هر دو از یک منبع (farazsms_sidebar_curated_slugs) می‌آیند.
	$curated = farazsms_sidebar_curated_slugs();
	$by_slug_final = array();
	foreach ( $submenu['farazsms'] as $entry ) {
		if ( isset( $entry[2] ) ) {
			$by_slug_final[ $entry[2] ] = $entry;
		}
	}
	$ordered = array();
	foreach ( $curated as $slug ) {
		if ( isset( $by_slug_final[ $slug ] ) ) {
			$ordered[] = $by_slug_final[ $slug ];
			unset( $by_slug_final[ $slug ] );
		}
	}
	// بقیه‌ی آیتم‌ها (پنهان‌شونده) پایین می‌مانند تا صفحه‌ای گم نشود.
	foreach ( $by_slug_final as $entry ) {
		$ordered[] = $entry;
	}
	$submenu['farazsms'] = array_values( $ordered );
}

/**
 * منبعِ واحدِ حقیقت برای سایدبارِ منوی وردپرس: کدام آیتم‌ها و با چه ترتیبی دیده شوند.
 *
 * هم ترتیبِ چیدمان (farazsms_menu_reorganize) و هم visibility
 * (farazsms_menu_trim_sidebar_css) از همین فهرست مشتق می‌شوند تا یک‌جا مدیریت شود.
 * با فیلترِ farazsms_sidebar_visible_slugs قابلِ تغییر است.
 *
 * @return string[] اسلاگ‌های زیرمنو به ترتیبِ نمایش.
 */
function farazsms_sidebar_curated_slugs() {
	return apply_filters( 'farazsms_sidebar_visible_slugs', array(
		'farazsms-dashboard',        // داشبورد
		'farazsms-settings',         // تنظیمات
		'farazsms-send-sms',         // ارسال پیامک
		'farazsms-reports',          // گزارشات
		'farazsms-login-register',   // ورود و ثبت نام
		'farazsms-orders-sms',       // پیامک سفارشات ووکامرس
		'farazsms-sms-forms',        // فرم ساز ها
		'farazsms-updates',          // بروزرسانی (آخر)
	) );
}

/**
 * کوتاه کردنِ منوی کناریِ وردپرس به «بخش‌های اصلی» — فقط با CSS (بدونِ دستکاریِ $submenu).
 *
 * درسِ مهم: حذفِ آیتم‌ها از $submenu باعث می‌شود کنترلِ دسترسیِ وردپرس آن صفحات را
 * «غیرمجاز» بداند (get_admin_page_parent والد را پیدا نمی‌کند → خطای دسترسی). پس به‌جای
 * حذف، فقط با CSS از سایدبار پنهان می‌کنیم. صفحات ثبت‌شده و کاملاً قابل‌دسترس می‌مانند
 * (از طریقِ سایدبارِ داخلیِ افزونه و آدرسِ مستقیم).
 *
 * بخش‌هایی که در سایدبار می‌مانند: داشبورد، تنظیمات، ارسال پیامک، گزارشات، ورود و ثبت‌نام، کش‌بک.
 * فهرست با فیلتر farazsms_sidebar_visible_slugs قابل تغییر است.
 */
add_action( 'admin_head', 'farazsms_menu_trim_sidebar_css', 100 );
function farazsms_menu_trim_sidebar_css() {
	global $submenu;
	if ( empty( $submenu['farazsms'] ) || ! is_array( $submenu['farazsms'] ) ) {
		return;
	}
	// منبعِ واحد: همان فهرستی که ترتیبِ چیدمان را هم تعیین می‌کند.
	// (farazsms-developers و farazsms-cashback عمداً اینجا نیستند — فقط از سایدبارِ
	// داخلیِ افزونه در دسترس‌اند و منوی وردپرس را شلوغ نمی‌کنند.)
	$keep = farazsms_sidebar_curated_slugs();

	$selectors = array();
	foreach ( $submenu['farazsms'] as $entry ) {
		$slug = isset( $entry[2] ) ? (string) $entry[2] : '';
		if ( $slug === '' || in_array( $slug, $keep, true ) ) {
			continue;
		}
		if ( strpos( $slug, 'farazsms-divider' ) !== false ) {
			continue; // dividerها جداگانه پایین مخفی می‌شوند
		}
		$s           = esc_attr( $slug );
		$selectors[] = '#adminmenu .toplevel_page_farazsms .wp-submenu li:has(> a[href$="page=' . $s . '"])';
		$selectors[] = '#adminmenu .toplevel_page_farazsms .wp-submenu li > a[href$="page=' . $s . '"]';
	}
	// همه‌ی divider headerها هم پنهان شوند (با ۶ آیتم، گروه‌بندی لازم نیست).
	$selectors[] = '#adminmenu .toplevel_page_farazsms .wp-submenu li:has(.farazsms-menu-divider)';

	if ( ! empty( $selectors ) ) {
		echo "\n<style id=\"farazsms-menu-trim\">" . implode( ',', $selectors ) . "{display:none !important;}</style>\n";
	}
}


/**
 * Style the menu dividers — gray uppercase headers that are visually distinct
 * but still readable. Targets the <span class="farazsms-menu-divider"> we inject above.
 */
add_action( 'admin_head', 'farazsms_menu_divider_css' );
function farazsms_menu_divider_css() {
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	// Only inject on pages where the admin menu is shown (i.e. any admin screen).
	?>
	<style id="farazsms-menu-divider-css">
	#adminmenu .toplevel_page_farazsms .wp-submenu .farazsms-menu-divider {
		display: block;
		color: #c1c8d4;
		font-size: 11px;
		font-weight: 600;
		letter-spacing: 0.4px;
		padding: 8px 12px 4px;
		margin-top: 8px;
		border-top: 1px solid rgba(255, 255, 255, 0.08);
		text-transform: none;
		opacity: 0.85;
		cursor: default;
	}
	#adminmenu .toplevel_page_farazsms .wp-submenu .farazsms-menu-divider.farazsms-menu-divider-first {
		margin-top: 0;
		border-top: 0;
	}
	#adminmenu .toplevel_page_farazsms .wp-submenu a:has(.farazsms-menu-divider) {
		pointer-events: none;
		padding: 0 !important;
		background: transparent !important;
	}
	#adminmenu .toplevel_page_farazsms .wp-submenu a:has(.farazsms-menu-divider):hover,
	#adminmenu .toplevel_page_farazsms .wp-submenu a:has(.farazsms-menu-divider):focus {
		color: inherit !important;
		background: transparent !important;
	}
	</style>
	<?php
}

/**
 * Headers use slug `#farazsms-divider-X` which WP turns into a real link. Click on
 * a header redirects to the first real item of that group to avoid 404.
 * Without this, clicking on a divider would 404.
 */
add_action( 'admin_init', 'farazsms_menu_divider_redirect' );
function farazsms_menu_divider_redirect() {
	if ( ! isset( $_GET['page'] ) ) {
		return;
	}
	// sanitize_key() در PHP کاراکتر `#` را حذف می‌کند. بنابراین اسلاگ‌ها بعد از sanitize
	// به شکل `farazsms-divider-X` می‌رسند (بدون `#`). map باید بر اساس فرم sanitize شده باشد.
	$page = sanitize_key( wp_unslash( $_GET['page'] ) );
	$map  = array(
		'farazsms-divider-general' => 'farazsms-dashboard',
		'farazsms-divider-club'    => 'farazsms-phonebook',
		'farazsms-divider-woo'     => 'farazsms',
		'farazsms-divider-other'   => 'farazsms-sms-forms',
	);
	if ( isset( $map[ $page ] ) ) {
		wp_safe_redirect( admin_url( 'admin.php?page=' . $map[ $page ] ) );
		exit;
	}
}

/**
 * Onboarding notice — shows a friendly setup hint on any plugin page when the
 * Api-Key isn't configured yet. This single banner replaces dozens of «Api-Key
 * missing» error messages users would otherwise see, and gives them a clear
 * one-click path to the settings page.
 *
 * Plus: a "did you know" hint with quick links to the major features for first-time admins.
 */
add_action( 'admin_notices', 'farazsms_admin_onboarding_notice' );
function farazsms_admin_onboarding_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	$on_plugin_page = $screen && strpos( (string) $screen->id, 'farazsms' ) !== false;
	if ( ! $on_plugin_page ) {
		return;
	}
	// Don't show on the settings page itself (user is already there), and don't show
	// on the dashboard hub (it shows its own onboarding hero box).
	$current_page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	if ( $current_page === 'farazsms-settings' || $current_page === 'farazsms-dashboard' ) {
		return;
	}
	$apikey = farazsms_get_apikey();
	if ( $apikey !== '' ) {
		return;
	}
	$settings_url = admin_url( 'admin.php?page=farazsms-settings' );
	?>
	<div class="notice notice-warning farazsms-onboarding-notice">
		<p>
			<strong>👋 <?php esc_html_e( 'به افزونه فراز اس‌ام‌اس خوش آمدید!', 'farazsms' ); ?></strong>
			<?php esc_html_e( 'برای شروع، کلید دسترسی (Api-Key) را وارد کنید — این کلید ارتباط افزونه با سامانه پیامکی شما را برقرار می‌کند.', 'farazsms' ); ?>
			<a href="<?php echo esc_url( $settings_url ); ?>" class="button button-primary"><?php esc_html_e( 'تنظیمات و وارد کردن Api-Key', 'farazsms' ); ?></a>
		</p>
		<p class="farazsms-onboarding-help">
			<?php esc_html_e( 'برای دریافت Api-Key:', 'farazsms' ); ?>
			<a href="https://sms.farazsms.com/" target="_blank" rel="noopener"><?php esc_html_e( 'ورود به پنل فراز اس‌ام‌اس', 'farazsms' ); ?></a>
			← <?php esc_html_e( 'مدیریت کلیدهای دسترسی', 'farazsms' ); ?> ← <?php esc_html_e( 'کپی کلید', 'farazsms' ); ?>
		</p>
	</div>
	<style>
	.farazsms-onboarding-notice { border-right-color: #4571ba !important; padding: 14px 18px !important; }
	.farazsms-onboarding-notice p { font-size: 14px; margin: 6px 0; }
	.farazsms-onboarding-notice .button { margin-right: 8px; }
	.farazsms-onboarding-notice .farazsms-onboarding-help { color: #4d4d4d; font-size: 13px; }
	</style>
	<?php
}

/**
 * Page-specific help blurbs. Adds a short info block at the top of pages that
 * don't already have their own guide section (settings, tracking-code, comments,
 * sms-forms, etc.). The text answers the most common first-time-user questions.
 */
add_action( 'admin_notices', 'farazsms_admin_page_specific_help' );
function farazsms_admin_page_specific_help() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$current_page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	$blurbs = array(
		'farazsms-settings' => array(
			'title' => __( 'تنظیمات افزونه فراز اس‌ام‌اس', 'farazsms' ),
			'body'  => __( 'در این صفحه کلید دسترسی (Api-Key) و خط ارسال پیش‌فرض را وارد می‌کنید. این دو در همه قابلیت‌های پلاگین استفاده می‌شود.', 'farazsms' ),
			'tip'   => __( 'اگر Api-Key ندارید: وارد پنل فراز شوید → مدیریت کلیدهای دسترسی → ساخت کلید جدید → کپی → چسباندن در فیلد زیر.', 'farazsms' ),
		),
		'farazsms'          => array(
			'title' => __( 'کد رهگیری سفارش', 'farazsms' ),
			'body'  => __( 'با ساخت الگوی پیامک «کد رهگیری»، پس از ثبت کد رهگیری روی سفارش ووکامرس، یک پیامک خودکار با کد رهگیری به مشتری ارسال می‌شود.', 'farazsms' ),
			'tip'   => __( 'متغیرهای قابل استفاده در متن الگو: %order_id% و %tracking_code% — نام برند فروشگاه را به‌صورت ثابت بنویسید.', 'farazsms' ),
		),
		'farazsms-comments' => array(
			'title' => __( 'پیامک رویدادهای دیدگاه', 'farazsms' ),
			'body'  => __( 'با تنظیم الگوهای پیامک برای ثبت دیدگاه/تأیید/پاسخ، در رویدادهای مربوط به دیدگاه‌های سایت پیامک خودکار ارسال می‌شود.', 'farazsms' ),
			'tip'   => __( 'برای دیدگاه‌های سفارش‌محور (پیامک نظرسنجی)، به منوی «نظرسنجی پس از خرید» مراجعه کنید.', 'farazsms' ),
		),
		'farazsms-sms-forms' => array(
			'title' => __( 'یکپارچگی با فرم‌ها', 'farazsms' ),
			'body'  => __( 'با Gravity Forms و Elementor Forms یکپارچه می‌شود. می‌توانید روی submit فرم، پیامک به ادمین یا کاربر بفرستید + فیلد OTP تأیید موبایل اضافه کنید.', 'farazsms' ),
			'tip'   => __( 'فیلد OTP کاربر را مجبور به تأیید موبایل قبل از ارسال فرم می‌کند — راهی ساده برای جلوگیری از فرم‌های اسپم.', 'farazsms' ),
		),
	);
	if ( ! isset( $blurbs[ $current_page ] ) ) {
		return;
	}
	$b = $blurbs[ $current_page ];
	?>
	<div class="notice notice-info farazsms-page-help-notice">
		<p>
			<strong>💡 <?php echo esc_html( $b['title'] ); ?></strong>
			— <?php echo esc_html( $b['body'] ); ?>
		</p>
		<?php if ( ! empty( $b['tip'] ) ) : ?>
			<p class="farazsms-page-help-tip">
				<strong><?php esc_html_e( 'نکته:', 'farazsms' ); ?></strong>
				<?php echo wp_kses_post( $b['tip'] ); ?>
			</p>
		<?php endif; ?>
	</div>
	<style>
	.farazsms-page-help-notice { border-right-color: #4571ba !important; padding: 12px 18px !important; }
	.farazsms-page-help-notice p { margin: 4px 0; font-size: 13px; line-height: 1.8; }
	.farazsms-page-help-notice .farazsms-page-help-tip { color: #4d4d4d; }
	</style>
	<?php
}
