<?php
/**
 * «سازگاری‌ها» — فهرستِ افزونه‌هایی که فراز اس‌ام‌اس با آن‌ها یکپارچه است.
 *
 * ⚠️ قاعدهٔ نگه‌داری (مهم): این فهرست **دستی نگه داشته نمی‌شود**. هر ماژولِ
 * یکپارچه‌سازی خودش را با فیلترِ زیر ثبت می‌کند:
 *
 * farazsms_compatibility_registry
 *
 * پس وقتی یکپارچگیِ تازه‌ای اضافه می‌شود، نامش خودکار اینجا می‌آید و کسی لازم
 * نیست این فایل را به‌روز کند. (همان درسی که از فهرستِ دستیِ صفحاتِ ادمین و
 * فهرستِ دستیِ بخش‌های پترن گرفتیم: فهرستِ مرکزیِ دستی دیر یا زود از واقعیت
 * عقب می‌ماند.)
 *
 * ورودی‌های «میراثی» پایینِ همین فایل seed شده‌اند چون ماژول‌هایشان قدیمی‌ترند؛
 * یکپارچگی‌های تازه **نباید** اینجا اضافه شوند.
 *
 * هر ورودی:
 *   name    — نامِ افزونه (همان‌طور که کاربر می‌شناسد)
 *   what    — ما با آن چه می‌کنیم (یک جملهٔ کوتاه، برای کاربر نه توسعه‌دهنده)
 *   group   — دسته‌بندیِ نمایشی
 *   detect  — basenameِ افزونه یا آرایه‌ای از basenameها، یا نامِ تابعِ تشخیص
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * دسته‌های نمایشی.
 *
 * @return array
 */
function farazsms_compat_groups() {
	return array(
		'core'    => 'فروشگاه و سفارش',
		'forms'   => 'فرم‌سازها',
		'members' => 'عضویت و ورود',
		'booking' => 'نوبت‌دهی و پشتیبانی',
		'ship'    => 'حمل‌ونقل و محصولات دیجیتال',
		'sms'     => 'افزونه‌های پیامکی و پنل‌ها',
		'channel' => 'کانال‌های پیام‌رسان',
	);
}

/**
 * رجیستریِ سازگاری‌ها.
 *
 * @return array
 */
function farazsms_compat_registry() {
	// ── ورودی‌های میراثی (ماژول‌های قدیمی‌تر که هنوز خودثبت نیستند) ──
	$registry = array(
		'woocommerce' => array(
			'name'   => 'WooCommerce',
			'what'   => 'پیامکِ همهٔ وضعیت‌های سفارش، سبد رهاشده، نظرسنجی، فاکتور، کش‌بک و کیف پول',
			'group'  => 'core',
			'detect' => 'woocommerce/woocommerce.php',
		),
		'gravityforms' => array(
			'name'   => 'Gravity Forms',
			'what'   => 'پیامک پس از ثبتِ فرم + تأییدِ شمارهٔ موبایل با کدِ یک‌بارمصرف',
			'group'  => 'forms',
			'detect' => 'gravityforms/gravityforms.php',
		),
		'elementor' => array(
			'name'   => 'Elementor / Elementor Pro',
			'what'   => 'پیامک پس از ثبتِ فرمِ المنتور + ویجتِ اختصاصیِ ورود با موبایل',
			'group'  => 'forms',
			'detect' => array( 'elementor/elementor.php', 'elementor-pro/elementor-pro.php' ),
		),
		'learnpress' => array(
			'name'   => 'LearnPress',
			'what'   => 'پیامکِ رویدادهای دوره و ثبت‌نامِ دانش‌پذیر',
			'group'  => 'members',
			'detect' => 'learnpress/learnpress.php',
		),
		'digits' => array(
			'name'   => 'Digits',
			'what'   => 'تأمینِ پیامکِ ورود و ثبت‌نامِ دیجیتس از خطِ فراز',
			'group'  => 'members',
			'detect' => 'digits/digits.php',
		),
		'mihanpanel' => array(
			'name'   => 'میهن‌پنل',
			'what'   => 'درگاهِ پیامکِ فراز برای ورود و ثبت‌نامِ میهن‌پنل',
			'group'  => 'members',
			'detect' => array( 'mihanpanel/mihanpanel.php', 'mihanpanel-lite/mihanpanel-lite.php', 'mihanpanel-pro/mihanpanel-pro.php' ),
		),
		'pinova' => array(
			'name'   => 'پینوا',
			'what'   => 'افزودنِ خودکارِ درگاهِ فراز به افزونهٔ ورودِ پینوا',
			'group'  => 'members',
			'detect' => 'farazsms_pinova_present',
		),
		'pwsms' => array(
			'name'   => 'پیامک ووکامرس (نبیک)',
			'what'   => 'افزودنِ درگاهِ فراز به افزونهٔ پیامکِ ووکامرس، بدونِ تداخل با تنظیماتش',
			'group'  => 'sms',
			'detect' => array( 'persian-woocommerce-sms/persian-woocommerce-sms.php', 'persian-woocommerce-sms-pro/persian-woocommerce-sms-pro.php' ),
		),
		'pws_tapin' => array(
			'name'   => 'حمل و نقل ووکامرس (تاپین)',
			'what'   => 'پیامکِ بارکدِ تاپین و وضعیت‌های ارسال، از داخلِ منویِ خودِ افزونه',
			'group'  => 'ship',
			'detect' => 'farazsms_pws_is_active',
		),
		'spotplayer' => array(
			'name'   => 'اسپات پلیر',
			'what'   => 'ارسالِ خودکارِ کدِ لایسنسِ ویدیو با پیامک، پس از خرید',
			'group'  => 'ship',
			'detect' => 'farazsms_spot_is_active',
		),
		'bale' => array(
			'name'   => 'پیام‌رسان بله',
			'what'   => 'ارسالِ همان اطلاع‌رسانی‌ها از کانالِ بله، در کنارِ پیامک',
			'group'  => 'channel',
			// کانالِ خودِ ماست، نه افزونه‌ی ثالث: با تنظیماتِ خودمان فعال می‌شود.
			'detect' => 'farazsms_compat_bale_on',
		),
	);

	/**
	 * ماژول‌های یکپارچه‌سازی خودشان را اینجا ثبت می‌کنند.
	 *
	 * @param array $registry
	 */
	$registry = (array) apply_filters( 'farazsms_compatibility_registry', $registry );

	// مرتب‌سازی: اول نصب‌شده‌ها، بعد الفبایی.
	uasort( $registry, static function ( $a, $b ) {
		$aa = farazsms_compat_is_active( $a ) ? 0 : 1;
		$bb = farazsms_compat_is_active( $b ) ? 0 : 1;
		if ( $aa !== $bb ) {
			return $aa <=> $bb;
		}
		return strcasecmp( (string) ( $a['name'] ?? '' ), (string) ( $b['name'] ?? '' ) );
	} );

	return $registry;
}

/**
 * آیا این افزونه روی سایت فعال است؟
 *
 * @param array $entry
 * @return bool
 */
function farazsms_compat_is_active( $entry ) {
	$detect = $entry['detect'] ?? '';
	if ( $detect === '' ) {
		return false;
	}
	// تابعِ تشخیص (نامِ تابع، closure، یا [شیء، متد]). فیلتر عمومی است، پس هم نوعِ
	// callable و هم استثنا باید مهار شوند — وگرنه یک ماژولِ ثالث می‌توانست کلِ
	// صفحه و شمارشِ داشبورد را با خطای مرگبار بیندازد.
	if ( ! is_string( $detect ) || strpos( $detect, '/' ) === false ) {
		if ( ! is_callable( $detect ) ) {
			return false;
		}
		try {
			return (bool) call_user_func( $detect );
		} catch ( \Throwable $e ) {
			return false;
		}
	}
	foreach ( (array) $detect as $basename ) {
		if ( farazsms_is_plugin_active( $basename ) ) {
			return true;
		}
	}
	return false;
}

/**
 * شمارشِ سازگاری‌های فعال — برای نمایش در داشبورد.
 *
 * @return array( 'total' => int, 'active' => int )
 */
function farazsms_compat_counts( $registry = null ) {
	// آرایه‌ی ازپیش‌ساخته را بپذیر تا صفحه دو بار رجیستری نسازد (دو uasort و دو
	// بار اجرای همه‌ی توابعِ تشخیص).
	$registry = is_array( $registry ) ? $registry : farazsms_compat_registry();
	$active   = 0;
	foreach ( $registry as $entry ) {
		if ( farazsms_compat_is_active( $entry ) ) {
			$active++;
		}
	}
	return array( 'total' => count( $registry ), 'active' => $active );
}

/**
 * کانالِ بله وقتی «فعال» شمرده می‌شود که دستِ‌کم یک سرویسش روشن باشد.
 *
 * @return bool
 */
function farazsms_compat_bale_on() {
	$services = farazsms_bale_enabled_services();
	return is_array( $services ) && ! empty( $services );
}

// ============================================================================
// صفحه
// ============================================================================

add_action( 'admin_menu', 'farazsms_compat_menu', 20 );
function farazsms_compat_menu() {
	add_submenu_page(
		'farazsms',
		__( 'سازگاری‌ها', 'farazsms' ),
		__( 'سازگاری‌ها', 'farazsms' ),
		'manage_options',
		'farazsms-compatibility',
		'farazsms_compat_render_page'
	);
}

function farazsms_compat_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$registry = farazsms_compat_registry();
	$groups   = farazsms_compat_groups();
	$counts   = farazsms_compat_counts( $registry );

	// گروه‌بندی برای نمایش
	$by_group = array();
	foreach ( $registry as $key => $entry ) {
		$g = (string) ( $entry['group'] ?? 'core' );
		// گروهِ ناشناخته به «فروشگاه» می‌افتد تا شمارشِ بالای صفحه با تعدادِ ردیف‌های
		// نمایش‌داده‌شده نخواند نداشته باشد.
		if ( ! isset( $groups[ $g ] ) ) {
			$g = 'core';
		}
		$by_group[ $g ] = $by_group[ $g ] ?? array();
		$by_group[ $g ][ $key ] = $entry;
	}
	?>
	<div class="wrap" dir="rtl">
		<h1>🧩 افزونه‌های سازگار با فراز اس‌ام‌اس</h1>

		<div class="farazsms-int-intro">
			فراز اس‌ام‌اس با <strong><?php echo (int) $counts['total']; ?></strong> افزونهٔ دیگر یکپارچه است.
			روی این سایت <strong><?php echo (int) $counts['active']; ?></strong> مورد از آن‌ها نصب و فعال است.
			<br>
			یکپارچگی یعنی بدونِ افزونهٔ واسط و بدونِ دست‌کاریِ آن افزونه، رویدادهایش را می‌شناسیم و برایشان پیامک می‌فرستیم.
		</div>

		<?php foreach ( $groups as $gkey => $glabel ) :
			if ( empty( $by_group[ $gkey ] ) ) {
				continue;
			} ?>
			<div class="farazsms-int-card">
				<div class="farazsms-int-card__head">
					<h2 class="farazsms-int-card__title"><?php echo esc_html( $glabel ); ?></h2>
				</div>
				<div class="farazsms-int-card__body">
					<div class="farazsms-int-scroll">
						<table class="widefat striped">
							<thead>
								<tr>
									<th style="width:210px">افزونه</th>
									<th>فراز اس‌ام‌اس با آن چه می‌کند</th>
									<th style="width:130px">روی این سایت</th>
								</tr>
							</thead>
							<tbody>
							<?php foreach ( $by_group[ $gkey ] as $entry ) :
								$on = farazsms_compat_is_active( $entry ); ?>
								<tr>
									<td><strong><?php echo esc_html( $entry['name'] ?? '' ); ?></strong></td>
									<td><?php echo esc_html( $entry['what'] ?? '' ); ?></td>
									<td>
										<span class="<?php echo $on ? 'farazsms-status farazsms-status-success' : 'farazsms-status farazsms-status-muted'; ?>">
											<?php echo $on ? '✓ فعال' : '— نصب نیست'; ?>
										</span>
									</td>
								</tr>
							<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		<?php endforeach; ?>

		<div class="farazsms-int-intro">
			افزونه‌ای که با آن کار می‌کنید اینجا نیست؟ از بخشِ «بازخورد» به ما بگویید — فهرستِ یکپارچگی‌ها بر اساسِ همین درخواست‌ها اولویت‌بندی می‌شود.
		</div>
	</div>
	<?php
}

add_filter( 'farazsms_nav_extra', 'farazsms_compat_register_nav' );
/**
 * خودثبتی در ناوبریِ افزونه.
 *
 * @param array $nav
 * @return array
 */
function farazsms_compat_register_nav( $nav ) {
	$nav['farazsms-compatibility'] = array(
		'title' => 'سازگاری‌ها',
		'icon'  => 'dashicons-admin-plugins',
		'desc'  => 'افزونه‌هایی که با فراز اس‌ام‌اس یکپارچه‌اند',
		'group' => 'general',
	);
	return $nav;
}
