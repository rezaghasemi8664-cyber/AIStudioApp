<?php
/**
 * ویجتِ Elementor برای فرمِ ورود و ثبت‌نامِ فراز اس‌ام‌اس.
 *
 * فقط وقتی Elementor فعال باشد بارگذاری می‌شود (require از داخلِ هوکِ register) —
 * همان الگوی ویجتِ «دکمه‌ی حساب».
 *
 * رندر عمداً از راهِ همان شورت‌کدِ زنده انجام می‌شود:
 *
 * [farazsms_login_form]
 *
 * یعنی ویجت هیچ نسخهٔ دومی از فرم نمی‌سازد؛ هر اصلاحی که در ماژولِ ورود انجام
 * شود، خودکار اینجا هم دیده می‌شود. (اگر HTMLِ فرم را دوباره می‌نوشتیم، دو مسیرِ
 * موازی داشتیم — همان اشتباهی که در ناوبری سه بار تکرار شد.)
 *
 * ظاهرِ پایه (رنگ، بوردر، CSSِ دلخواه) همچنان از تنظیماتِ «ورود و ثبت نام» می‌آید؛
 * کنترل‌های زیر فقط همان‌ها را برای این نمونه بازنویسی می‌کنند.
 *
 * @package farazsms
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'farazsms_login_widget_shortcode' ) ) {
	/**
	 * تنظیماتِ ویجت → رشته‌ی شورت‌کد.
	 *
	 * ⚠️ اینجا نباید esc_attr زد: تجزیه‌گرِ شورت‌کدِ وردپرس موجودیتِ HTML را
	 * رمزگشایی نمی‌کند، پس نشانیِ چندپارامتری (…?a=1&b=2) به &amp; تبدیل و پارامترِ
	 * دوم نابود می‌شد. مقدار با esc_url_raw پاک می‌شود و فقط دو نویسه‌ای که
	 * می‌توانند خودِ شورت‌کد را بشکنند حذف می‌شوند.
	 *
	 * بیرون از گاردِ Elementor تعریف شده تا بدونِ Elementor هم قابلِ تست باشد.
	 *
	 * @param array $settings
	 * @return string
	 */
	function farazsms_login_widget_shortcode( $settings ) {
		$atts = array( 'embedded="1"' );
		$back = isset( $settings['back_url']['url'] ) ? (string) $settings['back_url']['url'] : '';
		if ( $back !== '' ) {
			$back = esc_url_raw( $back );
			$back = str_replace( array( '"', ']' ), '', $back );
			if ( $back !== '' ) {
				$atts[] = 'back_url="' . $back . '"';
			}
		}
		return '[farazsms_login_form ' . implode( ' ', $atts ) . ']';
	}
}

if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
	return;
}

if ( ! class_exists( 'FarazSMS_Login_Form_Elementor_Widget' ) ) {

	class FarazSMS_Login_Form_Elementor_Widget extends \Elementor\Widget_Base {

		public function get_name() {
			return 'farazsms_login_form';
		}

		public function get_title() {
			return 'فرم ورود و ثبت‌نام فراز';
		}

		public function get_icon() {
			return 'eicon-form-horizontal';
		}

		public function get_categories() {
			return array( 'general' );
		}

		/**
		 * ماژولِ ورود خاموش باشد، ویجت در پنلِ المنتور فهرست نمی‌شود — تا کسی
		 * ویجتی را که روی سایت کار نمی‌کند نگذارد. (ثبت حذف نمی‌شود تا صفحه‌های
		 * موجود خطای «ویجت پیدا نشد» نگیرند.)
		 *
		 * @return bool
		 */
		public function show_in_panel() {
			return ! function_exists( 'farazsms_login_module_is_enabled' ) || farazsms_login_module_is_enabled();
		}

		public function get_keywords() {
			return array( 'login', 'register', 'otp', 'sms', 'ورود', 'ثبت نام', 'پیامک', 'فراز' );
		}

		protected function register_controls() {

			// ── محتوا ──
			$this->start_controls_section( 'farazsms_login_content', array(
				'label' => 'فرم ورود',
			) );

			$this->add_control( 'notice', array(
				'type' => \Elementor\Controls_Manager::RAW_HTML,
				'raw'  => '<div style="font-size:12px;line-height:2;color:#365891">این ویجت همان فرمِ رسمیِ ورود/ثبت‌نامِ افزونه را نمایش می‌دهد. تنظیماتِ اصلی (روش ورود، پیامک، امنیت) از بخشِ «ورود و ثبت نام» افزونه انجام می‌شود.</div>',
			) );

			$this->add_control( 'back_url', array(
				'label'       => 'پس از ورود، به این نشانی برود',
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => 'خالی = پیش‌فرضِ تنظیمات',
				'options'     => array( 'url' ),
				'label_block' => true,
			) );


			$this->add_control( 'hide_for_logged_in', array(
				'label'        => 'برای کاربرِ واردشده پنهان شود',
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => 'بله',
				'label_off'    => 'خیر',
				'default'      => '',
				'description'  => 'کاربرِ واردشده به‌هرحال فرمِ ورود را نمی‌بیند؛ این گزینه تعیین می‌کند که آیا جای آن خالی بماند یا یک پیامِ کوتاه نمایش داده شود.',
			) );

			$this->end_controls_section();

			// ── ظاهر ──
			$this->start_controls_section( 'farazsms_login_style', array(
				'label' => 'ظاهر',
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			) );

			$this->add_control( 'max_width', array(
				'label'      => 'حداکثر عرض',
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array( 'px' => array( 'min' => 240, 'max' => 900 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .farazsms-el-login' => 'max-width: {{SIZE}}{{UNIT}}; margin-inline: auto;',
				),
			) );

			$this->add_control( 'align', array(
				'label'     => 'چیدمان',
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array( 'title' => 'راست', 'icon' => 'eicon-text-align-right' ),
					'center'     => array( 'title' => 'وسط', 'icon' => 'eicon-text-align-center' ),
					'flex-end'   => array( 'title' => 'چپ', 'icon' => 'eicon-text-align-left' ),
				),
				'default'   => 'center',
				'selectors' => array(
					'{{WRAPPER}} > .elementor-widget-container' => 'display:flex; justify-content: {{VALUE}};',
				),
			) );

			$this->add_control( 'bg', array(
				'label'     => 'رنگ زمینه',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .farazsms-el-login, {{WRAPPER}} .farazsms-el-login .login-register-form' => 'background: {{VALUE}} !important;' ),
			) );

			$this->add_control( 'text_color', array(
				'label'     => 'رنگ متن',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .farazsms-el-login' => 'color: {{VALUE}};' ),
			) );

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				array( 'name' => 'box_border', 'selector' => '{{WRAPPER}} .farazsms-el-login' )
			);

			$this->add_control( 'radius', array(
				'label'      => 'گِردی گوشه',
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .farazsms-el-login' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			) );

			$this->add_control( 'padding', array(
				'label'      => 'فاصلهٔ داخلی',
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array(
					'{{WRAPPER}} .farazsms-el-login' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			) );

			$this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				array( 'name' => 'box_shadow', 'selector' => '{{WRAPPER}} .farazsms-el-login' )
			);

			$this->end_controls_section();

			// ── دکمه ──
			$this->start_controls_section( 'farazsms_login_button_style', array(
				'label' => 'دکمه',
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			) );

			$this->add_control( 'btn_bg', array(
				'label'     => 'رنگ دکمه',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .farazsms-el-login button, {{WRAPPER}} .farazsms-el-login input[type="submit"], {{WRAPPER}} .farazsms-el-login input.farazsms-submit' => 'background: {{VALUE}} !important; border-color: {{VALUE}} !important;',
				),
			) );

			$this->add_control( 'btn_color', array(
				'label'     => 'رنگ متنِ دکمه',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .farazsms-el-login button, {{WRAPPER}} .farazsms-el-login input[type="submit"], {{WRAPPER}} .farazsms-el-login input.farazsms-submit' => 'color: {{VALUE}} !important;',
				),
			) );

			$this->add_control( 'btn_radius', array(
				'label'      => 'گِردی دکمه',
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
				'selectors'  => array(
					'{{WRAPPER}} .farazsms-el-login button, {{WRAPPER}} .farazsms-el-login input[type="submit"], {{WRAPPER}} .farazsms-el-login input.farazsms-submit' => 'border-radius: {{SIZE}}px !important;',
				),
			) );

			$this->end_controls_section();
		}

		/**
		 * رندر — همیشه از راهِ شورت‌کدِ رسمی.
		 */
		/**
		 * آیا داخلِ ویرایشگر/پیش‌نمایشِ المنتور هستیم؟
		 *
		 * @return bool
		 */
		private function in_editor() {
			if ( ! class_exists( '\Elementor\Plugin' ) || ! isset( \Elementor\Plugin::$instance ) ) {
				return false;
			}
			$p = \Elementor\Plugin::$instance;
			if ( isset( $p->editor ) && method_exists( $p->editor, 'is_edit_mode' ) && $p->editor->is_edit_mode() ) {
				return true;
			}
			if ( isset( $p->preview ) && method_exists( $p->preview, 'is_preview_mode' ) && $p->preview->is_preview_mode() ) {
				return true;
			}
			return false;
		}

		/**
		 * ساختِ رشته‌ی شورت‌کد از تنظیماتِ ویجت.
		 *
		 * تابعِ خالص و جدا نگه داشته شده تا قابلِ تست باشد — نامِ پارامترها دقیقاً
		 * همان چیزی است که شورت‌کد می‌پذیرد و اگر روزی تغییر کند باید قرمز شود.
		 *
		 * حالتِ درون‌صفحه‌ای همیشه روشن است (حالتِ دیگر برای ویجت مناسب نیست).
		 *
		 * @param array $settings
		 * @return string
		 */
		public function build_shortcode( $settings ) {
			return farazsms_login_widget_shortcode( $settings );
		}

		protected function render() {
			$settings = $this->get_settings_for_display();

			// ⚠️ ماژولِ «ورود و ثبت نام» خاموش باشد، فرم رندر می‌شود ولی هندلرهای
			// AJAX ثبت نشده‌اند (سازنده‌ی کلاسِ ماژول فقط هنگامِ رندرِ شورت‌کد اجرا
			// می‌شود، و درخواستِ admin-ajax یک درخواستِ جداست). نتیجه فرمی بود که
			// شماره را می‌گرفت و هیچ اتفاقی نمی‌افتاد — بدونِ هیچ خطایی. پس روی
			// فرانت چیزی چاپ نمی‌کنیم و در ویرایشگر دلیل را صریح می‌گوییم.
			if ( ! farazsms_login_module_is_enabled() ) {
				if ( $this->in_editor() ) {
					echo '<div class="farazsms-el-login" style="padding:14px;border:1px dashed #d52a16;color:#d52a16;border-radius:8px">'
						. esc_html__( 'ماژول «ورود و ثبت نام» فراز خاموش است؛ این فرم روی سایت نمایش داده نمی‌شود. از پیشخوان → فراز اس‌ام‌اس → ورود و ثبت نام آن را روشن کنید.', 'farazsms' )
						. '</div>';
				}
				return;
			}

			// ⚠️ فقط یک نمونه در هر صفحه. شناسه‌ی شمارشِ معکوسِ فرم (#farazsms-timer)
			// در تمپلیت‌های ماژول ثابت است و جاوااسکریپت با querySelector تکی آن را
			// می‌گیرد؛ با دو نمونه (مثلاً یکی در هدرِ سراسری و یکی در متنِ صفحه)
			// «ارسالِ مجددِ کد» روی نمونه‌ی دوم هرگز کار نمی‌کرد.
			static $rendered = false;
			if ( $rendered ) {
				if ( $this->in_editor() ) {
					echo '<div class="farazsms-el-login" style="padding:14px;opacity:.7">'
						. esc_html__( 'در هر صفحه فقط یک فرمِ ورود نمایش داده می‌شود (این نمونه‌ی دوم است).', 'farazsms' )
						. '</div>';
				}
				return;
			}

			// ⚠️ کاربرِ واردشده هرگز به شورت‌کد نمی‌رسد.
			// دلیل: مسیرِ غیرِ درون‌صفحه‌ایِ فرمِ ورود برای کاربرِ واردشده یک ریدایرکتِ
			// جاوااسکریپتی به صفحه‌ی اصلی چاپ می‌کند — داخلِ یک ویجت (مخصوصاً در
			// هدر/فوترِ سراسری) یعنی پرت‌شدنِ هر مشتریِ واردشده از هر صفحه‌ای.
			// مسیرِ درون‌صفحه‌ای هم رشته‌ی خالی می‌دهد، پس ویجت در ویرایشگر ناپدید
			// و غیرقابلِ انتخاب می‌شد.
			if ( is_user_logged_in() ) {
				if ( empty( $settings['hide_for_logged_in'] ) ) {
					echo '<div class="farazsms-el-login farazsms-el-login--in">' . esc_html__( 'شما وارد شده‌اید.', 'farazsms' ) . '</div>';
				} elseif ( $this->in_editor() ) {
					echo '<div class="farazsms-el-login" style="padding:14px;opacity:.7">' . esc_html__( 'فرمِ ورود — برای کاربرِ واردشده پنهان است.', 'farazsms' ) . '</div>';
				}
				return;
			}

			$html = do_shortcode( $this->build_shortcode( $settings ) );
			if ( trim( (string) $html ) === '' ) {
				// خروجیِ خالی در ویرایشگر یعنی ویجتِ نامرئی و غیرقابلِ انتخاب.
				if ( $this->in_editor() ) {
					echo '<div class="farazsms-el-login" style="padding:14px;opacity:.7">' . esc_html__( 'فرمِ ورود اینجا نمایش داده می‌شود.', 'farazsms' ) . '</div>';
				}
				return;
			}

			$rendered = true;
			echo '<div class="farazsms-el-login">' . $html . '</div>';
		}
	}
}
