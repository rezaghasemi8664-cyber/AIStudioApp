<?php
/**
 * درجِ گروهیِ کد رهگیری — یک صفحه، همهٔ سفارش‌ها.
 *
 * به‌جای بازکردنِ تک‌تکِ سفارش‌ها، این صفحه سفارش‌های اخیرِ «بدونِ کد رهگیری» را در یک جدول
 * می‌آورد؛ فروشنده کد + سرویسِ حمل را وارد و با یک کلیک ذخیره+ارسال می‌کند. هستهٔ ذخیره/ارسال
 * همان هندلرِ امنِ موجود است (farazsms_handle_save_tracking_code — nonce + cap + ارسالِ پترن)،
 * پس این فایل فقط UI و صدا زدنِ per-row است؛ منطقِ ارسال دوباره‌نویسی نمی‌شود.
 *
 * @package FarazSMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', 'farazsms_bulk_tracking_menu', 20 );
function farazsms_bulk_tracking_menu() {
	// فقط وقتی ووکامرس فعال است معنا دارد.
	if ( ! class_exists( 'WooCommerce' ) ) {
		return;
	}
	add_submenu_page(
		'farazsms',
		'درج گروهی کد رهگیری',
		'درج گروهی رهگیری',
		'edit_shop_orders',
		'farazsms-bulk-tracking',
		'farazsms_bulk_tracking_render_page'
	);
}

/**
 * سفارش‌های نامزدِ نمایش: اخیر، در وضعیت‌های انتخاب‌شده، و «بدونِ کد رهگیریِ ثبت‌شده».
 *
 * @param string $status وضعیتِ ووکامرس (بدونِ wc-)، یا 'any'
 * @param int    $limit
 * @return WC_Order[]
 */
function farazsms_bulk_tracking_get_orders( $status = 'processing', $limit = 50 ) {
	if ( ! function_exists( 'wc_get_orders' ) ) {
		return array();
	}
	$args = array(
		'limit'   => (int) $limit,
		'orderby' => 'date',
		'order'   => 'DESC',
		'return'  => 'objects',
	);
	if ( $status !== 'any' ) {
		$args['status'] = array( 'wc-' . sanitize_key( $status ) );
	} else {
		$args['status'] = array( 'wc-processing', 'wc-completed', 'wc-on-hold' );
	}
	$orders = wc_get_orders( $args );
	if ( empty( $orders ) || ! is_array( $orders ) ) {
		return array();
	}
	// فقط سفارش‌هایی که هنوز کد رهگیری ندارند (HPOS-safe از طریقِ get_meta).
	$out = array();
	foreach ( $orders as $order ) {
		if ( ! $order instanceof WC_Order ) {
			continue;
		}
		$code = (string) $order->get_meta( 'farazsms_tracking_code' );
		if ( trim( $code ) === '' ) {
			$out[] = $order;
		}
	}
	return $out;
}

function farazsms_bulk_tracking_render_page() {
	if ( ! current_user_can( 'edit_shop_orders' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}

	$status = isset( $_GET['fbt_status'] ) ? sanitize_key( wp_unslash( $_GET['fbt_status'] ) ) : 'processing';
	$allowed_status = array( 'processing', 'completed', 'on-hold', 'any' );
	if ( ! in_array( $status, $allowed_status, true ) ) {
		$status = 'processing';
	}
	$limit  = isset( $_GET['fbt_limit'] ) ? max( 10, min( 200, (int) $_GET['fbt_limit'] ) ) : 50;

	$orders = farazsms_bulk_tracking_get_orders( $status, $limit );
	$nonce  = wp_create_nonce( 'save_tracking_code_nonce' );

	$carriers = array(
		'post'  => 'پست',
		'tipax' => 'تیپاکس',
		'other' => 'سایر',
	);
	$status_labels = array(
		'processing' => 'در حال انجام',
		'completed'  => 'تکمیل‌شده',
		'on-hold'    => 'در انتظار بررسی',
		'any'        => 'همه (انجام/تکمیل/انتظار)',
	);
	$has_jalali = function_exists( 'farazsms_tracking_log_to_jalali' );
	?>
	<div class="wrap farazsms-bulk-tracking">
		<h1 style="margin-bottom:6px;">📦 درج گروهی کد رهگیری</h1>
		<p style="color:#555; margin-top:0;">سفارش‌های اخیرِ بدونِ کد رهگیری. کد و سرویسِ حمل را وارد کنید و «ذخیره و ارسال» را بزنید — پیامکِ رهگیری با همان پترنِ سرویس ارسال می‌شود. نیازی به بازکردنِ تک‌تکِ سفارش‌ها نیست.</p>

		<form method="get" style="margin:14px 0; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
			<input type="hidden" name="page" value="farazsms-bulk-tracking">
			<label>وضعیت:
				<select name="fbt_status">
					<?php foreach ( $status_labels as $k => $lbl ) : ?>
						<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $status, $k ); ?>><?php echo esc_html( $lbl ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<label>تعداد:
				<select name="fbt_limit">
					<?php foreach ( array( 20, 50, 100, 200 ) as $n ) : ?>
						<option value="<?php echo esc_attr( $n ); ?>" <?php selected( $limit, $n ); ?>><?php echo esc_html( $n ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<button type="submit" class="button">فیلتر</button>
			<span style="color:#777;"><?php echo esc_html( count( $orders ) ); ?> سفارش بدونِ کد رهگیری</span>
		</form>

		<?php if ( empty( $orders ) ) : ?>
			<div class="notice notice-success inline"><p>هیچ سفارشِ بدونِ کد رهگیری در این فیلتر نیست. 🎉</p></div>
		<?php else : ?>
		<table class="widefat striped" id="farazsms-bulk-tracking-table" style="max-width:1100px;">
			<thead>
				<tr>
					<th style="width:80px;">سفارش</th>
					<th>مشتری</th>
					<th style="width:110px;">مقصد</th>
					<th style="width:120px;">تاریخ</th>
					<th style="width:180px;">کد رهگیری</th>
					<th style="width:110px;">سرویس</th>
					<th style="width:150px;">عملیات</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $orders as $order ) :
					$oid   = $order->get_id();
					$name  = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
					if ( $name === '' ) { $name = '#' . $oid; }
					$city  = $order->get_shipping_city() ? $order->get_shipping_city() : $order->get_billing_city();
					$date  = $order->get_date_created();
					$date_str = '';
					if ( $date ) {
						$date_str = $has_jalali ? farazsms_tracking_log_to_jalali( $date->date( 'Y-m-d H:i:s' ) ) : $date->date_i18n( 'Y-m-d' );
					}
					$edit_url = method_exists( $order, 'get_edit_order_url' ) ? $order->get_edit_order_url() : get_edit_post_link( $oid );
					?>
					<tr data-order="<?php echo esc_attr( $oid ); ?>">
						<td><a href="<?php echo esc_url( $edit_url ); ?>" target="_blank" rel="noopener">#<?php echo esc_html( $oid ); ?></a></td>
						<td><?php echo esc_html( $name ); ?></td>
						<td><?php echo esc_html( $city ); ?></td>
						<td style="direction:ltr; text-align:right;"><?php echo esc_html( $date_str ); ?></td>
						<td><input type="text" class="fbt-code regular-text" style="width:100%;" dir="ltr" placeholder="کد مرسوله" autocomplete="off"></td>
						<td>
							<select class="fbt-carrier">
								<?php foreach ( $carriers as $ck => $cl ) : ?>
									<option value="<?php echo esc_attr( $ck ); ?>"><?php echo esc_html( $cl ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
						<td>
							<button type="button" class="button button-primary fbt-save">ذخیره و ارسال</button>
							<span class="fbt-result" style="margin-right:6px; font-size:12px;"></span>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<p style="margin-top:14px;">
			<button type="button" class="button" id="fbt-save-all">💾 ذخیره و ارسالِ همهٔ ردیف‌های پرشده</button>
			<span id="fbt-save-all-result" style="margin-right:8px;"></span>
		</p>
		<?php endif; ?>
	</div>

	<script>
	(function($){
		var ajaxurl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
		var nonce   = <?php echo wp_json_encode( $nonce ); ?>;

		function saveRow($row){
			var $code = $row.find('.fbt-code');
			var code  = $.trim($code.val() || '');
			var $res  = $row.find('.fbt-result');
			if (code === '') { return $.Deferred().resolve(false).promise(); }
			var $btn = $row.find('.fbt-save');
			$btn.prop('disabled', true);
			$res.css('color', '#777').text('در حال ارسال…');
			return $.post(ajaxurl, {
				action: 'save_tracking_code',
				security: nonce,
				order_id: $row.data('order'),
				tracking_code: code,
				carrier: $row.find('.fbt-carrier').val()
			}).done(function(resp){
				if (resp && resp.success) {
					$res.css('color', '#096d49').text('✓ ارسال شد');
					$row.css('opacity', '0.6');
					$code.prop('readonly', true);
				} else {
					var m = (resp && resp.data) ? (typeof resp.data === 'string' ? resp.data : (resp.data.message || 'خطا')) : 'خطا';
					$res.css('color', '#b32817').text('✗ ' + m);
					$btn.prop('disabled', false);
				}
			}).fail(function(){
				$res.css('color', '#b32817').text('✗ خطای شبکه');
				$btn.prop('disabled', false);
			});
		}

		$(document).on('click', '.fbt-save', function(){
			saveRow($(this).closest('tr'));
		});

		$('#fbt-save-all').on('click', function(){
			var $btn = $(this).prop('disabled', true);
			var $out = $('#fbt-save-all-result').css('color', '#777').text('در حال پردازش…');
			var rows = $('#farazsms-bulk-tracking-table tbody tr').filter(function(){
				return $.trim($(this).find('.fbt-code').val() || '') !== '' && !$(this).find('.fbt-code').prop('readonly');
			}).toArray();
			var i = 0, ok = 0;
			(function next(){
				if (i >= rows.length){
					$out.css('color', '#096d49').text('تمام شد — ' + ok + ' مورد ارسال شد.');
					$btn.prop('disabled', false);
					return;
				}
				var $row = $(rows[i++]);
				saveRow($row).always(function(){
					if ($row.find('.fbt-result').text().indexOf('✓') === 0) { ok++; }
					setTimeout(next, 250); // فاصلهٔ کوتاه تا پنلِ فراز خفه نشود.
				});
			})();
		});
	})(jQuery);
	</script>
	<?php
}
