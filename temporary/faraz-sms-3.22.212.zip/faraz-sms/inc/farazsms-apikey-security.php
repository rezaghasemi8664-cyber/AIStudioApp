<?php
/**
 * امنیتِ کلیدِ دسترسی (Api-Key) — رمزنگاریِ شفاف در دیتابیس + کمک‌کننده‌های ماسک.
 *
 * مسئله: کلیدِ دسترسی به‌صورتِ متنِ ساده در option ذخیره می‌شد و در فیلدِ تنظیمات هم
 * نمایش داده می‌شد؛ پس هر کسی که به پیشخوان یا دیتابیس دسترسی داشت آن را می‌دید.
 *
 * راهکار (و مرزِ واقعیِ امنیت — صادقانه):
 *   - کلید را نمی‌توان «هش» کرد، چون افزونه باید مقدارِ اصلی را بخواند تا با وب‌سرویسِ
 *     فراز پیامک بفرستد. پس رمزنگاریِ «برگشت‌پذیر» به‌کار می‌رود، نه هشِ یک‌طرفه.
 *   - کلیدِ رمز از salt هایِ وردپرس (wp_salt) مشتق می‌شود که در wp-config.php هستند،
 *     یعنی «بیرونِ دیتابیس». بنابراین یک دامپِ خامِ دیتابیس به‌تنهایی نمی‌تواند کلید را
 *     رمزگشایی کند (به wp-config.php هم نیاز است). این در برابرِ نشتِ دیتابیس محافظت می‌کند،
 *     ولی کسی که به فایل‌های سایت و دیتابیس هر دو دسترسی دارد همچنان می‌تواند رمزگشایی کند —
 *     چون افزونه باید بتواند برای ارسال، کلید را بخواند. این محدودیتِ ذاتیِ هر رازِ سمت‌سرور است.
 *   - در UI کلید اصلاً نمایش داده نمی‌شود (ماسک)؛ فقط وضعیتِ «ذخیره شده» نشان داده می‌شود.
 *
 * پیاده‌سازی: فیلترهای option وردپرس (pre_update_option / option) رمزنگاری/رمزگشایی را
 * شفاف انجام می‌دهند، پس هیچ‌کدام از ده‌ها نقطه‌ی خواندنِ get_option('farazsms_apikey')
 * لازم نیست تغییر کند.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_APIKEY_ENC_PREFIX = 'enc:v1:';

/**
 * کلیدِ متقارنِ ۳۲ بایتی مشتق‌شده از salt هایِ wp-config (خارج از دیتابیس).
 *
 * @return string 32 bytes raw.
 */
function farazsms_apikey_secret() {
	$salt = function_exists( 'wp_salt' ) ? wp_salt( 'auth' ) : ( defined( 'AUTH_SALT' ) ? AUTH_SALT : 'farazsms-fallback-salt' );
	return hash( 'sha256', $salt . '|farazsms-apikey-v1', true );
}

/**
 * آیا مقدار از قبل رمزنگاری‌شده است؟
 *
 * @param mixed $value
 * @return bool
 */
function farazsms_apikey_is_encrypted( $value ) {
	return is_string( $value ) && strpos( $value, FARAZSMS_APIKEY_ENC_PREFIX ) === 0;
}

/**
 * رمزنگاریِ متنِ ساده برای ذخیره. در صورتِ نبودِ openssl یا خطا، همان متنِ ساده برگردانده
 * می‌شود تا هرگز کلید گم نشود (fail-safe، نه fail-closed).
 *
 * @param string $plain
 * @return string
 */
function farazsms_apikey_encrypt( $plain ) {
	if ( ! is_string( $plain ) || $plain === '' ) {
		return $plain;
	}
	if ( farazsms_apikey_is_encrypted( $plain ) ) {
		return $plain; // دوبار رمزنگاری نکن
	}
	if ( ! function_exists( 'openssl_encrypt' ) || ! function_exists( 'openssl_random_pseudo_bytes' ) ) {
		return $plain;
	}
	$iv     = openssl_random_pseudo_bytes( 16 );
	$cipher = openssl_encrypt( $plain, 'aes-256-cbc', farazsms_apikey_secret(), OPENSSL_RAW_DATA, $iv );
	if ( $cipher === false ) {
		return $plain;
	}
	return FARAZSMS_APIKEY_ENC_PREFIX . base64_encode( $iv . $cipher );
}

/**
 * رمزگشایی مقدارِ ذخیره‌شده. مقادیرِ قدیمیِ متنِ ساده (بدونِ پیشوند) بدونِ تغییر برمی‌گردند
 * (سازگاریِ گذشته‌نگر). خطای رمزگشایی → رشته‌ی خالی (کلیدِ خراب، نه متنِ ذخیره‌شده‌ی خام).
 *
 * @param mixed $stored
 * @return mixed
 */
function farazsms_apikey_decrypt( $stored ) {
	if ( ! farazsms_apikey_is_encrypted( $stored ) ) {
		return $stored; // متنِ سادهٔ قدیمی یا غیررشته‌ای
	}
	if ( ! function_exists( 'openssl_decrypt' ) ) {
		return $stored;
	}
	$raw = base64_decode( substr( $stored, strlen( FARAZSMS_APIKEY_ENC_PREFIX ) ), true );
	if ( $raw === false || strlen( $raw ) <= 16 ) {
		return '';
	}
	$iv     = substr( $raw, 0, 16 );
	$cipher = substr( $raw, 16 );
	$plain  = openssl_decrypt( $cipher, 'aes-256-cbc', farazsms_apikey_secret(), OPENSSL_RAW_DATA, $iv );
	return $plain === false ? '' : $plain;
}

/**
 * آیا کلیدِ دسترسیِ معتبری ذخیره شده است؟ (بدونِ افشای مقدار)
 *
 * @return bool
 */
function farazsms_apikey_is_set() {
	$k = get_option( 'farazsms_apikey', '' ); // فیلترِ option رمزگشایی می‌کند
	return is_string( $k ) && trim( $k ) !== '';
}

// --- فیلترهای شفافِ رمزنگاری در لایه‌ی option ---

// هنگامِ ذخیره: متنِ ساده → رمزنگاری‌شده. علاوه بر آن، گاردِ متمرکز: چون کلید در UI
// ماسک است و فرم‌ها آن را خالی ارسال می‌کنند، مقدارِ خالی یعنی «تغییر نده» — نه پاک‌کردن.
// این محافظت همه‌ی مسیرهای ذخیره (تنظیمات، AJAX، Settings-APIِ میهن‌پنل، PWSMS، …) را
// یک‌جا پوشش می‌دهد. پاک‌کردنِ عمدیِ کلید فقط با delete_option ممکن است.
add_filter( 'pre_update_option_farazsms_apikey', 'farazsms_apikey_pre_update', 10, 2 );
function farazsms_apikey_pre_update( $value, $old_value ) {
	$value = is_string( $value ) ? $value : '';
	if ( trim( $value ) === '' && is_string( $old_value ) && $old_value !== '' ) {
		return $old_value; // مقدارِ ذخیره‌شده (رمزنگاری‌شده) دست‌نخورده می‌ماند
	}
	return farazsms_apikey_encrypt( $value );
}

// هنگامِ افزودنِ اولیه (add_option) هم رمزنگاری شود.
add_filter( 'pre_add_option_farazsms_apikey', 'farazsms_apikey_pre_add', 10, 1 );
function farazsms_apikey_pre_add( $value ) {
	return farazsms_apikey_encrypt( is_string( $value ) ? $value : '' );
}

// هنگامِ خواندن: رمزنگاری‌شده → متنِ ساده (شفاف برای همه‌ی خواننده‌ها).
add_filter( 'option_farazsms_apikey', 'farazsms_apikey_decrypt', 10, 1 );

/**
 * مهاجرتِ یک‌بارِ کلیدِ متنِ سادهٔ موجود به شکلِ رمزنگاری‌شده (بدونِ نیاز به ذخیره‌ی دستی).
 */
add_action( 'admin_init', 'farazsms_apikey_migrate_plaintext' );
function farazsms_apikey_migrate_plaintext() {
	if ( get_option( 'farazsms_apikey_enc_migrated' ) === '1' ) {
		return;
	}
	global $wpdb;
	// مقدارِ خام را مستقیم از دیتابیس بخوان (بدونِ فیلترِ رمزگشایی) تا بفهمیم متنِ ساده است یا نه.
	$raw = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1", 'farazsms_apikey' ) );
	if ( is_string( $raw ) && $raw !== '' && ! farazsms_apikey_is_encrypted( $raw ) ) {
		// $raw متنِ ساده است؛ دوباره ذخیره کن تا فیلترِ pre_update آن را رمزنگاری کند.
		update_option( 'farazsms_apikey', $raw );
	}
	update_option( 'farazsms_apikey_enc_migrated', '1' );
}

/**
 * ترمیمِ یک‌بار برای سایت‌هایی که در نسخه‌های ۳.۲۲.۱۰۹–۱۱۳ کلیدِ رمزنگاری‌شده (enc:v1:...)
 * به‌اشتباه در تنظیماتِ PWSMS نوشته شده بود. کلیدِ متنِ سادهٔ صحیح را دوباره به PWSMS می‌فرستد
 * (idempotent — اگر از قبل درست باشد، هیچ نوشتنی رخ نمی‌دهد).
 */
add_action( 'admin_init', 'farazsms_apikey_heal_pwsms_ciphertext' );
function farazsms_apikey_heal_pwsms_ciphertext() {
	if ( get_option( 'farazsms_apikey_pwsms_heal_v114' ) === '1' ) {
		return;
	}
	$plain = get_option( 'farazsms_apikey', '' ); // از طریقِ فیلترِ option رمزگشایی‌شده
	if ( is_string( $plain ) && trim( $plain ) !== '' ) {
		farazsms_sync_apikey_to_pwsms( '', $plain ); // متنِ ساده → PWSMS (ciphertextِ خراب را جایگزین می‌کند)
	}
	update_option( 'farazsms_apikey_pwsms_heal_v114', '1' );
}

/**
 * نوتیسِ سلامتِ رمزگشایی: اگر کلیدِ ذخیره‌شده «رمزنگاری‌شده» است ولی رمزگشایی به رشتهٔ خالی
 * می‌رسد (معمولاً به‌خاطر تغییرِ saltهای wp-config)، همهٔ ارسال‌ها بی‌صدا قطع می‌شوند. این نوتیس
 * خطا را «دیدنی و قابلِ‌بازیابی» می‌کند تا مدیر بداند باید کلید را دوباره وارد کند.
 */
add_action( 'admin_notices', 'farazsms_apikey_decrypt_health_notice' );
function farazsms_apikey_decrypt_health_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	static $checked = null;
	if ( $checked === null ) {
		$checked = false;
		global $wpdb;
		$raw = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1", 'farazsms_apikey' ) );
		// فقط وقتی مقدار «رمزنگاری‌شده» است ولی رمزگشایی خالی می‌شود = کلید غیرقابلِ‌بازگشایی.
		if ( farazsms_apikey_is_encrypted( $raw ) && farazsms_apikey_decrypt( $raw ) === '' ) {
			$checked = true;
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( '[farazsms] apikey decrypt failed — wp-config salts likely rotated; admin must re-enter the key.' );
			}
		}
	}
	if ( ! $checked ) {
		return;
	}
	$settings_url = admin_url( 'admin.php?page=farazsms-settings' );
	?>
	<div class="notice notice-error">
		<p>
			<strong>⚠️ فراز اس‌ام‌اس:</strong>
			کلیدِ دسترسیِ ذخیره‌شده قابلِ رمزگشایی نیست (معمولاً به‌خاطرِ تغییرِ کلیدهای امنیتیِ
			<span style="direction:ltr;"><code>wp-config.php</code></span>
			). تا کلید را دوباره وارد نکنید، پیامکی ارسال نمی‌شود.
			<a href="<?php echo esc_url( $settings_url ); ?>" class="button button-primary" style="margin-right:8px;">واردکردنِ دوبارهٔ کلید</a>
		</p>
	</div>
	<?php
}
