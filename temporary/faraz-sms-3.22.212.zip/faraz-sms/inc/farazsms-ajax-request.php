<?php
/*
*
*	***** Faraz woo Scheduled sms *****
*
*	Ajax Request
*	
*/
if ( ! defined( 'WPINC' ) ) {
	die;
}
/*
Ajax Requests
*/
add_action( 'wp_ajax_farazsms_save_credentials', 'farazsms_ajax_save_credentials' );
// nopriv intentionally NOT registered — admin-only endpoint that writes to wp_options.
function farazsms_ajax_save_credentials() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'دسترسی غیرمجاز', 403 );
		return;
	}
	if ( ! check_ajax_referer( 'farazsms_save_settings', 'farazsms_save_nonce', false ) ) {
		wp_send_json_error( 'نشست منقضی شده است؛ صفحه را یک‌بار رفرش کنید.' );
		return;
	}
	$form_context = isset( $_POST['form'] ) ? sanitize_text_field( $_POST['form'] ) : '';
	// v3.21.96: هم نامِ بدونِ پیشوند (که JS می‌سازد) و هم نامِ پیشوندارِ خودِ فیلدهای فرم پذیرفته
	// می‌شوند. قبلاً فقط نامِ بدونِ پیشوند خوانده می‌شد؛ اگر JS اجرا نمی‌شد، مقدار هرگز ذخیره نمی‌شد.
	$apikey       = isset( $_POST['apikey'] ) ? $_POST['apikey'] : ( isset( $_POST['farazsms_apikey'] ) ? $_POST['farazsms_apikey'] : '' );
	$pattern      = isset( $_POST['pattern'] ) ? $_POST['pattern'] : '';
	$sender       = isset( $_POST['sender'] ) ? $_POST['sender'] : ( isset( $_POST['farazsms_sender'] ) ? $_POST['farazsms_sender'] : '' );
	$poll_pattern = isset( $_POST['poll_pattern'] ) ? $_POST['poll_pattern'] : '';
	$send_poll_sms = isset( $_POST['send_poll_sms'] ) ? $_POST['send_poll_sms'] : '0';
	$send_time    = $send_poll_sms === '1' ? ( isset( $_POST['send_time'] ) ? $_POST['send_time'] : '' ) : '';
	$send_status  = $send_poll_sms === '1' ? ( isset( $_POST['send_status'] ) ? $_POST['send_status'] : '' ) : '';

	// فقط تنظیمات: کلید دسترسی و خط ارسال کننده
	if ( $form_context === 'settings' ) {
		// کلید در UI ماسک است و خالی ارسال می‌شود. فیلدِ خالی = «کلیدِ فعلی را نگه دار».
		// فقط وقتی هیچ کلیدی (نه جدید نه قبلی) نبود خطا بده.
		$apikey_input = trim( (string) $apikey );
		$existing_key = (string) get_option( 'farazsms_apikey', '' );
		if ( $apikey_input === '' && trim( $existing_key ) === '' ) {
			wp_send_json_error( 'لطفا کلید دسترسی را وارد کنید' );
			return;
		}
		$clean_apikey = ( $apikey_input !== '' ) ? sanitize_text_field( $apikey_input ) : $existing_key;
		if ( $apikey_input !== '' ) {
			update_option( 'farazsms_apikey', sanitize_text_field( $apikey_input ) );
		}
		update_option( 'farazsms_sender', sanitize_text_field( $sender ) );
		// خطِ تبلیغات (پیش‌فرض PRO) — با اعتبارسنجی: فقط PRO یا خطِ 998/9998؛ خطِ خدماتی رد می‌شود
		// (تا کاربر نتواند خطِ خدماتی را برای تبلیغ استفاده کند). مقدارِ نامعتبر ذخیره نمی‌شود و خطا برمی‌گردد.
		$ad_sender_raw = isset( $_POST['ad_sender'] ) ? wp_unslash( $_POST['ad_sender'] )
			: ( isset( $_POST['farazsms_ad_sender'] ) ? wp_unslash( $_POST['farazsms_ad_sender'] ) : '' );
		$ad_val = farazsms_validate_ad_sender( $ad_sender_raw );
		if ( $ad_val['ok'] ) {
			update_option( 'farazsms_ad_sender', $ad_val['value'] !== '' ? $ad_val['value'] : 'PRO' );
		}
		$show_credit = isset( $_POST['show_credit_in_admin_bar'] ) ? sanitize_text_field( $_POST['show_credit_in_admin_bar'] ) : '0';
		update_option( 'farazsms_show_credit_in_admin_bar', ( $show_credit === '1' ) ? '1' : '0' );
		// ویجتِ گزارشِ روزانه در داشبورد (پیش‌فرض روشن)
		$dash_widget = isset( $_POST['dash_widget_enabled'] ) ? sanitize_text_field( $_POST['dash_widget_enabled'] ) : '0';
		update_option( 'farazsms_dash_widget_enabled', ( $dash_widget === '1' ) ? '1' : '0' );

		// همگام‌سازی دفاعی به افزونه پیامک ووکامرس — حتی اگر update_option_X hook فعال نشد
		// (مثلاً به دلیل اینکه مقدار تغییری نکرده)، این مسیر مستقیم تضمین می‌کند که کلید در
		// sms_main_settings هم نوشته شود تا کاربر مجبور به وارد کردن دوباره نشود.
		farazsms_sync_apikey_to_pwsms( '', $clean_apikey );

		// Cache اعتبار پاک شود تا UI تازه‌ترین مقدار را بگیرد.
		delete_transient( 'farazsms_credit_' . md5( $clean_apikey ) );

		// v3.22.14: گاردِ کشِ آبجکت/autoload — علتِ «روی نصبِ تازه کلید/خط ذخیره نمی‌شود». وقتی این
		// optionها برای اولین بار (به‌صورتِ autoloaded) ساخته می‌شوند، روی بعضی آبجکت‌کش‌های پایدار
		// کشِ alloptions تازه نمی‌شود و خواندنِ بعدی همان «وجود ندارد» را برمی‌گرداند → کلید خالی می‌ماند.
		// با پاک‌کردنِ صریح، خواندنِ بعدی از دیتابیس می‌آید. (روی نصبِ قدیمی که کلید هست مشکلی نبود.)
		wp_cache_delete( 'farazsms_apikey', 'options' );
		wp_cache_delete( 'farazsms_sender', 'options' );
		wp_cache_delete( 'farazsms_ad_sender', 'options' );
		wp_cache_delete( 'alloptions', 'options' );

		// اگر خطِ تبلیغاتیِ واردشده نامعتبر بود (خطِ خدماتی): بقیه‌ی تنظیمات ذخیره شده‌اند و فقط این خط نه.
		// مثلِ مسیرِ native، این را «هشدار» می‌دانیم نه شکستِ کامل — تا کاربر فکر نکند هیچ‌چیز ذخیره نشد.
		// پیام در نوتیسِ ادمین (همان transientِ مسیرِ native) پس از رفرش نشان داده می‌شود.
		if ( empty( $ad_val['ok'] ) ) {
			set_transient( 'farazsms_ad_sender_error_' . get_current_user_id(), $ad_val['error'], HOUR_IN_SECONDS );
		}
		wp_send_json_success();
		return;
	}

	// تنظیمات OTP (صفحه اطلاع رسانی گرویتی - المنتور)
	if ( $form_context === 'otp' ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'دسترسی غیرمجاز' );
			return;
		}
		if ( isset( $_POST['farazsms_otp_pattern'] ) ) {
			update_option( 'farazsms_otp_pattern', sanitize_text_field( wp_unslash( $_POST['farazsms_otp_pattern'] ) ), false );
		}
		if ( isset( $_POST['farazsms_otp_message'] ) ) {
			update_option( 'farazsms_otp_message', wp_kses_post( wp_unslash( $_POST['farazsms_otp_message'] ) ), false );
		}
		wp_send_json_success();
		return;
	}

	// کد رهگیری — Multi-pattern (v3.13.7+): پشتیبانی از سه پترن جداگانه برای post/tipax/other.
	// فرم جدید carrier را پست می‌کند و pattern + message هر دو فیلد جداگانه ارسال می‌شوند.
	if ( $form_context === 'tracking' ) {
		$carrier = isset( $_POST['carrier'] ) ? sanitize_text_field( wp_unslash( $_POST['carrier'] ) ) : '';
		$msg     = isset( $_POST['message'] ) ? wp_unslash( $_POST['message'] ) : '';

		if ( in_array( $carrier, array( 'post', 'tipax', 'other' ), true ) ) {
			update_option( 'farazsms_pattern_' . $carrier, sanitize_text_field( $pattern ), false );
			update_option( 'farazsms_message_' . $carrier, $msg, false );
			// برای backward compat، post هم در farazsms_pattern و farazsms_message قدیمی ذخیره می‌شود
			// تا کد قدیمی که هنوز به این options اشاره می‌کند کار کند.
			if ( $carrier === 'post' ) {
				update_option( 'farazsms_pattern', sanitize_text_field( $pattern ), false );
				update_option( 'farazsms_message', $msg, false );
			}
		} else {
			// Fallback به رفتار قبلی برای backward compatibility با کلاینت‌های قدیمی.
			update_option( 'farazsms_pattern', sanitize_text_field( $pattern ), false );
		}
		wp_send_json_success();
		return;
	}

	// فرم دیدگاه سایت: ذخیره همه تنظیمات دیدگاه (فقط مدیر)
	if ( $form_context === 'comments' ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'دسترسی غیرمجاز' );
			return;
		}
		if ( isset( $_POST['farazsms_comment_admin_phones'] ) ) {
			update_option( 'farazsms_comment_admin_phones', sanitize_text_field( wp_unslash( $_POST['farazsms_comment_admin_phones'] ) ), false );
		}
		if ( isset( $_POST['farazsms_comment_admin_pattern'] ) ) {
			update_option( 'farazsms_comment_admin_pattern', sanitize_text_field( wp_unslash( $_POST['farazsms_comment_admin_pattern'] ) ), false );
		}
		if ( isset( $_POST['farazsms_comment_admin_message'] ) ) {
			update_option( 'farazsms_comment_admin_message', wp_kses_post( wp_unslash( $_POST['farazsms_comment_admin_message'] ) ), false );
		}
		if ( isset( $_POST['farazsms_comment_user_approve_pattern'] ) ) {
			update_option( 'farazsms_comment_user_approve_pattern', sanitize_text_field( wp_unslash( $_POST['farazsms_comment_user_approve_pattern'] ) ), false );
		}
		if ( isset( $_POST['farazsms_comment_user_approve_message'] ) ) {
			update_option( 'farazsms_comment_user_approve_message', wp_kses_post( wp_unslash( $_POST['farazsms_comment_user_approve_message'] ) ), false );
		}
		if ( isset( $_POST['farazsms_comment_user_reply_pattern'] ) ) {
			update_option( 'farazsms_comment_user_reply_pattern', sanitize_text_field( wp_unslash( $_POST['farazsms_comment_user_reply_pattern'] ) ), false );
		}
		if ( isset( $_POST['farazsms_comment_user_reply_message'] ) ) {
			update_option( 'farazsms_comment_user_reply_message', wp_kses_post( wp_unslash( $_POST['farazsms_comment_user_reply_message'] ) ), false );
		}
		wp_send_json_success();
		return;
	}

	// فرم نظرسنجی: اگر apikey خالی و poll_pattern ارسال شده
	if ( empty( trim( $apikey ) ) && ! empty( $poll_pattern ) ) {
		update_option( 'farazsms_poll_pattern', sanitize_text_field( $poll_pattern ), false );
		update_option( 'farazsms_send_poll_sms', sanitize_text_field( $send_poll_sms ), false );
		update_option( 'farazsms_send_time', sanitize_text_field( $send_time ), false );
		update_option( 'farazsms_send_status', sanitize_text_field( $send_status ), false );
		wp_send_json_success();
		return;
	}

	if ( empty( trim( $apikey ) ) ) {
		wp_send_json_error( 'لطفا اطلاعات را کامل وارد کنید' );
		return;
	}

	update_option( 'farazsms_apikey', sanitize_text_field( $apikey ) );
	update_option( 'farazsms_pattern', sanitize_text_field( $pattern ), false );
	update_option( 'farazsms_sender', sanitize_text_field( $sender ) );

	if ( isset( $_POST['poll_pattern'] ) ) {
		update_option( 'farazsms_poll_pattern', sanitize_text_field( $poll_pattern ), false );
		update_option( 'farazsms_send_poll_sms', sanitize_text_field( $send_poll_sms ), false );
		update_option( 'farazsms_send_time', sanitize_text_field( $send_time ), false );
		update_option( 'farazsms_send_status', sanitize_text_field( $send_status ), false );
	}

	wp_send_json_success();
}

add_action('wp_ajax_farazsms_create_pattern', 'farazsms_create_pattern_callback');

function farazsms_create_pattern_callback() {
	// بررسی nonce با check_ajax_referer (خودش خطا را مدیریت می‌کند)
	check_ajax_referer('farazsms_create_pattern', 'nonce');
	// v3.21.26 امنیتی (P1): nonce اجازه نیست؛ این هندلر option می‌نویسد و API پولی صدا می‌زند.
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'دسترسی غیرمجاز', 403 );
		return;
	}

	// v3.13.19 BUG FIX: قبل از این، early-return فقط 'message_text' را چک می‌کرد
	// و باعث خطای «متن پیام ارسال نشده است» در صفحه ۳-پترنی کد رهگیری می‌شد
	// (که با کلید 'message' می‌فرستد). حالا هر دو کلید را early-check می‌کنیم.
	if ( ! isset( $_POST['message_text'] ) && ! isset( $_POST['message'] ) ) {
		wp_send_json_error( 'متن پیام ارسال نشده است.' );
		return;
	}

	// دریافت متن پیام — اول 'message_text' (JS قدیمی)، fallback به 'message' (JS جدید کد رهگیری).
	$message = '';
	if ( isset( $_POST['message_text'] ) && $_POST['message_text'] !== '' ) {
		$message = $_POST['message_text'];
	} elseif ( isset( $_POST['message'] ) && $_POST['message'] !== '' ) {
		$message = $_POST['message'];
	}

	// حذف slashes اضافی که WordPress اضافه می‌کند
	$message = wp_unslash($message);
	
	// حفظ خطوط جدید و کاراکترهای خاص، فقط کاراکترهای خطرناک را حذف کن
	$message = wp_check_invalid_utf8($message, true);
	
	if (empty(trim($message))) {
		wp_send_json_error('متن پیام خالی است.');
		return;
	}
	
	$section_type = isset($_POST['section_type']) ? sanitize_text_field($_POST['section_type']) : '';
	// افزودنِ آدرسِ سایت به انتهای متن، حالا به‌صورتِ متمرکز داخلِ خودِ توابعِ ساخت/آپدیتِ
	// پترن (farazsms_pattern_append_site_url) انجام می‌شود — برای همه‌ی بخش‌ها، یک‌جا.

	// v3.22.52: پترنِ OTPِ فرم‌ها (GF/Elementor) خطِ پایانیِ WebOTP بگیرد تا کدِ پیامک روی
	// اندروید/کروم خودکار در فیلد پر شود. این خط شاملِ %code% دومی است؛ عمداً به‌جای تزریق در متن
	// (که پارسرِ ضدِ‌تکرارِ متغیر ردش می‌کرد) به‌صورتِ extra_append پاس داده می‌شود تا «بعد از parse»
	// به متنِ نهایی بچسبد — پارسر فقط یک %code% می‌بیند ولی فراز متنِ دو-%code%ای را می‌پذیرد
	// (عیناً مثلِ پترنِ ماژولِ لاگین). ساختار: دامنه (بدونِ www، تا append_site_url را no-op کند و
	// WebOTP را آخر نگه دارد) سپس خطِ «@هاستِ‌دقیق #کد».
	$otp_webotp_append = '';
	if ( $section_type === 'otp' && strpos( $message, '%code%' ) !== false ) {
		$webotp_exact_host = (string) wp_parse_url( home_url(), PHP_URL_HOST ); // با www (باید با origin صفحه یکی باشد)
		if ( $webotp_exact_host !== '' ) {
			$webotp_brand_host = preg_replace( '/^www\./i', '', $webotp_exact_host );
			$otp_webotp_append = "\n" . $webotp_brand_host . "\n@" . $webotp_exact_host . ' #%code%';
		}
	}

	// تعیین کد پترن موجود (در صورت وجود) برای آپدیت به‌جای ساخت جدید
	$status_key = isset($_POST['status_key']) ? sanitize_text_field($_POST['status_key']) : '';
	$existing_code = '';
	$patterns = get_option('farazsms_patterns', array());
	// «tracking» عمداً از خواندنِ خانه‌ی مشترکِ آرایه‌ی patterns مستثناست: هر سه carrier
	// (پست/تیپاکس/سایر) status_key یکسانِ 'tracking' می‌فرستند، پس خواندن از این خانه هر سه
	// را به یک پترنِ واحد قفل می‌کرد و بلوکِ per-carrier پایین (خط ۲۱۹) هرگز اجرا نمی‌شد.
	// برای tracking کدِ موجود فقط از option اختصاصیِ همان carrier خوانده می‌شود.
	if ( ! empty( $section_type ) && $section_type !== 'tracking' && ! empty( $status_key ) && is_array( $patterns ) && isset( $patterns[ $section_type ][ $status_key ] ) ) {
		$existing_code = trim( $patterns[ $section_type ][ $status_key ] );
	}
	if ( empty( $existing_code ) && $section_type === 'otp' ) {
		$existing_code = trim( get_option( 'farazsms_otp_pattern', '' ) );
	}
	if ( empty( $existing_code ) && ( $section_type === '' || $section_type === 'tracking' ) ) {
		// v3.21.x رفعِ باگ «سه باکس، یک پترن»: هر carrier (پست/تیپاکس/سایر) باید پترنِ
		// مستقلِ خودش را بسازد/آپدیت کند. قبلاً کدِ موجود از farazsms_pattern (legacyِ مشترک)
		// خوانده می‌شد، پس هر سه carrier همان یک پترن را آپدیت می‌کردند و متنشان یکی می‌شد.
		// حالا کدِ موجود را از option اختصاصیِ همان carrier می‌خوانیم.
		$carrier_lookup = isset( $_POST['carrier'] ) ? sanitize_key( $_POST['carrier'] ) : '';
		if ( in_array( $carrier_lookup, array( 'post', 'tipax', 'other' ), true ) ) {
			$existing_code = trim( get_option( 'farazsms_pattern_' . $carrier_lookup, '' ) );
			// «پست» وارثِ پترنِ تک‌قلوی legacy است (سازگاریِ پس‌رو).
			if ( $existing_code === '' && $carrier_lookup === 'post' ) {
				$existing_code = trim( get_option( 'farazsms_pattern', '' ) );
			}
		} else {
			$existing_code = trim( get_option( 'farazsms_pattern', '' ) );
		}
	}
	$is_comment_section = ( $section_type === 'comment' || strpos( $section_type, 'comment' ) === 0 );
	if ( empty( $existing_code ) && $is_comment_section ) {
		if ( isset( $_POST['pattern_code'] ) ) {
			$posted = trim( sanitize_text_field( wp_unslash( $_POST['pattern_code'] ) ) );
			if ( $posted !== '' ) {
				$existing_code = $posted;
			}
		}
		if ( empty( $existing_code ) && ! empty( $status_key ) ) {
			$existing_code = farazsms_get_comment_pattern_code( $status_key );
		}
	}
	$use_update = ! empty( $existing_code );

	// v3.22.8: حالتِ صریحِ کاربر. 'new' یعنی «پترنِ کاملاً تازه بساز» — حتی اگر کدِ موجود
	// هست نادیده‌اش بگیر. این برای سایت‌هایی است که از دیتابیسِ سایتِ دیگری کپی شده‌اند و
	// کدپترنِ همان سایت را به ارث برده‌اند؛ ویرایش، پترنِ آن سایت را هم عوض می‌کند. 'edit'
	// (پیش‌فرض) رفتارِ قبلی است: اگر کدِ موجود هست آپدیت کن، وگرنه بساز.
	$pattern_mode = isset( $_POST['mode'] ) ? sanitize_key( $_POST['mode'] ) : 'edit';
	if ( $pattern_mode === 'new' ) {
		$use_update    = false;
		$existing_code = '';
	}

	// تعیین دسته پترن برای API: 1=otp, 3=order, 255=others
	if ( $section_type === 'otp' ) {
		$category = 1;
	} elseif ( in_array( $section_type, array( 'buyer', 'super_admin', 'product_admin' ), true ) || $section_type === '' || $section_type === 'tracking' ) {
		$category = 3;
	} else {
		$category = 255;
	}
	
	// v3.17.3: description همیشه برندشده — هر پترن به admin فراز می‌گوید
	// از کدام بخش افزونه فراز اس ام اس آمده.
	$carrier            = isset( $_POST['carrier'] ) ? sanitize_key( $_POST['carrier'] ) : '';
	$pattern_description = farazsms_pattern_brand_description( $section_type, $status_key, $carrier );

	// ارسال به IranPayamak: آپدیت پترن موجود یا ساخت جدید
	if ( in_array( $section_type, array( 'buyer', 'super_admin', 'product_admin' ) ) ) {
		$response = $use_update
			? farazsms_update_pattern_for_pwsms( $existing_code, $message, $category )
			: farazsms_create_pattern_for_pwsms( $message, $category, $pattern_description );
	} else {
		$response = $use_update
			? farazsms_update_pattern( $existing_code, $message, $category, $pattern_description, $otp_webotp_append )
			: farazsms_create_pattern( $message, $category, $pattern_description, $otp_webotp_append );
	}

	// ریسپانس ممکن است JSON استرینگ باشد → تبدیل به آرایه
	$data = json_decode($response, true);

	// اگر JSON نبود، احتمالاً خطاست
	if (!$data) {
		wp_send_json_error([
			'message' => 'خطا در پردازش پاسخ سرور: ' . substr($response, 0, 200),
			'raw_response' => $response
		]);
		return;
	}

	// اگر آپدیت انجام شده و پترن در پنل حذف شده باشد، به صورت خودکار پترن جدید بساز
	if ( $use_update && isset( $data['status'] ) && $data['status'] !== 'success' && function_exists( 'farazsms_is_pattern_not_found_response' ) && farazsms_is_pattern_not_found_response( $data ) ) {
		if ( in_array( $section_type, array( 'buyer', 'super_admin', 'product_admin' ), true ) ) {
			$response = farazsms_create_pattern_for_pwsms( $message, $category, $pattern_description );
		} else {
			$response = farazsms_create_pattern( $message, $category, $pattern_description, $otp_webotp_append );
		}
		$data = json_decode( $response, true );
		if ( ! $data ) {
			wp_send_json_error([
				'message' => 'خطا در پردازش پاسخ ساخت پترن جدید: ' . substr($response, 0, 200),
				'raw_response' => $response
			]);
			return;
		}
	}

	// بررسی وضعیت success
	if (isset($data['status']) && $data['status'] === 'success') {
		// استخراج code از: data → code (در آپدیت ممکن است خالی باشد، از کد قبلی استفاده می‌کنیم)
		$pattern_code = null;
		if (isset($data['data']) && is_string($data['data'])) {
			$pattern_code = sanitize_text_field($data['data']);
		} elseif (isset($data['data']['code'])) {
			$pattern_code = sanitize_text_field($data['data']['code']);
		}
		if ( empty( $pattern_code ) && $use_update && ! empty( $existing_code ) ) {
			$pattern_code = $existing_code;
		}
		// $section_type قبلاً در خط 67 تعریف شده است
		
		// اگر pattern_code پیدا شد، در option ذخیره کن
		if (!empty($pattern_code)) {
			// پترن OTP برای فرم‌های المنتور و گرویتی
			if ( $section_type === 'otp' ) {
				update_option( 'farazsms_otp_pattern', sanitize_text_field( $pattern_code ), false );
			}
			// به‌روزرسانی farazsms_pattern با کد پترن جدید — فقط برای بخش رهگیری (نه دیدگاه و نه پیامک فارسی)
			if ( ! $is_comment_section && $section_type !== 'otp' ) {
				// Multi-pattern (v3.13.7+): اگر carrier در POST آمده، در option اختصاصی همان carrier ذخیره کن.
				$carrier = isset( $_POST['carrier'] ) ? sanitize_text_field( wp_unslash( $_POST['carrier'] ) ) : '';
				if ( in_array( $carrier, array( 'post', 'tipax', 'other' ), true ) ) {
					update_option( 'farazsms_pattern_' . $carrier, sanitize_text_field( $pattern_code ), false );
					if ( ! empty( $message ) ) {
						update_option( 'farazsms_message_' . $carrier, wp_unslash( $message ), false );
					}
					// post همیشه در farazsms_pattern قدیمی هم mirror می‌شود (backward compat).
					if ( $carrier === 'post' ) {
						update_option( 'farazsms_pattern', sanitize_text_field( $pattern_code ), false );
					}
				} else {
					// Fallback به رفتار قبلی.
					update_option( 'farazsms_pattern', sanitize_text_field( $pattern_code ), false );
				}
			}
			if ( $is_comment_section && ! empty( $status_key ) ) {
				$comment_option = farazsms_comment_pattern_option_name( $status_key );
				if ( $comment_option !== '' ) {
					update_option( $comment_option, sanitize_text_field( $pattern_code ), false );
				}
			}
			// ذخیره متن پیام در farazsms_message - فقط برای بخش رهگیری (نه پیامک فارسی و نه دیدگاه)
			if (!empty($message) && !in_array($section_type, ['buyer', 'super_admin', 'product_admin']) && ! $is_comment_section) {
				update_option('farazsms_message', wp_unslash($message), false);
			}
			// اگر status_key وجود داشت، در array structure هم ذخیره کن.
			// «tracking» مستثناست: منبعِ حقیقتش option‌های per-carrier (farazsms_pattern_<carrier>)
			// است؛ نوشتن در خانه‌ی مشترکِ ['tracking']['tracking'] هر سه carrier را به‌هم قفل می‌کرد.
			if (!empty($status_key) && $section_type !== 'tracking') {
			// دریافت array موجود
			$patterns = get_option('farazsms_patterns', []);
			
			// اطمینان از وجود ساختار
			if (!is_array($patterns)) {
				$patterns = [];
			}
			if (!isset($patterns[$section_type])) {
				$patterns[$section_type] = [];
			}
			
			// ذخیره کد پترن برای این وضعیت
			$patterns[$section_type][$status_key] = $pattern_code;
			
			// ذخیره در option
			update_option('farazsms_patterns', $patterns, false);
			}
		}
 
		
		if ($pattern_code) {
			$success_msg = $use_update
				? 'پترن با موفقیت به‌روزرسانی شد.'
				: 'پترن با موفقیت ایجاد شد و تنظیمات به‌روزرسانی شد.';
			wp_send_json_success([
				'message' => $success_msg,
				'pattern_code' => $pattern_code,
				'updated' => $use_update,
				'status_key' => $status_key,
				'section_type' => $section_type,
				'response' => $data
			]);
			return;
		}

		wp_send_json_error([
			'message' => 'فیلد code در پاسخ پیدا نشد.',
			'response' => $data
		]);
		return;
	}

	// اگر status != success بود
	$error_message = isset($data['message']) ? $data['message'] : 'خطای نامشخص در ساخت پترن.';
	if (isset($data['messages']) && is_array($data['messages'])) {
		$error_message = implode(', ', $data['messages']);
	}
	
	wp_send_json_error([
		'message' => $error_message,
		'response' => $data
	]);
}

/**
 * AJAX endpoint برای دریافت جزئیات پترن
 */
add_action('wp_ajax_farazsms_get_pattern_details', 'farazsms_get_pattern_details_callback');

function farazsms_get_pattern_details_callback() {
	// بررسی nonce
	if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'farazsms_get_pattern_details')) {
		wp_send_json_error('خطا در احراز هویت.');
		return;
	}
	// v3.21.26 امنیتی (P1): این هندلر با کلیدِ سایت از پنل می‌خواند → فقط مدیر.
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'دسترسی غیرمجاز', 403 );
		return;
	}

	if (!isset($_POST['pattern_code']) || empty($_POST['pattern_code'])) {
		wp_send_json_error('کد پترن ارسال نشده است.');
		return;
	}

	$pattern_code = sanitize_text_field($_POST['pattern_code']);
	$section_type = isset($_POST['section_type']) ? sanitize_text_field($_POST['section_type']) : '';
	
	// دریافت جزئیات پترن از API
	// اگر section_type مربوط به پیامک فارسی است، از farazsms_get_pattern_details_for_pwsms استفاده کن
	// در غیر این صورت از farazsms_get_pattern_details استفاده کن (برای بخش رهگیری)
	if (in_array($section_type, ['buyer', 'super_admin', 'product_admin'])) {
		// استفاده از تابع دریافت جزئیات پترن برای پیامک فارسی (apikey از PWSMS گرفته می‌شود)
		$response = farazsms_get_pattern_details_for_pwsms($pattern_code);
	} else {
		// استفاده از تابع دریافت جزئیات پترن برای بخش رهگیری (apikey از farazsms_apikey گرفته می‌شود)
		$response = farazsms_get_pattern_details($pattern_code);
	}
	
	// ریسپانس ممکن است JSON استرینگ باشد → تبدیل به آرایه
	$data = json_decode($response, true);
	
	// اگر JSON نبود، احتمالاً خطاست
	if (!$data) {
		wp_send_json_error([
			'message' => 'خطا در پردازش پاسخ سرور: ' . substr($response, 0, 200),
			'raw_response' => $response
		]);
		return;
	}
	
	// بررسی وضعیت success
	if (isset($data['status']) && $data['status'] === 'success') {
		wp_send_json_success([
			'pattern_code' => $pattern_code,
			'data' => $data['data'] ?? null,
			'response' => $data
		]);
		return;
	}
	
	// اگر status != success بود
	$error_message = isset($data['message']) ? $data['message'] : 'خطای نامشخص در دریافت جزئیات پترن.';
	if (isset($data['messages']) && is_array($data['messages'])) {
		$error_message = implode(', ', $data['messages']);
	}
	
	wp_send_json_error([
		'message' => $error_message,
		'response' => $data
	]);
}



add_action( 'wp_ajax_farazsms_save_wc_sms_data', 'farazsms_save_wc_sms_data' );
// nopriv intentionally NOT registered — admin-only endpoint that writes to wp_options.
function farazsms_save_wc_sms_data() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'دسترسی غیرمجاز', 403 );
		return;
	}
	if ( ! check_ajax_referer( 'farazsms_save_settings', 'farazsms_save_nonce', false ) ) {
		wp_send_json_error( 'نشست منقضی شده است؛ صفحه را یک‌بار رفرش کنید.' );
		return;
	}
	$so_tmp = array();
	$sms_data = $_POST['sms_data'] ?? '';
	if ( ! is_array( $sms_data ) ) {
		wp_send_json_error( 'داده‌ای برای ذخیره ارسال نشد.' );
		return;
	}
	foreach ( $sms_data as $i => $data ) {
		preg_match_all( '!\d+!', $data['name'], $match_id );
		preg_match_all( "/\[([^\]]*)\]/", $data['name'], $match_name );
		$so_tmp[ $match_id[0][0] ][ $match_name[1][1] ] = $data['value'];
	}
	update_option( 'farazsms_wc_sms_data', $so_tmp, false );
	wp_send_json_success();
}

add_action( 'wp_ajax_farazsms_save_users_sms_data', 'farazsms_save_users_sms_data' );
// nopriv intentionally NOT registered — admin-only endpoint that writes to wp_options.
function farazsms_save_users_sms_data() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'دسترسی غیرمجاز', 403 );
		return;
	}
	if ( ! check_ajax_referer( 'farazsms_save_settings', 'farazsms_save_nonce', false ) ) {
		wp_send_json_error( 'نشست منقضی شده است؛ صفحه را یک‌بار رفرش کنید.' );
		return;
	}
	$so_tmp = array();
	$sms_data = $_POST['sms_data'] ?? '';
	if ( ! is_array( $sms_data ) ) {
		wp_send_json_error( 'داده‌ای برای ذخیره ارسال نشد.' );
		return;
	}
	foreach ( $sms_data as $i => $data ) {
		preg_match_all( '!\d+!', $data['name'], $match_id );
		preg_match_all( "/\[([^\]]*)\]/", $data['name'], $match_name );
		$so_tmp[ $match_id[0][0] ][ $match_name[1][1] ] = $data['value'];
	}
	update_option( 'farazsms_users_sms_data', $so_tmp, false );
	wp_send_json_success();
}

add_action( 'wp_ajax_farazsms_save_users_settings', 'farazsms_save_users_settings' );
// nopriv intentionally NOT registered — admin-only endpoint that writes to wp_options.
function farazsms_save_users_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'دسترسی غیرمجاز', 403 );
		return;
	}
	if ( ! check_ajax_referer( 'farazsms_save_settings', 'farazsms_save_nonce', false ) ) {
		wp_send_json_error( 'نشست منقضی شده است؛ صفحه را یک‌بار رفرش کنید.' );
		return;
	}
	update_option( 'farazsms_active_digits', sanitize_text_field( $_POST['farazsms_active_digits'] ?? '' ), false );
	update_option( 'farazsms_custom_phone_meta_keys', sanitize_text_field( $_POST['farazsms_custom_phone_meta_keys'] ?? '' ), false );
	wp_send_json_success();
}

add_action( 'wp_ajax_farazsms_save_gf_sms_data', 'farazsms_save_gf_sms_data' );
// nopriv intentionally NOT registered — admin-only endpoint that writes to wp_options.
function farazsms_save_gf_sms_data() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'دسترسی غیرمجاز', 403 );
		return;
	}
	if ( ! check_ajax_referer( 'farazsms_save_settings', 'farazsms_save_nonce', false ) ) {
		wp_send_json_error( 'نشست منقضی شده است؛ صفحه را یک‌بار رفرش کنید.' );
		return;
	}
	$so_tmp = array();
	$sms_data = $_POST['sms_data'] ?? '';
	if ( ! is_array( $sms_data ) ) {
		wp_send_json_error( 'داده‌ای برای ذخیره ارسال نشد.' );
		return;
	}
	foreach ( $sms_data as $i => $data ) {
		preg_match_all( '!\d+!', $data['name'], $match_id );
		preg_match_all( "/\[([^\]]*)\]/", $data['name'], $match_name );
		//print_r($match_name);
		if ( ! empty( $data['value'] ) ) {
			if ( isset( $match_id[0][1] ) ) {
				$so_tmp[ $match_id[0][0] ]['condition'][ $match_id[0][1] ][ $match_name[1][2] ] = $data['value'];
			} else {
				$so_tmp[ $match_id[0][0] ][ $match_name[1][1] ] = $data['value'];
			}
		}
	}
	update_option( 'farazsms_gf_sms_data', $so_tmp, false );
	wp_send_json_success();
}
