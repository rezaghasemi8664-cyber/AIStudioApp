<?php
/**
 * کوتاه‌کننده‌ی لینک (سرویسِ فراز: frzs.ir / Kutt.it) برای متنِ پیامک.
 *
 * مشکل: لینک‌های بلندِ سبدِ رهاشده/نظرسنجی/موجودشد متنِ پیامک را زشت و طولانی می‌کنند و
 * به‌دلیلِ لینکِ ناشناس، پیامک در صفِ مانیتورینگ می‌افتد (تأخیر + هزینه‌ی بیشتر).
 * راه‌حل: کوتاه‌کردنِ لینک با سرویسِ کوتاه‌کننده‌ی فراز (frzs.ir).
 *
 * کلید/آدرس به‌صورتِ سرویسِ مشترکِ فراز hardcode شده‌اند (فعلاً کاربر کوتاه‌کننده‌ی دیگری
 * انتخاب نمی‌کند). انتخابِ «کوتاه‌کننده یا لینکِ سایتِ اصلی» در تنظیماتِ هر ماژول است.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

// سرویسِ مشترکِ فراز (frzs.ir). در آینده اگر لازم شد قابلِ override با constant در wp-config.
if ( ! defined( 'FARAZSMS_KUTT_BASE' ) ) {
	define( 'FARAZSMS_KUTT_BASE', 'https://frzs.ir' );
}
if ( ! defined( 'FARAZSMS_KUTT_KEY' ) ) {
	define( 'FARAZSMS_KUTT_KEY', 'ztWMf5od8Bar4YXj0ecuxIw19VL9GyF7moSLtIHp' );
}
// انقضای لینکِ کوتاه‌شده: لینک‌ها ۷ روز فعال می‌مانند و بعد آزاد (قابلِ استفاده‌ی مجدد)
// می‌شوند تا حسابِ کوتاه‌کننده با لینک‌های دائمیِ انباشته نشود. فرمتِ موردِ قبولِ Kutt: «N days».
if ( ! defined( 'FARAZSMS_KUTT_EXPIRE_IN' ) ) {
	define( 'FARAZSMS_KUTT_EXPIRE_IN', '7 days' );
}

const FARAZSMS_SHORTENER_MODES_OPTION = 'farazsms_shortener_modes';

/**
 * حالتِ هر ماژول: 'short' (کوتاه‌کننده، پیش‌فرض) یا 'direct' (لینکِ سایتِ اصلی).
 *
 * v3.22.71: انتخابِ per-module دوباره برگشت (در v3.22.43 موقتاً حذف شده بود). مدیر می‌تواند برای
 * هر ماژول بینِ کوتاه‌کننده و لینکِ سایتِ اصلی یکی را انتخاب کند. پیش‌فرض همچنان 'short'.
 */
function farazsms_shortener_mode( $module_key ) {
	$modes = get_option( FARAZSMS_SHORTENER_MODES_OPTION, array() );
	if ( ! is_array( $modes ) ) {
		$modes = array();
	}
	return ( isset( $modes[ $module_key ] ) && $modes[ $module_key ] === 'direct' ) ? 'direct' : 'short';
}

/**
 * کوتاه‌کردنِ یک URL برای یک ماژول. اگر حالتِ ماژول «direct» باشد یا API خطا دهد، همان
 * URLِ اصلی برمی‌گردد (هرگز پیامک را نمی‌شکند).
 *
 * @param string $url
 * @param string $module_key  'abandoned' | 'survey' | 'notify'
 * @param string $description توضیحِ لینک در پنلِ کوتاه‌کننده (مثلِ «ماژول … / کاربری …»)
 * @return string
 */
function farazsms_shorten_link( $url, $module_key = '', $description = '' ) {
	$url = (string) $url;
	if ( $url === '' ) {
		return $url;
	}
	if ( $module_key !== '' && farazsms_shortener_mode( $module_key ) !== 'short' ) {
		return $url; // کاربر برای این ماژول «لینکِ سایتِ اصلی» را انتخاب کرده.
	}
	$base = rtrim( FARAZSMS_KUTT_BASE, '/' );
	$key  = FARAZSMS_KUTT_KEY;
	if ( $base === '' || $key === '' ) {
		return $url;
	}

	$cache_key = 'farazsms_short_' . md5( $base . '|' . $url );
	$cached    = get_transient( $cache_key );
	if ( is_string( $cached ) && $cached !== '' ) {
		return $cached;
	}

	// v3.22.44 (بازبینی T6): circuit-breaker. حالا که کوتاه‌کننده همیشه فعال است، لینکِ فاکتور هم
	// روی مسیرِ checkout (پیامکِ سفارش) کوتاه می‌شود. اگر kutt در دسترس نباشد، هر سفارش با URLِ
	// یکتا (بدونِ cache) ۸ثانیه معطل می‌شد. با این breaker، پس از یک شکست تا ۵ دقیقه اصلاً تلاش
	// نمی‌کنیم و بی‌درنگ لینکِ اصلی برمی‌گردد.
	if ( get_transient( 'farazsms_shortener_down' ) ) {
		return $url;
	}

	$resp = wp_remote_post( $base . '/api/v2/links', array(
		'timeout' => 8, // در مسیرِ cron/دیسپچ اجرا می‌شود، نه رندرِ صفحه.
		'headers' => array(
			'Content-Type' => 'application/json',
			'X-API-KEY'    => $key,
		),
		'body'    => wp_json_encode( array_filter( array(
			'target'      => $url,
			'description' => $description !== '' ? mb_substr( $description, 0, 200 ) : '',
			// انقضای ۳۰روزه (اگر تعریف‌شده). با array_filter اگر خالی باشد ارسال نمی‌شود.
			'expire_in'   => defined( 'FARAZSMS_KUTT_EXPIRE_IN' ) ? FARAZSMS_KUTT_EXPIRE_IN : '',
		), function ( $v ) { return $v !== '' && $v !== null; } ) ),
	) );
	if ( is_wp_error( $resp ) ) {
		set_transient( 'farazsms_shortener_down', 1, 5 * MINUTE_IN_SECONDS ); // T6 breaker
		return $url;
	}
	$code = (int) wp_remote_retrieve_response_code( $resp );
	$data = json_decode( wp_remote_retrieve_body( $resp ), true );
	if ( $code >= 200 && $code < 300 && is_array( $data ) ) {
		$short = '';
		if ( ! empty( $data['link'] ) ) {
			$short = (string) $data['link'];
		} elseif ( ! empty( $data['address'] ) ) {
			$short = (string) $data['address'];
		}
		if ( $short !== '' && strpos( $short, 'http' ) !== 0 ) {
			$short = $base . '/' . ltrim( $short, '/' );
		}
		if ( $short !== '' ) {
			// کش کوتاه‌تر از عمرِ لینک (۷ روز) تا لینکِ منقضی‌شده دوباره از کش برنگردد.
			set_transient( $cache_key, $short, 6 * DAY_IN_SECONDS );
			return $short;
		}
	} elseif ( $code < 200 || $code >= 300 ) {
		// پاسخِ ناموفقِ سرور → breaker را فعال کن (T6) تا هر ارسال دوباره ۸ثانیه معطل نشود.
		set_transient( 'farazsms_shortener_down', 1, 5 * MINUTE_IN_SECONDS );
	}
	return $url; // fallback امن
}

// ============================================================================
// انتخابِ روشِ ارسالِ لینک — برای درج در تنظیماتِ هر ماژول.
// ============================================================================

/**
 * یک فرمِ کوچکِ خودبسنده (با nonce و submitِ خودش) که روشِ ارسالِ لینکِ این ماژول را می‌پرسد.
 * در تنظیماتِ سبدِ رهاشده / نظرسنجی / موجودشد فراخوانی می‌شود.
 *
 * @param string $module_key
 * @param string $module_label
 */
function farazsms_shortener_render_choice( $module_key, $module_label ) {
	// v3.22.71: فرمِ انتخابِ دوحالته دوباره برگشت (کوتاه‌کننده / لینکِ سایتِ اصلی).
	$mode = farazsms_shortener_mode( $module_key );
	?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="background:#f5f8fe; border:1px solid #e1e1e1; border-radius:12px; padding:16px 18px; margin:18px 0; max-width:680px; direction:rtl;">
		<input type="hidden" name="action" value="farazsms_shortener_save_mode">
		<input type="hidden" name="module" value="<?php echo esc_attr( $module_key ); ?>">
		<?php wp_nonce_field( 'farazsms_shortener_mode_' . $module_key, 'farazsms_shortener_mode_nonce' ); ?>
		<div style="font-size:14px; font-weight:700; color:#263f67; margin-bottom:4px;">🔗 روشِ ارسالِ لینک در پیامک</div>
		<p style="font-size:12px; color:#9b9b9b; margin:0 0 10px; line-height:1.9;">لینک‌های بلند متنِ پیامک را زشت و گران می‌کنند و در صفِ مانیتورینگ می‌افتند. توصیه: کوتاه‌کننده.</p>

		<label style="display:block; padding:9px 11px; border:1px solid <?php echo $mode === 'short' ? '#10c282' : '#e1e1e1'; ?>; border-radius:8px; margin-bottom:8px; cursor:pointer; background:<?php echo $mode === 'short' ? '#e2f8f0' : '#fff'; ?>;">
			<input type="radio" name="shortener_mode" value="short" <?php checked( $mode, 'short' ); ?>>
			<strong>ارسال با کوتاه‌کننده (پیشنهادی)</strong>
			<span style="display:block; font-size:12px; color:#096d49; margin-top:4px; padding-right:22px;">⚡ ارسالِ سریع‌تر • 💰 هزینه‌ی کمتر (در صفِ مانیتورینگ نمی‌رود) • ✨ متنِ پیامکِ زیباتر</span>
		</label>
		<label style="display:block; padding:9px 11px; border:1px solid <?php echo $mode === 'direct' ? '#e2a916' : '#e1e1e1'; ?>; border-radius:8px; cursor:pointer; background:<?php echo $mode === 'direct' ? '#faf1da' : '#fff'; ?>;">
			<input type="radio" name="shortener_mode" value="direct" <?php checked( $mode, 'direct' ); ?>>
			<strong>ارسال با لینکِ سایتِ اصلی</strong>
			<span style="display:block; font-size:12px; color:#c2410c; margin-top:4px; padding-right:22px;">لینکِ طولانی‌تر • هزینه‌ی بیشتر (افزایشِ کاراکتر) • احتمالِ افتادن در صفِ مانیتورینگ</span>
		</label>

		<button type="submit" class="button button-primary" style="margin-top:10px;">💾 ذخیره روشِ لینک (<?php echo esc_html( $module_label ); ?>)</button>
	</form>
	<?php
}

add_action( 'admin_post_farazsms_shortener_save_mode', 'farazsms_shortener_save_mode' );
function farazsms_shortener_save_mode() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	$module = isset( $_POST['module'] ) ? sanitize_key( $_POST['module'] ) : '';
	check_admin_referer( 'farazsms_shortener_mode_' . $module, 'farazsms_shortener_mode_nonce' );
	if ( $module !== '' ) {
		$modes = get_option( FARAZSMS_SHORTENER_MODES_OPTION, array() );
		if ( ! is_array( $modes ) ) {
			$modes = array();
		}
		$modes[ $module ] = ( ( $_POST['shortener_mode'] ?? 'short' ) === 'direct' ) ? 'direct' : 'short';
		update_option( FARAZSMS_SHORTENER_MODES_OPTION, $modes, false );
	}
	wp_safe_redirect( wp_get_referer() ?: admin_url() );
	exit;
}
