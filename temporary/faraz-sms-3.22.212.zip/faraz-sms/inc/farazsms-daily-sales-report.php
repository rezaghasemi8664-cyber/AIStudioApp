<?php
/**
 * Daily Sales Report SMS — Phase 14 (v3.14.8)
 *
 * هر شب ساعت 00:10 (پیش‌فرض)، آمار فروشِ خالصِ روزِ تقویمیِ قبل (مجموع مبلغ + تعداد سفارش)
 * را به شماره مدیران فروشگاه به‌صورت پیامک با پترن ارسال می‌کند.
 *
 * Option:
 *
 *   farazsms_daily_sales_settings:
 *     - enabled        ('1' یا '0' — پیش‌فرض: '1')
 *     - admin_phones   (رشته با شماره‌ها جدا با ,)
 *     - pattern_code   (پیش‌فرض: GPwbnk6dDE)
 *     - hour           (پیش‌فرض: '00:10')
 *
 * متغیرهای پترن:
 *   - %amount%       مجموع مبلغ سفارشات
 *   - %order_count%  تعداد سفارشات
 *
 * طراحی برای ۱۰۰k سایت:
 *   - یک query WC_Order_Query در روز فقط در cron — صفر impact روی frontend
 *   - statuses فقط 'completed' و 'processing' — قابل تنظیم با فیلتر
 *   - چند شماره مدیر → چند ریکوئست جدا به API فراز (پترن single-recipient است)
 *   - اگر WC غیرفعال شد یا API قطع شد، cron برمی‌گردد بدون خطا
 *   - تابع render در صفحه تنظیمات افزونه inject می‌شود (نه صفحه جدا)
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_DAILY_REPORT_CRON_HOOK = 'farazsms_daily_sales_report_cron';

function farazsms_daily_report_get_settings() {
	$defaults = array(
		'enabled'         => '1',   // گزارشِ روزانه
		'weekly_enabled'  => '1',   // v3.21.89: گزارشِ هفتگی (پیش‌فرض روشن)
		'monthly_enabled' => '1',   // v3.21.89: گزارشِ ماهانه (پیش‌فرض روشن)
		'skip_zero'       => '0',   // v3.21.89: در دوره‌ی بدونِ فروش پیامک نفرست
		'admin_phones'    => '',
		'pattern_code'    => 'GPwbnk6dDE',
		'hour'            => '00:10',
	);
	$saved = get_option( 'farazsms_daily_sales_settings', array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}
	return array_merge( $defaults, $saved );
}

/** تنظیماتِ پترنِ گزارشِ هفتگی (کد + متن) — در option جدا تا سازنده‌ی پترن مستقل بنویسد. */
function farazsms_weekly_report_get() {
	$s = get_option( 'farazsms_weekly_report_settings', array() );
	if ( ! is_array( $s ) ) {
		$s = array();
	}
	return array(
		'pattern_code' => isset( $s['pattern_code'] ) ? (string) $s['pattern_code'] : '',
		'message'      => isset( $s['message'] ) && $s['message'] !== '' ? (string) $s['message']
			: farazsms_report_default_message( 'weekly' ),
	);
}

/** تنظیماتِ پترنِ گزارشِ ماهانه (کد + متن). */
function farazsms_monthly_report_get() {
	$s = get_option( 'farazsms_monthly_report_settings', array() );
	if ( ! is_array( $s ) ) {
		$s = array();
	}
	return array(
		'pattern_code' => isset( $s['pattern_code'] ) ? (string) $s['pattern_code'] : '',
		'message'      => isset( $s['message'] ) && $s['message'] !== '' ? (string) $s['message']
			: farazsms_report_default_message( 'monthly' ),
	);
}

/**
 * پیش‌فرضِ متنِ هر دوره‌ی گزارش — تک‌منبعِ حقیقت.
 *
 * تا پیش از این، پیش‌فرضِ روزانه فقط درون‌خطی در فرمِ تنظیمات بود؛ یعنی هر مصرف‌کننده‌ی دیگری
 * (مثلِ مسیرِ بله که برای ساختِ متنِ حل‌شده به همان قالب نیاز دارد) مجبور بود نسخه‌ی دومی از
 * همان متن بسازد. حالا رابطِ کاربری و مسیرِ بله هر دو از همین‌جا می‌خوانند.
 *
 * @param string $period 'daily' | 'weekly' | 'monthly'
 * @return string
 */
function farazsms_report_default_message( $period ) {
	$defaults = array(
		'daily'   => "📊 گزارش فروش دیروز\nمبلغ کل: %amount% تومان\nتعداد سفارش: %order_count%",
		'weekly'  => "📊 گزارشِ فروشِ هفتگی\nهفته‌ی گذشته: %amount% تومان (%order_count% سفارش)\nهفته‌ی قبل‌تر: %prev_amount% تومان (%prev_order_count% سفارش)",
		'monthly' => "📊 گزارشِ فروشِ ماهانه\nماهِ گذشته: %amount% تومان (%order_count% سفارش)\nماهِ قبل‌تر: %prev_amount% تومان (%prev_order_count% سفارش)",
	);
	$period = (string) $period;
	return isset( $defaults[ $period ] ) ? $defaults[ $period ] : $defaults['daily'];
}

/**
 * قالبِ متنِ یک دوره: متنِ ذخیره‌شده‌ی همان دوره، وگرنه پیش‌فرضِ همان دوره.
 * هرگز رشته‌ی خالی برنمی‌گرداند — پس هیچ‌وقت متنِ خالی به کانالِ بله نمی‌رود.
 *
 * @param string $period 'daily' | 'weekly' | 'monthly'
 * @return string
 */
function farazsms_report_period_message( $period ) {
	$period = (string) $period;
	if ( 'weekly' === $period ) {
		$w   = farazsms_weekly_report_get();
		$msg = (string) $w['message'];
	} elseif ( 'monthly' === $period ) {
		$m   = farazsms_monthly_report_get();
		$msg = (string) $m['message'];
	} else {
		$s   = farazsms_daily_report_get_settings();
		$msg = isset( $s['message'] ) ? (string) $s['message'] : '';
	}
	return trim( $msg ) !== '' ? $msg : farazsms_report_default_message( $period );
}

/**
 * تصمیمِ ارسالِ کانالِ بله برای یک گزارش — واحدِ خالص تا هر سناریو بدونِ شبکه آزمودنی باشد.
 *
 * قاعده: گیرنده‌های بله فقط شماره‌هایی‌اند که پیامکشان موفق بوده، و متن از قالبِ محلیِ همان
 * دوره با مقادیرِ همان ارسال بازسازی می‌شود (متنِ تازه نوشته نمی‌شود).
 *
 * @param string $period           'daily' | 'weekly' | 'monthly'
 * @param string $message_template قالبِ پاس‌داده‌شده؛ خالی → قالبِ همان دوره.
 * @param array  $attrs            همان متغیرهایی که برای پیامک ساخته شدند.
 * @param array  $sent_phones      شماره‌هایی که پیامکشان موفق بود.
 * @return array آرایه‌ی خالی یعنی «هیچ فراخوانیِ بله‌ای»؛ وگرنه array( recipients, text ).
 */
function farazsms_report_bale_payload( $period, $message_template, $attrs, $sent_phones ) {
	$sent_phones = array_values( array_unique( array_filter(
		array_map( 'strval', array_filter( (array) $sent_phones, 'is_scalar' ) ),
		'strlen'
	) ) );
	if ( empty( $sent_phones ) ) {
		return array(); // شکستِ کاملِ پیامک → بله هم نباید برود
	}
	$template = trim( (string) $message_template ) !== ''
		? (string) $message_template
		: farazsms_report_period_message( $period );
	$text = farazsms_bale_resolve_local_text( $template, is_array( $attrs ) ? $attrs : array() );
	if ( trim( $text ) === '' ) {
		return array(); // متنِ خالی هرگز به بله نمی‌رود
	}
	return array( 'recipients' => $sent_phones, 'text' => $text );
}

function farazsms_daily_report_is_enabled() {
	$s = farazsms_daily_report_get_settings();
	return $s['enabled'] === '1';
}

// ── Cron Registration ────────────────────────────────────────────────────

/**
 * ثبت cron — همیشه یک‌بار در روز.
 * نکته: WP-Cron قابل اعتماد نیست برای زمان دقیق (فقط در بازدید سایت اجرا می‌شود).
 * برای زمان دقیق، system cron پیشنهاد می‌شود (راهنما در UI نوشته شده).
 */
add_action( 'init', 'farazsms_daily_report_schedule_cron' );
function farazsms_daily_report_schedule_cron() {
	// بدونِ ووکامرس گزارشِ فروشی وجود ندارد — cron زمان‌بندی نشود.
	if ( ! function_exists( 'wc_get_orders' ) ) {
		return;
	}
	if ( wp_next_scheduled( FARAZSMS_DAILY_REPORT_CRON_HOOK ) ) {
		return;
	}
	// زمان اجرای اول: ساعت تنظیم‌شده فردا
	$s          = farazsms_daily_report_get_settings();
	$hour       = $s['hour'];
	$site_tz    = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'Asia/Tehran' );
	$tomorrow   = new DateTime( 'tomorrow ' . $hour, $site_tz );
	$timestamp  = $tomorrow->getTimestamp();
	wp_schedule_event( $timestamp, 'daily', FARAZSMS_DAILY_REPORT_CRON_HOOK );
}

// re-schedule هر بار که option تغییر کرد (تغییر ساعت)
add_action( 'update_option_farazsms_daily_sales_settings', 'farazsms_daily_report_reschedule', 10, 2 );
function farazsms_daily_report_reschedule( $old, $new ) {
	$old_hour = ( is_array( $old ) && isset( $old['hour'] ) ) ? $old['hour'] : '';
	$new_hour = ( is_array( $new ) && isset( $new['hour'] ) ) ? $new['hour'] : '00:10';
	if ( $old_hour === $new_hour ) {
		return;
	}
	wp_clear_scheduled_hook( FARAZSMS_DAILY_REPORT_CRON_HOOK );
	$site_tz   = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'Asia/Tehran' );
	$tomorrow  = new DateTime( 'tomorrow ' . $new_hour, $site_tz );
	wp_schedule_event( $tomorrow->getTimestamp(), 'daily', FARAZSMS_DAILY_REPORT_CRON_HOOK );
}

// ── Cron Handler ────────────────────────────────────────────────────────

add_action( FARAZSMS_DAILY_REPORT_CRON_HOOK, 'farazsms_daily_report_run' );
/**
 * v3.21.89: دیسپچرِ سه‌دوره‌ای. کرونِ روزانه اجرا می‌شود و بسته به مرزهای تقویمِ شمسی،
 * گزارشِ روزانه (همیشه)، هفتگی (شنبه‌ها = شروعِ هفته‌ی ایرانی) و ماهانه (اولِ ماهِ شمسی) را
 * می‌فرستد. هر گزارش دوره‌ی کاملِ قبل را با دوره‌ی پیش از آن مقایسه می‌کند.
 */
function farazsms_daily_report_run( $force = false ) {
	if ( ! function_exists( 'wc_get_orders' ) ) {
		return; // WC غیرفعال — silent skip
	}
	$s      = farazsms_daily_report_get_settings();
	$phones = farazsms_report_recipients( $s );
	if ( empty( $phones ) ) {
		return;
	}
	$skip_zero = ( $s['skip_zero'] === '1' );
	$site_tz   = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'Asia/Tehran' );
	$today_mid = new DateTime( 'today 00:00:00', $site_tz );
	$today_ts  = $today_mid->getTimestamp();
	$today_str = $today_mid->format( 'Y-m-d' );

	// ── روزانه ─────────────────────────────────────────────
	if ( $s['enabled'] === '1' && trim( (string) $s['pattern_code'] ) !== ''
		&& ( $force || get_option( 'farazsms_report_last_daily' ) !== $today_str ) ) {
		$start = ( clone $today_mid )->modify( '-1 day' )->getTimestamp();
		list( $amt, $cnt ) = farazsms_report_calc_range( $start, $today_ts - 1 );
		// v3.22.119: «فروشِ صفر» = تعدادِ صفر «یا» مبلغِ صفر/منفی (مثلِ روزی که همه‌ی سفارش‌ها مسترد شده‌اند).
		if ( ! ( $skip_zero && ( $cnt === 0 || $amt <= 0 ) ) ) {
			$attrs = array( 'amount' => number_format( $amt ), 'order_count' => (string) $cnt );
			farazsms_report_send( $phones, trim( (string) $s['pattern_code'] ), $attrs, 'daily', $amt, $cnt, farazsms_report_period_message( 'daily' ) );
		}
		update_option( 'farazsms_report_last_daily', $today_str, false );
	}

	// ── هفتگی (فقط شنبه = شروعِ هفته‌ی ایرانی) ───────────────
	$weekly = farazsms_weekly_report_get();
	if ( $s['weekly_enabled'] === '1' && trim( $weekly['pattern_code'] ) !== ''
		&& ( $force || (int) $today_mid->format( 'N' ) === 6 ) // ISO: شنبه = 6 (در تست دور زده می‌شود)
		&& ( $force || get_option( 'farazsms_report_last_weekly' ) !== $today_str ) ) {
		$cur_start  = ( clone $today_mid )->modify( '-7 days' )->getTimestamp();  // هفته‌ی گذشته
		$prev_start = ( clone $today_mid )->modify( '-14 days' )->getTimestamp(); // هفته‌ی قبل‌تر
		list( $amt, $cnt )   = farazsms_report_calc_range( $cur_start, $today_ts - 1 );
		list( $pamt, $pcnt ) = farazsms_report_calc_range( $prev_start, $cur_start - 1 );
		if ( ! ( $skip_zero && ( $cnt === 0 || $amt <= 0 ) ) ) {
			farazsms_report_send( $phones, $weekly['pattern_code'], farazsms_report_compare_attrs( $amt, $cnt, $pamt, $pcnt ), 'weekly', $amt, $cnt, farazsms_report_period_message( 'weekly' ) );
		}
		update_option( 'farazsms_report_last_weekly', $today_str, false );
	}

	// ── ماهانه (فقط اولِ ماهِ شمسی) ─────────────────────────
	$monthly = farazsms_monthly_report_get();
	$today_j = farazsms_report_today_jalali( $today_mid ); // [jy, jm, jd]
	if ( $s['monthly_enabled'] === '1' && trim( $monthly['pattern_code'] ) !== ''
		&& ( $force || (int) $today_j[2] === 1 ) // اولِ ماهِ شمسی (در تست دور زده می‌شود)
		&& ( $force || get_option( 'farazsms_report_last_monthly' ) !== $today_str ) ) {
		// v3.22.202: مرزِ ماه از منبعِ واحد می‌آید (inc/farazsms-jalali-window.php).
		list( $cur_start, $prev_start ) = farazsms_report_monthly_bounds( $today_ts );
		list( $amt, $cnt )   = farazsms_report_calc_range( $cur_start, $today_ts - 1 );
		list( $pamt, $pcnt ) = farazsms_report_calc_range( $prev_start, $cur_start - 1 );
		if ( ! ( $skip_zero && ( $cnt === 0 || $amt <= 0 ) ) ) {
			farazsms_report_send( $phones, $monthly['pattern_code'], farazsms_report_compare_attrs( $amt, $cnt, $pamt, $pcnt ), 'monthly', $amt, $cnt, farazsms_report_period_message( 'monthly' ) );
		}
		update_option( 'farazsms_report_last_monthly', $today_str, false );
	}
}

/** استخراجِ شماره‌های مدیر (با fallback به شماره‌ی مالکِ پنل). */
function farazsms_report_recipients( $s ) {
	$raw = trim( (string) $s['admin_phones'] );
	if ( $raw === '' ) {
		$profile = farazsms_get_profile();
		if ( is_array( $profile ) && ! empty( $profile['mobile'] ) ) {
			$raw = (string) $profile['mobile'];
		}
	}
	$phones = array_filter( array_map( 'trim', preg_split( '/[,،]+/u', $raw ) ) );
	$out    = array();
	foreach ( $phones as $p ) {
		$p = farazsms_normalize_phone( $p );
		if ( $p !== '' ) {
			$out[] = $p;
		}
	}
	return array_values( array_unique( $out ) );
}

/**
 * ارسالِ یک گزارش به همه‌ی شماره‌ها + ثبتِ آخرین اجرا برای همان دوره.
 *
 * @param array  $phones           شماره‌های مدیران (نرمال‌شده).
 * @param string $pattern_code     کدپترنِ همان دوره.
 * @param array  $attrs            متغیرهای پترن.
 * @param string $period           'daily' | 'weekly' | 'monthly'
 * @param int    $amount           مبلغِ دوره (برای «آخرین اجرا»).
 * @param int    $order_count      تعدادِ سفارشِ دوره (برای «آخرین اجرا»).
 * @param string $message_template قالبِ متنِ همان دوره — برای بازسازیِ متنِ حل‌شده‌ی بله.
 *                                 خالی → قالبِ همان دوره از تک‌منبعِ پیش‌فرض خوانده می‌شود.
 */
function farazsms_report_send( $phones, $pattern_code, $attrs, $period, $amount, $order_count, $message_template = '' ) {
	$sender      = trim( (string) get_option( 'farazsms_sender', '' ) );
	$sent_ok     = 0;
	$send_error  = '';
	$sent_phones = array();
	foreach ( $phones as $phone ) {
		$res = farazsms_send_pattern_sms_raw( $phone, $pattern_code, $attrs, $sender );
		if ( $res === 'success' || $res === true ) {
			$sent_ok++;
			$sent_phones[] = $phone;
		} elseif ( $send_error === '' && is_string( $res ) ) {
			$send_error = $res;
		}
	}
	$opt = 'daily' === $period ? 'farazsms_daily_sales_last_run'
		: ( 'weekly' === $period ? 'farazsms_weekly_sales_last_run' : 'farazsms_monthly_sales_last_run' );
	update_option( $opt, array(
		'time'        => current_time( 'mysql' ),
		'amount'      => $amount,
		'order_count' => $order_count,
		'recipients'  => count( $phones ),
		'sent_ok'     => $sent_ok,
		'success'     => $sent_ok > 0,
		'error'       => $send_error,
	), false );

	// کانالِ بله (MVP): پس از حلقه‌ی پیامک، همان متنِ حل‌شده‌ی محلی — با یک فراخوانیِ آرایه‌ای —
	// برای همان شماره‌هایی که پیامکشان موفق بود. گِیت/async/مهارِ خطا داخلِ maybe_send است، پس
	// این‌جا نه صف می‌سازیم نه تلاشِ دوباره؛ شکستِ بله هیچ اثری روی مسیرِ پیامک ندارد.
	$bale = farazsms_report_bale_payload( $period, $message_template, $attrs, $sent_phones );
	if ( ! empty( $bale ) ) {
		farazsms_bale_maybe_send( 'admin_report', $bale['recipients'], $bale['text'] );
	}
}

/**
 * مرزهای گزارشِ ماهانه: [آغازِ ماهِ تازه‌تمام‌شده، آغازِ ماهِ قبل‌تر].
 *
 * ⚠️ واحدِ جدا تا offsetها آزمودنی باشند. پیش از این این دو خط داخلِ تابعِ
 * بلندِ ارسال بودند و هیچ تستی نمی‌توانست بگوید ‎-۱ و ‎-۲ درست‌اند یا جابه‌جا؛
 * جهش نشان داد عوض‌کردنشان سوئیت را سبز نگه می‌دارد.
 *
 * @param int $today_ts مهرِ زمانیِ **واقعیِ** بامدادِ امروز به وقتِ سایت.
 * @return array{0:int,1:int}
 */
function farazsms_report_monthly_bounds( $today_ts ) {
	return array(
		farazsms_jalali_month_start_ts( -1, $today_ts ),
		farazsms_jalali_month_start_ts( -2, $today_ts ),
	);
}

/** متغیرهای مقایسه‌ایِ گزارشِ هفتگی/ماهانه. */
function farazsms_report_compare_attrs( $amt, $cnt, $pamt, $pcnt ) {
	return array(
		'amount'           => number_format( $amt ),
		'order_count'      => (string) $cnt,
		'prev_amount'      => number_format( $pamt ),
		'prev_order_count' => (string) $pcnt,
	);
}

/** [jy,jm,jd] امروز در تایم‌زونِ سایت. */
function farazsms_report_today_jalali( $today_mid ) {
	$gy = (int) $today_mid->format( 'Y' );
	$gm = (int) $today_mid->format( 'n' );
	$gd = (int) $today_mid->format( 'j' );
	// گاردِ function_exists برداشته شد: از v3.22.199 تبدیلِ تقویم در
	// inc/farazsms-jalali-window.php است که در عمقِ صفر و بی‌قید بار می‌شود.
	// fallbackِ قبلی (روز=۰) گزارشِ ماهانه را بی‌صدا خاموش می‌کرد.
	return farazsms_birthday_gregorian_to_jalali( $gy, $gm, $gd );
}

/** ماهِ شمسیِ قبل: [jy,jm] → [jy',jm']. */
function farazsms_report_prev_jalali_month( $jy, $jm ) {
	$jm--;
	if ( $jm < 1 ) {
		$jm = 12;
		$jy--;
	}
	return array( $jy, $jm );
}

/** timestampِ نیمه‌شبِ یک تاریخِ شمسی در تایم‌زونِ سایت. */
function farazsms_report_jalali_ts( $jy, $jm, $jd, $site_tz ) {
	list( $gy, $gm, $gd ) = farazsms_jalali_to_gregorian( $jy, $jm, $jd );
	$dt = new DateTime( sprintf( '%04d-%02d-%02d 00:00:00', $gy, $gm, $gd ), $site_tz );
	return $dt->getTimestamp();
}

/**
 * تبدیلِ شمسی→میلادی (الگوریتمِ استانداردِ jdf). معکوسِ farazsms_birthday_gregorian_to_jalali.
 *
 * @return array [gy, gm, gd]
 */
function farazsms_jalali_to_gregorian( $jy, $jm, $jd ) {
	$jy   += 1595;
	$days  = -355668 + ( 365 * $jy ) + ( intdiv( $jy, 33 ) * 8 ) + intdiv( ( ( $jy % 33 ) + 3 ), 4 ) + $jd
		+ ( ( $jm < 7 ) ? ( $jm - 1 ) * 31 : ( ( $jm - 7 ) * 30 ) + 186 );
	$gy    = 400 * intdiv( $days, 146097 );
	$days  = $days % 146097;
	if ( $days > 36524 ) {
		$gy  += 100 * intdiv( --$days, 36524 );
		$days = $days % 36524;
		if ( $days >= 365 ) {
			$days++;
		}
	}
	$gy   += 4 * intdiv( $days, 1461 );
	$days  = $days % 1461;
	if ( $days > 365 ) {
		$gy  += intdiv( $days - 1, 365 );
		$days = ( $days - 1 ) % 365;
	}
	$gd    = $days + 1;
	$leap  = ( ( $gy % 4 === 0 && $gy % 100 !== 0 ) || ( $gy % 400 === 0 ) );
	$sal_a = array( 0, 31, $leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 );
	$gm    = 0;
	for ( $gm = 1; $gm <= 12; $gm++ ) {
		$v = $sal_a[ $gm ];
		if ( $gd <= $v ) {
			break;
		}
		$gd -= $v;
	}
	return array( $gy, $gm, $gd );
}

/**
 * محاسبه آمارِ فروشِ خالصِ روزِ تقویمیِ قبل با WC_Order_Query.
 *
 * @return array [total_amount, order_count]
 */
function farazsms_daily_report_calculate_stats() {
	$site_tz = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'Asia/Tehran' );
	$start   = ( new DateTime( 'yesterday 00:00:00', $site_tz ) )->getTimestamp();
	$end     = ( new DateTime( 'today 00:00:00', $site_tz ) )->getTimestamp();
	return farazsms_report_calc_range( $start, $end - 1 );
}

/**
 * v3.21.89: محاسبه‌ی عمومیِ فروشِ خالص در یک بازه‌ی زمانی — پایه‌ی گزارشِ روزانه/هفتگی/ماهانه.
 * فروشِ «خالص» هم‌راستا با Analytics: فیلتر روی date_paid، وضعیت‌های completed/processing/on-hold/
 * refunded، و مبلغ = کلِ سفارش منهای مرجوعی/مالیات/ارسالِ خالص.
 *
 * @param int $start_ts شروعِ بازه (شامل)
 * @param int $end_ts   پایانِ بازه (شامل)
 * @return array [total_amount, order_count]
 */
function farazsms_report_calc_range( $start_ts, $end_ts ) {
	if ( ! function_exists( 'wc_get_orders' ) ) {
		return array( 0.0, 0 );
	}
	// v3.22.120: فقط سفارش‌های «خریدِ نهایی‌شده» شمرده می‌شوند:
	//   - فیلترِ date_paid تضمین می‌کند فقط سفارشِ «پرداخت‌شده» بیاید (سفارشِ «در انتظار پرداخت»
	//     تاریخِ پرداخت ندارد → اصلاً شمرده نمی‌شود).
	//   - وضعیت‌ها به completed/processing محدود شد (وضعیت‌های واقعاً‌پرداخت‌شده‌ی ووکامرس).
	//     on-hold (در انتظارِ تأیید/دستی) و refunded (مسترد = فروش نیست) از پیش‌فرض حذف شدند
	//     تا شمارش دقیقاً برابرِ خریدهای واقعی باشد. با فیلترِ زیر قابلِ تغییر است.
	$args = array(
		'limit'     => -1,
		'status'    => apply_filters( 'farazsms_daily_report_order_statuses', array( 'completed', 'processing' ) ),
		'date_paid' => (int) $start_ts . '...' . (int) $end_ts,
		'return'    => 'objects',
	);
	$orders = wc_get_orders( $args );

	$total = 0.0;
	$count = 0;
	if ( is_array( $orders ) ) {
		foreach ( $orders as $order ) {
			if ( ! $order instanceof WC_Order ) {
				continue;
			}
			// v3.22.119: «فروش» = کلِ مبلغِ سفارش (همان چیزی که در پیامکِ سفارش و پنلِ ووکامرس می‌بینید)،
			// نه «خالصِ بدونِ مالیات/هزینه‌ی ارسال». حالتِ خالص باعث می‌شد گزارش (مثلاً ۹.۳م) با مبلغِ
			// واقعیِ سفارش (۱۴م) نخواند و مدیر گیج شود. فقط مبلغِ مسترد کم می‌شود (سفارشِ مسترد ≈ ۰).
			$total += (float) $order->get_total() - (float) $order->get_total_refunded();
			$count++;
		}
	}
	return array( $total, $count );
}

// ── Admin UI — Section در صفحه farazsms-settings ─────────────────────────

// v3.14.9: قبلاً از admin_notices استفاده می‌کرد که کارت را «بالای صفحه» قرار
// می‌داد (بیرون از قاب visual صفحه تنظیمات). حالا از یک action hook اختصاصی
// استفاده می‌شود که داخل خود template صفحه تنظیمات قرار می‌گیرد — همراستا با
// بقیه محتوا.
add_action( 'farazsms_settings_page_extra_sections', 'farazsms_daily_report_render_section' );

// POST handler جدا از render — تا قبل از render اجرا شود.
add_action( 'admin_init', 'farazsms_daily_report_handle_save' );
function farazsms_daily_report_handle_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ( $_SERVER['REQUEST_METHOD'] ?? '' ) !== 'POST' || empty( $_POST['farazsms_daily_report_save'] ) ) {
		return;
	}
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	if ( $page !== 'farazsms-settings' ) {
		return;
	}
	check_admin_referer( 'farazsms_daily_report_settings', 'farazsms_daily_report_nonce' );
	farazsms_daily_report_persist_from_post();
	wp_safe_redirect( add_query_arg( 'farazsms_daily_saved', '1', admin_url( 'admin.php?page=farazsms-settings' ) ) );
	exit;
}

/**
 * ذخیره‌ی تنظیماتِ گزارش از روی $_POST — مشترک بینِ POST کلاسیک و AJAX
 * تا منطقِ sanitize/ذخیره فقط در یک جا باشد (بدونِ واگرایی بینِ دو مسیر).
 */
function farazsms_daily_report_persist_from_post() {
	$current = farazsms_daily_report_get_settings();
	$current['enabled']         = isset( $_POST['daily_report_enabled'] ) ? '1' : '0';
	$current['weekly_enabled']  = isset( $_POST['weekly_report_enabled'] ) ? '1' : '0';
	$current['monthly_enabled'] = isset( $_POST['monthly_report_enabled'] ) ? '1' : '0';
	$current['skip_zero']       = isset( $_POST['report_skip_zero'] ) ? '1' : '0';
	$current['admin_phones']    = sanitize_text_field( $_POST['daily_report_admin_phones'] ?? '' );
	$current['pattern_code']    = sanitize_text_field( $_POST['daily_report_pattern_code'] ?? 'GPwbnk6dDE' );
	$current['hour']            = sanitize_text_field( $_POST['daily_report_hour'] ?? '00:10' );
	update_option( 'farazsms_daily_sales_settings', $current, false );

	// کدهای پترنِ هفتگی/ماهانه در option‌های جدا (سازنده‌ی پترن هم آن‌ها را می‌نویسد).
	$weekly = get_option( 'farazsms_weekly_report_settings', array() );
	if ( ! is_array( $weekly ) ) { $weekly = array(); }
	$weekly['pattern_code'] = sanitize_text_field( $_POST['weekly_report_pattern_code'] ?? '' );
	update_option( 'farazsms_weekly_report_settings', $weekly, false );

	$monthly = get_option( 'farazsms_monthly_report_settings', array() );
	if ( ! is_array( $monthly ) ) { $monthly = array(); }
	$monthly['pattern_code'] = sanitize_text_field( $_POST['monthly_report_pattern_code'] ?? '' );
	update_option( 'farazsms_monthly_report_settings', $monthly, false );
}

// AJAX: ذخیره بدونِ رفرشِ صفحه — یک‌دست با بقیه‌ی صفحه‌ی تنظیمات (کلیدِ دسترسی، Matomo).
add_action( 'wp_ajax_farazsms_daily_report_save', 'farazsms_daily_report_ajax_save' );
function farazsms_daily_report_ajax_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی مجاز نیست' ) );
	}
	check_ajax_referer( 'farazsms_daily_report_settings', 'farazsms_daily_report_nonce' );
	farazsms_daily_report_persist_from_post();
	wp_send_json_success( array( 'message' => '✓ تنظیمات گزارش روزانه ذخیره شد.' ) );
}

// اجرای دستی برای تست — همان تابعِ cron را اجرا می‌کند و نتیجه‌ی واقعی را در «آخرین اجرا» نشان می‌دهد.
add_action( 'admin_init', 'farazsms_daily_report_handle_test_send' );
function farazsms_daily_report_handle_test_send() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ( $_SERVER['REQUEST_METHOD'] ?? '' ) !== 'POST' || empty( $_POST['farazsms_daily_report_test'] ) ) {
		return;
	}
	if ( ( isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '' ) !== 'farazsms-settings' ) {
		return;
	}
	check_admin_referer( 'farazsms_daily_report_settings', 'farazsms_daily_report_nonce' );
	// ارسالِ آزمایشی: با force هر سه دوره (روزانه/هفتگی/ماهانه) بدونِ توجه به روزِ هفته/ماه و
	// گاردِ یک‌بار-در-روز ارسال می‌شوند تا مدیر بتواند همه را همین‌جا تست کند.
	farazsms_daily_report_run( true ); // وضعیتِ واقعی (موفق/خطا) در optionها ثبت می‌شود.
	wp_safe_redirect( add_query_arg( 'farazsms_daily_tested', '1', admin_url( 'admin.php?page=farazsms-settings' ) ) );
	exit;
}

function farazsms_daily_report_render_section() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	// گزارشِ فروش بدونِ ووکامرس بی‌فایده است — اگر ووکامرس فعال نیست، این بخش مخفی بماند.
	if ( ! class_exists( 'WooCommerce' ) && ! function_exists( 'wc_get_orders' ) ) {
		return;
	}

	// نکته: POST handler حالا در admin_init قبل از render اجرا می‌شود.
	// اینجا فقط notice موفقیت را بر اساس query string نمایش می‌دهیم.
	$saved_ok = isset( $_GET['farazsms_daily_saved'] ) && $_GET['farazsms_daily_saved'] === '1';

	$s        = farazsms_daily_report_get_settings();
	$last_run = get_option( 'farazsms_daily_sales_last_run', array() );

	// اگر شماره‌ی مدیر هنوز وارد نشده، شماره‌ی مالکِ پنل را از وب‌سرویسِ فراز پیش‌پُر کن
	// تا کاربر فقط ذخیره را بزند (و پیامک به همان شماره برود).
	$admin_phones_value = (string) $s['admin_phones'];
	if ( trim( $admin_phones_value ) === '' ) {
		$profile = farazsms_get_profile();
		if ( is_array( $profile ) && ! empty( $profile['mobile'] ) ) {
			$admin_phones_value = (string) $profile['mobile'];
		}
	}
	?>
	<!-- v3.14.9: داخل ساختار قاب صفحه تنظیمات — wrapper بیرونی حذف شد تا با
	     بقیه محتوای صفحه (فرم تنظیمات اصلی، connection panel) هم‌راستا باشد. -->
	<div style="direction:rtl; font-family:inherit; margin-top:24px;">
		<?php if ( $saved_ok ) : ?>
			<div style="background:#e2f8f0; border:1px solid #10c282; color:#096d49; padding:10px 14px; border-radius:8px; margin-bottom:14px;">
				✓ تنظیمات گزارش روزانه ذخیره شد.
			</div>
		<?php endif; ?>
		<?php if ( isset( $_GET['farazsms_daily_tested'] ) && $_GET['farazsms_daily_tested'] === '1' ) : ?>
			<div style="background:#eff6ff; border:1px solid #bfdbfe; color:#1e40af; padding:10px 14px; border-radius:8px; margin-bottom:14px;">
				📤 ارسالِ آزمایشی انجام شد — نتیجه‌ی واقعی را در کادرِ «آخرین اجرا» پایین ببینید.
			</div>
		<?php endif; ?>
		<div style="background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:22px 24px;">
			<div style="display:flex; align-items:center; gap:10px; margin-bottom:14px;">
				<div style="width:38px; height:38px; background:linear-gradient(135deg,#0c9765 0%,#0c9765 100%); color:#fff; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:18px;">📊</div>
				<div>
					<h3 style="margin:0; font-size:15px; font-weight:700; color:#263f67;">گزارش پیامکی روزانه فروش</h3>
					<p style="margin:2px 0 0; font-size:11.5px; color:#9b9b9b;">
						هر شب ساعت تنظیم‌شده، آمار فروشِ روزِ قبل (مجموع مبلغِ خالص + تعداد سفارش) به شماره مدیران ارسال می‌شود
					</p>
				</div>
			</div>

			<form method="post" action="" id="farazsms_daily_report_form">
				<?php wp_nonce_field( 'farazsms_daily_report_settings', 'farazsms_daily_report_nonce' ); ?>

				<!-- دوره‌های گزارش (هر سه پیش‌فرض روشن) -->
				<div style="display:flex; flex-wrap:wrap; gap:10px; margin-bottom:14px;">
					<?php
					$farazsms_report_toggles = array(
						'daily_report_enabled'   => array( '📅 روزانه', $s['enabled'] === '1' ),
						'weekly_report_enabled'  => array( '🗓️ هفتگی (شنبه‌ها)', $s['weekly_enabled'] === '1' ),
						'monthly_report_enabled' => array( '📆 ماهانه (اولِ ماهِ شمسی)', $s['monthly_enabled'] === '1' ),
					);
					foreach ( $farazsms_report_toggles as $name => $cfg ) :
						list( $label, $on ) = $cfg;
						?>
						<label style="flex:1 1 180px; display:flex; align-items:center; gap:10px; padding:11px 14px; background:<?php echo $on ? '#e2f8f0' : '#faf1da'; ?>; border:1px solid <?php echo $on ? '#10c282' : '#e2a916'; ?>; border-radius:10px; cursor:pointer;">
							<input type="checkbox" class="farazsms-toggle" name="<?php echo esc_attr( $name ); ?>" value="1" <?php checked( $on ); ?> style="margin:0; width:18px; height:18px;">
							<span style="font-size:12.5px; font-weight:600;"><?php echo esc_html( $label ); ?></span>
						</label>
					<?php endforeach; ?>
				</div>

				<!-- عدم‌ارسال در دوره‌ی بدونِ فروش -->
				<label style="display:flex; align-items:center; gap:10px; padding:10px 14px; background:#f5f8fe; border:1px solid #e1e1e1; border-radius:10px; cursor:pointer; margin-bottom:14px;">
					<input type="checkbox" class="farazsms-toggle" name="report_skip_zero" value="1" <?php checked( $s['skip_zero'], '1' ); ?> style="margin:0; width:18px; height:18px;">
					<span style="font-size:12.5px; font-weight:600; color:#4d4d4d;">در دوره‌ای که فروش صفر است پیامک ارسال نشود</span>
				</label>

				<!-- Phones + Hour + Pattern -->
				<div style="display:flex; flex-wrap:wrap; gap:14px; margin-bottom:14px;">
					<div style="flex:1 1 360px;">
						<label for="daily_report_admin_phones" style="display:block; font-size:12px; font-weight:600; color:#4d4d4d; margin-bottom:4px;">
							شماره موبایل مدیران <span style="color:#d52a16;">*</span>
						</label>
						<input type="text" id="daily_report_admin_phones" name="daily_report_admin_phones" value="<?php echo esc_attr( $admin_phones_value ); ?>" placeholder="09120000000,09130000000" style="width:100%; padding:8px 12px; border:1px solid #e1e1e1; border-radius:6px; font-size:13px; direction:ltr; text-align:left; font-family:monospace;">
						<p style="margin:4px 0 0; font-size:11px; color:#9b9b9b;">برای چند مدیر، شماره‌ها را با کاما (<code>,</code>) جدا کنید — به هر یک پیامک جداگانه می‌رود.</p>
					</div>
					<div style="flex:1 1 120px;">
						<label for="daily_report_hour" style="display:block; font-size:12px; font-weight:600; color:#4d4d4d; margin-bottom:4px;">ساعت ارسال</label>
						<input type="time" id="daily_report_hour" name="daily_report_hour" value="<?php echo esc_attr( $s['hour'] ); ?>" style="width:100%; padding:8px 12px; border:1px solid #e1e1e1; border-radius:6px; font-size:13px;">
						<p style="margin:4px 0 0; font-size:11px; color:#9b9b9b;">پیش‌فرض: <code>00:10</code></p>
					</div>
				</div>

				<div style="margin-bottom:14px;">
					<label for="daily_report_pattern_code" style="display:block; font-size:12px; font-weight:600; color:#4d4d4d; margin-bottom:4px;">کد پترن</label>
					<input type="text" id="daily_report_pattern_code" name="daily_report_pattern_code" value="<?php echo esc_attr( $s['pattern_code'] ); ?>" placeholder="GPwbnk6dDE" style="width:100%; max-width:300px; padding:8px 12px; border:1px solid #e1e1e1; border-radius:6px; font-size:13px; direction:ltr; text-align:left; font-family:monospace;">
					<p style="margin:4px 0 0; font-size:11px; color:#9b9b9b; line-height:1.8;">
						متغیرهای پترن: <code>%amount%</code> (مجموع مبلغ) و <code>%order_count%</code> (تعداد سفارش)
					</p>
					<?php
					// v3.21.55: ساختِ خودکارِ پترن (مثلِ بقیه‌ی بخش‌ها).
					$dr_msg = farazsms_report_period_message( 'daily' );
					farazsms_feature_pattern_builder_ui( 'daily_report', $dr_msg, array( '%amount%', '%order_count%' ), 'daily_report_pattern_code' );
					?>
				</div>

				<!-- v3.21.89: پترنِ گزارشِ هفتگی و ماهانه (با مقایسه‌ی دوره‌ی قبل) -->
				<?php $farazsms_weekly = farazsms_weekly_report_get(); $farazsms_monthly = farazsms_monthly_report_get(); ?>
				<div style="margin-bottom:14px; padding-top:12px; border-top:1px dashed #e1e1e1;">
					<div style="font-size:13px; font-weight:700; color:#263f67; margin-bottom:4px;">🗓️ پترنِ گزارشِ هفتگی</div>
					<input type="hidden" name="weekly_report_pattern_code" value="<?php echo esc_attr( $farazsms_weekly['pattern_code'] ); ?>">
					<p style="margin:0 0 4px; font-size:11px; color:#9b9b9b;">متغیرها: <code>%amount%</code>، <code>%order_count%</code> (هفته‌ی گذشته) و <code>%prev_amount%</code>، <code>%prev_order_count%</code> (هفته‌ی قبل‌تر).</p>
					<?php
					farazsms_feature_pattern_builder_ui( 'weekly_report', $farazsms_weekly['message'], array( '%amount%', '%order_count%', '%prev_amount%', '%prev_order_count%' ), 'weekly_report_pattern_code' );
					?>
				</div>

				<div style="margin-bottom:14px;">
					<div style="font-size:13px; font-weight:700; color:#263f67; margin-bottom:4px;">📆 پترنِ گزارشِ ماهانه</div>
					<input type="hidden" name="monthly_report_pattern_code" value="<?php echo esc_attr( $farazsms_monthly['pattern_code'] ); ?>">
					<p style="margin:0 0 4px; font-size:11px; color:#9b9b9b;">متغیرها: <code>%amount%</code>، <code>%order_count%</code> (ماهِ گذشته) و <code>%prev_amount%</code>، <code>%prev_order_count%</code> (ماهِ قبل‌تر).</p>
					<?php
					farazsms_feature_pattern_builder_ui( 'monthly_report', $farazsms_monthly['message'], array( '%amount%', '%order_count%', '%prev_amount%', '%prev_order_count%' ), 'monthly_report_pattern_code' );
					?>
				</div>

				<!-- Last run info -->
				<?php if ( ! empty( $last_run ) && is_array( $last_run ) ) :
					$lr_time   = isset( $last_run['time'] ) ? (string) $last_run['time'] : '';
					$lr_jalali = ( $lr_time !== '' ) ? farazsms_send_reports_to_jalali( $lr_time ) : $lr_time;
					// سازگاری با لاگ‌های قدیمی که فیلدِ success نداشتند.
					$lr_ok      = array_key_exists( 'success', $last_run ) ? (bool) $last_run['success'] : true;
					$lr_sent_ok = isset( $last_run['sent_ok'] ) ? (int) $last_run['sent_ok'] : (int) ( $last_run['recipients'] ?? 0 );
					?>
					<div style="background:<?php echo $lr_ok ? '#eaeff7' : '#fdeae8'; ?>; border:1px solid <?php echo $lr_ok ? '#c1d0e8' : '#d52a16'; ?>; padding:10px 14px; border-radius:8px; margin-bottom:14px; font-size:11.5px; color:<?php echo $lr_ok ? '#263f67' : '#b32d2e'; ?>;">
						📤 آخرین اجرا: <strong><?php echo esc_html( $lr_jalali ); ?></strong>
						— <?php echo esc_html( number_format_i18n( $last_run['amount'] ?? 0 ) ); ?> تومان
						/ <?php echo esc_html( number_format_i18n( $last_run['order_count'] ?? 0 ) ); ?> سفارش
						<?php if ( $lr_ok ) : ?>
							/ ✅ به <?php echo esc_html( $lr_sent_ok ); ?> شماره ارسال شد
						<?php else : ?>
							/ ❌ ارسال ناموفق<?php echo ! empty( $last_run['error'] ) ? ' — ' . esc_html( $last_run['error'] ) : ''; ?>
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<!-- Tip -->
				<div style="background:#faf1da; border:1px solid #e2a916; color:#83620d; padding:10px 14px; border-radius:8px; margin-bottom:14px; font-size:11.5px; line-height:1.9;">
					<strong>💡 نکته فنی:</strong> WP-Cron فقط هنگام بازدید سایت اجرا می‌شود.
					برای ساعت دقیق ارسال، در سرور خود system cron تنظیم کنید (cPanel/CLI). در غیر این صورت پیامک ممکن است چند دقیقه/ساعت دیرتر ارسال شود.
				</div>

				<button type="submit" name="farazsms_daily_report_save" value="1" id="farazsms_daily_report_save_btn" style="background:#365891; color:#fff; border:none; padding:9px 22px; font-size:13px; font-weight:600; border-radius:8px; cursor:pointer; font-family:inherit;">
					💾 ذخیره
				</button>
				<button type="submit" name="farazsms_daily_report_test" value="1" style="background:#0f766e; color:#fff; border:none; padding:9px 22px; font-size:13px; font-weight:600; border-radius:8px; cursor:pointer; font-family:inherit; margin-right:8px;">
					📤 ارسال آزمایشی الان
				</button>
				<span id="farazsms_daily_report_save_status" style="margin-right:10px; font-size:12px; font-weight:600;"></span>
				<p style="margin-top:8px; font-size:11px; color:#9b9b9b;">«ارسال آزمایشی الان» همین حالا گزارش را می‌فرستد و نتیجه‌ی واقعی (موفق یا خطا) را در کادرِ «آخرین اجرا» نشان می‌دهد.</p>
			</form>
			<script>
			// v3.22.108: ذخیره‌ی گزارشِ روزانه با AJAX (بدونِ رفرش) — یک‌دست با کلیدِ دسترسی و Matomo.
			// «ارسالِ آزمایشی» عمداً POST/رفرش می‌ماند چون نتیجه را در «آخرین اجرا» بارگذاری می‌کند.
			(function () {
				var form = document.getElementById('farazsms_daily_report_form');
				var saveBtn = document.getElementById('farazsms_daily_report_save_btn');
				var statusEl = document.getElementById('farazsms_daily_report_save_status');
				if (!form || !saveBtn || typeof ajaxurl === 'undefined') { return; }
				saveBtn.addEventListener('click', function (e) {
					e.preventDefault();
					var origText = saveBtn.textContent;
					saveBtn.disabled = true;
					statusEl.style.color = '#9b9b9b';
					statusEl.textContent = 'در حال ذخیره…';
					var fd = new FormData(form);
					fd.append('action', 'farazsms_daily_report_save');
					fetch(ajaxurl, { method: 'POST', credentials: 'same-origin', body: fd })
						.then(function (r) { return r.json(); })
						.then(function (res) {
							saveBtn.disabled = false; saveBtn.textContent = origText;
							if (res && res.success) {
								statusEl.style.color = '#0c9765';
								statusEl.textContent = (res.data && res.data.message) ? res.data.message : '✓ ذخیره شد.';
							} else {
								statusEl.style.color = '#b32d2e';
								statusEl.textContent = (res && res.data && res.data.message) ? res.data.message : 'خطا در ذخیره';
							}
						})
						.catch(function () {
							saveBtn.disabled = false; saveBtn.textContent = origText;
							statusEl.style.color = '#b32d2e';
							statusEl.textContent = 'خطا در ارتباط با سرور';
						});
				});
			})();
			</script>
		</div>
	</div>
	<?php
}
