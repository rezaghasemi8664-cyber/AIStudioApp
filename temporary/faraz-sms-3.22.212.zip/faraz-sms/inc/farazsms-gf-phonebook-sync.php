<?php
/**
 * Gravity Forms → Phonebook Auto-Sync — v3.17.4
 *
 * هر شماره موبایلی که از طریق فرم Gravity وارد می‌شود را خودکار به
 * دفترچه تلفن پنل فراز اس‌ام‌اس می‌فرستد + import یکباره ورودی‌های قبلی.
 *
 * فلوی پیکربندی:
 *  ۱) ادمین وارد صفحه «همگام‌سازی فرم‌ها → دفترچه تلفن» می‌شود
 *  ۲) Form → Phone Field → Target Phonebook را انتخاب می‌کند
 *  ۳) (اختیاری) Name Field را هم انتخاب می‌کند
 *  ۴) با کلیک «ایمپورت سوابق»، تمام entry های قبلی به‌صورت batch به Faraz می‌رود
 *  ۵) از آن به بعد، هر submission جدید خودکار push می‌شود
 *
 * چند فرم مختلف می‌توانند به دفترچه‌های مختلف map شوند — mappings آرایه‌ای است.
 *
 * Performance:
 *  - bulk_upsert_contacts: مخاطبان در بسته‌های ۵۰۰تایی و همگام ثبت می‌شوند؛ تقسیم بر پایه‌ی
 *    شمارِ ردیف و حجمِ فایل است، نه chunkِ ۵۰۰تایی (آن پارامتر دیگر بی‌اثر است).
 *  - import async از طریق AJAX با progress reporting
 *  - hook submission سبک — فقط دو فیلد را extract می‌کند
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_GF_PB_OPTION = 'farazsms_gf_phonebook_mappings';

// v3.17.5: standalone submenu حذف شد — این صفحه به‌صورت تب در farazsms-phonebook
// رندر می‌شود (برای کاهش شلوغی منو). تابع farazsms_gf_pb_render_page() از داخل
// render_phonebook_page() صدا زده می‌شود.

// ============================================================================
// Settings storage
// ============================================================================

function farazsms_gf_pb_get_mappings() {
	$raw = get_option( FARAZSMS_GF_PB_OPTION, array() );
	return is_array( $raw ) ? $raw : array();
}

function farazsms_gf_pb_save_mappings( $mappings ) {
	update_option( FARAZSMS_GF_PB_OPTION, array_values( $mappings ), false );
}

// ============================================================================
// Helper: GF active + API instance
// ============================================================================

function farazsms_gf_pb_is_gf_active() {
	return class_exists( 'GFAPI' ) || class_exists( 'GFForms' );
}

function farazsms_gf_pb_get_api() {
	if ( ! class_exists( 'FarazSMS_Next_Phonebook_API' ) ) {
		$path = dirname( __FILE__, 2 ) . '/modules/farazsms-next/includes/class-phonebook-api.php';
		if ( file_exists( $path ) ) {
			require_once $path;
		}
	}
	if ( ! class_exists( 'FarazSMS_Next_Phonebook_API' ) ) {
		return null;
	}
	return new FarazSMS_Next_Phonebook_API();
}

// ============================================================================
// Save mapping handler
// ============================================================================

add_action( 'admin_post_farazsms_gf_pb_save_mapping', 'farazsms_gf_pb_handle_save_mapping' );
function farazsms_gf_pb_handle_save_mapping() {
	if ( ! current_user_can( 'manage_options' ) ) wp_die();
	check_admin_referer( 'farazsms_gf_pb_save_mapping' );

	$form_id        = (int) ( $_POST['form_id'] ?? 0 );
	$phone_field_id = sanitize_text_field( $_POST['phone_field_id'] ?? '' );
	$name_field_id  = sanitize_text_field( $_POST['name_field_id'] ?? '' );
	$phonebook_id   = (int) ( $_POST['phonebook_id'] ?? 0 );

	if ( $form_id <= 0 || $phone_field_id === '' || $phonebook_id <= 0 ) {
		wp_safe_redirect( add_query_arg( 'gf_pb_error', rawurlencode( 'اطلاعات ناقص است — فرم، فیلد موبایل، و دفترچه باید انتخاب شوند.' ), wp_get_referer() ) );
		exit;
	}

	$mappings   = farazsms_gf_pb_get_mappings();
	$mappings[] = array(
		'id'             => uniqid( 'm_' ),
		'form_id'        => $form_id,
		'phone_field_id' => $phone_field_id,
		'name_field_id'  => $name_field_id,
		'phonebook_id'   => $phonebook_id,
		'created_at'     => current_time( 'mysql' ),
		'last_imported'  => '',
		'import_count'   => 0,
	);
	farazsms_gf_pb_save_mappings( $mappings );

	wp_safe_redirect( add_query_arg( 'gf_pb_saved', '1', wp_get_referer() ) );
	exit;
}

// ============================================================================
// Delete mapping
// ============================================================================

add_action( 'admin_post_farazsms_gf_pb_delete_mapping', 'farazsms_gf_pb_handle_delete_mapping' );
function farazsms_gf_pb_handle_delete_mapping() {
	if ( ! current_user_can( 'manage_options' ) ) wp_die();
	check_admin_referer( 'farazsms_gf_pb_delete_mapping' );

	$id       = sanitize_text_field( $_POST['mapping_id'] ?? '' );
	$mappings = farazsms_gf_pb_get_mappings();
	$mappings = array_filter( $mappings, function ( $m ) use ( $id ) {
		return ( $m['id'] ?? '' ) !== $id;
	} );
	farazsms_gf_pb_save_mappings( $mappings );

	wp_safe_redirect( add_query_arg( 'gf_pb_deleted', '1', wp_get_referer() ) );
	exit;
}

// ============================================================================
// One-time historical import — AJAX
// ============================================================================

add_action( 'wp_ajax_farazsms_gf_pb_import_history', 'farazsms_gf_pb_ajax_import_history' );
function farazsms_gf_pb_ajax_import_history() {
	check_ajax_referer( 'farazsms_gf_pb_import', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ) );
	}
	if ( ! farazsms_gf_pb_is_gf_active() ) {
		wp_send_json_error( array( 'message' => 'افزونه Gravity Forms فعال نیست.' ) );
	}
	$apikey = get_option( 'farazsms_apikey', '' );
	if ( $apikey === '' ) {
		wp_send_json_error( array( 'message' => 'کلید دسترسی (Api-Key) را در تنظیمات وارد کنید.' ) );
	}

	$id       = sanitize_text_field( $_POST['mapping_id'] ?? '' );
	$mappings = farazsms_gf_pb_get_mappings();
	$mapping  = null;
	foreach ( $mappings as $m ) {
		if ( ( $m['id'] ?? '' ) === $id ) {
			$mapping = $m;
			break;
		}
	}
	if ( ! $mapping ) {
		wp_send_json_error( array( 'message' => 'Mapping یافت نشد.' ) );
	}

	// خواندن همه entry های فرم
	$form_id        = (int) $mapping['form_id'];
	$phone_field_id = (string) $mapping['phone_field_id'];
	$name_field_id  = (string) ( $mapping['name_field_id'] ?? '' );
	$phonebook_id   = (int) $mapping['phonebook_id'];

	$entries = array();
	try {
		$entries = GFAPI::get_entries(
			$form_id,
			array( 'status' => 'active' ),
			null,
			array( 'offset' => 0, 'page_size' => 5000 )  // سقف ۵هزار entry per request
		);
	} catch ( Exception $e ) {
		wp_send_json_error( array( 'message' => 'خطا در خواندن entry ها: ' . $e->getMessage() ) );
	}

	if ( ! is_array( $entries ) || empty( $entries ) ) {
		wp_send_json_error( array( 'message' => 'هیچ entry در این فرم یافت نشد.' ) );
	}

	// ساخت contacts array — duplicates توسط Faraz dedup می‌شود (mobile unique)
	$contacts = array();
	$seen_mobiles = array();
	foreach ( $entries as $entry ) {
		$raw_phone = isset( $entry[ $phone_field_id ] ) ? (string) $entry[ $phone_field_id ] : '';
		if ( $raw_phone === '' ) continue;

		$normalized = farazsms_normalize_phone( $raw_phone );
		if ( ! preg_match( '/^09\d{9}$/', $normalized ) ) continue;
		if ( isset( $seen_mobiles[ $normalized ] ) ) continue;
		$seen_mobiles[ $normalized ] = true;

		$name = $name_field_id !== '' && isset( $entry[ $name_field_id ] )
			? sanitize_text_field( (string) $entry[ $name_field_id ] ) : '';

		$contacts[] = array(
			'name'  => $name,
			'phone' => $normalized,
		);
	}

	if ( empty( $contacts ) ) {
		wp_send_json_error( array( 'message' => 'هیچ شماره موبایل معتبری در entry ها یافت نشد. (فرمت باید 09xxxxxxxxx باشد)' ) );
	}

	// برای importهای بزرگ (>۱۰۰۰ مخاطب) کار تکه‌تکه به صفِ مشترک می‌رود تا
	// PHP timeout نخوریم. (تا v3.22.201 این شرط به Action Scheduler هم گره
	// خورده بود؛ آن گره در ۲۰۲ برداشته شد — پایین را ببینید.)
	// v3.22.202: شرطِ «اگر Action Scheduler هست» برداشته شد. صفِ مشترک روی سایتِ
	// بدونِ AS هم کرون و باقی‌مانده و کچ‌آپ دارد؛ با آن شرط، سایتِ بدونِ ووکامرس
	// ۵۰۰۰ مخاطب را همان‌جا و روی همان درخواست می‌فرستاد — یعنی همان تایم‌اوتی
	// که این شاخه برای فرارش نوشته شده بود.
	$total_contacts = count( $contacts );
	$use_async      = $total_contacts > FARAZSMS_PB_SYNC_MAX_INLINE;

	if ( $use_async ) {
		// در chunk های ۵۰۰ تایی به‌صورت async
		$chunks = array_chunk( $contacts, 500 );
		foreach ( $chunks as $chunk ) {
			// ⚠️ نه کلید و نه خودِ مخاطبان در آرگومانِ کار نمی‌روند: بدونِ
			// Action Scheduler این آرگومان‌ها در آپشنِ cron — که autoload است —
			// سریال می‌شوند. یعنی کلیدِ خام روی دیتابیس، به‌علاوه‌ی صدها شماره
			// روی هر بارگذاریِ صفحه. تکه در یک ترنزینتِ غیرautoload می‌نشیند و
			// فقط شناسه‌اش سفر می‌کند.
			$chunk_id = 'farazsms_gf_pb_chunk_' . wp_generate_password( 12, false, false );
			set_transient( $chunk_id, $chunk, 6 * HOUR_IN_SECONDS );
			farazsms_queue_task( 'gf-phonebook', 'farazsms_gf_pb_push_chunk', array( $phonebook_id, $chunk_id ) );
		}

		// به‌روز کردن mapping
		foreach ( $mappings as $i => $m ) {
			if ( ( $m['id'] ?? '' ) === $id ) {
				$mappings[ $i ]['last_imported'] = current_time( 'mysql' );
				$mappings[ $i ]['import_count']  = $total_contacts;
				break;
			}
		}
		farazsms_gf_pb_save_mappings( $mappings );

		wp_send_json_success( array(
			'message' => sprintf( '✓ %d مخاطب در صف ارسال (background) قرار گرفت. در عرض چند دقیقه کامل می‌شود.', $total_contacts ),
			'count'   => $total_contacts,
			'total'   => count( $entries ),
			'async'   => true,
		) );
	}

	// Push to Faraz با bulk_upsert (sync — برای کم تا متوسط)
	$api = farazsms_gf_pb_get_api();
	if ( ! $api ) {
		wp_send_json_error( array( 'message' => 'ماژول phonebook API در دسترس نیست.' ) );
	}

	$result = $api->bulk_upsert_contacts( $phonebook_id, $contacts, $apikey, 500 );

	if ( ! is_array( $result ) || empty( $result['success'] ) ) {
		// کلیدِ واقعیِ خطا «error» است، نه «message».
		$em = is_array( $result ) && ! empty( $result['error'] ) ? $result['error']
			: ( is_array( $result ) && ! empty( $result['message'] ) ? $result['message'] : 'خطای نامشخص در ارتباط با سرور' );
		wp_send_json_error( array( 'message' => $em ) );
	}

	// به‌روز کردن mapping با شمارش
	foreach ( $mappings as $i => $m ) {
		if ( ( $m['id'] ?? '' ) === $id ) {
			$mappings[ $i ]['last_imported'] = current_time( 'mysql' );
			// شمارِ «به‌صف‌رفته»، نه «تلاش‌شده» — وگرنه فهرستِ نگاشت‌ها عددِ متورم نشان می‌دهد.
			$mappings[ $i ]['import_count']  = isset( $result['queued'] ) ? (int) $result['queued'] : 0;
			break;
		}
	}
	farazsms_gf_pb_save_mappings( $mappings );

	// v3.22.175: واردسازیِ سمتِ پنل ناهم‌زمان است — پاسخِ آپلود فقط «به صف رفت» را تأیید
	// می‌کند، نه «ذخیره شد». تعداد را از خودِ پاسخ می‌خوانیم، نه از شمارشِ محلی.
	$queued = isset( $result['queued'] ) ? (int) $result['queued'] : 0;
	// متنِ هشدار یک پیاده‌سازی بیشتر ندارد (ترجمه‌پذیر، با هر دو شاخه‌ی خطا).
	$warn = class_exists( 'FarazSMS_Next_Phonebook_API' )
		? FarazSMS_Next_Phonebook_API::partial_failure_text( $result )
		: '';
	wp_send_json_success( array(
		'message'  => sprintf( '✓ %d شماره در دفترچه تلفن ثبت شد.%s', $queued, $warn ),
		'count'    => $queued,
		'total'    => count( $entries ),
	) );
}

/**
 * v3.18.0: callback که توسط Action Scheduler صدا زده می‌شود — push یک chunk به Faraz.
 * Function-name (نه closure) لازم است تا AS بتواند serialize کند.
 */
function farazsms_gf_pb_push_chunk( $phonebook_id, $contacts, $apikey = '' ) {
	$api = farazsms_gf_pb_get_api();
	if ( ! $api ) return;
	// آرگومان یا شناسه‌ی ترنزینت است (مسیرِ فعلی) یا خودِ آرایه (کارِ پارک‌شده‌ی
	// نسخه‌ی قبل). قراردادِ اعلام‌شده‌ی همین تابع است، نه گاردِ ورودیِ ناشناخته.
	$chunk_id = is_string( $contacts ) ? $contacts : '';
	if ( $chunk_id !== '' ) {
		$contacts = get_transient( $chunk_id );
		delete_transient( $chunk_id );
		if ( ! is_array( $contacts ) ) {
			farazsms_send_diag_log( 'phonebook', 'bulk-upsert', 'chunk_expired', array( 'source' => 'gf-phonebook' ) );
			return;
		}
	}
	if ( $apikey === '' ) {
		$apikey = (string) farazsms_get_apikey();
	}
	$result = $api->bulk_upsert_contacts( (int) $phonebook_id, $contacts, $apikey );

	// ⚠️ این مسیر پس‌زمینه‌ای است و پاسخی به کاربر نمی‌دهد؛ اگر نتیجه را دور بریزیم،
	// شکست (کلیدِ نامعتبر، دفترچه‌ی حذف‌شده، سقفِ نرخ) کاملاً بی‌صدا می‌ماند و
	// کاربر پیامِ «در صف قرار گرفت» را دیده است. تنها ردِ ممکن، لاگِ تشخیص است.
	$log = farazsms_gf_pb_chunk_failure_log( $result, count( (array) $contacts ) );
	if ( $log ) {
		farazsms_send_diag_log( 'phonebook', 'bulk-upsert', $log['result'], $log['context'] );
	}
}

/**
 * نگاشتِ نتیجه‌ی یک تکه‌ی پس‌زمینه‌ای به ردیفِ لاگِ تشخیص — یا null اگر چیزی برای گفتن نباشد.
 *
 * جدا نگه داشته می‌شود تا همین تصمیم (چه وقت لاگ، با چه کدی) در تست قابلِ ادعا باشد؛
 * این مسیر هیچ پاسخی به کاربر نمی‌دهد، پس لاگ تنها ردِ ممکن است.
 *
 * @param mixed $result خروجیِ bulk_upsert_contacts
 * @param int   $rows   تعدادِ ردیف‌های این تکه
 * @return array|null
 */
function farazsms_gf_pb_chunk_failure_log( $result, $rows ) {
	$ok     = is_array( $result ) && ! empty( $result['success'] );
	$failed = is_array( $result ) && isset( $result['failed'] ) ? (int) $result['failed'] : 0;
	if ( $ok && $failed <= 0 ) {
		return null;
	}
	$msg = is_array( $result ) && ! empty( $result['error'] ) ? (string) $result['error'] : 'unknown';
	return array(
		'result'  => 'api_error:' . $msg,
		'context' => array(
			'source'    => 'phonebook-bulk',
			// کدِ HTTP از خودِ نتیجه می‌آید؛ بدونِ آن، سقفِ نرخ در این مسیر
			// (که هیچ کانالِ کاربری ندارد) برای همیشه ناشناس می‌ماند.
			'http_code' => is_array( $result ) && isset( $result['http'] ) ? (int) $result['http'] : 0,
			'detail'    => 'gf-async rows=' . (int) $rows . ' failed=' . $failed,
		),
	);
}

// ============================================================================
// On every new submission — auto push
// ============================================================================

add_action( 'gform_after_submission', 'farazsms_gf_pb_on_submission', 10, 2 );
function farazsms_gf_pb_on_submission( $entry, $form ) {
	$form_id = (int) ( $form['id'] ?? 0 );
	if ( $form_id <= 0 ) return;

	$mappings = farazsms_gf_pb_get_mappings();
	if ( empty( $mappings ) ) return;

	$apikey = get_option( 'farazsms_apikey', '' );
	if ( $apikey === '' ) return;

	$api = farazsms_gf_pb_get_api();
	if ( ! $api ) return;

	foreach ( $mappings as $m ) {
		if ( (int) ( $m['form_id'] ?? 0 ) !== $form_id ) continue;

		$phone_field_id = (string) ( $m['phone_field_id'] ?? '' );
		$name_field_id  = (string) ( $m['name_field_id'] ?? '' );
		$phonebook_id   = (int) ( $m['phonebook_id'] ?? 0 );
		if ( $phone_field_id === '' || $phonebook_id <= 0 ) continue;

		$raw_phone = isset( $entry[ $phone_field_id ] ) ? (string) $entry[ $phone_field_id ] : '';
		if ( $raw_phone === '' ) continue;

		$normalized = farazsms_normalize_phone( $raw_phone );
		if ( ! preg_match( '/^09\d{9}$/', $normalized ) ) continue;

		$name = $name_field_id !== '' && isset( $entry[ $name_field_id ] )
			? sanitize_text_field( (string) $entry[ $name_field_id ] ) : '';

		// ⚠️ ارسالِ درجا ممنوع: این هوک روی درخواستِ بازدیدکننده اجرا می‌شود.
		//
		// تا v3.22.209 همین‌جا یک درخواستِ HTTP مسدودکننده به سرویس می‌رفت. هر
		// کندیِ سرویس مستقیم به کاربرِ در حالِ ثبتِ فرم می‌رسید — همان چیزی که
		// روی LiteSpeed به‌شکلِ ۵۰۳ دیده شد. حالا به صفِ مشترک می‌رود.
		//
		// شماره در آرگومانِ کار نمی‌نشیند (باقی‌مانده‌ی صف در آپشن سریال می‌شود
		// و شماره دادهٔ شخصی است): در ترنزینتِ غیرautoload می‌ماند و فقط
		// شناسه‌اش سفر می‌کند — همان الگوی مسیرِ گروهی.
		$chunk_id = 'farazsms_gf_pb_chunk_' . wp_generate_password( 12, false, false );
		set_transient( $chunk_id, array( array( 'phone' => $normalized, 'name' => $name ) ), 6 * HOUR_IN_SECONDS );
		if ( ! farazsms_queue_task( 'gf-phonebook', 'farazsms_gf_pb_push_chunk', array( $phonebook_id, $chunk_id ) ) ) {
			// صف نپذیرفت — بهتر است دیر برسد تا هرگز نرسد.
			delete_transient( $chunk_id );
			$api->add_contact( $phonebook_id, $name, $normalized, $apikey );
		}
	}
}

// ============================================================================
// Render admin page — قابل استفاده هم به‌صورت standalone، هم embed در phonebook
// ============================================================================

/**
 * تابع اصلی render — وقتی به‌صورت standalone صدا زده شود، wrapper کامل می‌سازد.
 */
function farazsms_gf_pb_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) return;
	$apikey = get_option( 'farazsms_apikey', '' );
	?>
	<section class="wrapper" style="direction:rtl;">
		<div id="farazsms_header">
			<div><a href="https://farazsms.com" target="_blank"><img src="<?php echo esc_url( FARAZSMS_CORE_IMG . 'logo-1.png' ); ?>" alt=""></a></div>
			<?php if ( $apikey !== '' ) : $credit = farazsms_get_credit(); ?>
				<div id="farazsms_account_info"><div class="farazsms_credit_amount"><span>میزان اعتبار: </span><?php echo esc_html( $credit ); ?><span> تومان</span></div><?php if ( function_exists( 'farazsms_render_profile_block' ) ) farazsms_render_profile_block(); ?></div>
			<?php endif; ?>
		</div>
		<?php farazsms_gf_pb_render_content(); ?>
	</section>
	<?php
}

/**
 * v3.17.5: محتوای صفحه (بدون wrapper) — برای embed در صفحه phonebook.
 */
function farazsms_gf_pb_render_content() {
	if ( ! current_user_can( 'manage_options' ) ) return;

	$apikey   = get_option( 'farazsms_apikey', '' );
	$mappings = farazsms_gf_pb_get_mappings();
	$gf_ok    = farazsms_gf_pb_is_gf_active();
	$api_ok   = $apikey !== '';

	// لیست فرم‌های GF
	$forms = array();
	if ( $gf_ok && class_exists( 'GFAPI' ) ) {
		$all = GFAPI::get_forms();
		foreach ( $all as $f ) {
			$forms[ (int) $f['id'] ] = array(
				'id'     => (int) $f['id'],
				'title'  => (string) ( $f['title'] ?? 'بدون نام' ),
				'fields' => isset( $f['fields'] ) && is_array( $f['fields'] ) ? $f['fields'] : array(),
			);
		}
	}

	// لیست دفترچه‌های فراز
	$phonebooks = array();
	if ( $api_ok ) {
		$api = farazsms_gf_pb_get_api();
		if ( $api ) {
			$pb_resp = $api->get_phonebooks( $apikey );
			// v3.21.40: باگِ «لیست دفترچه‌ها نمایش داده نمی‌شود» — get_phonebooks ساختارِ
			// خامِ API را برمی‌گرداند ({status, data:{items|data|[...]}}), نه کلیدهای
			// success/phonebooks. قبلاً این شرط همیشه false بود و dropdown خالی می‌ماند.
			// حالا دقیقاً مثلِ extract_phonebooks_list سه ساختارِ ممکن را می‌خوانیم.
			if ( is_array( $pb_resp ) ) {
				if ( isset( $pb_resp['data']['items'] ) && is_array( $pb_resp['data']['items'] ) ) {
					$phonebooks = $pb_resp['data']['items'];
				} elseif ( isset( $pb_resp['data']['data'] ) && is_array( $pb_resp['data']['data'] ) ) {
					$phonebooks = $pb_resp['data']['data'];
				} elseif ( isset( $pb_resp['data'] ) && is_array( $pb_resp['data'] ) && isset( $pb_resp['data'][0]['id'] ) ) {
					$phonebooks = $pb_resp['data'];
				}
			}
		}
	}
	?>
		<!-- Hero -->
		<div style="background:linear-gradient(135deg, #365891 0%, #4571ba 100%); color:#fff; border-radius:14px; padding:24px 28px; margin-bottom:18px; box-shadow:0 8px 24px rgba(14,116,144,0.18); position:relative; overflow:hidden;">
			<div style="position:absolute; top:-10px; left:-12px; font-size:120px; opacity:0.1; line-height:1;">📋</div>
			<div style="display:flex; align-items:center; gap:18px; flex-wrap:wrap; position:relative; z-index:2;">
				<div style="font-size:48px;">🔄</div>
				<div style="flex:1; min-width:220px;">
					<h2 style="margin:0 0 6px; font-size:20px; font-weight:800;">همگام‌سازی Gravity Forms → دفترچه تلفن</h2>
					<div style="font-size:13px; opacity:0.94; line-height:1.7;">
						هر فرم را به یک دفترچه تلفن متفاوت map کنید. ورودی‌های قبلی یکباره import می‌شوند،
						و submission های آینده به‌صورت خودکار به Faraz می‌رود.
					</div>
				</div>
			</div>
		</div>

		<?php if ( isset( $_GET['gf_pb_saved'] ) ) : ?>
			<div style="background:#e2f8f0; border:1px solid #10c282; color:#096d49; padding:10px 14px; border-radius:8px; margin-bottom:14px;">✓ Mapping ذخیره شد.</div>
		<?php endif; ?>
		<?php if ( isset( $_GET['gf_pb_deleted'] ) ) : ?>
			<div style="background:#faf1da; border:1px solid #e2a916; color:#83620d; padding:10px 14px; border-radius:8px; margin-bottom:14px;">⚠ Mapping حذف شد.</div>
		<?php endif; ?>
		<?php if ( isset( $_GET['gf_pb_error'] ) ) : ?>
			<div style="background:#fdeae8; border:1px solid #d52a16; color:#b32817; padding:10px 14px; border-radius:8px; margin-bottom:14px;">✗ <?php echo esc_html( rawurldecode( $_GET['gf_pb_error'] ) ); ?></div>
		<?php endif; ?>

		<?php if ( ! $gf_ok ) : ?>
			<div style="background:#faf1da; border:1.5px solid #e2a916; color:#83620d; padding:18px 22px; border-radius:12px; margin-bottom:18px;">
				⚠ افزونه Gravity Forms روی این سایت نصب یا فعال نیست. ابتدا آن را فعال کنید.
			</div>
		<?php endif; ?>

		<?php if ( ! $api_ok ) : ?>
			<div style="background:#faf1da; border:1.5px solid #e2a916; color:#83620d; padding:18px 22px; border-radius:12px; margin-bottom:18px;">
				⚠ کلید دسترسی (Api-Key) در <a href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-settings' ) ); ?>">تنظیمات افزونه</a> وارد نشده است.
			</div>
		<?php endif; ?>

		<!-- لیست mapping های موجود -->
		<?php if ( ! empty( $mappings ) ) : ?>
			<h3 style="margin:6px 0 12px; font-size:15px; color:#263f67; font-weight:700;">📋 سینک‌های فعال</h3>
			<div style="background:#fff; border:1.5px solid #e1e1e1; border-radius:12px; overflow:hidden; margin-bottom:24px;">
				<table style="width:100%; border-collapse:collapse; font-size:12.5px;">
					<thead style="background:#f5f8fe;">
						<tr>
							<th style="text-align:right; padding:12px 16px; border-bottom:1px solid #e1e1e1; font-weight:700;">فرم</th>
							<th style="text-align:right; padding:12px 16px; border-bottom:1px solid #e1e1e1; font-weight:700;">فیلد موبایل</th>
							<th style="text-align:right; padding:12px 16px; border-bottom:1px solid #e1e1e1; font-weight:700;">دفترچه مقصد</th>
							<th style="text-align:right; padding:12px 16px; border-bottom:1px solid #e1e1e1; font-weight:700;">آخرین ایمپورت</th>
							<th style="text-align:right; padding:12px 16px; border-bottom:1px solid #e1e1e1; font-weight:700;">عملیات</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $mappings as $m ) :
							$form_title = isset( $forms[ $m['form_id'] ] ) ? $forms[ $m['form_id'] ]['title'] : 'فرم #' . (int) $m['form_id'];
							$pb_name = '—';
							foreach ( $phonebooks as $pb ) {
								if ( (int) ( $pb['id'] ?? 0 ) === (int) $m['phonebook_id'] ) { $pb_name = $pb['title'] ?? ( $pb['name'] ?? '' ); break; }
							}
							?>
							<tr style="border-bottom:1px solid #f5f8fe;">
								<td style="padding:11px 16px;"><strong><?php echo esc_html( $form_title ); ?></strong> <span style="color:#9b9b9b;">#<?php echo (int) $m['form_id']; ?></span></td>
								<td style="padding:11px 16px; font-family:Menlo,Consolas,monospace; color:#4d4d4d; direction:ltr; text-align:right;">field #<?php echo esc_html( $m['phone_field_id'] ); ?></td>
								<td style="padding:11px 16px;"><?php echo esc_html( $pb_name ); ?> <span style="color:#9b9b9b;">#<?php echo (int) $m['phonebook_id']; ?></span></td>
								<td style="padding:11px 16px; color:#9b9b9b;">
									<?php if ( ! empty( $m['last_imported'] ) ) : ?>
										<?php echo esc_html( $m['last_imported'] ); ?>
										<br><span style="font-size:11px; color:#0c9765;">(<?php echo (int) $m['import_count']; ?> مخاطب)</span>
									<?php else : ?>
										<span style="color:#9b9b9b;">هنوز import نشده</span>
									<?php endif; ?>
								</td>
								<td style="padding:11px 16px;">
									<button type="button" class="farazsms-gf-pb-import-btn" data-mapping-id="<?php echo esc_attr( $m['id'] ); ?>" style="background:#0c9765; color:#fff; border:none; padding:7px 14px; border-radius:6px; font-size:11.5px; font-weight:700; cursor:pointer; margin-left:4px;">
										🚀 ایمپورت سوابق
									</button>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline;" onsubmit="return confirm('این mapping حذف شود؟');">
										<input type="hidden" name="action" value="farazsms_gf_pb_delete_mapping">
										<input type="hidden" name="mapping_id" value="<?php echo esc_attr( $m['id'] ); ?>">
										<?php wp_nonce_field( 'farazsms_gf_pb_delete_mapping' ); ?>
										<button type="submit" style="background:#fff; color:#d52a16; border:1px solid #d52a16; padding:7px 12px; border-radius:6px; font-size:11.5px; font-weight:600; cursor:pointer;">✗ حذف</button>
									</form>
									<div class="farazsms-gf-pb-import-msg" style="display:none; margin-top:8px; font-size:11.5px;"></div>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>

		<!-- فرم اضافه کردن mapping جدید -->
		<?php if ( $gf_ok && $api_ok ) : ?>
			<h3 style="margin:18px 0 12px; font-size:15px; color:#263f67; font-weight:700;">➕ اضافه کردن سینک جدید</h3>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="farazsms-gf-pb-form" style="background:#fff; border:1.5px solid #c1d0e8; border-radius:12px; padding:22px 26px;">
				<input type="hidden" name="action" value="farazsms_gf_pb_save_mapping">
				<?php wp_nonce_field( 'farazsms_gf_pb_save_mapping' ); ?>

				<div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:14px; margin-bottom:14px;">
					<label>
						<span style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:6px;">۱) انتخاب فرم</span>
						<select name="form_id" id="farazsms-gf-pb-form-id" required style="width:100%; padding:9px 12px; border:1px solid #e1e1e1; border-radius:7px;">
							<option value="">— انتخاب فرم —</option>
							<?php foreach ( $forms as $f ) : ?>
								<option value="<?php echo esc_attr( $f['id'] ); ?>"><?php echo esc_html( $f['title'] ); ?> (#<?php echo (int) $f['id']; ?>)</option>
							<?php endforeach; ?>
						</select>
					</label>

					<label>
						<span style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:6px;">۲) فیلد شماره موبایل</span>
						<select name="phone_field_id" id="farazsms-gf-pb-phone-field" required style="width:100%; padding:9px 12px; border:1px solid #e1e1e1; border-radius:7px;">
							<option value="">— ابتدا فرم را انتخاب کنید —</option>
						</select>
					</label>

					<label>
						<span style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:6px;">۳) فیلد نام (اختیاری)</span>
						<select name="name_field_id" id="farazsms-gf-pb-name-field" style="width:100%; padding:9px 12px; border:1px solid #e1e1e1; border-radius:7px;">
							<option value="">— بدون نام —</option>
						</select>
					</label>

					<label>
						<span style="display:block; font-size:13px; font-weight:600; color:#4d4d4d; margin-bottom:6px;">۴) دفترچه تلفن مقصد</span>
						<select name="phonebook_id" required style="width:100%; padding:9px 12px; border:1px solid #e1e1e1; border-radius:7px;">
							<option value="">— انتخاب دفترچه —</option>
							<?php foreach ( $phonebooks as $pb ) : ?>
								<option value="<?php echo esc_attr( $pb['id'] ?? '' ); ?>"><?php echo esc_html( $pb['title'] ?? ( $pb['name'] ?? ( '#' . ( $pb['id'] ?? '' ) ) ) ); ?></option>
							<?php endforeach; ?>
						</select>
						<?php if ( empty( $phonebooks ) ) : ?>
							<small style="display:block; margin-top:4px; color:#d52a16; font-size:11px;">⚠ هیچ دفترچه تلفنی در پنل فراز شما یافت نشد. ابتدا یک دفترچه بسازید.</small>
						<?php endif; ?>
					</label>
				</div>

				<div style="display:flex; justify-content:flex-end;">
					<button type="submit" style="background:#365891; color:#fff; border:none; padding:10px 24px; border-radius:8px; font-size:13.5px; font-weight:700; cursor:pointer; box-shadow:0 4px 12px rgba(67,56,202,0.22);">
						💾 ذخیره سینک
					</button>
				</div>
			</form>

			<!-- داده‌های فرم‌ها برای JS -->
			<script type="application/json" id="farazsms-gf-pb-forms-data"><?php echo wp_json_encode( $forms, JSON_UNESCAPED_UNICODE ); ?></script>
			<script>
			(function($){
				var formsData = {};
				try {
					formsData = JSON.parse(document.getElementById('farazsms-gf-pb-forms-data').textContent);
				} catch (e) {}

				$('#farazsms-gf-pb-form-id').on('change', function(){
					var fid = $(this).val();
					var $phone = $('#farazsms-gf-pb-phone-field');
					var $name = $('#farazsms-gf-pb-name-field');
					$phone.html('<option value="">— انتخاب فیلد —</option>');
					$name.html('<option value="">— بدون نام —</option>');
					if (!fid || !formsData[fid]) return;
					var fields = formsData[fid].fields || [];
					fields.forEach(function(field){
						var label = field.label || ('field #' + field.id);
						var typ = field.type || '';
						$phone.append('<option value="' + field.id + '">' + label + ' [' + typ + ']</option>');
						$name.append('<option value="' + field.id + '">' + label + ' [' + typ + ']</option>');
					});
				});

				// Import history button
				$('.farazsms-gf-pb-import-btn').on('click', function(){
					var $btn = $(this);
					var mappingId = $btn.data('mapping-id');
					var $msg = $btn.closest('td').find('.farazsms-gf-pb-import-msg');
					if (!confirm('شروع ایمپورت تمام ورودی‌های قبلی این فرم به دفترچه؟ این فرایند ممکن است چند دقیقه طول بکشد.')) return;
					$btn.prop('disabled', true).text('در حال ایمپورت...');
					$msg.hide().removeClass('success error');
					$.post(ajaxurl, {
						action: 'farazsms_gf_pb_import_history',
						nonce: '<?php echo esc_js( wp_create_nonce( 'farazsms_gf_pb_import' ) ); ?>',
						mapping_id: mappingId
					}, function(res){
						if (res && res.success) {
							$msg.css({background:'#e2f8f0', color:'#096d49', padding:'6px 10px', borderRadius:'5px', border:'1px solid #10c282'})
								.text(res.data.message).show();
							setTimeout(function(){ window.location.reload(); }, 1500);
						} else {
							var em = (res && res.data && res.data.message) || 'خطا';
							$msg.css({background:'#fdeae8', color:'#b32817', padding:'6px 10px', borderRadius:'5px', border:'1px solid #d52a16'})
								.text('✗ ' + em).show();
							$btn.prop('disabled', false).text('🚀 ایمپورت سوابق');
						}
					}).fail(function(){
						$msg.css({background:'#fdeae8', color:'#b32817', padding:'6px 10px', borderRadius:'5px', border:'1px solid #d52a16'})
							.text('✗ خطای ارتباط با سرور').show();
						$btn.prop('disabled', false).text('🚀 ایمپورت سوابق');
					});
				});
			})(jQuery);
			</script>
		<?php endif; ?>

		<!-- توضیحات -->
		<details style="margin-top:18px; background:#f5f8fe; border:1px solid #e1e1e1; border-radius:10px; padding:12px 16px; font-size:12px; color:#4d4d4d; line-height:1.8;">
			<summary style="cursor:pointer; font-weight:600; color:#263f67; font-size:12.5px;">🔍 چگونه کار می‌کند؟</summary>
			<div style="margin-top:10px;">
				<strong>۱) Mapping بسازید:</strong> فرم Gravity → فیلد موبایل → دفترچه تلفن مقصد.
				<br>
				<strong>۲) ایمپورت سوابق:</strong> دکمه «🚀 ایمپورت سوابق» تمام entry های موجود (تا ۵۰۰۰) را در یک batch ارسال می‌کند.
				<br>
				<strong>۳) سینک خودکار:</strong> از این به بعد، هر submission جدید روی این فرم خودکار به دفترچه مقصد اضافه می‌شود.
				<br>
				<strong>۴) چند فرم، چند دفترچه:</strong> می‌توانید چندین mapping داشته باشید — هر فرم با دفترچه‌ای متفاوت.
				<br>
				<strong>Performance:</strong> bulk upsert با chunk 500 — برای ۱۰هزار مخاطب حدود ۲۰ API call.
				<br>
				<strong>نرمالایز:</strong> همه‌ی شماره‌ها به فرمت <code style="background:#fff; padding:1px 6px; border-radius:4px; direction:ltr;">09xxxxxxxxx</code> تبدیل می‌شوند. شماره‌های نامعتبر skip می‌شوند.
			</div>
		</details>
	<?php
}
