<?php
/**
 * دفترچه‌تلفنِ مخصوصِ هر محصول (per-product phonebook).
 *
 * باکسی در صفحه‌ی ویرایشِ محصولِ ووکامرس (ستونِ کناری) که مدیر می‌تواند انتخاب کند خریدارانِ
 * این محصول در کدام دفترچه‌تلفن ذخیره شوند. پیش‌فرض: دفترچه‌ی عمومیِ افزونه (همان سینکِ
 * فعلی). اگر دفترچه‌ی اختصاصی انتخاب شود، خریدار «علاوه بر» دفترچه‌ی عمومی، در آن هم ذخیره
 * می‌شود (ذخیره در هر دو بی‌اشکال است — خواسته‌ی کاربر).
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_PRODUCT_PB_META = '_farazsms_product_phonebook_id';

/**
 * فهرستِ دفترچه‌های پنلِ فراز (id => title) — با کشِ یک‌ساعته (مثلِ بقیه‌ی نقاط).
 *
 * @return array<int,string>
 */
function farazsms_product_pb_get_list() {
	$api_key = farazsms_get_apikey();
	if ( $api_key === '' || ! class_exists( 'FarazSMS_Next_Phonebook_API' ) ) {
		return array();
	}
	$cache_key = 'farazsms_product_pb_list_' . md5( $api_key );
	$cached    = get_transient( $cache_key );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	$api  = new FarazSMS_Next_Phonebook_API();
	$resp = $api->get_phonebooks( $api_key );
	$rows = array();
	if ( is_array( $resp ) ) {
		if ( isset( $resp['data']['items'] ) && is_array( $resp['data']['items'] ) ) {
			$rows = $resp['data']['items'];
		} elseif ( isset( $resp['data']['data'] ) && is_array( $resp['data']['data'] ) ) {
			$rows = $resp['data']['data'];
		} elseif ( isset( $resp['data'] ) && is_array( $resp['data'] ) && isset( $resp['data'][0]['id'] ) ) {
			$rows = $resp['data'];
		}
	}
	$list = array();
	foreach ( (array) $rows as $r ) {
		if ( isset( $r['id'] ) ) {
			$list[ (int) $r['id'] ] = (string) ( $r['title'] ?? ( $r['name'] ?? ( '#' . $r['id'] ) ) );
		}
	}
	set_transient( $cache_key, $list, HOUR_IN_SECONDS );
	return $list;
}

// ============================================================================
// متاباکسِ محصول
// ============================================================================

add_action( 'add_meta_boxes', 'farazsms_product_pb_add_metabox' );
function farazsms_product_pb_add_metabox() {
	add_meta_box(
		'farazsms_product_phonebook',
		__( '📒 دفترچه‌تلفنِ این محصول (فراز اس ام اس)', 'farazsms' ),
		'farazsms_product_pb_render_metabox',
		'product',
		'side',
		'default'
	);
}

function farazsms_product_pb_render_metabox( $post ) {
	wp_nonce_field( 'farazsms_product_pb_save', 'farazsms_product_pb_nonce' );
	$current = (int) get_post_meta( $post->ID, FARAZSMS_PRODUCT_PB_META, true );
	$list    = farazsms_product_pb_get_list();
	$ready   = ( farazsms_get_apikey() !== '' );
	?>
	<p style="font-size:12px; color:#4d4d4d; line-height:1.9; margin:0 0 8px;">
		خریدارانِ این محصول، علاوه بر <strong>دفترچه‌ی عمومیِ افزونه</strong>، در دفترچه‌ی انتخابیِ زیر هم ذخیره می‌شوند.
		مثلاً برای یک محصولِ خاص می‌خواهید مخاطبانش جدا دسته‌بندی شوند (برای ارسالِ پیامکِ هدفمندِ همان گروه).
	</p>
	<?php if ( ! $ready ) : ?>
		<p style="color:#b32817; font-size:12px;">ابتدا کلیدِ دسترسی را در تنظیماتِ افزونه وارد کنید.</p>
	<?php elseif ( empty( $list ) ) : ?>
		<p style="color:#83620d; font-size:12px;">دفترچه‌ای در پنلِ فراز پیدا نشد. ابتدا یک دفترچه بسازید.</p>
	<?php else : ?>
		<select name="farazsms_product_phonebook_id" style="width:100%;">
			<option value="0"><?php esc_html_e( '— پیش‌فرض (فقط دفترچه‌ی عمومی) —', 'farazsms' ); ?></option>
			<?php foreach ( $list as $id => $title ) : ?>
				<option value="<?php echo (int) $id; ?>" <?php selected( $current, $id ); ?>>
					<?php echo esc_html( $title ); ?> (#<?php echo (int) $id; ?>)
				</option>
			<?php endforeach; ?>
		</select>
		<p style="font-size:11px; color:#787c82; margin-top:6px;">
			«پیش‌فرض» = همان رفتارِ معمول (فقط دفترچه‌ی عمومی). با انتخابِ یک دفترچه، خریدار در <em>هر دو</em> ذخیره می‌شود.
		</p>
	<?php endif; ?>
	<?php
}

add_action( 'save_post_product', 'farazsms_product_pb_save', 10, 2 );
function farazsms_product_pb_save( $post_id, $post ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! isset( $_POST['farazsms_product_pb_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['farazsms_product_pb_nonce'] ) ), 'farazsms_product_pb_save' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$pb_id = isset( $_POST['farazsms_product_phonebook_id'] ) ? (int) $_POST['farazsms_product_phonebook_id'] : 0;
	if ( $pb_id > 0 ) {
		update_post_meta( $post_id, FARAZSMS_PRODUCT_PB_META, $pb_id );
	} else {
		delete_post_meta( $post_id, FARAZSMS_PRODUCT_PB_META );
	}
}

// ============================================================================
// سینکِ سفارش → دفترچه‌های اختصاصیِ محصولات (افزایشی، fail-open)
// ============================================================================

add_action( 'woocommerce_checkout_order_processed', 'farazsms_product_pb_sync_order', 31, 1 );
function farazsms_product_pb_sync_order( $order_id ) {
	try {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$api_key = farazsms_get_apikey();
		if ( $api_key === '' ) {
			return;
		}
		$phone = (string) $order->get_billing_phone();
		$phone = farazsms_normalize_phone( $phone );
		if ( $phone === '' ) {
			return;
		}
		$name = trim( $order->get_formatted_billing_full_name() );
		if ( $name === '' ) {
			$name = __( 'مشتری', 'farazsms' );
		}

		// دفترچه‌های اختصاصیِ یکتا از روی محصولاتِ سفارش.
		$pb_ids = array();
		foreach ( $order->get_items() as $item ) {
			$pid = $item->get_product_id();
			if ( ! $pid ) {
				continue;
			}
			$pb = (int) get_post_meta( $pid, FARAZSMS_PRODUCT_PB_META, true );
			if ( $pb > 0 ) {
				$pb_ids[ $pb ] = true;
			}
		}
		if ( empty( $pb_ids ) ) {
			return;
		}
		foreach ( array_keys( $pb_ids ) as $pb_id ) {
			$args = array(
				'order_id'     => (int) $order_id,
				'phonebook_id' => (int) $pb_id,
				'name'         => $name,
				'phone'        => $phone,
			);
			// از همان workerِ fail-openِ ماژولِ دفترچه استفاده می‌کنیم.
			//
			// ⚠️ v3.22.202: شاخه‌ی دومِ این‌جا («اگر Action Scheduler نبود، همین‌جا
			// اجرا کن») حذف شد؛ روی سایتی بدونِ AS، ثبتِ مخاطب دقیقاً روی درخواستِ
			// ثبتِ سفارش انجام می‌شد. صف خودش نردبان دارد. گاردِ function_exists هم
			// لازم نیست: خودِ صف is_callable می‌کند و نامِ اشتباه را در لاگِ تشخیص
			// صدا می‌زند. کلیدِ API هم دیگر سفر نمی‌کند (worker خودش می‌خوانَد).
			// آرایه در یک عضو پیچیده می‌شود تا associative بودنش حفظ شود.
			farazsms_queue_task( 'product-phonebook', 'farazsms_next_pb_add_contact_worker', array( $args ) );
		}
	} catch ( \Throwable $e ) {
		error_log( 'farazsms product-phonebook sync failed: ' . $e->getMessage() );
	}
}
