<?php
/**
 * v3.22.45 (#6e): اطلاع‌رسانیِ آپدیتِ افزونه به مدیر + صفحه‌ی «بروزرسانی‌ها».
 *
 * وقتی افزونه (به‌صورتِ خودکار یا دستی) آپدیت می‌شود، یک پیامکِ یک‌بارهٔ پترنی به مدیرِ سایت
 * می‌رود و مدیر می‌تواند در صفحه‌ی «بروزرسانی‌ها» لیستِ تغییرات (از پیام‌های tagِ گیت‌لب) را ببیند.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

// کدِ پترنِ اطلاعِ آپدیت (بدونِ متغیر). قابلِ override در wp-config.php.
if ( ! defined( 'FARAZSMS_UPDATE_NOTIFY_PATTERN' ) ) {
	define( 'FARAZSMS_UPDATE_NOTIFY_PATTERN', 'bH192PdjEs' );
}

const FARAZSMS_NOTIFIED_VERSION_OPTION = 'farazsms_notified_version';

/** بیشترین تلاش برای اعلانِ یک نسخه، پیش از تسلیم‌شدن (هر تلاش دستِ‌کم ۱۵ دقیقه فاصله دارد). */
if ( ! defined( 'FARAZSMS_UPDATE_NOTIFY_MAX_TRIES' ) ) {
	define( 'FARAZSMS_UPDATE_NOTIFY_MAX_TRIES', 12 );
}

/**
 * کلیدِ «این نسخه اطلاع داده شد» — یک نقطه، تا نویسنده و خواننده هرگز از هم جدا نشوند.
 *
 * @param string $version
 * @return string
 */
function farazsms_updates_notified_key( $version ) {
	return 'farazsms_update_notified_' . md5( (string) $version );
}
const FARAZSMS_UPDATES_CHANGELOG_TRANSIENT = 'farazsms_updates_changelog';

// ============================================================================
// تشخیصِ آپدیت + ارسالِ یک‌بارهٔ پیامک
// ============================================================================

add_action( 'admin_init', 'farazsms_updates_maybe_notify' );
function farazsms_updates_maybe_notify() {
	if ( ! defined( 'FARAZSMS_PLUGIN_VERSION' ) ) {
		return;
	}
	$current = (string) FARAZSMS_PLUGIN_VERSION;
	$stored  = (string) get_option( FARAZSMS_NOTIFIED_VERSION_OPTION, '' );

	if ( $stored === '' ) {
		// نصبِ اول (یا اولین‌بارِ فعال‌شدنِ این قابلیت) → فقط نسخه را ثبت کن، پیامک نده.
		update_option( FARAZSMS_NOTIFIED_VERSION_OPTION, $current, false );
		return;
	}
	if ( $stored === $current ) {
		return; // تغییری رخ نداده.
	}

	delete_transient( FARAZSMS_UPDATES_CHANGELOG_TRANSIENT );

	// v3.22.69: اگر مدیر اطلاع‌رسانیِ پیامکیِ آپدیت را خاموش کرده، فقط نسخه ثبت شد؛ پیامک نرود.
	if ( get_option( 'farazsms_update_notify_optout', '0' ) === '1' ) {
		update_option( FARAZSMS_NOTIFIED_VERSION_OPTION, $current, false );
		return;
	}

	// ⚠️ v3.22.176 — ریشه‌ی «پیامکِ بروزرسانی نمی‌آید»: پیش از این، نسخه **قبل** از ارسال
	// ثبت می‌شد. اگر ارسال انجام نمی‌شد (کرانِ سایت خواب و کارِ ناهم‌زمان معلق، اعتبارِ
	// ناکافی، پترنِ ردشده)، آن اعلان برای همیشه از دست می‌رفت و هیچ تلاشِ دوباره‌ای نبود.
	// حالا نسخه فقط پس از ارسالِ موفق ثبت می‌شود و تا آن‌وقت، هر بازدیدِ پیشخوان
	// (با فاصله‌ی کوتاه، تا فشار نیاورد) دوباره تلاش می‌کند.
	if ( ! farazsms_updates_notify_attempt_allowed( $current ) ) {
		return;
	}

	// ارسال همیشه از صفِ مشترک می‌رود؛ هیچ شاخه‌ی همگامی نیست.
	//
	// ⚠️ v3.22.202: گاردِ function_exists برداشته شد. با حذفِ دیسپچرِ قدیمی آن
	// شرط false می‌شد و دقیقاً شاخه‌ی همگام را فعال می‌کرد — یعنی بارگذاریِ
	// پیشخوان پشتِ یک تماسِ HTTP، خلافِ همان قانونی که کامنتش را توجیه می‌کرد.
	// صف در عمقِ صفر بار می‌شود، پس گارد لازم نیست.
	farazsms_queue_task( 'updates-notify', 'farazsms_updates_send_notification', array( $current ) );
}

/**
 * آیا اجازه‌ی یک تلاشِ تازه برای اعلانِ همین نسخه هست؟
 *
 * جلوی طوفانِ تلاش در هر بارگذاریِ پیشخوان را می‌گیرد، ولی برخلافِ رفتارِ قبلی
 * «یک‌بار و تمام» نیست: هر ۱۵ دقیقه یک تلاشِ دیگر، تا وقتی ارسال موفق شود.
 *
 * @param string $version
 * @return bool
 */
function farazsms_updates_notify_attempt_allowed( $version ) {
	$key = 'farazsms_update_notify_try_' . md5( (string) $version );
	if ( get_transient( $key ) ) {
		return false;
	}

	// سقفِ تلاش: بدونِ آن، سایتی با پیکربندیِ خرابِ دائمی (اعتبارِ صفر، پترنِ تأییدنشده)
	// تا ابد هر ۱۵ دقیقه به سرویس می‌زند. پس از سقف، نسخه «اطلاع‌داده‌شده» ثبت می‌شود و
	// یک ردِ تشخیص می‌مانَد تا معلوم باشد چرا اعلان نرفت.
	$tries_key = 'farazsms_update_notify_tries_' . md5( (string) $version );
	$tries     = (int) get_option( $tries_key, 0 );
	if ( $tries >= FARAZSMS_UPDATE_NOTIFY_MAX_TRIES ) {
		farazsms_send_diag_log( 'update-notify', 'update-notify', 'api_error:اعلانِ بروزرسانی پس از تلاش‌های مکرر ارسال نشد', array(
			'source'    => 'update-notify',
			'http_code' => 0,
			'detail'    => 'version=' . $version . ' tries=' . $tries,
		) );
		// شمارنده عمداً پاک نمی‌شود: با پاک‌کردنش، فراخوانیِ بعدی از صفر شروع می‌کرد و
		// سقف بی‌اثر می‌شد. فقط ارسالِ موفق آن را پاک می‌کند.
		update_option( FARAZSMS_NOTIFIED_VERSION_OPTION, $version, false );
		return false;
	}
	update_option( $tries_key, $tries + 1, false );

	set_transient( $key, 1, 15 * MINUTE_IN_SECONDS );
	return true;
}


// ⚠️ ثبتِ هوک حذف شد: تنها فراخوان، صفِ مشترک است که کالبک را با نامش صدا
// می‌زند (is_callable)، نه با do_action. ثبتِ خودارجاع فقط گمراه‌کننده بود.
/**
 * @param string $version
 */
function farazsms_updates_send_notification( $version ) {
	$pattern = defined( 'FARAZSMS_UPDATE_NOTIFY_PATTERN' ) ? (string) FARAZSMS_UPDATE_NOTIFY_PATTERN : '';
	if ( $pattern === '' || ! function_exists( 'farazsms_sms_send_pattern' ) ) {
		return;
	}
	// ضدِ ارسالِ دوباره برای همین نسخه (اگر async دو بار fire شود).
	$sent_key = farazsms_updates_notified_key( $version );
	if ( get_transient( $sent_key ) ) {
		return;
	}
	// ادعای کوتاهِ اسلات **پیش از** ارسال: بدونِ آن، یک کارِ صف‌شده و یک تلاشِ همگام
	// می‌توانند هم‌زمان بفرستند و مدیر دو پیامکِ یکسان بگیرد (دو نسخه‌ی اخیر برای رفعِ
	// همین کلاسِ باگ منتشر شد). روی موفقیت به یک روز ارتقا می‌یابد.
	set_transient( $sent_key, 1, 10 * MINUTE_IN_SECONDS );

	$phones = farazsms_updates_admin_phones();
	if ( empty( $phones ) ) {
		// شماره‌ی مدیری تنظیم نشده — کسی برای اطلاع نیست. نسخه را ثبت می‌کنیم تا این
		// حالت هر ۱۵ دقیقه دوباره تلاش نکند؛ چیزی برای فرستادن وجود ندارد.
		update_option( FARAZSMS_NOTIFIED_VERSION_OPTION, $version, false );
		return;
	}
	$sender = farazsms_cfg_sender();

	// v3.22.111: متغیرِ %domain% — آدرسِ (هاستِ) سایت، تا وقتی کسی چند سایت دارد بفهمد
	// این پیامکِ بروزرسانی برای کدام سایت بوده است. مقدار همیشه غیرخالی است.
	$domain = farazsms_pattern_site_domain();
	// ⚠️ v3.22.205 — نامِ متغیر **دو شکل** فرستاده می‌شود.
	//
	// کدِ این پترن در افزونه هاردکد است، یعنی همه‌ی نصب‌ها از یک پترنِ مشترک
	// استفاده می‌کنند. آن پترن در پنل ویرایش شده و متغیرش «domin» نام گرفته،
	// در حالی که افزونه «domain» می‌فرستاد؛ پنل هم پترنی را که همه‌ی متغیرهای
	// اعلام‌شده‌اش نیامده باشد با ۴۰۰ رد می‌کند. نتیجه: پیامکِ اطلاعِ
	// به‌روزرسانی روی **هر** سایتی که این پترن را دارد قطع شده بود، و تنها
	// ردش یک ردیفِ لاگ بود که کسی نمی‌بیند.
	//
	// متغیرِ اضافه بی‌ضرر است (پنل نامِ ناشناخته را نادیده می‌گیرد)، پس هر دو
	// املا فرستاده می‌شود تا هم پترنِ فعلی کار کند و هم اگر روزی در پنل به
	// «domain» تغییر نام داد.
	$attributes = array(
		'domain' => $domain,
		'domin'  => $domain,
	);

	// اگر پترن در پنلِ فراز شاملِ %domain% باشد، آدرسِ سایت جایگزین می‌شود؛
	// اگر نباشد، فراز این متغیرِ اضافی را نادیده می‌گیرد و متنِ ثابتِ پترن ارسال می‌شود.
	farazsms_updates_notify_dispatch(
		$version,
		$phones,
		function ( $phone ) use ( $pattern, $attributes, $sender ) {
			return farazsms_sms_send_pattern( $phone, $pattern, $attributes, $sender );
		}
	);
}

/**
 * آیا این پاسخ یک خطای **پیکربندی** است، نه یک شکستِ گذرا؟
 *
 * ⚠️ چرا تفکیک لازم است: منطقِ تلاشِ دوباره برای شکستِ گذرا نوشته شده (کرونِ
 * خواب، اعتبارِ لحظه‌ای، تایم‌اوت). خطای پیکربندی — مثلاً پترنی که متغیری
 * می‌خواهد که ما نمی‌فرستیم — با تکرار **هرگز** درست نمی‌شود. روی سایتِ واقعی
 * همین یازده تلاشِ بی‌فایده در یک روز ساخت، و تنها ردش ردیف‌های لاگی بود که
 * کسی نمی‌بیند. چنین خطایی باید یک‌بار، صریح، و با نامِ همان متغیر گزارش شود.
 *
 * @param mixed $res پاسخِ لایه‌ی ارسال.
 * @return string نامِ فیلدِ جاافتاده، یا رشته‌ی خالی اگر خطای پیکربندی نبود.
 */
function farazsms_updates_missing_pattern_field( $res ) {
	// ⚠️ پاسخ همیشه رشته‌ی فارسیِ تخت نیست. لایه‌ی ارسال گاهی بدنه‌ی خامِ سرویس
	// را برمی‌گرداند (وقتی envelope نشناسد) و کیفِ اعتبارسنجیِ لاراول هم به‌شکلِ
	// آرایه‌ی تودرتو می‌آید. اگر فقط روی رشته‌ی تخت regex بزنیم، همان روزی که
	// قالبِ پیام عوض شود، تشخیص کور می‌شود و یازده تلاشِ بی‌فایده برمی‌گردد —
	// بدونِ هیچ نشانه‌ای که آشکارساز از کار افتاده.
	$text = '';
	if ( is_string( $res ) ) {
		$text    = $res;
		$decoded = json_decode( $res, true );
		if ( is_array( $decoded ) ) {
			$text .= ' ' . wp_json_encode( $decoded, JSON_UNESCAPED_UNICODE );
		}
	} elseif ( is_array( $res ) ) {
		$text = (string) wp_json_encode( $res, JSON_UNESCAPED_UNICODE );
	} else {
		return '';
	}

	// قالبِ پیامِ سرویس: «فیلد X باید ارسال شود.»
	if ( preg_match( '/فیلد\s+([A-Za-z0-9_\-]+)\s+باید ارسال شود/u', $text, $m ) ) {
		return $m[1];
	}
	// شکلِ دومِ همان خطا: کیفِ اعتبارسنجی، که کلیدش نامِ همان فیلد است.
	if ( preg_match( '/"([A-Za-z0-9_\-]+)"\s*:\s*\[[^]]*باید ارسال شود/u', $text, $m ) ) {
		return $m[1];
	}
	return '';
}

/**
 * ارسال به گیرنده‌ها و ثبتِ نسخه **فقط در صورتِ موفقیت**.
 *
 * ⚠️ قلبِ رفعِ v3.22.176 و دلیلِ جدا بودنش: با تزریقِ فرستنده، همین قرارداد
 * («شکست ⇒ نسخه ثبت نشود ⇒ دفعه‌ی بعد دوباره تلاش شود») بدونِ شبکه ادعا می‌شود.
 *
 * @param string   $version
 * @param string[] $phones
 * @param callable $send   تابعی که یک شماره می‌گیرد و پاسخِ لایه‌ی ارسال را برمی‌گرداند.
 * @return bool آیا دستِ‌کم یک ارسال موفق بود؟
 */
function farazsms_updates_notify_dispatch( $version, array $phones, $send ) {
	$sent_any = false;
	$missing  = '';
	foreach ( $phones as $phone ) {
		$res = call_user_func( $send, $phone );
		if ( farazsms_updates_send_looks_successful( $res ) ) {
			$sent_any = true;
			continue;
		}
		if ( $missing === '' ) {
			$missing = farazsms_updates_missing_pattern_field( $res );
		}
	}

	// خطای پیکربندی: تلاشِ دوباره بی‌فایده است. نسخه «اطلاع‌داده‌شده» ثبت
	// می‌شود تا حلقه بایستد، و به‌جای ردیفِ لاگِ خاموش، به مدیر گفته می‌شود
	// دقیقاً کدام متغیر کم است و چه باید بکند.
	if ( ! $sent_any && $missing !== '' ) {
		update_option( 'farazsms_update_notify_pattern_error', array(
			'field'      => $missing,
			'pattern'    => defined( 'FARAZSMS_UPDATE_NOTIFY_PATTERN' ) ? (string) FARAZSMS_UPDATE_NOTIFY_PATTERN : '',
			'version'    => (string) $version,
			'noticed_at' => time(),
		), false );
		// گیرنده و کدِ پترن هر دو در دسترس‌اند؛ خالی‌گذاشتنشان یعنی ردیف دقیقاً در
		// همان دو ستونی خالی بماند که پشتیبان رویشان فیلتر می‌کند.
		farazsms_send_diag_log(
			isset( $phones[0] ) ? (string) $phones[0] : '',
			defined( 'FARAZSMS_UPDATE_NOTIFY_PATTERN' ) ? (string) FARAZSMS_UPDATE_NOTIFY_PATTERN : '',
			'api_error:پترنِ اطلاعِ بروزرسانی متغیرِ «' . $missing . '» می‌خواهد که افزونه نمی‌فرستد — تلاشِ دوباره متوقف شد',
			array(
				'source'    => 'update-notify',
				'http_code' => 400,
				'detail'    => 'version=' . $version,
			)
		);
		// شمارنده‌ی تلاش دیگر به کار نمی‌آید؛ ماندنش یک ردیفِ آپشنِ یتیم است.
		delete_option( 'farazsms_update_notify_tries_' . md5( $version ) );
		update_option( FARAZSMS_NOTIFIED_VERSION_OPTION, $version, false );
		return false;
	}

	// فقط وقتی واقعاً چیزی رفت، نسخه را «اطلاع‌داده‌شده» علامت بزن. در غیرِ این صورت
	// بازدیدِ بعدیِ پیشخوان (پس از پنجره‌ی تلاش) دوباره امتحان می‌کند.
	if ( $sent_any ) {
		set_transient( farazsms_updates_notified_key( $version ), 1, DAY_IN_SECONDS );
		delete_option( 'farazsms_update_notify_tries_' . md5( (string) $version ) );
		update_option( FARAZSMS_NOTIFIED_VERSION_OPTION, $version, false );
	}
	return $sent_any;
}

/**
 * آیا پاسخِ لایه‌ی ارسال «واقعاً رفت» است؟
 *
 * لایه‌ی ارسال برای خطاها رشته‌های شناخته‌شده برمی‌گرداند (missing_params و …) یا پاسخِ
 * JSONِ سرویس. هر چیزی که صریحاً خطا باشد، «نرفته» شمرده می‌شود تا تلاشِ دوباره ممکن بماند.
 *
 * @param mixed $res
 * @return bool
 */
function farazsms_updates_send_looks_successful( $res ) {
	// ⚠️ قراردادِ واقعیِ farazsms_sms_send_pattern (خوانده‌شده از inc/farazsms-sms-service.php):
	//     'success' | 'missing_params' | 'api_error:<msg>' | 'curl_error:<msg>' | <بدنه‌ی خام>
	// پس فهرستِ **مجاز** لازم است، نه فهرستِ ممنوع: نسخه‌ی اولِ این تابع هر رشته‌ی ناشناخته را
	// «موفق» می‌گرفت و در نتیجه «اعتبارِ ناکافی» و «تایم‌اوتِ شبکه» — دقیقاً همان دو حالتی که
	// این رفع برایشان نوشته شد — باز هم اعلان را برای همیشه می‌سوزاندند.
	if ( is_string( $res ) ) {
		if ( $res === 'success' ) {
			return true;
		}
		$decoded = json_decode( $res, true );
		if ( ! is_array( $decoded ) ) {
			return false; // 'api_error:…' / 'curl_error:…' / 'missing_params' / بدنه‌ی ناشناخته
		}
		$res = $decoded;
	}
	if ( is_array( $res ) ) {
		return isset( $res['status'] ) && $res['status'] === 'success';
	}
	return false;
}

/**
 * شماره‌های مدیرِ سایت برای اطلاع‌رسانی — از منابعِ موجودِ افزونه جمع و یکتا می‌شوند.
 *
 * @return array<int,string>
 */
function farazsms_updates_admin_phones() {
	$raw = array();
	$comment_phones = (string) get_option( 'farazsms_comment_admin_phones', '' );
	if ( $comment_phones !== '' ) {
		$raw[] = $comment_phones;
	}
	$r = farazsms_order_sms_admin_recipients( farazsms_order_sms_settings() );
	if ( is_array( $r ) ) {
		$raw = array_merge( $raw, $r );
	}
	$phones = array();
	foreach ( $raw as $chunk ) {
		foreach ( preg_split( '/[\s,،;]+/u', (string) $chunk ) as $p ) {
			$p = farazsms_normalize_phone( $p );
			if ( preg_match( '/^09\d{9}$/', (string) $p ) ) {
				$phones[ $p ] = true;
			}
		}
	}
	return array_keys( $phones );
}

// ============================================================================
// چنج‌لاگ (لیستِ تغییرات) از پیام‌های tagِ گیت‌لب — داخلِ صفحه‌ی موجودِ «به‌روزرسانی افزونه»
// (slug: farazsms-updates) رندر می‌شود؛ منوی جداگانه‌ای ساخته نمی‌شود تا با آن صفحه برخورد نکند.
// ============================================================================

add_action( 'farazsms_updates_page_after', 'farazsms_updates_render_changelog' );

/**
 * فهرستِ نسخه‌ها از tagهای گیت‌لب (هر tag پیام دارد = شرحِ تغییراتِ آن نسخه). ۶ ساعت کش می‌شود.
 *
 * @return array<int,array{version:string,tag:string,message:string,date:string}>
 */
function farazsms_updates_fetch_changelog() {
	$cached = get_transient( FARAZSMS_UPDATES_CHANGELOG_TRANSIENT );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	if ( ! defined( 'FARAZSMS_UPDATE_GITLAB_BASE' ) || ! defined( 'FARAZSMS_UPDATE_PROJECT' ) ) {
		return array();
	}
	$project = rawurlencode( FARAZSMS_UPDATE_PROJECT );
	$url     = trailingslashit( FARAZSMS_UPDATE_GITLAB_BASE ) . 'api/v4/projects/' . $project . '/repository/tags?per_page=50';
	$resp    = wp_remote_get( $url, array(
		'timeout'    => 8,
		'sslverify'  => true,
		'user-agent' => 'FarazSMS-Updater/' . FARAZSMS_PLUGIN_VERSION,
	) );
	if ( is_wp_error( $resp ) || (int) wp_remote_retrieve_response_code( $resp ) !== 200 ) {
		return array();
	}
	$tags = json_decode( wp_remote_retrieve_body( $resp ), true );
	if ( ! is_array( $tags ) ) {
		return array();
	}
	$list = array();
	foreach ( $tags as $t ) {
		$name = isset( $t['name'] ) ? (string) $t['name'] : '';
		$ver  = ltrim( $name, 'vV' );
		if ( ! preg_match( '/^\d+(\.\d+){1,3}$/', $ver ) ) {
			continue;
		}
		$msg = '';
		if ( ! empty( $t['message'] ) ) {
			$msg = (string) $t['message'];
		} elseif ( ! empty( $t['release']['description'] ) ) {
			$msg = (string) $t['release']['description'];
		} elseif ( isset( $t['commit']['title'] ) ) {
			$msg = (string) $t['commit']['title'];
		}
		$date   = isset( $t['commit']['committed_date'] ) ? (string) $t['commit']['committed_date'] : '';
		$list[] = array( 'version' => $ver, 'tag' => $name, 'message' => trim( $msg ), 'date' => $date );
	}
	usort( $list, function ( $a, $b ) {
		return version_compare( $b['version'], $a['version'] );
	} );
	set_transient( FARAZSMS_UPDATES_CHANGELOG_TRANSIENT, $list, 6 * HOUR_IN_SECONDS );
	return $list;
}

/**
 * حذفِ ایموجی/نمادهای تصویری از متنِ چنج‌لاگ — کاربر متنِ فارسیِ ساده می‌خواهد.
 * (کامیت‌های گیت طبقِ قانون ایموجی دارند؛ فقط نمایشِ کاربرپسند پاک می‌شود.)
 * پیکان‌ها و نشانه‌گذاریِ متنی (→، —) دست‌نخورده می‌مانند.
 */
function farazsms_updates_strip_emoji( $text ) {
	if ( ! is_string( $text ) || $text === '' ) {
		return $text;
	}
	$text = preg_replace( '/[\x{1F000}-\x{1FFFF}\x{2600}-\x{27BF}\x{2B00}-\x{2BFF}\x{FE00}-\x{FE0F}\x{200D}\x{20E3}\x{2049}\x{203C}]/u', '', $text );
	// فاصله‌های اضافیِ باقی‌مانده در ابتدای خطوط پس از حذفِ ایموجی.
	$text = preg_replace( "/[ \t]+\n/", "\n", (string) $text );
	$text = preg_replace( "/\n[ \t]+/", "\n", (string) $text );
	return trim( (string) $text );
}

function farazsms_updates_render_changelog() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$current = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? (string) FARAZSMS_PLUGIN_VERSION : '';
	$list    = farazsms_updates_fetch_changelog();
	// v3.22.69 (امنیتی): فقط ۳ نسخه‌ی آخر نمایش داده شود — نه کلِ تاریخچه.
	if ( is_array( $list ) && count( $list ) > 3 ) {
		$list = array_slice( $list, 0, 3 );
	}
	?>
	<div style="direction:rtl; max-width:840px; margin-top:26px;">
		<h2 style="font-size:18px; margin:0 0 4px;">لیستِ تغییرات (Changelog)</h2>
		<p style="color:#9b9b9b; font-size:12.5px; margin:0 0 12px;">۳ نسخه‌ی آخر — تازه‌ترین بالا.</p>

		<?php if ( empty( $list ) ) : ?>
			<div style="background:#faf1da; border:1px solid #e2a916; color:#83620d; padding:14px 18px; border-radius:10px; font-size:13px; line-height:1.9;">
				فهرستِ تغییرات در حالِ حاضر در دسترس نیست (ارتباط با سرورِ به‌روزرسانی برقرار نشد). کمی بعد دوباره تلاش کنید.
			</div>
		<?php else : ?>
			<div style="display:flex; flex-direction:column; gap:12px; margin-top:16px;">
				<?php foreach ( $list as $rel ) :
					$is_current = ( $rel['version'] === $current );
					$jdate = '';
					if ( $rel['date'] !== '' ) {
						$jdate = farazsms_send_reports_to_jalali( strtotime( $rel['date'] ), false );
					}
					?>
					<div style="background:#fff; border:1px solid <?php echo $is_current ? '#10c282' : '#e1e1e1'; ?>; border-right:4px solid <?php echo $is_current ? '#0c9765' : '#9b9b9b'; ?>; border-radius:12px; padding:14px 18px; box-shadow:0 1px 2px rgba(0,0,0,.03);">
						<div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
							<span style="font-weight:800; font-size:15px; direction:ltr;"><?php echo esc_html( $rel['tag'] ); ?></span>
							<?php if ( $is_current ) : ?>
								<span style="background:#e2f8f0; color:#096d49; font-size:11px; font-weight:700; padding:2px 9px; border-radius:20px;">نسخه‌ی فعلیِ شما</span>
							<?php endif; ?>
							<?php if ( $jdate !== '' ) : ?>
								<span style="color:#9b9b9b; font-size:11.5px; margin-right:auto;"><?php echo esc_html( $jdate ); ?></span>
							<?php endif; ?>
						</div>
						<?php if ( $rel['message'] !== '' ) : ?>
							<pre style="white-space:pre-wrap; word-break:break-word; font-family:inherit; font-size:13px; color:#4d4d4d; margin:8px 0 0; line-height:1.9;"><?php echo esc_html( farazsms_updates_strip_emoji( $rel['message'] ) ); ?></pre>
						<?php endif; ?>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
	<?php
}

// ============================================================================
// v3.22.69: تیکِ روشن/خاموشِ اطلاع‌رسانیِ پیامکیِ آپدیت (پیش‌فرض روشن — الگوی opt-outِ Matomo)
// ============================================================================

add_action( 'admin_post_farazsms_update_notify_toggle', 'farazsms_update_notify_toggle_handler' );
function farazsms_update_notify_toggle_handler() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی غیرمجاز.', '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'farazsms_update_notify_toggle' );
	// تیک = روشن (optout='0')؛ بدونِ تیک = خاموش (optout='1').
	$optout = isset( $_POST['farazsms_update_notify_enable'] ) ? '0' : '1';
	update_option( 'farazsms_update_notify_optout', $optout, false );

	$url = add_query_arg( 'farazsms_un_saved', '1', wp_get_referer() ?: admin_url( 'admin.php?page=farazsms-updates' ) );
	if ( function_exists( 'farazsms_self_update_safe_redirect' ) ) {
		farazsms_self_update_safe_redirect( $url ); // مقاوم به headers-already-sent.
	} else {
		wp_safe_redirect( $url );
		exit;
	}
}

/**
 * کارتِ کم‌رنگ (داخلِ <details>) در پایینِ صفحه‌ی «به‌روزرسانی افزونه» — کم‌جلوه، مثلِ آمار.
 */
add_action( 'farazsms_updates_page_after', 'farazsms_update_notify_render_card' );
function farazsms_update_notify_render_card() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$enabled = get_option( 'farazsms_update_notify_optout', '0' ) !== '1';
	?>
	<details style="margin-top:16px; border:1px solid #e1e1e1; border-radius:10px; padding:6px 16px; background:#fff; direction:rtl; max-width:820px;">
		<summary style="cursor:pointer; color:#9b9b9b; font-size:13px; padding:8px 0;">⚙️ اطلاع‌رسانیِ پیامکیِ آپدیت</summary>
		<div style="padding:6px 2px 12px; line-height:2; font-size:13px; color:#4d4d4d;">
			<?php if ( isset( $_GET['farazsms_un_saved'] ) ) : ?>
				<div style="background:#e2f8f0; border:1px solid #10c282; color:#096d49; padding:8px 12px; border-radius:8px; margin-bottom:10px;">✓ ذخیره شد.</div>
			<?php endif; ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="farazsms_update_notify_toggle">
				<?php wp_nonce_field( 'farazsms_update_notify_toggle' ); ?>
				<label style="display:flex; align-items:center; gap:10px;">
					<input type="checkbox" name="farazsms_update_notify_enable" value="1" <?php checked( $enabled ); ?> style="width:16px;height:16px;">
					<span>وقتی افزونه به‌روزرسانی شد، با پیامک به مدیر (شماره‌های مدیرِ سایت) اطلاع بده.</span>
				</label>
				<button type="submit" class="button button-small" style="margin-top:10px;">ذخیره</button>
			</form>
		</div>
	</details>
	<?php
}

add_action( 'admin_notices', 'farazsms_update_notify_pattern_error_notice' );
/**
 * هشدارِ «پترنِ اطلاعِ بروزرسانی با افزونه نمی‌خوانَد».
 *
 * ⚠️ بدونِ این، تنها ردِ ماجرا یک ردیف در لاگِ تشخیص بود و فروشنده فقط
 * می‌فهمید «مدتی است پیامکِ بروزرسانی نمی‌آید» — بدونِ هیچ سرنخی.
 *
 * @return void
 */
function farazsms_update_notify_pattern_error_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$e = get_option( 'farazsms_update_notify_pattern_error', array() );
	if ( ! is_array( $e ) || empty( $e['field'] ) ) {
		return;
	}
	// ⚠️ آپشن **پاک نمی‌شود**. admin_notices روی هر صفحه‌ی مدیریت اجرا می‌شود،
	// از جمله صفحه‌هایی که بلافاصله ریدایرکت می‌شوند یا خروجی‌شان دیده نمی‌شود؛
	// پاک‌کردن پیش از رندر یعنی تنها هشدارِ موجود می‌تواند بی‌آنکه کسی ببیند
	// مصرف شود — و چون نسخه هم «اطلاع‌داده‌شده» ثبت شده، دیگر هیچ ردی نمی‌ماند.
	// خودِ نوتیس dismissible است و بستنش دستِ مدیر است.
	?>
	<div class="notice notice-warning is-dismissible" style="direction:rtl;">
		<p>
			<strong>فراز اس ام اس:</strong>
			<?php
			printf(
				/* translators: 1: نامِ متغیر 2: کدِ پترن */
				esc_html__( 'پیامکِ اطلاع‌رسانیِ به‌روزرسانی ارسال نشد: پترنِ «%2$s» در پنل متغیری به نامِ «%1$s» دارد که افزونه آن را نمی‌فرستد. در پنلِ فراز آن متغیر را از پترن بردارید (یا نامش را به «domain» تغییر دهید) تا پیامک دوباره برقرار شود.', 'farazsms' ),
				esc_html( (string) $e['field'] ),
				esc_html( (string) ( $e['pattern'] ?? '' ) )
			);
			?>
		</p>
		<p>
			<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'farazsms_dismiss_pattern_error', '1' ), 'farazsms_dismiss_pattern_error' ) ); ?>">
				<?php esc_html_e( 'متوجه شدم، دیگر نشان نده', 'farazsms' ); ?>
			</a>
		</p>
	</div>
	<?php
}

add_action( 'admin_init', 'farazsms_update_notify_pattern_error_dismiss' );
/**
 * بستنِ دستیِ هشدارِ ناهم‌خوانیِ پترن.
 *
 * @return void
 */
function farazsms_update_notify_pattern_error_dismiss() {
	if ( empty( $_GET['farazsms_dismiss_pattern_error'] ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'farazsms_dismiss_pattern_error' ) ) {
		return;
	}
	delete_option( 'farazsms_update_notify_pattern_error' );
}
