<?php
/**
 * OTP (One-Time Password) backend for form verification
 * Used by Gravity Forms and Elementor form OTP fields.
 *
 * Handles: generate/store OTP in transient, send via pattern SMS, verify and set verified transient.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/** OTP transient expiry (seconds) */
// v3.22.32: از ۱۲۰ به ۳۰۰ افزایش یافت — زیرِ اینترنتِ ملی پیامک گاهی با تأخیر می‌رسد و کدِ
// درست به‌عنوانِ «منقضی» رد می‌شد. ماژولِ لاگین از قبل ۳۰۰ ثانیه دارد؛ اینجا هم‌تراز شد.
define( 'FARAZSMS_OTP_TRANSIENT_EXPIRY', 300 );

/** Verified transient expiry (seconds) - form can be submitted within this window */
define( 'FARAZSMS_OTP_VERIFIED_EXPIRY', 300 );

/** Rate limit: min seconds between send per mobile */
define( 'FARAZSMS_OTP_RATE_LIMIT_SECONDS', 60 );

/** Max consecutive failed verify attempts before lockout */
define( 'FARAZSMS_OTP_MAX_ATTEMPTS', 5 );

/** Lockout duration after max failed attempts (seconds) */
define( 'FARAZSMS_OTP_LOCKOUT_SECONDS', 15 * MINUTE_IN_SECONDS );

/**
 * v3.17.3: تزریق یک‌بار CSS مدرن برای فیلد OTP — برای GF و Elementor مشترک.
 * v3.20.0: inline `<style>` به فایل خارجی منتقل شد (assets/css/farazsms-otp-modern.css)
 * تا browser cache کند. این تابع فقط یک‌بار enqueue را تضمین می‌کند.
 */
function farazsms_otp_maybe_inject_styles() {
	static $injected = false;
	if ( $injected ) return;
	$injected = true;

	$css_url = defined( 'FARAZSMS_CORE_CSS' )
		? FARAZSMS_CORE_CSS . 'farazsms-otp-modern.css'
		: ( defined( 'FARAZSMS_PLUGIN_FILE' )
			? plugins_url( 'assets/css/farazsms-otp-modern.css', FARAZSMS_PLUGIN_FILE )
			: '' );

	if ( $css_url === '' ) return;

	if ( did_action( 'wp_enqueue_scripts' ) ) {
		// قبلاً enqueue phase تمام شده — print فوری (HTML head ممکن است هنوز باز باشد یا inline در body)
		printf(
			'<link rel="stylesheet" id="farazsms-otp-modern-css" href="%s" media="all" />',
			esc_url( $css_url )
		);
	} else {
		wp_enqueue_style( 'farazsms-otp-modern', $css_url, array(), defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1.0', 'all' );
	}
}

/**
 * Normalize mobile for storage/transient key (consistent format).
 *
 * @param string $mobile Raw mobile input.
 * @return string Normalized mobile.
 */
function farazsms_otp_normalize_mobile( $mobile ) {
	if ( empty( $mobile ) ) {
		return '';
	}
	// v3.17.6: ابتدا ارقام فارسی/عربی را به لاتین تبدیل کن — قبل از regex
	$mobile = farazsms_tr_num( $mobile );
	$mobile = preg_replace( '/[\s\-]/', '', $mobile );
	preg_match_all( '/\d+/', $mobile, $m );
	$digits = implode( '', $m[0] ?? [] );
	if ( empty( $digits ) ) {
		return '';
	}
	// Iranian: 09... or 9... → 09...
	if ( strlen( $digits ) >= 10 && ( substr( $digits, 0, 2 ) === '98' || substr( $digits, 0, 1 ) === '9' ) ) {
		if ( substr( $digits, 0, 2 ) === '98' ) {
			$digits = '0' . substr( $digits, 2 );
		} elseif ( substr( $digits, 0, 1 ) === '9' && strlen( $digits ) === 10 ) {
			$digits = '0' . $digits;
		}
	}
	return $digits;
}

/**
 * Generate and store OTP for a mobile, send SMS via pattern.
 *
 * @param string $mobile Normalized mobile number.
 * @return array { 'success' => bool, 'message' => string }
 */
function farazsms_otp_send_code( $mobile ) {
	$pattern_code = get_option( 'farazsms_otp_pattern', '' );
	if ( empty( $pattern_code ) ) {
		return array(
			'success' => false,
			'message' => __( 'کد پترنِ «تأیید موبایل» ساخته نشده است؛ به همین دلیل پیامک ارسال نمی‌شود. مدیرِ سایت باید از مسیرِ «فراز اس ام اس ← گرویتی‌فرم/المنتور» ابتدا «ساخت پترن کد تأیید» را بزند و آن را در پنلِ فراز تأیید کند.', 'farazsms' ),
		);
	}


	// v3.13.12 SECURITY FIX: Multi-tier rate-limit برای جلوگیری از spam vector.
	//
	// قبل: فقط ۶۰ ثانیه per-mobile cooldown. مهاجم می‌توانست ~۸۶۴k پیامک/روز
	// (با هزینه‌ی صاحب سایت) به شماره‌های دلخواه ایرانی بفرستد.
	//
	// حالا سه لایه:
	//  1. per-mobile progressive backoff: 60s → 300s → 900s
	//  2. per-IP daily cap: حداکثر 20 درخواست OTP در روز از یک IP
	//  3. global hourly cap: حداکثر 500 OTP در ساعت در کل سایت
	//
	// همه به‌صورت transient که به‌خوبی روی Redis/Memcached هم scale می‌شود.

	$rate_key      = 'farazsms_otp_sent_' . $mobile;
	$backoff_key   = 'farazsms_otp_backoff_' . $mobile;
	$backoff_level = (int) get_transient( $backoff_key );

	if ( get_transient( $rate_key ) ) {
		return array( 'success' => false, 'message' => __( 'لطفاً کمی صبر کنید و دوباره درخواست ارسال کد دهید.', 'farazsms' ) );
	}

	// لایه ۲: per-IP daily cap
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? preg_replace( '/[^0-9a-fA-F\.:]/', '', $_SERVER['REMOTE_ADDR'] ) : '';
	if ( $ip !== '' ) {
		$ip_key   = 'farazsms_otp_ip_' . md5( $ip );
		$ip_count = (int) get_transient( $ip_key );
		if ( $ip_count >= 20 ) {
			return array( 'success' => false, 'message' => __( 'تعداد درخواست از این آی‌پی زیاد است. فردا دوباره تلاش کنید.', 'farazsms' ) );
		}
		set_transient( $ip_key, $ip_count + 1, DAY_IN_SECONDS );
	}

	// لایه ۳: global hourly cap (محافظت از اعتبار پنل صاحب سایت)
	$global_key   = 'farazsms_otp_global_hour';
	$global_count = (int) get_transient( $global_key );
	if ( $global_count >= 500 ) {
		return array( 'success' => false, 'message' => __( 'سامانه موقتاً اشباع است. لطفاً دقایقی دیگر تلاش کنید.', 'farazsms' ) );
	}
	set_transient( $global_key, $global_count + 1, HOUR_IN_SECONDS );

	// 6-digit OTP from a CSPRNG (random_int) — 1,000,000 combinations, not predictable.
	$otp = str_pad( (string) random_int( 0, 999999 ), 6, '0', STR_PAD_LEFT );
	$transient_key = 'farazsms_otp_' . $mobile;
	// v3.21.27 (P4) امنیتی — شمارنده‌ی تلاشِ خطا را روی ارسالِ مجدد صفر نمی‌کنیم؛ وگرنه مهاجم
	// با هر resend دوباره ۵ تلاش می‌گیرد و قفلِ brute-force دور می‌خورد. فقط در تأییدِ موفق پاک می‌شود.
	set_transient( $transient_key, $otp, FARAZSMS_OTP_TRANSIENT_EXPIRY );

	// لایه ۱: progressive backoff per-mobile — هر بار طولانی‌تر می‌شود.
	$backoff_steps = array( 60, 300, 900, 3600 ); // 1m, 5m, 15m, 1h
	$next_idx      = min( $backoff_level, count( $backoff_steps ) - 1 );
	$cooldown      = $backoff_steps[ $next_idx ];
	set_transient( $rate_key, '1', $cooldown );
	set_transient( $backoff_key, $backoff_level + 1, DAY_IN_SECONDS );

	$sender = get_option( 'farazsms_sender', '' );
	$recipient = $mobile;
	$recipient = farazsms_normalize_phone( $mobile );
	// API expects attributes; pattern variable name is typically "code"
	$attributes = array( 'code' => $otp );
	$result = farazsms_send_pattern_sms_raw( $recipient, $pattern_code, $attributes, $sender );

	if ( $result === 'success' ) {
		return array( 'success' => true, 'message' => __( 'کد تأیید ارسال شد.', 'farazsms' ) );
	}

	// v3.22.36 (F1): «مبهم» فقط خطای ارتباطی/timeout (curl_error) است که ممکن است پیامک واقعاً
	// رفته باشد (زیرِ اینترنتِ ملی) و نباید کدِ رسیده را پاک کرد. بقیهٔ خطاها قطعی‌اند و پیامکی
	// نرفته:  api_error (ردِ پنل)، missing_params / missing_pattern (پترن/کلید تنظیم‌نشده)، یا
	// پاسخِ مبهم. قبلاً فقط api_error قطعی بود؛ در نتیجه پترنِ تنظیم‌نشده «موفقِ مبهم» می‌شد و
	// کاربر با فرمِ کدی که هرگز پیامکی برایش نمی‌آمد بن‌بستِ نامرئی می‌گرفت (+ سوختنِ بودجهٔ OTP).
	$is_ambiguous = is_string( $result ) && strpos( $result, 'curl_error:' ) === 0;

	if ( ! $is_ambiguous ) {
		delete_transient( $transient_key );
		delete_transient( $rate_key );
		// v3.21.27 (P5) امنیتی — شمارنده‌های IP/global که قبل از ارسال زیاد شده بودند را روی خطا برگردان
		// (وگرنه خطاهای ارسال، بودجه‌ی OTPِ کاربرانِ مجاز را می‌سوزانند).
		if ( isset( $ip_key ) ) { $c = (int) get_transient( $ip_key ); if ( $c > 0 ) { set_transient( $ip_key, $c - 1, DAY_IN_SECONDS ); } }
		$g = (int) get_transient( $global_key ); if ( $g > 0 ) { set_transient( $global_key, $g - 1, HOUR_IN_SECONDS ); }
		if ( $result === 'missing_params' || $result === 'missing_pattern' ) {
			$err = __( 'سرویسِ پیامک هنوز آماده نیست (پترنِ کد تأیید یا کلیدِ دسترسی تنظیم نشده). لطفاً با مدیرِ سایت تماس بگیرید.', 'farazsms' );
		} elseif ( is_string( $result ) && strpos( $result, 'api_error:' ) === 0 ) {
			$err = substr( $result, strlen( 'api_error:' ) );
		} else {
			$err = is_string( $result ) ? $result : __( 'خطا در ارسال پیامک.', 'farazsms' );
		}
		return array( 'success' => false, 'message' => $err );
	}

	// خطای ارتباطی/timeout: کد را نگه‌دار (پاک نکن) و فرمِ کد را باز کن.
	return array(
		'success'   => true,
		'ambiguous' => true,
		'message'   => __( 'اگر پیامکِ کد را دریافت کردید، همان را وارد کنید. (در صورتِ عدم دریافت، چند لحظه بعد دوباره «ارسال کد» بزنید.)', 'farazsms' ),
	);
}

/**
 * Verify OTP and set verified transient for form submission.
 *
 * @param string $mobile   Normalized mobile.
 * @param string $code     User-entered code.
 * @param string $context  'gf' or 'elementor'.
 * @param string $form_id  Form identifier (GF form id or Elementor form post id).
 * @return array { 'success' => bool, 'message' => string }
 */
function farazsms_otp_verify_code( $mobile, $code, $context, $form_id ) {
	// Brute-force lockout — after FARAZSMS_OTP_MAX_ATTEMPTS failures, refuse verify for the lockout window.
	$attempts_key = 'farazsms_otp_attempts_' . $mobile;
	$attempts     = (int) get_transient( $attempts_key );
	if ( $attempts >= FARAZSMS_OTP_MAX_ATTEMPTS ) {
		return array(
			'success' => false,
			'message' => __( 'تعداد تلاش‌های ناموفق زیاد است. لطفاً ۱۵ دقیقه دیگر مجدداً تلاش کنید.', 'farazsms' ),
		);
	}

	$transient_key = 'farazsms_otp_' . $mobile;
	$stored        = get_transient( $transient_key );
	if ( $stored === false || (string) $stored !== (string) $code ) {
		set_transient( $attempts_key, $attempts + 1, FARAZSMS_OTP_LOCKOUT_SECONDS );
		return array( 'success' => false, 'message' => __( 'کد وارد شده اشتباه یا منقضی است.', 'farazsms' ) );
	}

	delete_transient( $transient_key );
	delete_transient( $attempts_key );
	// v3.13.12: ریست کردن backoff progressive وقتی verify موفق است — تا کاربر صادق
	// دفعه بعد بدون cooldown طولانی بتواند درخواست بدهد.
	delete_transient( 'farazsms_otp_backoff_' . $mobile );

	$verified_key = 'farazsms_otp_verified_' . $context . '_' . $form_id . '_' . $mobile;
	set_transient( $verified_key, '1', FARAZSMS_OTP_VERIFIED_EXPIRY );
	// v3.22.107: کلیدِ مستقل از form_id — گِیتِ سمتِ‌سرورِ کانفیگ‌محورِ المنتور form_idِ JS را ندارد،
	// پس با این کلید (context + mobile) بدونِ وابستگی به form_id تأیید را می‌سنجد.
	set_transient( 'farazsms_otp_verified_' . $context . '__' . $mobile, '1', FARAZSMS_OTP_VERIFIED_EXPIRY );
	return array( 'success' => true, 'message' => __( 'شماره موبایل تأیید شد.', 'farazsms' ) );
}

/**
 * Check if mobile is verified for this form (used on form validation).
 *
 * @param string $context  'gf' or 'elementor'.
 * @param string $form_id  Form id.
 * @param string $mobile   Normalized mobile.
 * @return bool
 */
function farazsms_otp_is_verified( $context, $form_id, $mobile ) {
	$key = 'farazsms_otp_verified_' . $context . '_' . $form_id . '_' . $mobile;
	return get_transient( $key ) === '1';
}

/**
 * AJAX: send OTP to mobile.
 */
function farazsms_otp_ajax_send() {
	$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
	if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'farazsms_otp_send' ) ) {
		wp_send_json_error( array( 'message' => __( 'خطای امنیتی. لطفاً صفحه را رفرش کنید.', 'farazsms' ) ) );
		return;
	}
	$mobile = isset( $_POST['mobile'] ) ? sanitize_text_field( wp_unslash( $_POST['mobile'] ) ) : '';
	$mobile = farazsms_otp_normalize_mobile( $mobile );
	if ( empty( $mobile ) || strlen( $mobile ) < 10 ) {
		wp_send_json_error( array( 'message' => __( 'شماره موبایل معتبر وارد کنید.', 'farazsms' ) ) );
		return;
	}
	$result = farazsms_otp_send_code( $mobile );
	if ( $result['success'] ) {
		wp_send_json_success( array( 'message' => $result['message'] ) );
	} else {
		wp_send_json_error( array( 'message' => $result['message'] ) );
	}
}

/**
 * AJAX: verify OTP and set verified transient.
 */
function farazsms_otp_ajax_verify() {
	$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( $_POST['nonce'] ) : '';
	if ( empty( $nonce ) || ! wp_verify_nonce( $nonce, 'farazsms_otp_verify' ) ) {
		wp_send_json_error( array( 'message' => __( 'خطای امنیتی. لطفاً صفحه را رفرش کنید.', 'farazsms' ) ) );
		return;
	}
	$mobile   = isset( $_POST['mobile'] ) ? sanitize_text_field( wp_unslash( $_POST['mobile'] ) ) : '';
	$code     = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';
	$context  = isset( $_POST['context'] ) ? sanitize_text_field( $_POST['context'] ) : '';
	$form_id  = isset( $_POST['form_id'] ) ? sanitize_text_field( $_POST['form_id'] ) : '';

	$mobile = farazsms_otp_normalize_mobile( $mobile );
	if ( empty( $mobile ) || empty( $code ) || ! in_array( $context, array( 'gf', 'elementor' ), true ) ) {
		wp_send_json_error( array( 'message' => __( 'پارامترهای ارسالی ناقص است.', 'farazsms' ) ) );
		return;
	}

	$result = farazsms_otp_verify_code( $mobile, $code, $context, $form_id );
	if ( $result['success'] ) {
		wp_send_json_success( array( 'message' => $result['message'] ) );
	} else {
		wp_send_json_error( array( 'message' => $result['message'] ) );
	}
}

add_action( 'wp_ajax_farazsms_otp_send', 'farazsms_otp_ajax_send' );
add_action( 'wp_ajax_nopriv_farazsms_otp_send', 'farazsms_otp_ajax_send' );
add_action( 'wp_ajax_farazsms_otp_verify', 'farazsms_otp_ajax_verify' );
add_action( 'wp_ajax_nopriv_farazsms_otp_verify', 'farazsms_otp_ajax_verify' );
