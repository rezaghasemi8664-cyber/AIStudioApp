<?php
/**
 * صفِ ارسالِ غیرمسدودِ مشترک.
 *
 * چرا یکی شد: سه ماژولِ فازِ یکپارچه‌سازی (تیکت، فرم‌سازها، عضویت) هر کدام
 * نسخه‌ی کپی‌شده‌ی خودشان را داشتند. نتیجه‌اش این بود که رفعِ باگِ «سقفِ صف،
 * پیامک‌های ادعا‌شده را دور می‌ریزد» فقط در یکی از سه‌تا اعمال شد و دو تای دیگر
 * ساکت شکسته ماندند. هر تغییرِ بعدی هم باید سه‌بار انجام می‌شد.
 *
 * قرارداد:
 *
 *   farazsms_queue_send( $channel, $phone, $pattern, $vars, $context )
 *
 * ارسال هرگز روی درخواستی که کاربر منتظرش است انجام نمی‌شود. تا v3.22.197 این
 * تضمین فقط روی FPM/LiteSpeed برقرار بود: آن‌جا پاسخ با fastcgi_finish_request
 * بسته می‌شد، ولی روی mod_php — که این تابع را ندارد — همان کد ارسال را وسطِ
 * درخواست انجام می‌داد. یعنی «صف» روی نصفِ بازارِ هدف دقیقاً معادلِ ارسالِ
 * مستقیم بود.
 *
 * حالا تخلیه بر اساسِ **حالتِ درخواست** تصمیم می‌گیرد، نه بر اساسِ SAPI:
 *
 *   unattended  کرون / WP-CLI / اجراکننده‌ی خودِ صف — کسی منتظر نیست، بفرست.
 *   detachable  می‌توان پاسخ را بست — ببند و بعد بفرست (رفتارِ FPM، بدونِ تغییر).
 *   bounded     پیشخوان، وقتی کرون از سررسید گذشته — با سقفِ کوچک بفرست.
 *   blocked     درخواستی که کاربر منتظرش است و پاسخ بسته نمی‌شود — هیچ نفرست.
 *
 * در حالتِ blocked صف پارک می‌شود و یک اجراکننده زمان‌بندی می‌گردد (اول
 * Action Scheduler، بعد رویدادِ تک‌بارِ کرون). حالتِ bounded عمداً وجود دارد:
 * اگر کرون هم خراب باشد، تنها راهِ باقی‌مانده پیشخوان است و «هرگز نفرست»
 * آن‌جا یعنی گم‌شدنِ دائمی، نه تعویق.
 *
 * سقفِ هر درخواست، باقی‌مانده را نابود نمی‌کند — ذخیره می‌شود و در نوبتِ بعدی
 * می‌رود. این برای رویدادهایی که «ادعا»ی یک‌بارمصرف دارند حیاتی است: آن‌ها
 * هرگز دوباره ساخته نمی‌شوند.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/** سقفِ ارسال در یک درخواست — عملیاتِ گروهی نباید یک درخواست را بی‌انتها کند. */
const FARAZSMS_QUEUE_MAX_PER_REQUEST = 25;

/**
 * سقفِ حالتِ bounded — پیشخوانی که مجبور شده خودش اجراکننده باشد.
 *
 * کوچک است چون این تنها حالتی است که یک انسان منتظرِ پاسخ می‌ماند. سقفِ ۲۵
 * این‌جا یعنی صفحه‌ی پیشخوان می‌تواند دقیقه‌ها معطل بماند؛ عددِ کوچک یعنی
 * باقی‌مانده در چند بازدیدِ متوالی تخلیه می‌شود، نه در یکی.
 */
const FARAZSMS_QUEUE_MAX_PER_REQUEST_BOUNDED = 3;

/** سقفِ نگهداریِ باقی‌مانده — تا یک عملیاتِ غول‌آسا آپشن را باد نکند. */
const FARAZSMS_QUEUE_SPILL_MAX = 500;

/** آپشنِ باقی‌مانده (مشترک بینِ همه‌ی کانال‌ها). */
const FARAZSMS_QUEUE_SPILL_OPTION = 'farazsms_send_queue_spill';

/** لحظه‌ی اولین دیده‌شدنِ ردیف‌های بی‌مهرِ نسخه‌های قبل (اسکالر — بالا را ببینید). */
const FARAZSMS_QUEUE_SPILL_SEEN_OPTION = 'farazsms_send_queue_spill_seen_at';

/** رویدادِ کرانِ تخلیه‌ی باقی‌مانده. */
const FARAZSMS_QUEUE_DRAIN_HOOK = 'farazsms_send_queue_drain';

/** قفلِ کوتاهِ برداشتنِ باقی‌مانده (تا دو فرایند یک فهرست را دوبار نفرستند). */
const FARAZSMS_QUEUE_LOCK_OPTION = 'farazsms_send_queue_lock';

/**
 * پس از این مدت، پیشخوان کار را از اجراکننده پس می‌گیرد.
 *
 * ⚠️ چرا لازم است: «اجراکننده‌ای در انتظار است» با «اجراکننده‌ای که هرگز اجرا
 * نمی‌شود» از بیرون یکسان دیده می‌شود. اکشنِ asyncِ Action Scheduler زمان ندارد،
 * پس تنها تفاوتشان گذرِ زمان است. بدونِ این مهلت، یک اکشنِ گیرکرده کچ‌آپِ
 * پیشخوان — آخرین راهِ نجات روی هاستِ بدونِ کرون — را برای همیشه خاموش می‌کرد.
 */
const FARAZSMS_QUEUE_HANDOVER_AFTER = 900;

/** مهلتِ قفل — بعد از آن، قفلِ یتیم آزاد می‌شود. */
const FARAZSMS_QUEUE_LOCK_TTL = 120;

/**
 * تصمیمِ «این درخواست را می‌شود فرستاد یا نه» — منطقِ خالص.
 *
 * عمداً از هر سیگنالِ محیطی جدا است تا هر پنج ورودی در تست قابلِ ساخت باشند.
 * تابعِ خواهرش farazsms_queue_runner_mode فقط سیگنال‌ها را جمع می‌کند.
 *
 * ترتیب معنا دارد: «کسی منتظر نیست» بر همه‌چیز مقدم است، چون روی کرون حتی اگر
 * fastcgi_finish_request هم موجود باشد، بستنِ پاسخ بی‌معناست.
 *
 * @param bool $is_cron        کرونِ وردپرس در حالِ اجراست.
 * @param bool $is_cli         WP-CLI.
 * @param bool $is_runner_hook تخلیه از دلِ رویدادِ اجراکننده‌ی خودِ صف آمده.
 * @param bool $can_detach     پاسخ را می‌توان پیش از کارِ سنگین بست.
 * @param bool $is_catchup     کچ‌آپِ پیشخوان (کرون از سررسید گذشته) این را شروع کرده.
 * @return string unattended|detachable|bounded|blocked
 */
function farazsms_queue_decide_mode( $is_cron, $is_cli, $is_runner_hook, $can_detach, $is_catchup ) {
	if ( $is_cron || $is_cli || $is_runner_hook ) {
		return 'unattended';
	}
	if ( $can_detach ) {
		return 'detachable';
	}
	if ( $is_catchup ) {
		return 'bounded';
	}
	return 'blocked';
}

/**
 * سقفِ ارسالِ هر حالت.
 *
 * @param string $mode
 * @return int صفر یعنی «روی این درخواست هیچ ارسالی نکن».
 */
function farazsms_queue_cap_for_mode( $mode ) {
	if ( $mode === 'unattended' || $mode === 'detachable' ) {
		return FARAZSMS_QUEUE_MAX_PER_REQUEST;
	}
	if ( $mode === 'bounded' ) {
		return FARAZSMS_QUEUE_MAX_PER_REQUEST_BOUNDED;
	}
	// ⚠️ فهرست عمداً «مجازها» را می‌شمارد نه «ممنوع‌ها». با شمردنِ ممنوع‌ها،
	// هر رشته‌ی ناشناخته (فیلترِ شخص ثالث، غلطِ تایپی) به سقفِ کاملِ ۲۵ و
	// پرشِ بستنِ پاسخ می‌رسید — یعنی بازترین رفتار برای ناشناخته‌ترین ورودی.
	return 0;
}

/**
 * پرچمِ «این تخلیه را کچ‌آپِ پیشخوان شروع کرده».
 *
 * @param bool|null $set null = فقط خواندن.
 * @return bool
 */
function farazsms_queue_catchup_flag( $set = null ) {
	static $flag = false;
	if ( $set !== null ) {
		$flag = (bool) $set;
	}
	return $flag;
}

/**
 * حالتِ درخواستِ جاری.
 *
 * درزِ تزریق (فیلتر) به همان دلیلِ farazsms_queue_sender وجود دارد: بدونِ آن،
 * سه شاخه از چهار شاخه‌ی تخلیه زیرِ PHPUnit اجراناپذیرند چون به وجود/نبودِ
 * توابعِ SAPI و به ثابت‌های تعریف‌شده وابسته‌اند و هیچ‌کدام در یک پروسه
 * برگشت‌پذیر نیستند.
 *
 * @return string
 */
function farazsms_queue_runner_mode() {
	$mode = farazsms_queue_decide_mode(
		( defined( 'DOING_CRON' ) && DOING_CRON ) || ( function_exists( 'wp_doing_cron' ) && wp_doing_cron() ),
		defined( 'WP_CLI' ) && WP_CLI,
		function_exists( 'doing_action' ) && doing_action( FARAZSMS_QUEUE_DRAIN_HOOK ),
		function_exists( 'fastcgi_finish_request' ) || function_exists( 'litespeed_finish_request' ),
		farazsms_queue_catchup_flag()
	);
	return (string) apply_filters( 'farazsms_queue_runner_mode', $mode );
}

/**
 * زمان‌بندیِ اجراکننده‌ی صف — نردبانِ ترابر، بدونِ پله‌ی همگام.
 *
 * ۱) Action Scheduler: کارگرِ مستقل، بی‌نیاز از کرونِ وردپرس.
 * ۲) رویدادِ تک‌بارِ کرون: روی هسته همیشه هست؛ وردپرس اجراکننده را با یک
 *    درخواستِ لوپ‌بکِ غیرمنتظر صدا می‌زند، پس درخواستِ فعلی معطل نمی‌ماند.
 *
 * هوک آرگومان نمی‌گیرد و کار در آپشنِ باقی‌مانده است، پس حذفِ رویدادِ تکراری
 * توسطِ وردپرس اینجا مطلوب است نه مضر.
 *
 * تنها نقطه‌ی زمان‌بندیِ اجراکننده در کلِ ماژول است — پارک و تخلیه هر دو از
 * همین رد می‌شوند، تا دو مسیرِ موازیِ زمان‌بندی ساخته نشود.
 *
 * @param int $delay ثانیه؛ صفر = در اولین فرصت.
 * @return bool اجراکننده‌ای زمان‌بندی شد؟
 */
function farazsms_queue_schedule_runner( $delay = 0 ) {
	$delay  = max( 0, (int) $delay );
	$target = time() + $delay;
	$next   = farazsms_queue_runner_next();

	// ⚠️ «اجراکننده‌ای هست» کافی نیست؛ باید **زودتر از سررسیدِ درخواستی** باشد.
	// وگرنه یک رویدادِ ۶۰ثانیه‌ایِ پارک، درخواستِ «بی‌درنگ»ِ حالتِ blocked را
	// بی‌صدا می‌بلعید و هر پیامکِ mod_php یک دقیقه دیر می‌رفت.
	if ( $next === true ) {
		return true; // اکشنِ بی‌درنگ از هر سررسیدی زودتر است.
	}
	if ( is_int( $next ) && $next <= $target ) {
		return true;
	}

	if ( farazsms_queue_as_available() ) {
		if ( $delay === 0 ) {
			as_enqueue_async_action( FARAZSMS_QUEUE_DRAIN_HOOK, array(), 'farazsms' );
		} else {
			as_schedule_single_action( $target, FARAZSMS_QUEUE_DRAIN_HOOK, array(), 'farazsms' );
		}
		return true;
	}

	// رویدادِ دیرترِ کرون جای خود را به سررسیدِ زودتر می‌دهد.
	$cron_next = wp_next_scheduled( FARAZSMS_QUEUE_DRAIN_HOOK );
	if ( $cron_next ) {
		wp_unschedule_event( $cron_next, FARAZSMS_QUEUE_DRAIN_HOOK );
	}
	return (bool) wp_schedule_single_event( $target, FARAZSMS_QUEUE_DRAIN_HOOK );
}

/**
 * آیا Action Scheduler کاملاً در دسترس است؟
 *
 * ⚠️ فیلتر فقط می‌تواند در دسترس‌بودن را **رد** کند، نه جعل: با true گرفتنِ آن
 * روی سایتِ بدونِ ووکامرس، فراخوانیِ as_enqueue_async_action خطای مرگبار
 * می‌دهد. درزِ تزریق لازم است چون زیرِ تست این توابع همیشه تعریف‌شده‌اند و
 * بدونِ آن، شاخه‌ی «سایتِ بدونِ زمان‌بند» اصلاً اجراناپذیر است.
 */
function farazsms_queue_as_available() {
	return function_exists( 'as_next_scheduled_action' )
		&& function_exists( 'as_enqueue_async_action' )
		&& function_exists( 'as_schedule_single_action' )
		&& (bool) apply_filters( 'farazsms_queue_scheduler_available', true );
}

/**
 * لحظه‌ای که پیشخوان برای اولین بار ردیفِ بی‌مهر را دید.
 *
 * ⚠️ ردیفِ نسخه‌ی قبل سنِ نامعلوم دارد و هر عددِ ثابتی برایش یک شکستِ دائمی
 * می‌سازد: عددِ بزرگ یعنی پیشخوان همیشه کار را از اجراکننده‌ی سالم پس می‌گیرد،
 * عددِ کوچک یعنی اگر اجراکننده خودش گیر کرده باشد آن ردیف **هرگز** تخلیه
 * نمی‌شود. هر دو حالت در بازبینی‌های همین فاز گزارش شدند.
 *
 * ⚠️ و چرا یک آپشنِ **اسکالر** به‌جای مهرزدنِ خودِ ردیف‌ها: نوشتنِ دوباره‌ی کلِ
 * فهرست از روی یک عکسِ قدیمی، بدونِ قفل، مسابقه می‌سازد — اگر در همان لحظه
 * درخواستِ دیگری کاری پارک کرده باشد، آن کار نابود می‌شود؛ و اگر تخلیه‌کننده
 * فهرست را پاک کرده باشد، کارِ رفته دوباره زنده می‌شود (پیامکِ تکراری).
 * قراردادِ این ماژول «باقی‌مانده نابود نمی‌شود» است؛ یک نوشتنِ تک‌مقداری و
 * idempotent آن را نمی‌شکند.
 *
 * @param int $now
 * @return int لحظه‌ی اولین دیده‌شدن (اگر تازه ثبت شود، همین حالا).
 */
function farazsms_queue_spill_seen_at( $now ) {
	$seen = (int) get_option( FARAZSMS_QUEUE_SPILL_SEEN_OPTION, 0 );
	if ( $seen <= 0 ) {
		$seen = (int) $now;
		update_option( FARAZSMS_QUEUE_SPILL_SEEN_OPTION, $seen, false );
	}
	return $seen;
}

/**
 * سنِ قدیمی‌ترین کارِ پارک‌شده، به ثانیه.
 *
 * ردیفِ نسخه‌ی قبل مهرِ زمان ندارد؛ کمی **زیرِ** مهلتِ تحویل شمرده می‌شود —
 * یعنی اگر اجراکننده‌ای در راه است همان تخلیه‌اش کند، و اگر نیست، پیشخوان.
 *
 * @param array $spill
 * @param int   $now
 * @param int   $legacy_seen_at لحظه‌ی اولین دیده‌شدنِ ردیف‌های بی‌مهر؛ ۰ = نامعلوم.
 * @return int
 */
function farazsms_queue_spill_age( $spill, $now, $legacy_seen_at = 0 ) {
	$oldest = 0;
	foreach ( (array) $spill as $job ) {
		if ( ! is_array( $job ) || empty( $job['queued_at'] ) ) {
			// سنِ ردیفِ بی‌مهر از لحظه‌ی اولین دیده‌شدنش شمرده می‌شود.
			if ( (int) $legacy_seen_at > 0 ) {
				$oldest = max( $oldest, (int) $now - (int) $legacy_seen_at );
				continue;
			}
			// بدونِ مرجعِ زمانی (فراخوانیِ خالصِ تست): تازه شمرده می‌شود، تا
			// تصمیم به اجراکننده‌ی در راه واگذار شود.
			$oldest = max( $oldest, FARAZSMS_QUEUE_HANDOVER_AFTER - 1 );
			continue;
		}
		$age = $now - (int) $job['queued_at'];
		if ( $age > $oldest ) {
			$oldest = $age;
		}
	}
	return $oldest;
}

/**
 * سررسیدِ اجراکننده‌ی بعدی — از **هر دو** ترابر.
 *
 * ⚠️ چرا یک تابعِ واحد: کچ‌آپِ پیشخوان فقط کرونِ وردپرس را می‌سنجید. از وقتی
 * زمان‌بندی Action Scheduler را ترجیح می‌دهد، روی هر سایتِ ووکامرسی آن پرسش
 * همیشه «هیچ اجراکننده‌ای نیست» جواب می‌داد — یعنی کچ‌آپ روی **هر** بازدیدِ
 * پیشخوان فعال می‌شد و ارسالِ همگام را دقیقاً به جایی برمی‌گرداند که این فاز
 * از آن‌جا حذفش کرده بود.
 *
 * ⚠️ سه‌حالته است، نه دوحالته: اکشنِ asyncِ Action Scheduler زمان ندارد ولی
 * «سالم و قریب‌الوقوع» است. اگر آن را عددِ صفر بدهیم، هر سنجشِ «سررسیدش
 * گذشته؟» آن را «عقب‌افتاده» می‌بیند و پیشخوان بی‌دلیل اجراکننده می‌شود.
 *
 * @return true|int|false true = اکشنِ بی‌درنگِ در انتظار؛ int = زمانِ یونیکس؛
 *                        false = هیچ اجراکننده‌ای نیست.
 */
function farazsms_queue_runner_next() {
	if ( farazsms_queue_as_available() ) {
		$as = as_next_scheduled_action( FARAZSMS_QUEUE_DRAIN_HOOK, null, 'farazsms' );
		if ( $as === true ) {
			return true;
		}
		if ( is_int( $as ) && $as > 0 ) {
			return $as;
		}
	}
	$cron = wp_next_scheduled( FARAZSMS_QUEUE_DRAIN_HOOK );
	return $cron ? (int) $cron : false;
}

/**
 * آیا این ردیفِ صف سالم است؟
 *
 * ⚠️ کلیدهای آرایه‌ای هم باید بررسی شوند، نه فقط رشته‌ای‌ها: حلقه‌ی تخلیه
 * پیش از try/catch مقدارِ context را در array_merge می‌ریزد و vars را به تابعِ
 * ارسال می‌دهد. ردیفِ ناقص (نسخه‌ی قدیمیِ آپشن یا دادهٔ خراب — دقیقاً همان
 * چیزی که این گارد برایش نوشته شده) یک TypeErrorِ مهارنشده در shutdown می‌داد،
 * آن هم بعد از حذفِ آپشن، یعنی نابودیِ کلِ باقی‌مانده.
 *
 * @param mixed $job
 * @return bool
 */
function farazsms_queue_job_is_valid( $job ) {
	if ( ! is_array( $job ) || empty( $job['channel'] ) ) {
		return false;
	}
	if ( ! isset( $job['context'] ) || ! is_array( $job['context'] ) ) {
		return false;
	}
	// ردیف‌های پارک‌شده‌ی پیش از v3.22.198 کلیدِ kind ندارند و همه ارسالِ پترن‌اند.
	if ( farazsms_queue_job_kind( $job ) === 'task' ) {
		return ! empty( $job['callback'] )
			&& farazsms_queue_callback_is_ours( $job['callback'] )
			&& isset( $job['args'] ) && is_array( $job['args'] );
	}
	return ! empty( $job['phone'] )
		&& ! empty( $job['pattern'] )
		&& isset( $job['vars'] ) && is_array( $job['vars'] );
}

/**
 * آیا این نامِ کارگر از خودِ افزونه است؟
 *
 * ⚠️ چرا اجازه‌نامه و نه فقط is_callable: باقی‌مانده‌ی صف در یک آپشن سریال
 * می‌شود، پس هر نوشتنِ ناخواسته روی wp_options (تزریقِ SQL در جای دیگر، یا
 * افزونه‌ای که update_option را به نقشِ کم‌دسترسی می‌دهد) می‌توانست ردیفی با
 * callback = هر تابعِ PHP بسازد و تخلیه‌ی بعدی آن را با آرگومانِ دلخواه اجرا
 * کند. is_callable چنین ردیفی را تأیید می‌کرد. همه‌ی ۲۲ فراخوانیِ واقعی
 * رشته‌ی ثابت‌اند و در این سه فضای نام می‌گنجند، پس هزینه‌ی این گارد صفر است
 * و در همان نقطه‌ای می‌نشیند که هر ردیف — چه از حافظه چه از آپشن — از آن رد
 * می‌شود.
 *
 * @param mixed $callback
 * @return bool
 */
function farazsms_queue_callback_is_ours( $callback ) {
	if ( ! is_string( $callback ) ) {
		return false;
	}
	// نامِ تابع در PHP بی‌توجه به بزرگی/کوچکی حروف است، پس مقایسه هم باید باشد.
	$callback = ltrim( trim( $callback ), '\\' );
	foreach ( array( 'farazsms_', 'fwss_', 'FarazSMS\\' ) as $prefix ) {
		if ( strncasecmp( $callback, $prefix, strlen( $prefix ) ) === 0 ) {
			return true;
		}
	}
	return false;
}

/**
 * نوعِ کار. نبودنِ کلید = ارسالِ پترن (ردیفِ نسخه‌ی قبل).
 *
 * @param array $job
 * @return string pattern|task
 */
function farazsms_queue_job_kind( $job ) {
	return ( isset( $job['kind'] ) && $job['kind'] === 'task' ) ? 'task' : 'pattern';
}

/**
 * ادعای اتمیکِ قفل.
 *
 * ⚠️ چرا مستقیم روی جدولِ آپشن‌ها: تابعِ افزودنِ آپشنِ وردپرس اتمیک **نیست** —
 * اول با کشِ notoptions وجود را می‌سنجد و بعد یک INSERT با ON DUPLICATE KEY
 * UPDATE می‌زند. دو فرایندِ هم‌زمان می‌توانند هر دو موفق شوند، و با آبجکت‌کشِ
 * ماندگار پنجره بازتر هم می‌شود. INSERT IGNORE روی کلیدِ یکتای option_name
 * تنها راهی است که واقعاً یک برنده دارد.
 *
 * @return bool قفل گرفته شد؟
 */
function farazsms_queue_lock_acquire() {
	global $wpdb;
	if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'query' ) ) {
		return false;
	}
	// قفلِ یتیم (فرایندِ قبلی وسطِ کار مرده) پس از مهلت آزاد می‌شود.
	$wpdb->query( $wpdb->prepare(
		"DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value < %d",
		FARAZSMS_QUEUE_LOCK_OPTION,
		time() - FARAZSMS_QUEUE_LOCK_TTL
	) );
	$wpdb->query( $wpdb->prepare(
		"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
		FARAZSMS_QUEUE_LOCK_OPTION,
		(string) time()
	) );
	$acquired = ( (int) $wpdb->rows_affected === 1 );
	if ( $acquired && function_exists( 'wp_cache_delete' ) ) {
		// کشِ آپشن‌ها از این نوشتنِ مستقیم بی‌خبر است.
		wp_cache_delete( FARAZSMS_QUEUE_LOCK_OPTION, 'options' );
		wp_cache_delete( 'notoptions', 'options' );
	}
	return $acquired;
}

/**
 * آزادسازیِ قفل.
 *
 * @return void
 */
function farazsms_queue_lock_release() {
	global $wpdb;
	if ( isset( $wpdb ) && is_object( $wpdb ) && method_exists( $wpdb, 'query' ) ) {
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name = %s",
			FARAZSMS_QUEUE_LOCK_OPTION
		) );
	}
	if ( function_exists( 'wp_cache_delete' ) ) {
		wp_cache_delete( FARAZSMS_QUEUE_LOCK_OPTION, 'options' );
		wp_cache_delete( 'notoptions', 'options' );
	}
}

/**
 * تابعی که واقعاً پیامک می‌فرستد.
 *
 * درزِ تزریق: بدونِ این، تخلیه هیچ‌وقت قابلِ تست نبود — تابعِ ارسالِ واقعی همیشه
 * تعریف‌شده است و هارنس راهی برای جایگزینی‌اش نداشت. کدریویو نشان داد همین
 * باعث شده بود ده رفع از دوازده رفعِ این ماژول هیچ شبکه‌ی ایمنی نداشته باشند.
 *
 * @return callable|null
 */
function farazsms_queue_sender() {
	$fn = apply_filters( 'farazsms_queue_sender', 'farazsms_send_pattern_sms_raw' );
	return is_callable( $fn ) ? $fn : null;
}

/**
 * صفِ درون‌حافظه‌ای.
 *
 * @return array
 */
function &farazsms_queue_ref() {
	static $queue = array();
	return $queue;
}

/**
 * افزودنِ یک ارسال به صف.
 *
 * @param string $channel نامِ ماژول (در لاگِ تشخیص به‌عنوان source دیده می‌شود)
 * @param string $phone
 * @param string $pattern کدپترن
 * @param array  $vars    متغیرهای پترن
 * @param array  $context دادهٔ کمکیِ لاگ (مثلاً event یا form_id)
 * @param string $sender  خطِ ارسال؛ خالی = خطِ کانونی. **باید** پر شود برای
 *                        پیام‌های تبلیغاتی، وگرنه از خطِ خدماتی می‌روند.
 * @return bool افزوده شد؟
 */
function farazsms_queue_send( $channel, $phone, $pattern, $vars = array(), $context = array(), $sender = '' ) {
	$channel = (string) $channel;
	$phone   = trim( (string) $phone );
	$pattern = trim( (string) $pattern );
	if ( $channel === '' || $phone === '' || $pattern === '' ) {
		return false;
	}

	// ⚠️ اعتبارسنجی جایش همین‌جاست، نه در تک‌تکِ مصرف‌کننده‌ها. اگر «نقطه‌ی واحد»
	// باشیم ولی گارد نداشته باشیم، هر کانالی که یادش برود شماره‌ی نامعتبر را وارد
	// صف می‌کند: هم سهمیه‌ی هر درخواست را می‌سوزاند، هم اعتبارِ پنل را.
	if ( ! farazsms_is_mobile( $phone ) ) {
		farazsms_send_diag_log( $phone, $pattern, 'invalid_mobile', array(
			'source' => $channel,
			'detail' => 'recipient rejected before queue',
		) );
		return false;
	}

	$queue   =& farazsms_queue_ref();
	$queue[] = array(
		'queued_at' => time(),
		'kind'    => 'pattern',
		'channel' => $channel,
		'phone'   => $phone,
		'pattern' => $pattern,
		'vars'    => is_array( $vars ) ? $vars : array(),
		'context' => is_array( $context ) ? $context : array(),
		// آرگومانِ صریح فقط برای خطِ سفارشیِ مدیر است (مثلِ فرم‌سازها)؛ در نبودش
		// خطِ کانالی از فهرستِ واحد می‌آید.
		'sender'  => trim( (string) $sender ) !== '' ? trim( (string) $sender ) : farazsms_queue_channel_sender( $channel ),
	);

	farazsms_queue_register_flush();
	return true;
}

/**
 * کانال‌هایی که پیامشان تبلیغاتی/ترویجی است و باید از خطِ تبلیغات بروند.
 *
 * ⚠️ دامنه‌ی این فهرست **فقط کانال‌های صف** است، نه کلِ افزونه.
 *
 * پیش از این هر نقطه‌ی ارسالِ صف‌شده خودش farazsms_get_ad_sender() را صدا
 * می‌زد و پاس می‌داد؛ حذفِ آن آرگومان در هر کدام، پیامِ تبلیغاتی را بی‌صدا
 * روی خطِ خدماتی می‌فرستاد. حالا برای کانال‌های صف یک فهرست است.
 *
 * مسیرهایی که مستقیم می‌فرستند (سفر، یادآورِ لیدمگنت، تولد، سبدِ رهاشده و…)
 * از صف رد نمی‌شوند و خطشان را خودشان با farazsms_get_ad_sender() می‌گیرند.
 * نسخه‌ی قبلیِ این فهرست نامشان را داشت و ادعای پوششی می‌کرد که وجود نداشت —
 * هیچ تولیدکننده‌ای آن کانال‌ها را وارد صف نمی‌کند. در اپیکِ ۱۷ ثبت شده است.
 *
 * @return string[]
 */
function farazsms_queue_promotional_channels() {
	return (array) apply_filters( 'farazsms_queue_promotional_channels', array(
		'newsletter',
		'spin-wheel',
		'wallet-topup',
	) );
}

/**
 * خطِ ارسالِ پیش‌فرضِ یک کانال.
 *
 * @param string $channel
 * @return string خالی = خطِ کانونی.
 */
function farazsms_queue_channel_sender( $channel ) {
	if ( in_array( (string) $channel, farazsms_queue_promotional_channels(), true )
		&& function_exists( 'farazsms_get_ad_sender' ) ) {
		return (string) farazsms_get_ad_sender();
	}
	return '';
}

/**
 * افزودنِ یک «کار» به همان صف.
 *
 * چرا لازم شد: بخشی از هزینه‌ی مسیرهای مسدودکننده خودِ ارسال نیست. مسیرِ
 * دیدگاه پیش از ارسال یک تماس با کوتاه‌کننده دارد و مسیرِ سفارش کلِ
 * جای‌گذاریِ متغیرها را. اگر فقط ارسال به تعویق بیفتد، نیمی از هزینه روی
 * درخواستِ کاربر می‌ماند.
 *
 * صفِ دومی ساخته نمی‌شود: همان spill، همان قفل، همان اجراکننده و همان
 * حالت‌های اجرا. فقط نوعِ ردیف فرق می‌کند.
 *
 * $callback باید تابعِ نام‌دار باشد و $args فقط داده‌ی قابلِ سریال‌سازی —
 * باقی‌مانده در یک آپشن ذخیره می‌شود و closure از آن جان به‌در نمی‌برد.
 *
 * @param string $channel
 * @param string $callback نامِ تابع.
 * @param array  $args     آرگومان‌های positional.
 * @param array  $context  دادهٔ کمکیِ لاگ.
 * @return bool
 */
function farazsms_queue_task( $channel, $callback, $args = array(), $context = array() ) {
	$channel  = (string) $channel;
	$callback = is_string( $callback ) ? trim( $callback ) : '';
	if ( $channel === '' || $callback === '' ) {
		return false;
	}
	// نامِ غلط یا تابعِ حذف‌شده باید همین‌جا صدا کند، نه بعد از رفت‌وبرگشتِ آپشن
	// و در قالبِ یک ردیفِ لاگ که کسی نمی‌بیند.
	if ( ! is_callable( $callback ) || ! farazsms_queue_callback_is_ours( $callback ) ) {
		$why = is_callable( $callback ) ? 'foreign_task: ' : 'uncallable_task: ';
		farazsms_send_diag_log( '', '', $why . $callback, array( 'source' => $channel ) );
		return false;
	}

	$queue   =& farazsms_queue_ref();
	$queue[] = array(
		'queued_at' => time(),
		'kind'     => 'task',
		'channel'  => $channel,
		'callback' => $callback,
		'args'     => is_array( $args ) ? array_values( $args ) : array(),
		'context'  => is_array( $context ) ? $context : array(),
	);

	farazsms_queue_register_flush();
	return true;
}

/**
 * ثبتِ یک‌بارهٔ هوکِ shutdown.
 *
 * اولویت ۱۰۰: بعد از wp_ob_end_flush_all، تا بافرِ خروجی خالی شده باشد.
 */
function farazsms_queue_register_flush() {
	// لچِ static حذف شد: افزودنِ یک تابعِ نام‌دار روی همان اولویت در وردپرس
	// خودش یکتا است (شناسه‌ی یکتای فیلتر از نامِ تابع ساخته می‌شود)، پس لچ
	// چیزی جز پنهان‌کردنِ ثبت از دیدِ تست اضافه نمی‌کرد — و حذفِ خودِ ثبت را
	// غیرقابلِ‌تشخیص می‌کرد.
	add_action( 'shutdown', 'farazsms_queue_flush', 100 );
}

/**
 * بستنِ پاسخ و سپس خالی‌کردنِ صف.
 *
 * هر ارسال در try/catchِ جدا است تا یک خطا نه بقیه‌ی صف را بیندازد و نه کارِ
 * shutdownِ سایرِ افزونه‌ها را.
 */
function farazsms_queue_flush() {
	$mode = farazsms_queue_runner_mode();
	$cap  = farazsms_queue_cap_for_mode( $mode );

	$queue =& farazsms_queue_ref();

	// درخواستی که کاربر منتظرش است و پاسخش بسته نمی‌شود (mod_php): هیچ ارسالی
	// اینجا انجام نمی‌شود. کار پارک می‌شود و اجراکننده زمان‌بندی می‌گردد.
	if ( $cap <= 0 ) {
		// ترتیب مهم است: اجراکننده‌ی بی‌درنگ اول ثبت شود تا پارک رویدادِ
		// تأخیردارِ خودش را روی آن اضافه نکند.
		farazsms_queue_schedule_runner( 0 );
		// بدهیِ پذیرفته‌شده (پیش از این تغییر هم بود): پارک یک خواندن-ادغام-نوشتنِ
		// آپشن است و اتمیک نیست، پس دو درخواستِ هم‌زمان می‌توانند کارِ هم را
		// بازنویسی کنند. قفلِ ماژول اینجا **عمداً** گرفته نمی‌شود: گرفتنش بدونِ
		// انصراف در صورتِ شکست هیچ‌چیز را جدا نمی‌کند (قفلِ تزئینی)، و انتظار برای
		// قفل روی درخواستِ بازدیدکننده دقیقاً همان معطلی‌ای است که این فاز حذفش کرد.
		farazsms_queue_park( $queue );
		return;
	}

	if ( $mode === 'detachable' ) {
		if ( function_exists( 'fastcgi_finish_request' ) ) {
			@fastcgi_finish_request();
		} elseif ( function_exists( 'litespeed_finish_request' ) ) {
			@litespeed_finish_request();
		}
	}
	// بدونِ این، اجرا وسطِ کار کشته می‌شد و نیمی از پیامک‌ها بی‌صدا نمی‌رفت.
	@ignore_user_abort( true );

	// ⚠️ خروج پیش از «پارک» ممنوع: کارهای درون‌حافظه هنوز ذخیره نشده‌اند و
	// «ادعا»ی یک‌بارمصرفشان از قبل مصرف شده — یعنی رها کردنشان یعنی گم‌شدنِ
	// دائمی، نه تعویق.
	$send = farazsms_queue_sender();
	if ( $send === null ) {
		farazsms_queue_park( $queue );
		return;
	}

	// باقی‌ماندهٔ درخواستِ قبلی، اول از همه — پشتِ قفلِ واقعاً اتمیک.
	$locked = farazsms_queue_lock_acquire();
	if ( $locked ) {
		$spill = get_option( FARAZSMS_QUEUE_SPILL_OPTION, array() );
		if ( is_array( $spill ) && ! empty( $spill ) ) {
			delete_option( FARAZSMS_QUEUE_SPILL_OPTION );
			$queue = array_merge( $spill, $queue );
		}
	}

	// ردیفِ ناقص (نسخه‌ی قدیمیِ آپشن یا دادهٔ خراب) نباید در shutdown خطای مرگبار
	// بدهد — آن هم بعد از اینکه آپشن پاک شده و کلِ باقی‌مانده فقط در حافظه است.
	$before_filter = count( $queue );
	$queue         = array_values( array_filter( $queue, 'farazsms_queue_job_is_valid' ) );
	$invalid       = $before_filter - count( $queue );
	if ( $invalid > 0 ) {
		// در ماژولی که شعارش «باقی‌مانده نابود نمی‌شود» است، حذفِ بی‌صدا ممنوع.
		farazsms_send_diag_log( '', '', 'dropped_invalid=' . $invalid, array( 'source' => 'send-queue' ) );
	}

	$default_sender = farazsms_cfg_sender();
	$done           = 0;

	while ( ! empty( $queue ) && $done < $cap ) {
		$job = array_shift( $queue );
		$done++;
		$log = array_merge( array( 'source' => $job['channel'] ), $job['context'] );

		if ( farazsms_queue_job_kind( $job ) === 'task' ) {
			try {
				if ( is_callable( $job['callback'] ) ) {
					// از همان farazsms_async_call رد می‌شود تا دو قراردادِ متفاوتِ
					// آرگومان (لیستی/انجمنی) در افزونه وجود نداشته باشد — رفعِ PHP 8
					// آن‌جا زندگی می‌کند و نباید دوباره نوشته شود.
					farazsms_async_call( $job['callback'], $job['args'] );
				} else {
					// کارِ ناشناخته (پارک‌شده پیش از حذف/تغییرِ نامِ تابع) بی‌صدا رد نشود.
					// ⚠️ رشته‌ی نتیجه خودش در ستونِ خطا می‌نشیند؛ اگر 'failed' بدهیم،
					// detail هرگز خوانده نمی‌شود و فقط کلمه‌ی «failed» ثبت می‌گردد.
					farazsms_send_diag_log( '', '', 'uncallable_task: ' . $job['callback'], $log );
				}
			} catch ( \Throwable $e ) {
				farazsms_send_diag_log( '', '', 'exception: ' . $job['callback'] . ': ' . $e->getMessage(), $log );
			}
			continue;
		}

		// ⚠️ خطِ هر کار جدا است. پیش از v3.22.198 همه‌ی کارها روی خطِ کانونی
		// می‌رفتند؛ با ورودِ کانال‌های تبلیغاتی به صف، آن یعنی رفتنِ پیامِ
		// تبلیغاتی روی خطِ خدماتی. ردیف‌های پارک‌شده‌ی نسخه‌ی قبل این کلید را
		// ندارند، پس نبودنش = خطِ کانونی (همان رفتارِ قبلی).
		$job_sender = isset( $job['sender'] ) && trim( (string) $job['sender'] ) !== ''
			? trim( (string) $job['sender'] )
			: $default_sender;
		try {
			$res = call_user_func( $send, $job['phone'], $job['pattern'], $job['vars'], $job_sender );
			if ( $res !== 'success' ) {
				// امضای واقعی: ( گیرنده، کدپترن، نتیجه، context )
				farazsms_send_diag_log(
					$job['phone'],
					$job['pattern'],
					is_string( $res ) && $res !== '' ? $res : 'failed',
					$log
				);
			}
		} catch ( \Throwable $e ) {
			// ⚠️ کلیدِ error در contextِ لاگ خوانده نمی‌شود؛ متنِ استثنا باید در
			// detail برود وگرنه فقط کلمه‌ی «exception» ثبت می‌شد و دلیلِ واقعی
			// برای همیشه گم می‌شد.
			farazsms_send_diag_log( $job['phone'], $job['pattern'], 'exception', array_merge( $log, array(
				'detail' => $e->getMessage(),
			) ) );
		}
	}

	// پارک **داخلِ** همان قفل انجام می‌شود: خواندن-تغییر-نوشتنِ آپشن بدونِ قفل،
	// همان رقابتی است که این رفع قرار بود ببندد (فرایندِ دیگر می‌توانست فهرستِ
	// در حالِ ارسال را دوباره زنده کند یا کارهای پارک‌شده را نابود کند).
	farazsms_queue_park( $queue );

	// اگر هنوز باقی‌مانده‌ای هست ولی هیچ رویدادی زمان‌بندی نشده (مثلاً کچ‌آپ
	// رویداد را حذف کرده و این اجرا قفل را نگرفته)، یکی زمان‌بندی می‌کنیم —
	// وگرنه باقی‌مانده تا بازدیدِ بعدیِ ادمین معلق می‌ماند.
	$left = get_option( FARAZSMS_QUEUE_SPILL_OPTION, array() );
	if ( is_array( $left ) && ! empty( $left ) ) {
		farazsms_queue_schedule_runner( 60 );
	}

	if ( $locked ) {
		farazsms_queue_lock_release();
	}
}

/**
 * نگه‌داشتنِ باقی‌مانده برای نوبتِ بعد.
 *
 * پیش از این، باقی‌ماندهٔ صف با پایانِ درخواست بی‌صدا از بین می‌رفت — و چون
 * رویدادها متایِ «ادعا»ی یک‌بارمصرف داشتند، هرگز تلاشِ دوباره نمی‌شدند.
 *
 * @param array $queue ارجاع به صف
 */
function farazsms_queue_park( &$queue ) {
	if ( empty( $queue ) ) {
		return;
	}

	// ⚠️ ادغام، نه جای‌گزینی: اگر درخواستِ دیگری هم‌زمان چیزی پارک کرده باشد،
	// نوشتنِ مستقیم آن را نابود می‌کرد.
	$existing = get_option( FARAZSMS_QUEUE_SPILL_OPTION, array() );
	$all      = array_merge( is_array( $existing ) ? $existing : array(), $queue );
	$queue    = array();

	// ⚠️ v3.22.202: تازه‌ترین‌ها نگه داشته می‌شوند، نه قدیمی‌ترین‌ها.
	// با بریدنِ انتها، ردیف‌های انباشته‌ی قدیمی صدرِ باقی‌مانده را می‌گرفتند و
	// پیامکِ سفارشی که همین حالا صف شده بود دور ریخته می‌شد — آن هم پیامکی که
	// ادعای ضدِتکرارش قبلاً مصرف شده و دیگر تلاشِ دوباره‌ای ندارد.
	$keep    = array_slice( $all, -FARAZSMS_QUEUE_SPILL_MAX );
	$dropped = count( $all ) - count( $keep );

	update_option( FARAZSMS_QUEUE_SPILL_OPTION, $keep, false );
	farazsms_queue_schedule_runner( 60 );

	// امضای واقعی فقط source/http_code/detail را می‌خواند — پس شمارش‌ها باید
	// داخلِ detail بروند، وگرنه هیچ‌جا ثبت نمی‌شوند.
	// ⚠️ «به صف رفت» رویدادِ اطلاعاتی است، ولی «دور انداخته شد» نیست. با یک
	// وضعیتِ مشترک، از دست رفتنِ یک پیامکِ سفارش به‌شکلِ ردیفِ سالم دیده می‌شد.
	if ( $dropped > 0 ) {
		// ⚠️ کانالِ ردیف‌های دورانداخته هم ثبت می‌شود، نه فقط تعداد. با شمارشِ
		// تنها، پشتیبانی می‌داند «چیزی گم شد» ولی نمی‌داند پیامکِ سفارش بود یا
		// یک پویشِ دوره‌ای — و همان تفاوت است که تعیین می‌کند باید نگران بود.
		$lost = array();
		foreach ( array_slice( $all, 0, $dropped ) as $gone ) {
			$ch = ( is_array( $gone ) && ! empty( $gone['channel'] ) ) ? (string) $gone['channel'] : 'unknown';
			$lost[ $ch ] = isset( $lost[ $ch ] ) ? $lost[ $ch ] + 1 : 1;
		}
		$detail = array();
		foreach ( $lost as $ch => $n ) {
			$detail[] = $ch . '=' . $n;
		}
		farazsms_send_diag_log( '', '', 'spill_overflow_dropped=' . $dropped, array(
			'source' => 'send-queue',
			'detail' => implode( ' ', $detail ),
		) );
	}
	farazsms_send_diag_log( '', '', 'queued', array(
		'source' => 'send-queue',
		'detail' => 'pending=' . count( $keep ),
	) );
}

add_action( FARAZSMS_QUEUE_DRAIN_HOOK, 'farazsms_queue_flush' );

add_action( 'admin_init', 'farazsms_queue_spill_catchup', 20 );
/**
 * جبرانِ wp-cronِ خاموش/لنگ — همان الگوی «کچ‌آپِ بازدیدِ ادمین».
 *
 * روی هاست‌هایی که کرانِ وردپرس غیرفعال است، رویدادِ زمان‌بندی‌شده هرگز اجرا
 * نمی‌شود و با زمانی در گذشته باقی می‌ماند؛ پس معیار «زمان‌بندی‌شده یا نه» نیست،
 * «سررسید گذشته یا نه» است.
 *
 * هزینه: یک خواندنِ آرایه‌ی کرانِ autoload، فقط در پیشخوان. فروشگاه هیچ اثری
 * نمی‌بیند و خودِ ارسال هم بعد از بسته‌شدنِ پاسخ انجام می‌شود.
 */
function farazsms_queue_spill_catchup() {
	if ( wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}
	$spill = get_option( FARAZSMS_QUEUE_SPILL_OPTION, array() );
	if ( ! is_array( $spill ) || empty( $spill ) ) {
		return;
	}
	$has_legacy = false;
	foreach ( $spill as $job ) {
		if ( is_array( $job ) && empty( $job['queued_at'] ) ) {
			$has_legacy = true;
			break;
		}
	}
	// ⚠️ پاک‌سازیِ مرجعِ زمانی این‌جاست، نه در تخلیه.
	//
	// تخلیه سقفِ هر درخواست دارد، پس **جزئی** است: اگر مرجع آن‌جا پاک شود،
	// ردیف‌های باقی‌مانده‌ی بی‌مهر ساعتِ تحویلشان از صفر شروع می‌شود و هر
	// بازدیدِ پیشخوان فقط یک دسته‌ی کوچک می‌برد — ۳۰۰ ردیف به‌جای چند بارگذاری،
	// یک روز طول می‌کشد. این‌جا شرطش دقیق است: مرجع وقتی می‌رود که دیگر هیچ
	// ردیفِ بی‌مهری نمانده باشد.
	if ( ! $has_legacy ) {
		delete_option( FARAZSMS_QUEUE_SPILL_SEEN_OPTION );
	}
	$seen_at = $has_legacy ? farazsms_queue_spill_seen_at( time() ) : 0;

	// اجراکننده‌ای که هنوز نوبتش نرسیده کافی است — **مگر** کار آن‌قدر مانده
	// باشد که معلوم شود آن اجراکننده اجرا نمی‌شود.
	$next = farazsms_queue_runner_next();
	$runner_pending = ( $next === true || ( is_int( $next ) && $next > time() ) );
	if ( $runner_pending && farazsms_queue_spill_age( $spill, time(), $seen_at ) < FARAZSMS_QUEUE_HANDOVER_AFTER ) {
		return;
	}
	$cron_next = wp_next_scheduled( FARAZSMS_QUEUE_DRAIN_HOOK );
	if ( $cron_next ) {
		wp_unschedule_event( $cron_next, FARAZSMS_QUEUE_DRAIN_HOOK );
	}
	// کرون از سررسید گذشته و پیشخوان تنها اجراکننده‌ی باقی‌مانده است. حالتِ
	// bounded یعنی «بفرست، ولی با سقفِ کوچک» — چون نفرستادن اینجا یعنی گم‌شدنِ
	// دائمی، نه تعویق.
	farazsms_queue_catchup_flag( true );
	farazsms_queue_register_flush();
}
