<?php
/**
 * یکپارچه‌سازی با «Ultimate Member» — پیامکِ چرخهٔ‌عمرِ عضویت.
 *
 * هوک‌ها از منبعِ Ultimate Member 2.12.1 استخراج و تأیید شده‌اند (نه از مستندات):
 *
 * um_user_register                ( $user_id, $args, $form_data )  includes/core/um-actions-register.php:573
 * um_after_user_is_approved       ( $user_id )                     includes/common/class-users.php:822
 * um_after_user_is_rejected       ( $user_id )                     includes/common/class-users.php:597
 * um_after_user_is_set_as_pending ( $user_id )                     includes/common/class-users.php:693
 * um_after_user_is_inactive       ( $user_id )                     includes/common/class-users.php:507
 * um_after_user_is_reactivated    ( $user_id )                     includes/common/class-users.php:934
 *
 * ⚠️ تلهٔ «دو پیامک برای یک اتفاق» — عمداً از هوکِ عمومی استفاده نمی‌کنیم:
 * متدِ approve() اول set_status() را صدا می‌زند که
 *
 * um_after_user_status_is_changed
 *
 * را آتش می‌زند، و **سپس** هوکِ اختصاصیِ approved را. اگر هر دو را می‌گرفتیم،
 * کاربر برای یک تأیید دو پیامک می‌گرفت. پس فقط هوک‌های اختصاصی گرفته می‌شوند.
 *
 * شماره‌ی موبایل: از فیلدِ سفارشیِ خودِ Ultimate Member خوانده می‌شود. تعریفِ
 * فیلدها در آپشنِ `um_fields` است، پس فهرستِ واقعی به مدیر نشان داده می‌شود و
 * لازم نیست نامِ متا را حدس بزند.
 *
 * کارایی: ثبت‌نام و تأیید مسیرِ کاربر/ادمین‌اند، پس ارسال هرگز درجا انجام نمی‌شود؛
 * صفِ shutdown پس از بسته‌شدنِ پاسخ خالی می‌شود.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_UM_OPTION      = 'farazsms_um_settings';

// ارسال از صفِ مشترک می‌گذرد (غیرمسدود + باقی‌ماندهٔ ماندگار):
//
// inc/farazsms-send-queue.php

/**
 * آیا Ultimate Member فعال است؟
 *
 * @return bool
 */
function farazsms_um_active() {
	return function_exists( 'UM' ) || defined( 'um_url' ) || class_exists( 'UM' );
}

/**
 * رویدادها → برچسب. کلیدها با متن‌های پیش‌فرض یکی‌اند (منبعِ واحد).
 *
 * @return array
 */
function farazsms_um_events() {
	return array(
		'register'       => 'ثبت‌نامِ کاربرِ جدید → به کاربر',
		'register_admin' => 'ثبت‌نامِ کاربرِ جدید → به مدیر',
		'approved'       => 'تأییدِ عضویت',
		'rejected'       => 'ردِ عضویت',
		'pending'        => 'در انتظارِ بررسی',
		'inactive'       => 'غیرفعال‌شدنِ حساب',
		'reactivated'    => 'فعال‌شدنِ دوبارهٔ حساب',
	);
}

/**
 * رویدادهایی که وضعیتِ عضویت را عوض می‌کنند — ادعای این‌ها با هم باطل می‌شود تا
 * چرخهٔ «تأیید ← رد ← تأییدِ دوباره» بی‌صدا حذف نشود.
 *
 * @return array
 */
function farazsms_um_status_events() {
	return array( 'approved', 'rejected', 'pending', 'inactive', 'reactivated' );
}

/**
 * @return array
 */
function farazsms_um_default_messages() {
	return array(
		'register'       => '%display_name% عزیز، ثبت‌نامِ شما انجام شد.' . "\n" . '%sitename%',
		'register_admin' => 'کاربرِ جدید ثبت‌نام کرد.' . "\n" . 'نام: %display_name%' . "\n" . 'نامِ کاربری: %user_login%' . "\n" . '%sitename%',
		'approved'       => '%display_name% عزیز، عضویتِ شما تأیید شد و حساب‌تان فعال است.' . "\n" . '%sitename%',
		'rejected'       => '%display_name% عزیز، متأسفانه درخواستِ عضویتِ شما تأیید نشد.' . "\n" . '%sitename%',
		'pending'        => '%display_name% عزیز، درخواستِ عضویتِ شما ثبت شد و در حالِ بررسی است.' . "\n" . '%sitename%',
		'inactive'       => '%display_name% عزیز، حسابِ کاربریِ شما غیرفعال شد.' . "\n" . '%sitename%',
		'reactivated'    => '%display_name% عزیز، حسابِ کاربریِ شما دوباره فعال شد.' . "\n" . '%sitename%',
	);
}

/**
 * @return array
 */
function farazsms_um_pattern_vars() {
	return array( '%display_name%', '%first_name%', '%last_name%', '%user_login%', '%user_email%', '%sitename%' );
}

// ============================================================================
// تنظیمات
// ============================================================================

/**
 * @return array
 */
function farazsms_um_settings() {
	$defaults = array(
		'enabled'     => '0',
		'phone_field' => '',
		'admin_phone' => '',
		'events'      => array(),
	);
	foreach ( farazsms_um_default_messages() as $key => $msg ) {
		$defaults['events'][ $key ] = array( 'enabled' => '0', 'pattern_code' => '', 'message' => $msg );
	}
	$saved = get_option( FARAZSMS_UM_OPTION, array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}
	$out    = array_merge( $defaults, $saved );
	$events = is_array( $out['events'] ?? null ) ? $out['events'] : array();
	foreach ( $defaults['events'] as $key => $default_event ) {
		$out['events'][ $key ] = array_merge( $default_event, is_array( $events[ $key ] ?? null ) ? $events[ $key ] : array() );
	}
	return $out;
}

/**
 * @param string $event
 * @return string
 */
function farazsms_um_pattern( $event ) {
	$s = farazsms_um_settings();
	if ( ( $s['enabled'] ?? '0' ) !== '1' ) {
		return '';
	}
	$cfg = $s['events'][ $event ] ?? array();
	if ( ( $cfg['enabled'] ?? '0' ) !== '1' ) {
		return '';
	}
	return trim( (string) ( $cfg['pattern_code'] ?? '' ) );
}

/**
 * فیلدهای سفارشیِ Ultimate Member — از آپشنِ خودش خوانده می‌شود.
 *
 * @return array metakey → برچسب
 */
function farazsms_um_field_choices() {
	$fields = get_option( 'um_fields', array() );
	$out    = array();
	if ( is_array( $fields ) ) {
		foreach ( $fields as $key => $def ) {
			if ( ! is_array( $def ) ) {
				continue;
			}
			// فیلترِ نوع عمداً برداشته شد: مدیرها فیلدِ موبایل را با نوع‌های
			// مختلفی می‌سازند و اگر فیلدشان در فهرست نبود، راهی برای انتخابش
			// نداشتند. همه پیشنهاد می‌شوند و ورودی هم آزاد است.
			$out[ (string) $key ] = (string) ( $def['title'] ?? $key );
		}
	}
	return $out;
}

// ============================================================================
// شماره و متغیرها
// ============================================================================

/**
 * @param int $user_id
 * @return string
 */
function farazsms_um_user_phone( $user_id ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return '';
	}
	$settings = farazsms_um_settings();
	$keys     = array();
	$chosen   = trim( (string) $settings['phone_field'] );
	if ( $chosen !== '' ) {
		$keys[] = $chosen;
	}
	// همان ترتیبِ مشترکِ بقیه‌ی ماژول‌ها به‌عنوانِ جایگزین.
	// انتخابِ صریحِ مدیر انحصاری است؛ راهنمای همان کادر می‌گوید «خالی بگذارید تا
	// خودکار عمل کند». اگر فیلدی انتخاب شده و خالی بود، سراغِ فیلدِ دیگری نمی‌رویم
	// وگرنه پیامک به شماره‌ی قدیمیِ صورتحساب می‌رفت.
	if ( $chosen === '' ) {
		$keys[] = 'mobile_number';
		$keys[] = 'billing_phone';
	}

	foreach ( $keys as $key ) {
		$value = trim( (string) get_user_meta( $user_id, $key, true ) );
		if ( $value === '' ) {
			continue;
		}
		return (string) farazsms_normalize_phone( $value );
	}
	return '';
}

/**
 * @param int $user_id
 * @return array
 */
function farazsms_um_vars( $user_id ) {
	$user = get_userdata( (int) $user_id );
	return array(
		'display_name' => $user ? (string) $user->display_name : '',
		'first_name'   => $user ? (string) $user->first_name : '',
		'last_name'    => $user ? (string) $user->last_name : '',
		'user_login'   => $user ? (string) $user->user_login : '',
		'user_email'   => $user ? (string) $user->user_email : '',
		'sitename'     => get_bloginfo( 'name' ),
	);
}

// ============================================================================
// ضدِتکرار
// ============================================================================

/**
 * ادعای یک‌بارمصرفِ (کاربر، رویداد).
 *
 * برای رویدادهای وضعیتی، ادعای بقیهٔ وضعیت‌ها باطل می‌شود تا چرخهٔ
 * «تأیید ← رد ← تأییدِ دوباره» واقعاً پیامک بدهد و بی‌صدا حذف نشود.
 *
 * @param int    $user_id
 * @param string $event
 * @return bool
 */
function farazsms_um_release_sibling_claims( $user_id, $event ) {
	foreach ( farazsms_um_status_events() as $other ) {
		if ( $other !== $event ) {
			delete_user_meta( (int) $user_id, '_farazsms_um_' . $other );
		}
	}
}

/**
 * ادعای یک‌بارمصرفِ (کاربر، رویداد).
 *
 * @param int    $user_id
 * @param string $event
 * @return bool
 */
function farazsms_um_claim( $user_id, $event ) {
	$user_id = (int) $user_id;
	// add_user_meta با unique=true فقط وقتی موفق می‌شود که از قبل نباشد.
	return (bool) add_user_meta( $user_id, '_farazsms_um_' . $event, 1, true );
}

// ============================================================================
// اعزام
// ============================================================================

/**
 * @param string $event
 * @param int    $user_id
 */
function farazsms_um_dispatch( $event, $user_id ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return;
	}

	// ⚠️ باطل‌کردنِ ادعای وضعیت‌های دیگر باید **پیش از** گیتِ «پترن خالی» باشد.
	// وگرنه: مدیر فقط «تأیید» را روشن کرده؛ تأیید → ادعا ثبت؛ رد → چون پترنش خالی
	// است زودتر برمی‌گردیم و ادعای approved باطل نمی‌شود؛ تأییدِ دوباره → هیچ
	// پیامکی نمی‌رود. یعنی دقیقاً همان چیزی که راهنمای صفحه وعده داده بود نقض می‌شد.
	if ( in_array( $event, farazsms_um_status_events(), true ) ) {
		farazsms_um_release_sibling_claims( $user_id, $event );
	}

	$pattern = farazsms_um_pattern( $event );
	if ( $pattern === '' ) {
		return;
	}

	// ⚠️ شماره **پیش از** ادعا خوانده می‌شود. اگر ادعا زودتر ثبت شود و بعد معلوم
	// شود شماره‌ای نیست (ثبت‌نامِ چندمرحله‌ای، ایمپورت)، آن رویداد برای همیشه
	// می‌سوزد و وقتی کاربر بعداً شماره‌اش را وارد کند هم جبران نمی‌شود.
	if ( $event === 'register_admin' ) {
		$settings = farazsms_um_settings();
		$phone    = trim( (string) $settings['admin_phone'] );
		if ( $phone !== '' ) {
			$phone = (string) farazsms_normalize_phone( $phone );
		}
	} else {
		$phone = farazsms_um_user_phone( $user_id );
	}
	if ( $phone === '' ) {
		return;
	}

	if ( ! farazsms_um_claim( $user_id, $event ) ) {
		return;
	}
	farazsms_queue_send( 'ultimate-member', $phone, $pattern, farazsms_um_vars( $user_id ), array( 'event' => $event ) );
}

// ============================================================================
// هوک‌ها — فقط اختصاصی‌ها (دلیل در docblockِ بالای فایل)
// ============================================================================

add_action( 'um_user_register', 'farazsms_um_on_register', 20, 1 );
function farazsms_um_on_register( $user_id ) {
	try {
		farazsms_um_dispatch( 'register', (int) $user_id );
		farazsms_um_dispatch( 'register_admin', (int) $user_id );
	} catch ( \Throwable $e ) {
		return; // ثبت‌نام هرگز نباید به‌خاطرِ پیامک بشکند.
	}
}

/**
 * ثبتِ هوک‌های وضعیت با یک حلقه — نگاشتِ هوکِ خودِ افزونه به رویدادِ ما.
 */
foreach ( array(
	'um_after_user_is_approved'       => 'approved',
	'um_after_user_is_rejected'       => 'rejected',
	'um_after_user_is_set_as_pending' => 'pending',
	'um_after_user_is_inactive'       => 'inactive',
	'um_after_user_is_reactivated'    => 'reactivated',
) as $farazsms_um_hook => $farazsms_um_event ) {
	add_action(
		$farazsms_um_hook,
		function ( $user_id ) use ( $farazsms_um_event ) {
			try {
				farazsms_um_dispatch( $farazsms_um_event, (int) $user_id );
			} catch ( \Throwable $e ) {
				return;
			}
		},
		20,
		1
	);
}
unset( $farazsms_um_hook, $farazsms_um_event );

// ============================================================================
// ساختِ خودکارِ پترن
// ============================================================================

add_filter( 'farazsms_feature_pattern_map', 'farazsms_um_register_pattern_features' );
function farazsms_um_register_pattern_features( $map ) {
	foreach ( array_keys( farazsms_um_default_messages() ) as $event ) {
		$map[ 'um_' . $event ] = array(
			'opt'     => FARAZSMS_UM_OPTION,
			'section' => 'club',
			'path'    => array( 'events', $event ),
		);
	}
	return $map;
}

// ============================================================================
// صفحه‌ی تنظیمات
// ============================================================================

add_action( 'admin_menu', 'farazsms_um_menu', 20 );
function farazsms_um_menu() {
	add_submenu_page(
		'farazsms',
		__( 'پیامک عضویت (Ultimate Member)', 'farazsms' ),
		__( 'پیامک عضویت (UM)', 'farazsms' ),
		'manage_options',
		'farazsms-ultimate-member',
		'farazsms_um_render_page'
	);
}

add_action( 'admin_init', 'farazsms_um_handle_save' );
function farazsms_um_handle_save() {
	if ( ! isset( $_POST['farazsms_um_nonce'] ) ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['farazsms_um_nonce'] ) ), 'farazsms_um_save' ) ) {
		return;
	}
	$settings                = farazsms_um_settings();
	$settings['enabled']     = isset( $_POST['farazsms_um_enabled'] ) ? '1' : '0';
	$settings['phone_field'] = sanitize_text_field( wp_unslash( $_POST['farazsms_um_phone_field'] ?? '' ) );
	$settings['admin_phone'] = sanitize_text_field( wp_unslash( $_POST['farazsms_um_admin_phone'] ?? '' ) );

	foreach ( array_keys( farazsms_um_default_messages() ) as $key ) {
		// متنِ پیامک را سازنده‌ی پترن می‌نویسد، نه این فرم.
		$settings['events'][ $key ]['enabled']      = isset( $_POST[ 'farazsms_um_ev_' . $key ] ) ? '1' : '0';
		$settings['events'][ $key ]['pattern_code'] = sanitize_text_field( wp_unslash( $_POST[ 'farazsms_um_pat_' . $key ] ?? '' ) );
	}
	update_option( FARAZSMS_UM_OPTION, $settings, false );

	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-success is-dismissible"><p>تنظیماتِ پیامکِ عضویت ذخیره شد.</p></div>';
	} );
}

function farazsms_um_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$settings = farazsms_um_settings();
	$events   = farazsms_um_events();
	$choices  = farazsms_um_field_choices();
	$vars     = farazsms_um_pattern_vars();
	$has_ui   = function_exists( 'farazsms_feature_pattern_builder_ui' );
	?>
	<div class="wrap" dir="rtl">
		<h1>👥 پیامک عضویت — Ultimate Member</h1>

		<?php if ( ! farazsms_um_active() ) : ?>
			<div class="notice notice-warning"><p>
				افزونهٔ <strong>Ultimate Member</strong> روی این سایت پیدا نشد. تنظیماتِ زیر ذخیره می‌شود ولی تا نصبِ آن اثری ندارد.
			</p></div>
		<?php endif; ?>

		<div class="farazsms-int-intro">
			<strong>این صفحه چه می‌کند؟</strong> در هر تغییرِ وضعیتِ عضویت — ثبت‌نام، تأیید، رد، غیرفعال‌سازی — به کاربر پیامک می‌دهد،
			و در صورت تمایل ثبت‌نامِ کاربرِ جدید را به مدیر اطلاع می‌دهد.
			<br><strong>راه‌اندازی در ۳ قدم:</strong>
			<ol>
				<li>کلیدِ کلی را روشن کنید و <strong>فیلدِ موبایل</strong> را از فهرستِ فیلدهای خودِ Ultimate Member انتخاب کنید.</li>
				<li>برای هر رویداد تیک بزنید، متن را ویرایش کنید و دکمهٔ ساختِ پترن را بزنید.</li>
				<li>ذخیره کنید.</li>
			</ol>
		</div>

		<form method="post" action="">
			<?php wp_nonce_field( 'farazsms_um_save', 'farazsms_um_nonce' ); ?>

			<div class="farazsms-int-card">
				<div class="farazsms-int-card__head">
					<h2 class="farazsms-int-card__title">وضعیتِ کلی</h2>
					<label class="farazsms-int-toggle">
						<input type="checkbox" name="farazsms_um_enabled" value="1" <?php checked( $settings['enabled'], '1' ); ?>>
						پیامکِ عضویت فعال باشد
					</label>
				</div>
				<div class="farazsms-int-card__body">
					<div class="farazsms-int-field">
						<label for="farazsms-um-field">فیلدِ موبایل در Ultimate Member</label>
						<input id="farazsms-um-field" type="text" dir="ltr" name="farazsms_um_phone_field" value="<?php echo esc_attr( $settings['phone_field'] ); ?>" list="farazsms-um-fields" placeholder="خالی = خودکار">
						<datalist id="farazsms-um-fields">
							<?php foreach ( $choices as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</datalist>
						<p class="farazsms-int-hint">
							خالی بگذارید تا خودکار عمل کند (اول فیلدِ موبایل، بعد موبایلِ صورتحسابِ ووکامرس).
							<?php if ( ! empty( $choices ) ) : ?>
								فیلدهای تعریف‌شده در Ultimate Member به‌عنوانِ پیشنهاد در همین کادر می‌آیند.
							<?php endif; ?>
						</p>
						<?php if ( ! empty( $choices ) ) : ?>
							<div class="farazsms-int-vars"><?php foreach ( array_slice( array_keys( $choices ), 0, 15 ) as $k ) : ?><code><?php echo esc_html( $k ); ?></code><?php endforeach; ?></div>
						<?php endif; ?>
					</div>
					<div class="farazsms-int-field">
						<label for="farazsms-um-admin">شمارهٔ مدیر (برای اطلاع از ثبت‌نامِ جدید)</label>
						<input id="farazsms-um-admin" type="text" dir="ltr" name="farazsms_um_admin_phone" value="<?php echo esc_attr( $settings['admin_phone'] ); ?>" placeholder="09xxxxxxxxx">
					</div>
				</div>
			</div>

			<?php foreach ( $events as $key => $label ) :
				$cfg = $settings['events'][ $key ] ?? array(); ?>
				<div class="farazsms-int-card">
					<div class="farazsms-int-card__head">
						<h2 class="farazsms-int-card__title"><?php echo esc_html( $label ); ?></h2>
						<label class="farazsms-int-toggle">
							<input type="checkbox" name="<?php echo esc_attr( 'farazsms_um_ev_' . $key ); ?>" value="1" <?php checked( $cfg['enabled'] ?? '0', '1' ); ?>>
							فعال
						</label>
					</div>
					<div class="farazsms-int-card__body">
						<div class="farazsms-int-field">
							<label for="<?php echo esc_attr( 'farazsms-um-pat-' . $key ); ?>">کدپترن</label>
							<input id="<?php echo esc_attr( 'farazsms-um-pat-' . $key ); ?>" type="text" dir="ltr" name="<?php echo esc_attr( 'farazsms_um_pat_' . $key ); ?>" value="<?php echo esc_attr( $cfg['pattern_code'] ?? '' ); ?>" placeholder="با دکمهٔ زیر خودکار پر می‌شود">
						</div>
						<?php if ( $has_ui ) {
							farazsms_feature_pattern_builder_ui( 'um_' . $key, (string) ( $cfg['message'] ?? '' ), $vars, 'farazsms_um_pat_' . $key );
						} ?>
					</div>
				</div>
			<?php endforeach; ?>

			<p><button type="submit" class="button button-primary">💾 ذخیره تنظیمات</button></p>
		</form>

		<div class="farazsms-int-intro">
			<strong>سؤال‌های پرتکرار</strong>
			<ul>
				<li><strong>پیامک نمی‌رود؟</strong> کاربر باید در همان فیلدی که بالا انتخاب کرده‌اید شماره داشته باشد. اگر «خودکار» گذاشته‌اید، فیلدِ موبایل و سپس موبایلِ صورتحسابِ ووکامرس بررسی می‌شود.</li>
				<li><strong>کاربری که رد شده و دوباره تأیید می‌شود، پیامک می‌گیرد؟</strong> بله. هر تغییرِ وضعیت پیامکِ خودش را دارد و ادعای وضعیت‌های قبلی باطل می‌شود.</li>
				<li><strong>هنگام تأیید دو پیامک می‌آید؟</strong> نمی‌آید — عمداً فقط از هوکِ اختصاصیِ هر وضعیت استفاده می‌شود، نه هوکِ عمومیِ تغییرِ وضعیت که هم‌زمان با آن آتش می‌شود.</li>
				<li><strong>ثبت‌نام کند می‌شود؟</strong> خیر. ارسال پس از بسته‌شدنِ صفحه انجام می‌شود.</li>
			</ul>
		</div>
	</div>
	<?php
}

add_filter( 'farazsms_compatibility_registry', 'farazsms_um_register_compat' );
/**
 * @param array $registry
 * @return array
 */
function farazsms_um_register_compat( $registry ) {
	$registry['ultimate_member'] = array(
		'name'   => 'Ultimate Member',
		'what'   => 'پیامکِ ثبت‌نام، تأیید، رد، در انتظارِ بررسی و تغییرِ وضعیتِ حسابِ عضو',
		'group'  => 'members',
		'detect' => 'farazsms_um_active',
	);
	return $registry;
}

add_filter( 'farazsms_nav_extra', 'farazsms_um_register_nav' );
/**
 * @param array $nav
 * @return array
 */
function farazsms_um_register_nav( $nav ) {
	$nav['farazsms-ultimate-member'] = array(
		'title' => 'عضویت (UM)',
		'icon'  => 'dashicons-groups',
		'desc'  => 'پیامکِ ثبت‌نام، تأیید و وضعیتِ عضویت',
		'group' => 'login',
		'when'  => 'farazsms_um_active',
	);
	return $nav;
}
