<?php
/**
 * لایه‌ی سرویسِ واحدِ پیامک (SMS Service Layer).
 *
 * تا امروز ۹ مسیرِ جدا به API فراز وصل می‌شدند، هرکدام با base-URL، هدرِ کلید،
 * timeout و مدیریتِ خطای کپی‌شده‌ی خودش. این فایل «یک نقطه‌ی خروج» می‌سازد تا:
 *   - آدرسِ پایه و هدرِ Api-Key فقط یک‌جا تعریف شود،
 *   - fallback به cURL (برای هاست‌های مسدودکننده‌ی wp_remote) یک‌جا اعمال شود،
 *   - نگهبانِ اتصال (note_failure / note_success) یک‌جا فراخوانی شود،
 *   - قانونِ «هرگز render را بلاک نکن» با timeout اجباری در همه‌جا تضمین شود.
 *
 * توابعِ ارسالِ قدیمی حفظ می‌شوند ولی درونِ خود به این سرویس delegate می‌کنند،
 * پس امضای آن‌ها و ۲۰+ فراخواننده دست‌نخورده می‌مانند.
 *
 * @package FarazSMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * آدرسِ پایه‌ی API (با اسلشِ پایانی).
 *
 * @return string
 */
function farazsms_sms_api_base() {
	return 'https://api.iranpayamak.com/ws/v1/';
}

/**
 * ساختِ URL کامل از یک مسیرِ نسبی.
 *
 * @param string $path مثلاً 'sms/pattern' یا 'account/balance'.
 * @return string
 */
function farazsms_sms_api_url( $path ) {
	return farazsms_sms_api_base() . ltrim( (string) $path, '/' );
}

/**
 * درخواستِ یکدست به API فراز.
 *
 * این تنها نقطه‌ای است که هدرِ Api-Key، timeout اجباری، fallbackِ cURL و
 * نگهبانِ اتصال را با هم اعمال می‌کند. همه‌ی مسیرهای جدید باید از این عبور کنند.
 *
 * @param string $method 'GET' | 'POST' | 'PUT' | 'DELETE'.
 * @param string $path   مسیرِ نسبی (روی base) یا URL کاملِ http(s).
 * @param array  $opts {
 *     @type array       $body    بدنه (به JSON تبدیل می‌شود) — برای POST/PUT.
 *     @type string      $apikey  کلید؛ پیش‌فرض از farazsms_cfg_apikey().
 *     @type int         $timeout ثانیه؛ پیش‌فرض 15 (اجباری برای مسیرِ سفارش).
 *     @type bool        $note    ثبتِ موفقیت/شکستِ اتصال؛ پیش‌فرض true.
 *     @type array       $headers هدرهای اضافه.
 * }
 * @return array|WP_Error پاسخِ استانداردِ wp_remote (یا WP_Error).
 */
function farazsms_sms_request( $method, $path, $opts = array() ) {
	$method  = strtoupper( $method );
	$url     = ( strpos( $path, 'http' ) === 0 ) ? $path : farazsms_sms_api_url( $path );
	$apikey  = isset( $opts['apikey'] ) ? $opts['apikey'] : ( farazsms_cfg_apikey());
	$timeout = isset( $opts['timeout'] ) ? (int) $opts['timeout'] : 15;
	$note    = ! isset( $opts['note'] ) || $opts['note'];

	$headers = array(
		'Accept'       => 'application/json',
		'Content-Type' => 'application/json',
		'Api-Key'      => $apikey,
	);
	if ( ! empty( $opts['headers'] ) && is_array( $opts['headers'] ) ) {
		$headers = array_merge( $headers, $opts['headers'] );
	}

	$args = array(
		'method'  => $method,
		'headers' => $headers,
		'timeout' => $timeout,
	);
	if ( isset( $opts['body'] ) ) {
		$args['body'] = is_string( $opts['body'] ) ? $opts['body'] : wp_json_encode( $opts['body'] );
	}

	// انتخابِ helperِ fallback بر اساس متد (موجود در farazsms-sms-api.php).
	if ( $method === 'GET' ) {
		$response = farazsms_remote_get_with_fallback( $url, $args );
	} elseif ( function_exists( 'farazsms_remote_post_with_fallback' ) ) {
		$response = farazsms_remote_post_with_fallback( $url, $args );
	} else {
		$response = wp_remote_request( $url, $args );
	}

	// نگهبانِ اتصال: یک‌جا برای همه‌ی مسیرها.
	if ( $note ) {
		if ( is_wp_error( $response ) ) {
			farazsms_connectivity_note_failure( 'sms_service: ' . $response->get_error_message() );
		} elseif ( function_exists( 'farazsms_connectivity_note_success' ) ) {
			farazsms_connectivity_note_success();
		}
	}

	return $response;
}

/**
 * استخراجِ بدنه‌ی JSON دیکدشده از پاسخِ سرویس.
 *
 * @param array|WP_Error $response خروجیِ farazsms_sms_request().
 * @return array|null آرایه‌ی دیکدشده یا null.
 */
function farazsms_sms_decode( $response ) {
	if ( is_wp_error( $response ) ) {
		return null;
	}
	$body = wp_remote_retrieve_body( $response );
	$data = json_decode( (string) $body, true );
	return is_array( $data ) ? $data : null;
}

/**
 * v3.22.59: مقدارِ خالی/null یک متغیرِ پترن را به «-» تبدیل می‌کند (وگرنه فراز کلِ پیامک را رد
 * می‌کند). قانونِ کلیِ ارسال به فراز: هیچ متغیرِ خالی نرود.
 *
 * @param mixed $value
 * @return string
 */
function farazsms_attr_placeholder_if_empty( $value ) {
	// object/array هرگز نباید (string) شود (fatal / "Array")؛ چنین مقداری = خالی تلقی می‌شود.
	if ( is_array( $value ) || is_object( $value ) ) {
		return '-';
	}
	$s = ( $value === null || $value === false ) ? '' : (string) $value;
	// trim فقط فاصله‌ی ASCII را می‌گیرد. \p{Z} همه‌ی جداکننده‌های فاصله‌ایِ یونیکد را می‌گیرد
	// (nbsp، فاصله‌ی ideographic/narrow/figure، …) و فهرستِ صریح، کاراکترهای صفرعرض/جهت‌نما را
	// (ZWSP/ZWNJ/ZWJ + LRM/RLM + word-joiner + BOM) که در دیتای سفارشِ فارسی رایج‌اند و «عملاً خالی».
	$strip   = '/^[\s\p{Z}\x{200B}\x{200C}\x{200D}\x{200E}\x{200F}\x{2060}\x{FEFF}]+|[\s\p{Z}\x{200B}\x{200C}\x{200D}\x{200E}\x{200F}\x{2060}\x{FEFF}]+$/u';
	$trimmed = preg_replace( $strip, '', $s );
	if ( $trimmed === null ) {
		// UTF-8 نامعتبر → preg با /u شکست می‌خورد. اگر خامِ نامعتبر را برگردانیم، json_encode = false و
		// ارسال بی‌صدا خراب می‌شود؛ پس بایت‌های نامعتبر را پاک می‌کنیم و روی نسخه‌ی سالم دوباره می‌سنجیم.
		$s       = function_exists( 'mb_scrub' ) ? mb_scrub( $s, 'UTF-8' ) : (string) mb_convert_encoding( $s, 'UTF-8', 'UTF-8' );
		$trimmed = preg_replace( $strip, '', $s );
		if ( $trimmed === null ) { // اگر هنوز شکست خورد → امن‌ترین حالت «-»
			return '-';
		}
	}
	// نسخه‌ی trim‌شده را برگردان (نه $s خام) تا کاراکترهای جهت‌نما/صفرعرضِ ابتدا-انتها که RTL را
	// در پیامک به‌هم می‌ریزند حذف شوند؛ فاصله‌ی داخلی دست‌نخورده می‌ماند.
	return $trimmed === '' ? '-' : $trimmed;
}

/**
 * ارسالِ پیامکِ پترن — سطحِ بالا، قراردادِ واحد.
 *
 * این جایگزینِ منطقِ تکراریِ curl در سراسرِ افزونه است. قراردادِ بازگشتی همان
 * farazsms_send_pattern_sms_raw قدیمی است تا فراخواننده‌ها تغییری لازم نداشته باشند:
 *   'success' در موفقیت، وگرنه رشته‌ی خطا ('missing_params' | 'api_error:…' | …).
 *
 * @param string $recipient    شماره‌ی گیرنده.
 * @param string $pattern_code کدِ پترن.
 * @param array  $attributes   متغیرهای پترن (key => value).
 * @param string $sender       خطِ ارسال (خالی = از تنظیمات).
 * @return string|true 'success' یا رشته‌ی خطا.
 */
function farazsms_sms_send_pattern( $recipient, $pattern_code, $attributes = array(), $sender = '' ) {
	$apikey = farazsms_cfg_apikey();
	if ( $sender === '' ) {
		$sender = farazsms_cfg_sender();
	}
	if ( $apikey === '' || $pattern_code === '' || $recipient === '' ) {
		return 'missing_params';
	}
	$recipient = farazsms_normalize_phone( $recipient );

	// v3.22.115: کلیدهای متغیرِ hex-ناامن را دقیقاً مثلِ زمانِ ساختِ پترن امن کن، تا نامِ
	// attribute با نامِ متغیرِ ذخیره‌شده در پترن بخواند (وگرنه متغیر خالی می‌ماند و ارسال رد می‌شود).
	if ( is_array( $attributes ) ) {
		$hexsafe_attrs = array();
		foreach ( $attributes as $attr_key => $attr_val ) {
			$hexsafe_attrs[ farazsms_pattern_hexsafe_name( $attr_key ) ] = $attr_val;
		}
		$attributes = $hexsafe_attrs;
	}

	$body = array(
		'code'          => $pattern_code,
		'recipient'     => $recipient,
		// v3.22.59 (قانونِ کلی): مقدارِ خالی/null هر متغیر → «-». فراز پترنِ دارای متغیرِ خالی را رد
		// می‌کند و پیامک اصلاً ارسال نمی‌شود؛ پس هیچ متغیرِ خالی به فراز نمی‌فرستیم.
		'attributes'    => array_map( 'farazsms_attr_placeholder_if_empty', (array) $attributes ),
		'line_number'   => $sender,
		'number_format' => 'english',
	);

	$response = farazsms_sms_request( 'POST', 'sms/pattern', array(
		'body'    => $body,
		'apikey'  => $apikey,
		'timeout' => 15,
	) );

	if ( is_wp_error( $response ) ) {
		$result = 'curl_error:' . $response->get_error_message();
	} else {
		$data = farazsms_sms_decode( $response );
		if ( $data && isset( $data['status'] ) && $data['status'] === 'success' ) {
			$result = 'success';
		} elseif ( $data && isset( $data['status'] ) && $data['status'] === 'error' ) {
			$msg    = isset( $data['message'] ) ? $data['message'] : 'خطای نامشخص';
			$msg    = farazsms_flatten_api_message( $msg );
			$result = 'api_error:' . $msg;
		} else {
			$result = (string) wp_remote_retrieve_body( $response );
		}
	}

	// v3.21.91: لاگِ متمرکزِ ارسال — تمامِ پیامک‌های پترنی از همین‌جا عبور می‌کنند، پس یک نقطه‌ی
	// واحد برای «آیا ارسال شد یا نه» می‌سازیم (پنلِ تشخیص). قبلاً هیچ لاگِ محلی‌ای نبود و تنها راه،
	// گزارش‌گیرِ آنلاینِ پنل بود که زیرِ اینترنتِ ملی گاهی در دسترس نیست.
	$diag_http = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
	farazsms_send_diag_log( $recipient, $pattern_code, $result, array(
		'source'    => 'pattern-service',
		'http_code' => $diag_http,
	) );

	return $result;
}

/**
 * transportِ واحد برای endpointهای «ساخت/آپدیتِ پترن» (/patterns).
 *
 * چهار تابعِ ساختِ پترن (create/update × عادی/pwsms) تا امروز هرکدام یک بلوکِ
 * curl خام داشتند بدونِ fallback. این helper آن‌ها را از مسیرِ واحدِ سرویس عبور
 * می‌دهد تا fallbackِ cURL (هاست‌های مسدودکننده) هم شامل‌شان شود. منطقِ ساختِ
 * بدنه و پارسِ خروجی در خودِ آن توابع دست‌نخورده می‌ماند.
 *
 * @param string $method 'POST' (ساخت) یا 'PUT' (آپدیت).
 * @param string $path   'patterns' یا 'patterns/{code}'.
 * @param array  $body   بدنه‌ی آماده‌شده توسطِ فراخواننده.
 * @param string $apikey کلید (خالی = کانونی).
 * @return array{body:string, code:int} متنِ خام و کدِ HTTP (سازگار با کدِ قدیمی).
 */
function farazsms_sms_pattern_request( $method, $path, $body, $apikey = '' ) {
	if ( $apikey === '' ) {
		$apikey = farazsms_cfg_apikey();
	}
	$response = farazsms_sms_request( $method, $path, array(
		'body'    => $body,
		'apikey'  => $apikey,
		'timeout' => 30,
	) );
	if ( is_wp_error( $response ) ) {
		return array(
			'body' => wp_json_encode( array( 'status' => 'error', 'message' => $response->get_error_message() ) ),
			'code' => 0,
		);
	}
	return array(
		'body' => (string) wp_remote_retrieve_body( $response ),
		'code' => (int) wp_remote_retrieve_response_code( $response ),
	);
}

/**
 * ارسالِ پیامکِ ساده (متنِ آزاد) به یک یا چند گیرنده.
 *
 * @param string|array $recipients شماره یا آرایه‌ی شماره‌ها.
 * @param string       $message    متنِ پیام.
 * @param string       $sender     خطِ ارسال (خالی = از تنظیمات).
 * @return array|WP_Error پاسخِ سرویس.
 */
function farazsms_sms_send_simple( $recipients, $message, $sender = '' ) {
	if ( $sender === '' ) {
		$sender = farazsms_cfg_sender();
	}
	$list = is_array( $recipients ) ? array_values( $recipients ) : array( $recipients );

	// v3.22.31: فیلدهای درستِ endpointِ sms/simple طبقِ مستنداتِ رسمی: text + line_number
	// (قبلاً message/sender بود که endpoint نمی‌شناخت — تابع بی‌استفاده بود ولی باگ‌دار).
	return farazsms_sms_request( 'POST', 'sms/simple', array(
		'body'    => array(
			'recipients'    => $list,
			'text'          => (string) $message,
			'line_number'   => $sender,
			'number_format' => 'english',
		),
		'timeout' => 30,
	) );
}
