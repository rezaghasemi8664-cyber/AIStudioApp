<?php
/**
 * Wallet Top-up via WooCommerce — v3.21.92 (Item 4)
 *
 * کاربر از طریقِ افزونه، کیف پولِ فروشگاهی‌اش را شارژ می‌کند:
 * یک محصولِ مجازیِ «شارژ کیف پول» با مبلغِ دلخواه به سبد افزوده می‌شود → پرداخت از درگاهِ
 * ووکامرس → سفارش ثبت می‌شود → پس از پرداخت، مبلغ به کیف پولِ farazsms-wallet.php واریز و
 * پیامک ارسال می‌شود. مصرفِ کیف پول در سفارش‌های بعدی از قبل در farazsms-wallet.php پیاده شده.
 *
 * وابسته به کیف پولِ بومیِ فروشگاه (farazsms_wallet_add_credit) — نه TeraWallet.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_WALLET_TOPUP_META = '_farazsms_wallet_topup';       // متای محصولِ شارژ
const FARAZSMS_WALLET_TOPUP_ITEM = '_farazsms_topup_amount';        // متای آیتمِ سفارش/سبد

function farazsms_wallet_topup_settings() {
	$d = array(
		'enabled'      => '1',
		'packages'     => '100000,200000,500000,1000000',
		'min'          => '50000',
		'max'          => '50000000',
		'expiry_days'  => '0',   // انقضای اعتبارِ شارژشده (۰=بی‌انقضا)
		'pattern_code' => '',
		'message'      => "کیف پول شما با موفقیت شارژ شد.\nمبلغ: %amount% تومان\nموجودی فعلی: %balance% تومان",
	);
	$s = get_option( 'farazsms_wallet_topup_settings', array() );
	return array_merge( $d, is_array( $s ) ? $s : array() );
}

function farazsms_wallet_topup_is_enabled() {
	$s = farazsms_wallet_topup_settings();
	return $s['enabled'] === '1' && function_exists( 'farazsms_wallet_add_credit' );
}

/**
 * شناسه‌ی محصولِ «شارژ کیف پول» — اگر نبود یا حذف شده بود، ساخته می‌شود (lazy).
 */
function farazsms_wallet_topup_product_id() {
	if ( ! function_exists( 'wc_get_product' ) || ! class_exists( 'WC_Product_Simple' ) ) {
		return 0;
	}
	$pid = (int) get_option( 'farazsms_wallet_topup_product_id', 0 );
	if ( $pid > 0 ) {
		$p = wc_get_product( $pid );
		if ( $p && $p->get_meta( FARAZSMS_WALLET_TOPUP_META ) === 'yes' ) {
			// v3.21.95: مهاجرت — محصولِ شارژی که پیش از معاف‌شدنِ مالیات ساخته شده بود، معاف شود
			// تا get_total (که مبنای اعتبار است) با مبلغِ پرداختی یکی باشد.
			if ( method_exists( $p, 'get_tax_status' ) && $p->get_tax_status() !== 'none' ) {
				$p->set_tax_status( 'none' );
				$p->save();
			}
			return $pid;
		}
	}
	// ساخت محصولِ مجازیِ مخفی.
	$product = new WC_Product_Simple();
	$product->set_name( 'شارژ کیف پول' );
	$product->set_status( 'publish' );
	$product->set_catalog_visibility( 'hidden' );
	$product->set_virtual( true );
	$product->set_sold_individually( true );
	$product->set_tax_status( 'none' ); // v3.21.93: شارژ مالیات نمی‌گیرد تا پرداختی == اعتبارِ واریزی.
	$product->set_price( 0 );
	$product->set_regular_price( 0 );
	$product->update_meta_data( FARAZSMS_WALLET_TOPUP_META, 'yes' );
	$pid = $product->save();
	if ( $pid ) {
		update_option( 'farazsms_wallet_topup_product_id', (int) $pid, false );
	}
	return (int) $pid;
}

/** آیا این محصول، محصولِ شارژِ کیف پول است؟ */
function farazsms_wallet_topup_is_topup_product( $product_id ) {
	if ( ! function_exists( 'wc_get_product' ) ) {
		return false;
	}
	$p = wc_get_product( $product_id );
	return $p && $p->get_meta( FARAZSMS_WALLET_TOPUP_META ) === 'yes';
}

/** آیا سبدِ خرید شاملِ آیتمِ شارژ است؟ (برای گاردِ عدمِ پرداخت با کیف پول). */
function farazsms_wallet_cart_has_topup() {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return false;
	}
	foreach ( WC()->cart->get_cart() as $item ) {
		if ( ! empty( $item[ FARAZSMS_WALLET_TOPUP_ITEM ] ) ) {
			return true;
		}
	}
	return false;
}

// ── افزودن به سبد با مبلغِ دلخواه ─────────────────────────────────────────
add_action( 'wp_loaded', 'farazsms_wallet_topup_handle_add' );
function farazsms_wallet_topup_handle_add() {
	if ( empty( $_REQUEST['farazsms_do_topup'] ) || ! farazsms_wallet_topup_is_enabled() ) {
		return;
	}
	if ( ! isset( $_REQUEST['farazsms_topup_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_REQUEST['farazsms_topup_nonce'] ) ), 'farazsms_topup' ) ) {
		return;
	}
	// v3.21.93: شارژ فقط برای کاربرِ واردشده — کیف پول به user_id نیاز دارد؛ وگرنه مهمان پول می‌دهد
	// و اعتباری واریز نمی‌شود.
	if ( ! is_user_logged_in() ) {
		if ( function_exists( 'wc_add_notice' ) ) {
			wc_add_notice( 'برای شارژ کیف پول ابتدا وارد شوید.', 'error' );
		}
		return;
	}
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return;
	}
	$s      = farazsms_wallet_topup_settings();
	$amount = isset( $_REQUEST['farazsms_topup_amount'] ) ? (float) preg_replace( '/[^0-9.]/', '', (string) wp_unslash( $_REQUEST['farazsms_topup_amount'] ) ) : 0;
	$min    = max( 1, (float) $s['min'] );
	$max    = max( $min, (float) $s['max'] );
	if ( $amount < $min || $amount > $max ) {
		wc_add_notice( sprintf( 'مبلغِ شارژ باید بین %s تا %s تومان باشد.', number_format( $min ), number_format( $max ) ), 'error' );
		return;
	}
	$pid = farazsms_wallet_topup_product_id();
	if ( $pid <= 0 ) {
		wc_add_notice( 'محصولِ شارژِ کیف پول در دسترس نیست.', 'error' );
		return;
	}
	// هر بار فقط یک آیتمِ شارژ در سبد بماند تا سردرگمی نشود.
	foreach ( WC()->cart->get_cart() as $key => $item ) {
		if ( ! empty( $item[ FARAZSMS_WALLET_TOPUP_ITEM ] ) ) {
			WC()->cart->remove_cart_item( $key );
		}
	}
	WC()->cart->add_to_cart( $pid, 1, 0, array(), array( FARAZSMS_WALLET_TOPUP_ITEM => $amount ) );
	wp_safe_redirect( wc_get_checkout_url() );
	exit;
}

// قیمتِ خطِ سبد = مبلغِ شارژ.
add_action( 'woocommerce_before_calculate_totals', 'farazsms_wallet_topup_set_price', 20, 1 );
function farazsms_wallet_topup_set_price( $cart ) {
	if ( is_admin() && ! ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
		return;
	}
	foreach ( $cart->get_cart() as $item ) {
		if ( ! empty( $item[ FARAZSMS_WALLET_TOPUP_ITEM ] ) && isset( $item['data'] ) ) {
			$item['data']->set_price( (float) $item[ FARAZSMS_WALLET_TOPUP_ITEM ] );
		}
	}
}

// نمایشِ مبلغِ شارژ زیرِ آیتمِ سبد.
add_filter( 'woocommerce_get_item_data', 'farazsms_wallet_topup_item_data', 10, 2 );
function farazsms_wallet_topup_item_data( $data, $item ) {
	if ( ! empty( $item[ FARAZSMS_WALLET_TOPUP_ITEM ] ) ) {
		$data[] = array( 'key' => 'مبلغِ شارژ', 'value' => number_format( (float) $item[ FARAZSMS_WALLET_TOPUP_ITEM ] ) . ' تومان' );
	}
	return $data;
}

// انتقالِ مبلغ به آیتمِ سفارش.
add_action( 'woocommerce_checkout_create_order_line_item', 'farazsms_wallet_topup_line_item', 10, 4 );
function farazsms_wallet_topup_line_item( $line_item, $cart_item_key, $values, $order ) {
	if ( ! empty( $values[ FARAZSMS_WALLET_TOPUP_ITEM ] ) ) {
		$line_item->add_meta_data( FARAZSMS_WALLET_TOPUP_ITEM, (float) $values[ FARAZSMS_WALLET_TOPUP_ITEM ], true );
	}
}

// ── واریز پس از پرداخت (یک‌بار برای هر سفارش) ─────────────────────────────
add_action( 'woocommerce_payment_complete', 'farazsms_wallet_topup_credit_order', 20, 1 );
add_action( 'woocommerce_order_status_completed', 'farazsms_wallet_topup_credit_order', 20, 1 );
add_action( 'woocommerce_order_status_processing', 'farazsms_wallet_topup_credit_order', 20, 1 );
function farazsms_wallet_topup_credit_order( $order_id ) {
	if ( ! farazsms_wallet_topup_is_enabled() || ! function_exists( 'wc_get_order' ) ) {
		return;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	// گاردِ یک‌بار به‌ازای سفارش.
	if ( $order->get_meta( '_farazsms_topup_credited' ) ) {
		return;
	}
	// جمعِ مبلغِ آیتم‌های شارژ = مبلغِ واقعاً پرداخت‌شده (get_total پس از تخفیف)، نه مبلغِ درخواستی.
	// v3.21.93: قبلاً از متای درخواستی خوانده می‌شد؛ با کدِ تخفیف کاربر کمتر می‌پرداخت ولی مبلغِ
	// کامل واریز می‌شد (پولِ رایگان). حالا فقط چیزی که پرداخت شده اعتبار می‌شود.
	$topup_total = 0.0;
	foreach ( $order->get_items() as $item ) {
		$is_topup = ( (float) $item->get_meta( FARAZSMS_WALLET_TOPUP_ITEM ) > 0 )
			|| ( method_exists( $item, 'get_product_id' ) && farazsms_wallet_topup_is_topup_product( $item->get_product_id() ) );
		if ( $is_topup ) {
			$topup_total += (float) $item->get_total(); // مبلغِ خطِ محصولِ شارژ پس از تخفیف
		}
	}
	if ( $topup_total <= 0 ) {
		return;
	}

	$user_id = (int) $order->get_user_id();
	if ( $user_id <= 0 ) {
		// مهمان: نمی‌توان به کیف پول واریز کرد. به‌جای بازگشتِ خاموش، ردِ پرِ صدا بگذار تا مدیر
		// دستی رسیدگی کند (سفارشِ شارژِ بی‌صاحب).
		$order->update_meta_data( '_farazsms_topup_unresolved', $topup_total );
		$order->add_order_note( sprintf( '⚠️ سفارشِ شارژِ کیف پول به مبلغ %s تومان بدونِ کاربر (مهمان) ثبت شد؛ اعتبار واریز نشد. لطفاً دستی رسیدگی کنید.', number_format( $topup_total ) ) );
		$order->save();
		return;
	}

	$s        = farazsms_wallet_topup_settings();
	$credited = farazsms_wallet_add_credit( $user_id, $topup_total, array(
		'source'      => 'topup',
		'order_id'    => (int) $order_id,
		'expiry_days' => max( 0, (int) $s['expiry_days'] ),
		'description' => 'شارژ کیف پول',
	) );
	if ( ! $credited ) {
		return;
	}
	$order->update_meta_data( '_farazsms_topup_credited', $topup_total );
	$order->add_order_note( sprintf( 'مبلغ %s تومان به کیف پولِ فراز کاربر واریز شد.', number_format( $topup_total ) ) );
	$order->save();

	// پیامکِ تأیید.
	$pattern = trim( (string) $s['pattern_code'] );
	if ( $pattern !== '' ) {
		$mobile = (string) $order->get_billing_phone();
		$mobile = farazsms_normalize_phone( $mobile );
		if ( $mobile !== '' ) {
			$balance = (float) farazsms_wallet_balance( $user_id );
			// روی هوکِ payment_complete اجرا می‌شود — یعنی مشتری در حالِ بازگشت
			// از درگاه است و منتظرِ همین درخواست. واریز بالاتر انجام شده و ثبت
			// شده؛ فقط ارسال به صف می‌رود. خطِ تبلیغاتی باید حفظ شود.
			farazsms_queue_send( 'wallet-topup', $mobile, $pattern, array(
				'amount'  => number_format( $topup_total ),
				'balance' => number_format( $balance ),
			), array( 'order_id' => (int) $order->get_id() ) );
		}
	}
}

// آیتمِ شارژ نباید با کیف پول پرداخت شود (وگرنه شارژ با موجودیِ خودِ کیف پول بی‌معنی می‌شود).
// farazsms_wallet_apply_fee این تابع را چک می‌کند (اگر موجود باشد).

// v3.21.93: کدِ تخفیف روی محصولِ شارژ اعمال نشود تا «پرداختی == اعتبارِ واریزی» بماند و راهِ
// پولِ رایگان بسته شود. (fixed_cart سراسری هم اثری ندارد چون اعتبار از get_total واقعی خوانده می‌شود.)
add_filter( 'woocommerce_coupon_is_valid_for_product', 'farazsms_wallet_topup_no_coupon', 10, 4 );
function farazsms_wallet_topup_no_coupon( $valid, $product, $coupon, $item ) {
	if ( $product && method_exists( $product, 'get_meta' ) && $product->get_meta( FARAZSMS_WALLET_TOPUP_META ) === 'yes' ) {
		return false;
	}
	return $valid;
}

// v3.21.93: با مرجوعیِ سفارشِ شارژ، اعتبارِ واریزشده باطل شود (جلوگیری از نشت: پس‌گرفتنِ پول +
// نگه‌داشتنِ موجودی).
add_action( 'woocommerce_order_refunded', 'farazsms_wallet_topup_on_refund', 10, 2 );
function farazsms_wallet_topup_on_refund( $order_id, $refund_id ) {
	if ( ! function_exists( 'wc_get_order' ) || ! function_exists( 'farazsms_wallet_reverse_by_order' ) ) {
		return;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order || ! $order->get_meta( '_farazsms_topup_credited' ) ) {
		return;
	}
	$user_id = (int) $order->get_user_id();
	if ( $user_id <= 0 ) {
		return;
	}
	// v3.21.95: فقط به‌اندازه‌ی مبلغِ همین مرجوعی باطل کن، نه کلِ اعتبار (مرجوعیِ جزئی نباید کلِ
	// موجودیِ کیف پول را بسوزاند). اگر مبلغِ مرجوعی مشخص نشد، به کلِ مرجوعیِ سفارش رجوع کن.
	$refund_amount = 0.0;
	$refund        = $refund_id ? wc_get_order( $refund_id ) : null;
	if ( $refund && method_exists( $refund, 'get_amount' ) ) {
		$refund_amount = abs( (float) $refund->get_amount() );
	}
	if ( $refund_amount <= 0 && method_exists( $order, 'get_total_refunded' ) ) {
		$refund_amount = abs( (float) $order->get_total_refunded() );
	}
	if ( $refund_amount <= 0 ) {
		return; // چیزی برای باطل‌کردن نیست.
	}
	$reversed = farazsms_wallet_reverse_by_order( $user_id, (int) $order_id, 'topup', $refund_amount );
	if ( $reversed > 0 ) {
		$order->add_order_note( sprintf( 'به‌دلیلِ مرجوعیِ %s تومان، همان مقدار از اعتبارِ کیف پولِ این سفارش باطل شد.', number_format( $reversed ) ) );
		$order->save();
	}
}

// ── شورت‌کدِ فرمِ شارژ ────────────────────────────────────────────────────
add_shortcode( 'farazsms_wallet_topup', 'farazsms_wallet_topup_shortcode' );
function farazsms_wallet_topup_shortcode() {
	if ( ! farazsms_wallet_topup_is_enabled() ) {
		return '';
	}
	if ( ! is_user_logged_in() ) {
		return '<div style="direction:rtl;color:#64748b;font-size:13px;">برای شارژ کیف پول ابتدا وارد شوید.</div>';
	}
	$s        = farazsms_wallet_topup_settings();
	$packages = array_filter( array_map( 'trim', explode( ',', (string) $s['packages'] ) ) );
	$balance  = (float) farazsms_wallet_balance( get_current_user_id() );
	ob_start();
	?>
	<form method="post" class="farazsms-topup-form" style="direction:rtl;max-width:420px;margin:12px auto;padding:20px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;">
		<div style="font-size:15px;font-weight:700;margin-bottom:4px;">شارژ کیف پول</div>
		<div style="font-size:12.5px;color:#64748b;margin-bottom:14px;">موجودی فعلی: <strong><?php echo esc_html( number_format( $balance ) ); ?> تومان</strong></div>
		<?php if ( $packages ) : ?>
			<div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px;">
				<?php foreach ( $packages as $p ) : $p = (float) preg_replace( '/[^0-9]/', '', $p ); if ( $p <= 0 ) continue; ?>
					<button type="button" class="farazsms-topup-pkg" data-amount="<?php echo esc_attr( $p ); ?>" style="flex:1 1 90px;background:#eef2ff;border:1px solid #c7d2fe;color:#263f67;border-radius:8px;padding:8px;font-size:13px;font-weight:600;cursor:pointer;"><?php echo esc_html( number_format( $p ) ); ?></button>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
		<input type="number" name="farazsms_topup_amount" class="farazsms-topup-amount" min="<?php echo esc_attr( (int) $s['min'] ); ?>" max="<?php echo esc_attr( (int) $s['max'] ); ?>" placeholder="مبلغِ دلخواه (تومان)" required style="width:100%;padding:10px 12px;border:1px solid #d1d5db;border-radius:8px;font-size:14px;box-sizing:border-box;margin-bottom:12px;direction:ltr;text-align:left;">
		<input type="hidden" name="farazsms_do_topup" value="1">
		<?php wp_nonce_field( 'farazsms_topup', 'farazsms_topup_nonce' ); ?>
		<button type="submit" style="width:100%;background:#365891;color:#fff;border:0;border-radius:8px;padding:11px;font-size:14px;font-weight:700;cursor:pointer;">پرداخت و شارژ</button>
		<p style="font-size:11px;color:#94a3b8;margin:8px 0 0;">حداقل <?php echo esc_html( number_format( (float) $s['min'] ) ); ?> — حداکثر <?php echo esc_html( number_format( (float) $s['max'] ) ); ?> تومان</p>
	</form>
	<script>
	(function(){
		var f=document.currentScript.previousElementSibling; if(!f||!f.classList.contains('farazsms-topup-form')){f=document.querySelector('.farazsms-topup-form');}
		if(!f) return; var amt=f.querySelector('.farazsms-topup-amount');
		f.querySelectorAll('.farazsms-topup-pkg').forEach(function(b){ b.addEventListener('click',function(){ amt.value=b.getAttribute('data-amount'); }); });
	})();
	</script>
	<?php
	return ob_get_clean();
}

// ── تنظیماتِ ادمین ────────────────────────────────────────────────────────
add_action( 'admin_menu', 'farazsms_wallet_topup_menu', 62 );
function farazsms_wallet_topup_menu() {
	add_submenu_page(
		'farazsms',
		'شارژ کیف پول',
		'💳 شارژ کیف پول',
		'manage_options',
		'farazsms-wallet-topup',
		'farazsms_wallet_topup_render_page'
	);
}

add_action( 'admin_post_farazsms_wallet_topup_save', 'farazsms_wallet_topup_handle_save' );
function farazsms_wallet_topup_handle_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die();
	}
	check_admin_referer( 'farazsms_wallet_topup_save' );
	$s = farazsms_wallet_topup_settings();
	$s['enabled']      = isset( $_POST['topup_enabled'] ) ? '1' : '0';
	$s['packages']     = sanitize_text_field( wp_unslash( $_POST['topup_packages'] ?? '' ) );
	$s['min']          = max( 1, (float) ( $_POST['topup_min'] ?? 50000 ) );
	$s['max']          = max( $s['min'], (float) ( $_POST['topup_max'] ?? 50000000 ) );
	$s['expiry_days']  = max( 0, (int) ( $_POST['topup_expiry_days'] ?? 0 ) );
	$s['pattern_code'] = sanitize_text_field( wp_unslash( $_POST['topup_pattern_code'] ?? '' ) );
	update_option( 'farazsms_wallet_topup_settings', $s, false );
	if ( $s['enabled'] === '1' ) {
		farazsms_wallet_topup_product_id(); // اطمینان از وجودِ محصول.
	}
	wp_safe_redirect( add_query_arg( 'saved', '1', wp_get_referer() ?: admin_url( 'admin.php?page=farazsms-wallet-topup' ) ) );
	exit;
}

function farazsms_wallet_topup_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی غیرمجاز.' );
	}
	$s        = farazsms_wallet_topup_settings();
	$wc_ok    = class_exists( 'WooCommerce' );
	?>
	<div class="wrap" style="direction:rtl;max-width:820px;">
		<h1 style="font-size:21px;">💳 شارژ کیف پول از طریق درگاه</h1>
		<?php if ( isset( $_GET['saved'] ) ) : ?>
			<div style="background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46;padding:10px 14px;border-radius:8px;margin:10px 0;">✓ ذخیره شد.</div>
		<?php endif; ?>
		<?php if ( ! $wc_ok ) : ?>
			<div style="background:#fef2f2;border:1px solid #fecaca;color:#b91c1c;padding:10px 14px;border-radius:8px;margin:10px 0;">این قابلیت نیازمندِ ووکامرس است.</div>
		<?php endif; ?>
		<p style="color:#64748b;font-size:13px;">کاربر مبلغِ دلخواه را از طریقِ درگاهِ ووکامرس پرداخت می‌کند و همان مبلغ به کیف پولش واریز می‌شود؛ سپس در خریدهای بعدی از موجودی استفاده می‌کند.</p>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:20px;margin-top:12px;">
			<input type="hidden" name="action" value="farazsms_wallet_topup_save">
			<?php wp_nonce_field( 'farazsms_wallet_topup_save' ); ?>

			<label style="display:flex;align-items:center;gap:10px;margin-bottom:16px;">
				<input type="checkbox" class="farazsms-toggle" name="topup_enabled" value="1" <?php checked( $s['enabled'], '1' ); ?> style="width:18px;height:18px;">
				<span style="font-weight:700;">فعال بودنِ شارژ کیف پول</span>
			</label>

			<p><label style="display:block;font-size:12.5px;font-weight:600;margin-bottom:4px;">بسته‌های پیشنهادی (تومان، با کاما)</label>
			<input type="text" name="topup_packages" value="<?php echo esc_attr( $s['packages'] ); ?>" style="width:100%;max-width:420px;padding:9px 12px;border:1px solid #cbd5e1;border-radius:7px;direction:ltr;text-align:left;"></p>

			<div style="display:flex;gap:12px;flex-wrap:wrap;">
				<p><label style="display:block;font-size:12.5px;font-weight:600;margin-bottom:4px;">حداقل مبلغ</label>
				<input type="number" name="topup_min" value="<?php echo esc_attr( (int) $s['min'] ); ?>" style="width:160px;padding:9px 12px;border:1px solid #cbd5e1;border-radius:7px;"></p>
				<p><label style="display:block;font-size:12.5px;font-weight:600;margin-bottom:4px;">حداکثر مبلغ</label>
				<input type="number" name="topup_max" value="<?php echo esc_attr( (int) $s['max'] ); ?>" style="width:160px;padding:9px 12px;border:1px solid #cbd5e1;border-radius:7px;"></p>
				<p><label style="display:block;font-size:12.5px;font-weight:600;margin-bottom:4px;">انقضای اعتبار (روز، ۰=بی‌انقضا)</label>
				<input type="number" name="topup_expiry_days" value="<?php echo esc_attr( (int) $s['expiry_days'] ); ?>" style="width:160px;padding:9px 12px;border:1px solid #cbd5e1;border-radius:7px;"></p>
			</div>

			<p><label style="display:block;font-size:12.5px;font-weight:600;margin:6px 0 4px;">کد پترنِ پیامکِ تأییدِ شارژ (اختیاری)</label>
			<input type="hidden" name="topup_pattern_code" value="<?php echo esc_attr( $s['pattern_code'] ); ?>">
			<?php
			farazsms_feature_pattern_builder_ui( 'wallet_topup', $s['message'], array( '%amount%', '%balance%' ), 'topup_pattern_code' );
			?></p>

			<div style="background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;padding:10px 14px;border-radius:8px;margin:8px 0;font-size:12.5px;">
				شورت‌کدِ فرمِ شارژ برای صفحه/حساب کاربری: <code dir="ltr">[farazsms_wallet_topup]</code>
			</div>

			<button type="submit" class="button button-primary" style="padding:8px 26px;">💾 ذخیره</button>
		</form>
	</div>
	<?php
}
