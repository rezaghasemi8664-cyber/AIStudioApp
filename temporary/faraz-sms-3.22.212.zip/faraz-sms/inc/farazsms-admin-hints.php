<?php
/**
 * Admin Hints — v3.21.20
 *
 * اعلانِ یک‌باره‌ی بالای پیشخوان: به مدیر می‌گوید همه‌ی قابلیت‌های پیامکی به‌صورتِ پیش‌فرض
 * فعال‌اند و می‌تواند هرکدام را که لازم ندارد غیرفعال/شخصی‌سازی کند. هدف: کاهشِ تیکت‌های
 * «چطور این بخش را خاموش کنم؟». قابلِ‌رد است و با کلیکِ «متوجه شدم» دیگر نمایش داده نمی‌شود
 * (در user_meta ذخیره می‌شود، پس per-user و دائمی است).
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_FEATURES_NOTICE_META = 'farazsms_features_notice_dismissed';

/**
 * نمایشِ اعلان در بالای صفحاتِ پیشخوان (تا وقتی مدیر آن را نبسته).
 */
add_action( 'admin_notices', 'farazsms_features_admin_notice' );
function farazsms_features_admin_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( get_user_meta( get_current_user_id(), FARAZSMS_FEATURES_NOTICE_META, true ) === '1' ) {
		return;
	}

	$nonce = wp_create_nonce( 'farazsms_dismiss_features_notice' );
	?>
	<div class="notice notice-info is-dismissible farazsms-features-notice" data-nonce="<?php echo esc_attr( $nonce ); ?>" style="border-right:4px solid #4571ba;">
		<p style="font-size:13.5px; line-height:2; margin:10px 0;">
			<strong>🎉 <?php esc_html_e( 'به فراز اس ام اس خوش آمدید', 'farazsms' ); ?></strong><br>
			<?php esc_html_e( 'همه‌ی قابلیت‌های پیامکیِ افزونه به‌صورت پیش‌فرض فعال هستند. می‌توانید بر اساس نیاز خودتان هر بخش را شخصی‌سازی کنید و بخش‌هایی را که لازم ندارید از تنظیماتِ همان بخش غیرفعال کنید.', 'farazsms' ); ?>
		</p>
		<p style="margin:10px 0;">
			<button type="button" class="button button-primary farazsms-features-notice-dismiss">
				<?php esc_html_e( 'متوجه شدم، دیگر نشان نده', 'farazsms' ); ?>
			</button>
		</p>
	</div>
	<script>
	(function(){
		var box = document.querySelector('.farazsms-features-notice');
		if (!box) { return; }
		function dismiss(){
			var fd = new FormData();
			fd.append('action', 'farazsms_dismiss_features_notice');
			fd.append('nonce', box.getAttribute('data-nonce'));
			fetch(ajaxurl, { method:'POST', credentials:'same-origin', body: fd });
		}
		var btn = box.querySelector('.farazsms-features-notice-dismiss');
		if (btn) { btn.addEventListener('click', function(){ dismiss(); box.style.display='none'; }); }
		// کلیک روی ضربدرِ پیش‌فرضِ وردپرس هم همان را دائمی می‌کند.
		box.addEventListener('click', function(e){
			if (e.target && e.target.classList && e.target.classList.contains('notice-dismiss')) { dismiss(); }
		});
	})();
	</script>
	<?php
}

/**
 * ذخیره‌ی «دیگر نشان نده» در user_meta.
 */
add_action( 'wp_ajax_farazsms_dismiss_features_notice', 'farazsms_dismiss_features_notice_ajax' );
function farazsms_dismiss_features_notice_ajax() {
	if ( ! current_user_can( 'manage_options' )
		|| ! check_ajax_referer( 'farazsms_dismiss_features_notice', 'nonce', false ) ) {
		wp_send_json_error( array(), 403 );
	}
	update_user_meta( get_current_user_id(), FARAZSMS_FEATURES_NOTICE_META, '1' );
	wp_send_json_success();
}
