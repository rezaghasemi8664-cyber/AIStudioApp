<?php
/**
 * Login Module Bridge — v3.13.22 (rewrite)
 *
 * اصول طراحی این بار (مطابق درخواست کاربر):
 *
 *   ۱) همه تنظیمات ماژول login در همان صفحه ما رندر می‌شوند — صفحه جداگانه
 *      «تنظیمات پیشرفته ماژول» وجود ندارد.
 *
 *   ۲) فیلد API Key حذف شده — از option('farazsms_apikey') افزونه اصلی استفاده می‌شود.
 *
 *   ۳) فیلد Sender حذف شده — از option('farazsms_sender') افزونه اصلی استفاده می‌شود.
 *
 *   ۴) تب «New User Signup Bonus» (wallet) حذف شده — افزونه ما wallet داریم.
 *
 *   ۵) تب «WooCommerce SMS» (woo_sms) حذف شده — افزونه ما WC SMS داریم.
 *
 *   ۶) فیلدهای WC داخل تب general (checkout_redirect, woocommerce_login_redirect) حذف.
 *
 *   ۷) منوی top-level خود ماژول (farazsms_login_settings) به‌کلی remove شده.
 *
 *   ۸) استایل صفحه: مطابق قاب یکپارچه ما (سفید، border-radius، رنگ ایندیگو، ...).
 *
 *   ۹) admin part ماژول همیشه load می‌شود تا All_Settings() در دسترس باشد.
 *      frontend part فقط با toggle=on فعال می‌شود.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

function farazsms_login_module_is_enabled() {
	return get_option( 'farazsms_login_module_enabled', '0' ) === '1';
}

/**
 * تضمین می‌کنیم api_key و sender ماژول login همیشه با تنظیمات اصلی افزونه
 * (farazsms_apikey, farazsms_sender) sync باشد — حتی اگر کاربر هرگز ذخیره نکرد.
 * این filter روی هر خواندن option اعمال می‌شود.
 */
add_filter( 'option_farazsms_login_settings', 'farazsms_login_inject_main_credentials' );
function farazsms_login_inject_main_credentials( $value ) {
	if ( ! is_array( $value ) ) {
		$value = array();
	}
	if ( ! isset( $value['sms'] ) || ! is_array( $value['sms'] ) ) {
		$value['sms'] = array();
	}
	// override همیشگی — کاربر نباید بتواند مقدار دیگری در ماژول ست کند.
	$value['sms']['api_key'] = (string) get_option( 'farazsms_apikey', '' );
	$farazsms_sender = trim( (string) get_option( 'farazsms_sender', '' ) );
	if ( $farazsms_sender !== '' ) {
		$value['sms']['sender'] = $farazsms_sender;
	} elseif ( ! isset( $value['sms']['sender'] ) || $value['sms']['sender'] === '' ) {
		$value['sms']['sender'] = '90008361'; // fallback پیش‌فرض فراز
	}
	return $value;
}

/**
 * Load ماژول — admin همیشه، frontend شرطی.
 *
 * v3.20.5 CRITICAL FIX: اگر کاربر افزونه‌ی standalone `farazsms-login` را هم
 * نصب داشته باشد (در /wp-content/plugins/farazsms-login/)، load کردن ماژول
 * bundled ما باعث «Constant FarazSMS__FILE__ already defined» Notice می‌شود.
 *
 * این Notice به‌صورت HTML قبل از headers چاپ می‌شود → `wp_redirect()` به
 * درگاه پرداخت fail می‌کند → **کاربر نمی‌تواند وارد درگاه پرداخت شود**.
 *
 * راه‌حل: اگر standalone فعال است، ماژول bundled را load نکن.
 */
/**
 * تصمیمِ بارگذاریِ ماژولِ ورودِ باندل‌شده — با تعویق به plugins_loaded.
 *
 * v3.22.72 (باگِ میهن‌پنل): پیش‌تر این تصمیم در file-scope (حینِ بارگذاریِ افزونه) گرفته می‌شد. اگر
 * faraz-sms زودتر از افزونه‌ی جدای farazsms-login بارگذاری می‌شد، در آن لحظه هنوز کلاس/ثابتِ استندالون
 * تعریف نبود؛ و اگر نامِ فایلِ اصلیِ استندالون هم عوض شده بود، regex هم ردش می‌کرد → هر دو نسخه بارگذاری
 * → «Notice: Constant already defined» → چون روی این هاست‌ها display_errors روشن است، Notice ابتدای
 * پاسخِ Ajax چاپ می‌شد و JSON را خراب می‌کرد (فرمِ OTPِ میهن‌پنل: پیامک ارسال می‌شد ولی کاربر به صفحه‌ی
 * واردکردنِ کد هدایت نمی‌شد). راه‌حل: این تصمیم را تا plugins_loaded (اولویت ۰) به تعویق می‌اندازیم؛ تا آن
 * لحظه همه‌ی افزونه‌ها بارگذاری شده‌اند و تشخیصِ استندالون قطعی است (class_exists / defined همیشه معتبر).
 *
 * ایمن است چون تنها مصرف‌کننده‌های FARAZSMS_LOGIN_BUNDLED / FARAZSMS_LOGIN_FRONTEND_ENABLED روی
 * init و بعد از آن اجرا می‌شوند (نه در file-scope پیش از plugins_loaded).
 */
function farazsms_login_bridge_maybe_load_module() {
	if ( defined( 'FARAZSMS_LOGIN_BUNDLED' ) ) {
		return; // قبلاً تصمیم گرفته و بارگذاری شده.
	}
	$module_main = dirname( __DIR__ ) . '/modules/farazsms-login/farazsms-login.php';

	// تشخیص standalone farazsms-login plugin
	$active_plugins = (array) get_option( 'active_plugins', array() );
	if ( is_multisite() ) {
		$active_plugins = array_merge( $active_plugins, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
	}
	$standalone_active = false;

	// (الف) قطعی‌ترین نشانه (روی plugins_loaded همیشه معتبر): کلاس/ثابتِ استندالون تعریف است.
	// این‌جا صرفِ‌نظر از نام/پوشه‌ی استندالون همه‌ی حالت‌ها را می‌گیرد.
	if ( class_exists( 'FarazSMS\\Login' ) || defined( 'FarazSMS__FILE__' ) ) {
		$standalone_active = true;
	}
	// (ب) fast-path از لیستِ افزونه‌های فعال — الگوی پوشه (مقاوم به تغییرِ نامِ فایلِ اصلیِ داخلِ پوشه‌ی
	// farazsms-login و بازنام‌شدنِ پوشه به -2/-3). پوشه باید دقیقاً farazsms-login یا farazsms-login-<رقم>
	// باشد؛ پس farazsms-login-widgets (که -widgets است، نه -<رقم> و نه /) false-match نمی‌شود. فولدرِ
	// خودِ ما faraz-sms است و اصلاً match نمی‌شود.
	if ( ! $standalone_active ) {
		foreach ( $active_plugins as $plugin_path ) {
			// دو الگوی fast-path (دفاعِ لایه‌ای؛ گارانتیِ اصلی همان class_exists بالاست):
			//  (۱) پوشه‌ی farazsms-login یا بازنام‌شده‌ی عددی (‎-2/-3) با هر نامِ فایلِ اصلی.
			//  (۲) هر پوشه‌ی *farazsms-login که فایلِ اصلی‌اش استانداردِ farazsms-login.php است
			//      (پوشه‌ی بازنام‌شده‌ی غیرعددی مثلِ farazsms-login-register را هم می‌گیرد).
			// هیچ‌کدام farazsms-login-widgets/… (که فایلِ اصلی‌اش farazsms-login.php نیست و -widgets عددی نیست)
			// را false-match نمی‌کند؛ پوشه‌ی خودِ ما هم faraz-sms است و اصلاً match نمی‌شود.
			if ( preg_match( '#(^|/)farazsms-login(-\d+)?/[^/]+\.php$#i', (string) $plugin_path )
				|| preg_match( '#(^|/)farazsms-login[^/]*/farazsms-login\.php$#i', (string) $plugin_path ) ) {
				$standalone_active = true;
				break;
			}
		}
	}

	if ( $standalone_active ) {
		// نسخه‌ی باندل را بارگذاری نکن (تا double-load/Notice رخ ندهد) و به ادمین یک‌بار اطلاع بده.
		add_action( 'admin_notices', 'farazsms_login_module_duplicate_notice' );
		return;
	}
	if ( ! file_exists( $module_main ) ) {
		return;
	}
	// نسخه‌ی bundled داخل افزونه‌ی فراز اس ام اس — فقط وقتی افزونه‌ی standalone فعال نیست.
	// با تعریف این ثابت، کیف‌پول، هدیه‌ی عضویتِ ماژول، و پیامک سفارشات ووکامرسِ ماژول
	// بارگذاری نمی‌شوند (کیف‌پول بومی + PWSMS جایگزین آن‌ها هستند) تا تداخل پیش نیاید.
	define( 'FARAZSMS_LOGIN_BUNDLED', true );
	if ( ! defined( 'FARAZSMS_LOGIN_FRONTEND_ENABLED' ) ) {
		define( 'FARAZSMS_LOGIN_FRONTEND_ENABLED', farazsms_login_module_is_enabled() );
	}
	require_once $module_main;
}
// اولویت ۰ روی plugins_loaded: زودتر از init (که مصرف‌کننده‌ها آنجا هستند) و پس از بارگذاریِ همه‌ی افزونه‌ها.
add_action( 'plugins_loaded', 'farazsms_login_bridge_maybe_load_module', 0 );

/**
 * admin notice تداخلِ نسخه‌ی جدا و باندل — یک‌بار به ادمین (کاربر باید یکی را غیرفعال کند).
 */
function farazsms_login_module_duplicate_notice() {
	if ( ! current_user_can( 'manage_options' ) ) return;
	?>
	<div class="notice notice-error">
		<p>
			<strong>⚠ تداخل افزونه فراز اس ام اس:</strong>
			شما هم «افزونه فراز اس ام اس» را نصب کرده‌اید (که شامل ماژول ورود/ثبت‌نام است)
			و هم افزونه‌ی <code>farazsms-login</code> به‌صورت جداگانه فعال است.
			این تداخل باعث «Notice: Constant already defined» می‌شود که می‌تواند
			<strong>redirect به درگاه پرداخت و پاسخِ پیامکِ فرم‌ها (مثلِ میهن‌پنل) را خراب کند</strong>.
		</p>
		<p>
			راه‌حل: از منوی «افزونه‌ها» افزونه‌ی <code>farazsms-login</code> را
			<strong>غیرفعال</strong> کنید — ماژول ورود/ثبت‌نام به‌صورت داخلی در افزونه‌ی فراز اس ام اس موجود است.
		</p>
	</div>
	<?php
}

/**
 * اجرای activator ماژول (ساخت جدول farazsms_verification، تنظیمات پیش‌فرض، صفحه ورود).
 * فایل activator با require_once بارگذاری می‌شود (باگ قبلی: فقط class_exists چک می‌شد
 * بدون require → کلاس هیچ‌وقت لود نمی‌شد و جدول ساخته نمی‌شد).
 *
 * @return bool موفقیت
 */
function farazsms_login_module_run_activator() {
	$activator = dirname( __DIR__ ) . '/modules/farazsms-login/includes/class-farazsms-activator.php';
	if ( ! class_exists( '\\FarazSMS\\Activator' ) && file_exists( $activator ) ) {
		require_once $activator;
	}
	if ( class_exists( '\\FarazSMS\\Activator' ) ) {
		\FarazSMS\Activator::activate();
		return true;
	}
	return false;
}

/**
 * Activator هنگام روشن شدن toggle.
 */
add_action( 'update_option_farazsms_login_module_enabled', 'farazsms_login_module_handle_toggle', 10, 2 );
function farazsms_login_module_handle_toggle( $old, $new ) {
	if ( $new === '1' && $old !== '1' ) {
		farazsms_login_module_run_activator();
		update_option( 'farazsms_login_module_db_ready', '1', true );

		// «جایگزینیِ فرم‌های ورود/ثبت‌نامِ سایت» هنگامِ فعال‌سازیِ ماژول پیش‌فرض روشن باشد.
		// activator این پیش‌فرض را فقط با add_option (وقتی آپشن وجود ندارد) می‌نویسد؛ روی سایتی
		// که farazsms_login_settings از قبل هست (مثلاً bridge کلید API را نوشته) هرگز مادّی نمی‌شد.
		// اینجا صریح می‌نویسیمش — فقط اگر کاربر قبلاً خودش تنظیمی نکرده باشد (کلید غایب باشد).
		$s = get_option( 'farazsms_login_settings', array() );
		if ( ! is_array( $s ) ) {
			$s = array();
		}
		if ( ! isset( $s['general'] ) || ! is_array( $s['general'] ) ) {
			$s['general'] = array();
		}
		if ( ! isset( $s['general']['replace_default_login_forms'] ) ) {
			$s['general']['replace_default_login_forms'] = '1';
			update_option( 'farazsms_login_settings', $s, false );
		}
	}
}

/**
 * تضمینِ وجودِ جداولِ ماژول در حالت bundled — یک‌بار.
 *
 * چون activation hook برای نسخه‌ی bundled اجرا نمی‌شود، جدول farazsms_verification
 * هرگز ساخته نمی‌شد؛ در نتیجه کدِ OTP ذخیره نمی‌شد و هر کدی «اشتباه» اعلام می‌گشت
 * (خطای DB: Table 'wp_farazsms_verification' doesn't exist). این تابع یک‌بار آن را می‌سازد.
 */
add_action( 'init', 'farazsms_login_module_ensure_tables', 9 );
function farazsms_login_module_ensure_tables() {
	if ( ! defined( 'FARAZSMS_LOGIN_BUNDLED' ) ) {
		return; // نسخه‌ی standalone خودش هنگام فعال‌سازی جدول را می‌سازد.
	}
	global $wpdb;
	$table = $wpdb->prefix . 'farazsms_verification';

	// مهم: به پرچمِ db_ready تنها اعتماد نکن. روی بعضی سایت‌ها (نسخه‌ی باگ‌دارِ قبلی)
	// پرچم '1' شده بود اما جدول واقعاً ساخته نشده بود → هر کدِ OTP «اشتباه» می‌شد.
	// پس وجودِ واقعیِ جدول را تأیید می‌کنیم. برای پرهیز از SHOW TABLES در هر request،
	// نتیجه‌ی مثبت را ۱۲ ساعت کش می‌کنیم.
	if ( get_option( 'farazsms_login_module_db_ready' ) === '1'
		&& get_transient( 'farazsms_login_module_db_verified' ) === '1' ) {
		return;
	}

	$exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );

	if ( ! $exists ) {
		// جدول نیست — مستقیم و مطمئن بساز (وابسته به موفقیتِ کاملِ activate() نباش).
		farazsms_login_module_create_verification_table();
		$exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );
		if ( ! $exists ) {
			// fallback نهایی: کلِ activator (options + صفحه + جداول).
			farazsms_login_module_run_activator();
			$exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );
		}
	}

	if ( $exists ) {
		update_option( 'farazsms_login_module_db_ready', '1', true );
		set_transient( 'farazsms_login_module_db_verified', '1', 12 * HOUR_IN_SECONDS );
	} else {
		// نتوانستیم بسازیم — پرچم را پاک کن تا در request بعدی دوباره تلاش شود.
		delete_option( 'farazsms_login_module_db_ready' );
	}
}

/**
 * ساختِ مستقیمِ جدولِ farazsms_verification با همان schema فعال‌سازی.
 * مستقل از activate() کامل تا حتی اگر بخش‌های دیگرِ activate شکست بخورند، جدول ساخته شود.
 *
 * @return bool وجودِ جدول پس از تلاش
 */
function farazsms_login_module_create_verification_table() {
	global $wpdb;
	$table           = $wpdb->prefix . 'farazsms_verification';
	$charset_collate = $wpdb->get_charset_collate();
	$sql             = "CREATE TABLE $table (
		id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
		verification VARCHAR(100) NOT NULL,
		code VARCHAR(10) NOT NULL,
		expire_date DATETIME NULL,
		PRIMARY KEY (id),
		UNIQUE (verification)
	) $charset_collate;";
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );
	return ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );
}

/**
 * حذف کامل منوی top-level ماژول از سایدبار + submenu های wallet/shortcodes.
 */
add_action( 'admin_menu', 'farazsms_login_module_remove_module_menus', 99999 );
function farazsms_login_module_remove_module_menus() {
	remove_menu_page( 'farazsms_login_settings' );
	remove_submenu_page( 'farazsms_login_settings', 'farazsms-wallet' );
	remove_submenu_page( 'farazsms_login_settings', 'farazsms-shortcodes' );
}

/**
 * فیلتر تنظیمات ماژول — حذف فیلدهای api_key، sender و تب‌های ووکامرس/wallet.
 *
 * @param array $settings خروجی All_Settings() از ماژول
 * @return array تنظیمات فیلتر شده برای نمایش در صفحه ما
 */
function farazsms_login_filter_settings( $settings ) {
	if ( ! is_array( $settings ) ) {
		return array();
	}

	// حذف کامل تب‌های مرتبط با ووکامرس/wallet/slide:
	//   - wallet, woo_sms: افزونه اصلی این‌ها را دارد
	//   - slide (پاپ‌آپ خروج): چون افزونه ما لید مگنت دارد، redundant است
	unset( $settings['wallet'] );
	unset( $settings['woo_sms'] );
	unset( $settings['slide'] );

	// در تب SMS، api_key و sender را حذف می‌کنیم (از تنظیمات اصلی افزونه می‌آیند).
	if ( isset( $settings['sms']['settings'] ) && is_array( $settings['sms']['settings'] ) ) {
		unset( $settings['sms']['settings']['api_key'] );
		unset( $settings['sms']['settings']['sender'] );
		// sms_test هم لازم نیست — افزونه ما تست SMS دارد.
		unset( $settings['sms']['settings']['sms_test'] );
	}

	// در تب general فقط هدینگِ اضافیِ ووکامرس را حذف می‌کنیم.
	// v3.21.16: «اجبار به ورود در تسویه‌حساب» و «هدایت حساب ووکامرس» دیگر حذف نمی‌شوند —
	// کاربرانی که این گزینه‌ها از افزونه‌ی standaloneِ قبلی روی '1' مانده بود، چون UI نداشتند
	// نمی‌توانستند خاموش‌شان کنند. حالا در تبِ «تنظیمات عمومی» قابلِ مدیریت‌اند.
	if ( isset( $settings['general']['settings'] ) && is_array( $settings['general']['settings'] ) ) {
		unset( $settings['general']['settings']['headin_woocommerce'] );
	}

	return $settings;
}

/**
 * Save handler — برای ذخیره تنظیمات ماژول از فرم ما.
 */
function farazsms_login_save_settings() {
	if ( ( $_SERVER['REQUEST_METHOD'] ?? '' ) !== 'POST' ) {
		return false;
	}
	if ( ! isset( $_POST['farazsms_login_settings_submit'] ) ) {
		return false;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return false;
	}
	check_admin_referer( 'farazsms_login_settings', 'farazsms_login_settings_nonce' );

	// تنظیمات local (toggle + ask_name)
	// toggle: همیشه فرم در همه تب‌ها داراست → '1' یا '0'
	$enabled = isset( $_POST['farazsms_login_module_enabled'] ) ? '1' : '0';
	update_option( 'farazsms_login_module_enabled', $enabled, false );

	// ask_name: فقط در تب general در فرم می‌آید. در سایر تب‌ها، مقدار قبلی حفظ می‌شود
	// تا روی save در تب‌های دیگر، انتخاب کاربر reset نشود.
	if ( isset( $_POST['farazsms_login_ask_name'] ) ) {
		$ask_name = $_POST['farazsms_login_ask_name'] === 'yes' ? 'yes' : 'no';
		update_option( 'farazsms_login_ask_name', $ask_name, false );
	}
	if ( isset( $_POST['farazsms_login_gate_checkout_present'] ) ) {
		$gate_checkout = isset( $_POST['farazsms_login_gate_checkout'] ) ? '1' : '0';
		update_option( 'farazsms_login_gate_checkout', $gate_checkout, false );
	}

	// v3.22.68: تنظیماتِ تبِ «محدودیت‌ها و امنیت» (custom، خارج از schemaِ فراز).
	if ( isset( $_POST['farazsms_login_limits_present'] ) ) {
		$lim = farazsms_login_limits_settings();
		$lim['enabled']          = isset( $_POST['fzl_enabled'] ) ? '1' : '0';
		$lim['require_token']    = isset( $_POST['fzl_require_token'] ) ? '1' : '0';
		$lim['token_strict']     = isset( $_POST['fzl_token_strict'] ) ? '1' : '0';
		$lim['number_heuristic'] = isset( $_POST['fzl_number_heuristic'] ) ? '1' : '0';
		$lim['admin_alert']      = isset( $_POST['fzl_admin_alert'] ) ? '1' : '0';
		$lim['min_seconds']      = max( 0, min( 60, (int) ( $_POST['fzl_min_seconds'] ?? 3 ) ) );
		$lim['per_number_max']   = max( 1, min( 100, (int) ( $_POST['fzl_per_number_max'] ?? 5 ) ) );
		$lim['per_ip_max']       = max( 0, min( 1000, (int) ( $_POST['fzl_per_ip_max'] ?? 0 ) ) ); // ۰ = خاموش؛ نباید به‌زور روشن شود (پروکسی/CGNAT).
		$lim['global_max']       = max( 10, min( 100000, (int) ( $_POST['fzl_global_max'] ?? 500 ) ) ); // هم‌راستا با پیش‌فرضِ merge (۵۰۰).
		update_option( 'farazsms_login_limits', $lim, false );
	}

	// تنظیمات ماژول — در همان option اصلی farazsms_login_settings
	$current_module_settings = get_option( 'farazsms_login_settings', array() );
	if ( ! is_array( $current_module_settings ) ) {
		$current_module_settings = array();
	}

	$active_tab = isset( $_POST['active_tab'] ) ? sanitize_key( $_POST['active_tab'] ) : '';
	if ( $active_tab === '' || ! in_array( $active_tab, array( 'sms', 'appearance', 'general', 'slide' ), true ) ) {
		return true; // saved local-only
	}

	// مقادیر api_key و sender از تنظیمات اصلی افزونه ست می‌شود (override).
	if ( ! isset( $current_module_settings['sms'] ) || ! is_array( $current_module_settings['sms'] ) ) {
		$current_module_settings['sms'] = array();
	}
	$current_module_settings['sms']['api_key'] = (string) get_option( 'farazsms_apikey', '' );
	$current_module_settings['sms']['sender']  = (string) get_option( 'farazsms_sender', '' );

	// آرایه فیلدهای قابل ذخیره را از All_Settings می‌گیریم تا فقط فیلدهای معتبر همان تب را ذخیره کنیم.
	if ( ! class_exists( '\\FarazSMS\\Admin\\Settings' ) ) {
		return true;
	}
	$settings_obj = new \FarazSMS\Admin\Settings();
	$all_settings = farazsms_login_filter_settings( $settings_obj->All_Settings() );
	if ( ! isset( $all_settings[ $active_tab ]['settings'] ) ) {
		return true;
	}

	foreach ( $all_settings[ $active_tab ]['settings'] as $field_id => $field ) {
		$type = $field['type'] ?? 'text';
		if ( in_array( $type, array( 'heading', 'html', 'sms-test' ), true ) ) {
			continue;
		}
		$value = isset( $_POST[ $field_id ] ) ? $_POST[ $field_id ] : '';
		switch ( $type ) {
			case 'switch':
				$value = ! empty( $value ) ? '1' : '0';
				break;
			case 'number':
				$value = sanitize_text_field( $value );
				break;
			case 'textarea':
				$value = wp_kses_post( wp_unslash( $value ) );
				break;
			case 'color':
				$value = sanitize_hex_color_no_hash( ltrim( (string) $value, '#' ) );
				// خالی/نامعتبر → رشته‌ی خالی (نه '#')؛ وگرنه option آلوده و فیلد با value="#" رندر می‌شد.
				$value = ( $value !== null && $value !== '' ) ? '#' . $value : '';
				break;
			case 'file':
			case 'url':
				$value = esc_url_raw( $value );
				break;
			default:
				$value = sanitize_text_field( wp_unslash( $value ) );
		}
		$current_module_settings[ $active_tab ][ $field_id ] = $value;
	}

	update_option( 'farazsms_login_settings', $current_module_settings, false );
	return true;
}

function farazsms_login_gate_is_request_safe_to_redirect() {
	if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || is_user_logged_in() ) {
		return false;
	}
	if ( is_feed() || is_preview() || is_robots() || is_trackback() ) {
		return false;
	}
	return true;
}

function farazsms_login_gate_current_url() {
	$scheme = is_ssl() ? 'https://' : 'http://';
	$host   = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : wp_parse_url( home_url(), PHP_URL_HOST );
	$uri    = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';
	return esc_url_raw( $scheme . $host . $uri );
}

function farazsms_login_gate_login_url( $return_url ) {
	$login_page_id = 0;
	$login_pages   = get_posts( array(
		'post_type'      => 'page',
		'post_status'    => array( 'publish', 'draft' ),
		'posts_per_page' => 1,
		'meta_key'       => '_wp_page_template',
		'meta_value'     => 'farazsms-login-page.php',
		'fields'         => 'ids',
	) );
	if ( ! empty( $login_pages ) ) {
		$login_page_id = (int) $login_pages[0];
	}
	if ( $login_page_id > 0 && get_post_status( $login_page_id ) === 'publish' ) {
		return add_query_arg( 'back_url', $return_url, get_permalink( $login_page_id ) );
	}
	return wp_login_url( $return_url );
}

/**
 * مهاجرتِ یک‌باره: تنظیمِ «اجبار به ورود در تسویه»ی ماژولِ ورود به آپشنِ واحد منتقل می‌شود.
 *
 * تا نسخه‌ی ۳٫۲۲٫۱۹۲ دو دروازه‌ی مستقل با دو تنظیمِ جدا همان کار را می‌کردند. هزینه‌اش دو بار
 * پرداخت شد: یک‌بار رفعِ نیمه‌کاره (فقط یکی وصل شده بود) و یک‌بار پرتِ مشتری پس از پرداخت
 * (استثنای صفحه‌ی تأییدیه فقط در یکی نوشته شده بود). حالا دروازه یکی است و این مهاجرت
 * تضمین می‌کند فروشگاهی که فقط تنظیمِ ماژول را روشن داشت، رفتارش عوض نشود.
 */
add_action( 'plugins_loaded', 'farazsms_login_gate_migrate_module_setting', 20 );
function farazsms_login_gate_migrate_module_setting() {
	if ( get_option( 'farazsms_login_gate_checkout_migrated' ) === '1' ) {
		return;
	}
	$login_settings = get_option( 'farazsms_login_settings', array() );
	$module_on      = is_array( $login_settings ) && ! empty( $login_settings['general']['checkout_redirect_to_login'] );
	if ( $module_on ) {
		update_option( 'farazsms_login_gate_checkout', '1', false );
	}
	update_option( 'farazsms_login_gate_checkout_migrated', '1', true );
}

function farazsms_login_gate_redirect_if_needed() {
	if ( ! farazsms_login_gate_is_request_safe_to_redirect() ) {
		return;
	}

	$queried_id = (int) get_queried_object_id();
	if ( $queried_id > 0 && get_page_template_slug( $queried_id ) === 'farazsms-login-page.php' ) {
		return;
	}

	$must_login = false;
	// صفحه‌ی «دریافتِ سفارش» و «پرداختِ سفارش» هم is_checkout هستند ولی دروازه نباید بگیردشان:
	// مهمانی که تازه پرداخت کرده باید تأییدیه‌اش را ببیند، و مهمانی که پرداختش ناموفق شده باید
	// بتواند دوباره تلاش کند. استثنای order-pay در ۳٫۲۲٫۱۹۲ به گیتِ ماژول اضافه شده بود و با
	// حذفِ آن گیت در اپیک ۱۵ از دست رفت؛ تستِ رفتاری پیدایش کرد.
	$fz_on_checkout = function_exists( 'is_checkout' ) && is_checkout()
		&& ! ( function_exists( 'is_order_received_page' ) && is_order_received_page() )
		&& ! ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-pay' ) );
	if ( $fz_on_checkout ) {
		$must_login = get_option( 'farazsms_login_gate_checkout', '0' ) === '1';
		if ( $must_login ) {
			/**
			 * عبورِ موردی از گیتِ تسویه (نه از گیتِ صفحه‌ای).
			 *
			 * ماژولِ سبدِ رهاشده با این فیلتر به مهمانی که سبدش را از روی لینکِ پیامکیِ خودش
			 * بازیابی کرده اجازه‌ی تمام‌کردنِ همان خرید را می‌دهد. جهتِ وابستگی عمداً همین است:
			 * فایلِ سبدِ رهاشده از مسیرِ لودرِ محافظت‌شده بار می‌شود و ممکن است اصلاً نباشد، پس
			 * گیت نباید تابعِ آن را صدا بزند — نبودِ ماژول یعنی نبودِ شنونده و رفتارِ بدونِ تغییر.
			 *
			 * @param bool $bypass پیش‌فرض false (گیت اعمال شود).
			 */
			$must_login = ! (bool) apply_filters( 'farazsms_login_gate_checkout_bypass', false );
		}
	}
	if ( ! $must_login && is_singular( 'page' ) && $queried_id > 0 ) {
		$must_login = get_post_meta( $queried_id, '_farazsms_login_required', true ) === '1';
	}
	if ( ! $must_login ) {
		return;
	}

	$return_url = farazsms_login_gate_current_url();
	wp_safe_redirect( farazsms_login_gate_login_url( $return_url ) );
	exit;
}
add_action( 'template_redirect', 'farazsms_login_gate_redirect_if_needed', 7 );

function farazsms_login_gate_add_page_metabox() {
	add_meta_box(
		'farazsms_login_gate_page',
		'ورود اجباری فراز اس‌ام‌اس',
		'farazsms_login_gate_render_page_metabox',
		'page',
		'side',
		'default'
	);
}
add_action( 'add_meta_boxes', 'farazsms_login_gate_add_page_metabox' );

function farazsms_login_gate_render_page_metabox( $post ) {
	wp_nonce_field( 'farazsms_login_gate_page', 'farazsms_login_gate_page_nonce' );
	$enabled = get_post_meta( $post->ID, '_farazsms_login_required', true ) === '1';
	?>
	<label style="display:block; line-height:1.8;">
		<input type="checkbox" name="farazsms_login_required" value="1" <?php checked( $enabled ); ?>>
		این برگه فقط برای کاربران واردشده نمایش داده شود.
	</label>
	<p style="margin:8px 0 0; color:#64748b;">کاربر مهمان ابتدا وارد صفحه ورود پیامکی می‌شود و بعد به همین برگه برمی‌گردد.</p>
	<?php
}

function farazsms_login_gate_save_page_metabox( $post_id ) {
	if ( ! isset( $_POST['farazsms_login_gate_page_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['farazsms_login_gate_page_nonce'] ) ), 'farazsms_login_gate_page' ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_page', $post_id ) ) {
		return;
	}
	if ( isset( $_POST['farazsms_login_required'] ) ) {
		update_post_meta( $post_id, '_farazsms_login_required', '1' );
	} else {
		delete_post_meta( $post_id, '_farazsms_login_required' );
	}
}
add_action( 'save_post_page', 'farazsms_login_gate_save_page_metabox' );

/**
 * رندر یک فیلد از روی schema ماژول — استایل قاب یکپارچه.
 */
function farazsms_login_render_field( $id, $field ) {
	$type        = $field['type'] ?? 'text';
	$title       = $field['title'] ?? '';
	$description = $field['description'] ?? '';
	$value       = $field['value'] ?? '';
	$width       = $field['width'] ?? 'w100';

	// عرض: w100=100%, w50=48%, w33=31%, w20=18%
	$width_map = array(
		'w100' => '100%',
		'w50'  => 'calc(50% - 8px)',
		'w33'  => 'calc(33.33% - 11px)',
		'w20'  => 'calc(20% - 13px)',
	);
	$css_width = isset( $width_map[ trim( explode( ' ', $width )[0] ) ] )
		? $width_map[ trim( explode( ' ', $width )[0] ) ]
		: '100%';
	$is_ltr = strpos( $width, 'ltr' ) !== false ? 'direction:ltr; text-align:left;' : '';

	if ( $type === 'heading' ) {
		echo '<h4 style="grid-column:1/-1; margin:18px 0 6px; font-size:14px; font-weight:700; color:#0f172a; border-bottom:1px solid #e5e7eb; padding-bottom:6px;">' . esc_html( $title ) . '</h4>';
		return;
	}
	if ( $type === 'html' ) {
		echo '<div style="grid-column:1/-1;">' . wp_kses_post( $field['html'] ?? '' ) . '</div>';
		return;
	}

	echo '<div style="flex: 0 1 ' . esc_attr( $css_width ) . '; min-width:200px;">';
	echo '<label for="' . esc_attr( $id ) . '" style="display:block; font-size:13px; font-weight:600; color:#334155; margin-bottom:6px;">' . esc_html( $title ) . '</label>';

	$common_style = 'width:100%; padding:8px 12px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px; font-family:inherit; box-sizing:border-box; ' . $is_ltr;

	switch ( $type ) {
		case 'textarea':
			echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '" rows="6" style="' . esc_attr( $common_style ) . ' min-height:120px; line-height:1.8;">' . esc_textarea( (string) $value ) . '</textarea>';
			break;
		case 'number':
			echo '<input type="number" id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '" value="' . esc_attr( $value ) . '" style="' . esc_attr( $common_style ) . '">';
			break;
		case 'color':
			// کلاسِ farazsms-color-field توسطِ wp-color-picker (در enqueue همین صفحه) به سواچِ
			// زنده + پالت تبدیل می‌شود؛ دیگر کاربر مجبور نیست hex را دستی و بدونِ بازخورد بزند.
			echo '<input type="text" class="farazsms-color-field" id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '" value="' . esc_attr( $value ) . '" placeholder="#000000" style="' . esc_attr( $common_style ) . ' direction:ltr; text-align:left; font-family:monospace;">';
			break;
		case 'switch':
		case 'checkbox':
			$checked = ! empty( $value ) && $value !== '0' ? 'checked' : '';
			echo '<label style="display:inline-flex; align-items:center; gap:10px; cursor:pointer;">';
			echo '<input type="checkbox" class="farazsms-toggle" id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '" value="1" ' . $checked . '>';
			echo '<span style="font-size:12px; font-weight:600; color:' . ( $checked ? '#16a34a' : '#94a3b8' ) . ';">' . ( $checked ? 'فعال' : 'غیرفعال' ) . '</span>';
			echo '</label>';
			break;
		case 'select':
			echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '" style="' . esc_attr( $common_style ) . '">';
			foreach ( ( $field['array'] ?? array() ) as $opt_val => $opt_label ) {
				$sel = (string) $value === (string) $opt_val ? 'selected' : '';
				echo '<option value="' . esc_attr( $opt_val ) . '" ' . $sel . '>' . esc_html( $opt_label ) . '</option>';
			}
			echo '</select>';
			break;
		case 'image-radio':
			// بازخوردِ «انتخاب‌شده» با CSS (:has(:checked)) + یک JSِ وانیلای پشتیبان
			// انجام می‌شود تا بدونِ وابستگی به admin.js (که این صفحه بارش نمی‌کند) کار کند.
			// رادیو داخلِ label است (ارتباطِ implicit)، پس کلیک، انتخاب را native ثبت می‌کند.
			farazsms_login_imageradio_assets();
			echo '<div class="farazsms-imgradio">';
			foreach ( ( $field['options'] ?? array() ) as $opt_val => $opt ) {
				$is_sel = (string) $value === (string) $opt_val;
				echo '<label class="farazsms-imgradio-opt' . ( $is_sel ? ' is-selected' : '' ) . '">';
				echo '<input type="radio" name="' . esc_attr( $id ) . '" value="' . esc_attr( $opt_val ) . '" ' . checked( $is_sel, true, false ) . '>';
				if ( ! empty( $opt['image'] ) ) {
					echo '<img src="' . esc_url( $opt['image'] ) . '" alt="' . esc_attr( $opt['label'] ?? '' ) . '">';
				}
				echo '<span class="farazsms-imgradio-label">' . esc_html( $opt['label'] ?? '' ) . '</span>';
				echo '</label>';
			}
			echo '</div>';
			break;
		case 'file':
			// آپلود مستقیم از کتابخانه‌ی رسانه‌ی وردپرس — کاربر دیگر لازم نیست لینک را دستی وارد کند.
			// فیلدِ متنی هم می‌ماند (برای ذخیره از همان handler و برای کاربرانی که می‌خواهند لینک بزنند).
			echo '<div class="farazsms-media-field" style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">';
			echo '<input type="text" id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '" value="' . esc_attr( $value ) . '" placeholder="https://..." class="farazsms-media-url" style="flex:1; min-width:200px; padding:8px 12px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px; direction:ltr; text-align:left; font-family:monospace;">';
			echo '<button type="button" class="button button-secondary farazsms-media-upload" data-target="' . esc_attr( $id ) . '"><span class="dashicons dashicons-upload" style="vertical-align:text-bottom;"></span> بارگذاری/انتخاب فایل</button>';
			echo '<button type="button" class="button farazsms-media-remove" data-target="' . esc_attr( $id ) . '" style="' . ( empty( $value ) ? 'display:none;' : '' ) . '">حذف</button>';
			echo '</div>';
			echo '<div class="farazsms-media-preview" data-for="' . esc_attr( $id ) . '" style="margin-top:6px;">';
			if ( ! empty( $value ) ) {
				echo '<img src="' . esc_url( $value ) . '" style="max-height:60px; border:1px solid #e5e7eb; border-radius:4px; padding:4px;">';
			}
			echo '</div>';
			break;
		default: // text
			echo '<input type="text" id="' . esc_attr( $id ) . '" name="' . esc_attr( $id ) . '" value="' . esc_attr( $value ) . '" style="' . esc_attr( $common_style ) . '">';
	}

	if ( $description !== '' ) {
		echo '<p style="margin:4px 0 0; font-size:11px; color:#64748b; line-height:1.7;">' . wp_kses_post( $description ) . '</p>';
	}
	echo '</div>';
}

/**
 * استایل + JSِ مستقلِ دکمه‌های انتخابِ تصویری (تم / ترازِ متن) — فقط یک‌بار چاپ می‌شود.
 *
 * این صفحه (bridge) admin.js ماژول را بار نمی‌کند، پس بازخوردِ بصریِ انتخاب را اینجا
 * خودمان فراهم می‌کنیم: اول با CSSِ :has(:checked) (بدونِ هیچ JS)، و یک JSِ وانیلای
 * پشتیبان برای مرورگرهای قدیمی که :has را پشتیبانی نمی‌کنند. کلیک، رادیو را به‌صورتِ
 * native انتخاب می‌کند چون رادیو داخلِ label است.
 */
function farazsms_login_imageradio_assets() {
	static $printed = false;
	if ( $printed ) {
		return;
	}
	$printed = true;
	?>
	<style>
	.farazsms-imgradio{display:flex;flex-wrap:wrap;gap:8px;}
	.farazsms-imgradio-opt{display:block;cursor:pointer;border:2px solid #e5e7eb;border-radius:8px;padding:6px;background:#fff;transition:border-color .15s,box-shadow .15s;}
	.farazsms-imgradio-opt:hover{border-color:#a5b4fc;}
	.farazsms-imgradio-opt input[type=radio]{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none;margin:0;}
	.farazsms-imgradio-opt img{display:block;width:80px;height:auto;border-radius:4px;}
	.farazsms-imgradio-label{display:block;text-align:center;font-size:11px;margin-top:4px;color:#64748b;}
	/* انتخاب‌شده — هم با کلاسِ سرور/JS و هم با :has(:checked) (بدونِ JS). */
	.farazsms-imgradio-opt.is-selected,
	.farazsms-imgradio-opt:has(input[type=radio]:checked){border-color:#365891;box-shadow:0 0 0 2px rgba(67,56,202,.18);}
	.farazsms-imgradio-opt.is-selected .farazsms-imgradio-label,
	.farazsms-imgradio-opt:has(input[type=radio]:checked) .farazsms-imgradio-label{color:#365891;}
	</style>
	<script>
	(function(){
		function sync(radio){
			if(!radio){return;}
			var name=radio.getAttribute('name');
			if(name){
				var group=document.querySelectorAll('.farazsms-imgradio-opt input[type=radio][name="'+name+'"]');
				for(var i=0;i<group.length;i++){
					var opt=group[i].closest('.farazsms-imgradio-opt');
					if(opt){opt.classList.remove('is-selected');}
				}
			}
			var sel=radio.closest('.farazsms-imgradio-opt');
			if(sel){sel.classList.add('is-selected');}
		}
		document.addEventListener('click',function(e){
			if(!e.target||!e.target.closest){return;}
			var opt=e.target.closest('.farazsms-imgradio-opt');
			if(!opt){return;}
			var radio=opt.querySelector('input[type=radio]');
			if(radio){radio.checked=true;sync(radio);}
		},false);
		document.addEventListener('change',function(e){
			var t=e.target;
			if(t&&t.matches&&t.matches('.farazsms-imgradio-opt input[type=radio]')){sync(t);}
		},false);
	})();
	</script>
	<?php
}

/**
 * صفحه اصلی تنظیمات «ورود و ثبت‌نام» — همه چیز inline در همان صفحه.
 */
/**
 * اسکریپتِ آپلودگرِ رسانه برای فیلدهای نوع file (لوگو / پس‌زمینه).
 * با کلیک روی دکمه، کتابخانه‌ی رسانه‌ی وردپرس باز می‌شود؛ فایلِ انتخاب/آپلودشده
 * در فیلدِ متنی همان فیلد قرار می‌گیرد و پیش‌نمایش به‌روز می‌شود. در فوتر چاپ می‌شود
 * تا jQuery و wp.media آماده باشند. add_action با همین نام، چاپِ تکراری را خنثی می‌کند.
 */
function farazsms_login_media_uploader_script() {
	?>
	<script>
	jQuery(function($){
		$(document).on('click', '.farazsms-media-upload', function(e){
			e.preventDefault();
			var target = $(this).data('target');
			var frame = wp.media({
				title: 'انتخاب یا بارگذاری فایل',
				button: { text: 'استفاده از این فایل' },
				multiple: false
			});
			frame.on('select', function(){
				var att = frame.state().get('selection').first().toJSON();
				$('#' + target).val(att.url).trigger('change');
				$('.farazsms-media-preview[data-for="' + target + '"]').html(
					'<img src="' + att.url + '" style="max-height:60px; border:1px solid #e5e7eb; border-radius:4px; padding:4px;">'
				);
				$('.farazsms-media-remove[data-target="' + target + '"]').show();
			});
			frame.open();
		});
		$(document).on('click', '.farazsms-media-remove', function(e){
			e.preventDefault();
			var target = $(this).data('target');
			$('#' + target).val('').trigger('change');
			$('.farazsms-media-preview[data-for="' + target + '"]').empty();
			$(this).hide();
		});
	});
	</script>
	<?php
}

/**
 * راه‌اندازیِ wp-color-picker روی فیلدهای رنگِ صفحه‌ی ورود/ثبت‌نام.
 */
function farazsms_login_color_picker_script() {
	?>
	<script>
	jQuery(function($){
		if ($.fn.wpColorPicker) {
			$('.farazsms-color-field').wpColorPicker();
		}
	});
	</script>
	<?php
}

/**
 * تبِ «محدودیت‌ها و امنیت» — کنترلِ گاردِ ضدِ رباتِ کدِ ورود.
 * داخلِ فرمِ اصلی رندر می‌شود؛ ذخیره در farazsms_login_save_settings().
 */
function farazsms_login_render_limits_tab() {
	$s = farazsms_login_limits_settings();
	$on = function ( $k ) use ( $s ) { return ! empty( $s[ $k ] ) && $s[ $k ] === '1'; };
	$nv = function ( $k, $d ) use ( $s ) { return isset( $s[ $k ] ) ? (int) $s[ $k ] : $d; };
	?>
	<input type="hidden" name="farazsms_login_limits_present" value="1">
	<div style="background:#f0f6fc; border:1px solid #c3d9ed; border-radius:10px; padding:12px 16px; margin-bottom:18px; line-height:2; font-size:13px; color:#334155;">
		🛡️ این بخش جلوی رباتی را می‌گیرد که با فرستادنِ کدِ تایید به شماره‌های مختلف، شارژِ پیامکیِ شما را خالی می‌کند.
		دفاع <b>نامرئی</b> است و کاربرِ واقعی هیچ اصطکاکی حس نمی‌کند. مقادیرِ پیش‌فرض سخاوتمندند و فقط در هجومِ واقعی فعال می‌شوند.
	</div>

	<div style="display:flex; flex-direction:column; gap:12px;">
		<label style="display:flex; align-items:center; gap:12px; padding:12px 14px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px;">
			<input type="checkbox" class="farazsms-toggle" name="fzl_enabled" value="1" <?php checked( $on( 'enabled' ) ); ?> style="width:18px;height:18px">
			<span style="font-weight:600;">فعال بودنِ محافظت (توصیه می‌شود روشن بماند)</span>
		</label>

		<label style="display:flex; align-items:center; gap:12px; padding:12px 14px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px;">
			<input type="checkbox" class="farazsms-toggle" name="fzl_number_heuristic" value="1" <?php checked( $on( 'number_heuristic' ) ); ?> style="width:18px;height:18px">
			<span>ردِ شماره‌های آشکارا جعلی (مثلِ <code dir="ltr">09000000000</code>)</span>
		</label>

		<label style="display:flex; align-items:center; gap:12px; padding:12px 14px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px;">
			<input type="checkbox" class="farazsms-toggle" name="fzl_require_token" value="1" <?php checked( $on( 'require_token' ) ); ?> style="width:18px;height:18px">
			<span>توکنِ نامرئی + هانی‌پات (رباتی که فرم را باز نکرده رد می‌شود)</span>
		</label>

		<label style="display:flex; align-items:center; gap:12px; padding:12px 14px; background:#fff7ed; border:1px solid #fed7aa; border-radius:8px;">
			<input type="checkbox" class="farazsms-toggle" name="fzl_token_strict" value="1" <?php checked( $on( 'token_strict' ) ); ?> style="width:18px;height:18px">
			<span>حالتِ سخت‌گیرانه: نبودِ توکن هم رد شود.
				<small style="color:#9a3412; display:block;">فقط بعد از اینکه مطمئن شدید ورود روی سایتتان درست کار می‌کند روشن کنید (وگرنه ممکن است بعضی قالب‌ها را محدود کند).</small>
			</span>
		</label>

		<label style="display:flex; align-items:center; gap:12px; padding:12px 14px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px;">
			<input type="checkbox" class="farazsms-toggle" name="fzl_admin_alert" value="1" <?php checked( $on( 'admin_alert' ) ); ?> style="width:18px;height:18px">
			<span>در صورتِ هجوم، به شماره‌ی مدیر پیامکِ هشدار بده</span>
		</label>

		<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:14px; margin-top:6px;">
			<label style="font-size:13px;">حداکثر کد در ساعت برای هر شماره
				<input type="number" name="fzl_per_number_max" min="1" max="100" value="<?php echo esc_attr( $nv( 'per_number_max', 5 ) ); ?>" style="width:100%; margin-top:6px;">
			</label>
			<label style="font-size:13px;">حداکثر کد در روز برای هر IP
				<input type="number" name="fzl_per_ip_max" min="0" max="1000" value="<?php echo esc_attr( $nv( 'per_ip_max', 0 ) ); ?>" style="width:100%; margin-top:6px;">
				<small style="color:#9a3412; display:block;">۰ = خاموش (توصیه‌شده روی هاستِ پشتِ کلودفلر/CDN یا موبایلِ CGNAT — وگرنه ممکن است همه‌ی کاربران یک IP شوند و قفل شوند).</small>
			</label>
			<label style="font-size:13px;">سقفِ سراسریِ سایت در ساعت (تورِ ایمنیِ شارژ)
				<input type="number" name="fzl_global_max" min="10" max="100000" value="<?php echo esc_attr( $nv( 'global_max', 500 ) ); ?>" style="width:100%; margin-top:6px;">
			</label>
			<label style="font-size:13px;">حداقل ثانیه بین بازشدنِ فرم و ارسال
				<input type="number" name="fzl_min_seconds" min="0" max="60" value="<?php echo esc_attr( $nv( 'min_seconds', 3 ) ); ?>" style="width:100%; margin-top:6px;">
			</label>
		</div>
	</div>
	<?php
}

/**
 * نوارِ تب‌های صفحه‌ی ورود/ثبت‌نام (مشترک بینِ فرمِ تنظیمات و تبِ خوش‌آمدگویی).
 */
function farazsms_login_render_tabnav( $valid_tabs, $active_tab, $tab_labels, $tab_icons, $module_settings ) {
	?>
	<div style="display:flex; gap:4px; border-bottom:1px solid #e5e7eb; padding:0 14px; background:#f8fafc; flex-wrap:wrap;">
		<?php foreach ( $valid_tabs as $tab_key ) :
			$virtual_tabs = array( 'migration', 'shortcodes', 'welcome', 'limits' );
			if ( ! in_array( $tab_key, $virtual_tabs, true ) && ! isset( $module_settings[ $tab_key ] ) ) {
				continue;
			}
			$is_active = $tab_key === $active_tab;
			$tab_url   = add_query_arg( array( 'page' => 'farazsms-login-register', 'lt' => $tab_key ), admin_url( 'admin.php' ) );
			?>
			<a href="<?php echo esc_url( $tab_url ); ?>" style="display:inline-flex; align-items:center; gap:6px; padding:12px 18px; font-size:13px; font-weight:<?php echo $is_active ? '700' : '500'; ?>; color:<?php echo $is_active ? '#365891' : '#64748b'; ?>; border-bottom:2px solid <?php echo $is_active ? '#4571ba' : 'transparent'; ?>; text-decoration:none; margin-bottom:-1px;">
				<span class="dashicons dashicons-<?php echo esc_attr( $tab_icons[ $tab_key ] ?? 'admin-generic' ); ?>" style="font-size:16px; width:16px; height:16px;"></span>
				<?php echo esc_html( $tab_labels[ $tab_key ] ?? ( $module_settings[ $tab_key ]['menu'] ?? $tab_key ) ); ?>
			</a>
		<?php endforeach; ?>
	</div>
	<?php
}

function farazsms_login_module_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی غیرمجاز.' );
	}

	// آپلودگرِ رسانه‌ی وردپرس برای فیلدهای لوگو و پس‌زمینه (دکمه‌ی «بارگذاری/انتخاب فایل»).
	wp_enqueue_media();
	add_action( 'admin_footer', 'farazsms_login_media_uploader_script' );

	// پیکرِ رنگِ وردپرس برای فیلدهای رنگِ تبِ «ظاهر فرم» — سواچِ زنده + پالت + اعتبارسنجی.
	// قبلاً این صفحه picker را بار نمی‌کرد و رنگ فقط input متنی بود؛ hex اشتباه بی‌بازخورد رد می‌شد.
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker' );
	add_action( 'admin_footer', 'farazsms_login_color_picker_script' );

	$saved_ok = farazsms_login_save_settings();

	$enabled    = farazsms_login_module_is_enabled();
	$ask_name   = get_option( 'farazsms_login_ask_name', 'yes' );
	$gate_checkout = get_option( 'farazsms_login_gate_checkout', '0' ) === '1';

	$active_tab = isset( $_GET['lt'] ) ? sanitize_key( $_GET['lt'] ) : 'sms';
	$valid_tabs = array( 'sms', 'appearance', 'general', 'limits', 'welcome', 'migration', 'shortcodes' );
	if ( ! in_array( $active_tab, $valid_tabs, true ) ) {
		$active_tab = 'sms';
	}

	// تنظیمات ماژول — فیلتر شده.
	$module_settings = array();
	if ( class_exists( '\\FarazSMS\\Admin\\Settings' ) ) {
		$settings_obj    = new \FarazSMS\Admin\Settings();
		$module_settings = farazsms_login_filter_settings( $settings_obj->All_Settings() );
	}

	$tab_labels = array(
		'sms'        => 'پیامک و OTP',
		'appearance' => 'ظاهر فرم',
		'general'    => 'تنظیمات عمومی',
			'limits'     => 'محدودیت‌ها و امنیت',
		'welcome'    => 'پیامک خوش‌آمدگویی',
		'migration'  => 'مهاجرت از سایر افزونه‌ها',
		'shortcodes' => 'شورت‌کدها',
	);
	$tab_icons = array(
		'sms'        => 'email-alt',
		'appearance' => 'admin-appearance',
		'general'    => 'admin-settings',
			'limits'     => 'shield',
		'welcome'    => 'megaphone',
		'migration'  => 'migrate',
		'shortcodes' => 'shortcode',
	);
	// تب migration یک تب «مجازی» است — در $module_settings از فراز نمی‌آید.
	// خودمان content آن را زیر تب render می‌کنیم.
	?>
	<div style="direction:rtl; font-family:inherit; max-width:980px;">

		<?php if ( $saved_ok ) : ?>
			<div style="background:#ecfdf5; border:1px solid #a7f3d0; color:#065f46; padding:10px 14px; border-radius:8px; margin-bottom:16px;">✓ تنظیمات با موفقیت ذخیره شد.</div>
		<?php endif; ?>

		<!-- Hero -->
		<div style="background: linear-gradient(135deg, #eef2ff 0%, #f5f3ff 100%); border:1px solid #c7d2fe; border-radius:12px; padding:18px 22px; margin-bottom:20px;">
			<h3 style="margin:0 0 6px; font-size:16px; color:#312e81; font-weight:700; display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
				🔐 ورود و ثبت‌نام با پیامک
				<?php if ( function_exists( 'farazsms_help_video_button' ) ) { farazsms_help_video_button( 'login' ); } ?>
			</h3>
			<p style="margin:0; color:#365891; font-size:13px; line-height:1.9;">
				ماژول اختصاصی ورود/ثبت‌نام با OTP. کلید دسترسی و خط ارسال از <strong>تنظیمات اصلی افزونه</strong> خوانده می‌شود — نیازی به وارد کردن مجدد نیست. این ماژول در حالت غیرفعال <strong>هیچ تأثیری</strong> روی فرم ورود سایر افزونه‌ها ندارد.
			</p>
		</div>

		<?php if ( $active_tab === 'welcome' ) : ?>
			<!-- تبِ مجزای پیامک خوش‌آمدگویی — فرمِ مستقلِ خودش را دارد، پس بیرون از فرمِ اصلی رندر می‌شود. -->
			<div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px 12px 0 0; overflow:hidden;">
				<?php farazsms_login_render_tabnav( $valid_tabs, $active_tab, $tab_labels, $tab_icons, $module_settings ); ?>
			</div>
			<?php do_action( 'farazsms_login_register_render_welcome_tab' ); ?>
		</div>
		<?php return; endif; ?>

		<form method="post" action="">
			<?php wp_nonce_field( 'farazsms_login_settings', 'farazsms_login_settings_nonce' ); ?>
			<input type="hidden" name="active_tab" value="<?php echo esc_attr( $active_tab ); ?>">

			<!-- Card 1: فقط master toggle — ask_name حالا داخل تب «تنظیمات عمومی» است -->
			<div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:20px; margin-bottom:18px;">
				<label style="display:flex; align-items:center; gap:14px; padding:12px 16px; background:<?php echo $enabled ? '#f0fdf4' : '#fff7ed'; ?>; border:1px solid <?php echo $enabled ? '#bbf7d0' : '#fed7aa'; ?>; border-radius:10px; cursor:pointer; margin:0;">
					<input type="checkbox" class="farazsms-toggle" name="farazsms_login_module_enabled" value="1" <?php checked( $enabled, true ); ?> style="margin:0; width:18px; height:18px;">
					<span style="flex:1; font-size:13px; font-weight:600;">
						فعال بودن ماژول ورود/ثبت‌نام با موبایل
						<?php if ( $enabled ) : ?>
							<span style="display:inline-block; background:#16a34a; color:#fff; font-size:10px; padding:2px 8px; border-radius:4px; margin-right:8px;">فعال ✓</span>
						<?php else : ?>
							<span style="display:inline-block; background:#f97316; color:#fff; font-size:10px; padding:2px 8px; border-radius:4px; margin-right:8px;">غیرفعال</span>
						<?php endif; ?>
					</span>
				</label>
			</div>

			<!-- Card 2: Tabbed advanced settings -->
			<?php if ( ! empty( $module_settings ) ) : ?>
				<div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:0; margin-bottom:18px; overflow:hidden;">

					<!-- Tab nav -->
						<?php farazsms_login_render_tabnav( $valid_tabs, $active_tab, $tab_labels, $tab_icons, $module_settings ); ?>

						<!-- Tab content -->
					<div style="padding:24px;">
						<?php if ( $active_tab === 'migration' ) : ?>
							<?php farazsms_login_render_migration_tab(); ?>
						<?php elseif ( $active_tab === 'shortcodes' ) : ?>
							<?php farazsms_login_render_shortcodes_tab(); ?>
							<?php elseif ( $active_tab === 'limits' ) : ?>
								<?php farazsms_login_render_limits_tab(); ?>
						<?php elseif ( isset( $module_settings[ $active_tab ]['settings'] ) ) : ?>
							<div style="display:flex; flex-wrap:wrap; gap:16px;">
								<?php foreach ( $module_settings[ $active_tab ]['settings'] as $field_id => $field ) : ?>
									<?php farazsms_login_render_field( $field_id, $field ); ?>
								<?php endforeach; ?>

								<?php if ( $active_tab === 'general' ) : ?>
									<!-- ask_name در تب تنظیمات عمومی -->
									<div style="flex:0 1 100%; min-width:200px; margin-top:8px;">
										<label style="display:block; font-size:13px; font-weight:600; color:#334155; margin-bottom:8px;">
											فیلد نام و نام خانوادگی در صفحه ثبت‌نام
										</label>
										<div style="display:flex; gap:24px; flex-wrap:wrap; padding:10px 14px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px;">
											<label style="display:inline-flex; align-items:center; gap:6px; cursor:pointer;">
												<input type="radio" name="farazsms_login_ask_name" value="yes" <?php checked( $ask_name, 'yes' ); ?> style="margin:0;">
												<span>بله <strong style="color:#dc2626;">(اجباری)</strong></span>
											</label>
											<label style="display:inline-flex; align-items:center; gap:6px; cursor:pointer;">
												<input type="radio" name="farazsms_login_ask_name" value="no" <?php checked( $ask_name, 'no' ); ?> style="margin:0;">
												<span>خیر، فیلد نام را حذف کن</span>
											</label>
										</div>
										<p style="margin:4px 0 0; font-size:11px; color:#64748b; line-height:1.7;">
											اگر «بله» را انتخاب کنید، فیلد نام در صفحه ثبت‌نام اجباری می‌شود.
										</p>
									</div>

									<div style="flex:0 1 100%; min-width:200px; margin-top:8px;">
										<input type="hidden" name="farazsms_login_gate_checkout_present" value="1">
										<label style="display:flex; align-items:flex-start; gap:10px; padding:12px 14px; background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; cursor:pointer;">
											<input type="checkbox" name="farazsms_login_gate_checkout" value="1" <?php checked( $gate_checkout ); ?> style="margin-top:3px;">
											<span>
												<strong style="display:block; color:#334155; font-size:13px;">اجبار ورود قبل از تسویه‌حساب ووکامرس</strong>
												<span style="display:block; color:#64748b; font-size:11.5px; line-height:1.8; margin-top:3px;">اگر کاربر مهمان روی پرداخت برود، ابتدا فرم ورود پیامکی نمایش داده می‌شود و بعد از ورود به همان صفحه تسویه‌حساب برمی‌گردد.</span>
											</span>
										</label>
									</div>

								<?php endif; ?>

								<?php if ( $active_tab === 'sms' ) : ?>
									<?php
									$site_domain = wp_parse_url( home_url(), PHP_URL_HOST );
									$site_domain = preg_replace( '#^www\.#i', '', (string) $site_domain );
									?>
									<div style="flex:0 1 100%; min-width:200px; margin-top:8px; padding:14px 16px; background:linear-gradient(135deg,#eef2ff 0%,#f5f3ff 100%); border:1px solid #c7d2fe; border-radius:10px;">
										<div style="font-size:13px; font-weight:700; color:#263f67; margin-bottom:6px;">
											🤖 ساخت پترن خودکار
										</div>
										<p style="margin:0 0 10px; font-size:12px; color:#365891; line-height:1.8;">
											پترن استاندارد OTP را با یک کلیک در پنل فراز اس‌ام‌اس بسازید. متغیر <code style="background:#fff; padding:1px 4px; border-radius:3px;">%code%</code> عددی ۶ رقمی است.
										</p>
										<div style="background:#fff; border:1px dashed #c7d2fe; padding:10px 12px; border-radius:6px; margin-bottom:10px; font-family:inherit; font-size:12px; line-height:1.9; color:#0f172a;">
											کدتایید شما %code%<br>
											<span style="color:#475569; direction:ltr; display:inline-block;"><?php echo esc_html( $site_domain ); ?></span><br>
											<span style="color:#475569; direction:ltr; display:inline-block;">@<?php echo esc_html( (string) wp_parse_url( home_url(), PHP_URL_HOST ) ); ?> #%code%</span>
										</div>
										<p style="margin:0 0 10px; font-size:11px; color:#16a34a; line-height:1.7;">خطِ آخر (<code>@دامنه #کد</code>) برای پرشدنِ خودکارِ کد روی گوشی (اندروید) لازم است و حتماً باید در پترن بماند.</p>
										<button type="button" id="farazsms-login-autobuild-pattern" data-nonce="<?php echo esc_attr( wp_create_nonce( 'farazsms_login_autobuild_pattern' ) ); ?>" style="background:#16a34a; color:#fff; border:none; padding:8px 16px; font-size:12px; font-weight:600; border-radius:6px; cursor:pointer; font-family:inherit;">
											⚡ ساخت پترن خودکار و درج در فیلد بالا
										</button>
										<span id="farazsms-login-autobuild-status" style="margin-right:10px; font-size:12px; color:#64748b;"></span>
										<p style="margin:8px 0 0; font-size:11px; color:#64748b; line-height:1.7;">
											بعد از کلیک، یک درخواست به سامانه فراز اس‌ام‌اس ارسال می‌شود و کد پترن ساخته‌شده در فیلد «کد پترن» قرار می‌گیرد. اگر می‌خواهید دستی پترن بسازید، می‌توانید کد آن را مستقیماً در فیلد «کد پترن» وارد کنید.
										</p>
									</div>
									<script>
									(function(){
										var btn = document.getElementById('farazsms-login-autobuild-pattern');
										if (!btn) return;
										btn.addEventListener('click', function(e){
											e.preventDefault();
											var status = document.getElementById('farazsms-login-autobuild-status');
											btn.disabled = true;
											btn.style.opacity = '0.6';
											status.textContent = 'در حال ساخت پترن…';
											var fd = new FormData();
											fd.append('action', 'farazsms_login_autobuild_pattern');
											fd.append('nonce', btn.dataset.nonce);
											fetch(ajaxurl, { method:'POST', credentials:'same-origin', body: fd })
												.then(function(r){ return r.json(); })
												.then(function(res){
													if (res && res.success && res.data && res.data.pattern_code) {
														var input = document.getElementById('pattern_code');
														if (input) input.value = res.data.pattern_code;
														status.textContent = '✓ پترن ساخته شد: ' + res.data.pattern_code + ' — دکمه ذخیره را بزنید';
														status.style.color = '#16a34a';
													} else {
														var msg = (res && res.data && res.data.message) ? res.data.message : 'خطای ناشناخته';
														status.textContent = '✗ ' + msg;
														status.style.color = '#dc2626';
													}
												})
												.catch(function(){
													status.textContent = '✗ خطای ارتباط';
													status.style.color = '#dc2626';
												})
												.finally(function(){
													btn.disabled = false;
													btn.style.opacity = '1';
												});
										});
									})();
									</script>
								<?php endif; ?>
							</div>
						<?php endif; ?>
					</div>
				</div>
			<?php endif; ?>

			<!-- Save -->
			<div style="display:flex; gap:12px; align-items:center; margin-bottom:18px;">
				<button type="submit" name="farazsms_login_settings_submit" value="1" style="background:#365891; color:#fff; border:none; padding:10px 28px; font-size:14px; font-weight:600; border-radius:8px; cursor:pointer; font-family:inherit;">
					💾 ذخیره تنظیمات
				</button>
			</div>
		</form>

		<!-- Card 3: راهنمای نمایش فرم در سایت + shortcodes -->
		<?php
		// چک می‌کنیم آیا برگه با قالب login از قبل موجود است؟
		$existing_login_page_id = 0;
		$existing_login_pages = get_posts( array(
			'post_type'      => 'page',
			'post_status'    => array( 'publish', 'draft' ),
			'posts_per_page' => 1,
			'meta_key'       => '_wp_page_template',
			'meta_value'     => 'farazsms-login-page.php',
			'fields'         => 'ids',
		) );
		if ( ! empty( $existing_login_pages ) ) {
			$existing_login_page_id = (int) $existing_login_pages[0];
		}
		?>
		<div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:20px; margin-bottom:18px;">
			<h4 style="margin:0 0 6px; font-size:14px; font-weight:700; color:#0f172a;">📍 نحوه نمایش فرم ورود در سایت</h4>
			<p style="margin:0 0 14px; font-size:12.5px; color:#64748b; line-height:1.9;">
				پس از فعال‌سازی ماژول، فرم ورود/ثبت‌نام در یک برگه با قالب اختصاصی نمایش داده می‌شود. می‌توانید این برگه را با یک کلیک بسازید:
			</p>

			<?php if ( $existing_login_page_id > 0 ) : ?>
				<div style="background:#f0fdf4; border:1px solid #bbf7d0; padding:12px 16px; border-radius:8px; margin-bottom:10px;">
					<strong style="color:#15803d;">✓ برگه ورود ساخته شده است.</strong>
					<div style="margin-top:6px; font-size:12.5px; color:#065f46;">
						URL برگه:
						<a href="<?php echo esc_url( get_permalink( $existing_login_page_id ) ); ?>" target="_blank" style="direction:ltr; display:inline-block; color:#15803d;">
							<?php echo esc_html( get_permalink( $existing_login_page_id ) ); ?>
						</a>
					</div>
					<div style="margin-top:8px;">
						<a href="<?php echo esc_url( get_edit_post_link( $existing_login_page_id ) ); ?>" style="display:inline-block; background:#fff; color:#15803d; padding:6px 12px; border:1px solid #bbf7d0; border-radius:6px; text-decoration:none; font-size:12px; margin-left:6px;">
							✏️ ویرایش برگه
						</a>
						<a href="<?php echo esc_url( get_permalink( $existing_login_page_id ) ); ?>" target="_blank" style="display:inline-block; background:#fff; color:#15803d; padding:6px 12px; border:1px solid #bbf7d0; border-radius:6px; text-decoration:none; font-size:12px;">
							🔗 مشاهده برگه
						</a>
					</div>
				</div>
			<?php else : ?>
				<button type="button" id="farazsms-login-create-page" data-nonce="<?php echo esc_attr( wp_create_nonce( 'farazsms_login_create_page' ) ); ?>" style="background:#16a34a; color:#fff; border:none; padding:10px 22px; font-size:13px; font-weight:600; border-radius:8px; cursor:pointer; font-family:inherit;">
					⚡ ساخت خودکار برگه ورود/ثبت‌نام
				</button>
				<span id="farazsms-login-create-page-status" style="margin-right:10px; font-size:12px; color:#64748b;"></span>
				<p style="margin:10px 0 0; font-size:11px; color:#64748b; line-height:1.7;">
					با کلیک، یک برگه با عنوان «ورود و ثبت‌نام» با قالب اختصاصی «FarazSMS Login Page» ساخته می‌شود. URL آن را در منوی سایت قرار دهید.
				</p>
				<script>
				(function(){
					var btn = document.getElementById('farazsms-login-create-page');
					if (!btn) return;
					btn.addEventListener('click', function(){
						var status = document.getElementById('farazsms-login-create-page-status');
						btn.disabled = true; btn.style.opacity = '0.6';
						status.textContent = 'در حال ساخت برگه…';
						var fd = new FormData();
						fd.append('action', 'farazsms_login_create_page');
						fd.append('nonce', btn.dataset.nonce);
						fetch(ajaxurl, { method:'POST', credentials:'same-origin', body: fd })
							.then(function(r){ return r.json(); })
							.then(function(res){
								if (res && res.success && res.data && res.data.url) {
									status.innerHTML = '✓ برگه ساخته شد — ' + '<a href="' + res.data.edit_url + '">ویرایش</a> | <a href="' + res.data.url + '" target="_blank">مشاهده</a>';
									status.style.color = '#16a34a';
									setTimeout(function(){ window.location.reload(); }, 1500);
								} else {
									var msg = (res && res.data && res.data.message) ? res.data.message : 'خطا';
									status.textContent = '✗ ' + msg;
									status.style.color = '#dc2626';
									btn.disabled = false; btn.style.opacity = '1';
								}
							})
							.catch(function(){
								status.textContent = '✗ خطای ارتباط';
								status.style.color = '#dc2626';
								btn.disabled = false; btn.style.opacity = '1';
							});
					});
				})();
				</script>
			<?php endif; ?>

			<!-- v3.14.10: بخش شورت‌کدها از پایان همه تب‌ها حذف شد — حالا فقط در تب «شورت‌کدها» نمایش داده می‌شود.
			     برای جلوگیری از شلوغی صفحات تنظیمات. -->
		</div>

		<?php
		// نقطه‌ی تزریقِ بخش‌های اضافی در صفحه‌ی ورود/ثبت‌نام (مثلِ پیامکِ خوش‌آمدگویی).
		do_action( 'farazsms_login_register_extra_sections' );
		?>
	</div>
	<?php
}

/**
 * AJAX: ساخت خودکار برگه ورود با قالب FarazSMS Login Page.
 */
add_action( 'wp_ajax_farazsms_login_create_page', 'farazsms_login_create_page_ajax' );
function farazsms_login_create_page_ajax() {
	check_ajax_referer( 'farazsms_login_create_page', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) || ! current_user_can( 'publish_pages' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
	}

	// چک کنیم برگه قبلاً ساخته نشده باشد
	$existing = get_posts( array(
		'post_type'      => 'page',
		'post_status'    => array( 'publish', 'draft' ),
		'posts_per_page' => 1,
		'meta_key'       => '_wp_page_template',
		'meta_value'     => 'farazsms-login-page.php',
		'fields'         => 'ids',
	) );
	if ( ! empty( $existing ) ) {
		$page_id = (int) $existing[0];
		wp_send_json_success( array(
			'url'      => get_permalink( $page_id ),
			'edit_url' => get_edit_post_link( $page_id, 'raw' ),
			'message'  => 'برگه از قبل وجود دارد.',
		) );
	}

	// ساخت برگه جدید
	$page_id = wp_insert_post( array(
		'post_title'    => 'ورود و ثبت‌نام',
		'post_name'     => 'login-register',
		'post_status'   => 'publish',
		'post_type'     => 'page',
		// محتوا باید «خودکفا» باشد: شورت‌کدِ فرم مستقیماً داخلِ محتوا قرار می‌گیرد تا حتی اگر قالبِ
		// اختصاصیِ FarazSMS Login Page توسطِ قالبِ سایت (مثلِ Woodmart/Elementor که روی template_include
		// اولویتِ دیرتری دارند) override شود، فرم باز هم در بدنه‌ی صفحه رندر شود. قبلاً محتوا فقط یک کامنت
		// بود و رندرِ فرم ۱۰۰٪ به بردنِ جنگِ قالب وابسته بود → روی این قالب‌ها صفحه سفید می‌شد.
		'post_content'  => "[farazsms_login_form]\n<!-- فرمِ ورود از شورت‌کدِ بالا رندر می‌شود؛ نیازی به ویرایش نیست. -->",
		'post_author'   => get_current_user_id(),
		'meta_input'    => array(
			'_wp_page_template' => 'farazsms-login-page.php',
		),
	), true );

	if ( is_wp_error( $page_id ) ) {
		wp_send_json_error( array( 'message' => $page_id->get_error_message() ) );
	}

	wp_send_json_success( array(
		'url'      => get_permalink( $page_id ),
		'edit_url' => get_edit_post_link( $page_id, 'raw' ),
		'message'  => 'برگه با موفقیت ساخته شد.',
	) );
}

/**
 * آیا این برگه واقعاً با «المنتور» ساخته شده؟ (نه صرفاً المنتور روی سایت فعال است)
 *
 * برای تشخیصِ دقیقِ برگه‌هایی که طرحِ اختصاصیِ خودشان را دارند و نباید فرمِ پیش‌فرض به آن‌ها تزریق شود.
 * برگه‌ی گوتنبرگ/کلاسیک (حتی اگر المنتور روی سایت فعال باشد) اینجا false برمی‌گردانَد.
 *
 * @param int $page_id
 * @return bool
 */
function farazsms_login_page_is_elementor_built( $page_id ) {
	$page_id = (int) $page_id;
	if ( $page_id <= 0 || ! class_exists( '\\Elementor\\Plugin' ) || ! isset( \Elementor\Plugin::$instance ) ) {
		return false;
	}
	$el = \Elementor\Plugin::$instance;
	if ( ! isset( $el->documents ) ) {
		return false;
	}
	$doc = $el->documents->get( $page_id );
	return $doc && method_exists( $doc, 'is_built_with_elementor' ) && $doc->is_built_with_elementor();
}

/**
 * تضمینِ رندرِ فرمِ ورود روی برگه‌ی قالبِ FarazSMS Login Page — در لحظه‌ی نمایش.
 *
 * مشکلِ ریشه‌ای: نسخه‌های قبلی برگه‌ی ورود را با محتوایی که فقط یک کامنت بود می‌ساختند و رندرِ فرم را
 * ۱۰۰٪ به اعمال‌شدنِ قالبِ اختصاصیِ ما می‌سپردند. روی قالب‌هایی مثلِ Woodmart/Elementor که روی
 * template_include اولویتِ دیرتری دارند، قالبِ ما override می‌شود و چون محتوای برگه شورت‌کد ندارد،
 * بدنه‌ی صفحه سفید می‌مانَد (فرم فقط داخلِ مودالِ هدر است).
 *
 * راهِ حلِ متکی‌به‌خود: به‌جای مهاجرتِ DB که به بازدیدِ ادمین وابسته بود، همین‌جا سرِ خروجیِ محتوا تضمین
 * می‌کنیم که برگه‌ی این قالب همیشه فرمِ ورود را نشان دهد — مستقل از قالبِ فعال، بدونِ نوشتن در DB، و
 * بلافاصله در نخستین بازدیدِ فرانت. این همان «هدفِ اعلام‌شده‌ی» این قالب است (نمایشِ فرمِ ورود)، نه یک
 * وصله روی خطای ناشناخته. اگر محتوا از قبل شورت‌کدِ فرم را داشته باشد، دست نمی‌زنیم (بدونِ فرمِ تکراری).
 *
 * اولویت ۹ تا پیش از do_shortcode (اولویت ۱۱) روی the_content اجرا شود و شورت‌کدِ افزوده پردازش گردد.
 */
add_filter( 'the_content', 'farazsms_login_ensure_form_on_login_page', 9 );
function farazsms_login_ensure_form_on_login_page( $content ) {
	if ( is_admin() || ! is_singular( 'page' ) || ! is_main_query() ) {
		return $content;
	}
	// «غیرفعال = صفر تداخل»: اگر فرانتِ ماژولِ ورود خاموش است، هیچ فرمی تزریق نکن (کدریویو #4).
	if ( defined( 'FARAZSMS_LOGIN_FRONTEND_ENABLED' ) && ! FARAZSMS_LOGIN_FRONTEND_ENABLED ) {
		return $content;
	}
	$queried_id = get_queried_object_id();
	// فقط محتوای «خودِ» برگه‌ی جاری را دست بزن — نه ویجت/related/loopِ فرعی که the_content را صدا می‌زنند.
	if ( ! $queried_id || get_the_ID() !== $queried_id ) {
		return $content;
	}
	if ( get_page_template_slug( $queried_id ) !== 'farazsms-login-page.php' ) {
		return $content;
	}
	if ( has_shortcode( (string) $content, 'farazsms_login_form' ) ) {
		return $content; // محتوا از قبل فرم را دارد — تکراری نساز.
	}
	// اگر برگه واقعاً با المنتور ساخته شده، طرحِ اختصاصیِ خودش را دارد — دست نمی‌زنیم تا فرمِ دومِ
	// اضافه روی طرحش ننشیند (کدریویو #1). ولی برگه‌های معمولی — کامنت‌محور، متن، یا حتی شورت‌کدِ مودالِ
	// [farazsms_login_modal] که فقط دکمه/پاپ‌آپ است و فرمِ inline ندارد — باید فرم بگیرند تا هیچ‌وقت سفید
	// نشوند. گاردِ قبلی («محتوا خالی نیست») این حالت‌ها را اشتباهاً رد می‌کرد و صفحه سفید می‌شد.
	if ( farazsms_login_page_is_elementor_built( $queried_id ) ) {
		return $content;
	}
	// خطِ خالیِ اطراف تا wpautop شورت‌کد را داخلِ <p> نپیچد (کدریویو #6).
	return $content . "\n\n[farazsms_login_form]\n";
}

/**
 * AJAX endpoint: ساخت پترن خودکار OTP برای ماژول login.
 *
 * متن پترن:
 *
 *   کدتایید شما %code%
 *   [domain]
 *
 *   - %code% متغیر عددی ۶ رقمی
 *   - [domain] دامنه سایت (بدون www / http(s))
 *
 * توضیحات پترن: «ساخته شده از طریق افزونه فراز اس ام اس»
 *
 * Endpoint:
 *
 *   POST /ws/v1/pattern  با Api-Key header
 *
 * پاسخ موفق: pattern code در فیلد pattern_code کاربر درج می‌شود (در DOM)
 * و در ذخیره بعدی فرم، در farazsms_login_settings ست می‌شود. کاربر می‌تواند
 * این پترن را تغییر دهد یا دستی کد دیگری وارد کند.
 */
add_action( 'wp_ajax_farazsms_login_autobuild_pattern', 'farazsms_login_autobuild_pattern' );
function farazsms_login_autobuild_pattern() {
	check_ajax_referer( 'farazsms_login_autobuild_pattern', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
	}

	$apikey = trim( (string) get_option( 'farazsms_apikey', '' ) );
	if ( $apikey === '' ) {
		wp_send_json_error( array( 'message' => 'ابتدا کلید دسترسی (Api-Key) را در تنظیمات افزونه وارد کنید.' ) );
	}

	// استخراج دامنه سایت بدون www / http(s) — برای نمایشِ خوانا.
	$domain = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	$domain = preg_replace( '#^www\.#i', '', $domain );

	// v3.21.25 (H1) — هاستِ دقیقِ صفحه برای WebOTP (بدونِ حذفِ www؛ باید با origin صفحه یکی باشد).
	$webotp_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );

	// v3.14.3 BUG FIX: endpoint صحیح `/patterns` + فرمت body صحیح فراز.
	// فرمت: { text, share, website, category, vars: [{var, type, length}] }
	// v3.21.25 (H1): خطِ پایانیِ «@host #code» برای autofillِ خودکارِ کد روی اندروید (WebOTP API).
	// بدونِ این خط، navigator.credentials.get({otp}) هرگز resolve نمی‌شود و کد دستی باید وارد شود.
	$pattern_message = "کدتایید شما %code%\n" . $domain . "\n@" . $webotp_host . " #%code%";
	$payload = array(
		'text'     => $pattern_message,
		'share'    => 0,
		'website'  => get_site_url(),
		'category' => 1,
		'vars'     => array(
			// type باید یکی از enumهای معتبر فراز باشد: 'str' یا 'int'.
			// مقدار قبلی 'number' نامعتبر بود و خطای «vars.0.type صحیح نمی‌باشد» می‌داد.
			array( 'var' => 'code', 'type' => 'int', 'length' => 6 ),
		),
	);
	$args = array(
		'method'    => 'POST',
		'timeout'   => 25,
		'sslverify' => true,
		'headers'   => array(
			'Content-Type' => 'application/json',
			'Accept'       => 'application/json',
			'Api-Key'      => $apikey,
		),
		'body'      => wp_json_encode( $payload, JSON_UNESCAPED_UNICODE ),
	);
	$endpoint = farazsms_sms_api_url( 'patterns' );
	if ( function_exists( 'farazsms_remote_post_with_fallback' ) ) {
		$response = farazsms_remote_post_with_fallback( $endpoint, $args );
	} else {
		$response = wp_remote_post( $endpoint, $args );
	}

	if ( is_wp_error( $response ) ) {
		wp_send_json_error( array( 'message' => 'خطای شبکه: ' . $response->get_error_message() ) );
	}

	$code = (int) wp_remote_retrieve_response_code( $response );
	$body = wp_remote_retrieve_body( $response );
	$data = json_decode( $body, true );

	// استخراج pattern_code از پاسخ — defensive چندین نام فیلد بررسی می‌شود
	$pattern_code = '';
	if ( is_array( $data ) ) {
		if ( ! empty( $data['data']['code'] ) ) {
			$pattern_code = (string) $data['data']['code'];
		} elseif ( ! empty( $data['data'] ) && is_string( $data['data'] ) ) {
			$pattern_code = (string) $data['data'];
		} elseif ( ! empty( $data['code'] ) ) {
			$pattern_code = (string) $data['code'];
		}
	}

	if ( $pattern_code === '' ) {
		$msg = '';
		if ( is_array( $data ) ) {
			if ( isset( $data['messages'] ) ) {
				$msg = is_array( $data['messages'] ) ? implode( '، ', array_map( 'strval', $data['messages'] ) ) : (string) $data['messages'];
			} elseif ( isset( $data['message'] ) ) {
				$msg = (string) $data['message'];
			}
		}
		if ( $msg === '' ) {
			$msg = 'پاسخ نامعتبر از سرور (HTTP ' . $code . ')';
		}
		wp_send_json_error( array( 'message' => $msg ) );
	}

	// ذخیره فوری در farazsms_login_settings تا اگر کاربر هرگز ذخیره نکرد، باز هم باقی بماند.
	$current = get_option( 'farazsms_login_settings', array() );
	if ( ! is_array( $current ) ) {
		$current = array();
	}
	if ( ! isset( $current['sms'] ) || ! is_array( $current['sms'] ) ) {
		$current['sms'] = array();
	}
	$current['sms']['pattern_code'] = $pattern_code;
	update_option( 'farazsms_login_settings', $current, false );

	wp_send_json_success( array(
		'pattern_code' => $pattern_code,
		'message'      => 'پترن با موفقیت ساخته شد.',
	) );
}

/**
 * AJAX endpoint: toggle سریع.
 */
add_action( 'wp_ajax_farazsms_login_module_toggle', 'farazsms_login_module_ajax_toggle' );
function farazsms_login_module_ajax_toggle() {
	check_ajax_referer( 'farazsms_login_module_toggle', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
	}
	$enable = isset( $_POST['enable'] ) && $_POST['enable'] === '1' ? '1' : '0';
	update_option( 'farazsms_login_module_enabled', $enable, false );
	wp_send_json_success( array(
		'enabled' => $enable === '1',
		'message' => $enable === '1' ? 'ماژول فعال شد.' : 'ماژول غیرفعال شد.',
	) );
}

/**
 * Migration: کپی meta شماره موبایل از افزونه‌های دیگر به mobile_number ما.
 *
 * Plugins پشتیبانی‌شده:
 *
 *   - Digits   (meta key: digits_phone)
 *   - Cresno   (meta key: cresno_phone — تحقیق: نام دقیق ممکن است متفاوت باشد)
 *   - WC       (meta key: billing_phone)
 *   - DokanPro (meta key: phone)
 *
 * تابع روی هر کاربر در batch (LIMIT 500) اجرا می‌شود. اگر کاربر هم mobile_number
 * موجود دارد، skip می‌شود (تا انتخاب اولویت کاربر حفظ شود).
 *
 * @param string $from key افزونه مبدأ
 * @param int    $offset برای batch
 * @return array  ['migrated'=>N, 'skipped'=>N, 'total'=>N, 'done'=>bool]
 */
function farazsms_login_migration_run( $from, $offset = 0, $custom_meta = '' ) {
	$map = array(
		'digits'   => 'digits_phone',
		'wc'       => 'billing_phone',
		'dokan'    => 'phone',
	);
	// v3.21.55: کلیدِ متای سفارشی — مدیر هر افزونه‌ی دیگری را با واردکردنِ دستیِ meta key
	// مهاجرت می‌دهد. فقط کاراکترهای مجازِ کلیدِ متا پذیرفته می‌شود.
	if ( $from === 'custom' ) {
		$source_meta = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $custom_meta );
		if ( $source_meta === '' ) {
			return array( 'error' => 'کلیدِ متا (meta key) را وارد کنید.' );
		}
	} elseif ( isset( $map[ $from ] ) ) {
		$source_meta = $map[ $from ];
	} else {
		return array( 'error' => 'افزونه مبدأ ناشناخته است.' );
	}

	global $wpdb;
	$batch_size = 500;

	// همه user_id هایی که meta $source_meta با مقدار غیرخالی دارند
	$rows = $wpdb->get_results( $wpdb->prepare(
		"SELECT user_id, meta_value FROM {$wpdb->usermeta}
		 WHERE meta_key = %s AND meta_value != ''
		 ORDER BY user_id ASC
		 LIMIT %d OFFSET %d",
		$source_meta, $batch_size, (int) $offset
	), ARRAY_A );

	$migrated = 0;
	$skipped  = 0;
	foreach ( $rows as $row ) {
		$user_id = (int) $row['user_id'];
		$value   = trim( (string) $row['meta_value'] );
		if ( $user_id <= 0 || $value === '' ) continue;

		// اگر mobile_number قبلاً مقدار دارد، رد کنیم (اولویت با مقدار موجود)
		$existing = (string) get_user_meta( $user_id, 'mobile_number', true );
		if ( $existing !== '' ) {
			$skipped++;
			continue;
		}
		// نرمال‌سازی به فرمت 09xxxxxxxxx اگر تابع موجود
		$value = farazsms_normalize_phone( $value );
		update_user_meta( $user_id, 'mobile_number', $value );
		// اگر billing_phone خالی است، آن هم پر کنیم (برای WC integration)
		$bp = (string) get_user_meta( $user_id, 'billing_phone', true );
		if ( $bp === '' ) {
			update_user_meta( $user_id, 'billing_phone', $value );
		}
		$migrated++;
	}

	$total_remaining = (int) $wpdb->get_var( $wpdb->prepare(
		"SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value != ''",
		$source_meta
	) );

	return array(
		'migrated' => $migrated,
		'skipped'  => $skipped,
		'batch'    => count( $rows ),
		'total'    => $total_remaining,
		'done'     => count( $rows ) < $batch_size,
	);
}

add_action( 'wp_ajax_farazsms_login_migration_run', 'farazsms_login_migration_ajax' );
function farazsms_login_migration_ajax() {
	check_ajax_referer( 'farazsms_login_migration', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
	}
	$from   = sanitize_key( $_POST['from'] ?? '' );
	$offset = (int) ( $_POST['offset'] ?? 0 );
	$custom = isset( $_POST['custom_meta'] ) ? sanitize_text_field( wp_unslash( $_POST['custom_meta'] ) ) : '';
	$result = farazsms_login_migration_run( $from, $offset, $custom );
	if ( isset( $result['error'] ) ) {
		wp_send_json_error( array( 'message' => $result['error'] ) );
	}
	wp_send_json_success( $result );
}

/**
 * Render تب «مهاجرت».
 */
function farazsms_login_render_migration_tab() {
	$plugins = array(
		'digits' => array(
			'title'    => 'Digits',
			'meta_key' => 'digits_phone',
			'desc'     => 'افزونه ورود/ثبت‌نام با موبایل Digits — meta key کاربر: digits_phone',
		),
		'wc'     => array(
			'title'    => 'WooCommerce',
			'meta_key' => 'billing_phone',
			'desc'     => 'کپی از فیلد billing_phone ووکامرس به mobile_number',
		),
		'dokan'  => array(
			'title'    => 'Dokan',
			'meta_key' => 'phone',
			'desc'     => 'کپی از فیلد phone دکان به mobile_number',
		),
	);
	?>
	<div style="direction:rtl; max-width:780px;">
		<!-- اطلاع‌رسانی: محلِ ذخیره‌ی شماره‌ی موبایل کاربران (منتقل‌شده از بالای صفحه به این تب،
		     چون مرجعِ کم‌اهمیت است و جایگاهِ طبیعی‌اش کنارِ توضیحاتِ مهاجرتِ mobile_number/billing_phone است). -->
		<div style="background:#f8fafc; border:1px solid #e2e8f0; border-right:4px solid #4571ba; border-radius:8px; padding:14px 16px; margin-bottom:18px;">
			<p style="margin:0 0 8px; color:#334155; font-size:13px; font-weight:700;">📱 شماره‌ی موبایلِ کاربران کجا ذخیره می‌شود؟</p>
			<p style="margin:0; color:#475569; font-size:12.5px; line-height:1.95;">
				هنگام ثبت‌نام با موبایل، شماره در سه جا ذخیره می‌شود:
			</p>
			<ul style="margin:8px 0 0; padding-right:18px; color:#475569; font-size:12.5px; line-height:2;">
				<li><strong>نام کاربری وردپرس</strong> (<code>user_login</code>) — خودِ شماره‌ی موبایل به‌عنوان نام کاربری ست می‌شود.</li>
				<li>متای کاربر <code>mobile_number</code> — کلیدِ اصلیِ شماره.</li>
				<li>متای کاربر <code>billing_phone</code> — برای نمایش در ووکامرس و یکپارچگی با صورت‌حساب.</li>
			</ul>
		</div>

		<div style="background:#eef2ff; border:1px solid #c7d2fe; padding:14px 18px; border-radius:10px; margin-bottom:18px;">
			<h4 style="margin:0 0 6px; font-size:14px; font-weight:700; color:#263f67;">🔄 مهاجرت از سایر افزونه‌های ورود</h4>
			<p style="margin:0; font-size:12.5px; color:#365891; line-height:1.9;">
				اگر قبلاً از افزونه دیگری برای ورود با موبایل استفاده می‌کرد‌ید (Digits، Cresno، ...)،
				این ابزار <strong>شماره موبایل کاربران فعلی</strong> را به فرمت مورد نیاز افزونه ما کپی می‌کند.
				کاربران دیگر به‌عنوان مشتری جدید شناسایی نمی‌شوند و با همان حساب قبلی وارد می‌شوند.
			</p>
		</div>

		<div style="background:#fffbeb; border:1px solid #fde68a; padding:12px 16px; border-radius:8px; margin-bottom:18px;">
			<strong style="color:#78350f;">⚠️ نکات مهم:</strong>
			<ul style="margin:6px 0 0 18px; padding:0; font-size:12.5px; color:#92400e; line-height:1.9;">
				<li>قبل از اجرا، از دیتابیس <strong>بکاپ بگیرید</strong>.</li>
				<li>کاربرانی که قبلاً <code>mobile_number</code> غیرخالی دارند، رد می‌شوند (اولویت با مقدار موجود).</li>
				<li>عملیات روی کل کاربران سایت اجرا می‌شود — برای ۱۰k+ کاربر، چند دقیقه طول می‌کشد.</li>
				<li>افزونه مبدأ بعد از مهاجرت همچنان می‌تواند فعال باشد — این فقط کپی است نه حذف.</li>
			</ul>
		</div>

		<?php foreach ( $plugins as $key => $cfg ) : ?>
			<div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:16px 18px; margin-bottom:12px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
				<div style="flex:1 1 300px;">
					<div style="font-size:14px; font-weight:700; color:#0f172a;"><?php echo esc_html( $cfg['title'] ); ?></div>
					<div style="font-size:11.5px; color:#64748b; margin-top:4px;"><?php echo esc_html( $cfg['desc'] ); ?></div>
				</div>
				<button type="button" class="farazsms-login-migration-btn" data-from="<?php echo esc_attr( $key ); ?>" data-title="<?php echo esc_attr( $cfg['title'] ); ?>" data-nonce="<?php echo esc_attr( wp_create_nonce( 'farazsms_login_migration' ) ); ?>" data-ajaxurl="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" style="background:#365891; color:#fff; border:none; padding:8px 18px; font-size:13px; font-weight:600; border-radius:6px; cursor:pointer; font-family:inherit;">
					🔄 شروع مهاجرت
				</button>
			</div>
		<?php endforeach; ?>

		<!-- v3.21.55: کلیدِ متای سفارشی — هر افزونه‌ی دیگر -->
		<div style="background:#fff; border:1px dashed #94a3b8; border-radius:10px; padding:16px 18px; margin-bottom:12px;">
			<div style="font-size:14px; font-weight:700; color:#0f172a; margin-bottom:4px;">افزونه‌ی دیگر (کلیدِ سفارشی)</div>
			<div style="font-size:11.5px; color:#64748b; margin-bottom:10px;">اگر از افزونه‌ی دیگری استفاده می‌کردید، کلیدِ متای (meta key) شماره موبایلِ آن را اینجا وارد کنید تا کاربرانش مهاجرت کنند. (اگر کلید را نمی‌دانید، از پشتیبانیِ آن افزونه بپرسید.)</div>
			<div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
				<input type="text" id="farazsms-login-migration-custom-meta" placeholder="مثلاً: user_mobile یا mobile" dir="ltr" style="flex:1 1 260px; padding:8px 12px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px; direction:ltr; text-align:left; font-family:monospace;">
				<button type="button" class="farazsms-login-migration-btn" data-from="custom" data-title="کلیدِ سفارشی" data-custom-input="farazsms-login-migration-custom-meta" data-nonce="<?php echo esc_attr( wp_create_nonce( 'farazsms_login_migration' ) ); ?>" data-ajaxurl="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>" style="background:#365891; color:#fff; border:none; padding:8px 18px; font-size:13px; font-weight:600; border-radius:6px; cursor:pointer; font-family:inherit;">
					🔄 شروع مهاجرت
				</button>
			</div>
		</div>

		<div id="farazsms-login-migration-result" style="margin-top:16px;"></div>

		<script>
		(function(){
			document.querySelectorAll('.farazsms-login-migration-btn').forEach(function(btn){
				btn.addEventListener('click', function(){
					var customMeta = '';
					if (btn.dataset.from === 'custom') {
						var ci = document.getElementById(btn.dataset.customInput);
						customMeta = ci ? ci.value.trim() : '';
						if (!customMeta) { alert('ابتدا کلیدِ متا (meta key) را وارد کنید.'); return; }
					}
					if (!confirm('آیا مطمئن هستید می‌خواهید مهاجرت از ' + btn.dataset.title + ' را آغاز کنید؟ این عملیات روی همه کاربران سایت اجرا می‌شود.')) return;
					var resultBox = document.getElementById('farazsms-login-migration-result');
					var totalMigrated = 0, totalSkipped = 0, offset = 0;
					btn.disabled = true; btn.style.opacity = '0.6';
					resultBox.innerHTML = '<div style="background:#eef2ff; border:1px solid #c7d2fe; padding:12px 16px; border-radius:8px; color:#263f67;">⏳ در حال اجرا… (batch ' + offset + ')</div>';

					function runBatch(){
						var fd = new FormData();
						fd.append('action', 'farazsms_login_migration_run');
						fd.append('nonce', btn.dataset.nonce);
						fd.append('from', btn.dataset.from);
						fd.append('offset', offset);
						if (btn.dataset.from === 'custom') { fd.append('custom_meta', customMeta); }
						fetch(btn.dataset.ajaxurl, { method:'POST', credentials:'same-origin', body: fd })
							.then(function(r){ return r.json(); })
							.then(function(res){
								if (!res || !res.success) {
									resultBox.innerHTML = '<div style="background:#fef2f2; border:1px solid #fecaca; padding:12px 16px; border-radius:8px; color:#b91c1c;">✗ ' + ((res && res.data && res.data.message) || 'خطا') + '</div>';
									btn.disabled = false; btn.style.opacity = '1'; return;
								}
								totalMigrated += res.data.migrated;
								totalSkipped  += res.data.skipped;
								offset        += res.data.batch;
								resultBox.innerHTML = '<div style="background:#eef2ff; border:1px solid #c7d2fe; padding:12px 16px; border-radius:8px; color:#263f67;">⏳ پردازش… منتقل‌شده: ' + totalMigrated + ' | رد شده: ' + totalSkipped + ' | تا اینجا: ' + offset + ' کاربر</div>';
								if (res.data.done) {
									resultBox.innerHTML = '<div style="background:#ecfdf5; border:1px solid #a7f3d0; padding:14px 18px; border-radius:8px; color:#065f46;">✓ مهاجرت کامل شد. <strong>' + totalMigrated + '</strong> کاربر منتقل شد و <strong>' + totalSkipped + '</strong> کاربر رد شد (mobile_number از قبل داشتند).</div>';
									btn.disabled = false; btn.style.opacity = '1';
								} else {
									runBatch();
								}
							})
							.catch(function(){
								resultBox.innerHTML = '<div style="background:#fef2f2; border:1px solid #fecaca; padding:12px 16px; border-radius:8px; color:#b91c1c;">✗ خطای ارتباط</div>';
								btn.disabled = false; btn.style.opacity = '1';
							});
					}
					runBatch();
				});
			});
		})();
		</script>
	</div>
	<?php
}

/**
 * Render تب «شورت‌کدها».
 * شورت‌کدهای ماژول login + نحوه استفاده.
 */
function farazsms_login_render_shortcodes_tab() {
	?>
	<div style="direction:rtl; max-width:860px;">
		<div style="background:#eef2ff; border:1px solid #c7d2fe; padding:14px 18px; border-radius:10px; margin-bottom:18px;">
			<h4 style="margin:0 0 6px; font-size:14px; font-weight:700; color:#263f67;">🔤 شورت‌کدهای موجود</h4>
			<p style="margin:0; font-size:12.5px; color:#365891; line-height:1.9;">
				برای نمایش فرم یا دکمه ورود/ثبت‌نام در هر صفحه، نوشته یا ویجت سایت خود از این شورت‌کدها استفاده کنید.
			</p>
		</div>

		<!-- Shortcode 1: Login Form (Full) -->
		<div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:18px 22px; margin-bottom:16px; border-right:4px solid #16a34a;">
			<h4 style="margin:0 0 8px; font-size:14px; font-weight:700; color:#0f172a;">📋 فرم کامل ورود / ثبت‌نام</h4>
			<p style="margin:0 0 12px; font-size:12.5px; color:#475569; line-height:1.9;">
				نمایش <strong>فرم کامل</strong> ورود/ثبت‌نام در هر صفحه یا پست. اگر می‌خواهید فرم را داخل صفحه‌ای از قبل موجود اضافه کنید (مثلاً یک صفحه فرود)، این شورت‌کد را در آن قرار دهید.
			</p>
			<div style="background:#0f172a; color:#e2e8f0; border-radius:6px; padding:12px 14px; direction:ltr; text-align:left; font-family:monospace; font-size:13px;">
				[farazsms_login_form]
			</div>
		</div>

		<!-- Shortcode: Login Modal (popup) -->
		<div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:18px 22px; margin-bottom:16px; border-right:4px solid #db2777;">
			<h4 style="margin:0 0 8px; font-size:14px; font-weight:700; color:#0f172a;">🪟 فرم ورود به‌صورت پاپ‌آپ (مودال)</h4>
			<p style="margin:0 0 12px; font-size:12.5px; color:#475569; line-height:1.9;">
				یک <strong>دکمه</strong> نمایش می‌دهد که با کلیک، فرمِ ورود/ثبت‌نام در یک <strong>پنجره‌ی شناور (پاپ‌آپ)</strong> باز می‌شود — بدون انتقال به صفحه‌ی دیگر. کاربرِ واردشده به‌جای آن، لینکِ «حساب من» می‌بیند. رنگ، متن و عرضِ پنجره دلخواهِ شماست.
			</p>
			<div style="background:#0f172a; color:#e2e8f0; border-radius:6px; padding:12px 14px; margin-bottom:10px; direction:ltr; text-align:left; font-family:monospace; font-size:13px;">
				[farazsms_login_modal]
			</div>
			<div style="font-size:11.5px; font-weight:600; color:#475569; margin:14px 0 6px;">با پارامترهای دلخواه:</div>
			<div style="background:#0f172a; color:#e2e8f0; border-radius:6px; padding:12px 14px; direction:ltr; text-align:left; font-family:monospace; font-size:12.5px; line-height:1.9;">
				[farazsms_login_modal<br>
				&nbsp;&nbsp;text="ورود / ثبت‌نام"<br>
				&nbsp;&nbsp;bg_color="#db2777"<br>
				&nbsp;&nbsp;text_color="#fff"<br>
				&nbsp;&nbsp;width="420"<br>
				]
			</div>
		</div>

		<!-- Shortcode 2: Login Button -->
		<div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:18px 22px; margin-bottom:16px; border-right:4px solid #365891;">
			<h4 style="margin:0 0 8px; font-size:14px; font-weight:700; color:#0f172a;">🔘 دکمه ورود / ثبت‌نام</h4>
			<p style="margin:0 0 12px; font-size:12.5px; color:#475569; line-height:1.9;">
				نمایش <strong>دکمه «ورود/ثبت‌نام»</strong> که به برگه فرم منتقل می‌کند. اگر کاربر قبلاً وارد شده، دکمه «حساب کاربری من» نمایش داده می‌شود.
			</p>
			<div style="background:#0f172a; color:#e2e8f0; border-radius:6px; padding:12px 14px; margin-bottom:10px; direction:ltr; text-align:left; font-family:monospace; font-size:13px;">
				[farazsms_login_button]
			</div>

			<div style="font-size:11.5px; font-weight:600; color:#475569; margin:14px 0 6px;">با پارامترهای دلخواه:</div>
			<div style="background:#0f172a; color:#e2e8f0; border-radius:6px; padding:12px 14px; direction:ltr; text-align:left; font-family:monospace; font-size:12.5px; line-height:1.9;">
				[farazsms_login_button<br>
				&nbsp;&nbsp;bg_color="#365891"<br>
				&nbsp;&nbsp;text_color="#fff"<br>
				&nbsp;&nbsp;text="ورود/ثبت‌نام"<br>
				&nbsp;&nbsp;account_text="حساب کاربری"<br>
				]
			</div>

			<details style="margin-top:12px;">
				<summary style="cursor:pointer; font-size:12px; font-weight:600; color:#365891;">جدول کامل پارامترها</summary>
				<table style="width:100%; margin-top:10px; border-collapse:collapse; font-size:12px;">
					<thead style="background:#f8fafc;">
						<tr>
							<th style="text-align:right; padding:8px 10px; border:1px solid #e5e7eb; font-weight:700;">پارامتر</th>
							<th style="text-align:right; padding:8px 10px; border:1px solid #e5e7eb; font-weight:700;">توضیح</th>
							<th style="text-align:right; padding:8px 10px; border:1px solid #e5e7eb; font-weight:700;">پیش‌فرض</th>
						</tr>
					</thead>
					<tbody>
						<tr><td style="padding:8px 10px; border:1px solid #e5e7eb;"><code>bg_color</code></td><td style="padding:8px 10px; border:1px solid #e5e7eb;">رنگ پس‌زمینه دکمه (HEX)</td><td style="padding:8px 10px; border:1px solid #e5e7eb;">#0BD08B</td></tr>
						<tr><td style="padding:8px 10px; border:1px solid #e5e7eb;"><code>text_color</code></td><td style="padding:8px 10px; border:1px solid #e5e7eb;">رنگ متن دکمه (HEX)</td><td style="padding:8px 10px; border:1px solid #e5e7eb;">#ffffff</td></tr>
						<tr><td style="padding:8px 10px; border:1px solid #e5e7eb;"><code>text</code></td><td style="padding:8px 10px; border:1px solid #e5e7eb;">متن دکمه برای کاربر مهمان</td><td style="padding:8px 10px; border:1px solid #e5e7eb;">ورود / ثبت‌نام</td></tr>
						<tr><td style="padding:8px 10px; border:1px solid #e5e7eb;"><code>account_text</code></td><td style="padding:8px 10px; border:1px solid #e5e7eb;">متن دکمه برای کاربر وارد شده</td><td style="padding:8px 10px; border:1px solid #e5e7eb;">حساب کاربری من</td></tr>
						<tr><td style="padding:8px 10px; border:1px solid #e5e7eb;"><code>account_url</code></td><td style="padding:8px 10px; border:1px solid #e5e7eb;">URL سفارشی صفحه حساب کاربری</td><td style="padding:8px 10px; border:1px solid #e5e7eb;">my-account ووکامرس</td></tr>
					</tbody>
				</table>
			</details>
		</div>

		<div style="background:#fffbeb; border:1px solid #fde68a; padding:12px 16px; border-radius:8px;">
			<p style="margin:0; font-size:12px; color:#78350f; line-height:1.9;">
				💡 <strong>نکته:</strong> برای ساخت یک صفحه اختصاصی ورود/ثبت‌نام بدون استفاده از شورت‌کد، یک صفحه جدید بسازید و قالب آن را روی <code>FarazSMS Login Page</code> تنظیم کنید — سپس از لینک منوی «ورود» به این صفحه ببرید.
			</p>
		</div>
	</div>
	<?php
}

/**
 * آمار برای داشبورد افزونه.
 */
function farazsms_login_module_get_stats() {
	global $wpdb;
	$total_users = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->users}" );
	$module_users = (int) $wpdb->get_var( $wpdb->prepare(
		"SELECT COUNT(DISTINCT user_id) FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value != ''",
		'mobile_number'
	) );
	return array(
		'total_users'  => $total_users,
		'module_users' => $module_users,
		'enabled'      => farazsms_login_module_is_enabled(),
	);
}

// ============================================================================
// ویجتِ Elementor برای فرمِ ورود/ثبت‌نام
// ============================================================================

add_action( 'elementor/widgets/register', 'farazsms_login_register_elementor_widget' );
/**
 * ثبتِ ویجت — فایل فقط داخلِ همین هوک require می‌شود تا روی سایتِ بدونِ المنتور
 * هیچ هزینه‌ای نداشته باشد.
 *
 * @param mixed $widgets_manager
 */
function farazsms_login_register_elementor_widget( $widgets_manager ) {
	if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
		return;
	}
	require_once __DIR__ . '/farazsms-login-elementor-widget.php';
	if ( class_exists( 'FarazSMS_Login_Form_Elementor_Widget' )
		&& is_object( $widgets_manager ) && method_exists( $widgets_manager, 'register' ) ) {
		$widgets_manager->register( new FarazSMS_Login_Form_Elementor_Widget() );
	}
}
