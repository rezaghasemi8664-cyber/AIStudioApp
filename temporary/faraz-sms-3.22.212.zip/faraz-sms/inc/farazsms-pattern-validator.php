<?php
/**
 * اعتبارسنجیِ متنِ پترن — جلوگیری از ساختِ پترنی که پنلِ فراز رد می‌کند.
 *
 * قاعده: اگر چند متغیر (varN) پشتِ سرِ هم و بدونِ توضیحِ متنی بینشان بیایند،
 * پنلِ فراز پترن را رد می‌کند (چون پس از تأیید، دیگر متنِ پیامک بازبینی نمی‌شود
 * و باید کلیتِ متن مشخص باشد). این فایل پیش از ارسال به API جلوی این اشتباه را
 * می‌گیرد تا تیمِ پشتیبانی مجبور نباشد ۱۲ ساعت بعد پترن را رد کند.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * آیا متنِ پترن بیش از حدِ مجاز متغیرِ پشت‌سرهم (بدونِ حرف/توضیح بینشان) دارد؟
 *
 * تا سقفِ مجاز (پیش‌فرض ۲) متغیرِ پشت‌سرهم اجازه داده می‌شود — چون «نام و نام‌خانوادگی»
 * پشتِ سرِ هم یک نیازِ رایج و طبیعی است و مجبورکردنِ کاربر به نوشتنِ برچسب برای هر کدام،
 * تجربه‌ی کاربریِ بدی است. فقط زنجیره‌ی ۳ متغیر یا بیشتر (بدونِ توضیح) رد می‌شود.
 *
 * سقف با فیلترِ farazsms_pattern_max_consecutive_vars قابلِ تغییر است.
 *
 * @param string   $pattern_text متنِ پترن با placeholderهای %varN% یا {varN}.
 * @param int|null $max_run      بیشینه‌ی متغیرِ پشت‌سرهمِ مجاز (null = از فیلتر/پیش‌فرضِ ۲).
 * @return bool true یعنی غیرمجاز است.
 */
function farazsms_pattern_has_bare_consecutive_vars( $pattern_text, $max_run = null ) {
	$pattern_text = (string) $pattern_text;
	if ( $max_run === null ) {
		$max_run = (int) apply_filters( 'farazsms_pattern_max_consecutive_vars', 2 );
	}
	if ( $max_run < 1 ) {
		$max_run = 1;
	}
	if ( ! preg_match_all( '/[%{]\s*var\d+\s*[%}]/u', $pattern_text, $m, PREG_OFFSET_CAPTURE ) ) {
		return false;
	}
	$matches = $m[0];
	$n       = count( $matches );
	if ( $n <= $max_run ) {
		return false;
	}
	// طولِ زنجیره‌ی جاری از متغیرهای پشت‌سرهمِ بدونِ توضیح؛ با دیدنِ حرف بینِ دو متغیر ریست می‌شود.
	$run = 1;
	for ( $i = 1; $i < $n; $i++ ) {
		$prev_end  = $matches[ $i - 1 ][1] + strlen( $matches[ $i - 1 ][0] );
		$cur_start = $matches[ $i ][1];
		$between   = substr( $pattern_text, $prev_end, $cur_start - $prev_end );
		if ( ! preg_match( '/[a-zA-Z\x{0600}-\x{06FF}]/u', $between ) ) {
			$run++;
			if ( $run > $max_run ) {
				return true; // زنجیره‌ی بلندتر از حدِ مجاز.
			}
		} else {
			$run = 1; // حرفِ توضیحی بینشان بود → زنجیره شکست.
		}
	}
	return false;
}

/**
 * پیامِ راهنمای رد — با مثالِ مجاز و غیرمجاز (تجربه‌ی کاربریِ بهتر).
 *
 * @return string
 */
function farazsms_pattern_var_warning_message() {
	return "❌ این الگوی پترن مورد تأیید قرار نمی‌گیرد.\n\n"
		. "بیش از ۲ متغیر را پشتِ سرِ هم و بدونِ توضیح گذاشته‌اید. حداکثر ۲ متغیرِ پشت‌سرهم مجاز است (مثلِ نام و نام‌خانوادگی)؛ برای بیشتر، بینشان یک توضیحِ متنی بگذارید.\n\n"
		. "✅ مجاز (تا ۲ متغیرِ پشت‌سرهم):\n\n"
		. "var1 var2\n\n"
		. "یا با برچسب:\n\n"
		. "نام: var1 موبایل: var2\n\n"
		. "❌ نمونه‌ی نادرست (۳ متغیر یا بیشترِ پشت‌سرهم):\n\n"
		. "var1 var2 var3\n\n"
		. "راهِ درست برای ۳ متغیر یا بیشتر: پیش از هر گروه توضیح بگذارید:\n\n"
		. "نام: var1 var2 موبایل: var3\n\n"
		. "نکته: نام برند به‌صورتِ خودکار به انتهای پترن اضافه می‌شود — لازم نیست خودتان بنویسید.";
}

// ============================================================================
// v3.22.177 — متنِ پترن و سنیتایزرِ هسته‌ی وردپرس
// ============================================================================

/** کلید و نسخه‌ی پرچمِ ترمیم (نسخه‌دار، تا پاسِ بعدی ممکن بماند). */
if ( ! defined( 'FARAZSMS_PATTERN_REPAIR_FLAG' ) ) {
	define( 'FARAZSMS_PATTERN_REPAIR_FLAG', 'farazsms_pattern_repair_done' );
}
if ( ! defined( 'FARAZSMS_PATTERN_REPAIR_VERSION' ) ) {
	define( 'FARAZSMS_PATTERN_REPAIR_VERSION', '2' );
}

/**
 * پاک‌سازیِ امنِ «متنِ پترن» — جایگزینِ sanitize_textarea_field برای متنی که جای‌گیر دارد.
 *
 * ⚠️ ریشه‌ی باگی که ماه‌ها «پترنِ کش‌بک خراب ساخته می‌شود» دیده می‌شد:
 * هسته‌ی وردپرس در _sanitize_text_fields() این کار را می‌کند —
 *
 *     while ( preg_match( '/%[a-f0-9]{2}/i', $filtered, $match ) ) {
 *         $filtered = str_replace( $match[0], '', $filtered );
 *     }
 *
 * یعنی هر «٪ + دو کاراکترِ هگز» را **حذف** می‌کند. پس %balance% به «lance%» و
 * %days_left% به «ys_left%» تبدیل می‌شد — پیش از آنکه متن اصلاً به پنل برسد.
 * مقصر پنلِ فراز نبود؛ ذخیره‌سازیِ خودمان بود.
 *
 * راهکار: جای‌گیرها پیش از سنیتایز کنار گذاشته و پس از آن سرِ جایشان برمی‌گردند.
 * فقط توکن‌هایی که خودمان از متنِ ورودی استخراج کرده‌ایم (و صرفاً حرف/رقم/زیرخط‌اند)
 * بازگردانده می‌شوند، پس هیچ راهِ تازه‌ای برای تزریق باز نمی‌شود.
 *
 * @param string $raw مقدارِ خام (هنوز unslash نشده).
 * @return string
 */
function farazsms_sanitize_pattern_text( $raw, $unslash = true ) {
	// sanitize_textarea_field برای آرایه/آبجکت رشته‌ی خالی می‌دهد؛ همان رفتار حفظ می‌شود
	// تا ارسالِ message[] فقط یک هشدارِ PHP و رشته‌ی «Array» تولید نکند.
	if ( is_array( $raw ) || is_object( $raw ) ) {
		return '';
	}
	$text = (string) $raw;
	if ( $unslash && function_exists( 'wp_unslash' ) ) {
		$text = wp_unslash( $text );
	}

	// نشانه در هر فراخوانی یکتاست: نشانه‌ی ثابت را کاربر می‌توانست عیناً تایپ کند و
	// آن‌وقت متنِ خودش با یک جای‌گیر جایگزین می‌شد.
	$salt         = function_exists( 'wp_generate_password' ) ? wp_generate_password( 8, false, false ) : (string) mt_rand( 100000, 999999 );
	$placeholders = array();
	$masked       = preg_replace_callback(
		'/%[A-Za-z_][A-Za-z0-9_]{0,60}%/',
		function ( $m ) use ( &$placeholders, $salt ) {
			$key                  = '@@FZ' . $salt . count( $placeholders ) . 'ZF@@';
			$placeholders[ $key ] = $m[0];
			return $key;
		},
		$text
	);
	// روی ورودیِ خرابِ UTF-8، preg_replace_callback مقدارِ null می‌دهد؛ آن‌وقت باید به
	// مسیرِ امنِ معمولی برگردیم، نه اینکه متنِ کاربر را با null جایگزین کنیم.
	if ( ! is_string( $masked ) ) {
		return function_exists( 'sanitize_textarea_field' ) ? sanitize_textarea_field( $text ) : trim( strip_tags( $text ) );
	}

	$clean = function_exists( 'sanitize_textarea_field' ) ? sanitize_textarea_field( $masked ) : trim( strip_tags( $masked ) );

	return $placeholders ? strtr( $clean, $placeholders ) : $clean;
}

/**
 * فهرستِ متغیرهایی که سنیتایزرِ هسته خرابشان می‌کند (نامشان با دو کاراکترِ هگز شروع می‌شود).
 * از اسکنِ متغیرهای واقعیِ افزونه به‌دست آمده است.
 *
 * @return string[]
 */
function farazsms_pattern_hexstripped_vars() {
	return array( 'balance', 'days_left', 'date', 'address', 'address_1', 'address_2' );
}

/**
 * ترمیمِ متنِ پترنی که پیش از این نسخه خراب ذخیره شده است.
 *
 * «lance%» را به «%balance%» برمی‌گرداند و مانندِ آن. برای اینکه متنِ سالم دوباره خراب
 * نشود، فقط جایی می‌گیرد که پیش از تکه‌ی خراب، حرف/رقم/زیرخط یا ٪ نباشد.
 *
 * @param string $text
 * @return string
 */
function farazsms_pattern_text_repair( $text ) {
	$text = (string) $text;
	if ( $text === '' ) {
		return $text;
	}
	// چند پاس: جای‌گیرهای چسبیده (%date%%balance% → te%lance%) در یک پاس فقط تا اولی
	// ترمیم می‌شوند، چون پس از ترمیمِ اولی، دومی حالا بعد از یک ٪ قرار می‌گیرد.
	for ( $pass = 0; $pass < 3; $pass++ ) {
		$before = $text;
		foreach ( farazsms_pattern_hexstripped_vars() as $var ) {
			$damaged = substr( $var, 2 );
			if ( $damaged === '' ) {
				continue;
			}
			// حروفِ بزرگ هم باید بگیرد: هسته بدونِ توجه به کوچک/بزرگ حذف می‌کند، پس
			// %BALANCE% هم به «LANCE%» تبدیل شده است.
			$fixed = preg_replace(
				'/(?<![A-Za-z0-9_])' . preg_quote( $damaged, '/' ) . '%/iu',
				'%' . $var . '%',
				$text
			);
			// روی UTF-8 خراب، preg_replace مقدارِ null می‌دهد — متنِ کاربر نباید نابود شود.
			if ( is_string( $fixed ) ) {
				$text = $fixed;
			}
		}
		if ( $text === $before ) {
			break;
		}
	}
	return $text;
}

/**
 * آپشن‌هایی که متنِ پیامک در آن‌ها ذخیره می‌شود.
 *
 * ⚠️ نام‌ها از خودِ سورسِ همان ماژول‌ها استخراج شده‌اند، نه از حدس: نسخه‌ی اولِ این فهرست
 * دستی نوشته شد و ۸ نام از ۲۰ تا اصلاً وجود نداشت — یعنی مهاجرت برای آن بخش‌ها بی‌صدا
 * هیچ کاری نمی‌کرد و پرچمِ «انجام شد» هم جلوی تلاشِ دوباره را می‌گرفت.
 *
 * @return string[]
 */
function farazsms_pattern_repairable_options() {
	return array(
		'farazsms_cashback_settings',
		'farazsms_notify_settings',
		'farazsms_abandoned_settings',
		'farazsms_order_sms_settings',
		'farazsms_login_security_settings',
		'farazsms_spin_wheel_settings',
		'farazsms_birthday_settings',
		'farazsms_daily_sales_settings',
		'farazsms_weekly_report_settings',
		'farazsms_monthly_report_settings',
		'farazsms_low_stock_settings',
		'farazsms_nostock_settings',
		'farazsms_wallet_topup_settings',
		'farazsms_campaign_settings',
		'farazsms_login_welcome_settings',
		'farazsms_pws_settings',
		'farazsms_lm_reminder_settings',
		'farazsms_jfb_rules',
		'farazsms_spotplayer_settings',
	);
}

/**
 * کلیدهایی که مقدارشان «متنِ پیامک» است.
 *
 * ترمیم فقط روی این‌ها اجرا می‌شود: راه‌رفتنِ کور روی همه‌ی رشته‌های یک آپشن یعنی کدِ
 * پترن، شماره‌ی خط، کدِ تخفیف و نشانیِ اینترنتی هم زیرِ regex بروند.
 *
 * @return string[]
 */
function farazsms_pattern_message_keys() {
	// از فراخوانی‌های واقعیِ farazsms_sanitize_pattern_text استخراج شده است؛
	// «otp_message» در نسخه‌ی اول جا افتاده بود و «lose_message»/«reminder_message»
	// اصلاً نوشته نمی‌شدند (همان تلهٔ فهرستِ دستی، یک تابع بعدتر).
	return array(
		'message', 'pattern_message', 'customer_message', 'admin_message',
		'otp_message', 'win_message', 'content', 'text',
	);
}

/**
 * ترمیمِ بازگشتی — فقط روی کلیدهای متنِ پیامک.
 *
 * @param mixed  $value
 * @param bool   $changed با ارجاع؛ اگر چیزی عوض شد true می‌شود.
 * @param string $key     کلیدِ فعلی (در ریشه خالی است).
 * @return mixed
 */
function farazsms_pattern_repair_deep( $value, &$changed, $key = '' ) {
	if ( is_string( $value ) ) {
		// $key === '' یعنی خودِ آپشن یک رشته است (نه آرایه‌ای از کلیدها) — آن‌وقت
		// خودش «متنِ پیام» است. بدونِ این شرط، شاخه‌ی رشته‌ایِ مهاجرت مرده بود.
		if ( $key !== '' && ! in_array( $key, farazsms_pattern_message_keys(), true ) ) {
			return $value;
		}
		$fixed = farazsms_pattern_text_repair( $value );
		if ( $fixed !== $value ) {
			$changed = true;
		}
		return $fixed;
	}
	if ( is_array( $value ) ) {
		foreach ( $value as $k => $v ) {
			$value[ $k ] = farazsms_pattern_repair_deep( $v, $changed, is_string( $k ) ? $k : $key );
		}
	}
	return $value;
}

/**
 * ترمیمِ یک‌باره‌ی متن‌های خراب‌شده روی سایت‌هایی که پیش از این نسخه ذخیره کرده‌اند.
 *
 * بدونِ این، رفعِ سنیتایزر فقط جلوی خرابیِ **تازه** را می‌گرفت و متنی که ماه‌ها پیش خراب
 * ذخیره شده بود همچنان خراب می‌مانْد و پترنِ غلط می‌ساخت.
 */
add_action( 'admin_init', 'farazsms_pattern_repair_stored_messages' );
function farazsms_pattern_repair_stored_messages() {
	// فقط در پیشخوانِ واقعی و با دسترسیِ مدیر: admin_init روی admin-ajax (از جمله
	// درخواست‌های مهمان) هم آتش می‌کند و آنجا نه لازم است نه امن.
	if ( ! is_admin() || ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( get_option( FARAZSMS_PATTERN_REPAIR_FLAG ) === FARAZSMS_PATTERN_REPAIR_VERSION ) {
		return;
	}

	foreach ( farazsms_pattern_repairable_options() as $opt ) {
		$value = get_option( $opt, null );
		if ( ! is_array( $value ) && ! is_string( $value ) ) {
			continue;
		}
		$changed = false;
		$fixed   = farazsms_pattern_repair_deep( $value, $changed );
		if ( $changed ) {
			// بدونِ آرگومانِ سوم تا autoloadِ فعلیِ آپشن دست‌نخورده بماند؛ دادنِ false
			// آپشن‌های autoloadشده را از حالتِ autoload درمی‌آورد و به هر بارگذاریِ
			// صفحه یک کوئریِ اضافه می‌افزاید.
			update_option( $opt, $fixed );
			// روی هاستِ آبجکت‌کشِ پایدار، خواندنِ بعدی می‌تواند مقدارِ کهنه را ببیند.
			if ( function_exists( 'wp_cache_delete' ) ) {
				wp_cache_delete( $opt, 'options' );
				wp_cache_delete( 'alloptions', 'options' );
			}
		}
	}

	// پرچم با «نسخه» کلید می‌خورد: اگر بعداً فهرستِ متغیرها یا آپشن‌ها کامل‌تر شد،
	// یک پاسِ تازه ممکن بماند (پرچمِ بولیِ قبلی این راه را برای همیشه می‌بست).
	update_option( FARAZSMS_PATTERN_REPAIR_FLAG, FARAZSMS_PATTERN_REPAIR_VERSION, false );
}
