<?php
/*
*
*	***** Integration with Persian WooCommerce SMS *****
*
*	این فایل Gateway جدید Farazsms.com(Next) را به افزونه پیامک پیشفرض اضافه می‌کند
*	
*/
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Compatibility shim for some PWSMS gateway packs.
 *
 * In some installations, gateway files may still reference the legacy
 * `PW\PWSMS\Gateways\GatewayInterface` / `GatewayTrait` while the core plugin
 * has moved to the abstract `Gateway` base class (7.2+). If those legacy
 * symbols are missing, PHP fatals while PWSMS scans gateways.
 *
 * We provide minimal no-op definitions to prevent a white screen.
 */
if ( ! interface_exists( 'PW\PWSMS\Gateways\GatewayInterface', false ) ) {
	// phpcs:ignore WordPress.NamingConventions.ValidClassName.NamespaceName
	interface PW_PWSMS_GatewayInterface_Shim {
		public static function id();
		public static function name();
		public function send();
	}
	class_alias( 'PW_PWSMS_GatewayInterface_Shim', 'PW\PWSMS\Gateways\GatewayInterface' );
}
if ( ! trait_exists( 'PW\PWSMS\Gateways\GatewayTrait', false ) ) {
	// phpcs:ignore WordPress.NamingConventions.ValidClassName.NamespaceName
	trait PW_PWSMS_GatewayTrait_Shim {}
	class_alias( 'PW_PWSMS_GatewayTrait_Shim', 'PW\PWSMS\Gateways\GatewayTrait' );
}

/**
 * Ensure Faraz gateways can be autoloaded on demand.
 *
 * PWSMS 7.2+ validates the selected gateway with class_exists() and
 * is_subclass_of(..., Gateway::class). If our gateway class isn't loaded yet,
 * it falls back to Logger (pwsms.log) and test send "succeeds" without sending.
 *
 * This autoloader guarantees the class is defined before PWSMS instantiates it.
 */
spl_autoload_register(
	static function ( $class ) {
		if ( $class !== 'PW\\PWSMS\\Gateways\\FarazSMSNext' && $class !== 'PW\\PWSMS\\Gateways\\IranPayamak' ) {
			return;
		}
		if ( ! defined( 'FARAZSMS_CORE_INC' ) ) {
			return;
		}
		$gateway_file = FARAZSMS_CORE_INC . 'farazsms-farazsmsnext-gateway.php';
		if ( file_exists( $gateway_file ) ) {
			require_once $gateway_file;
		}
	},
	true,
	true
);

/**
 * Persian WooCommerce SMS 7.1 (GatewayInterface) or 7.2+ (abstract Gateway).
 *
 * @return bool
 */
function farazsms_pwsms_supports_custom_gateways() {
	if ( interface_exists( 'PW\PWSMS\Gateways\GatewayInterface' ) && trait_exists( 'PW\PWSMS\Gateways\GatewayTrait' ) ) {
		return true;
	}
	return class_exists( 'PW\PWSMS\Gateways\Gateway' );
}

/**
 * @return void
 */
function farazsms_ensure_farazsmsnext_gateway_loaded() {
	if ( ! farazsms_pwsms_supports_custom_gateways() ) {
		return;
	}
	$gateway_file = FARAZSMS_CORE_INC . 'farazsms-farazsmsnext-gateway.php';
	if ( file_exists( $gateway_file ) && ! class_exists( 'PW\PWSMS\Gateways\FarazSMSNext', false ) ) {
		require_once $gateway_file;
	}
}

/**
 * @param mixed $screen
 * @return bool
 */
function farazsms_is_pwsms_admin_settings_screen( $screen ) {
	if ( ! $screen || ! isset( $screen->id ) ) {
		return false;
	}
	$ids = array(
		'woocommerce_page_persian-woocommerce-sms-pro',
		'persian-wc_page_persian-woocommerce-sms-pro',
		'admin_page_persian-woocommerce-sms-pro',
	);
	return in_array( $screen->id, $ids, true );
}

/**
 * v3.22.43 (#6a): بنرِ اطلاع‌رسانی روی صفحه‌ی تنظیماتِ «پیامک حرفه‌ای ووکامرس».
 *
 * اگر مدیر در افزونه‌ی فراز حالتِ ارسالِ پیامکِ سفارشات را روی «بومی» گذاشته باشد، پیامکِ سفارشات
 * از خودِ فراز می‌رود و PWSMS دیگر لازم نیست؛ کاربر باید بداند چرا PWSMS پیامک نمی‌فرستد و اگر
 * می‌خواهد از PWSMS استفاده کند کجا حالت را عوض کند (کاهشِ تیکتِ «پیامک ارسال نمی‌شود»).
 */
add_action( 'admin_notices', 'farazsms_pwsms_native_mode_notice' );
function farazsms_pwsms_native_mode_notice() {
	if ( ! current_user_can( 'manage_options' ) || ! function_exists( 'get_current_screen' ) ) {
		return;
	}
	if ( ! farazsms_is_pwsms_admin_settings_screen( get_current_screen() ) ) {
		return;
	}
	$mode = 'native';
	$s    = farazsms_order_sms_settings();
	$mode = $s['mode'] ?? 'native';
	if ( $mode !== 'native' ) {
		return; // مدیر روی «ووکامرس فارسی» گذاشته — PWSMS دارد کارش را می‌کند، بنری لازم نیست.
	}
	$settings_url = admin_url( 'admin.php?page=farazsms-orders-sms' );
	?>
	<div class="notice notice-info" style="border-right:4px solid #2271b1; padding:12px 16px; direction:rtl;">
		<p style="font-size:13.5px; margin:0 0 6px;"><strong>ℹ️ پیامکِ سفارشات از افزونه‌ی «فراز اس ام اس» ارسال می‌شود.</strong></p>
		<p style="font-size:13px; margin:0 0 8px; line-height:1.9;">
			در تنظیماتِ فراز اس ام اس، حالتِ ارسالِ پیامکِ سفارشات روی <strong>«بومی»</strong> است؛ یعنی پیامکِ تغییرِ وضعیتِ
			سفارش مستقیماً توسطِ فراز فرستاده می‌شود و در این حالت <strong>نیازی به افزونه‌ی «پیامک حرفه‌ای ووکامرس» نیست</strong>.
			اگر ترجیح می‌دهید پیامک‌ها از همین افزونه (پیامک حرفه‌ای ووکامرس) ارسال شوند، در تنظیماتِ فراز حالت را روی
			<strong>«ووکامرس فارسی»</strong> بگذارید.
		</p>
		<a href="<?php echo esc_url( $settings_url ); ?>" class="button button-primary">تنظیماتِ ارسالِ پیامکِ سفارشات در فراز</a>
	</div>
	<?php
}

/**
 * @param string $class
 * @return bool
 */
function farazsms_is_farazsmsnext_gateway_class( $class ) {
	if ( ! is_string( $class ) || $class === '' ) {
		return false;
	}
	$supported = array(
		'PW\PWSMS\Gateways\FarazSMSNext',
		'PW\PWSMS\Gateways\IranPayamak',
		'farazsmsnext',
		'iranpayamak',
	);
	if ( in_array( $class, $supported, true ) ) {
		return true;
	}
	if ( class_exists( $class, false ) && is_subclass_of( $class, 'PW\PWSMS\Gateways\FarazSMSNext', false ) ) {
		return true;
	}
	return false;
}

add_action( 'init', 'farazsms_fix_gateway_check', 1 );
function farazsms_fix_gateway_check() {
	if ( ! function_exists( 'PWSMS' ) ) {
		return;
	}

	$active_gateway = PWSMS()->get_option( 'sms_gateway' );
	if ( ! farazsms_is_farazsmsnext_gateway_class( $active_gateway ) ) {
		return;
	}

	farazsms_ensure_farazsmsnext_gateway_loaded();
}

add_action( 'plugins_loaded', 'farazsms_load_farazsmsnext_gateway', 20 );
function farazsms_load_farazsmsnext_gateway() {
	farazsms_ensure_farazsmsnext_gateway_loaded();
}

/**
 * Migrate stored PWSMS gateway id (e.g. 'farazsmsnext') to FQCN so PWSMS 7.2+
 * doesn't fallback to Logger gateway on test send.
 *
 * @return void
 */
add_action( 'plugins_loaded', 'farazsms_migrate_pwsms_gateway_option', 30 );
function farazsms_migrate_pwsms_gateway_option() {
	if ( ! function_exists( 'PWSMS' ) ) {
		return;
	}

	$settings = get_option( 'sms_main_settings', array() );
	if ( ! is_array( $settings ) ) {
		return;
	}

	$current = isset( $settings['sms_gateway'] ) ? (string) $settings['sms_gateway'] : '';
	$current = trim( $current );
	if ( $current === '' ) {
		return;
	}

	$farazsmsnext_fqcn = 'PW\PWSMS\Gateways\FarazSMSNext';

	$map = array(
		'farazsmsnext' => $farazsmsnext_fqcn,
		'iranpayamak'  => 'PW\PWSMS\Gateways\IranPayamak',
		// v3.21.21: درگاهِ توکارِ PWSMS «FarazSMS.com - فراز اس ام اس» (id=farazsms) و نسخه‌ی
		// FQCN‌اش را به درگاهِ رسمیِ خودمان منتقل می‌کنیم. هر دو به api.iranpayamak.com با همان
		// Api-Key می‌زنند، پس مهاجرت بدونِ وقفه است (کلید و خط حفظ می‌شود). کاربر دیگر اشتباهی
		// روی درگاهِ قدیمی نمی‌ماند.
		'farazsms'                          => $farazsmsnext_fqcn,
		'PW\PWSMS\Gateways\FarazSMSToken'   => $farazsmsnext_fqcn,
	);

	if ( ! isset( $map[ $current ] ) ) {
		return;
	}

	// آیا این یک مهاجرت از درگاهِ قدیمیِ farazsms.com است؟ (برای نمایشِ اعلان به مدیر.)
	$is_legacy_faraz = ( $current === 'farazsms' || $current === 'PW\PWSMS\Gateways\FarazSMSToken' );

	// Ensure our gateway class is available before switching.
	farazsms_ensure_farazsmsnext_gateway_loaded();

	$target = $map[ $current ];
	if ( class_exists( $target ) ) {
		$settings['sms_gateway'] = $target;
		update_option( 'sms_main_settings', $settings );
		if ( $is_legacy_faraz ) {
			// پرچمِ یک‌باره تا اعلانِ «درگاه به نسخه‌ی رسمی منتقل شد + کلید را وارد کنید» نشان داده شود.
			update_option( 'farazsms_pwsms_gateway_migrated_notice', '1', false );
		}
	}
}

/**
 * اضافه کردن Gateway جدید Farazsms.com(Next) به لیست Gateway‌های افزونه پیامک پیشفرض
 */
add_filter( 'pwoosms_sms_gateways', 'farazsms_add_farazsmsnext_gateway', 10 );
function farazsms_add_farazsmsnext_gateway( $gateways ) {
	$farazsmsnext_class = 'PW\PWSMS\Gateways\FarazSMSNext';
	$iranpayamak_class = 'PW\PWSMS\Gateways\IranPayamak';
	
	if ( ! class_exists( $farazsmsnext_class, false ) ) {
		farazsms_ensure_farazsmsnext_gateway_loaded();
	}
	
	if ( class_exists( $farazsmsnext_class ) ) {
		$gateway_name = $farazsmsnext_class::name();
		$gateways[ $farazsmsnext_class ] = $gateway_name;
	}
	
	if ( class_exists( $iranpayamak_class ) ) {
		$gateway_name = $iranpayamak_class::name();
		$gateways[ $iranpayamak_class ] = $gateway_name;
	}

	// v3.21.21: درگاهِ توکارِ PWSMS «FarazSMS.com - فراز اس ام اس» را از لیست پنهان می‌کنیم تا
	// کاربر اشتباهی آن را انتخاب نکند. این درگاه به همان api.iranpayamak.com می‌زند ولی
	// امکاناتِ یکپارچه‌ی ما (ساختِ پترن، باشگاه، لید مگنت، …) را ندارد. سایت‌هایی که قبلاً
	// آن را انتخاب کرده‌اند با farazsms_migrate_pwsms_gateway_option خودکار به درگاهِ رسمیِ
	// ما منتقل می‌شوند، پس پنهان‌کردن تداخلی ایجاد نمی‌کند.
	unset( $gateways['PW\PWSMS\Gateways\FarazSMSToken'] );
	unset( $gateways['farazsms'] );

	return $gateways;
}

/**
 * v3.21.21: اعلانِ مدیر پس از مهاجرتِ خودکارِ درگاه از «farazsms.com (قدیمی)» به درگاهِ
 * رسمیِ ما — به‌همراهِ یادآوریِ این‌که کلیدِ دسترسی باید وارد باشد وگرنه ارسال کار نمی‌کند.
 * با کلیکِ «متوجه شدم» پرچم پاک می‌شود و دیگر نمایش داده نمی‌شود.
 */
add_action( 'admin_notices', 'farazsms_pwsms_gateway_migrated_admin_notice' );
function farazsms_pwsms_gateway_migrated_admin_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( get_option( 'farazsms_pwsms_gateway_migrated_notice' ) !== '1' ) {
		return;
	}

	$apikey      = (string) farazsms_get_pwsms_apikey();
	$key_missing = ( trim( $apikey ) === '' );
	$nonce       = wp_create_nonce( 'farazsms_dismiss_pwsms_gateway_notice' );
	?>
	<div class="notice <?php echo $key_missing ? 'notice-warning' : 'notice-success'; ?> is-dismissible farazsms-pwsms-gw-notice" data-nonce="<?php echo esc_attr( $nonce ); ?>" style="border-right:4px solid <?php echo $key_missing ? '#e2a916' : '#0c9765'; ?>;">
		<p style="font-size:13.5px; line-height:2; margin:10px 0;">
			<strong>✅ <?php esc_html_e( 'درگاهِ پیامکِ فراز اس ام اس به‌صورتِ خودکار به «نسخه‌ی رسمی» منتقل شد.', 'farazsms' ); ?></strong><br>
			<?php esc_html_e( 'پیش از این درگاهِ قدیمیِ farazsms.com انتخاب شده بود. خط ارسال و کلیدِ دسترسیِ شما حفظ شده و ارسال بدونِ وقفه ادامه می‌یابد.', 'farazsms' ); ?>
			<?php if ( $key_missing ) : ?>
				<br><strong style="color:#83620d;">⚠ <?php esc_html_e( 'توجه: کلیدِ دسترسی (Api-Key) خالی است. تا وقتی کلید را در تنظیماتِ وب‌سرویسِ «پیامک حرفه‌ای ووکامرس» وارد نکنید، پیامک ارسال نمی‌شود.', 'farazsms' ); ?></strong>
			<?php endif; ?>
		</p>
		<p style="margin:10px 0;">
			<button type="button" class="button button-primary farazsms-pwsms-gw-dismiss"><?php esc_html_e( 'متوجه شدم', 'farazsms' ); ?></button>
		</p>
	</div>
	<script>
	(function(){
		var box = document.querySelector('.farazsms-pwsms-gw-notice');
		if (!box) { return; }
		function dismiss(){
			var fd = new FormData();
			fd.append('action', 'farazsms_dismiss_pwsms_gateway_notice');
			fd.append('nonce', box.getAttribute('data-nonce'));
			fetch(ajaxurl, { method:'POST', credentials:'same-origin', body: fd });
		}
		var btn = box.querySelector('.farazsms-pwsms-gw-dismiss');
		if (btn) { btn.addEventListener('click', function(){ dismiss(); box.style.display='none'; }); }
		box.addEventListener('click', function(e){
			if (e.target && e.target.classList && e.target.classList.contains('notice-dismiss')) { dismiss(); }
		});
	})();
	</script>
	<?php
}

add_action( 'wp_ajax_farazsms_dismiss_pwsms_gateway_notice', 'farazsms_dismiss_pwsms_gateway_notice_ajax' );
function farazsms_dismiss_pwsms_gateway_notice_ajax() {
	if ( ! current_user_can( 'manage_options' )
		|| ! check_ajax_referer( 'farazsms_dismiss_pwsms_gateway_notice', 'nonce', false ) ) {
		wp_send_json_error( array(), 403 );
	}
	delete_option( 'farazsms_pwsms_gateway_migrated_notice' );
	wp_send_json_success();
}

// Note: an empty `farazsms_fix_get_sms_gateway` was previously hooked here on `plugins_loaded`
// with priority 25 but did nothing. Removed — no functional change, just less hook overhead.

/**
 * حذف فیلدهای username/password و اضافه کردن فیلد Api-Key به تنظیمات افزونه پیامک پیشفرض
 * اولویت بالا برای اینکه قبل از رندر شدن فیلدها، اونها رو حذف کنیم
 */
add_filter( 'pwoosms_main_settings', 'farazsms_modify_main_settings', 5 );
function farazsms_modify_main_settings( $settings ) {
	$farazsmsnext_class = 'PW\PWSMS\Gateways\FarazSMSNext';

	if ( ! class_exists( $farazsmsnext_class ) ) {
		return $settings;
	}

	// One-time defaults migration. Previously this filter wrote to wp_options on every
	// settings-page render (and could recurse through update_option_sms_main_settings),
	// causing write amplification + autoload bloat. The flag below ensures we seed
	// defaults exactly once per site.
	$defaults_migration_version = '1.0.0';
	$migration_flag             = (string) get_option( 'farazsms_pwsms_defaults_migrated', '' );
	if ( $migration_flag !== $defaults_migration_version && function_exists( 'PWSMS' ) ) {
		$sms_main_settings = get_option( 'sms_main_settings', array() );
		if ( ! is_array( $sms_main_settings ) ) {
			$sms_main_settings = array();
		}
		$changed = false;
		if ( empty( $sms_main_settings['sms_gateway_sender'] ) ) {
			$sms_main_settings['sms_gateway_sender'] = '90008361';
			$changed = true;
		}
		// v3.13.1: default برای پنهان کردن نام کاربری/رمز عوض شد ('0' = پنهان).
		// به این ترتیب کاربر فقط فیلد Api-Key را می‌بیند و فرآیند Onboarding ساده می‌شود.
		// نصب‌های قدیمی که قبلاً مقدار '1' را ذخیره کرده‌اند، تغییر نمی‌کنند.
		if ( ! isset( $sms_main_settings['farazsms_enable_username_password'] ) ) {
			$enable_user_pass_default = get_option( 'farazsms_enable_username_password', '0' );
			$sms_main_settings['farazsms_enable_username_password'] = ( $enable_user_pass_default === '1' ) ? 'on' : 'off';
			$changed = true;
		}
		if ( $changed ) {
			update_option( 'sms_main_settings', $sms_main_settings, false );
		}
		update_option( 'farazsms_pwsms_defaults_migrated', $defaults_migration_version, false );
	}

	$new_settings   = array();
	$api_key_added  = false;
	$checkbox_added = false;

	foreach ( $settings as $field ) {
		if ( isset( $field['name'] ) && $field['name'] === 'sms_gateway_sender' ) {
			$field['default'] = '90008361';
		}

		$new_settings[] = $field;

		if ( isset( $field['name'] ) && $field['name'] === 'sms_gateway' && ! $checkbox_added ) {
			// v3.13.1: default = '0' (پنهان). کاربر فقط Api-Key می‌بیند، مگر اینکه عمداً تیک بزند.
			$enable_username_password = get_option( 'farazsms_enable_username_password', '0' );
			$new_settings[] = array(
				'name'    => 'farazsms_enable_username_password',
				'label'   => 'وارد کردن رمز و یوزرنیم',
				'type'    => 'checkbox',
				'desc'    => 'به‌صورت پیش‌فرض غیرفعال است — افزونه فراز اس‌ام‌اس فقط با کلید دسترسی (Api-Key) کار می‌کند. در صورت نیاز به نام کاربری/رمز برای سایر وب‌سرویس‌ها، این گزینه را فعال کنید.',
				'default' => $enable_username_password === '1' ? 'on' : 'off',
			);
			$checkbox_added = true;
		}
		
		if ( isset( $field['name'] ) && $field['name'] === 'sms_gateway_sender' && ! $api_key_added ) {
			$new_settings[] = [
				'name'  => 'sms_gateway_apikey',
				'label' => 'کلید دسترسی (Api-Key)',
				'type'  => 'text',
				'ltr'   => true,
				'desc'  => 'برای Gateway Farazsms.com(Next) از Api-Key استفاده می‌شود.',
			];
			$api_key_added = true;
		}
	}
	
	return $new_settings;
}

/**
 * ذخیره وضعیت چک‌باکس "وارد کردن رمز و یوزرنیم" هنگام ذخیره تنظیمات
 */
add_action( 'update_option_sms_main_settings', 'farazsms_save_username_password_checkbox', 10, 2 );
function farazsms_save_username_password_checkbox( $old_value, $value ) {
	if ( ! is_array( $value ) ) {
		return;
	}
	// When a checkbox is unchecked in an HTML form, its key is absent from $_POST entirely.
	// Previously we defaulted the absent case to '1' (enabled), which made the toggle
	// impossible to turn off. Correct behavior: absent = '0' (disabled).
	if ( isset( $value['farazsms_enable_username_password'] ) ) {
		$checkbox_value = $value['farazsms_enable_username_password'] === 'on' ? '1' : '0';
	} else {
		$checkbox_value = '0';
	}
	update_option( 'farazsms_enable_username_password', $checkbox_value, false );
}

/**
 * افزودن CSS برای مخفی کردن فیلدهای username/password (به عنوان پشتیبان)
 */
add_action( 'admin_head', 'farazsms_hide_username_password_fields' );
function farazsms_hide_username_password_fields() {
	$screen = get_current_screen();
	if ( ! farazsms_is_pwsms_admin_settings_screen( $screen ) ) {
		return;
	}

	// v3.13.1: default = '0' — فیلد u/p به‌صورت پیش‌فرض پنهان است.
	$enable_username_password = get_option( 'farazsms_enable_username_password', '0' );
	?>
	<style type="text/css">
		.farazsms-hide-username-password {
			display: none !important;
		}
	</style>
	<?php
}

/**
 * افزودن JavaScript برای toggle کردن فیلدهای username/password با استفاده از action hook
 * استفاده از action hook افزونه پیامک فارسی که مطمئناً اجرا می‌شود
 */
add_action( 'pwoosms_settings_form_bottom_sms_main_settings', 'farazsms_add_username_password_toggle_script', 20 );
function farazsms_add_username_password_toggle_script( $form ) {
	$farazsmsnext_class = 'PW\PWSMS\Gateways\FarazSMSNext';
	$iranpayamak_class = 'PW\PWSMS\Gateways\IranPayamak';
	if ( ! class_exists( $farazsmsnext_class ) ) {
		return;
	}
	
	// v3.13.1: default = '0' (پنهان).
	$enable_username_password = get_option( 'farazsms_enable_username_password', '0' );
	$farazsmsnext_full_class = str_replace( '\\', '\\\\', $farazsmsnext_class );
	$iranpayamak_full_class = str_replace( '\\', '\\\\', $iranpayamak_class );
	?>
	<script type="text/javascript">
	jQuery(document).ready(function($) {
		function farazsmsToggleUsernamePasswordFields() {
			var checkbox = $('#wpuf-sms_main_settings\\[farazsms_enable_username_password\\]');
			var usernameRow = $('input[name="sms_main_settings[sms_gateway_username]"]').closest('tr');
			var passwordRow = $('input[name="sms_main_settings[sms_gateway_password]"]').closest('tr');
			
			if (checkbox.length && usernameRow.length && passwordRow.length) {
				var isChecked = checkbox.is(':checked');
				
				if (isChecked) {
					usernameRow.show();
					passwordRow.show();
				} else {
					usernameRow.hide();
					passwordRow.hide();
			}
			}
		}
		
		$(document.body).on('change', '#wpuf-sms_main_settings\\[farazsms_enable_username_password\\]', function() {
			farazsmsToggleUsernamePasswordFields();
		});
		
		var checkboxInit = $('#wpuf-sms_main_settings\\[farazsms_enable_username_password\\]');
		if (checkboxInit.length) {
			checkboxInit.change(function() {
				farazsmsToggleUsernamePasswordFields();
			}).change();
		}
		
		setTimeout(function() {
			farazsmsToggleUsernamePasswordFields();
		}, 100);
		setTimeout(function() {
			farazsmsToggleUsernamePasswordFields();
		}, 500);
		
		function toggleApiKeyField() {
			var selectedGateway = $('#sms_main_settings\\[sms_gateway\\]').val();
			var apikeyRow = $('input[name="sms_main_settings[sms_gateway_apikey]"]').closest('tr');
			
			if (apikeyRow.length) {
				var supportedGateways = [
					'<?php echo esc_js( $farazsmsnext_full_class ); ?>',
					'<?php echo esc_js( $iranpayamak_full_class ); ?>'
				];
				if (supportedGateways.indexOf(selectedGateway) !== -1) {
					apikeyRow.show();
				} else {
					apikeyRow.hide();
				}
			}
		}
		
		$(document.body).on('change', '#sms_main_settings\\[sms_gateway\\]', function() {
			setTimeout(toggleApiKeyField, 50);
		});
		
		function setDefaultSender() {
			var senderInput = $('input[name="sms_main_settings[sms_gateway_sender]"]');
			if (senderInput.length && senderInput.val() === '') {
				senderInput.val('90008361');
			}
		}
		
		setTimeout(toggleApiKeyField, 100);
		setTimeout(setDefaultSender, 100);
		setTimeout(setDefaultSender, 300);
		
		$(document.body).on('change', '#sms_main_settings\\[sms_gateway\\]', function() {
			setTimeout(setDefaultSender, 50);
		});
	});
	</script>
	<?php
}



/**
 * افزودن دکمه "ساخت پترن" کنار هر textarea وضعیت در صفحه buyer
 * استفاده از action hook برای اضافه کردن دکمه بعد از render شدن فیلدها
 */
add_action( 'pwoosms_settings_form_bottom_sms_buyer_settings', 'farazsms_add_pattern_buttons_to_buyer_form', 10, 1 );
add_action( 'admin_footer', 'farazsms_add_pattern_buttons_script' );

/**
 * مودالِ مدرنِ مشترک به‌جای farazsmsPwsmsModal()های پیش‌فرضِ مرورگر (ظاهرِ قدیمی + بریده‌شدنِ متن).
 * با تشخیصِ نوع از ایموجیِ ابتدای پیام (✅/⚠️/❌) رنگ‌بندی می‌شود؛ متن کامل، اسکرول‌شونده.
 */
add_action( 'admin_footer', 'farazsms_pwsms_modal_assets', 1 );
function farazsms_pwsms_modal_assets() {
	// دکمه‌ها از طریقِ فیلترِ فرم رندر می‌شوند (نه با تشخیصِ صفحه)، پس مودال هم باید
	// هرجا PWSMS فعال است در دسترس باشد تا «پاپ‌آپ اصلاً نمی‌آید» رخ ندهد.
	if ( ! function_exists( 'PWSMS' ) ) {
		return;
	}
	?>
	<style>
	.farazsms-pm-overlay{position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:1000000;display:flex;align-items:center;justify-content:center;padding:16px;direction:rtl;}
	.farazsms-pm-box{background:#fff;border-radius:16px;max-width:480px;width:100%;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 24px 60px rgba(0,0,0,.3);overflow:hidden;font-family:inherit;}
	.farazsms-pm-head{padding:18px 22px 6px;font-size:16px;font-weight:800;display:flex;align-items:center;gap:8px;}
	.farazsms-pm-body{padding:4px 22px 16px;font-size:13.5px;line-height:2.1;color:#4d4d4d;white-space:pre-wrap;overflow-y:auto;flex:1;}
	.farazsms-pm-foot{padding:12px 22px 18px;text-align:left;border-top:1px solid #f5f8fe;}
	.farazsms-pm-ok{border:none;color:#fff;padding:9px 24px;border-radius:10px;font-size:13.5px;font-weight:700;cursor:pointer;font-family:inherit;}
	.farazsms-pattern-button{background:linear-gradient(135deg,#0c9765 0%,#096d49 100%)!important;color:#fff!important;border:none!important;border-radius:8px!important;padding:7px 16px!important;font-size:12.5px!important;font-weight:700!important;cursor:pointer;box-shadow:0 2px 6px rgba(22,163,74,.3);transition:transform .12s,box-shadow .12s;line-height:1.7!important;height:auto!important;}
	.farazsms-pattern-button::before{content:"⚡ ";}
	.farazsms-pattern-button:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(22,163,74,.4);}
	.farazsms-pattern-button:disabled{opacity:.6;cursor:default;transform:none;box-shadow:none;}
	.farazsms-pattern-info{background:#fff!important;border:1px solid #e1e1e1!important;border-right:4px solid #4571ba!important;border-radius:10px!important;padding:12px 14px!important;box-shadow:0 1px 3px rgba(0,0,0,.04);}
	.farazsms-pattern-info code{background:#f5f8fe!important;border:1px solid #e1e1e1;direction:ltr;display:inline-block;}
	.farazsms-status-active,.farazsms-status-pending,.farazsms-status-inactive,.farazsms-status-unknown{padding:2px 12px;border-radius:20px;font-weight:700;font-size:12px;display:inline-block;}
	.farazsms-status-active{background:#e2f8f0;color:#096d49;}
	.farazsms-status-pending{background:#faf1da;color:#83620d;}
	.farazsms-status-inactive{background:#fdeae8;color:#b32817;}
	.farazsms-status-unknown{background:#f5f8fe;color:#4d4d4d;}
	/* بنرِ «تغییرات ذخیره نشده» (مثلِ Apply در المنتور) */
	#farazsms-pwsms-unsaved-bar{display:none;position:fixed;top:32px;left:0;right:0;z-index:99998;background:linear-gradient(90deg,#e2a916,#e2a916);color:#fff;padding:11px 18px;font-size:12.5px;font-weight:600;line-height:1.9;align-items:center;justify-content:center;gap:14px;box-shadow:0 3px 12px rgba(0,0,0,.22);direction:rtl;flex-wrap:wrap;}
	#farazsms-pwsms-unsaved-bar button{background:#fff;color:#83620d;border:none;padding:7px 16px;border-radius:8px;font-weight:700;font-size:12.5px;cursor:pointer;font-family:inherit;flex:0 0 auto;}
	#farazsms-pwsms-unsaved-bar button:hover{background:#faf1da;}
	@media (max-width:782px){ #farazsms-pwsms-unsaved-bar{top:46px;} }
	</style>
	<script type="text/javascript">
	window.farazsmsPwsmsModal = function( message ) {
		message = String( message );
		var type = message.indexOf('✅') === 0 ? 'success' : ( message.indexOf('⚠️') === 0 ? 'warning' : ( message.indexOf('❌') === 0 ? 'error' : 'info' ) );
		var color = { success:'#0c9765', warning:'#e2a916', error:'#d52a16', info:'#365891' }[ type ];
		var icon  = { success:'✅', warning:'⚠️', error:'❌', info:'💬' }[ type ];
		var title = { success:'پترن ساخته شد', warning:'توجه', error:'خطا', info:'پیام' }[ type ];
		// ایموجیِ ابتدای متن را حذف کن تا در بدنه تکرار نشود.
		var body = message.replace(/^(✅|⚠️|❌)\s*/, '');
		var old = document.querySelector('.farazsms-pm-overlay'); if ( old ) { old.remove(); }
		var ov = document.createElement('div'); ov.className = 'farazsms-pm-overlay';
		ov.innerHTML =
			'<div class="farazsms-pm-box" role="dialog" aria-modal="true">' +
			'<div class="farazsms-pm-head" style="color:' + color + '"><span>' + icon + '</span><span></span></div>' +
			'<div class="farazsms-pm-body"></div>' +
			'<div class="farazsms-pm-foot"><button type="button" class="farazsms-pm-ok" style="background:' + color + '">باشه، متوجه شدم</button></div>' +
			'</div>';
		ov.querySelector('.farazsms-pm-head span:last-child').textContent = title;
		ov.querySelector('.farazsms-pm-body').textContent = body;
		document.body.appendChild( ov );
		function close(){ ov.remove(); document.removeEventListener('keydown', onKey); }
		function onKey(e){ if ( e.key === 'Escape' ) { close(); } }
		ov.querySelector('.farazsms-pm-ok').addEventListener('click', close);
		ov.addEventListener('click', function(e){ if ( e.target === ov ) { close(); } });
		document.addEventListener('keydown', onKey);
		ov.querySelector('.farazsms-pm-ok').focus();
	};

	// ── بنرِ «تغییرات ذخیره نشده» ───────────────────────────────────────────────
	// با «ساخت پترن»، پترن سمتِ فراز عوض می‌شود اما متنِ باکسِ ووکامرس تا زدنِ «ذخیره»ی
	// پایینِ صفحه ذخیره نمی‌شود؛ نتیجه: سرِ ارسالِ سفارش، متغیرها نمی‌خوانند. این بنر
	// (مثلِ Apply در المنتور) یادآوری می‌کند که آخرِ کار یک‌بار ذخیره شود.
	(function(){
		function showBar(){
			var bar = document.getElementById('farazsms-pwsms-unsaved-bar');
			if (bar) { bar.style.display = 'flex'; return; }
			bar = document.createElement('div');
			bar.id = 'farazsms-pwsms-unsaved-bar';
			bar.innerHTML = '<span>✅ <strong>پترن ساخته شد.</strong> هر متن را ویرایش کردید، یک‌بار «ساخت پترن»‌اش را بزنید؛ و در پایان، وقتی همه‌ی پترن‌های موردنظرتان را ساختید، یک‌بار دکمه‌ی «ذخیره»ی پایینِ صفحه را بزنید تا فعال شوند (لازم نیست بعدِ هر پترن ذخیره کنید).</span>'
				+ '<button type="button" id="farazsms-pwsms-unsaved-go">💾 رفتن به دکمه‌ی ذخیره</button>';
			document.body.appendChild(bar);
			document.getElementById('farazsms-pwsms-unsaved-go').addEventListener('click', function(){
				var subs = document.querySelectorAll('input[type="submit"], button[type="submit"]');
				var btn  = subs.length ? subs[subs.length - 1] : null;
				if (btn) {
					btn.scrollIntoView({ behavior:'smooth', block:'center' });
					var prev = btn.style.boxShadow;
					btn.style.boxShadow = '0 0 0 4px rgba(245,158,11,.55)';
					setTimeout(function(){ btn.style.boxShadow = prev; }, 2600);
				} else {
					window.scrollTo({ top: document.body.scrollHeight, behavior:'smooth' });
				}
			});
		}
		// بنر فقط بعد از زدنِ «ساخت پترن» نشان داده می‌شود (نه با صرفِ ویرایشِ متن — قبلاً
		// محرکِ ویرایشِ متن باعث می‌شد بنر زودتر از موعد و پیش از ساختِ پترن ظاهر شود).
		document.addEventListener('click', function(e){
			var t = e.target;
			if (t && t.classList && t.classList.contains('farazsms-pattern-button')) {
				setTimeout(showBar, 60);
			}
		}, true);
		// با زدنِ «ذخیره»ی فرم، بنر را پنهان کن (تغییرات دارد ذخیره می‌شود).
		document.addEventListener('submit', function(){
			var bar = document.getElementById('farazsms-pwsms-unsaved-bar');
			if (bar) { bar.style.display = 'none'; }
		}, true);
	})();
	</script>
	<?php
}

function farazsms_add_pattern_buttons_to_buyer_form( $form ) {
	$patterns = get_option('farazsms_patterns', []);
	// JSON_HEX_TAG / JSON_HEX_AMP prevent a `</script>` inside an admin-stored pattern
	// from breaking out of the surrounding inline <script> block.
	$patterns_json = wp_json_encode( $patterns, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
	?>
	<script type="text/javascript">
	(function($) {
		// پاس دادن اطلاعات پترن از PHP به JavaScript
		var farazsmsPatterns = <?php echo $patterns_json; ?>;
			// تضمین: اگر مودالِ مدرن لود نشده باشد، حداقل پیام نمایش داده شود.
			if (typeof window.farazsmsPwsmsModal !== "function") { window.farazsmsPwsmsModal = function(m){ window.alert(String(m)); }; }
		
		// تابع برای نمایش اطلاعات پترن
		function farazsmsDisplayPatternInfo($textarea, statusKey, sectionType, $container) {
			// اگر container داده نشده، از th استفاده کن
			if (!$container) {
				var $tr = $textarea.closest('tr');
				if (!$tr.length) {
					return;
				}
				$container = $tr.find('.farazsms-pattern-container');
				if (!$container.length) {
					return;
				}
			}
			
			// حذف info box قبلی اگر وجود داشته باشد
			$container.find('.farazsms-pattern-info').remove();
			
			// بررسی وجود کد پترن
			var patternCode = null;
			if (farazsmsPatterns && farazsmsPatterns[sectionType] && farazsmsPatterns[sectionType][statusKey]) {
				patternCode = farazsmsPatterns[sectionType][statusKey];
			}
			
			if (!patternCode) {
				return; // اگر کد پترن وجود نداشت، چیزی نمایش نده
			}
			
			// ساخت info box
			var $infoBox = $('<div class="farazsms-pattern-info" style="margin-top: 10px; padding: 10px; background: #f0f0f1; border-right: 3px solid #2271b1; border-radius: 3px; font-size: 13px;"></div>');
			$infoBox.html('<strong>کد پترن:</strong> <code style="background: #fff; padding: 2px 5px; border-radius: 2px;">' + $('<i>').text(patternCode).html() + '</code><br><span class="farazsms-pattern-status">در حال دریافت وضعیت...</span>');
			
			// اضافه کردن info box به container (بعد از دکمه)
			$container.append($infoBox);
			
			// دریافت جزئیات پترن از API
			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					action: 'farazsms_get_pattern_details',
					pattern_code: patternCode,
					section_type: sectionType,
					nonce: '<?php echo wp_create_nonce( "farazsms_get_pattern_details" ); ?>'
				},
				success: function(response) {
					var $statusSpan = $infoBox.find('.farazsms-pattern-status');
					if (response.success && response.data && response.data.data) {
						var patternData = response.data.data;
						var status = patternData.status || 'نامشخص';
						var statusText = '';
						var statusClass = '';
						
						// تعیین متن و کلاس بر اساس وضعیت
						if (status === 'active' || status === 'approved') {
							statusText = '✅ تأیید شده و فعال';
							statusClass = 'farazsms-status-active';
						} else if (status === 'pending' || status === 'waiting') {
							statusText = '⏳ در انتظار تأیید (۱ تا ۲۴ ساعت)';
							statusClass = 'farazsms-status-pending';
						} else if (status === 'inactive' || status === 'rejected') {
							statusText = '❌ رد/غیرفعال';
							statusClass = 'farazsms-status-inactive';
						} else {
							statusText = status;
							statusClass = 'farazsms-status-unknown';
						}
						
						$statusSpan.html('<strong>وضعیت:</strong> <span class="' + statusClass + '">' + $('<i>').text(statusText).html() + '</span>');
					} else {
						$statusSpan.html('<strong>وضعیت:</strong> <span class="farazsms-status-unknown">خطا در دریافت اطلاعات</span>');
					}
				},
				error: function() {
					var $statusSpan = $infoBox.find('.farazsms-pattern-status');
					$statusSpan.html('<strong>وضعیت:</strong> <span class="farazsms-status-unknown">خطا در دریافت اطلاعات</span>');
				}
			});
		}
		
		function farazsmsAddPatternButtons() {
			var $textareas = $('textarea[name*="sms_buyer_settings"][name*="sms_body_"]');
			
			if ($textareas.length === 0) {
				$textareas = $('#sms_buyer_settings textarea[name*="sms_body_"]');
			}
			
			if ($textareas.length === 0) {
				$textareas = $('textarea').filter(function() {
					var name = $(this).attr('name') || '';
					return name.indexOf('sms_buyer_settings') !== -1 && name.indexOf('sms_body_') !== -1;
				});
			}
			
			if ($textareas.length === 0) {
				return;
			}
			
			$textareas.each(function() {
				var $textarea = $(this);
				var textareaName = $textarea.attr('name') || '';
				if (textareaName.indexOf('sms_buyer_settings') === -1 || textareaName.indexOf('sms_body_') === -1) {
					return;
				}
				
				// بررسی که آیا دکمه قبلاً اضافه شده یا نه
				var $tr = $textarea.closest('tr');
				if (!$tr.length) {
					return;
				}
				
				// اگر دکمه قبلاً اضافه شده، skip کن
				if ($tr.find('.farazsms-pattern-button').length > 0) {
					return;
				}
				
				// استخراج نام وضعیت از name
				var statusKey = '';
				var match = textareaName.match(/sms_body_([^\]]+)/);
				if (match && match[1]) {
					statusKey = match[1];
				}
				
				if (!statusKey) {
					return;
				}
				
				// پیدا کردن th (label) برای قرار دادن دکمه و info box
				var $th = $tr.find('th');
				if (!$th.length) {
					return;
				}
				
				// ساخت container برای دکمه و info box
				var $container = $('<div class="farazsms-pattern-container" style="margin-top: 5px; clear: both;"></div>');
				
				// ساخت دکمه
				var buttonId = 'farazsms-pattern-btn-' + statusKey.replace(/[^a-zA-Z0-9_-]/g, '-');
				// v3.22.8: section از نامِ textarea تشخیص داده می‌شود؛ اگر پترن هست، «ویرایشِ فعلی»، وگرنه «ساخت پترن».
				var farazsmsSection = (textareaName.indexOf('super_admin') !== -1) ? 'super_admin' : ((textareaName.indexOf('product_admin') !== -1) ? 'product_admin' : 'buyer');
				var farazsmsHasPattern = !!(typeof farazsmsPatterns !== 'undefined' && farazsmsPatterns && farazsmsPatterns[farazsmsSection] && farazsmsPatterns[farazsmsSection][statusKey]);
				var $button = $('<button type="button" id="' + buttonId + '" class="button farazsms-pattern-button">' + (farazsmsHasPattern ? '✏️ ویرایشِ پترنِ فعلی' : 'ساخت پترن') + '</button>');
				// اعمال استایل inline برای اطمینان از اعمال
				$button.css({
					'background': '#2271b1',
					'background-color': '#2271b1',
					'color': '#fff',
					'border-color': '#2271b1',
					'border': '1px solid #2271b1',
					'font-weight': '600',
					'padding': '4px 10px',
					'margin-top': '10px',
					'margin-right': '5px',
					'cursor': 'pointer',
					'width': '100%',
				});
				
				$button.on('mouseenter', function() {
					$(this).css({
						'background': '#135e96',
						'background-color': '#135e96',
						'border-color': '#135e96',
						'border': '1px solid #135e96'
					});
				}).on('mouseleave', function() {
					$(this).css({
						'background': '#2271b1',
						'background-color': '#2271b1',
						'border-color': '#2271b1',
						'border': '1px solid #2271b1'
					});
				});
				
				// اضافه کردن event handler برای دکمه
				$button.on('click', function(e) {
					e.preventDefault();
					e.stopPropagation();
					var textareaValue = $textarea.val();
					if (!textareaValue || textareaValue.trim() === '') {
						farazsmsPwsmsModal('⚠️ متن پیامک خالی است. لطفا ابتدا متن را وارد کنید.');
						return;
					}
					// تشخیصِ فرمتِ پنلِ قدیمی (pcode:/patterncode: + var:value) و هشدار به کاربر.
					if (/pcode/i.test(textareaValue) || /patterncode/i.test(textareaValue)) {
						farazsmsPwsmsModal('⚠️ متنِ شما شاملِ «pcode» است — این شیوه مخصوصِ پنلِ قدیمی بوده و دیگر کار نمی‌کند.\n\nاینجا کدِ پترن ننویسید؛ فقط متنِ دلخواهِ پیامک را بسازید:\n۱) متنِ پیامک را به فارسی بنویسید.\n۲) هرجا مقدار پویا لازم بود، از متغیرهای ووکامرس (دکمه‌های زیرِ همین کادر) استفاده کنید؛ مثلِ {b_first_name}، {order_id}، {price}، {all_items}.\n۳) سپس دکمه‌ی «ساخت پترن» را بزنید تا خودِ افزونه پترن را بسازد.\n\n⏰ تأییدِ پترن در پنلِ فراز ۱ تا ۲۴ ساعت طول می‌کشد. اگر اشتباه (با فرمتِ قدیمی) بسازید رد می‌شود و باید از نو شروع کنید؛ پس همین حالا درست بسازید.\n\nمثال:\nسلام {b_first_name}\nسفارشِ شماره {order_id} ثبت شد.\nمبلغِ سفارش: {price}');
						return;
					}
					
					var $btn = $(this);
					var originalText = $btn.text();
					
					// غیرفعال کردن دکمه و نمایش loading
					$btn.prop('disabled', true).text('در حال ساخت...');
					
					// ارسال درخواست AJAX برای ساخت پترن
					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'farazsms_create_pattern',
							message_text: textareaValue,
							status_key: statusKey,
							section_type: 'buyer',
							nonce: '<?php echo wp_create_nonce( "farazsms_create_pattern" ); ?>'
						},
						success: function(response) {
							if (response.success && response.data && response.data.pattern_code) {
								var patternCode = response.data.pattern_code;
								
								// به‌روزرسانی farazsmsPatterns
								if (!farazsmsPatterns) {
									farazsmsPatterns = {};
								}
								if (!farazsmsPatterns.buyer) {
									farazsmsPatterns.buyer = {};
								}
								farazsmsPatterns.buyer[statusKey] = patternCode;
								
								var result = '✅ پترن با موفقیت ساخته شد!\n\n';
								result += 'کد پترن: ' + $('<i>').text(patternCode).html() + '\n\n';
								result += 'منتظر تایید پترن باشید.\n';
								result += 'تایید پترن بین ۱ تا ۲۴ ساعت زمان‌بر است و پس از آن پیامک‌های شما ارسال می‌شود.';
								farazsmsPwsmsModal(result);
								
								// نمایش اطلاعات پترن
								farazsmsDisplayPatternInfo($textarea, statusKey, 'buyer');
							} else {
								var errorMsg = '❌ خطا در ساخت پترن:\n\n';
								if (response.data && response.data.message) {
									errorMsg += response.data.message;
								} else if (response.data && typeof response.data === 'string') {
									errorMsg += response.data;
								} else {
									errorMsg += 'خطای ناشناخته';
								}
								farazsmsPwsmsModal(errorMsg);
							}
						},
						error: function(xhr, status, error) {
							farazsmsPwsmsModal('❌ خطا در ارسال درخواست:\n\n' + error + '\n\nلطفا دوباره تلاش کنید.');
						},
						complete: function() {
							// فعال کردن مجدد دکمه
							$btn.prop('disabled', false).text(originalText);
						}
					});
				});
				
				// اضافه کردن دکمه به container
				$container.append($button);
				// v3.22.8: دکمه‌ی دومِ «ساخت پترنِ جدید» (کوچک‌تر). فقط وقتی پترن هست دیده می‌شود؛ mode=new
				// یعنی حتی اگر کدپترنِ موجود هست نادیده گرفته شود و پترنِ تازه ساخته شود (برای سایت‌های کپی‌شده).
				var $farazsmsNewBtn = $('<button type="button" class="button">➕ ساخت پترنِ جدید</button>').css({ 'color':'#9b9b9b','font-size':'11.5px','padding':'3px 8px','margin-top':'6px','cursor':'pointer','width':'100%','background':'#f5f8fe','border':'1px solid #e1e1e1' });
				if (!farazsmsHasPattern) { $farazsmsNewBtn.hide(); }
				$farazsmsNewBtn.on('click', function(e){
					e.preventDefault(); e.stopPropagation();
					var v = $textarea.val();
					if (!v || v.trim() === '') { farazsmsPwsmsModal('⚠️ متن پیامک خالی است. لطفا ابتدا متن را وارد کنید.'); return; }
					if (/pcode/i.test(v) || /patterncode/i.test(v)) { farazsmsPwsmsModal('⚠️ متنِ شما شاملِ «pcode» است — کدِ پترن ننویسید؛ فقط متنِ پیامک را با متغیرهای ووکامرس بسازید.'); return; }
					if (!confirm('یک پترنِ کاملاً جدید ساخته می‌شود و کدپترنِ فعلی جایگزین می‌گردد. مطمئنید؟')) { return; }
					var $b = $(this); var ot = $b.text(); $b.prop('disabled', true).text('در حال ساختِ جدید...');
					$.ajax({ url: ajaxurl, type: 'POST', data: { action: 'farazsms_create_pattern', message_text: v, status_key: statusKey, section_type: farazsmsSection, mode: 'new', nonce: '<?php echo wp_create_nonce( "farazsms_create_pattern" ); ?>' },
						success: function(r){ if (r.success && r.data && r.data.pattern_code) { if(!farazsmsPatterns){farazsmsPatterns={};} if(!farazsmsPatterns[farazsmsSection]){farazsmsPatterns[farazsmsSection]={};} farazsmsPatterns[farazsmsSection][statusKey]=r.data.pattern_code; farazsmsPwsmsModal('✅ پترنِ جدید ساخته شد!\n\nکد پترن: ' + $('<i>').text(r.data.pattern_code).html() + '\n\nتایید بین ۱ تا ۲۴ ساعت زمان‌بر است.'); farazsmsDisplayPatternInfo($textarea, statusKey, farazsmsSection); } else { farazsmsPwsmsModal('❌ خطا در ساخت پترن:\n\n' + ((r.data && r.data.message) ? r.data.message : 'خطای ناشناخته')); } },
						error: function(x,s,er){ farazsmsPwsmsModal('❌ خطا در ارسال درخواست:\n\n' + er); },
						complete: function(){ $b.prop('disabled', false).text(ot); }
					});
				});
				$container.append($farazsmsNewBtn);
				
				// اضافه کردن container به th (label)
				$th.append($container);
				
				// نمایش اطلاعات پترن اگر وجود داشته باشد
				farazsmsDisplayPatternInfo($textarea, statusKey, 'buyer', $container);
			});
		}
		
		// اجرای فوری - بدون wait کردن
		if (typeof jQuery !== 'undefined') {
			jQuery(function($) {
				farazsmsAddPatternButtons();
				setTimeout(farazsmsAddPatternButtons, 50);
				setTimeout(farazsmsAddPatternButtons, 150);
				setTimeout(farazsmsAddPatternButtons, 300);
				setTimeout(farazsmsAddPatternButtons, 500);
			});
		} else {
			// اگر jQuery هنوز لود نشده، wait کن
			window.addEventListener('DOMContentLoaded', function() {
				if (typeof jQuery !== 'undefined') {
					jQuery(function($) {
						farazsmsAddPatternButtons();
						setTimeout(farazsmsAddPatternButtons, 50);
						setTimeout(farazsmsAddPatternButtons, 150);
					});
				}
			});
		}
	})(jQuery || window.jQuery || window.$);
	</script>
	<?php
}

function farazsms_add_pattern_buttons_script() {
	$screen = get_current_screen();
	if ( ! farazsms_is_pwsms_admin_settings_screen( $screen ) ) {
		return;
	}

	$tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : '';
	if ( $tab !== 'buyer' && ! empty( $tab ) ) {
		return;
	}
	
	// دریافت اطلاعات پترن‌های ذخیره شده
	$patterns = get_option('farazsms_patterns', []);
	// JSON_HEX_TAG / JSON_HEX_AMP prevent a `</script>` inside an admin-stored pattern
	// from breaking out of the surrounding inline <script> block.
	$patterns_json = wp_json_encode( $patterns, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
	
	?>
	<script type="text/javascript">
	jQuery(function($) {
		// پاس دادن اطلاعات پترن از PHP به JavaScript
		var farazsmsPatterns = <?php echo $patterns_json; ?>;
			// تضمین: اگر مودالِ مدرن لود نشده باشد، حداقل پیام نمایش داده شود.
			if (typeof window.farazsmsPwsmsModal !== "function") { window.farazsmsPwsmsModal = function(m){ window.alert(String(m)); }; }
		
		// تابع برای نمایش اطلاعات پترن
		function farazsmsDisplayPatternInfo($textarea, statusKey, sectionType, $container) {
			// اگر container داده نشده، از th استفاده کن
			if (!$container) {
				var $tr = $textarea.closest('tr');
				if (!$tr.length) {
					return;
				}
				$container = $tr.find('.farazsms-pattern-container');
				if (!$container.length) {
					return;
				}
			}
			
			// حذف info box قبلی اگر وجود داشته باشد
			$container.find('.farazsms-pattern-info').remove();
			
			// بررسی وجود کد پترن
			var patternCode = null;
			if (farazsmsPatterns && farazsmsPatterns[sectionType] && farazsmsPatterns[sectionType][statusKey]) {
				patternCode = farazsmsPatterns[sectionType][statusKey];
			}
			
			if (!patternCode) {
				return; // اگر کد پترن وجود نداشت، چیزی نمایش نده
			}
			
			// ساخت info box
			var $infoBox = $('<div class="farazsms-pattern-info" style="margin-top: 10px; padding: 10px; background: #f0f0f1; border-right: 3px solid #2271b1; border-radius: 3px; font-size: 13px;"></div>');
			$infoBox.html('<strong>کد پترن:</strong> <code style="background: #fff; padding: 2px 5px; border-radius: 2px;">' + $('<i>').text(patternCode).html() + '</code><br><span class="farazsms-pattern-status">در حال دریافت وضعیت...</span>');
			
			// اضافه کردن info box به container (بعد از دکمه)
			$container.append($infoBox);
			
			// دریافت جزئیات پترن از API
			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					action: 'farazsms_get_pattern_details',
					pattern_code: patternCode,
					section_type: sectionType,
					nonce: '<?php echo wp_create_nonce( "farazsms_get_pattern_details" ); ?>'
				},
				success: function(response) {
					var $statusSpan = $infoBox.find('.farazsms-pattern-status');
					if (response.success && response.data && response.data.data) {
						var patternData = response.data.data;
						var status = patternData.status || 'نامشخص';
						var statusText = '';
						var statusClass = '';
						
						// تعیین متن و کلاس بر اساس وضعیت
						if (status === 'active' || status === 'approved') {
							statusText = '✅ تأیید شده و فعال';
							statusClass = 'farazsms-status-active';
						} else if (status === 'pending' || status === 'waiting') {
							statusText = '⏳ در انتظار تأیید (۱ تا ۲۴ ساعت)';
							statusClass = 'farazsms-status-pending';
						} else if (status === 'inactive' || status === 'rejected') {
							statusText = '❌ رد/غیرفعال';
							statusClass = 'farazsms-status-inactive';
						} else {
							statusText = status;
							statusClass = 'farazsms-status-unknown';
						}
						
						$statusSpan.html('<strong>وضعیت:</strong> <span class="' + statusClass + '">' + $('<i>').text(statusText).html() + '</span>');
					} else {
						$statusSpan.html('<strong>وضعیت:</strong> <span class="farazsms-status-unknown">خطا در دریافت اطلاعات</span>');
					}
				},
				error: function() {
					var $statusSpan = $infoBox.find('.farazsms-pattern-status');
					$statusSpan.html('<strong>وضعیت:</strong> <span class="farazsms-status-unknown">خطا در دریافت اطلاعات</span>');
				}
			});
		}
		
		function farazsmsAddPatternButtons() {
			// پیدا کردن همه textarea های buyer settings
			var $textareas = $('textarea[name*="sms_buyer_settings"][name*="sms_body_"]');
			
			if ($textareas.length === 0) {
				$textareas = $('#sms_buyer_settings textarea[name*="sms_body_"]');
			}
			
			if ($textareas.length === 0) {
				$textareas = $('textarea[name*="sms_body_"]').filter(function() {
					return $(this).attr('name').indexOf('sms_buyer_settings') !== -1;
				});
			}
			
			$textareas.each(function() {
				var $textarea = $(this);
				var textareaName = $textarea.attr('name') || '';
				
				// فقط textarea های buyer settings
				if (textareaName.indexOf('sms_buyer_settings') === -1 || textareaName.indexOf('sms_body_') === -1) {
					return;
				}
				
				// بررسی که آیا دکمه قبلاً اضافه شده یا نه
				var $tr = $textarea.closest('tr');
				if (!$tr.length) {
					return;
				}
				
				// اگر دکمه قبلاً اضافه شده، skip کن
				if ($tr.find('.farazsms-pattern-button').length > 0) {
					return;
				}
				
				// استخراج نام وضعیت از name
				var statusKey = '';
				var match = textareaName.match(/sms_body_([^\]]+)/);
				if (match && match[1]) {
					statusKey = match[1];
				}
				
				if (!statusKey) {
					return;
				}
				
				// پیدا کردن th (label) برای قرار دادن دکمه و info box
				var $th = $tr.find('th');
				if (!$th.length) {
					return;
				}
				
				// ساخت container برای دکمه و info box
				var $container = $('<div class="farazsms-pattern-container" style="margin-top: 5px; clear: both;"></div>');
				
				// ساخت دکمه
				var buttonId = 'farazsms-pattern-btn-' + statusKey.replace(/[^a-zA-Z0-9_-]/g, '-');
				// v3.22.8: section از نامِ textarea تشخیص داده می‌شود؛ اگر پترن هست، «ویرایشِ فعلی»، وگرنه «ساخت پترن».
				var farazsmsSection = (textareaName.indexOf('super_admin') !== -1) ? 'super_admin' : ((textareaName.indexOf('product_admin') !== -1) ? 'product_admin' : 'buyer');
				var farazsmsHasPattern = !!(typeof farazsmsPatterns !== 'undefined' && farazsmsPatterns && farazsmsPatterns[farazsmsSection] && farazsmsPatterns[farazsmsSection][statusKey]);
				var $button = $('<button type="button" id="' + buttonId + '" class="button farazsms-pattern-button">' + (farazsmsHasPattern ? '✏️ ویرایشِ پترنِ فعلی' : 'ساخت پترن') + '</button>');
				// اعمال استایل inline برای اطمینان از اعمال
				$button.css({
					'background': '#2271b1',
					'background-color': '#2271b1',
					'color': '#fff',
					'border-color': '#2271b1',
					'border': '1px solid #2271b1',
					'font-weight': '600',
					'padding': '8px 15px',
					'margin-top': '10px',
					'margin-right': '5px',
					'cursor': 'pointer'
				});
				
				// اضافه کردن event handler برای hover
				$button.on('mouseenter', function() {
					$(this).css({
						'background': '#135e96',
						'background-color': '#135e96',
						'border-color': '#135e96',
						'border': '1px solid #135e96'
					});
				}).on('mouseleave', function() {
					$(this).css({
						'background': '#2271b1',
						'background-color': '#2271b1',
						'border-color': '#2271b1',
						'border': '1px solid #2271b1'
					});
				});
				
				// اضافه کردن event handler برای دکمه
				$button.on('click', function(e) {
					e.preventDefault();
					e.stopPropagation();
					var textareaValue = $textarea.val();
					if (!textareaValue || textareaValue.trim() === '') {
						farazsmsPwsmsModal('⚠️ متن پیامک خالی است. لطفا ابتدا متن را وارد کنید.');
						return;
					}
					// تشخیصِ فرمتِ پنلِ قدیمی (pcode:/patterncode: + var:value) و هشدار به کاربر.
					if (/pcode/i.test(textareaValue) || /patterncode/i.test(textareaValue)) {
						farazsmsPwsmsModal('⚠️ متنِ شما شاملِ «pcode» است — این شیوه مخصوصِ پنلِ قدیمی بوده و دیگر کار نمی‌کند.\n\nاینجا کدِ پترن ننویسید؛ فقط متنِ دلخواهِ پیامک را بسازید:\n۱) متنِ پیامک را به فارسی بنویسید.\n۲) هرجا مقدار پویا لازم بود، از متغیرهای ووکامرس (دکمه‌های زیرِ همین کادر) استفاده کنید؛ مثلِ {b_first_name}، {order_id}، {price}، {all_items}.\n۳) سپس دکمه‌ی «ساخت پترن» را بزنید تا خودِ افزونه پترن را بسازد.\n\n⏰ تأییدِ پترن در پنلِ فراز ۱ تا ۲۴ ساعت طول می‌کشد. اگر اشتباه (با فرمتِ قدیمی) بسازید رد می‌شود و باید از نو شروع کنید؛ پس همین حالا درست بسازید.\n\nمثال:\nسلام {b_first_name}\nسفارشِ شماره {order_id} ثبت شد.\nمبلغِ سفارش: {price}');
						return;
					}
					
					var $btn = $(this);
					var originalText = $btn.text();
					
					// غیرفعال کردن دکمه و نمایش loading
					$btn.prop('disabled', true).text('در حال ساخت...');
					
					// ارسال درخواست AJAX برای ساخت پترن
					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'farazsms_create_pattern',
							message_text: textareaValue,
							status_key: statusKey,
							section_type: 'buyer',
							nonce: '<?php echo wp_create_nonce( "farazsms_create_pattern" ); ?>'
						},
						success: function(response) {
							if (response.success && response.data && response.data.pattern_code) {
								var patternCode = response.data.pattern_code;
								
								// به‌روزرسانی farazsmsPatterns
								if (!farazsmsPatterns) {
									farazsmsPatterns = {};
								}
								if (!farazsmsPatterns.buyer) {
									farazsmsPatterns.buyer = {};
								}
								farazsmsPatterns.buyer[statusKey] = patternCode;
								
								var result = '✅ پترن با موفقیت ساخته شد!\n\n';
								result += 'کد پترن: ' + $('<i>').text(patternCode).html() + '\n\n';
								result += 'منتظر تایید پترن باشید.\n';
								result += 'تایید پترن بین ۱ تا ۲۴ ساعت زمان‌بر است و پس از آن پیامک‌های شما ارسال می‌شود.';
								farazsmsPwsmsModal(result);
								
								// نمایش اطلاعات پترن
								farazsmsDisplayPatternInfo($textarea, statusKey, 'buyer');
							} else {
								var errorMsg = '❌ خطا در ساخت پترن:\n\n';
								if (response.data && response.data.message) {
									errorMsg += response.data.message;
								} else if (response.data && typeof response.data === 'string') {
									errorMsg += response.data;
								} else {
									errorMsg += 'خطای ناشناخته';
								}
								farazsmsPwsmsModal(errorMsg);
							}
						},
						error: function(xhr, status, error) {
							farazsmsPwsmsModal('❌ خطا در ارسال درخواست:\n\n' + error + '\n\nلطفا دوباره تلاش کنید.');
						},
						complete: function() {
							// فعال کردن مجدد دکمه
							$btn.prop('disabled', false).text(originalText);
						}
					});
				});
				
				// اضافه کردن دکمه به container
				$container.append($button);
				// v3.22.8: دکمه‌ی دومِ «ساخت پترنِ جدید» (کوچک‌تر). فقط وقتی پترن هست دیده می‌شود؛ mode=new
				// یعنی حتی اگر کدپترنِ موجود هست نادیده گرفته شود و پترنِ تازه ساخته شود (برای سایت‌های کپی‌شده).
				var $farazsmsNewBtn = $('<button type="button" class="button">➕ ساخت پترنِ جدید</button>').css({ 'color':'#9b9b9b','font-size':'11.5px','padding':'3px 8px','margin-top':'6px','cursor':'pointer','width':'100%','background':'#f5f8fe','border':'1px solid #e1e1e1' });
				if (!farazsmsHasPattern) { $farazsmsNewBtn.hide(); }
				$farazsmsNewBtn.on('click', function(e){
					e.preventDefault(); e.stopPropagation();
					var v = $textarea.val();
					if (!v || v.trim() === '') { farazsmsPwsmsModal('⚠️ متن پیامک خالی است. لطفا ابتدا متن را وارد کنید.'); return; }
					if (/pcode/i.test(v) || /patterncode/i.test(v)) { farazsmsPwsmsModal('⚠️ متنِ شما شاملِ «pcode» است — کدِ پترن ننویسید؛ فقط متنِ پیامک را با متغیرهای ووکامرس بسازید.'); return; }
					if (!confirm('یک پترنِ کاملاً جدید ساخته می‌شود و کدپترنِ فعلی جایگزین می‌گردد. مطمئنید؟')) { return; }
					var $b = $(this); var ot = $b.text(); $b.prop('disabled', true).text('در حال ساختِ جدید...');
					$.ajax({ url: ajaxurl, type: 'POST', data: { action: 'farazsms_create_pattern', message_text: v, status_key: statusKey, section_type: farazsmsSection, mode: 'new', nonce: '<?php echo wp_create_nonce( "farazsms_create_pattern" ); ?>' },
						success: function(r){ if (r.success && r.data && r.data.pattern_code) { if(!farazsmsPatterns){farazsmsPatterns={};} if(!farazsmsPatterns[farazsmsSection]){farazsmsPatterns[farazsmsSection]={};} farazsmsPatterns[farazsmsSection][statusKey]=r.data.pattern_code; farazsmsPwsmsModal('✅ پترنِ جدید ساخته شد!\n\nکد پترن: ' + $('<i>').text(r.data.pattern_code).html() + '\n\nتایید بین ۱ تا ۲۴ ساعت زمان‌بر است.'); farazsmsDisplayPatternInfo($textarea, statusKey, farazsmsSection); } else { farazsmsPwsmsModal('❌ خطا در ساخت پترن:\n\n' + ((r.data && r.data.message) ? r.data.message : 'خطای ناشناخته')); } },
						error: function(x,s,er){ farazsmsPwsmsModal('❌ خطا در ارسال درخواست:\n\n' + er); },
						complete: function(){ $b.prop('disabled', false).text(ot); }
					});
				});
				$container.append($farazsmsNewBtn);
				
				// اضافه کردن container به th (label)
				$th.append($container);
				
				// نمایش اطلاعات پترن اگر وجود داشته باشد
				farazsmsDisplayPatternInfo($textarea, statusKey, 'buyer', $container);
			});
		}
		
		farazsmsAddPatternButtons();
		setTimeout(farazsmsAddPatternButtons, 100);
		setTimeout(farazsmsAddPatternButtons, 300);
		setTimeout(farazsmsAddPatternButtons, 500);
		setTimeout(farazsmsAddPatternButtons, 1000);
		setTimeout(farazsmsAddPatternButtons, 2000);
		
		$(window).on('load', function() {
			setTimeout(farazsmsAddPatternButtons, 100);
			setTimeout(farazsmsAddPatternButtons, 500);
		});
		
		if (typeof MutationObserver !== 'undefined') {
			var observer = new MutationObserver(function(mutations) {
				var shouldRun = false;
				mutations.forEach(function(mutation) {
					if (mutation.addedNodes.length > 0) {
						shouldRun = true;
					}
				});
				if (shouldRun) {
					setTimeout(farazsmsAddPatternButtons, 200);
				}
			});
			
			var bodyElement = document.body;
			if (bodyElement) {
				observer.observe(bodyElement, { 
					childList: true, 
					subtree: true 
				});
			}
		}
		
		$(document).on('click', 'a[href*="tab=buyer"]', function() {
			setTimeout(farazsmsAddPatternButtons, 500);
			setTimeout(farazsmsAddPatternButtons, 1000);
		});
	});
	</script>
	<style type="text/css">
		/* استایل برای دکمه ساخت پترن */
		button.farazsms-pattern-button,
		.button.farazsms-pattern-button,
		.farazsms-pattern-button.button {
			background: #2271b1 !important;
			background-color: #2271b1 !important;
			color: #fff !important;
			border-color: #2271b1 !important;
			border: 1px solid #2271b1 !important;
			font-weight: 600 !important;
			padding: 8px 15px !important;
			margin-top: 10px !important;
			margin-right: 5px !important;
			cursor: pointer !important;
		}
		button.farazsms-pattern-button:hover,
		.button.farazsms-pattern-button:hover,
		.farazsms-pattern-button.button:hover {
			background: #135e96 !important;
			background-color: #135e96 !important;
			border-color: #135e96 !important;
			border: 1px solid #135e96 !important;
			color: #fff !important;
		}
		button.farazsms-pattern-button:focus,
		.button.farazsms-pattern-button:focus,
		.farazsms-pattern-button.button:focus {
			box-shadow: 0 0 0 1px #fff, 0 0 0 3px #2271b1 !important;
		}
		/* استایل برای وضعیت پترن */
		.farazsms-status-active {
			color: #00a32a;
			font-weight: 600;
		}
		.farazsms-status-pending {
			color: #dba617;
			font-weight: 600;
		}
		.farazsms-status-inactive {
			color: #d63638;
			font-weight: 600;
		}
		.farazsms-status-unknown {
			color: #4d4d4d;
		}
		/* استایل برای container دکمه و info box در th */
		.farazsms-pattern-container {
			margin-top: 5px;
			clear: both;
		}
	</style>
	<?php
}

/**
 * افزودن دکمه "ساخت پترن" کنار هر textarea وضعیت در صفحه super_admin
 * استفاده از action hook برای اضافه کردن دکمه بعد از render شدن فیلدها
 */
add_action( 'pwoosms_settings_form_bottom_sms_super_admin_settings', 'farazsms_add_pattern_buttons_to_super_admin_form', 10, 1 );
add_action( 'admin_footer', 'farazsms_add_pattern_buttons_super_admin_script' );

function farazsms_add_pattern_buttons_to_super_admin_form( $form ) {
	$patterns = get_option('farazsms_patterns', []);
	// JSON_HEX_TAG / JSON_HEX_AMP prevent a `</script>` inside an admin-stored pattern
	// from breaking out of the surrounding inline <script> block.
	$patterns_json = wp_json_encode( $patterns, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
	?>
	<script type="text/javascript">
	(function($) {
		var farazsmsPatterns = <?php echo $patterns_json; ?>;
			// تضمین: اگر مودالِ مدرن لود نشده باشد، حداقل پیام نمایش داده شود.
			if (typeof window.farazsmsPwsmsModal !== "function") { window.farazsmsPwsmsModal = function(m){ window.alert(String(m)); }; }
		
		function farazsmsDisplayPatternInfo($textarea, statusKey, sectionType, $container) {
			if (!$container) {
				var $tr = $textarea.closest('tr');
				if (!$tr.length) {
					return;
				}
				$container = $tr.find('.farazsms-pattern-container');
				if (!$container.length) {
					return;
				}
			}
			
			// حذف info box قبلی اگر وجود داشته باشد
			$container.find('.farazsms-pattern-info').remove();
			
			// بررسی وجود کد پترن
			var patternCode = null;
			if (farazsmsPatterns && farazsmsPatterns[sectionType] && farazsmsPatterns[sectionType][statusKey]) {
				patternCode = farazsmsPatterns[sectionType][statusKey];
			}
			
			if (!patternCode) {
				return; // اگر کد پترن وجود نداشت، چیزی نمایش نده
			}
			
			// ساخت info box
			var $infoBox = $('<div class="farazsms-pattern-info" style="margin-top: 10px; padding: 10px; background: #f0f0f1; border-right: 3px solid #2271b1; border-radius: 3px; font-size: 13px;"></div>');
			$infoBox.html('<strong>کد پترن:</strong> <code style="background: #fff; padding: 2px 5px; border-radius: 2px;">' + $('<i>').text(patternCode).html() + '</code><br><span class="farazsms-pattern-status">در حال دریافت وضعیت...</span>');
			
			// اضافه کردن info box به container (بعد از دکمه)
			$container.append($infoBox);
			
			// دریافت جزئیات پترن از API
			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					action: 'farazsms_get_pattern_details',
					pattern_code: patternCode,
					section_type: sectionType,
					nonce: '<?php echo wp_create_nonce( "farazsms_get_pattern_details" ); ?>'
				},
				success: function(response) {
					var $statusSpan = $infoBox.find('.farazsms-pattern-status');
					if (response.success && response.data && response.data.data) {
						var patternData = response.data.data;
						var status = patternData.status || 'نامشخص';
						var statusText = '';
						var statusClass = '';
						
						// تعیین متن و کلاس بر اساس وضعیت
						if (status === 'active' || status === 'approved') {
							statusText = '✅ تأیید شده و فعال';
							statusClass = 'farazsms-status-active';
						} else if (status === 'pending' || status === 'waiting') {
							statusText = '⏳ در انتظار تأیید (۱ تا ۲۴ ساعت)';
							statusClass = 'farazsms-status-pending';
						} else if (status === 'inactive' || status === 'rejected') {
							statusText = '❌ رد/غیرفعال';
							statusClass = 'farazsms-status-inactive';
						} else {
							statusText = status;
							statusClass = 'farazsms-status-unknown';
						}
						
						$statusSpan.html('<strong>وضعیت:</strong> <span class="' + statusClass + '">' + $('<i>').text(statusText).html() + '</span>');
					} else {
						$statusSpan.html('<strong>وضعیت:</strong> <span class="farazsms-status-unknown">خطا در دریافت اطلاعات</span>');
					}
				},
				error: function() {
					var $statusSpan = $infoBox.find('.farazsms-pattern-status');
					$statusSpan.html('<strong>وضعیت:</strong> <span class="farazsms-status-unknown">خطا در دریافت اطلاعات</span>');
				}
			});
		}
		
		function farazsmsAddPatternButtonsSuperAdmin() {
			// پیدا کردن همه textarea های super_admin settings
			// شامل: super_admin_sms_body_* و admin_low_stock و admin_out_stock
			var $textareas = $('textarea[name*="sms_super_admin_settings"]').filter(function() {
				var name = $(this).attr('name') || '';
				return name.indexOf('sms_super_admin_settings') !== -1 && (
					name.indexOf('super_admin_sms_body_') !== -1 ||
					name.indexOf('[admin_low_stock]') !== -1 ||
					name.indexOf('[admin_out_stock]') !== -1
				);
			});
			
			if ($textareas.length === 0) {
				$textareas = $('#sms_super_admin_settings textarea').filter(function() {
					var name = $(this).attr('name') || '';
					return name.indexOf('super_admin_sms_body_') !== -1 ||
						name.indexOf('[admin_low_stock]') !== -1 ||
						name.indexOf('[admin_out_stock]') !== -1;
				});
			}
			
			if ($textareas.length === 0) {
				return;
			}
			
			$textareas.each(function() {
				var $textarea = $(this);
				var textareaName = $textarea.attr('name') || '';
				if (textareaName.indexOf('sms_super_admin_settings') === -1) {
					return;
				}
				
				// بررسی که آیا دکمه قبلاً اضافه شده یا نه
				var $tr = $textarea.closest('tr');
				if (!$tr.length) {
					return;
				}
				
				// اگر دکمه قبلاً اضافه شده، skip کن
				if ($tr.find('.farazsms-pattern-button').length > 0) {
					return;
				}
				
				// استخراج نام وضعیت از name
				var statusKey = '';
				var match = textareaName.match(/super_admin_sms_body_([^\]]+)/);
				if (match && match[1]) {
					statusKey = match[1];
				} else {
					// برای فیلدهای موجودی انبار
					match = textareaName.match(/\[(admin_low_stock|admin_out_stock)\]/);
					if (match && match[1]) {
						statusKey = match[1];
					}
				}
				
				if (!statusKey) {
					return;
				}
				
				// پیدا کردن th (label) برای قرار دادن دکمه و info box
				var $th = $tr.find('th');
				if (!$th.length) {
					return;
				}
				
				// ساخت container برای دکمه و info box
				var $container = $('<div class="farazsms-pattern-container" style="margin-top: 5px; clear: both;"></div>');
				
				// ساخت دکمه
				var buttonId = 'farazsms-pattern-btn-super-' + statusKey.replace(/[^a-zA-Z0-9_-]/g, '-');
				// v3.22.8: section از نامِ textarea تشخیص داده می‌شود؛ اگر پترن هست، «ویرایشِ فعلی»، وگرنه «ساخت پترن».
				var farazsmsSection = (textareaName.indexOf('super_admin') !== -1) ? 'super_admin' : ((textareaName.indexOf('product_admin') !== -1) ? 'product_admin' : 'buyer');
				var farazsmsHasPattern = !!(typeof farazsmsPatterns !== 'undefined' && farazsmsPatterns && farazsmsPatterns[farazsmsSection] && farazsmsPatterns[farazsmsSection][statusKey]);
				var $button = $('<button type="button" id="' + buttonId + '" class="button farazsms-pattern-button">' + (farazsmsHasPattern ? '✏️ ویرایشِ پترنِ فعلی' : 'ساخت پترن') + '</button>');
				// اعمال استایل inline برای اطمینان از اعمال
				$button.css({
					'background': '#2271b1',
					'background-color': '#2271b1',
					'color': '#fff',
					'border-color': '#2271b1',
					'border': '1px solid #2271b1',
					'font-weight': '600',
					'padding': '4px 10px',
					'margin-top': '10px',
					'margin-right': '5px',
					'cursor': 'pointer',
					'width': '100%'
				});
				
				$button.on('mouseenter', function() {
					$(this).css({
						'background': '#135e96',
						'background-color': '#135e96',
						'border-color': '#135e96',
						'border': '1px solid #135e96'
					});
				}).on('mouseleave', function() {
					$(this).css({
						'background': '#2271b1',
						'background-color': '#2271b1',
						'border-color': '#2271b1',
						'border': '1px solid #2271b1'
					});
				});
				
				// اضافه کردن event handler برای دکمه
				$button.on('click', function(e) {
					e.preventDefault();
					e.stopPropagation();
					var textareaValue = $textarea.val();
					if (!textareaValue || textareaValue.trim() === '') {
						farazsmsPwsmsModal('⚠️ متن پیامک خالی است. لطفا ابتدا متن را وارد کنید.');
						return;
					}
					// تشخیصِ فرمتِ پنلِ قدیمی (pcode:/patterncode: + var:value) و هشدار به کاربر.
					if (/pcode/i.test(textareaValue) || /patterncode/i.test(textareaValue)) {
						farazsmsPwsmsModal('⚠️ متنِ شما شاملِ «pcode» است — این شیوه مخصوصِ پنلِ قدیمی بوده و دیگر کار نمی‌کند.\n\nاینجا کدِ پترن ننویسید؛ فقط متنِ دلخواهِ پیامک را بسازید:\n۱) متنِ پیامک را به فارسی بنویسید.\n۲) هرجا مقدار پویا لازم بود، از متغیرهای ووکامرس (دکمه‌های زیرِ همین کادر) استفاده کنید؛ مثلِ {b_first_name}، {order_id}، {price}، {all_items}.\n۳) سپس دکمه‌ی «ساخت پترن» را بزنید تا خودِ افزونه پترن را بسازد.\n\n⏰ تأییدِ پترن در پنلِ فراز ۱ تا ۲۴ ساعت طول می‌کشد. اگر اشتباه (با فرمتِ قدیمی) بسازید رد می‌شود و باید از نو شروع کنید؛ پس همین حالا درست بسازید.\n\nمثال:\nسلام {b_first_name}\nسفارشِ شماره {order_id} ثبت شد.\nمبلغِ سفارش: {price}');
						return;
					}
					
					var $btn = $(this);
					var originalText = $btn.text();
					
					// غیرفعال کردن دکمه و نمایش loading
					$btn.prop('disabled', true).text('در حال ساخت...');
					
					// ارسال درخواست AJAX برای ساخت پترن
					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'farazsms_create_pattern',
							message_text: textareaValue,
							status_key: statusKey,
							section_type: 'super_admin',
							nonce: '<?php echo wp_create_nonce( "farazsms_create_pattern" ); ?>'
						},
						success: function(response) {
							if (response.success && response.data && response.data.pattern_code) {
								var patternCode = response.data.pattern_code;
								
								// به‌روزرسانی farazsmsPatterns
								if (!farazsmsPatterns) {
									farazsmsPatterns = {};
								}
								if (!farazsmsPatterns.super_admin) {
									farazsmsPatterns.super_admin = {};
								}
								farazsmsPatterns.super_admin[statusKey] = patternCode;
								
								var result = '✅ پترن با موفقیت ساخته شد!\n\n';
								result += 'کد پترن: ' + $('<i>').text(patternCode).html() + '\n\n';
								result += 'منتظر تایید پترن باشید.\n';
								result += 'تایید پترن بین ۱ تا ۲۴ ساعت زمان‌بر است و پس از آن پیامک‌های شما ارسال می‌شود.';
								farazsmsPwsmsModal(result);
								
								// نمایش اطلاعات پترن
								farazsmsDisplayPatternInfo($textarea, statusKey, 'super_admin', $container);
							} else {
								var errorMsg = '❌ خطا در ساخت پترن:\n\n';
								if (response.data && response.data.message) {
									errorMsg += response.data.message;
								} else if (response.data && typeof response.data === 'string') {
									errorMsg += response.data;
								} else {
									errorMsg += 'خطای ناشناخته';
								}
								farazsmsPwsmsModal(errorMsg);
							}
						},
						error: function(xhr, status, error) {
							farazsmsPwsmsModal('❌ خطا در ارسال درخواست:\n\n' + error + '\n\nلطفا دوباره تلاش کنید.');
						},
						complete: function() {
							// فعال کردن مجدد دکمه
							$btn.prop('disabled', false).text(originalText);
						}
					});
				});
				
				// اضافه کردن دکمه به container
				$container.append($button);
				// v3.22.8: دکمه‌ی دومِ «ساخت پترنِ جدید» (کوچک‌تر). فقط وقتی پترن هست دیده می‌شود؛ mode=new
				// یعنی حتی اگر کدپترنِ موجود هست نادیده گرفته شود و پترنِ تازه ساخته شود (برای سایت‌های کپی‌شده).
				var $farazsmsNewBtn = $('<button type="button" class="button">➕ ساخت پترنِ جدید</button>').css({ 'color':'#9b9b9b','font-size':'11.5px','padding':'3px 8px','margin-top':'6px','cursor':'pointer','width':'100%','background':'#f5f8fe','border':'1px solid #e1e1e1' });
				if (!farazsmsHasPattern) { $farazsmsNewBtn.hide(); }
				$farazsmsNewBtn.on('click', function(e){
					e.preventDefault(); e.stopPropagation();
					var v = $textarea.val();
					if (!v || v.trim() === '') { farazsmsPwsmsModal('⚠️ متن پیامک خالی است. لطفا ابتدا متن را وارد کنید.'); return; }
					if (/pcode/i.test(v) || /patterncode/i.test(v)) { farazsmsPwsmsModal('⚠️ متنِ شما شاملِ «pcode» است — کدِ پترن ننویسید؛ فقط متنِ پیامک را با متغیرهای ووکامرس بسازید.'); return; }
					if (!confirm('یک پترنِ کاملاً جدید ساخته می‌شود و کدپترنِ فعلی جایگزین می‌گردد. مطمئنید؟')) { return; }
					var $b = $(this); var ot = $b.text(); $b.prop('disabled', true).text('در حال ساختِ جدید...');
					$.ajax({ url: ajaxurl, type: 'POST', data: { action: 'farazsms_create_pattern', message_text: v, status_key: statusKey, section_type: farazsmsSection, mode: 'new', nonce: '<?php echo wp_create_nonce( "farazsms_create_pattern" ); ?>' },
						success: function(r){ if (r.success && r.data && r.data.pattern_code) { if(!farazsmsPatterns){farazsmsPatterns={};} if(!farazsmsPatterns[farazsmsSection]){farazsmsPatterns[farazsmsSection]={};} farazsmsPatterns[farazsmsSection][statusKey]=r.data.pattern_code; farazsmsPwsmsModal('✅ پترنِ جدید ساخته شد!\n\nکد پترن: ' + $('<i>').text(r.data.pattern_code).html() + '\n\nتایید بین ۱ تا ۲۴ ساعت زمان‌بر است.'); farazsmsDisplayPatternInfo($textarea, statusKey, farazsmsSection); } else { farazsmsPwsmsModal('❌ خطا در ساخت پترن:\n\n' + ((r.data && r.data.message) ? r.data.message : 'خطای ناشناخته')); } },
						error: function(x,s,er){ farazsmsPwsmsModal('❌ خطا در ارسال درخواست:\n\n' + er); },
						complete: function(){ $b.prop('disabled', false).text(ot); }
					});
				});
				$container.append($farazsmsNewBtn);
				
				// اضافه کردن container به th (label)
				$th.append($container);
				
				// نمایش اطلاعات پترن اگر وجود داشته باشد
				farazsmsDisplayPatternInfo($textarea, statusKey, 'super_admin', $container);
			});
		}
		
		// اجرای فوری - بدون wait کردن
		if (typeof jQuery !== 'undefined') {
			jQuery(function($) {
				farazsmsAddPatternButtonsSuperAdmin();
				setTimeout(farazsmsAddPatternButtonsSuperAdmin, 50);
				setTimeout(farazsmsAddPatternButtonsSuperAdmin, 150);
				setTimeout(farazsmsAddPatternButtonsSuperAdmin, 300);
				setTimeout(farazsmsAddPatternButtonsSuperAdmin, 500);
			});
		} else {
			// اگر jQuery هنوز لود نشده، wait کن
			window.addEventListener('DOMContentLoaded', function() {
				if (typeof jQuery !== 'undefined') {
					jQuery(function($) {
						farazsmsAddPatternButtonsSuperAdmin();
						setTimeout(farazsmsAddPatternButtonsSuperAdmin, 50);
						setTimeout(farazsmsAddPatternButtonsSuperAdmin, 150);
					});
				}
			});
		}
	})(jQuery || window.jQuery || window.$);
	</script>
	<?php
}

function farazsms_add_pattern_buttons_super_admin_script() {
	$screen = get_current_screen();
	if ( ! farazsms_is_pwsms_admin_settings_screen( $screen ) ) {
		return;
	}

	$tab = isset( $_GET['tab'] ) ? sanitize_text_field( $_GET['tab'] ) : '';
	if ( $tab !== 'super_admin' && ! empty( $tab ) ) {
		return;
	}
	
	// دریافت اطلاعات پترن‌های ذخیره شده
	$patterns = get_option('farazsms_patterns', []);
	// JSON_HEX_TAG / JSON_HEX_AMP prevent a `</script>` inside an admin-stored pattern
	// from breaking out of the surrounding inline <script> block.
	$patterns_json = wp_json_encode( $patterns, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
	
	?>
	<script type="text/javascript">
	jQuery(function($) {
		// پاس دادن اطلاعات پترن از PHP به JavaScript
		var farazsmsPatterns = <?php echo $patterns_json; ?>;
			// تضمین: اگر مودالِ مدرن لود نشده باشد، حداقل پیام نمایش داده شود.
			if (typeof window.farazsmsPwsmsModal !== "function") { window.farazsmsPwsmsModal = function(m){ window.alert(String(m)); }; }
		
		// تابع برای نمایش اطلاعات پترن
		function farazsmsDisplayPatternInfo($textarea, statusKey, sectionType, $container) {
			// اگر container داده نشده، از th استفاده کن
			if (!$container) {
				var $tr = $textarea.closest('tr');
				if (!$tr.length) {
					return;
				}
				$container = $tr.find('.farazsms-pattern-container');
				if (!$container.length) {
					return;
				}
			}
			
			// حذف info box قبلی اگر وجود داشته باشد
			$container.find('.farazsms-pattern-info').remove();
			
			// بررسی وجود کد پترن
			var patternCode = null;
			if (farazsmsPatterns && farazsmsPatterns[sectionType] && farazsmsPatterns[sectionType][statusKey]) {
				patternCode = farazsmsPatterns[sectionType][statusKey];
			}
			
			if (!patternCode) {
				return; // اگر کد پترن وجود نداشت، چیزی نمایش نده
			}
			
			// ساخت info box
			var $infoBox = $('<div class="farazsms-pattern-info" style="margin-top: 10px; padding: 10px; background: #f0f0f1; border-right: 3px solid #2271b1; border-radius: 3px; font-size: 13px;"></div>');
			$infoBox.html('<strong>کد پترن:</strong> <code style="background: #fff; padding: 2px 5px; border-radius: 2px;">' + $('<i>').text(patternCode).html() + '</code><br><span class="farazsms-pattern-status">در حال دریافت وضعیت...</span>');
			
			// اضافه کردن info box به container (بعد از دکمه)
			$container.append($infoBox);
			
			// دریافت جزئیات پترن از API
			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					action: 'farazsms_get_pattern_details',
					pattern_code: patternCode,
					section_type: sectionType,
					nonce: '<?php echo wp_create_nonce( "farazsms_get_pattern_details" ); ?>'
				},
				success: function(response) {
					var $statusSpan = $infoBox.find('.farazsms-pattern-status');
					if (response.success && response.data && response.data.data) {
						var patternData = response.data.data;
						var status = patternData.status || 'نامشخص';
						var statusText = '';
						var statusClass = '';
						
						// تعیین متن و کلاس بر اساس وضعیت
						if (status === 'active' || status === 'approved') {
							statusText = '✅ تأیید شده و فعال';
							statusClass = 'farazsms-status-active';
						} else if (status === 'pending' || status === 'waiting') {
							statusText = '⏳ در انتظار تأیید (۱ تا ۲۴ ساعت)';
							statusClass = 'farazsms-status-pending';
						} else if (status === 'inactive' || status === 'rejected') {
							statusText = '❌ رد/غیرفعال';
							statusClass = 'farazsms-status-inactive';
						} else {
							statusText = status;
							statusClass = 'farazsms-status-unknown';
						}
						
						$statusSpan.html('<strong>وضعیت:</strong> <span class="' + statusClass + '">' + $('<i>').text(statusText).html() + '</span>');
					} else {
						$statusSpan.html('<strong>وضعیت:</strong> <span class="farazsms-status-unknown">خطا در دریافت اطلاعات</span>');
					}
				},
				error: function() {
					var $statusSpan = $infoBox.find('.farazsms-pattern-status');
					$statusSpan.html('<strong>وضعیت:</strong> <span class="farazsms-status-unknown">خطا در دریافت اطلاعات</span>');
				}
			});
		}
		
		function farazsmsAddPatternButtonsSuperAdmin() {
			// پیدا کردن همه textarea های super_admin settings
			// شامل: super_admin_sms_body_* و admin_low_stock و admin_out_stock
			var $textareas = $('textarea[name*="sms_super_admin_settings"]').filter(function() {
				var name = $(this).attr('name') || '';
				return name.indexOf('sms_super_admin_settings') !== -1 && (
					name.indexOf('super_admin_sms_body_') !== -1 ||
					name.indexOf('[admin_low_stock]') !== -1 ||
					name.indexOf('[admin_out_stock]') !== -1
				);
			});
			
			if ($textareas.length === 0) {
				$textareas = $('#sms_super_admin_settings textarea').filter(function() {
					var name = $(this).attr('name') || '';
					return name.indexOf('super_admin_sms_body_') !== -1 ||
						name.indexOf('[admin_low_stock]') !== -1 ||
						name.indexOf('[admin_out_stock]') !== -1;
				});
			}
			
			$textareas.each(function() {
				var $textarea = $(this);
				var textareaName = $textarea.attr('name') || '';
				
				// فقط textarea های super_admin settings
				if (textareaName.indexOf('sms_super_admin_settings') === -1) {
					return;
				}
				
				// بررسی که آیا دکمه قبلاً اضافه شده یا نه
				var $tr = $textarea.closest('tr');
				if (!$tr.length) {
					return;
				}
				
				// اگر دکمه قبلاً اضافه شده، skip کن
				if ($tr.find('.farazsms-pattern-button').length > 0) {
					return;
				}
				
				// استخراج نام وضعیت از name
				var statusKey = '';
				var match = textareaName.match(/super_admin_sms_body_([^\]]+)/);
				if (match && match[1]) {
					statusKey = match[1];
				} else {
					// برای فیلدهای موجودی انبار
					match = textareaName.match(/\[(admin_low_stock|admin_out_stock)\]/);
					if (match && match[1]) {
						statusKey = match[1];
					}
				}
				
				if (!statusKey) {
					return;
				}
				
				// پیدا کردن th (label) برای قرار دادن دکمه و info box
				var $th = $tr.find('th');
				if (!$th.length) {
					return;
				}
				
				// ساخت container برای دکمه و info box
				var $container = $('<div class="farazsms-pattern-container" style="margin-top: 5px; clear: both;"></div>');
				
				// ساخت دکمه
				var buttonId = 'farazsms-pattern-btn-super-' + statusKey.replace(/[^a-zA-Z0-9_-]/g, '-');
				// v3.22.8: section از نامِ textarea تشخیص داده می‌شود؛ اگر پترن هست، «ویرایشِ فعلی»، وگرنه «ساخت پترن».
				var farazsmsSection = (textareaName.indexOf('super_admin') !== -1) ? 'super_admin' : ((textareaName.indexOf('product_admin') !== -1) ? 'product_admin' : 'buyer');
				var farazsmsHasPattern = !!(typeof farazsmsPatterns !== 'undefined' && farazsmsPatterns && farazsmsPatterns[farazsmsSection] && farazsmsPatterns[farazsmsSection][statusKey]);
				var $button = $('<button type="button" id="' + buttonId + '" class="button farazsms-pattern-button">' + (farazsmsHasPattern ? '✏️ ویرایشِ پترنِ فعلی' : 'ساخت پترن') + '</button>');
				// اعمال استایل inline برای اطمینان از اعمال
				$button.css({
					'background': '#2271b1',
					'background-color': '#2271b1',
					'color': '#fff',
					'border-color': '#2271b1',
					'border': '1px solid #2271b1',
					'font-weight': '600',
					'padding': '4px 10px',
					'margin-top': '10px',
					'margin-right': '5px',
					'cursor': 'pointer'
				});
				
				// اضافه کردن event handler برای hover
				$button.on('mouseenter', function() {
					$(this).css({
						'background': '#135e96',
						'background-color': '#135e96',
						'border-color': '#135e96',
						'border': '1px solid #135e96'
					});
				}).on('mouseleave', function() {
					$(this).css({
						'background': '#2271b1',
						'background-color': '#2271b1',
						'border-color': '#2271b1',
						'border': '1px solid #2271b1'
					});
				});
				
				// اضافه کردن event handler برای دکمه
				$button.on('click', function(e) {
					e.preventDefault();
					e.stopPropagation();
					var textareaValue = $textarea.val();
					if (!textareaValue || textareaValue.trim() === '') {
						farazsmsPwsmsModal('⚠️ متن پیامک خالی است. لطفا ابتدا متن را وارد کنید.');
						return;
					}
					// تشخیصِ فرمتِ پنلِ قدیمی (pcode:/patterncode: + var:value) و هشدار به کاربر.
					if (/pcode/i.test(textareaValue) || /patterncode/i.test(textareaValue)) {
						farazsmsPwsmsModal('⚠️ متنِ شما شاملِ «pcode» است — این شیوه مخصوصِ پنلِ قدیمی بوده و دیگر کار نمی‌کند.\n\nاینجا کدِ پترن ننویسید؛ فقط متنِ دلخواهِ پیامک را بسازید:\n۱) متنِ پیامک را به فارسی بنویسید.\n۲) هرجا مقدار پویا لازم بود، از متغیرهای ووکامرس (دکمه‌های زیرِ همین کادر) استفاده کنید؛ مثلِ {b_first_name}، {order_id}، {price}، {all_items}.\n۳) سپس دکمه‌ی «ساخت پترن» را بزنید تا خودِ افزونه پترن را بسازد.\n\n⏰ تأییدِ پترن در پنلِ فراز ۱ تا ۲۴ ساعت طول می‌کشد. اگر اشتباه (با فرمتِ قدیمی) بسازید رد می‌شود و باید از نو شروع کنید؛ پس همین حالا درست بسازید.\n\nمثال:\nسلام {b_first_name}\nسفارشِ شماره {order_id} ثبت شد.\nمبلغِ سفارش: {price}');
						return;
					}
					
					var $btn = $(this);
					var originalText = $btn.text();
					
					// غیرفعال کردن دکمه و نمایش loading
					$btn.prop('disabled', true).text('در حال ساخت...');
					
					// ارسال درخواست AJAX برای ساخت پترن
					$.ajax({
						url: ajaxurl,
						type: 'POST',
						data: {
							action: 'farazsms_create_pattern',
							message_text: textareaValue,
							status_key: statusKey,
							section_type: 'super_admin',
							nonce: '<?php echo wp_create_nonce( "farazsms_create_pattern" ); ?>'
						},
						success: function(response) {
							if (response.success && response.data && response.data.pattern_code) {
								var patternCode = response.data.pattern_code;
								
								// به‌روزرسانی farazsmsPatterns
								if (!farazsmsPatterns) {
									farazsmsPatterns = {};
								}
								if (!farazsmsPatterns.super_admin) {
									farazsmsPatterns.super_admin = {};
								}
								farazsmsPatterns.super_admin[statusKey] = patternCode;
								
								var result = '✅ پترن با موفقیت ساخته شد!\n\n';
								result += 'کد پترن: ' + $('<i>').text(patternCode).html() + '\n\n';
								result += 'منتظر تایید پترن باشید.\n';
								result += 'تایید پترن بین ۱ تا ۲۴ ساعت زمان‌بر است و پس از آن پیامک‌های شما ارسال می‌شود.';
								farazsmsPwsmsModal(result);
								
								// نمایش اطلاعات پترن
								farazsmsDisplayPatternInfo($textarea, statusKey, 'super_admin', $container);
							} else {
								var errorMsg = '❌ خطا در ساخت پترن:\n\n';
								if (response.data && response.data.message) {
									errorMsg += response.data.message;
								} else if (response.data && typeof response.data === 'string') {
									errorMsg += response.data;
								} else {
									errorMsg += 'خطای ناشناخته';
								}
								farazsmsPwsmsModal(errorMsg);
							}
						},
						error: function(xhr, status, error) {
							farazsmsPwsmsModal('❌ خطا در ارسال درخواست:\n\n' + error + '\n\nلطفا دوباره تلاش کنید.');
						},
						complete: function() {
							// فعال کردن مجدد دکمه
							$btn.prop('disabled', false).text(originalText);
						}
					});
				});
				
				// اضافه کردن دکمه به container
				$container.append($button);
				// v3.22.8: دکمه‌ی دومِ «ساخت پترنِ جدید» (کوچک‌تر). فقط وقتی پترن هست دیده می‌شود؛ mode=new
				// یعنی حتی اگر کدپترنِ موجود هست نادیده گرفته شود و پترنِ تازه ساخته شود (برای سایت‌های کپی‌شده).
				var $farazsmsNewBtn = $('<button type="button" class="button">➕ ساخت پترنِ جدید</button>').css({ 'color':'#9b9b9b','font-size':'11.5px','padding':'3px 8px','margin-top':'6px','cursor':'pointer','width':'100%','background':'#f5f8fe','border':'1px solid #e1e1e1' });
				if (!farazsmsHasPattern) { $farazsmsNewBtn.hide(); }
				$farazsmsNewBtn.on('click', function(e){
					e.preventDefault(); e.stopPropagation();
					var v = $textarea.val();
					if (!v || v.trim() === '') { farazsmsPwsmsModal('⚠️ متن پیامک خالی است. لطفا ابتدا متن را وارد کنید.'); return; }
					if (/pcode/i.test(v) || /patterncode/i.test(v)) { farazsmsPwsmsModal('⚠️ متنِ شما شاملِ «pcode» است — کدِ پترن ننویسید؛ فقط متنِ پیامک را با متغیرهای ووکامرس بسازید.'); return; }
					if (!confirm('یک پترنِ کاملاً جدید ساخته می‌شود و کدپترنِ فعلی جایگزین می‌گردد. مطمئنید؟')) { return; }
					var $b = $(this); var ot = $b.text(); $b.prop('disabled', true).text('در حال ساختِ جدید...');
					$.ajax({ url: ajaxurl, type: 'POST', data: { action: 'farazsms_create_pattern', message_text: v, status_key: statusKey, section_type: farazsmsSection, mode: 'new', nonce: '<?php echo wp_create_nonce( "farazsms_create_pattern" ); ?>' },
						success: function(r){ if (r.success && r.data && r.data.pattern_code) { if(!farazsmsPatterns){farazsmsPatterns={};} if(!farazsmsPatterns[farazsmsSection]){farazsmsPatterns[farazsmsSection]={};} farazsmsPatterns[farazsmsSection][statusKey]=r.data.pattern_code; farazsmsPwsmsModal('✅ پترنِ جدید ساخته شد!\n\nکد پترن: ' + $('<i>').text(r.data.pattern_code).html() + '\n\nتایید بین ۱ تا ۲۴ ساعت زمان‌بر است.'); farazsmsDisplayPatternInfo($textarea, statusKey, farazsmsSection); } else { farazsmsPwsmsModal('❌ خطا در ساخت پترن:\n\n' + ((r.data && r.data.message) ? r.data.message : 'خطای ناشناخته')); } },
						error: function(x,s,er){ farazsmsPwsmsModal('❌ خطا در ارسال درخواست:\n\n' + er); },
						complete: function(){ $b.prop('disabled', false).text(ot); }
					});
				});
				$container.append($farazsmsNewBtn);
				
				// اضافه کردن container به th (label)
				$th.append($container);
				
				// نمایش اطلاعات پترن اگر وجود داشته باشد
				farazsmsDisplayPatternInfo($textarea, statusKey, 'super_admin', $container);
			});
		}
		
		farazsmsAddPatternButtonsSuperAdmin();
		setTimeout(farazsmsAddPatternButtonsSuperAdmin, 100);
		setTimeout(farazsmsAddPatternButtonsSuperAdmin, 300);
		setTimeout(farazsmsAddPatternButtonsSuperAdmin, 500);
		setTimeout(farazsmsAddPatternButtonsSuperAdmin, 1000);
		setTimeout(farazsmsAddPatternButtonsSuperAdmin, 2000);
		
		$(window).on('load', function() {
			setTimeout(farazsmsAddPatternButtonsSuperAdmin, 100);
			setTimeout(farazsmsAddPatternButtonsSuperAdmin, 500);
		});
		
		if (typeof MutationObserver !== 'undefined') {
			var observer = new MutationObserver(function(mutations) {
				var shouldRun = false;
				mutations.forEach(function(mutation) {
					if (mutation.addedNodes.length > 0) {
						shouldRun = true;
					}
				});
				if (shouldRun) {
					setTimeout(farazsmsAddPatternButtonsSuperAdmin, 200);
				}
			});
			
			var bodyElement = document.body;
			if (bodyElement) {
				observer.observe(bodyElement, { 
					childList: true, 
					subtree: true 
				});
			}
		}
		
		$(document).on('click', 'a[href*="tab=super_admin"]', function() {
			setTimeout(farazsmsAddPatternButtonsSuperAdmin, 500);
			setTimeout(farazsmsAddPatternButtonsSuperAdmin, 1000);
		});
	});
	</script>
	<style type="text/css">
		/* استایل برای دکمه ساخت پترن */
		button.farazsms-pattern-button,
		.button.farazsms-pattern-button,
		.farazsms-pattern-button.button {
			background: #2271b1 !important;
			background-color: #2271b1 !important;
			color: #fff !important;
			border-color: #2271b1 !important;
			border: 1px solid #2271b1 !important;
			font-weight: 600 !important;
			padding: 4px 10px !important;
			margin-top: 10px !important;
			margin-right: 5px !important;
			cursor: pointer !important;
		}
		button.farazsms-pattern-button:hover,
		.button.farazsms-pattern-button:hover,
		.farazsms-pattern-button.button:hover {
			background: #135e96 !important;
			background-color: #135e96 !important;
			border-color: #135e96 !important;
			border: 1px solid #135e96 !important;
			color: #fff !important;
		}
		button.farazsms-pattern-button:focus,
		.button.farazsms-pattern-button:focus,
		.farazsms-pattern-button.button:focus {
			box-shadow: 0 0 0 1px #fff, 0 0 0 3px #2271b1 !important;
		}
		/* استایل برای وضعیت پترن */
		.farazsms-status-active {
			color: #00a32a;
			font-weight: 600;
		}
		.farazsms-status-pending {
			color: #dba617;
			font-weight: 600;
		}
		.farazsms-status-inactive {
			color: #d63638;
			font-weight: 600;
		}
		.farazsms-status-unknown {
			color: #4d4d4d;
		}
		.farazsms-pattern-container {
			float: left;
			margin-top: 5px;
			clear: both;
		}
		th:has(.farazsms-pattern-container) {
			position: relative;
		}
		th .farazsms-pattern-container {
			width: 100%;
		}
	</style>
	<?php
}


/**
 * ───────────────────────────────────────────────────────────────────────────
 *  پیامکِ «مدیرِ محصول / فروشنده» (product_admin) — دکمه‌ی «ساخت پترن»
 * ───────────────────────────────────────────────────────────────────────────
 *  مسیرِ ارسالِ این بخش از قبل کامل بود (farazsms-core-functions.php → type=5،
 *  گیتویِ FarazSMSNext، و farazsms_patterns['product_admin'])؛ اما UIِ ساختِ پترن
 *  برای آن وجود نداشت، پس farazsms_patterns['product_admin'] هیچ‌وقت پُر نمی‌شد و
 *  پیامکِ فروشنده ارسال نمی‌شد. این بخش همان دکمه‌های بخشِ «مدیرِ کل» را برای
 *  بخشِ «مدیرِ محصول/فروشنده» هم اضافه می‌کند. (section_type = product_admin)
 *
 *  از تشخیصِ DOM (نه فقط هوکِ PWSMS) استفاده می‌کنیم تا اگر نامِ دقیقِ هوکِ
 *  بخشِ فروشنده در نسخه‌ی PWSMS فرق داشت هم دکمه‌ها تزریق شوند.
 */
add_action( 'pwoosms_settings_form_bottom_sms_product_admin_settings', 'farazsms_add_pattern_buttons_product_admin_inline', 10, 1 );
add_action( 'admin_footer', 'farazsms_add_pattern_buttons_product_admin_script' );

function farazsms_add_pattern_buttons_product_admin_inline( $form = null ) {
	farazsms_render_product_admin_pattern_script();
}

function farazsms_add_pattern_buttons_product_admin_script() {
	if ( ! function_exists( 'PWSMS' ) ) {
		return;
	}
	$screen = get_current_screen();
	if ( ! farazsms_is_pwsms_admin_settings_screen( $screen ) ) {
		return;
	}
	farazsms_render_product_admin_pattern_script();
}

/**
 * اسکریپتِ تزریقِ دکمه‌ی «ساخت پترن» در بخشِ مدیرِ محصول/فروشنده.
 * چندبار صدا زده شدنش بی‌خطر است (هر textarea فقط یک‌بار دکمه می‌گیرد).
 */
function farazsms_render_product_admin_pattern_script() {
	static $printed = false;
	if ( $printed ) {
		return;
	}
	$printed = true;

	$patterns      = get_option( 'farazsms_patterns', array() );
	$patterns_json = wp_json_encode( $patterns, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );
	$nonce_create  = wp_create_nonce( 'farazsms_create_pattern' );
	$nonce_details = wp_create_nonce( 'farazsms_get_pattern_details' );
	?>
	<script type="text/javascript">
	(function($){
		if (!$) { return; }
		var farazsmsPatterns = <?php echo $patterns_json; ?> || {};
		if (typeof window.farazsmsPwsmsModal !== "function") { window.farazsmsPwsmsModal = function(m){ window.alert(String(m)); }; }
		var SECTION = 'product_admin';

		function showInfo($container, statusKey){
			$container.find('.farazsms-pattern-info').remove();
			var code = (farazsmsPatterns && farazsmsPatterns[SECTION] && farazsmsPatterns[SECTION][statusKey]) ? farazsmsPatterns[SECTION][statusKey] : null;
			if (!code) { return; }
			var $info = $('<div class="farazsms-pattern-info" style="margin-top:10px;padding:10px;background:#f0f0f1;border-right:3px solid #2271b1;border-radius:3px;font-size:13px;"></div>');
			$info.html('<strong>کد پترن:</strong> <code style="background:#fff;padding:2px 5px;border-radius:2px;">'+code+'</code><br><span class="farazsms-pattern-status">در حال دریافت وضعیت...</span>');
			$container.append($info);
			$.ajax({ url: ajaxurl, type:'POST', data:{ action:'farazsms_get_pattern_details', pattern_code:code, section_type:SECTION, nonce:'<?php echo esc_js( $nonce_details ); ?>' },
				success:function(r){
					var $s = $info.find('.farazsms-pattern-status'), st = (r.success && r.data && r.data.data && r.data.data.status) ? r.data.data.status : '';
					var t, c;
					if (st==='active'||st==='approved'){ t='✅ تأیید شده و فعال'; c='farazsms-status-active'; }
					else if (st==='pending'||st==='waiting'){ t='⏳ در انتظار تأیید (۱ تا ۲۴ ساعت)'; c='farazsms-status-pending'; }
					else if (st==='inactive'||st==='rejected'){ t='❌ رد/غیرفعال'; c='farazsms-status-inactive'; }
					else if (st){ t=st; c='farazsms-status-unknown'; }
					else { $s.html('<strong>وضعیت:</strong> <span class="farazsms-status-unknown">خطا در دریافت اطلاعات</span>'); return; }
					$s.html('<strong>وضعیت:</strong> <span class="'+c+'">'+t+'</span>');
				},
				error:function(){ $info.find('.farazsms-pattern-status').html('<strong>وضعیت:</strong> <span class="farazsms-status-unknown">خطا در دریافت اطلاعات</span>'); }
			});
		}

		function inject(){
			var $textareas = $('textarea[name*="sms_product_admin_settings"]').filter(function(){
				return ($(this).attr('name')||'').indexOf('product_admin_sms_body_') !== -1;
			});
			if ($textareas.length === 0) {
				$textareas = $('#sms_product_admin_settings textarea').filter(function(){
					return ($(this).attr('name')||'').indexOf('product_admin_sms_body_') !== -1;
				});
			}
			$textareas.each(function(){
				var $ta = $(this), name = $ta.attr('name')||'';
				var $tr = $ta.closest('tr'); if (!$tr.length) { return; }
				if ($tr.find('.farazsms-pattern-button').length > 0) { return; }
				var m = name.match(/product_admin_sms_body_([^\]]+)/);
				var statusKey = (m && m[1]) ? m[1] : '';
				if (!statusKey) { return; }
				var $th = $tr.find('th'); if (!$th.length) { return; }

				var $container = $('<div class="farazsms-pattern-container" style="margin-top:5px;clear:both;"></div>');
				var pmHasPattern = !!(farazsmsPatterns && farazsmsPatterns[SECTION] && farazsmsPatterns[SECTION][statusKey]);
				var $btn = $('<button type="button" class="button farazsms-pattern-button">' + (pmHasPattern ? '✏️ ویرایشِ پترنِ فعلی' : 'ساخت پترن') + '</button>').css({
					'background':'#2271b1','background-color':'#2271b1','color':'#fff','border':'1px solid #2271b1',
					'font-weight':'600','padding':'4px 10px','margin-top':'10px','cursor':'pointer','width':'100%'
				});
				$btn.on('mouseenter', function(){ $(this).css({'background':'#135e96','background-color':'#135e96','border':'1px solid #135e96'}); })
					.on('mouseleave', function(){ $(this).css({'background':'#2271b1','background-color':'#2271b1','border':'1px solid #2271b1'}); });

				$btn.on('click', function(e){
					e.preventDefault(); e.stopPropagation();
					var val = $ta.val();
					if (!val || val.trim() === '') { farazsmsPwsmsModal('⚠️ متن پیامک خالی است. لطفا ابتدا متن را وارد کنید.'); return; }
					if (/pcode/i.test(val) || /patterncode/i.test(val)) {
						farazsmsPwsmsModal('⚠️ متنِ شما شاملِ «pcode» است — این شیوه مخصوصِ پنلِ قدیمی بوده و دیگر کار نمی‌کند.\n\nاینجا کدِ پترن ننویسید؛ فقط متنِ دلخواهِ پیامک را بنویسید و از متغیرهای ووکامرس استفاده کنید، سپس «ساخت پترن» را بزنید.');
						return;
					}
					var $b = $(this), orig = $b.text();
					$b.prop('disabled', true).text('در حال ساخت...');
					$.ajax({ url: ajaxurl, type:'POST', data:{ action:'farazsms_create_pattern', message_text:val, status_key:statusKey, section_type:SECTION, nonce:'<?php echo esc_js( $nonce_create ); ?>' },
						success:function(r){
							if (r.success && r.data && r.data.pattern_code) {
								if (!farazsmsPatterns[SECTION]) { farazsmsPatterns[SECTION] = {}; }
								farazsmsPatterns[SECTION][statusKey] = r.data.pattern_code;
								farazsmsPwsmsModal('✅ پترن با موفقیت ساخته شد!\n\nکد پترن: ' + r.data.pattern_code + '\n\nمنتظر تایید پترن باشید (۱ تا ۲۴ ساعت).');
								showInfo($container, statusKey);
							} else {
								var msg = (r.data && r.data.message) ? r.data.message : ((r.data && typeof r.data === 'string') ? r.data : 'خطای ناشناخته');
								farazsmsPwsmsModal('❌ خطا در ساخت پترن:\n\n' + msg);
							}
						},
						error:function(x,s,err){ farazsmsPwsmsModal('❌ خطا در ارسال درخواست:\n\n' + err + '\n\nلطفا دوباره تلاش کنید.'); },
						complete:function(){ $b.prop('disabled', false).text(orig); }
					});
				});

				$container.append($btn);
				var $pmNew = $('<button type="button" class="button">➕ ساخت پترنِ جدید</button>').css({ 'color':'#9b9b9b','font-size':'11.5px','padding':'3px 8px','margin-top':'6px','cursor':'pointer','width':'100%','background':'#f5f8fe','border':'1px solid #e1e1e1' });
				if (!pmHasPattern) { $pmNew.hide(); }
				$pmNew.on('click', function(e){
					e.preventDefault(); e.stopPropagation();
					var val = $ta.val();
					if (!val || val.trim() === '') { farazsmsPwsmsModal('⚠️ متن پیامک خالی است. لطفا ابتدا متن را وارد کنید.'); return; }
					if (/pcode/i.test(val) || /patterncode/i.test(val)) { farazsmsPwsmsModal('⚠️ متنِ شما شاملِ «pcode» است — فقط متنِ پیامک را با متغیرهای ووکامرس بسازید.'); return; }
					if (!confirm('یک پترنِ کاملاً جدید ساخته می‌شود و کدپترنِ فعلی جایگزین می‌گردد. مطمئنید؟')) { return; }
					var $b = $(this), orig = $b.text(); $b.prop('disabled', true).text('در حال ساختِ جدید...');
					$.ajax({ url: ajaxurl, type:'POST', data:{ action:'farazsms_create_pattern', message_text:val, status_key:statusKey, section_type:SECTION, mode:'new', nonce:'<?php echo esc_js( $nonce_create ); ?>' },
						success:function(r){ if (r.success && r.data && r.data.pattern_code) { if (!farazsmsPatterns[SECTION]) { farazsmsPatterns[SECTION] = {}; } farazsmsPatterns[SECTION][statusKey] = r.data.pattern_code; farazsmsPwsmsModal('✅ پترنِ جدید ساخته شد!\n\nکد پترن: ' + r.data.pattern_code + '\n\nتایید بین ۱ تا ۲۴ ساعت زمان‌بر است.'); showInfo($container, statusKey); } else { var msg = (r.data && r.data.message) ? r.data.message : 'خطای ناشناخته'; farazsmsPwsmsModal('❌ خطا در ساخت پترن:\n\n' + msg); } },
						error:function(x,s,err){ farazsmsPwsmsModal('❌ خطا در ارسال درخواست:\n\n' + err); },
						complete:function(){ $b.prop('disabled', false).text(orig); }
					});
				});
				$container.append($pmNew);
				$th.append($container);
				showInfo($container, statusKey);
			});
		}

		jQuery(function(){
			inject();
			[100,300,500,1000,2000].forEach(function(t){ setTimeout(inject, t); });
			$(window).on('load', function(){ setTimeout(inject, 200); setTimeout(inject, 700); });
			if (typeof MutationObserver !== 'undefined' && document.body) {
				var obs = new MutationObserver(function(muts){
					for (var i=0;i<muts.length;i++){ if (muts[i].addedNodes.length){ setTimeout(inject, 200); break; } }
				});
				obs.observe(document.body, { childList:true, subtree:true });
			}
			$(document).on('click', 'a[href*="tab=product_admin"]', function(){ setTimeout(inject, 400); setTimeout(inject, 1000); });
		});
	})(window.jQuery || window.$);
	</script>
	<?php
}
