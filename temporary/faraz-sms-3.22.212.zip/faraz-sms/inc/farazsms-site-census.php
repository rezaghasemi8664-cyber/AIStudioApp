<?php
/**
 * سرشماریِ محیطِ نصب — «کدام افزونه‌ها کنارِ فراز اس‌ام‌اس نصب‌اند؟»
 *
 * چرا: تصمیمِ «با کدام افزونه یکپارچه شویم» تا امروز روی عددِ *جهانیِ* وردپرس‌دات‌ارگ
 * گرفته می‌شد که برای بازارِ ایران گمراه‌کننده است (نمونه: بوکنتیک جهانی محترم است و در
 * ایران تقریباً مرده). این ماژول همان داده را از واقعیتِ نصب‌های خودمان می‌گیرد.
 *
 * کجا دیده می‌شود: در همان مَتومویی که از قبل داریم —
 *
 * Behaviour → Events
 *
 * چون شناسه‌ی بازدیدکننده از دامنه ساخته می‌شود، «بازدیدکننده‌ی یکتا»ی مَتومو دقیقاً
 * یعنی «تعدادِ سایت‌هایی که آن افزونه را دارند». پس هیچ بک‌اند و هیچ رابطِ کاربریِ
 * جدیدی لازم نیست.
 *
 * ⚠️ کارایی — قانونِ سختِ پروژه: هیچ‌چیز نباید رندرِ سایت را کند کند. این ماژول
 * هرگز روی مسیرِ فرانت‌اند اجرا نمی‌شود. دو مسیرِ اجرا دارد و هر دو غیرمسدودند:
 *   ۱) کرانِ هفتگی (خودش پس‌زمینه است)
 *   ۲) جبرانِ بازدیدِ ادمین، فقط وقتی کران عقب افتاده — روی shutdown و پس از
 *      صفِ مشترک، یعنی بیرون از درخواستی که کاربر منتظرش است.
 * درخواستِ HTTP هم blocking=false است. باگِ کندیِ v3.20.56 دقیقاً از نقضِ همین
 * قاعده آمد — تکرارش نکنید.
 *
 * حریمِ خصوصی: داده شناسایی‌پذیر است (آدرسِ سایت فرستاده می‌شود). هرگز دادهٔ
 * مشتریِ فروشگاه — شماره، ایمیل، سفارش — فرستاده نمی‌شود. مدیرِ سایت در تنظیمات
 * دقیقاً می‌بیند چه می‌رود و می‌تواند خاموش کند.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_CENSUS_CRON     = 'farazsms_census_send';
const FARAZSMS_CENSUS_SCHEDULE = 'farazsms_census_weekly';
const FARAZSMS_CENSUS_LAST_OPT = 'farazsms_census_last_run';
const FARAZSMS_CENSUS_OPTOUT   = 'farazsms_census_optout';
const FARAZSMS_CENSUS_SITE_OPT = 'farazsms_census_site_id';

/** سقفِ رویداد در هر ارسال — سایتی با صدها افزونه نباید بدنه‌ی غول بسازد. */
const FARAZSMS_CENSUS_MAX_EVENTS = 150;

/**
 * شناسه‌ی Siteِ **اختصاصیِ سرشماری** در ماتومو.
 *
 * عمداً از Siteِ آمارِ بازدیدِ فروشگاه‌ها جداست: سرشماری هفته‌ای هزاران
 * «بازدیدکننده»ی ساختگی می‌سازد و اگر در همان پراپرتی بنشیند، آمارِ واقعی را
 * بی‌فایده می‌کند. تا وقتی این شناسه تنظیم نشده، سرشماری **ارسال نمی‌کند** —
 * آلوده‌کردنِ داده‌ی واقعی بدتر از نداشتنِ داده است.
 *
 * @return string
 */
function farazsms_census_site_id() {
	$id = '';
	if ( defined( 'FARAZSMS_CENSUS_MATOMO_SITE_ID' ) && FARAZSMS_CENSUS_MATOMO_SITE_ID ) {
		$id = FARAZSMS_CENSUS_MATOMO_SITE_ID;
	} else {
		$id = (string) get_option( FARAZSMS_CENSUS_SITE_OPT, '' );
	}
	return trim( (string) apply_filters( 'farazsms_census_site_id', $id ) );
}

/**
 * فعال است؟
 *
 * دو کلید پشتِ سر هم: کلیدِ عمومیِ آمار (اگر مدیر کلِ آمار را خاموش کرده، احترام
 * می‌گذاریم) و کلیدِ اختصاصیِ خودِ سرشماری.
 *
 * @return bool
 */
function farazsms_census_is_enabled() {
	if ( defined( 'FARAZSMS_CENSUS_FORCE_OFF' ) && FARAZSMS_CENSUS_FORCE_OFF ) {
		return false;
	}
	if ( get_option( FARAZSMS_CENSUS_OPTOUT, '0' ) === '1' ) {
		return false;
	}
	if ( ! function_exists( 'farazsms_matomo_is_enabled' ) ) {
		return false;
	}
	if ( farazsms_census_site_id() === '' ) {
		return false; // بدونِ Siteِ اختصاصی چیزی نمی‌فرستیم.
	}
	return farazsms_matomo_is_enabled();
}

// ============================================================================
// جمع‌آوریِ داده
// ============================================================================

/**
 * اسلاگِ افزونه از مسیرِ آن ('bookly-responsive-.../main.php' → 'bookly-responsive-...').
 *
 * @param string $plugin_file
 * @return string
 */
function farazsms_census_slug( $plugin_file ) {
	$plugin_file = (string) $plugin_file;
	$parts       = explode( '/', $plugin_file );
	// افزونه‌های تک‌فایلی پوشه ندارند؛ آن‌وقت خودِ نامِ فایل بدونِ پسوند اسلاگ است.
	return count( $parts ) > 1 ? $parts[0] : preg_replace( '/\.php$/i', '', $plugin_file );
}

/**
 * کلِ بارِ سرشماری. همین آرایه عیناً در کارتِ تنظیمات به مدیرِ سایت نشان داده
 * می‌شود — یعنی «آنچه می‌بیند» دقیقاً «آنچه می‌رود» است، نه توصیفی از آن.
 *
 * @return array
 */
function farazsms_census_collect() {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	$all    = get_plugins();
	$active = (array) get_option( 'active_plugins', array() );

	// در مالتی‌سایت، افزونه‌های شبکه‌ای در آپشنِ سایت نیستند.
	if ( is_multisite() ) {
		$network = (array) get_site_option( 'active_sitewide_plugins', array() );
		$active  = array_merge( $active, array_keys( $network ) );
	}

	$plugins = array();
	foreach ( array_unique( $active ) as $file ) {
		$data      = isset( $all[ $file ] ) ? $all[ $file ] : array();
		$plugins[] = array(
			'slug'    => farazsms_census_slug( $file ),
			'name'    => isset( $data['Name'] ) ? (string) $data['Name'] : '',
			'version' => isset( $data['Version'] ) ? (string) $data['Version'] : '',
		);
	}

	$theme = wp_get_theme();

	$payload = array(
		'site_url'  => home_url(),
		'domain'    => (string) wp_parse_url( home_url(), PHP_URL_HOST ),
		'wp'        => get_bloginfo( 'version' ),
		'php'       => PHP_VERSION,
		'locale'    => get_locale(),
		'multisite' => is_multisite() ? '1' : '0',
		'theme'     => $theme instanceof WP_Theme ? $theme->get( 'Name' ) . ' ' . $theme->get( 'Version' ) : '',
		'wc'        => defined( 'WC_VERSION' ) ? WC_VERSION : '',
		'farazsms'  => defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '',
		'plugins'   => $plugins,
	);

	return (array) apply_filters( 'farazsms_census_payload', $payload );
}

// ============================================================================
// تبدیل به رویدادهای مَتومو
// ============================================================================

/**
 * شناسه‌ی بازدیدکننده‌ی مَتومو = ۱۶ رقمِ hex از دامنه.
 *
 * این همان ترفندی است که شمارش را رایگان می‌کند: هر سایت یک «بازدیدکننده»ی
 * پایدار است، پس متریکِ «بازدیدکنندگانِ یکتا»ی خودِ مَتومو می‌شود «تعدادِ سایت‌ها».
 *
 * @param string $domain
 * @return string
 */
function farazsms_census_visitor_id( $domain ) {
	// در مالتی‌سایتِ زیرشاخه‌ای همه‌ی زیرسایت‌ها یک دامنه دارند؛ اگر شناسه فقط از
	// دامنه ساخته شود، همه یک «بازدیدکننده» می‌شوند و شمارشِ سایت‌ها غلط از آب
	// درمی‌آید. پس آدرسِ کاملِ خانه مبنا قرار می‌گیرد.
	return substr( md5( (string) home_url( '/' ) . '|' . (string) $domain ), 0, 16 );
}

/**
 * ساختِ آرایه‌ی درخواست‌های bulk مَتومو از بارِ سرشماری.
 *
 * @param array $payload
 * @return array فهرستی از query-stringها (هرکدام با '?' شروع می‌شود)
 */
function farazsms_census_build_requests( $payload ) {
	$site_id = farazsms_census_site_id();
	if ( $site_id === '' ) {
		return array();
	}

	// بارِ سرشماری از فیلترِ farazsms_census_payload می‌گذرد، پس نمی‌توان فرض کرد
	// کلیدها دست‌نخورده مانده‌اند — همه‌جا با isset خوانده می‌شود.
	$domain = isset( $payload['domain'] ) ? (string) $payload['domain'] : '';
	if ( $domain === '' ) {
		return array();
	}

	$base = array(
		'idsite'      => $site_id,
		'rec'         => '1',
		'apiv'        => '1',
		'_id'         => farazsms_census_visitor_id( $domain ),
		'url'         => isset( $payload['site_url'] ) ? (string) $payload['site_url'] : '',
		'lang'        => isset( $payload['locale'] ) ? (string) $payload['locale'] : '',
		// نامِ کنش = دامنه، تا در گزارش‌های مَتومو سایت مستقیم خوانده شود.
		'action_name' => $domain,
	);

	$events = array();

	foreach ( array( 'wp', 'php', 'wc', 'farazsms', 'theme', 'locale', 'multisite' ) as $key ) {
		if ( ! isset( $payload[ $key ] ) || (string) $payload[ $key ] === '' ) {
			continue;
		}
		$events[] = array( 'census-env', $key, (string) $payload[ $key ] );
	}

	$plugins = isset( $payload['plugins'] ) && is_array( $payload['plugins'] ) ? $payload['plugins'] : array();
	foreach ( $plugins as $plugin ) {
		if ( ! is_array( $plugin ) || empty( $plugin['slug'] ) ) {
			continue;
		}
		// e_a = اسلاگ (همان چیزی که در گزارش گروه می‌شود)، e_n = نسخه.
		$events[] = array( 'census-plugin', $plugin['slug'], (string) $plugin['version'] );
	}

	$requests = array();
	foreach ( $events as $event ) {
		$requests[] = '?' . http_build_query(
			$base + array(
				'e_c' => $event[0],
				'e_a' => $event[1],
				'e_n' => $event[2],
			)
		);
	}

	return array_slice( $requests, 0, FARAZSMS_CENSUS_MAX_EVENTS );
}

// ============================================================================
// ارسال — همیشه غیرمسدود
// ============================================================================

/**
 * ارسالِ سرشماری. یک درخواستِ POSTِ bulk، غیرمسدود.
 *
 * blocking=false یعنی پاسخ خوانده نمی‌شود، پس «قطع‌کننده‌ی مدارِ مبتنی بر پاسخ»
 * اینجا بی‌معناست و عمداً نداریم؛ محافظِ واقعی این است که این تابع هرگز روی مسیرِ
 * رندر صدا زده نمی‌شود.
 *
 * @return bool آیا درخواست فرستاده شد
 */
function farazsms_census_send() {
	if ( ! farazsms_census_is_enabled() ) {
		return false;
	}
	if ( ! function_exists( 'farazsms_matomo_tracker_endpoint' ) ) {
		return false;
	}

	try {
		$payload  = farazsms_census_collect();
		$requests = farazsms_census_build_requests( $payload );
	} catch ( \Throwable $e ) {
		return false;
	}

	if ( empty( $requests ) ) {
		return false;
	}

	// زمانِ اجرا را *قبل از* ارسال ثبت می‌کنیم: اگر ارسال شکست بخورد، هفته‌ی بعد
	// دوباره تلاش می‌شود — ولی یک درخواستِ ناموفق نباید باعثِ تلاشِ مکرر در هر
	// بازدیدِ ادمین شود.
	update_option( FARAZSMS_CENSUS_LAST_OPT, time(), false );

	wp_remote_post(
		farazsms_census_endpoint(),
		array(
			'blocking'  => false,
			'timeout'   => 3,
			'headers'   => array( 'Content-Type' => 'application/json' ),
			'body'      => wp_json_encode( array( 'requests' => $requests ) ),
			'sslverify' => true,
		)
	);

	return true;
}

/**
 * نقطه‌ی دریافتِ bulk مَتومو.
 *
 * @return string
 */
function farazsms_census_endpoint() {
	return farazsms_matomo_tracker_endpoint();
}

// ============================================================================
// زمان‌بندی — کرانِ هفتگی
// ============================================================================

add_filter( 'cron_schedules', 'farazsms_census_cron_schedules' );
/**
 * زمان‌بندیِ اختصاصی، تا به وجود/نبودِ 'weekly'ِ هسته در نسخه‌های مختلفِ وردپرس
 * وابسته نباشیم.
 *
 * @param array $schedules
 * @return array
 */
function farazsms_census_cron_schedules( $schedules ) {
	if ( ! is_array( $schedules ) ) {
		$schedules = array();
	}
	$schedules[ FARAZSMS_CENSUS_SCHEDULE ] = array(
		'interval' => WEEK_IN_SECONDS,
		'display'  => 'هفتگی (سرشماریِ فراز اس‌ام‌اس)',
	);
	return $schedules;
}

add_action( 'init', 'farazsms_census_maybe_schedule' );
function farazsms_census_maybe_schedule() {
	// زمان‌بندی کارِ فرانت‌اند نیست. بدونِ این گارد، هر بازدیدِ صفحه‌ی فروشگاه دو
	// آپشنِ غیرِ autoload می‌خواند — یعنی دو کوئریِ اضافه روی هاستِ بدونِ آبجکت‌کش.
	if ( ! is_admin() && ! wp_doing_cron() ) {
		return;
	}
	if ( ! farazsms_census_is_enabled() ) {
		// خاموش شده؟ زمان‌بندی را هم برمی‌داریم تا کرانِ بی‌مصرف باقی نماند.
		$ts = wp_next_scheduled( FARAZSMS_CENSUS_CRON );
		if ( $ts ) {
			wp_unschedule_event( $ts, FARAZSMS_CENSUS_CRON );
		}
		return;
	}
	if ( ! wp_next_scheduled( FARAZSMS_CENSUS_CRON ) ) {
		// تأخیرِ اولیه‌ی تصادفی تا ۶ ساعت، تا ۱۰هزار سایت هم‌زمان به سرورِ آمار نزنند.
		wp_schedule_event( time() + wp_rand( 300, 6 * HOUR_IN_SECONDS ), FARAZSMS_CENSUS_SCHEDULE, FARAZSMS_CENSUS_CRON );
	}
}

add_action( FARAZSMS_CENSUS_CRON, 'farazsms_census_send' );

register_deactivation_hook(
	defined( 'FARAZSMS_PLUGIN_FILE' ) ? FARAZSMS_PLUGIN_FILE : __FILE__,
	'farazsms_census_clear_cron'
);
/**
 * با غیرفعال‌شدنِ افزونه، رویدادِ کران هم برداشته می‌شود تا ردیفِ یتیم در آپشنِ
 * cron باقی نماند. (آپشن‌های خودِ ماژول با الگوی farazsms_* در uninstall پاک می‌شوند.)
 */
function farazsms_census_clear_cron() {
	$ts = wp_next_scheduled( FARAZSMS_CENSUS_CRON );
	if ( $ts ) {
		wp_unschedule_event( $ts, FARAZSMS_CENSUS_CRON );
	}
}

// ============================================================================
// جبرانِ کرانِ لنگ — همان الگوی v3.22.139 (سبد رهاشده)
// ============================================================================

add_action( 'admin_init', 'farazsms_census_maybe_catchup' );
/**
 * روی هاست‌هایی که wp-cron خاموش/لنگ است، سرشماری هرگز اجرا نمی‌شد و آن سایت‌ها
 * از آمار حذف می‌شدند — یعنی خودِ داده سوگیری پیدا می‌کرد. اینجا فقط وقتی بیش از
 * ۸ روز گذشته باشد، ارسال را به بعد از بسته‌شدنِ پاسخ موکول می‌کنیم.
 */
function farazsms_census_maybe_catchup() {
	if ( ! farazsms_census_is_enabled() ) {
		return;
	}
	if ( wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}
	if ( get_transient( 'farazsms_census_catchup_lock' ) ) {
		return; // اخیراً صف شده — دوباره نه.
	}
	$last = (int) get_option( FARAZSMS_CENSUS_LAST_OPT, 0 );
	if ( $last > 0 && ( time() - $last ) < ( 8 * DAY_IN_SECONDS ) ) {
		return;
	}
	// v3.22.202: نردبانِ تعویقِ خصوصی حذف شد و کار به صفِ مشترک رفت.
	// آن نردبان روی mod_php تضمینی نداشت (پاسخ بسته نمی‌شد) و نه ذخیره‌ی
	// باقی‌مانده داشت، نه اجراکننده، نه کچ‌آپ.
	//
	// ⚠️ قفل را تولیدکننده می‌گذارد: مهرِ «آخرین ارسال» را کارگر می‌نویسد، و
	// تا اجرا نشود شرطِ بالا باز است — یعنی هر بازدیدِ پیشخوان یک ردیفِ دیگر.
	// ⚠️ نتیجه‌ی نوشتن گیت نمی‌شود: اگر کشِ سایت پر باشد و نوشتن شکست بخورد،
	// گیت‌کردن یعنی این قابلیت برای همیشه خاموش می‌ماند. شکستِ debounce
	// حداکثر یک ردیفِ تکراری هزینه دارد؛ شکستِ قابلیت خیلی گران‌تر است.
	set_transient( 'farazsms_census_catchup_lock', 1, HOUR_IN_SECONDS );
	farazsms_queue_task( 'census', 'farazsms_census_send' );
}


// ============================================================================
// کارتِ تنظیمات — افشای صریحِ آنچه فرستاده می‌شود
// ============================================================================

add_action( 'farazsms_analytics_card_fields', 'farazsms_census_render_field' );
/**
 * سرشماری عمداً کارتِ جداگانه ندارد: یک گزینه‌ی آماری است و جایش داخلِ همان
 * کارتِ «آمار و حریم خصوصی» است، با همان یک دکمه‌ی ذخیره.
 */
function farazsms_census_render_field() {
	// ⚠️ تا وقتی شناسه‌ی Siteِ سرشماری پیکربندی نشده، این ماژول اصلاً چیزی نمی‌فرستد.
	// پس نه گزینه‌اش را نشان می‌دهیم (فیلدِ بی‌معنا برای مدیرِ فروشگاه) و نه ادعایی
	// می‌کنیم که واقعیت ندارد. با bakeشدنِ ثابت، خودکار ظاهر می‌شود.
	if ( farazsms_census_site_id() === '' ) {
		return;
	}
	$optout = get_option( FARAZSMS_CENSUS_OPTOUT, '0' ) === '1';
	?>
	<?php // نشانگرِ حضور: بدونِ آن، «تیک نخورده» از «اصلاً رندر نشده» قابلِ تفکیک نیست. ?>
	<input type="hidden" name="farazsms_census_present" value="1">
	<p style="margin:10px 0 0">
		<label style="display:inline-flex;align-items:center;gap:10px;font-weight:600;font-size:14px">
			<input type="checkbox" name="farazsms_census_enable" value="1" <?php checked( ! $optout ); ?>>
			ارسالِ فهرستِ افزونه‌های نصب‌شده (برای بهبودِ سازگاری‌ها)
		</label>
	</p>
	<?php
}

add_action( 'admin_init', 'farazsms_census_handle_save' );
/**
 * با نانسِ همان کارتِ آمار ذخیره می‌شود — یک فرم، یک دکمه.
 */
function farazsms_census_handle_save() {
	if ( ! isset( $_POST['farazsms_matomo_nonce'] ) ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['farazsms_matomo_nonce'] ) ), 'farazsms_matomo_save' ) ) {
		return;
	}
	// ⚠️ اگر فیلدِ ما در آن فرم نبوده، «تیک نخورده» نیست — یعنی اصلاً پرسیده نشده.
	// بدونِ این بررسی، ذخیره‌ی فرمِ آمار می‌توانست سرشماری را بی‌صدا خاموش کند.
	if ( ! isset( $_POST['farazsms_census_present'] ) ) {
		return;
	}
	update_option( FARAZSMS_CENSUS_OPTOUT, isset( $_POST['farazsms_census_enable'] ) ? '0' : '1', false );
}
