<?php
/**
 * Unified Dashboard Frame — Phase 7 (v3.13.0)
 *
 * این فایل یک قالب یکپارچه (شبیه تنظیمات قالب وودمارت) برای کل صفحات افزونه فراز اس‌ام‌اس
 * فراهم می‌کند. تمام صفحات افزونه درون یک Frame مشترک رندر می‌شوند که شامل:
 *
 *   - نوار بالا (Topbar): لوگو، اعتبار، نسخه، لینک ورود به پنل
 *   - ناوبری کنار صفحه (داخلی): گروه‌های فیچر + دسترسی سریع به همه قابلیت‌ها
 *   - بدنه: محتوای صفحه فعلی
 *
 * صفحه جدید «داشبورد» با اسلاگ
 *
 *   farazsms-dashboard
 *
 * هم به‌عنوان hub اصلی اضافه می‌شود و در ابتدای منو قرار می‌گیرد. در ناوبری داخلی Frame
 * هم اولین آیتم همین صفحه است.
 *
 * Hook ها:
 *
 *   all_admin_notices   priority 99999  →  باز کردن Frame
 *   in_admin_footer     priority 0      →  بستن Frame
 *
 * طراحی RTL-aware. سی‌اس‌اس inline اما scoped زیر کلاس
 *
 *   .farazsms-app-frame
 *
 * هیچ leak به سایر افزونه‌ها/قالب پیشخوان نخواهد داشت.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/* ------------------------------------------------------------------------- *
 *  Helpers
 * ------------------------------------------------------------------------- */

/**
 * تشخیص اینکه صفحه فعلی، صفحه‌ای از افزونه است.
 * بر اساس
 *
 *   $_GET['page']
 *
 * یا
 *
 *   $screen->id
 *
 * تصمیم می‌گیرد.
 */
function farazsms_is_plugin_page() {
	$plugin_pages = farazsms_dashboard_known_slugs();
	if ( isset( $_GET['page'] ) ) {
		$page = sanitize_key( wp_unslash( $_GET['page'] ) );
		if ( in_array( $page, $plugin_pages, true ) ) {
			return true;
		}
	}
	if ( function_exists( 'get_current_screen' ) ) {
		$screen = get_current_screen();
		if ( $screen && isset( $screen->id ) && strpos( (string) $screen->id, 'farazsms' ) !== false ) {
			return true;
		}
	}
	return false;
}

/**
 * آیا این صفحه باید در «قابِ اپ» (frame) پیچیده شود؟
 *
 * v3.22.83: بعضی صفحاتِ یکپارچگی، فرمِ بلندِ قدیمی هستند (مثلِ صفحه‌ی تنظیماتِ المنتورِ فراز) که در
 * قابِ اپ با overflow:hidden کلیپ می‌شوند و اسکرول نمی‌خورند (کاربر مجبور می‌شد zoom-out کند). این
 * صفحات را در حالتِ عادیِ ادمین (اسکرولِ نیتیو) رها می‌کنیم؛ سرکوبِ نوتیس همچنان اعمال می‌شود.
 *
 * @return bool
 */
function farazsms_page_uses_frame() {
	// تصمیم یک‌بار در هر ریکوئست محاسبه و cache می‌شود تا open (all_admin_notices) و close
	// (in_admin_footer) حتماً به یک نتیجه برسند و بافرِ خروجی نامتوازن نشود — حتی اگر فیلترِ
	// farazsms_frameless_pages بینِ این دو غیرقطعی باشد.
	static $decision = null;
	if ( $decision !== null ) {
		return $decision;
	}
	$decision = true;
	if ( ! farazsms_is_plugin_page() ) {
		$decision = false;
		return $decision;
	}
	$raw_pages = apply_filters( 'farazsms_frameless_pages', array( 'elementor_farazsms' ) );
	if ( isset( $_GET['page'] ) && in_array( sanitize_key( wp_unslash( $_GET['page'] ) ), (array) $raw_pages, true ) ) {
		$decision = false;
	}
	return $decision;
}

/**
 * لیست همه slugهای شناخته‌شده افزونه (برای بررسی + ناوبری داخلی).
 */
function farazsms_dashboard_known_slugs() {
	// v3.20.90: منبعِ حقیقتِ واحد — slugها از farazsms_dashboard_nav_groups() مشتق می‌شوند
	// تا دیگر این فهرست و nav_groups از هم desync نشوند (افزودنِ یک قابلیت فقط در
	// nav_groups کافی است). فهرستِ پایه به‌عنوانِ کفِ اطمینان نگه داشته می‌شود تا
	// اگر nav_groups بر اساسِ نبودِ WooCommerce فیلتر شد، صفحاتِ اصلی frame بگیرند.
	$slugs = array();
	foreach ( farazsms_dashboard_nav_groups() as $group ) {
		if ( empty( $group['items'] ) || ! is_array( $group['items'] ) ) {
			continue;
		}
		foreach ( $group['items'] as $item ) {
			if ( ! empty( $item['slug'] ) ) {
				$slugs[ $item['slug'] ] = true;
			}
		}
	}
	// کفِ اطمینان: صفحاتِ همیشه‌موجود (مستقل از WooCommerce).
	$base = array(
		'farazsms-dashboard', 'farazsms-settings', 'farazsms-send-sms',
		'farazsms-reports', 'farazsms-login-register', 'farazsms-cashback',
		'farazsms-segments', 'farazsms-spin',
	);
	foreach ( $base as $s ) {
		$slugs[ $s ] = true;
	}
	return array_keys( $slugs );
}

/**
 * ساختار گروه‌های ناوبری داخلی Frame — هم برای sidebar داخل صفحه و هم برای hub.
 * هر آیتم: slug، عنوان، آیکن dashicons، توضیح کوتاه.
 */
function farazsms_dashboard_nav_groups() {
	// v3.22.167: مسیرِ دومِ ناوبری حذف شد. تا پیش از این دو فهرستِ موازی وجود
	// داشت (این تابع و _raw) که فقط یکی‌شان زنده بود؛ همین باعث شد سه بار
	// صفحه‌ای ثبت شود و هیچ‌جا دیده نشود. حالا یک منبع بیشتر نیست.
	//
	// افزودنِ صفحه‌ی تازه: فیلترِ farazsms_nav_extra (نه ویرایشِ فهرست).
	return farazsms_dashboard_nav_groups_v2();
}

/**
 * URL هر slug پلاگین. برای پنل فراز چون مقصد خارجی است، URL خاص می‌گذاریم
 * تا کاربر مستقیم منتقل شود.
 */
function farazsms_dashboard_item_url( $slug ) {
	return admin_url( 'admin.php?page=' . $slug );
}

/**
 * پیدا کردن گروه و آیتم فعال بر اساس slug فعلی.
 *
 * @return array{0:string,1:?array}  [group_key, item_array_or_null]
 */
function farazsms_dashboard_current_item() {
	$current = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	foreach ( farazsms_dashboard_nav_groups() as $gkey => $group ) {
		foreach ( $group['items'] as $item ) {
			if ( $item['slug'] === $current ) {
				return array( $gkey, $item );
			}
		}
	}
	return array( '', null );
}

/* ------------------------------------------------------------------------- *
 *  Register hub submenu
 * ------------------------------------------------------------------------- */

add_action( 'admin_menu', 'farazsms_dashboard_register_hub', 20 );
function farazsms_dashboard_register_hub() {
	add_submenu_page(
		'farazsms',
		__( 'داشبورد فراز اس‌ام‌اس', 'farazsms' ),
		__( 'داشبورد', 'farazsms' ),
		'manage_options',
		'farazsms-dashboard',
		'farazsms_dashboard_hub_render'
	);
}

/* ------------------------------------------------------------------------- *
 *  Frame: open + close hooks
 * ------------------------------------------------------------------------- */

/**
 * نکته فنی مهم درباره Lifecycle Frame:
 *
 *   - باز کردن frame داخل `all_admin_notices` (در `#wpbody-content`) انجام می‌شود.
 *   - بستن frame باید قبل از بسته شدن `#wpbody-content` رخ دهد، اما هیچ action رسمی WP
 *     بین callback صفحه و `</div><!-- wpbody-content -->` وجود ندارد.
 *   - راه‌حل: بعد از باز کردن frame یک `ob_start()` می‌گذاریم تا کل خروجی بعدی buffer شود.
 *     سپس در `in_admin_footer` priority 0، buffer را گرفته، تگ بستن frame را دقیقاً
 *     قبل از marker `</div><!-- wpbody-content -->` تزریق می‌کنیم و echo می‌کنیم.
 *   - این کار باعث می‌شود ساختار DOM معتبر بماند:
 *
 *       #wpbody-content
 *         .farazsms-app-frame
 *           .farazsms-app-content__inner [page content]
 *         /.farazsms-app-frame
 *       /#wpbody-content
 */
/**
 * v3.22.65: نوتیس‌های افزونه‌ها/قالب‌های دیگر داخلِ فریمِ ما شلوغی می‌کنند و غیرحرفه‌ای
 * دیده می‌شوند. فقط روی صفحاتِ خودِ فراز، نوتیس‌های «غیرِ فراز» را حذف می‌کنیم؛ نوتیس‌های
 * خودِ افزونه (فریم، خوش‌آمد، …) دست‌نخورده می‌مانند. با فیلتر قابلِ خاموش‌کردن است.
 */
add_action( 'in_admin_header', 'farazsms_suppress_foreign_admin_notices', 1 );
function farazsms_suppress_foreign_admin_notices() {
	if ( ! farazsms_is_plugin_page() ) {
		return;
	}
	if ( ! apply_filters( 'farazsms_suppress_foreign_notices', true ) ) {
		return;
	}
	global $wp_filter;
	foreach ( array( 'admin_notices', 'all_admin_notices', 'user_admin_notices' ) as $hook ) {
		if ( empty( $wp_filter[ $hook ] ) || empty( $wp_filter[ $hook ]->callbacks ) ) {
			continue;
		}
		// ⚠️ v3.22.83: قبلاً مستقیم $wp_filter[$hook]->callbacks را unset می‌کردیم — این کار وضعیتِ
		// داخلیِ WP_Hook (آرایه‌ی iterations) را با callbacks ناهماهنگ می‌کرد و هنگامِ اجرای بعدیِ
		// همان هوک، «Undefined offset: <priority>» + «Invalid argument for foreach()» در
		// wp-includes/class-wp-hook.php می‌داد. راهِ درست: اول جمع‌آوری، بعد حذف با API رسمیِ
		// remove_action که خودش iterations/current_priority را درست نگه می‌دارد.
		$to_remove = array();
		foreach ( $wp_filter[ $hook ]->callbacks as $prio => $cbs ) {
			if ( ! is_array( $cbs ) ) {
				continue;
			}
			foreach ( $cbs as $id => $cb ) {
				$fn = isset( $cb['function'] ) ? $cb['function'] : null;
				if ( farazsms_notice_callback_should_keep( $fn ) ) {
					continue; // نوتیس‌های خودِ فراز + ووکامرس/هسته + closureها بمانند.
				}
				$to_remove[] = array( $fn, (int) $prio );
			}
		}
		foreach ( $to_remove as $r ) {
			remove_action( $hook, $r[0], $r[1] );
		}
	}
}

/**
 * آیا این نوتیس باید نگه داشته شود؟
 * نگه‌داشتن: نوتیس‌های خودِ فراز (farazsms/wto_)، نوتیس‌های حیاتیِ ووکامرس/هسته (آپدیتِ
 * دیتابیس، nag)، و closure/callableِ ناشناخته (محافظه‌کارانه، تا نوتیسِ خودمان بلعیده نشود).
 * حذف: صرفاً تبلیغات/توصیه‌های نامیِ افزونه‌های ثالث.
 *
 * @param mixed $fn
 * @return bool
 */
function farazsms_notice_callback_should_keep( $fn ) {
	// closure → مطمئن نیستیم؛ محافظه‌کارانه نگه‌دار (نوتیسِ آمارِ خودِ ما closure است).
	if ( $fn instanceof Closure ) {
		return true;
	}
	if ( is_string( $fn ) ) {
		$s = strtolower( $fn );
		return ( strpos( $s, 'farazsms' ) !== false || strpos( $s, 'wto_' ) !== false
			|| strpos( $s, 'woocommerce' ) !== false || strpos( $s, 'wc_' ) !== false
			|| strpos( $s, 'update_nag' ) !== false || strpos( $s, 'maintenance_nag' ) !== false );
	}
	if ( is_array( $fn ) && isset( $fn[0] ) ) {
		$cls = strtolower( is_object( $fn[0] ) ? get_class( $fn[0] ) : (string) $fn[0] );
		return ( strpos( $cls, 'farazsms' ) !== false || strpos( $cls, 'wto_' ) !== false
			|| strpos( $cls, 'woocommerce' ) !== false || strpos( $cls, 'wc_' ) !== false );
	}
	// callableِ ناشناخته (invokable object و …) → محافظه‌کارانه نگه‌دار.
	return true;
}

add_action( 'all_admin_notices', 'farazsms_unified_frame_open', 99999 );
function farazsms_unified_frame_open() {
	if ( ! farazsms_page_uses_frame() ) {
		return;
	}
	farazsms_unified_frame_inline_css();
	$apikey = farazsms_get_apikey();
	$credit = '';
	if ( ! empty( $apikey ) ) {
		$credit_raw = farazsms_get_credit();
		if ( $credit_raw !== false && $credit_raw !== '' ) {
			$credit = (string) $credit_raw;
		}
	}
	$version = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '';
	$portal_url = farazsms_get_farazsms_portal_url();
	list( $current_gkey, $current_item ) = farazsms_dashboard_current_item();
	?>
	<div class="farazsms-app-frame" dir="rtl">
		<header class="farazsms-app-topbar">
			<div class="farazsms-app-topbar__brand">
				<a href="<?php echo esc_url( farazsms_dashboard_item_url( 'farazsms-dashboard' ) ); ?>" class="farazsms-app-topbar__logo">
					<img src="<?php echo esc_url( FARAZSMS_CORE_IMG . 'logo-1.png' ); ?>" alt="فراز اس‌ام‌اس">
				</a>
				<?php if ( $version ) : ?>
					<span class="farazsms-app-topbar__version">v<?php echo esc_html( $version ); ?></span>
				<?php endif; ?>
			</div>
			<div class="farazsms-app-topbar__meta">
				<?php if ( $credit !== '' ) : ?>
					<a href="<?php echo esc_url( farazsms_dashboard_item_url( 'farazsms-settings' ) ); ?>" class="farazsms-app-topbar__credit" title="<?php esc_attr_e( 'مشاهده تنظیمات اعتبار', 'farazsms' ); ?>">
						<span class="dashicons dashicons-money-alt"></span>
						<span class="farazsms-app-topbar__credit-label"><?php esc_html_e( 'اعتبار:', 'farazsms' ); ?></span>
						<strong><?php echo esc_html( $credit ); ?></strong>
						<span class="farazsms-app-topbar__credit-unit"><?php esc_html_e( 'تومان', 'farazsms' ); ?></span>
					</a>
				<?php else : ?>
					<a href="<?php echo esc_url( farazsms_dashboard_item_url( 'farazsms-settings' ) ); ?>" class="farazsms-app-topbar__credit farazsms-app-topbar__credit--empty">
						<span class="dashicons dashicons-warning"></span>
						<?php esc_html_e( 'Api-Key وارد نشده', 'farazsms' ); ?>
					</a>
				<?php endif; ?>
				<a href="<?php echo esc_url( $portal_url ); ?>" target="_blank" rel="noopener" class="farazsms-app-topbar__button farazsms-app-topbar__button--ghost">
					<span class="dashicons dashicons-external"></span>
					<?php esc_html_e( 'پنل فراز اس‌ام‌اس', 'farazsms' ); ?>
				</a>
				<a href="https://farazsms.com/" target="_blank" rel="noopener" class="farazsms-app-topbar__button farazsms-app-topbar__button--ghost farazsms-app-topbar__button--icon" title="<?php esc_attr_e( 'سایت رسمی', 'farazsms' ); ?>">
					<span class="dashicons dashicons-admin-site-alt3"></span>
				</a>
				<?php if ( function_exists( 'farazsms_ux_v2_topbar_toggle' ) ) { farazsms_ux_v2_topbar_toggle(); } ?>
			</div>
		</header>
		<div class="farazsms-app-body">
			<aside class="farazsms-app-sidebar">
				<button type="button" class="farazsms-app-sidebar__toggle" aria-label="<?php esc_attr_e( 'باز/بستن ناوبری', 'farazsms' ); ?>">
					<span class="dashicons dashicons-menu-alt"></span>
				</button>
				<?php farazsms_ux_v2_render_sidebar( $current_gkey, $current_item ); ?>
			</aside>
			<main class="farazsms-app-content">
				<?php if ( $current_item ) : ?>
					<div class="farazsms-app-pagehead">
						<h1 class="farazsms-app-pagehead__title">
							<span class="dashicons <?php echo esc_attr( $current_item['icon'] ); ?>"></span>
							<?php echo esc_html( $current_item['title'] ); ?>
						</h1>
						<?php if ( ! empty( $current_item['desc'] ) ) : ?>
							<p class="farazsms-app-pagehead__desc"><?php echo esc_html( $current_item['desc'] ); ?></p>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				<div class="farazsms-app-content__inner">
				<?php farazsms_ux_v2_render_login_tabs(); ?>
	<?php
	// شروع buffering تا بتوانیم تگ‌های بستن را در جای درست (قبل از بسته‌شدن
	// wpbody-content) تزریق کنیم. سطح فعلی buffer را ذخیره می‌کنیم تا close
	// بداند کدام buffer متعلق به ماست (در صورتی که سایر افزونه‌ها هم ob_start بزنند).
	ob_start();
	$GLOBALS['farazsms_frame_ob_level'] = ob_get_level();
}

add_action( 'in_admin_footer', 'farazsms_unified_frame_close', 0 );
function farazsms_unified_frame_close() {
	if ( ! farazsms_page_uses_frame() ) {
		return;
	}
	$our_level = isset( $GLOBALS['farazsms_frame_ob_level'] ) ? (int) $GLOBALS['farazsms_frame_ob_level'] : 0;
	if ( $our_level <= 0 || ob_get_level() <= 0 ) {
		return;
	}
	// اگر افزونه‌ای بالاتر از ما buffer باز کرده، آن‌ها را flush می‌کنیم تا به buffer ما برسیم.
	$safety = 0;
	while ( ob_get_level() > $our_level && $safety < 20 ) {
		ob_end_flush();
		$safety++;
	}
	// v3.13.19 BUG FIX: قبل از این، اگر buffer ما به هر دلیلی بسته شده بود
	// (مثلاً افزونه دیگری ob_end_clean زده یا exception buffer را trash کرده)،
	// این تابع return می‌کرد بدون flush کردن buffer ما → صفحه سفید!
	// حالا اگر به buffer خود نرسیم، با تمام buffers باز موجود flush می‌کنیم تا
	// محتوای صفحه از دست نرود.
	if ( ob_get_level() !== $our_level ) {
		// emergency flush — تمام buffer های موجود را خروجی بده تا صفحه سفید نشود
		while ( ob_get_level() > 0 ) {
			@ob_end_flush();
		}
		return;
	}
	$buf = ob_get_clean();
	unset( $GLOBALS['farazsms_frame_ob_level'] );

	// آماده‌سازی markup بستن frame.
	ob_start();
	?>
				</div>
			</main>
		</div>
		<footer class="farazsms-app-footer">
			<div class="farazsms-app-footer__row">
				<span><?php esc_html_e( 'افزونه فراز اس‌ام‌اس', 'farazsms' ); ?></span>
				<span class="farazsms-app-footer__sep">•</span>
				<a href="https://farazsms.com/" target="_blank" rel="noopener"><?php esc_html_e( 'سایت رسمی', 'farazsms' ); ?></a>
				<span class="farazsms-app-footer__sep">•</span>
				<a href="https://sms.farazsms.com/" target="_blank" rel="noopener"><?php esc_html_e( 'ورود به پنل', 'farazsms' ); ?></a>
				<span class="farazsms-app-footer__sep">•</span>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-feedback' ) ); ?>"><?php esc_html_e( 'بازخورد و گزارش مشکل', 'farazsms' ); ?></a>
			</div>
			<!-- v3.17.7: اعلامیه‌ی کپی‌رایت رسمی -->
			<div class="farazsms-app-footer__copyright">
				© <?php echo esc_html( wp_date( 'Y' ) ); ?> —
				<?php esc_html_e( 'کلیه حقوق مادی و معنوی این افزونه متعلق به سامانه پیامک فراز اس‌ام‌اس (شرکت زرین ارتباطات آسیا) است و هرگونه کپی‌برداری از آن غیرمجاز و پیگرد قانونی دارد.', 'farazsms' ); ?>
			</div>
		</footer>
	</div>
	<?php
	$close = ob_get_clean();

	// تزریق close markup دقیقاً قبل از بسته شدن wpbody-content (که WP در admin-footer.php
	// emit می‌کند). اگر marker پیدا نشد، fallback به prepend می‌رویم — این تضمین می‌کند
	// frame همیشه بسته می‌شود حتی اگر ساختار admin-footer.php در آینده عوض شود.
	$marker = '</div><!-- wpbody-content -->';
	$pos    = strpos( $buf, $marker );
	if ( $pos !== false ) {
		$buf = substr_replace( $buf, $close, $pos, 0 );
	} else {
		// Fallback: bracket frame around the whole buffer.
		$buf = $close . $buf;
	}
	echo $buf;
}

/* ------------------------------------------------------------------------- *
 *  Inline CSS — scoped under .farazsms-app-frame
 * ------------------------------------------------------------------------- */

function farazsms_unified_frame_inline_css() {
	static $printed = false;
	if ( $printed ) {
		return;
	}
	$printed = true;
	?>
	<style id="farazsms-app-frame-css">
	/* Reset within the frame */
	#wpbody-content { padding-bottom: 0 !important; }
	#wpbody-content .farazsms-app-frame { margin: 12px 0 0 12px; }
	#wpcontent { padding-right: 12px !important; }
	.farazsms-app-frame * { box-sizing: border-box; }

	/* v3.17.6: فونت سراسری frame — روی کل قاب اعمال می‌شود (sidebar، topbar، محتوا، dropdownها).
	   v3.22.153: فونتِ رسمیِ محصول (Yekan Bakh) جای IRANSans را گرفت تا پیشخوانِ افزونه با
	   پنلِ کاربریِ فراز یکدست باشد. فایل‌های فونت داخلِ خودِ افزونه‌اند و فقط همین‌جا
	   (زیرِ .farazsms-app-frame) اعمال می‌شوند — سایتِ فروشگاه دست‌نخورده می‌ماند. */
	.farazsms-app-frame,
	.farazsms-app-frame *:not(code):not(pre):not(kbd):not(samp):not([class*="dashicons"]) {
		font-family: 'Yekan Bakh FarazSMS', IRANSans, Tahoma, sans-serif !important;
	}
	.farazsms-app-frame code,
	.farazsms-app-frame pre,
	.farazsms-app-frame kbd,
	.farazsms-app-frame samp { font-family: Menlo, Consolas, "Courier New", monospace !important; }

	/* Hide the default .wrap padding/H1 — pages use their own headers; the frame's pagehead is enough */
	.farazsms-app-content__inner > .wrap,
	.farazsms-app-content__inner > section.wrapper {
		margin: 0 !important;
		padding: 0 !important;
	}
	/* Hide the duplicate per-page header (logo + credit) since the unified topbar has them already */
	.farazsms-app-frame .farazsms-app-content__inner section.wrapper > #farazsms_header,
	.farazsms-app-frame .farazsms-app-content__inner section.wrapper > #fwss_header { display: none !important; }
	/* Plugin pages that use <ul class="tabs"> at the top — keep them but normalize spacing */
	.farazsms-app-frame .farazsms-app-content__inner ul.tabs { margin-top: 0; }

	/* ════════════════════════════════════════════════════════════════════════
	 *  Polish/Normalize legacy styles — v3.13.9
	 *  هدف: یکپارچه‌سازی دکمه‌ها/فیلدها/نوتیس‌ها در صفحات قدیمی (تنظیمات، کد رهگیری،
	 *  اتومیشن، ...) با ظاهر جدید قاب. تمام rule ها زیر .farazsms-app-frame scoped شده‌اند
	 *  تا هیچ leak به سایر صفحات WP نباشد.
	 * ════════════════════════════════════════════════════════════════════════ */

	/* wrapper container — حذف min-width و عرض ثابت 1024px قدیمی */
	.farazsms-app-frame .farazsms-app-content__inner section.wrapper {
		min-width: 0 !important;
		max-width: 100% !important;
		margin: 0 !important;
		font-family: inherit !important;
	}

	/* Buttons — همه دکمه‌ها (.farazsms_button, .fwss_button) compact و یکپارچه */
	.farazsms-app-frame .farazsms-app-content__inner .farazsms_button,
	.farazsms-app-frame .farazsms-app-content__inner .fwss_button {
		/* v3.22.154: مطابقِ دکمه‌ی پروداکشن — 12px/700، شعاعِ ۶، ارتفاعِ کمینه ۴۰،
		   بدونِ جابه‌جاییِ عمودی در هاور (سیستمِ پنل فقط شفافیت را کم می‌کند). */
		display: inline-flex !important;
		align-items: center !important;
		justify-content: center !important;
		gap: 4px !important;
		background: #365891 !important;
		color: #fff !important;
		border: 1px solid #365891 !important;
		padding: 5px 14px !important;
		text-align: center !important;
		font-size: 12px !important;
		font-weight: 700 !important;
		cursor: pointer !important;
		position: relative !important;
		font-family: inherit !important;
		width: auto !important;
		min-width: 0 !important;
		min-height: 40px !important;
		border-radius: 6px !important;
		transition: opacity .2s ease !important;
		height: auto !important;
		line-height: 1.6 !important;
		box-shadow: none !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner .farazsms_button:hover,
	.farazsms-app-frame .farazsms-app-content__inner .fwss_button:hover {
		background: #365891 !important;
		opacity: .9 !important;
		box-shadow: none !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner .farazsms_button:active,
	.farazsms-app-frame .farazsms-app-content__inner .fwss_button:active {
		transform: translateY(0) !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner .farazsms_button--compact,
	.farazsms-app-frame .farazsms-app-content__inner .farazsms_button.farazsms_button--compact {
		padding: 6px 14px !important;
		font-size: 12px !important;
		min-width: 0 !important;
	}

	/* Input fields — یکپارچه‌سازی ارتفاع و padding */
	.farazsms-app-frame .farazsms-app-content__inner .input-field,
	.farazsms-app-frame .farazsms-app-content__inner input[type="text"]:not(.farazsms-pwsms-test-mobile):not(.farazsms-wallet-custom-amount):not(.farazsms-app-topbar input),
	.farazsms-app-frame .farazsms-app-content__inner input[type="number"],
	.farazsms-app-frame .farazsms-app-content__inner input[type="email"],
	.farazsms-app-frame .farazsms-app-content__inner input[type="tel"],
	.farazsms-app-frame .farazsms-app-content__inner input[type="time"],
	.farazsms-app-frame .farazsms-app-content__inner select {
		/* v3.22.154: مطابقِ .faraz-input پروداکشن — ارتفاع ۴۴، بوردرِ dominant300. */
		width: 100% !important;
		padding: 0 10px !important;
		border: 1px solid #98b0d9 !important;
		border-radius: 6px !important;
		font-size: 13px !important;
		font-weight: 500 !important;
		line-height: 1.5 !important;
		height: 44px !important;
		min-height: 44px !important;
		font-family: inherit !important;
		background: #fff !important;
		color: #263f67 !important;
		box-shadow: none !important;
		transition: border-color .3s ease !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner .input-field:focus,
	.farazsms-app-frame .farazsms-app-content__inner input[type="text"]:focus,
	.farazsms-app-frame .farazsms-app-content__inner input[type="number"]:focus,
	.farazsms-app-frame .farazsms-app-content__inner input[type="email"]:focus,
	.farazsms-app-frame .farazsms-app-content__inner select:focus,
	.farazsms-app-frame .farazsms-app-content__inner textarea:focus {
		outline: none !important;
		border-color: #4571ba !important;
		box-shadow: 0 0 0 2px #eaeff7 !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner textarea.input-field,
	.farazsms-app-frame .farazsms-app-content__inner textarea {
		width: 100% !important;
		padding: 8px 10px !important;
		border: 1px solid #98b0d9 !important;
		border-radius: 6px !important;
		font-size: 13px !important;
		font-weight: 500 !important;
		line-height: 1.9 !important;
		font-family: inherit !important;
		min-height: 96px !important;
		background: #fff !important;
		color: #263f67 !important;
		transition: border-color .3s ease !important;
	}

	/* Form labels — تایپوگرافی یکپارچه */
	.farazsms-app-frame .farazsms-app-content__inner label {
		display: block;
		margin-bottom: 6px !important;
		font-family: inherit !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner label .label {
		display: block;
		font-size: 13px;
		font-weight: 600;
		color: #4d4d4d;
		margin-bottom: 6px;
		padding: 0 !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner label .required {
		color: #d52a16;
		margin-right: 3px;
	}

	/* Save button container — حذف center align */
	.farazsms-app-frame .farazsms-app-content__inner .farazsms_save_button_container,
	.farazsms-app-frame .farazsms-app-content__inner .farazsms_save_button_container_wc,
	.farazsms-app-frame .farazsms-app-content__inner .fwss_save_button_container,
	.farazsms-app-frame .farazsms-app-content__inner .fwss_save_button_container_wc {
		display: flex !important;
		flex-direction: row !important;
		justify-content: flex-start !important;
		align-items: center !important;
		gap: 12px !important;
		margin-top: 14px !important;
	}

	/* Info/error/success messages — کارت‌های مدرن */
	.farazsms-app-frame .farazsms-app-content__inner .farazsms-info-message,
	.farazsms-app-frame .farazsms-app-content__inner .farazsms_info_message,
	.farazsms-app-frame .farazsms-app-content__inner .fwss-info-message,
	.farazsms-app-frame .farazsms-app-content__inner .digits_pattern_info {
		background: #eaeff7 !important;
		border: 1px solid #c1d0e8 !important;
		color: #263f67 !important;
		padding: 10px 14px !important;
		border-radius: 8px !important;
		font-size: 12.5px !important;
		line-height: 1.8 !important;
		height: auto !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner .farazsms-error-message {
		background: #fdeae8 !important;
		border: 1px solid #d52a16 !important;
		color: #b32817 !important;
		padding: 10px 14px !important;
		border-radius: 8px !important;
		font-size: 12.5px !important;
		line-height: 1.8 !important;
		height: auto !important;
		display: block !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner .farazsms-success-message,
	.farazsms-app-frame .farazsms-app-content__inner .fwss-success-message {
		background: #e2f8f0 !important;
		border: 1px solid #10c282 !important;
		color: #096d49 !important;
		padding: 10px 14px !important;
		border-radius: 8px !important;
		font-size: 12.5px !important;
		line-height: 1.8 !important;
		height: auto !important;
		display: block !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner .fsms-warning-message,
	.farazsms-app-frame .farazsms-app-content__inner .fwss-warning-message {
		background: #faf1da !important;
		border: 1px solid #e2a916 !important;
		color: #83620d !important;
		padding: 10px 14px !important;
		border-radius: 8px !important;
		font-size: 12.5px !important;
		line-height: 1.8 !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner .fwss_notice {
		background: #eaeff7 !important;
		border: 1px solid #c1d0e8 !important;
		color: #263f67 !important;
		padding: 10px 14px !important;
		border-radius: 8px !important;
		margin-bottom: 16px !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner .fwss_notice p { margin: 0 !important; font-size: 13px; line-height: 1.8; }

	/* Tabs — کامپکت‌تر */
	.farazsms-app-frame .farazsms-app-content__inner ul.tabs {
		display: flex !important;
		gap: 4px !important;
		list-style: none !important;
		margin: 0 0 0 0 !important;
		padding: 0 !important;
		transform: none !important;
		border-bottom: 1px solid #e1e1e1 !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner ul.tabs > li {
		display: inline-block !important;
		padding: 10px 18px !important;
		cursor: pointer !important;
		color: #9b9b9b !important;
		font-size: 13px !important;
		font-weight: 500 !important;
		border: none !important;
		border-bottom: 2px solid transparent !important;
		box-shadow: none !important;
		margin-bottom: -1px !important;
		background: transparent !important;
		transition: all 0.15s !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner ul.tabs > li:hover {
		color: #365891 !important;
		border-bottom-color: rgba(99, 102, 241, 0.3) !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner ul.tabs > li.active {
		color: #365891 !important;
		background: transparent !important;
		border-bottom: 2px solid #4571ba !important;
		box-shadow: none !important;
		font-weight: 600 !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner ul.tab__content {
		list-style: none !important;
		margin: 0 !important;
		padding: 18px 0 0 0 !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner ul.tab__content > li { padding: 0 !important; }
	.farazsms-app-frame .farazsms-app-content__inner .content__wrapper { padding: 0 !important; }

	/* Form rows — بهتر نمایش دادن row/col */
	.farazsms-app-frame .farazsms-app-content__inner .farazsms_form .row,
	.farazsms-app-frame .farazsms-app-content__inner .fwss_form .row {
		display: flex !important;
		flex-wrap: wrap !important;
		gap: 12px !important;
		margin: 0 !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner .farazsms_form .col-6,
	.farazsms-app-frame .farazsms-app-content__inner .fwss_form .col-6 {
		flex: 1 1 280px !important;
		min-width: 0 !important;
		max-width: 100% !important;
		padding: 0 !important;
	}
	.farazsms-app-frame .farazsms-app-content__inner .container {
		max-width: 100% !important;
		padding: 0 !important;
		margin: 0 !important;
	}

	/* جداکننده‌های br پشت سر هم اشغال فضای زیاد می‌کنند — همشون رو jam کنیم */
	.farazsms-app-frame .farazsms-app-content__inner br + br { display: none; }

	/* Description text زیر فیلدها */
	.farazsms-app-frame .farazsms-app-content__inner .description,
	.farazsms-app-frame .farazsms-app-content__inner p.description {
		font-size: 11px !important;
		color: #9b9b9b !important;
		margin: 4px 0 0 0 !important;
		line-height: 1.7 !important;
	}

	/* صفحات افزونه — حذف H2/H1 های قدیمی که overlap با pagehead قاب می‌کنند */
	.farazsms-app-frame .farazsms-app-content__inner > .wrap > h1:first-child,
	.farazsms-app-frame .farazsms-app-content__inner > .wrap > h2:first-child {
		display: none !important;
	}

	/* ── Frame container ───────────────────────────────────────── */
	.farazsms-app-frame {
		direction: rtl;
		font-family: Tahoma, 'IRANSans', 'Vazir', -apple-system, BlinkMacSystemFont, sans-serif;
		background: #f1f3f6;
		border: 1px solid #e2e6ea;
		border-radius: 12px;
		overflow: hidden;
		box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);
		margin-right: 20px !important;
		margin-left: 20px !important;
		margin-top: 16px !important;
	}

	/* ── Topbar ────────────────────────────────────────────────── */
	.farazsms-app-topbar {
		display: flex;
		justify-content: space-between;
		align-items: center;
		gap: 16px;
		padding: 14px 20px;
		/* v3.22.153: هویتِ پنلِ محصول — سرمه‌ای، بدونِ بنفشِ تزئینی. */
		background: linear-gradient(135deg, #1b3f7a 0%, #365891 100%);
		color: #fff;
	}
	.farazsms-app-topbar__brand { display: flex; align-items: center; gap: 12px; }
	.farazsms-app-topbar__logo img { height: 32px; width: auto; display: block; filter: brightness(0) invert(1); }
	.farazsms-app-topbar__version {
		background: rgba(255,255,255,0.18);
		color: #fff;
		font-size: 11px;
		font-weight: 600;
		padding: 3px 8px;
		border-radius: 20px;
		letter-spacing: 0.3px;
	}
	.farazsms-app-topbar__meta { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
	.farazsms-app-topbar__credit {
		display: inline-flex;
		align-items: center;
		gap: 6px;
		background: rgba(255,255,255,0.16);
		color: #fff !important;
		padding: 8px 14px;
		border-radius: 8px;
		font-size: 13px;
		font-weight: 500;
		text-decoration: none;
		transition: background 0.15s;
	}
	.farazsms-app-topbar__credit:hover { background: rgba(255,255,255,0.26); }
	.farazsms-app-topbar__credit strong { font-size: 14px; font-weight: 700; }
	.farazsms-app-topbar__credit-unit { opacity: 0.85; font-size: 12px; }
	.farazsms-app-topbar__credit--empty { background: rgba(244, 67, 54, 0.85); }
	.farazsms-app-topbar__credit--empty:hover { background: rgba(244, 67, 54, 1); }
	.farazsms-app-topbar__credit .dashicons { font-size: 18px; width: 18px; height: 18px; }
	.farazsms-app-topbar__button {
		display: inline-flex;
		align-items: center;
		gap: 6px;
		background: rgba(255,255,255,0.10);
		border: 1px solid rgba(255,255,255,0.22);
		color: #fff !important;
		padding: 7px 12px;
		border-radius: 8px;
		font-size: 13px;
		text-decoration: none;
		transition: background 0.15s;
	}
	.farazsms-app-topbar__button:hover { background: rgba(255,255,255,0.20); }
	.farazsms-app-topbar__button .dashicons { font-size: 16px; width: 16px; height: 16px; }
	.farazsms-app-topbar__button--icon { padding: 7px 9px; }

	/* ── Body (sidebar + content) ─────────────────────────────── */
	.farazsms-app-body {
		display: grid;
		grid-template-columns: 240px 1fr;
		min-height: 600px;
		background: #fff;
	}
	.farazsms-app-sidebar {
		background: #f5f8fe;
		border-left: 1px solid #e1e1e1;
		padding: 16px 0;
		position: relative;
	}
	.farazsms-app-sidebar__toggle {
		display: none;
		background: transparent;
		border: 0;
		cursor: pointer;
		color: #4d4d4d;
		padding: 6px;
		position: absolute;
		top: 8px;
		left: 8px;
	}
	.farazsms-app-sidebar__group { margin-bottom: 18px; }
	.farazsms-app-sidebar__group-label {
		display: flex;
		align-items: center;
		gap: 6px;
		font-size: 11px;
		font-weight: 700;
		color: #9b9b9b;
		letter-spacing: 0.4px;
		padding: 4px 16px 8px;
		text-transform: none;
	}
	.farazsms-app-sidebar__group-label .dashicons { font-size: 14px; width: 14px; height: 14px; color: #9b9b9b; }
	.farazsms-app-sidebar__items { list-style: none; margin: 0; padding: 0; }
	.farazsms-app-sidebar__item a {
		display: flex;
		align-items: center;
		gap: 8px;
		padding: 9px 16px;
		color: #4d4d4d !important;
		text-decoration: none;
		font-size: 13px;
		font-weight: 500;
		border-right: 3px solid transparent;
		transition: background 0.12s, border-color 0.12s, color 0.12s;
	}
	.farazsms-app-sidebar__item a:hover {
		background: #eaeff7;
		color: #365891 !important;
		border-right-color: rgba(99, 102, 241, 0.35);
	}
	.farazsms-app-sidebar__item a .dashicons {
		font-size: 16px;
		width: 16px;
		height: 16px;
		color: #9b9b9b;
		transition: color 0.12s;
	}
	.farazsms-app-sidebar__item a:hover .dashicons { color: #4571ba; }
	.farazsms-app-sidebar__item.is-active a {
		background: #eaeff7;
		color: #365891 !important;
		border-right-color: #4571ba;
		font-weight: 600;
	}
	.farazsms-app-sidebar__item.is-active a .dashicons { color: #4571ba; }

	/* ── Content ─────────────────────────────────────────────── */
	.farazsms-app-content {
		padding: 20px 24px 28px;
		background: #fff;
		min-width: 0;
	}
	.farazsms-app-pagehead {
		border-bottom: 1px solid #e1e1e1;
		padding-bottom: 14px;
		margin-bottom: 18px;
	}
	.farazsms-app-pagehead__title {
		display: flex;
		align-items: center;
		gap: 10px;
		font-size: 20px;
		margin: 0;
		color: #263f67;
		font-weight: 700;
	}
	.farazsms-app-pagehead__title .dashicons {
		font-size: 22px;
		width: 22px;
		height: 22px;
		color: #4571ba;
	}
	.farazsms-app-pagehead__desc {
		margin: 6px 0 0;
		color: #9b9b9b;
		font-size: 13px;
	}
	.farazsms-app-content__inner { min-height: 400px; }

	/* ── Footer ──────────────────────────────────────────────── */
	.farazsms-app-footer {
		padding: 14px 20px;
		background: #f5f8fe;
		border-top: 1px solid #e1e1e1;
		font-size: 12px;
		color: #9b9b9b;
		display: flex;
		flex-direction: column;
		gap: 8px;
	}
	.farazsms-app-footer__row {
		display: flex;
		gap: 8px;
		align-items: center;
		flex-wrap: wrap;
	}
	.farazsms-app-footer a { color: #4d4d4d !important; text-decoration: none; }
	.farazsms-app-footer a:hover { color: #365891 !important; }
	.farazsms-app-footer__sep { opacity: 0.5; }
	/* v3.17.7: اعلامیه‌ی کپی‌رایت — فونت کوچک، رنگ خنثی، spacing مناسب */
	.farazsms-app-footer__copyright {
		padding-top: 8px;
		border-top: 1px dashed #e1e1e1;
		font-size: 11px;
		color: #9b9b9b;
		line-height: 1.7;
		text-align: center;
	}

	/* ── Responsive ──────────────────────────────────────────── */
	@media (max-width: 960px) {
		.farazsms-app-body { grid-template-columns: 1fr; }
		.farazsms-app-sidebar { border-left: 0; border-bottom: 1px solid #e1e1e1; padding: 12px 0; }
		.farazsms-app-sidebar__group { margin-bottom: 10px; }
		.farazsms-app-topbar { flex-wrap: wrap; }
	}

	/* ── Hide WP standard top H1 inside frame to avoid duplication ── */
	.farazsms-app-frame .farazsms-app-content__inner > .wrap > h1:first-child {
		font-size: 16px;
		font-weight: 600;
		color: #4d4d4d;
		padding: 0;
		margin: 0 0 12px;
	}

	/* ── Reduce visual clutter: hide WP submenu dividers in this frame ── */
	#adminmenu .toplevel_page_farazsms .wp-submenu .farazsms-menu-divider { font-size: 10px; opacity: 0.7; }

	/* ── Hub page styles ─────────────────────────────────────── */
	.farazsms-hub-hero {
		background: linear-gradient(135deg, #eaeff7 0%, #f5f8fe 100%);
		border: 1px solid #eaeff7;
		border-radius: 12px;
		padding: 24px 26px;
		margin-bottom: 22px;
	}
	.farazsms-hub-hero h2 { margin: 0 0 6px; font-size: 22px; color: #1b3f7a; font-weight: 700; }
	.farazsms-hub-hero p { margin: 0; color: #365891; font-size: 14px; line-height: 1.9; }

	.farazsms-hub-stats {
		display: grid;
		grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
		gap: 14px;
		margin-bottom: 26px;
	}
	.farazsms-hub-stat {
		background: #fff;
		border: 1px solid #e1e1e1;
		border-radius: 10px;
		padding: 16px 18px;
		display: flex;
		align-items: center;
		gap: 12px;
	}
	.farazsms-hub-stat__icon {
		width: 42px;
		height: 42px;
		border-radius: 10px;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		background: #eaeff7;
		color: #4571ba;
		flex-shrink: 0;
	}
	.farazsms-hub-stat__icon .dashicons { font-size: 22px; width: 22px; height: 22px; }
	.farazsms-hub-stat__body { flex: 1; min-width: 0; }
	.farazsms-hub-stat__label { font-size: 12px; color: #9b9b9b; margin: 0 0 3px; }
	.farazsms-hub-stat__value { font-size: 18px; color: #263f67; font-weight: 700; margin: 0; }

	.farazsms-hub-group {
		margin-bottom: 28px;
	}
	.farazsms-hub-group__head {
		display: flex;
		align-items: center;
		gap: 8px;
		margin-bottom: 12px;
	}
	.farazsms-hub-group__title {
		font-size: 15px;
		font-weight: 700;
		color: #263f67;
		margin: 0;
	}
	.farazsms-hub-group__divider {
		flex: 1;
		height: 1px;
		background: linear-gradient(to left, transparent, #e1e1e1);
	}
	.farazsms-hub-grid {
		display: grid;
		grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
		gap: 12px;
	}
	.farazsms-hub-card {
		display: flex;
		gap: 12px;
		padding: 14px 16px;
		background: #fff;
		border: 1px solid #e1e1e1;
		border-radius: 10px;
		text-decoration: none !important;
		color: inherit !important;
		transition: border-color 0.15s, box-shadow 0.15s, transform 0.15s;
	}
	.farazsms-hub-card:hover {
		border-color: #c1d0e8;
		box-shadow: 0 4px 12px rgba(99,102,241,0.10);
		transform: translateY(-1px);
	}
	.farazsms-hub-card__icon {
		width: 36px;
		height: 36px;
		border-radius: 8px;
		background: #f5f8fe;
		color: #4571ba;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		flex-shrink: 0;
	}
	.farazsms-hub-card__icon .dashicons { font-size: 20px; width: 20px; height: 20px; }
	.farazsms-hub-card__body { flex: 1; min-width: 0; }
	.farazsms-hub-card__title { font-size: 14px; font-weight: 600; color: #263f67; margin: 0 0 3px; }
	.farazsms-hub-card__desc { font-size: 12px; color: #9b9b9b; margin: 0; line-height: 1.7; }
	</style>
	<script>
	// Sidebar toggle on mobile
	document.addEventListener('DOMContentLoaded', function() {
		var btn = document.querySelector('.farazsms-app-sidebar__toggle');
		var nav = document.querySelector('.farazsms-app-sidebar__nav');
		if (btn && nav) {
			btn.addEventListener('click', function() {
				nav.style.display = (nav.style.display === 'none') ? '' : 'none';
			});
		}
	});
	</script>
	<?php
}

/* ------------------------------------------------------------------------- *
 *  Hide WP sidebar submenu when inside a plugin page (WoodMart-style)
 *  We don't fully remove the submenu (still accessible via direct click on
 *  parent), but we visually collapse it to reduce sidebar noise.
 * ------------------------------------------------------------------------- */

add_action( 'admin_head', 'farazsms_hide_wp_submenu_when_in_plugin' );
function farazsms_hide_wp_submenu_when_in_plugin() {
	if ( ! farazsms_is_plugin_page() ) {
		return;
	}
	?>
	<style id="farazsms-hide-wp-submenu-css">
	/* On plugin pages, hide the duplicated WP submenu — internal nav inside the frame
	   already handles navigation. The top-level item stays clickable from sidebar. */
	#adminmenu .toplevel_page_farazsms .wp-submenu-wrap,
	#adminmenu .toplevel_page_farazsms .wp-submenu {
		display: none !important;
	}
	#adminmenu .toplevel_page_farazsms.wp-has-current-submenu .wp-submenu-head {
		display: block !important;
	}
	/* Re-show submenu on hover so users can still jump between top-level items */
	#adminmenu .toplevel_page_farazsms:hover .wp-submenu-wrap,
	#adminmenu .toplevel_page_farazsms:hover .wp-submenu {
		display: block !important;
	}
	/* On non-plugin pages: leave submenu alone (handled by menu organizer normally) */
	</style>
	<?php
}

/* ------------------------------------------------------------------------- *
 *  Hub page render
 * ------------------------------------------------------------------------- */

function farazsms_dashboard_hub_render() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( __( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}

	$apikey  = farazsms_get_apikey();
	$credit  = '';
	if ( ! empty( $apikey ) ) {
		$credit_raw = farazsms_get_credit();
		if ( $credit_raw !== false && $credit_raw !== '' ) {
			$credit = (string) $credit_raw;
		}
	}
	$stats = farazsms_dashboard_collect_stats();
	?>
	<div class="farazsms-hub-wrapper">

		<?php
		// v3.21.11: نقطه‌ی تزریقِ ویزاردِ شروع (onboarding) و هر افزونه‌ی بالای داشبورد.
		do_action( 'farazsms_dashboard_top' );
		?>

		<?php if ( empty( $apikey ) ) : ?>
			<div class="farazsms-hub-hero" style="background: linear-gradient(135deg, #fdeae8 0%, #faf1da 100%); border-color:#d52a16;">
				<h2 style="color:#9f1239;">👋 <?php esc_html_e( 'به افزونه فراز اس‌ام‌اس خوش آمدید', 'farazsms' ); ?></h2>
				<p style="color:#b32817;">
					<?php esc_html_e( 'برای شروع، کلید دسترسی (Api-Key) را در صفحه تنظیمات وارد کنید.', 'farazsms' ); ?>
					&nbsp;
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-settings' ) ); ?>" style="color:#fff !important; background:#b32817; padding:6px 14px; border-radius:6px; text-decoration:none; font-weight:600;">
						<?php esc_html_e( 'ورود به صفحه تنظیمات', 'farazsms' ); ?>
					</a>
				</p>
			</div>
		<?php else : ?>
			<div class="farazsms-hub-hero">
				<?php
				// نام را از پنل پیامکی (وب‌سرویس پروفایل) بگیر؛ اگر در دسترس نبود به نام
				// نمایشیِ کاربر وردپرس برگرد.
				$farazsms_hero_profile = farazsms_get_profile();
				$farazsms_hero_name = ( is_array( $farazsms_hero_profile ) && ! empty( $farazsms_hero_profile['display_name'] ) )
					? $farazsms_hero_profile['display_name']
					: wp_get_current_user()->display_name;
				?>
				<h2>👋 <?php printf( esc_html__( 'سلام %s، خوش آمدید', 'farazsms' ), esc_html( $farazsms_hero_name ) ); ?></h2>
				<p><?php esc_html_e( 'این داشبورد به شما نمای کلی از وضعیت پلاگین، آمار ارسال و دسترسی سریع به تمام قابلیت‌ها را می‌دهد.', 'farazsms' ); ?></p>
			</div>
		<?php endif; ?>

		<?php
		// اگر ارسالِ درخواست به فراز اس ام اس مسدود شده باشد، علتِ واقعی را همین‌جا (به‌جای
		// «کلید نامعتبر») نشان بده.
		if ( ! empty( $apikey ) ) {
			echo farazsms_connectivity_inline_warning_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
		?>

		<!-- Quick stat cards -->
		<div class="farazsms-hub-stats">
			<div class="farazsms-hub-stat">
				<div class="farazsms-hub-stat__icon"><span class="dashicons dashicons-money-alt"></span></div>
				<div class="farazsms-hub-stat__body">
					<p class="farazsms-hub-stat__label"><?php esc_html_e( 'اعتبار پنل', 'farazsms' ); ?></p>
					<p class="farazsms-hub-stat__value"><?php echo $credit !== '' ? esc_html( $credit ) . ' <small style="font-size:11px; font-weight:500; color:#9b9b9b;">تومان</small>' : '—'; ?></p>
				</div>
			</div>
			<div class="farazsms-hub-stat">
				<div class="farazsms-hub-stat__icon" style="background:#e2f8f0; color:#0c9765;"><span class="dashicons dashicons-groups"></span></div>
				<div class="farazsms-hub-stat__body">
					<p class="farazsms-hub-stat__label"><?php esc_html_e( 'مشترکین خبرنامه', 'farazsms' ); ?></p>
					<p class="farazsms-hub-stat__value"><?php echo esc_html( number_format_i18n( $stats['newsletter_subs'] ) ); ?></p>
				</div>
			</div>
			<div class="farazsms-hub-stat">
				<div class="farazsms-hub-stat__icon" style="background:#faf1da; color:#e2a916;"><span class="dashicons dashicons-bell"></span></div>
				<div class="farazsms-hub-stat__body">
					<p class="farazsms-hub-stat__label"><?php esc_html_e( 'موجود شد خبرم کن', 'farazsms' ); ?></p>
					<p class="farazsms-hub-stat__value"><?php echo esc_html( number_format_i18n( $stats['notify_subs'] ) ); ?></p>
				</div>
			</div>
			<div class="farazsms-hub-stat">
				<div class="farazsms-hub-stat__icon" style="background:#fdeae8; color:#d52a16;"><span class="dashicons dashicons-cart"></span></div>
				<div class="farazsms-hub-stat__body">
					<p class="farazsms-hub-stat__label"><?php esc_html_e( 'سبد رهاشده (۷ روز)', 'farazsms' ); ?></p>
					<p class="farazsms-hub-stat__value"><?php echo esc_html( number_format_i18n( $stats['abandoned_recent'] ) ); ?></p>
				</div>
			</div>
			<?php
			// v3.14.1: کارت برجسته آمار کش‌بک — اگر سیستم فعال، نمایش اثربخشی روی فروش.
			if ( function_exists( 'farazsms_cashback_get_stats' ) ) :
				$cb_stats = farazsms_cashback_get_stats();
				if ( ! empty( $cb_stats['enabled'] ) ) :
					$currency = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : 'تومان';
				?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-cashback' ) ); ?>" class="farazsms-hub-stat" style="text-decoration:none; color:inherit; cursor:pointer; background:linear-gradient(135deg,#0c9765 0%,#0c9765 100%); color:#fff; grid-column: span 2;">
					<div class="farazsms-hub-stat__icon" style="background:rgba(255,255,255,0.18); color:#fff;"><span class="dashicons dashicons-chart-line"></span></div>
					<div class="farazsms-hub-stat__body">
						<p class="farazsms-hub-stat__label" style="color:#fff; opacity:0.95;"><?php esc_html_e( '📈 افزایش فروش از سیستم کش‌بک', 'farazsms' ); ?></p>
						<p class="farazsms-hub-stat__value" style="color:#fff;">
							<?php echo esc_html( number_format_i18n( $cb_stats['sales_with_cashback'] ) ); ?>
							<small style="font-size:11px; font-weight:500; opacity:0.85;"><?php echo esc_html( $currency ); ?></small>
						</p>
						<p style="margin:2px 0 0; font-size:10px; opacity:0.85;">
							<?php echo esc_html( number_format_i18n( $cb_stats['repeat_customers'] ) ); ?> مشتری بازگشتی · نرخ تبدیل <?php echo esc_html( $cb_stats['conversion_rate'] ); ?>٪
						</p>
					</div>
				</a>
				<?php endif; endif; ?>

			<?php
			// v3.13.20: کارت‌های آمار ماژول ورود/ثبت‌نام — تعداد کل اعضای سایت + ثبت‌نام با ماژول.
			if ( function_exists( 'farazsms_login_module_get_stats' ) ) :
				$login_stats = farazsms_login_module_get_stats();
				?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-login-register' ) ); ?>" class="farazsms-hub-stat" style="text-decoration:none; color:inherit; cursor:pointer;">
					<div class="farazsms-hub-stat__icon" style="background:#eaeff7; color:#365891;"><span class="dashicons dashicons-admin-users"></span></div>
					<div class="farazsms-hub-stat__body">
						<p class="farazsms-hub-stat__label"><?php esc_html_e( 'کل اعضای سایت', 'farazsms' ); ?></p>
						<p class="farazsms-hub-stat__value"><?php echo esc_html( number_format_i18n( $login_stats['total_users'] ) ); ?></p>
					</div>
				</a>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-login-register' ) ); ?>" class="farazsms-hub-stat" style="text-decoration:none; color:inherit; cursor:pointer;">
					<div class="farazsms-hub-stat__icon" style="background:#eaeff7; color:#365891;"><span class="dashicons dashicons-smartphone"></span></div>
					<div class="farazsms-hub-stat__body">
						<p class="farazsms-hub-stat__label">
							<?php esc_html_e( 'ثبت‌نام با موبایل', 'farazsms' ); ?>
							<?php if ( ! $login_stats['enabled'] ) : ?>
								<span style="display:inline-block; background:#e2a916; color:#fff; font-size:9px; padding:1px 6px; border-radius:3px; margin-right:4px;">غیرفعال</span>
							<?php endif; ?>
						</p>
						<p class="farazsms-hub-stat__value"><?php echo esc_html( number_format_i18n( $login_stats['module_users'] ) ); ?></p>
					</div>
				</a>
			<?php endif; ?>
		</div>

		<!-- پنل خرید شارژ — مستقیم در داشبورد قابل دسترس -->
		<?php if ( function_exists( 'farazsms_render_wallet_recharge_panel' ) ) : ?>
			<?php farazsms_render_wallet_recharge_panel(); ?>
		<?php endif; ?>

		<!-- پنل تست ارسال پیامک (compact mode — فقط فرم تست SMS، بدون status/credit cards) -->
		<?php if ( function_exists( 'farazsms_render_connection_test_panel' ) ) : ?>
			<?php farazsms_render_connection_test_panel( array( 'compact' => true ) ); ?>
		<?php endif; ?>

		<!-- Feature groups -->
		<?php foreach ( farazsms_dashboard_nav_groups() as $gkey => $group ) :
			// در hub، گروه «تنظیمات اصلی» خود داشبورد را دوباره نشان ندهد
			$items = array_filter( $group['items'], function( $i ) { return $i['slug'] !== 'farazsms-dashboard'; } );
			if ( empty( $items ) ) continue;
			?>
			<section class="farazsms-hub-group">
				<div class="farazsms-hub-group__head">
					<h3 class="farazsms-hub-group__title">
						<span class="dashicons <?php echo esc_attr( $group['icon'] ); ?>" style="color:#4571ba; vertical-align:middle;"></span>
						<?php echo esc_html( $group['label'] ); ?>
					</h3>
					<span class="farazsms-hub-group__divider"></span>
				</div>
				<div class="farazsms-hub-grid">
					<?php foreach ( $items as $item ) : ?>
						<a href="<?php echo esc_url( farazsms_dashboard_item_url( $item['slug'] ) ); ?>" class="farazsms-hub-card">
							<div class="farazsms-hub-card__icon"><span class="dashicons <?php echo esc_attr( $item['icon'] ); ?>"></span></div>
							<div class="farazsms-hub-card__body">
								<p class="farazsms-hub-card__title"><?php echo esc_html( $item['title'] ); ?></p>
								<p class="farazsms-hub-card__desc"><?php echo esc_html( $item['desc'] ); ?></p>
							</div>
						</a>
					<?php endforeach; ?>
				</div>
			</section>
		<?php endforeach; ?>

	</div>
	<?php
}

/**
 * جمع‌آوری آمار سریع برای نمایش در hub.
 * هر شمارش inside try/catch تا اگر جدولی نباشد، صفر برگردانده شود.
 */
function farazsms_dashboard_collect_stats() {
	global $wpdb;
	$out = array(
		'newsletter_subs'  => 0,
		'notify_subs'      => 0,
		'abandoned_recent' => 0,
	);

	// Newsletter subscribers (wp_farazsms_newsletter_subscribers — column status='active')
	$t = $wpdb->prefix . 'farazsms_newsletter_subscribers';
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) ) === $t ) {
		$out['newsletter_subs'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE status = %s", 'active' ) );
	}

	// Notify-me subscribers (wp_farazsms_notify_subscribers — column status='pending')
	$t = $wpdb->prefix . 'farazsms_notify_subscribers';
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) ) === $t ) {
		$out['notify_subs'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE status = %s", 'pending' ) );
	}

	// Abandoned carts in last 7 days (wp_farazsms_abandoned_carts — created_at DATETIME)
	$t = $wpdb->prefix . 'farazsms_abandoned_carts';
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) ) === $t ) {
		$out['abandoned_recent'] = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM $t WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)"
		);
	}

	return $out;
}

/* ------------------------------------------------------------------------- *
 *  Tell core-init.php to enqueue assets on the new slug too
 * ------------------------------------------------------------------------- */

add_filter( 'admin_body_class', 'farazsms_dashboard_body_class' );
function farazsms_dashboard_body_class( $classes ) {
	if ( farazsms_is_plugin_page() ) {
		$classes .= ' farazsms-in-plugin-frame';
	}
	return $classes;
}
