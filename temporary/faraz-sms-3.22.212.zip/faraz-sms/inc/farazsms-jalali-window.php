<?php
/**
 * مرزِ ماهِ تقویم — یک تصمیم، یک نقطه.
 *
 * چرا این فایل هست: فروشگاهِ ایرانی ماهش را شمسی می‌شمارد. گزارشِ پیامکیِ
 * ماهانه از قبل درست بود (اولِ هر ماهِ شمسی، با پنجره‌ی شمسی)، ولی داشبوردهای
 * پیشخوان ماه را با
 *
 * date( 'Y-m-01', ... )
 *
 * یعنی اولِ ماهِ **میلادی** می‌گرفتند. نتیجه این بود که «این ماه» در دو جای
 * افزونه دو معنای متفاوت داشت.
 *
 * تبدیلِ تقویم اینجا دوباره نوشته نمی‌شود: پیاده‌سازیِ موجود صدا زده می‌شود
 * تا پیاده‌سازیِ چهارمی از تقویمِ جلالی در مخزن ساخته نشود.
 *
 * ⚠️ خروجی به وقتِ **محلیِ سایت** است، چون همه‌ی جدول‌های خودِ افزونه
 * (sent_at، created_at، …) با current_time('mysql') نوشته می‌شوند. این تابع
 * تقویم را عوض می‌کند، نه منطقه‌ی زمانی را.
 *
 * @package FarazSMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * «اکنون» به‌صورتِ مهرِ زمانیِ واقعی — تنها منبعِ زمانِ این فایل.
 *
 * از current_time مشتق می‌شود (نه time) تا همان جایی تزریق‌پذیر بماند که
 * بقیه‌ی افزونه زمان را از آن می‌گیرد؛ ولی مقدارِ برگشتی مطابقِ قراردادِ این
 * فایل، مهرِ **واقعی** است نه محلی‌نما.
 *
 * @return int
 */
function farazsms_jalali_now() {
	$tz = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'Asia/Tehran' );
	// ⚠️ ساعتِ دیواریِ سایت در منطقه‌ی زمانیِ سایت پارس می‌شود، نه «مهرِ
	// محلی‌نما منهای آفست». آن تفریق آفست را در لحظه‌ی **جابه‌جاشده** می‌سنجید.
	//
	// صادقانه: این شکل هم در ساعتِ تکرارشونده‌ی پایانِ ساعتِ تابستانی مبهم است
	// (اولین وقوع انتخاب می‌شود). برای ایران بی‌اثر است (آفستِ ثابتِ ‎+۳:۳۰) و
	// سوئیت هم — چون استابِ زمان آفستِ ثابت دارد — نمی‌تواند این را بسنجد؛
	// در سندِ بدهی ثبت شده است. مقصودِ این تغییر رفعِ ابهامِ DST نیست، یکی‌کردنِ
	// قراردادِ ورودی و خروجی است.
	$dt = date_create_immutable( (string) current_time( 'mysql' ), $tz );
	return $dt ? $dt->getTimestamp() : time();
}

/**
 * مهرِ زمانیِ آغازِ یک ماهِ شمسی، نسبت به ماهِ جاری.
 *
 * ⚠️ تنها جایی که مرزِ ماه حساب می‌شود. پیش از این دو مصرف‌کننده هرکدام
 * خودشان از روی همان توابعِ پایه می‌ساختندش: پنجره‌ی داشبورد (رشته‌ی MySQL) و
 * گزارشِ پیامکیِ ماهانه (مهرِ زمانی). یک تصمیم، دو پیاده‌سازی.
 *
 * ⚠️ v3.22.202 — قراردادِ ورودی: **مهرِ زمانیِ واقعی** (همان که time می‌دهد)،
 * نه مهرِ «محلی‌نما»ی current_time('timestamp'). نسخه‌ی اول ورودی را محلی‌نما
 * می‌گرفت ولی خروجی را واقعی می‌داد، و گزارشِ ماهانه — که همیشه مهرِ واقعی
 * می‌دهد — به اندازه‌ی gmt_offset عقب می‌افتاد. چون آن گزارش فقط روزِ اولِ
 * ماهِ شمسی اجرا می‌شود، این عقب‌افتادگی **همیشه** به ماهِ قبل می‌رسید: هر ماه
 * پنجره‌ی «ماهِ گذشته» دو ماه پهنا داشت. یک قرارداد برای ورودی و خروجی.
 *
 * @param int      $offset_months ۰ = ماهِ جاری، ‎-۱ = ماهِ پیش، ‎-۲ = دو ماه پیش.
 * @param int|null $now_ts        مهرِ زمانیِ واقعی؛ null = اکنون.
 * @return int مهرِ زمانیِ واقعیِ آغازِ آن ماه.
 */
function farazsms_jalali_month_start_ts( $offset_months, $now_ts = null ) {
	$now_ts = ( $now_ts === null ) ? farazsms_jalali_now() : (int) $now_ts;
	$tz     = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'Asia/Tehran' );

	list( $jy, $jm ) = farazsms_jalali_ym_of( $now_ts );
	for ( $i = 0; $i < abs( (int) $offset_months ); $i++ ) {
		list( $jy, $jm ) = farazsms_report_prev_jalali_month( $jy, $jm );
	}
	return farazsms_report_jalali_ts( $jy, $jm, 1, $tz );
}

/**
 * پنجره‌ی یک ماهِ شمسی، به‌صورتِ رشته‌ی MySQL در وقتِ محلیِ سایت.
 *
 * @param string   $which  'current' = ماهِ جاری تا همین لحظه، 'previous' = ماهِ کاملِ گذشته.
 * @param int|null $now_ts مهرِ زمانیِ **واقعی**؛ null = اکنون. (برای تست تزریق می‌شود.)
 * @return array{start:string,end:string}
 */
function farazsms_jalali_month_window( $which = 'current', $now_ts = null ) {
	$now_ts = ( $now_ts === null ) ? farazsms_jalali_now() : (int) $now_ts;
	$tz     = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'Asia/Tehran' );

	if ( $which === 'previous' ) {
		$start_ts = farazsms_jalali_month_start_ts( -1, $now_ts );
		// پایان = یک ثانیه پیش از آغازِ ماهِ جاری. طولِ ماهِ شمسی (۲۹/۳۰/۳۱)
		// این‌طوری خودش درمی‌آید و لازم نیست جدولِ طولِ ماه نگه داریم.
		$end_ts = farazsms_jalali_month_start_ts( 0, $now_ts ) - 1;
		return array(
			'start' => gmdate( 'Y-m-d H:i:s', $start_ts + farazsms_jalali_tz_offset( $tz, $start_ts ) ),
			'end'   => gmdate( 'Y-m-d H:i:s', $end_ts + farazsms_jalali_tz_offset( $tz, $end_ts ) ),
		);
	}

	$start_ts = farazsms_jalali_month_start_ts( 0, $now_ts );
	return array(
		'start' => gmdate( 'Y-m-d H:i:s', $start_ts + farazsms_jalali_tz_offset( $tz, $start_ts ) ),
		'end'   => gmdate( 'Y-m-d H:i:s', $now_ts + farazsms_jalali_tz_offset( $tz, $now_ts ) ),
	);
}

/**
 * تبدیلِ میلادی → شمسی (الگوریتمِ استانداردِ jdf).
 *
 * ⚠️ خانه‌اش اینجاست نه در فایلِ تولد: آن فایل با farazsms_require_protected
 * بار می‌شود و روی هاستِ بدونِ لودر عمداً رد می‌شود. از وقتی داشبوردها به این
 * تبدیل وابسته‌اند، نبودنش یعنی خطای مرگبار روی پیشخوان.
 *
 * نام عمداً همان ماند تا هیچ فراخواننده‌ای تغییر نکند.
 *
 * @param int $gy
 * @param int $gm
 * @param int $gd
 * @return array [jy, jm, jd]
 */
function farazsms_birthday_gregorian_to_jalali( $gy, $gm, $gd ) {
	$g_d_m = array( 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 );
	$gy2 = ( $gm > 2 ) ? ( $gy + 1 ) : $gy;
	$days = 355666 + ( 365 * $gy ) + intdiv( $gy2 + 3, 4 ) - intdiv( $gy2 + 99, 100 ) + intdiv( $gy2 + 399, 400 ) + $gd + $g_d_m[ $gm - 1 ];
	$jy = -1595 + ( 33 * intdiv( $days, 12053 ) );
	$days = $days % 12053;
	$jy += 4 * intdiv( $days, 1461 );
	$days = $days % 1461;
	if ( $days > 365 ) {
		$jy += intdiv( $days - 1, 365 );
		$days = ( $days - 1 ) % 365;
	}
	if ( $days < 186 ) {
		$jm = 1 + intdiv( $days, 31 );
		$jd = 1 + ( $days % 31 );
	} else {
		$jm = 7 + intdiv( $days - 186, 30 );
		$jd = 1 + ( ( $days - 186 ) % 30 );
	}
	return array( $jy, $jm, $jd );
}

/**
 * [سالِ شمسی، ماهِ شمسی] یک لحظه، به وقتِ سایت.
 *
 * ⚠️ ورودی مهرِ زمانیِ **واقعی** است و تبدیل با منطقه‌ی زمانیِ سایت انجام
 * می‌شود. پیش از این با gmdate روی همان عدد کار می‌کرد، یعنی ورودی باید
 * «محلی‌نما» می‌بود — قراردادی که فراخوانندهٔ گزارشِ ماهانه رعایتش نمی‌کرد و
 * هیچ‌چیز هم آن را نمی‌گرفت.
 *
 * @param int $ts مهرِ زمانیِ واقعی.
 * @return array [jy, jm]
 */
function farazsms_jalali_ym_of( $ts ) {
	$tz = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'Asia/Tehran' );
	$ts = (int) $ts + farazsms_jalali_tz_offset( $tz, (int) $ts );
	$gy = (int) gmdate( 'Y', $ts );
	$gm = (int) gmdate( 'n', $ts );
	$gd = (int) gmdate( 'j', $ts );
	$j  = farazsms_birthday_gregorian_to_jalali( $gy, $gm, $gd );
	return array( (int) $j[0], (int) $j[1] );
}

/**
 * اختلافِ منطقه‌ی زمانی در یک لحظه‌ی مشخص.
 *
 * ⚠️ ثابت نیست: تابعِ سازنده‌ی مرزِ ماه یک مهرِ زمانیِ **واقعی** (UTC) می‌دهد و
 * ما رشته‌ی محلی می‌خواهیم؛ با آفستِ ثابت، سایتی که ساعتِ تابستانی دارد یک
 * ساعت جابه‌جا می‌شد.
 *
 * @param DateTimeZone $tz
 * @param int          $ts
 * @return int ثانیه
 */
function farazsms_jalali_tz_offset( $tz, $ts ) {
	$dt = new DateTime( '@' . (int) $ts );
	$dt->setTimezone( $tz );
	return (int) $dt->getOffset();
}
