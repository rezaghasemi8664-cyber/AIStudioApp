<?php
/**
 * Marketing / ROI Dashboard — v3.21.98 (theme 6)
 *
 * صفحه‌ی «📈 بازدهی پیامک»: فعالیتِ همه‌ی قابلیت‌های بازاریابیِ افزونه را یک‌جا نشان می‌دهد —
 * پیامکِ ارسالی و نرخِ موفقیت، نظرسنجی و نرخِ تبدیل، گردونه، خبرنامه، سبدِ رها + درآمدِ بازیابی،
 * کش‌بک، و کوپن‌های صادر/استفاده‌شده. فقط خواندنی؛ از جدول‌های موجودِ هر قابلیت می‌خواند.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'admin_menu', 'farazsms_dash_menu', 59 );
function farazsms_dash_menu() {
	add_submenu_page(
		'farazsms',
		'بازدهی پیامک',
		'📈 بازدهی پیامک',
		'manage_options',
		'farazsms-marketing',
		'farazsms_dash_render_page'
	);
}

/** آیا جدول وجود دارد؟ */
function farazsms_dash_table_exists( $table ) {
	global $wpdb;
	return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
}

/** یک عددِ COUNT/SUM امن (اگر جدول نبود یا خطا، ۰). */
function farazsms_dash_num( $table, $sql, $args = array() ) {
	if ( ! farazsms_dash_table_exists( $table ) ) {
		return 0.0;
	}
	global $wpdb;
	$val = empty( $args ) ? $wpdb->get_var( $sql ) : $wpdb->get_var( $wpdb->prepare( $sql, ...$args ) );
	return (float) $val;
}

function farazsms_dash_price( $amount ) {
	return farazsms_price_plain( $amount );
}

function farazsms_dash_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی غیرمجاز.' );
	}
	global $wpdb;

	$range = isset( $_GET['range'] ) ? (int) $_GET['range'] : 30;
	if ( ! in_array( $range, array( 7, 30, 90 ), true ) ) {
		$range = 30;
	}
	$since = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - $range * DAY_IN_SECONDS );

	// ── پیامک (پنلِ تشخیص) ──
	$sms_total = 0.0; $sms_ok = 0.0;
	$t = farazsms_send_diag_table();
	$sms_total = farazsms_dash_num( $t, "SELECT COUNT(*) FROM $t WHERE created_at >= %s", array( $since ) );
	$sms_ok    = farazsms_dash_num( $t, "SELECT COUNT(*) FROM $t WHERE status = 'success' AND created_at >= %s", array( $since ) );
	$sms_rate = $sms_total > 0 ? round( $sms_ok / $sms_total * 100 ) : 0;

	// ── نظرسنجی ──
	$sv_sent = 0.0; $sv_reviews = 0.0;
	if ( function_exists( 'farazsms_survey_table' ) ) {
		$t = farazsms_survey_table();
		$sv_sent    = farazsms_dash_num( $t, "SELECT COUNT(*) FROM $t WHERE dispatched_at >= %s", array( $since ) );
		$sv_reviews = farazsms_dash_num( $t, "SELECT COUNT(*) FROM $t WHERE reviews_count > 0 AND dispatched_at >= %s", array( $since ) );
	}
	$sv_rate = $sv_sent > 0 ? round( $sv_reviews / $sv_sent * 100 ) : 0;

	// ── گردونه ──
	$spin_players = 0.0; $spin_winners = 0.0;
	if ( function_exists( 'farazsms_spin_table' ) ) {
		$t = farazsms_spin_table();
		$spin_players = farazsms_dash_num( $t, "SELECT COUNT(*) FROM $t WHERE created_at >= %s", array( $since ) );
		$spin_winners = farazsms_dash_num( $t, "SELECT COUNT(*) FROM $t WHERE won = 1 AND created_at >= %s", array( $since ) );
	}

	// ── خبرنامه ──
	$nl_total = 0.0; $nl_new = 0.0;
	if ( function_exists( 'farazsms_newsletter_table' ) ) {
		$t = farazsms_newsletter_table();
		$nl_total = farazsms_dash_num( $t, "SELECT COUNT(*) FROM $t WHERE status = 'active'" );
		$nl_new   = farazsms_dash_num( $t, "SELECT COUNT(*) FROM $t WHERE status = 'active' AND subscribed_at >= %s", array( $since ) );
	}

	// ── سبدِ رها + درآمدِ بازیابی ──
	$ab_sent = 0.0; $ab_recovered = 0.0; $ab_revenue = 0.0;
	if ( function_exists( 'farazsms_abandoned_table' ) ) {
		global $wpdb;
		$t = farazsms_abandoned_table();
		// ⚠️ مخرج هم باید درست باشد، نه فقط صورت.
		//
		// تا این بازبینی مخرج «status IN ('sent','recovered')» بود؛ چون وضعیتِ
		// recovered روی هر سفارشِ پرداخت‌شده نوشته می‌شود، مخرج با خریدهای عادی
		// باد می‌کرد. بدتر اینکه مخرج روی created_at و صورت روی recovered_at
		// بود — دو پایه‌ی زمانیِ متفاوت، که نرخ را حتی می‌توانست از ۱۰۰٪ رد کند.
		// حالا هر دو روی «پیامکی که در همین پنجره رفت» می‌ایستند.
		$ab_sent      = farazsms_dash_num( $t, "SELECT COUNT(*) FROM $t WHERE sent_at IS NOT NULL AND sent_at >= %s", array( $since ) );
		// همان تعریفِ واحدِ انتساب که داشبوردِ سودآوری هم از آن می‌خواند —
		// وضعیتِ خامِ `recovered` روی هر خریدِ عادی هم نوشته می‌شود.
		// ⚠️ بدونِ fallback: نسخه‌ی جایگزین همان شمارشِ غلطی بود که این باگ را
		// ساخت. تعریف در farazsms-config.php است که همیشه و پیش از این فایل
		// بار می‌شود، پس «شاید نباشد» حالتی نیست که باید پوشش داده شود.
		$ab_where     = farazsms_abandoned_attributed_where( array( 'sent_at >= %s' ) );
		// ⚠️ مبلغ از **سفارشِ واقعی** می‌آید، نه از ارزشِ سبد در لحظه‌ی رصد —
		// همان منبعی که صفحه‌ی سودآوری استفاده می‌کند. تا این بازبینی، دو صفحه
		// برای یک سبد دو مبلغِ متفاوت نشان می‌دادند.
		// ⚠️ گاردِ وجودِ جدول لازم است: کوئریِ خام برخلافِ farazsms_dash_num()
		// خودش این را چک نمی‌کند، و روی نصبِ تازه (جدولِ هنوز ساخته‌نشده) یک
		// خطای پایگاه‌داده روی صفحه‌ی مدیریت چاپ می‌شد.
		$ab_order_ids = array();
		if ( farazsms_dash_table_exists( $t ) && function_exists( 'farazsms_roi_countable_orders' ) ) {
			$ab_order_ids = (array) $wpdb->get_col( $wpdb->prepare(
				"SELECT recovered_order_id FROM $t WHERE $ab_where AND recovered_order_id > 0",
				$since
			) );
			$ab_order_ids = farazsms_roi_countable_orders( $ab_order_ids );
		}
		$ab_recovered = count( $ab_order_ids );
		$ab_revenue   = function_exists( 'farazsms_roi_sum_order_totals' )
			? farazsms_roi_sum_order_totals( $ab_order_ids )
			: 0;
	}
	$ab_rate = $ab_sent > 0 ? round( $ab_recovered / $ab_sent * 100 ) : 0;

	// ── کش‌بک ──
	$cb_count = 0.0; $cb_sum = 0.0;
	if ( function_exists( 'farazsms_cashback_credits_table' ) ) {
		$t = farazsms_cashback_credits_table();
		$cb_count = farazsms_dash_num( $t, "SELECT COUNT(*) FROM $t WHERE created_at >= %s", array( $since ) );
		$cb_sum   = farazsms_dash_num( $t, "SELECT COALESCE(SUM(amount),0) FROM $t WHERE created_at >= %s", array( $since ) );
	}

	// ── کوپن‌های افزونه (صادر/استفاده) — بر اساسِ نشانه‌های متا/پیشوندِ کد ──
	$cp_issued = (float) $wpdb->get_var(
		"SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p
		 WHERE p.post_type = 'shop_coupon' AND (
			EXISTS (SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id = p.ID AND m.meta_key = '_farazsms_birthday_coupon')
			OR EXISTS (SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id = p.ID AND m.meta_key = '_farazsms_spin_prize')
			OR p.post_title LIKE 'FZREVIEW-%'
		 )"
	);
	$cp_used = (float) $wpdb->get_var(
		"SELECT COALESCE(SUM(CAST(uc.meta_value AS UNSIGNED)),0)
		 FROM {$wpdb->posts} p
		 JOIN {$wpdb->postmeta} uc ON uc.post_id = p.ID AND uc.meta_key = 'usage_count'
		 WHERE p.post_type = 'shop_coupon' AND (
			EXISTS (SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id = p.ID AND m.meta_key = '_farazsms_birthday_coupon')
			OR EXISTS (SELECT 1 FROM {$wpdb->postmeta} m WHERE m.post_id = p.ID AND m.meta_key = '_farazsms_spin_prize')
			OR p.post_title LIKE 'FZREVIEW-%'
		 )"
	);

	$card = function ( $icon, $title, $big, $sub, $color ) {
		echo '<div style="flex:1 1 210px;background:#fff;border:1px solid #e1e1e1;border-radius:14px;padding:16px 18px;">';
		echo '<div style="font-size:12px;color:#9b9b9b;margin-bottom:6px;">' . esc_html( $icon . ' ' . $title ) . '</div>';
		echo '<div style="font-size:24px;font-weight:800;color:' . esc_attr( $color ) . ';font-variant-numeric:tabular-nums;">' . wp_kses_post( $big ) . '</div>';
		if ( $sub !== '' ) {
			echo '<div style="font-size:11.5px;color:#9b9b9b;margin-top:3px;">' . wp_kses_post( $sub ) . '</div>';
		}
		echo '</div>';
	};
	?>
	<div class="wrap" style="direction:rtl;max-width:1100px;">
		<h1 style="font-size:21px;">📈 بازدهی پیامک</h1>
		<p style="color:#9b9b9b;font-size:13px;margin:4px 0 14px;">نمای کلیِ فعالیتِ بازاریابیِ پیامکیِ افزونه در بازه‌ی انتخابی.</p>

		<div style="margin-bottom:16px;">
			<?php foreach ( array( 7 => '۷ روز', 30 => '۳۰ روز', 90 => '۹۰ روز' ) as $r => $lbl ) :
				$url = add_query_arg( array( 'page' => 'farazsms-marketing', 'range' => $r ), admin_url( 'admin.php' ) );
				$on  = ( $range === $r ); ?>
				<a href="<?php echo esc_url( $url ); ?>" style="display:inline-block;padding:6px 16px;border-radius:8px;font-size:13px;text-decoration:none;margin-left:6px;<?php echo $on ? 'background:#365891;color:#fff;font-weight:700;' : 'background:#eaeff7;color:#365891;'; ?>"><?php echo esc_html( $lbl ); ?></a>
			<?php endforeach; ?>
		</div>

		<div style="display:flex;flex-wrap:wrap;gap:14px;">
			<?php
			$card( '📨', 'پیامکِ ارسالی', number_format_i18n( $sms_total ), 'موفق: ' . number_format_i18n( $sms_ok ) . ' (' . $sms_rate . '٪)', '#263f67' );
			$card( '🛒', 'بازیابیِ سبدِ رها', number_format_i18n( $ab_recovered ) . ' سفارش', 'از ' . number_format_i18n( $ab_sent ) . ' پیامک (' . $ab_rate . '٪)', '#0c9765' );
			$card( '💰', 'درآمدِ بازیابیِ سبد', esc_html( farazsms_dash_price( $ab_revenue ) ), 'ارزشِ سبدهای بازگشته', '#0c9765' );
			$card( '⭐', 'نظرسنجی', number_format_i18n( $sv_reviews ) . ' نظر', 'از ' . number_format_i18n( $sv_sent ) . ' ارسال (' . $sv_rate . '٪ تبدیل)', '#365891' );
			$card( '🎡', 'گردونهٔ شانس', number_format_i18n( $spin_players ) . ' شرکت', number_format_i18n( $spin_winners ) . ' برنده', '#365891' );
			$card( '📰', 'خبرنامه', number_format_i18n( $nl_total ) . ' مشترک', '+' . number_format_i18n( $nl_new ) . ' جدید در این بازه', '#0ea5e9' );
			$card( '🎁', 'کش‌بکِ اعطاشده', number_format_i18n( $cb_count ) . ' مورد', 'جمع: ' . esc_html( farazsms_dash_price( $cb_sum ) ), '#e2a916' );
			$card( '🏷️', 'کوپن‌های افزونه', number_format_i18n( $cp_issued ) . ' صادر', number_format_i18n( $cp_used ) . ' بار استفاده', '#e11d48' );
			?>
		</div>

		<div style="background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;padding:12px 16px;border-radius:10px;margin-top:18px;font-size:12.5px;line-height:1.9;">
			💡 «درآمدِ بازیابیِ سبد» تمیزترین عددِ درآمدِ مستقیمِ منتسب به پیامک است (سبدهایی که پس از پیامکِ یادآوری به سفارش تبدیل شدند). «کوپن‌های افزونه» شاملِ کوپن‌های تولد، گردونه و پاداشِ نظر است.
			<br>برای جزئیاتِ تک‌به‌تکِ ارسال‌ها به «🩺 تشخیص ارسال» بروید.
		</div>
	</div>
	<?php
}
