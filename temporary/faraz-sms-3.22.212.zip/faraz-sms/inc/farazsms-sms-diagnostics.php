<?php
/**
 * SMS Diagnostics — v3.21.91
 *
 * لاگِ متمرکزِ ارسالِ پیامک‌های پترنی + صفحه‌ی «تشخیصِ ارسال». هدف: پاسخ به دردِ مشترکِ
 * «نمی‌دانم پیامک ارسال شد یا نه» (تیکت‌های نظرسنجی/تولد/موجودی/سبد رها). تمامِ ارسال‌های
 * پترنی از farazsms_sms_send_pattern عبور می‌کنند و همان‌جا اینجا لاگ می‌شوند.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_SEND_DIAG_DB_VERSION = '1.1.0';

function farazsms_send_diag_table() {
	global $wpdb;
	return $wpdb->prefix . 'farazsms_send_diag';
}

function farazsms_send_diag_maybe_install() {
	if ( get_option( 'farazsms_send_diag_db' ) === FARAZSMS_SEND_DIAG_DB_VERSION ) {
		return;
	}
	if ( ! function_exists( 'dbDelta' ) ) {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	}
	global $wpdb;
	$table   = farazsms_send_diag_table();
	$collate = $wpdb->get_charset_collate();
	// v3.22.27: افزودنِ source (کدام قابلیت پیامک زد) و http_code (برای تشخیصِ timeout
	// در برابرِ خطای واقعیِ پنل). dbDelta روی جدولِ موجود این دو ستون را ALTER/ADD می‌کند.
	dbDelta( "CREATE TABLE $table (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		recipient VARCHAR(20) NOT NULL DEFAULT '',
		pattern_code VARCHAR(64) NOT NULL DEFAULT '',
		source VARCHAR(40) NOT NULL DEFAULT '',
		http_code SMALLINT NOT NULL DEFAULT 0,
		status VARCHAR(20) NOT NULL DEFAULT '',
		error VARCHAR(255) NOT NULL DEFAULT '',
		created_at DATETIME NOT NULL,
		PRIMARY KEY  (id),
		KEY created_at (created_at),
		KEY status (status)
	) $collate;" );
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
		update_option( 'farazsms_send_diag_db', FARAZSMS_SEND_DIAG_DB_VERSION, true );
	}
}
add_action( 'admin_init', 'farazsms_send_diag_maybe_install' );
// v3.22.36 (F7): روی init هم اجرا شود تا بعد از به‌روزرسانی، ستون‌های جدید (source/http_code)
// قبل از اولین ارسالِ فرانت‌اند (checkout/OTP/فرم) هم ساخته شوند — وگرنه insertِ آن ارسال‌ها
// روی ستونِ ناموجود شکست می‌خورد و ردیفِ لاگ گم می‌شد. maybe_install با تطبیقِ نسخه سریع
// early-return می‌کند، پس بارِ اضافه ندارد.
add_action( 'init', 'farazsms_send_diag_maybe_install' );

/**
 * ثبتِ یک ارسال. $result همان رشته‌ی خروجیِ farazsms_sms_send_pattern است
 * ('success' | 'api_error:…' | 'curl_error:…' | 'missing_params' | متن خام).
 *
 * @param string $recipient    شماره‌ی گیرنده.
 * @param string $pattern_code کدِ پترن.
 * @param mixed  $result       نتیجه (رشته‌ی خروجیِ سرویس یا true).
 * @param array  $context {
 *     اطلاعاتِ اضافی برای تشخیص (v3.22.27).
 *     @type string $source    قابلیتِ ارسال‌کننده، مثلاً 'login-otp' | 'pattern-service'.
 *     @type int    $http_code کدِ HTTP پاسخ (۰ = پاسخی نرسید/timeout).
 *     @type string $detail    توضیحِ خام (curl error یا بریده‌ی بدنه) برای دیباگ.
 * }
 */
function farazsms_send_diag_log( $recipient, $pattern_code, $result, $context = array() ) {
	// خاموش‌کردنِ لاگ با فیلتر (برای سایت‌هایی که نمی‌خواهند).
	if ( ! apply_filters( 'farazsms_send_diag_enabled', true ) ) {
		return;
	}
	global $wpdb;
	$table = farazsms_send_diag_table();
	// وضعیت و متنِ خطا — تصمیمِ واحد، در farazsms-diag-classify.php.
	$classified = farazsms_diag_classify_result( $result );
	$status     = $classified['status'];
	$error      = $classified['error'];

	// v3.22.27: اگر detailِ خام آمد و متنِ خطا خالی بود، از آن استفاده کن.
	$detail = isset( $context['detail'] ) ? (string) $context['detail'] : '';
	if ( $error === '' && $status !== 'success' && $detail !== '' ) {
		$error = $detail;
	}

	$ok = $wpdb->insert( $table, array(
		'recipient'    => substr( (string) $recipient, 0, 20 ),
		'pattern_code' => substr( (string) $pattern_code, 0, 64 ),
		'source'       => substr( isset( $context['source'] ) ? (string) $context['source'] : '', 0, 40 ),
		'http_code'    => isset( $context['http_code'] ) ? (int) $context['http_code'] : 0,
		'status'       => $status,
		'error'        => mb_substr( (string) $error, 0, 255 ),
		'created_at'   => current_time( 'mysql' ),
	) );

	// هرس: هر ~۵۰ درج، ردیف‌های قدیمی‌تر از ۲۰۰۰ تای اخیر را پاک کن تا جدول بی‌رشد نماند.
	if ( $ok && $wpdb->insert_id % 50 === 0 ) {
		$keep_id = (int) $wpdb->get_var( "SELECT id FROM $table ORDER BY id DESC LIMIT 1 OFFSET 2000" );
		if ( $keep_id > 0 ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE id < %d", $keep_id ) );
		}
	}
}

// ── صفحه‌ی ادمین ─────────────────────────────────────────────────────────
add_action( 'admin_menu', 'farazsms_send_diag_menu', 60 );
function farazsms_send_diag_menu() {
	add_submenu_page(
		'farazsms',
		__( 'تشخیص ارسال', 'farazsms' ),
		__( '🩺 تشخیص ارسال', 'farazsms' ),
		'manage_options',
		'farazsms-diagnostics',
		'farazsms_send_diag_render_page'
	);
}

function farazsms_send_diag_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی غیرمجاز.' );
	}
	farazsms_send_diag_maybe_install();
	global $wpdb;
	$table  = farazsms_send_diag_table();
	$filter = isset( $_GET['st'] ) ? sanitize_key( wp_unslash( $_GET['st'] ) ) : '';
	$search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';

	$where = ' WHERE 1=1';
	$args  = array();
	if ( in_array( $filter, array( 'success', 'api_error', 'curl_error', 'failed', 'queued', 'invalid_mobile', 'not_sent' ), true ) ) {
		$where .= ' AND status = %s';
		$args[] = $filter;
	}
	if ( $search !== '' ) {
		$like   = '%' . $wpdb->esc_like( $search ) . '%';
		$where .= ' AND (recipient LIKE %s OR pattern_code LIKE %s)';
		$args[] = $like;
		$args[] = $like;
	}
	$sql  = "SELECT * FROM $table $where ORDER BY id DESC LIMIT 200";
	$rows = empty( $args ) ? $wpdb->get_results( $sql, ARRAY_A ) : $wpdb->get_results( $wpdb->prepare( $sql, ...$args ), ARRAY_A );

	// آمارِ ۲۴ ساعتِ اخیر — از تجمیعِ مشترک.
	//
	// ⚠️ این کوئری تا v3.22.212 همین‌جا و درون‌خطی بود، یعنی دانشِ «چند ارسال
	// شکست خورده» فقط وقتی وجود داشت که کسی این صفحه را باز کند. حالا همان
	// تجمیع در farazsms-send-health.php است و دیده‌بان هم از همان می‌خواند —
	// یک عدد، دو مصرف‌کننده.
	$stat = farazsms_send_health_totals( 24 );
	?>
	<div class="wrap" style="direction:rtl; font-family:inherit; max-width:1100px;">
		<h1 style="font-size:21px;">🩺 تشخیص ارسال پیامک</h1>
		<p style="color:#9b9b9b; font-size:13px; margin:4px 0 16px;">اینجا نتیجه‌ی واقعیِ همه‌ی پیامک‌های پترنیِ افزونه ثبت می‌شود — برای اینکه بفهمید یک پیامک واقعاً ارسال شد یا نه و اگر نشد، چرا.</p>

		<div style="display:flex; gap:12px; flex-wrap:wrap; margin-bottom:16px;">
			<div style="flex:1 1 150px; background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:14px 16px;">
				<div style="font-size:24px; font-weight:800;"><?php echo (int) ( $stat['total'] ?? 0 ); ?></div>
				<div style="font-size:12px; color:#9b9b9b;">کلِ ارسال (۲۴ ساعت)</div>
			</div>
			<div style="flex:1 1 150px; background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:14px 16px;">
				<div style="font-size:24px; font-weight:800; color:#0c9765;"><?php echo (int) ( $stat['ok'] ?? 0 ); ?></div>
				<div style="font-size:12px; color:#9b9b9b;">موفق</div>
			</div>
			<div style="flex:1 1 150px; background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:14px 16px;">
				<div style="font-size:24px; font-weight:800; color:#d52a16;"><?php echo (int) ( $stat['bad'] ?? 0 ); ?></div>
				<div style="font-size:12px; color:#9b9b9b;">ناموفق</div>
			</div>
		</div>

		<form method="get" action="" style="margin-bottom:14px; display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
			<input type="hidden" name="page" value="farazsms-diagnostics">
			<input type="text" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="🔍 شماره یا کد پترن" style="padding:8px 12px; border:1px solid #e1e1e1; border-radius:8px; font-size:13px; direction:ltr; text-align:left;">
			<select name="st" style="padding:8px 12px; border:1px solid #e1e1e1; border-radius:8px; font-size:13px;">
				<option value="">همه‌ی وضعیت‌ها</option>
				<option value="success" <?php selected( $filter, 'success' ); ?>>موفق</option>
				<option value="api_error" <?php selected( $filter, 'api_error' ); ?>>خطای پنل (api_error)</option>
				<option value="not_sent" <?php selected( $filter, 'not_sent' ); ?>>ارسال نشد (بدونِ تماس با پنل)</option>
				<option value="curl_error" <?php selected( $filter, 'curl_error' ); ?>>خطای ارتباط (curl_error)</option>
				<option value="failed" <?php selected( $filter, 'failed' ); ?>>ناموفقِ نامشخص</option>
				<option value="queued" <?php selected( $filter, 'queued' ); ?>>در صف</option>
				<option value="invalid_mobile" <?php selected( $filter, 'invalid_mobile' ); ?>>شماره نامعتبر</option>
			</select>
			<button type="submit" class="button">فیلتر</button>
		</form>

		<div style="background:#faf1da; border:1px solid #e2a916; color:#83620d; padding:10px 14px; border-radius:8px; margin-bottom:14px; font-size:12px; line-height:1.9;">
			💡 خطای <code dir="ltr">api_error: pattern_not_found</code> یا مشابه یعنی کدِ پترن روی پنلِ فراز وجود ندارد یا هنوز <strong>تأیید نشده</strong> (تأیید ۱ تا ۲۴ ساعت طول می‌کشد). ارسال‌های زمان‌بندی‌شده (نظرسنجی/سبد رها/تولد) روی صفِ زمان‌بندی اجرا می‌شوند؛ اگر چیزی اینجا نیست، ممکن است کرون/Action Scheduler اجرا نشده باشد — به «ابزارها ← Scheduled Actions» سر بزنید.
		</div>

		<div style="overflow-x:auto; background:#fff; border:1px solid #e1e1e1; border-radius:12px;">
			<table style="width:100%; border-collapse:collapse; font-size:12.5px; min-width:680px;">
				<thead><tr style="background:#f5f8fe; text-align:right;">
					<th style="padding:10px 12px; color:#4d4d4d;">زمان</th>
					<th style="padding:10px 12px; color:#4d4d4d;">گیرنده</th>
					<th style="padding:10px 12px; color:#4d4d4d;">قابلیت</th>
					<th style="padding:10px 12px; color:#4d4d4d;">کد پترن</th>
					<th style="padding:10px 12px; color:#4d4d4d;">HTTP</th>
					<th style="padding:10px 12px; color:#4d4d4d;">وضعیت</th>
					<th style="padding:10px 12px; color:#4d4d4d;">خطا</th>
				</tr></thead>
				<tbody>
				<?php if ( empty( $rows ) ) : ?>
					<tr><td colspan="7" style="padding:22px; text-align:center; color:#9b9b9b;">هنوز ارسالی ثبت نشده.</td></tr>
				<?php else : foreach ( $rows as $r ) :
					$jdate  = farazsms_send_reports_to_jalali( $r['created_at'] );
					$is_ok  = $r['status'] === 'success';
					// «در صف» شکست نیست — نه رنگِ قرمز بگیرد نه برچسبِ انگلیسی.
					$is_q   = $r['status'] === 'queued';
					$is_im  = $r['status'] === 'invalid_mobile';
					$badge  = $is_ok ? '#0c9765' : ( $is_q ? '#83620d' : ( $is_im ? '#83620d' : '#d52a16' ) );
					$label  = $is_ok ? 'موفق ✓' : ( $is_q ? 'در صف ⏳' : ( $is_im ? 'شماره نامعتبر' : $r['status'] ) );
					$src_map = array( 'login-otp' => '🔐 ورود/OTP', 'pattern-service' => 'پترن' );
					$src    = ( isset( $r['source'] ) && $r['source'] !== '' ) ? ( isset( $src_map[ $r['source'] ] ) ? $src_map[ $r['source'] ] : $r['source'] ) : '—';
					$hc     = isset( $r['http_code'] ) ? (int) $r['http_code'] : 0;
					$hc_col = ( $hc === 0 ) ? '#83620d' : ( ( $hc >= 200 && $hc < 300 ) ? '#0c9765' : '#d52a16' );
					?>
					<tr style="border-top:1px solid #f5f8fe;">
						<td style="padding:9px 12px; color:#9b9b9b; font-size:11.5px; white-space:nowrap;"><?php echo esc_html( $jdate ); ?></td>
						<td style="padding:9px 12px; direction:ltr; text-align:right; font-family:Menlo,monospace;"><?php echo esc_html( $r['recipient'] ); ?></td>
						<td style="padding:9px 12px; color:#4d4d4d; font-size:11.5px; white-space:nowrap;"><?php echo esc_html( $src ); ?></td>
						<td style="padding:9px 12px; direction:ltr; text-align:right; font-family:Menlo,monospace; color:#4d4d4d;"><?php echo esc_html( $r['pattern_code'] ); ?></td>
						<td style="padding:9px 12px; direction:ltr; text-align:center; font-family:Menlo,monospace; font-weight:700; color:<?php echo esc_attr( $hc_col ); ?>;"><?php echo $hc === 0 ? '—' : (int) $hc; ?></td>
						<td style="padding:9px 12px;"><span style="color:<?php echo esc_attr( $badge ); ?>; font-weight:700;"><?php echo esc_html( $label ); ?></span></td>
						<td style="padding:9px 12px; color:#b32817; font-size:11.5px; direction:ltr; text-align:right; word-break:break-all;"><?php echo esc_html( $r['error'] ); ?></td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>
	</div>
	<?php
}
