<?php
/**
 * گاردِ کدگذاری (encoder loader guard).
 *
 * هدف: مخفی‌کردنِ سورسِ فایل‌های حساس با encode (ionCube یا SourceGuardian) — ولی
 * بدونِ اینکه روی هاست‌هایی که loaderِ آن encoder را ندارند، سایت سفید/فاتال شود.
 *
 * این فایل خودش هرگز encode نمی‌شود (همیشه plaintext بماند) چون باید قبل از هر
 * فایلِ encode-شده اجرا شود و تصمیم بگیرد.
 *
 * منطق farazsms_require_protected():
 *   - فایلِ plaintext  → دقیقاً مثلِ require_once عادی (تا قبل از encode، رفتار عوض نشود).
 *   - فایلِ encode-شده + loader موجود → require می‌شود (اجرا می‌شود).
 *   - فایلِ encode-شده + loader غایب  → skip می‌شود + برای اخطار ثبت می‌گردد (به‌جای فاتال).
 *
 * پس «فایل‌های حساس» فقط ماژول‌های اختیاری‌اند که اگر غیرفعال شوند، هسته‌ی افزونه
 * (ارسالِ پیامک) همچنان کار می‌کند. هرگز فایلِ هسته‌ی حیاتی را به این فهرست نبرید،
 * وگرنه «fallback» بی‌معنا می‌شود.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * آیا loaderِ یکی از encoderها روی این سرور فعال است؟
 *
 * @return bool
 */
function farazsms_encoder_loader_present() {
	static $present = null;
	if ( $present !== null ) {
		return $present;
	}
	$present = extension_loaded( 'ionCube Loader' )
		|| extension_loaded( 'SourceGuardian' )
		|| extension_loaded( 'sourceguardian' );
	return $present;
}

/**
 * آیا این فایل به‌صورتِ encode-شده است؟ (تشخیص از روی امضای ابتدای فایل.)
 *
 * SourceGuardian: «return sg_load('...')» — امضای sg_load.
 * ionCube: بلوکِ «if(!extension_loaded('ionCube Loader'))» در ابتدای فایل.
 *
 * @param string $path
 * @return bool
 */
function farazsms_file_is_encoded( $path ) {
	if ( ! is_readable( $path ) ) {
		return false;
	}
	$head = @file_get_contents( $path, false, null, 0, 400 );
	if ( $head === false || $head === '' ) {
		return false;
	}
	return strpos( $head, 'sg_load' ) !== false
		|| strpos( $head, 'ionCube' ) !== false
		|| strpos( $head, 'IonCube' ) !== false;
}

$GLOBALS['farazsms_skipped_protected'] = array();

/**
 * require امنِ یک فایلِ احتمالاً encode-شده.
 *
 * @param string $abs_path مسیرِ کاملِ فایل.
 * @return bool true اگر بارگذاری شد، false اگر skip/ناموجود.
 */
function farazsms_require_protected( $abs_path ) {
	if ( ! is_readable( $abs_path ) ) {
		return false;
	}
	if ( farazsms_file_is_encoded( $abs_path ) && ! farazsms_encoder_loader_present() ) {
		// فایلِ قفل‌شده ولی loader نیست → اجرا نکن (تا فاتال نشود)؛ برای اخطار ثبت کن.
		$GLOBALS['farazsms_skipped_protected'][] = basename( $abs_path );
		return false;
	}
	require_once $abs_path;
	return true;
}

/**
 * اخطارِ پیشخوان اگر قابلیتی به‌خاطرِ نبودِ loader غیرفعال شده باشد.
 */
add_action( 'admin_notices', 'farazsms_encoder_missing_notice' );
function farazsms_encoder_missing_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	if ( empty( $GLOBALS['farazsms_skipped_protected'] ) ) {
		return;
	}
	$count = count( array_unique( $GLOBALS['farazsms_skipped_protected'] ) );
	?>
	<div class="notice notice-warning" style="padding:12px 16px;">
		<p style="font-size:13px; line-height:2; margin:0 0 6px; color:#83620d; font-weight:700;">
			⚠️ برخی قابلیت‌های افزونه فراز اس ام اس روی این سرور غیرفعال شده‌اند
		</p>
		<p style="font-size:12.5px; line-height:2; margin:0; color:#3f2d00;">
			<?php echo (int) $count; ?> ماژولِ افزونه به‌صورتِ کدگذاری‌شده ارائه شده‌اند و برای اجرا به یکی از
			<span style="direction:ltr; unicode-bidi:isolate;">ionCube Loader</span>
			یا
			<span style="direction:ltr; unicode-bidi:isolate;">SourceGuardian Loader</span>
			نیاز دارند که روی هاستِ شما نصب نیست. هسته‌ی افزونه (ارسالِ پیامک) سالم کار می‌کند،
			ولی برای فعال‌شدنِ این قابلیت‌ها از پشتیبانیِ هاست بخواهید یکی از این loaderها را فعال کند.
		</p>
	</div>
	<?php
}
