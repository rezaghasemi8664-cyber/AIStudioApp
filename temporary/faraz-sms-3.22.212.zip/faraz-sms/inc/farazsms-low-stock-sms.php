<?php
/**
 * Low / Out-of-stock ADMIN SMS — v3.21.88 (Item 6)
 *
 * قابلیتِ بومیِ افزونه: وقتی موجودیِ محصول کم می‌شود (woocommerce_low_stock) یا تمام می‌شود
 * (woocommerce_no_stock)، به شماره‌ی مدیر پیامک می‌فرستد. قبلاً این قابلیت وجود نداشت و
 * تنها متکی به افزونه‌ی PWSMS بود؛ حالا مستقل است.
 *
 * پیش‌نیاز ووکامرس: «مدیریتِ موجودی» باید فعال باشد و آستانه‌ی کم‌موجودی تنظیم شده باشد،
 * وگرنه خودِ ووکامرس این اکشن‌ها را fire نمی‌کند.
 *
 * متغیرهای پترن: %product% (نام محصول)، %stock% (موجودیِ باقی‌مانده). آدرسِ سایت خودکار افزوده می‌شود.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/** تنظیمات + پیش‌فرض‌ها. */
function farazsms_low_stock_get_settings() {
	$low = get_option( 'farazsms_low_stock_settings', array() );
	if ( ! is_array( $low ) ) {
		$low = array();
	}
	$no = get_option( 'farazsms_nostock_settings', array() );
	if ( ! is_array( $no ) ) {
		$no = array();
	}
	return array(
		'enabled'         => isset( $low['enabled'] ) ? $low['enabled'] : '1', // پیش‌فرض روشن
		'admin_phones'    => isset( $low['admin_phones'] ) ? (string) $low['admin_phones'] : '',
		'low_pattern'     => isset( $low['pattern_code'] ) ? (string) $low['pattern_code'] : '',
		'low_message'     => isset( $low['message'] ) && $low['message'] !== ''
			? (string) $low['message']
			: "هشدارِ موجودی\nموجودیِ این محصول کم شد:\n%product%\nموجودیِ باقی‌مانده: %stock%",
		'no_pattern'      => isset( $no['pattern_code'] ) ? (string) $no['pattern_code'] : '',
		'no_message'      => isset( $no['message'] ) && $no['message'] !== ''
			? (string) $no['message']
			: "اتمامِ موجودی\nموجودیِ این محصول تمام شد:\n%product%",
	);
}

/** لیستِ شماره‌های مدیر (با fallback به شماره‌ی مالکِ پنل). */
function farazsms_low_stock_recipients( $settings ) {
	$raw = trim( (string) $settings['admin_phones'] );
	if ( $raw === '' ) {
		$profile = farazsms_get_profile();
		if ( is_array( $profile ) && ! empty( $profile['mobile'] ) ) {
			$raw = (string) $profile['mobile'];
		}
	}
	$parts = preg_split( '/[,،\s]+/u', $raw );
	$out   = array();
	foreach ( (array) $parts as $p ) {
		$p = trim( $p );
		if ( $p === '' ) {
			continue;
		}
		$out[] = farazsms_normalize_phone( $p );
	}
	return array_values( array_unique( array_filter( $out ) ) );
}

/** ارسالِ پیامکِ موجودی برای یک محصول. $event = 'low' | 'no'. */
function farazsms_low_stock_notify( $product, $event ) {
	if ( ! ( $product instanceof WC_Product ) ) {
		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $product ) : null;
	}
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$settings = farazsms_low_stock_get_settings();
	if ( $settings['enabled'] !== '1' ) {
		return;
	}
	$pattern = $event === 'no' ? $settings['no_pattern'] : $settings['low_pattern'];
	if ( trim( (string) $pattern ) === '' ) {
		return; // پترن ساخته نشده.
	}

	$product_id = $product->get_id();
	// جلوگیری از پیامکِ تکراری: هر محصول/رویداد حداکثر یک‌بار در ۱۲ ساعت.
	$lock_key = 'farazsms_stock_sms_' . $event . '_' . $product_id;
	if ( get_transient( $lock_key ) ) {
		return;
	}
	set_transient( $lock_key, 1, 12 * HOUR_IN_SECONDS );

	$recipients = farazsms_low_stock_recipients( $settings );
	if ( empty( $recipients ) ) {
		return;
	}

	$stock = $product->get_stock_quantity();
	$attrs = array(
		'product' => (string) $product->get_name(),
		'stock'   => $stock === null ? '0' : (string) $stock,
	);

	// این تابع روی هوک‌های موجودی اجرا می‌شود و کاهشِ موجودی وسطِ تسویه رخ
	// می‌دهد — یعنی مشتری منتظرِ همین درخواست است. ارسال به ازای هر گیرنده
	// نباید روی آن انجام شود. ادعا (ترنزینتِ ۱۲ساعته) پیش از این نقطه گرفته
	// شده، پس صف‌گذاری تکرار نمی‌سازد.
	foreach ( $recipients as $mobile ) {
		farazsms_queue_send( 'low-stock', $mobile, $pattern, $attrs, array( 'event' => $event ) );
	}
}

// مسیرِ اولِ ووکامرس: این اکشن‌ها هنگامِ کاهشِ موجودی از طریقِ سفارش fire می‌شوند
// (فقط اگر مدیریتِ موجودی روشن باشد و آستانه تنظیم شده باشد).
add_action( 'woocommerce_low_stock', function ( $product ) {
	farazsms_low_stock_notify( $product, 'low' );
}, 10, 1 );
add_action( 'woocommerce_no_stock', function ( $product ) {
	farazsms_low_stock_notify( $product, 'no' );
}, 10, 1 );

/**
 * مسیرِ دومِ مطمئن (v3.21.94): برخی سایت‌ها گزارش دادند که پیامکِ موجودی ارسال نمی‌شود؛ علت این
 * است که اکشن‌های بالا فقط هنگامِ کاهشِ موجودی از طریقِ «سفارش» fire می‌شوند، نه هنگامِ ویرایشِ
 * دستیِ موجودی، و به تنظیماتِ اعلانِ ووکامرس هم وابسته‌اند. اینجا خودمان روی هر تغییرِ موجودی
 * (دستی یا سفارش) آستانه را چک می‌کنیم و مستقل از تنظیماتِ ووکامرس پیامک می‌دهیم.
 */
add_action( 'woocommerce_product_set_stock', 'farazsms_low_stock_on_stock_change', 20, 1 );
add_action( 'woocommerce_variation_set_stock', 'farazsms_low_stock_on_stock_change', 20, 1 );
function farazsms_low_stock_on_stock_change( $product ) {
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	if ( ! $product->managing_stock() ) {
		return; // بدونِ مدیریتِ موجودی، عددِ موجودی معنا ندارد.
	}
	$qty = $product->get_stock_quantity();
	if ( $qty === null || $qty === '' ) {
		return;
	}
	$qty = (float) $qty;
	$pid = $product->get_id();

	// v3.21.95: فقط روی «کاهشِ» موجودی هشدار بده، نه افزایش/شارژِ مجدد/ایجاد. موجودیِ قبلی را در
	// متای محصول نگه می‌داریم (مستقیم با update_post_meta تا save و در نتیجه re-trigger نشود).
	$prev_raw = get_post_meta( $pid, '_farazsms_last_stock_qty', true );
	$has_prev = ( $prev_raw !== '' && $prev_raw !== null );
	$prev     = (float) $prev_raw;
	update_post_meta( $pid, '_farazsms_last_stock_qty', $qty );
	if ( ! $has_prev || $qty >= $prev ) {
		return; // بارِ اول یا افزایش/بدونِ‌تغییر → هشدار نده.
	}

	// آستانه‌ی کم‌موجودی: تنظیمِ محصول، وگرنه تنظیمِ سراسریِ ووکامرس (پیش‌فرض ۲).
	$threshold = get_option( 'woocommerce_notify_low_stock_amount', 2 );
	if ( function_exists( 'wc_get_low_stock_amount' ) ) {
		$threshold = wc_get_low_stock_amount( $product );
	}
	$threshold = ( $threshold === '' || $threshold === null ) ? 2.0 : (float) $threshold;

	if ( $qty <= 0 ) {
		// بک‌اوردر: محصول هنوز قابلِ فروش است → «اتمامِ موجودی» نفرست.
		if ( method_exists( $product, 'backorders_allowed' ) && $product->backorders_allowed() ) {
			return;
		}
		farazsms_low_stock_notify( $product, 'no' );
	} elseif ( $qty <= $threshold ) {
		farazsms_low_stock_notify( $product, 'low' );
	}
}

// وقتی محصول دوباره موجود شد، قفلِ ضدِتکرار را پاک کن تا دفعه‌ی بعد که کم/تمام شد دوباره خبر بدهد.
add_action( 'woocommerce_product_set_stock_status', function ( $product_id, $status ) {
	if ( $status === 'instock' ) {
		delete_transient( 'farazsms_stock_sms_low_' . $product_id );
		delete_transient( 'farazsms_stock_sms_no_' . $product_id );
	}
}, 10, 2 );

// ── Admin UI — بخش داخلِ صفحه‌ی «پیامک سفارشات (بومی)» ────────────────────
// v3.21.94: از صفحه‌ی تنظیماتِ کلی به صفحه‌ی سفارشاتِ بومی منتقل شد.
add_action( 'farazsms_orders_sms_extra_sections', 'farazsms_low_stock_render_section' );

add_action( 'admin_init', 'farazsms_low_stock_handle_save' );
function farazsms_low_stock_handle_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ( $_SERVER['REQUEST_METHOD'] ?? '' ) !== 'POST' || empty( $_POST['farazsms_low_stock_save'] ) ) {
		return;
	}
	if ( ( isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '' ) !== 'farazsms-orders-sms' ) {
		return;
	}
	check_admin_referer( 'farazsms_low_stock_settings', 'farazsms_low_stock_nonce' );

	$low = get_option( 'farazsms_low_stock_settings', array() );
	if ( ! is_array( $low ) ) {
		$low = array();
	}
	$no = get_option( 'farazsms_nostock_settings', array() );
	if ( ! is_array( $no ) ) {
		$no = array();
	}
	$low['enabled']      = isset( $_POST['low_stock_enabled'] ) ? '1' : '0';
	$low['admin_phones'] = sanitize_text_field( wp_unslash( $_POST['low_stock_admin_phones'] ?? '' ) );
	$low['pattern_code'] = sanitize_text_field( wp_unslash( $_POST['low_stock_pattern_code'] ?? '' ) );
	$no['pattern_code']  = sanitize_text_field( wp_unslash( $_POST['no_stock_pattern_code'] ?? '' ) );
	update_option( 'farazsms_low_stock_settings', $low, false );
	update_option( 'farazsms_nostock_settings', $no, false );

	wp_safe_redirect( add_query_arg( 'farazsms_low_stock_saved', '1', admin_url( 'admin.php?page=farazsms-orders-sms' ) ) );
	exit;
}

function farazsms_low_stock_render_section() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! class_exists( 'WooCommerce' ) && ! function_exists( 'wc_get_product' ) ) {
		return;
	}
	$s        = farazsms_low_stock_get_settings();
	$saved_ok = isset( $_GET['farazsms_low_stock_saved'] ) && $_GET['farazsms_low_stock_saved'] === '1';

	$phones_value = (string) $s['admin_phones'];
	if ( trim( $phones_value ) === '' ) {
		$profile = farazsms_get_profile();
		if ( is_array( $profile ) && ! empty( $profile['mobile'] ) ) {
			$phones_value = (string) $profile['mobile'];
		}
	}
	?>
	<div style="direction:rtl; font-family:inherit; margin-top:24px;">
		<?php if ( $saved_ok ) : ?>
			<div style="background:#e2f8f0; border:1px solid #10c282; color:#096d49; padding:10px 14px; border-radius:8px; margin-bottom:14px;">✓ تنظیماتِ پیامکِ موجودی ذخیره شد.</div>
		<?php endif; ?>
		<div style="background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:22px 24px;">
			<div style="display:flex; align-items:center; gap:10px; margin-bottom:14px;">
				<div style="width:38px; height:38px; background:linear-gradient(135deg,#e2a916 0%,#e2a916 100%); color:#fff; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:18px;">📦</div>
				<div>
					<h3 style="margin:0; font-size:15px; font-weight:700; color:#263f67;">پیامکِ کاهش/اتمامِ موجودی به مدیر</h3>
					<p style="margin:2px 0 0; font-size:11.5px; color:#9b9b9b;">هنگام کم‌شدن یا تمام‌شدنِ موجودیِ محصول، به شماره‌ی مدیر پیامک می‌رود.</p>
				</div>
			</div>

			<div style="background:#faf1da; border:1px solid #e2a916; color:#83620d; padding:10px 14px; border-radius:8px; margin-bottom:14px; font-size:12px; line-height:1.9;">
				⚠ نیازمندِ «مدیریتِ موجودی»ِ ووکامرس: در «ووکامرس ← تنظیمات ← محصولات ← موجودی» گزینه‌ی مدیریتِ موجودی و آستانه‌ی کم‌موجودی باید فعال باشد، وگرنه ووکامرس این هشدارها را تولید نمی‌کند.
			</div>

			<!-- v3.22.20: بدونِ فرمِ جدا — داخلِ فرمِ صفحه‌ی سفارشات است و با همان دکمه‌ی ذخیره ذخیره می‌شود. -->
			<input type="hidden" name="farazsms_low_stock_present" value="1">

				<label style="display:flex; align-items:center; gap:12px; padding:12px 16px; background:<?php echo $s['enabled']==='1' ? '#e2f8f0' : '#faf1da'; ?>; border:1px solid <?php echo $s['enabled']==='1' ? '#10c282' : '#e2a916'; ?>; border-radius:10px; cursor:pointer; margin-bottom:14px;">
					<input type="checkbox" class="farazsms-toggle" name="low_stock_enabled" value="1" <?php checked( $s['enabled'], '1' ); ?> style="margin:0; width:18px; height:18px;">
					<span style="flex:1; font-size:13px; font-weight:600;">فعال بودنِ پیامکِ موجودی به مدیر
						<?php echo $s['enabled']==='1' ? '<span style="background:#0c9765; color:#fff; font-size:10px; padding:2px 8px; border-radius:4px; margin-right:8px;">فعال ✓</span>' : '<span style="background:#e2a916; color:#fff; font-size:10px; padding:2px 8px; border-radius:4px; margin-right:8px;">غیرفعال</span>'; ?>
					</span>
				</label>

				<label style="display:block; font-size:13px; font-weight:700; color:#4d4d4d; margin-bottom:6px;">شماره‌ی مدیر (گیرنده)</label>
				<input type="text" name="low_stock_admin_phones" value="<?php echo esc_attr( $phones_value ); ?>" placeholder="09120000000" style="width:100%; max-width:360px; padding:9px 12px; border:1px solid #e1e1e1; border-radius:8px; font-size:13px; direction:ltr; text-align:left; font-family:Menlo,Consolas,monospace; margin-bottom:6px;">
				<p style="margin:0 0 16px; font-size:11.5px; color:#9b9b9b;">چند شماره را با «،» جدا کنید.</p>

				<div style="font-size:13px; font-weight:700; color:#263f67; margin:10px 0 4px;">۱) پترنِ «کاهشِ موجودی»</div>
				<input type="hidden" name="low_stock_pattern_code" value="<?php echo esc_attr( $s['low_pattern'] ); ?>">
				<?php
				farazsms_feature_pattern_builder_ui( 'low_stock', $s['low_message'], array( '%product%', '%stock%' ), 'low_stock_pattern_code' );
				?>

				<div style="font-size:13px; font-weight:700; color:#263f67; margin:16px 0 4px;">۲) پترنِ «اتمامِ موجودی»</div>
				<input type="hidden" name="no_stock_pattern_code" value="<?php echo esc_attr( $s['no_pattern'] ); ?>">
				<?php
				farazsms_feature_pattern_builder_ui( 'no_stock', $s['no_message'], array( '%product%' ), 'no_stock_pattern_code' );
				?>

		</div>
	</div>
	<?php
}
