<?php
/**
 * موتورِ اورلیِ مشترکِ فراز (Overlay Engine) — فاز ۱ زیرساخت.
 *
 * یک «پوسته»ی واحد + موتورِ تریگر + بارگذارِ تنبل + تم، که همه‌ی پاپ‌آپ‌ها/مودال‌های
 * افزونه (گردونه‌ی شانس، لیدمگنت، «موجود شد خبرم کن»، بازخورد، تولد، خبرنامه، …) رویش
 * می‌نشینند. هدف: یک قفلِ اسکرولِ درست به‌جای چند کپیِ ناهماهنگ، یک موتورِ تریگرِ مشترک
 * (تأخیر/اسکرول/خروج)، بارگذاریِ تنبل (سایت هیچ‌وقت کند نمی‌شود) و تم‌سازیِ رنگِ مشترک.
 *
 * قرارداد: هر فیچر با farazsms_overlay_register() ثبت می‌شود؛ کدِ سنگینِ فیچر یک chunkِ
 * جداست که فقط با شلیکِ تریگر (یا کلیک) تزریق می‌شود و FarazOverlay.define(id, impl) را
 * صدا می‌زند. تا وقتی هیچ فیچری ثبت نکند، این فایل کاملاً بی‌اثر است — هیچ assetی enqueue
 * نمی‌شود.
 *
 * @package farazsms
 * @since   3.22.133
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * رجیستریِ درون‌حافظه‌ایِ اورلی‌های ثبت‌شده (بر اساسِ id).
 *
 * @return array مرجع به رجیستری.
 */
function &farazsms_overlay_registry() {
	static $registry = array();
	return $registry;
}

/**
 * ثبتِ یک اورلی روی موتورِ مشترک.
 *
 * @param array $args {
 *     @type string          $id          شناسه‌ی یکتا (اجباری).
 *     @type string          $chunk       URLِ فایلِ JSِ فیچر که lazy تزریق می‌شود (اجباری).
 *     @type array           $trigger     ['type'=>on_load|delay|scroll|exit_intent|click, 'value'=>N].
 *     @type string          $frequency   always|session|day|once.
 *     @type array           $theme       نگاشتِ توکنِ رنگ → مقدار (accent, btn_bg, …).
 *     @type callable|string $render_gate تابعی که true/false برمی‌گرداند؛ فقط اگر true بود اورلی فعال است.
 * }
 */
function farazsms_overlay_register( array $args ) {
	if ( empty( $args['id'] ) || empty( $args['chunk'] ) ) {
		return;
	}
	$registry = &farazsms_overlay_registry();
	$id       = sanitize_key( $args['id'] );

	$registry[ $id ] = wp_parse_args(
		$args,
		array(
			'id'          => $id,
			'trigger'     => array( 'type' => 'on_load' ),
			'frequency'   => 'always',
			'theme'       => array(),
			'render_gate' => '__return_true',
		)
	);
	$registry[ $id ]['id'] = $id;
}

/**
 * فهرستِ اورلی‌هایی که در این درخواست فعال‌اند (render_gate پاس شده) — آماده‌ی JS.
 *
 * @return array
 */
function farazsms_overlay_active_configs() {
	$out = array();
	foreach ( farazsms_overlay_registry() as $id => $ov ) {
		$gate = isset( $ov['render_gate'] ) ? $ov['render_gate'] : '__return_true';
		if ( is_callable( $gate ) && ! call_user_func( $gate ) ) {
			continue;
		}
		$out[] = array(
			'id'        => $id,
			'trigger'   => isset( $ov['trigger'] ) ? $ov['trigger'] : array( 'type' => 'on_load' ),
			'frequency' => isset( $ov['frequency'] ) ? (string) $ov['frequency'] : 'always',
			'chunk'     => esc_url_raw( $ov['chunk'] ),
			// (object) تا در JS حتی اگر خالی باشد، {} شود نه [].
			'theme'     => (object) ( isset( $ov['theme'] ) && is_array( $ov['theme'] ) ? $ov['theme'] : array() ),
		);
	}
	return $out;
}

/**
 * register کردنِ assetِ هسته — زود (priority 1). فقط register (خروجی ندارد) تا فیچرهای دیگر
 * (مثلِ لیدمگنت که از ابزارِ onTrigger/lockScroll استفاده می‌کند) بتوانند 'farazsms-overlay' را
 * به‌عنوان dependency اعلام کنند، حتی اگر اورلیِ shellِ فعالی نباشد.
 */
function farazsms_overlay_register_assets() {
	$ver = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1.0';
	if ( ! wp_style_is( 'farazsms-overlay', 'registered' ) ) {
		wp_register_style( 'farazsms-overlay', FARAZSMS_CORE_CSS . 'farazsms-overlay.css', array(), $ver );
	}
	if ( ! wp_script_is( 'farazsms-overlay', 'registered' ) ) {
		wp_register_script( 'farazsms-overlay', FARAZSMS_CORE_JS . 'farazsms-overlay.js', array(), $ver, true );
	}
}
add_action( 'wp_enqueue_scripts', 'farazsms_overlay_register_assets', 1 );
add_action( 'admin_enqueue_scripts', 'farazsms_overlay_register_assets', 1 );

/**
 * دیرتر (priority 20): دادهٔ اورلی‌ها را localize و — اگر اورلیِ shellِ فعالی باشد — خودِ هسته را
 * enqueue کن. (اگر فیچری هسته را به‌عنوان dependency enqueue کرده باشد، دادهٔ localize هم با آن چاپ
 * می‌شود.) اگر نه اورلیِ shellی باشد و نه فیچری dependency کرده باشد، هیچ assetی خروجی نمی‌رود.
 */
function farazsms_overlay_maybe_enqueue() {
	if ( ! wp_script_is( 'farazsms-overlay', 'registered' ) ) {
		return;
	}
	// کدریویو v3.22.152: یک‌بار محاسبه شود — قبلاً دوبار صدا زده می‌شد و هر render_gateِ ثبت‌شده
	// (که می‌تواند کوئری/شمارنده داشته باشد) دو بار اجرا می‌شد.
	$active = farazsms_overlay_active_configs();
	wp_localize_script(
		'farazsms-overlay',
		'farazsmsOverlayData',
		array(
			'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
			'overlays' => $active,
		)
	);
	if ( ! empty( $active ) ) {
		wp_enqueue_style( 'farazsms-overlay' );
		wp_enqueue_script( 'farazsms-overlay' );
	}
}
add_action( 'wp_enqueue_scripts', 'farazsms_overlay_maybe_enqueue', 20 );
add_action( 'admin_enqueue_scripts', 'farazsms_overlay_maybe_enqueue', 20 );

/**
 * افزودنِ defer به تگِ هسته‌ی اورلی تا رندرِ صفحه را بلاک نکند.
 *
 * @param string $tag    تگِ کاملِ <script>.
 * @param string $handle هندلِ اسکریپت.
 * @return string
 */
function farazsms_overlay_script_defer( $tag, $handle ) {
	if ( 'farazsms-overlay' === $handle && false === strpos( $tag, ' defer' ) ) {
		$tag = str_replace( ' src=', ' defer src=', $tag );
	}
	return $tag;
}
add_filter( 'script_loader_tag', 'farazsms_overlay_script_defer', 10, 2 );
