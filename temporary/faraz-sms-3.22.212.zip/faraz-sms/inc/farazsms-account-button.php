<?php
/**
 * دکمه‌ی هوشمندِ حساب/ورود — مستقل از هر سیستمِ لاگین، سازگار با همه‌ی قالب‌ها.
 *
 * وقتی کاربر لاگین نیست → «ورود و ثبت‌نام» و لینک به صفحه‌ی ورود.
 * وقتی لاگین است → نامِ کاربر (یا اگر نام نبود، شماره‌ی موبایل) و لینک به مای‌اکانت.
 *
 * چهار راهِ قرار دادن (همه از یک هسته تغذیه می‌کنند):
 *   1) ارتقای خودکارِ لینکِ ورودِ موجود در منو/هدر (JS — «از روی لینک تشخیص بده»).
 *   2) کلاسِ اختیاری .farazsms-account روی هر عنصر.
 *   3) شورت‌کد [farazsms_account_button].
 *   4) بلاکِ گوتنبرگ + ویجتِ Elementor.
 *
 * دامِ کش: صفحه‌ی کش‌شده وضعیتِ لاگین را فریز می‌کند. راهِ حل: سرور حالتِ واقعیِ
 * لحظه‌ی رندر را می‌زند (بی‌فلش روی سایتِ بی‌کش) و یک AJAXِ کش‌ناپذیر وضعیتِ واقعیِ
 * همین کاربر را می‌گیرد و اگر HTMLِ کش‌شده کهنه بود، متن/مقصد را تصحیح می‌کند.
 *
 * @package FarazSMS
 * @since 3.22.62
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// ============================================================================
// تنظیمات
// ============================================================================

/**
 * پیش‌فرض‌ها + مقدارِ ذخیره‌شده.
 *
 * @return array
 */
function farazsms_account_button_settings() {
	$defaults = array(
		'enabled'          => '0', // پیش‌فرض خاموش (قانونِ پروژه برای فیچرِ نو).
		'guest_label'      => 'ورود و ثبت‌نام',
		'login_url'        => '', // خالی = تشخیصِ خودکار.
		'account_url'      => '', // خالی = مای‌اکانتِ ووکامرس.
		'preset'           => 'default', // default | outline | pill | minimal
		'accent_color'     => '#2271b1',
		'show_icon'        => '1',
		'greeting'         => '', // مثلاً «سلام، » پیش از نام (اختیاری).
		'upgrade_menu'     => '1', // آداپتور A: ارتقای خودکارِ لینکِ منو.
		'match_extra'      => '', // الگوهای اضافه‌ی URL برای تشخیصِ لینکِ ورود (یکی در هر خط).
	);
	$saved = get_option( 'farazsms_account_button_settings', array() );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
}

/**
 * @return bool
 */
function farazsms_account_button_is_enabled() {
	$s = farazsms_account_button_settings();
	return $s['enabled'] === '1';
}

// ============================================================================
// حل‌کننده‌های URL و هویت
// ============================================================================

/**
 * URLِ صفحه‌ی ورود: تنظیمات → تشخیصِ صفحه با قالبِ ورودِ افزونه → wp_login_url.
 *
 * @return string
 */
function farazsms_account_button_login_url() {
	static $cached = null;
	if ( $cached !== null ) {
		return $cached;
	}
	$s = farazsms_account_button_settings();
	$opt = trim( (string) $s['login_url'] );
	if ( $opt !== '' ) {
		$cached = $opt;
		return $cached;
	}
	// تشخیصِ صفحه‌ی ورودِ افزونه از روی page-template (بدونِ وابستگی به کلاسِ ماژول).
	if ( function_exists( 'get_pages' ) ) {
		$pages = get_pages( array(
			'meta_key'   => '_wp_page_template',
			'meta_value' => 'farazsms-login-page.php',
			'number'     => 1,
		) );
		if ( ! empty( $pages ) && isset( $pages[0]->ID ) ) {
			$url = get_permalink( $pages[0]->ID );
			if ( $url ) {
				$cached = $url;
				return $cached;
			}
		}
	}
	$cached = wp_login_url();
	return $cached;
}

/**
 * URLِ مای‌اکانت: تنظیمات → مای‌اکانتِ ووکامرس → خانه.
 *
 * @return string
 */
function farazsms_account_button_account_url() {
	static $cached = null;
	if ( $cached !== null ) {
		return $cached;
	}
	$s = farazsms_account_button_settings();
	$opt = trim( (string) $s['account_url'] );
	if ( $opt !== '' ) {
		$cached = $opt;
		return $cached;
	}
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		$url = wc_get_page_permalink( 'myaccount' );
		if ( $url ) {
			$cached = $url;
			return $cached;
		}
	}
	$cached = home_url( '/' );
	return $cached;
}

/**
 * شماره‌ی موبایلِ کاربر با کلیدهای واحدِ پروژه.
 *
 * @param int $user_id
 * @return string
 */
function farazsms_account_button_get_mobile( $user_id ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return '';
	}
	foreach ( array( 'mobile_number', 'billing_phone', 'digits_phone_no' ) as $key ) {
		$v = trim( (string) get_user_meta( $user_id, $key, true ) );
		if ( $v !== '' ) {
			return $v;
		}
	}
	return '';
}

/**
 * برچسبِ کاربرِ لاگین‌شده: نامِ واقعی، وگرنه موبایل، وگرنه «حساب کاربری».
 *
 * @param WP_User $user
 * @return string
 */
function farazsms_account_button_user_label( $user ) {
	if ( ! is_a( $user, 'WP_User' ) ) {
		return 'حساب کاربری';
	}
	$s    = farazsms_account_button_settings();
	$name = trim( (string) $user->first_name . ' ' . (string) $user->last_name );
	if ( $name === '' ) {
		$dn = trim( (string) $user->display_name );
		// display_name را فقط اگر «واقعاً نام» باشد بپذیر: نه user_login، نه صرفاً عددی/موبایل، نه ایمیل.
		$digits_only = ( $dn !== '' && preg_replace( '/\D/', '', $dn ) === $dn );
		$looks_email = ( strpos( $dn, '@' ) !== false );
		if ( $dn !== '' && $dn !== (string) $user->user_login && ! $digits_only && ! $looks_email ) {
			$name = $dn;
		}
	}
	if ( $name === '' ) {
		$mobile = farazsms_account_button_get_mobile( $user->ID );
		if ( $mobile !== '' ) {
			$name = $mobile;
		}
	}
	if ( $name === '' ) {
		$name = 'حساب کاربری';
	}
	$greeting = trim( (string) $s['greeting'] );
	return $greeting !== '' ? ( $greeting . $name ) : $name;
}

// ============================================================================
// هسته‌ی رندر
// ============================================================================

/**
 * HTMLِ دکمه — منبعِ واحد برای شورت‌کد/بلاک/ویجت.
 * سرور حالتِ واقعیِ لحظه‌ی رندر را می‌زند + data-attr برای تصحیحِ کش‌امنِ JS.
 *
 * @param array $args guest_label | preset | class | show_icon
 * @return string
 */
function farazsms_account_button_render( $args = array() ) {
	$s = farazsms_account_button_settings();

	$args = wp_parse_args( $args, array(
		'guest_label' => $s['guest_label'],
		'preset'      => $s['preset'],
		'class'       => '',
		'show_icon'   => $s['show_icon'],
	) );

	$login_url   = farazsms_account_button_login_url();
	$account_url = farazsms_account_button_account_url();
	$logged_in   = is_user_logged_in();

	if ( $logged_in ) {
		$user  = wp_get_current_user();
		$label = farazsms_account_button_user_label( $user );
		$href  = $account_url;
	} else {
		$label = (string) $args['guest_label'];
		$href  = $login_url;
	}

	$preset  = sanitize_html_class( $args['preset'] !== '' ? $args['preset'] : 'default' );
	$classes = 'farazsms-account-btn farazsms-account-btn--' . $preset;
	if ( ! empty( $args['class'] ) ) {
		$classes .= ' ' . sanitize_text_field( $args['class'] );
	}

	$icon = '';
	if ( $args['show_icon'] === '1' || $args['show_icon'] === 1 || $args['show_icon'] === true ) {
		$icon = '<span class="farazsms-account-btn__icon" aria-hidden="true"></span>';
	}

	// data-attrها: JS با این‌ها وضعیت را از AJAX تصحیح می‌کند حتی اگر HTML کش‌شده باشد.
	$data = sprintf(
		' data-fab="1" data-fab-login="%s" data-fab-account="%s" data-fab-guest="%s"',
		esc_url( $login_url ),
		esc_url( $account_url ),
		esc_attr( $args['guest_label'] )
	);

	return sprintf(
		'<a class="%1$s" href="%2$s"%3$s>%4$s<span class="farazsms-account-btn__label">%5$s</span></a>',
		esc_attr( $classes ),
		esc_url( $href ),
		$data,
		$icon,
		esc_html( $label )
	);
}

// ============================================================================
// آداپتور: شورت‌کد
// ============================================================================

add_shortcode( 'farazsms_account_button', 'farazsms_account_button_shortcode' );
function farazsms_account_button_shortcode( $atts ) {
	if ( ! farazsms_account_button_is_enabled() ) {
		return '';
	}
	farazsms_account_button_enqueue_now();
	$atts = shortcode_atts( array(
		'guest_label' => farazsms_account_button_settings()['guest_label'],
		'preset'      => farazsms_account_button_settings()['preset'],
		'class'       => '',
		'icon'        => farazsms_account_button_settings()['show_icon'],
	), $atts, 'farazsms_account_button' );

	return farazsms_account_button_render( array(
		'guest_label' => $atts['guest_label'],
		'preset'      => $atts['preset'],
		'class'       => $atts['class'],
		'show_icon'   => $atts['icon'],
	) );
}

// ============================================================================
// آداپتور: بلاکِ گوتنبرگ (سرور-رندر، بدونِ build)
// ============================================================================

add_action( 'init', 'farazsms_account_button_register_block' );
function farazsms_account_button_register_block() {
	if ( ! function_exists( 'register_block_type' ) ) {
		return;
	}
	$ver = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1';

	// اسکریپتِ ویرایشگر (بدونِ build؛ از globalهای wp استفاده می‌کند).
	wp_register_script(
		'farazsms-account-button-block',
		FARAZSMS_CORE_JS . 'farazsms-account-button-block.js',
		array( 'wp-blocks', 'wp-element', 'wp-block-editor', 'wp-components', 'wp-server-side-render', 'wp-i18n' ),
		$ver,
		true
	);

	register_block_type( 'farazsms/account-button', array(
		'api_version'     => 2,
		'editor_script'   => 'farazsms-account-button-block',
		'render_callback' => 'farazsms_account_button_block_render',
		'attributes'      => array(
			'preset'     => array( 'type' => 'string', 'default' => '' ),
			'guestLabel' => array( 'type' => 'string', 'default' => '' ),
			'showIcon'   => array( 'type' => 'boolean', 'default' => true ),
			'align'      => array( 'type' => 'string', 'default' => '' ),
		),
	) );
}

/**
 * render_callbackِ بلاک.
 *
 * @param array $attrs
 * @return string
 */
function farazsms_account_button_block_render( $attrs ) {
	if ( ! farazsms_account_button_is_enabled() ) {
		// در ویرایشگر (درخواستِ REST) یک توضیح نشان بده تا بلاک «خراب» به‌نظر نرسد.
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return '<div class="farazsms-account-btn-block" style="padding:10px 14px;border:1px dashed #c3d9ed;border-radius:8px;color:#b26a00;font-size:13px">دکمه‌ی حساب هنوز در تنظیماتِ فراز فعال نشده؛ در سایتِ واقعی نمایش داده نمی‌شود.</div>';
		}
		return '';
	}
	farazsms_account_button_enqueue_now();
	$attrs = is_array( $attrs ) ? $attrs : array();
	$s     = farazsms_account_button_settings();

	$wrap_class = 'farazsms-account-btn-block';
	if ( ! empty( $attrs['align'] ) ) {
		$wrap_class .= ' has-text-align-' . sanitize_html_class( $attrs['align'] );
	}

	$html = farazsms_account_button_render( array(
		'guest_label' => isset( $attrs['guestLabel'] ) && $attrs['guestLabel'] !== '' ? $attrs['guestLabel'] : $s['guest_label'],
		'preset'      => isset( $attrs['preset'] ) && $attrs['preset'] !== '' ? $attrs['preset'] : $s['preset'],
		'show_icon'   => ( ! isset( $attrs['showIcon'] ) || $attrs['showIcon'] ) ? '1' : '0',
	) );

	return '<div class="' . esc_attr( $wrap_class ) . '">' . $html . '</div>';
}

// ============================================================================
// آداپتور: ویجتِ Elementor (اولین ویجتِ نمایشیِ افزونه)
// ============================================================================

add_action( 'elementor/widgets/register', 'farazsms_account_button_register_elementor' );
function farazsms_account_button_register_elementor( $widgets_manager ) {
	if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
		return;
	}
	require_once __DIR__ . '/farazsms-account-button-elementor.php';
	if ( class_exists( 'FarazSMS_Account_Button_Elementor_Widget' ) && is_object( $widgets_manager ) && method_exists( $widgets_manager, 'register' ) ) {
		$widgets_manager->register( new FarazSMS_Account_Button_Elementor_Widget() );
	}
}

// ============================================================================
// AJAXِ کش‌امن (بدونِ nonce — nonce زیرِ کش می‌میرد و این endpoint فقط-خواندنی است)
// ============================================================================

add_action( 'wp_ajax_farazsms_account_state', 'farazsms_account_button_ajax_state' );
add_action( 'wp_ajax_nopriv_farazsms_account_state', 'farazsms_account_button_ajax_state' );
function farazsms_account_button_ajax_state() {
	// PIIِ خودِ کاربر است، ولی صریحاً خصوصی و کش‌ناپذیر تا هیچ لایه‌ی کشی آن را بین کاربران به اشتراک نگذارد.
	// هدرها پیش از هر early-return ست می‌شوند تا پاسخِ «disabled» هم کش نشود.
	nocache_headers();
	if ( ! headers_sent() ) {
		header( 'Cache-Control: private, no-store, max-age=0' );
		header( 'Vary: Cookie' );
	}
	if ( ! farazsms_account_button_is_enabled() ) {
		wp_send_json_error( 'disabled', 403 );
	}
	$s = farazsms_account_button_settings();

	if ( ! is_user_logged_in() ) {
		wp_send_json_success( array(
			'logged_in' => false,
			'label'     => $s['guest_label'],
			'href'      => farazsms_account_button_login_url(),
		) );
	}

	$user = wp_get_current_user();
	wp_send_json_success( array(
		'logged_in' => true,
		'label'     => farazsms_account_button_user_label( $user ),
		'href'      => farazsms_account_button_account_url(),
	) );
}

// ============================================================================
// بارگذاریِ asset (سراسری وقتی فعال است — دکمه‌ی هدر روی هر صفحه‌ای هست)
// ============================================================================

add_action( 'wp_enqueue_scripts', 'farazsms_account_button_enqueue_now' );
function farazsms_account_button_enqueue_now() {
	if ( ! farazsms_account_button_is_enabled() ) {
		return;
	}
	if ( wp_script_is( 'farazsms-account-button', 'enqueued' ) ) {
		return;
	}
	$ver = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1';
	$s   = farazsms_account_button_settings();

	if ( ! wp_style_is( 'farazsms-account-button', 'registered' ) ) {
		wp_register_style( 'farazsms-account-button', FARAZSMS_CORE_CSS . 'farazsms-account-button.css', array(), $ver );
	}
	if ( ! wp_script_is( 'farazsms-account-button', 'registered' ) ) {
		wp_register_script( 'farazsms-account-button', FARAZSMS_CORE_JS . 'farazsms-account-button.js', array(), $ver, true );
	}

	wp_enqueue_style( 'farazsms-account-button' );
	// در خروجی هم دوباره اعتبارسنجی می‌کنیم (نه فقط هنگامِ ذخیره) تا CSS-breakout ممکن نباشد.
	$accent = function_exists( 'sanitize_hex_color' ) ? sanitize_hex_color( $s['accent_color'] ) : '';
	if ( ! $accent ) {
		$accent = '#2271b1';
	}
	wp_add_inline_style( 'farazsms-account-button', ':root{--fab-accent:' . $accent . ';}' );

	// الگوهای تشخیصِ لینکِ ورود (برای آداپتور A).
	$match = array();
	$login = farazsms_account_button_login_url();
	if ( $login ) {
		$match[] = $login;
	}
	$extra = preg_split( '/\r\n|\r|\n/', (string) $s['match_extra'] );
	foreach ( (array) $extra as $line ) {
		$line = trim( $line );
		if ( $line !== '' ) {
			$match[] = $line;
		}
	}

	wp_enqueue_script( 'farazsms-account-button' );
	wp_localize_script( 'farazsms-account-button', 'farazsms_account', array(
		'ajax_url'     => admin_url( 'admin-ajax.php' ),
		'login_url'    => $login,
		'account_url'  => farazsms_account_button_account_url(),
		'guest_label'  => $s['guest_label'],
		'upgrade_menu' => $s['upgrade_menu'] === '1',
		'match'        => array_values( array_unique( $match ) ),
	) );
}

// ============================================================================
// تنظیماتِ ادمین (صفحه‌ی مستقل — الگوی farazsms-birthday)
// ============================================================================

add_action( 'admin_menu', 'farazsms_account_button_register_submenu', 60 );
function farazsms_account_button_register_submenu() {
	add_submenu_page(
		'farazsms',
		'دکمه‌ی حساب کاربری',
		'👤 دکمه‌ی حساب',
		'manage_options',
		'farazsms-account-button',
		'farazsms_account_button_render_admin'
	);
}

add_action( 'admin_post_farazsms_account_button_save', 'farazsms_account_button_handle_save' );
function farazsms_account_button_handle_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی مجاز نیست.' );
	}
	check_admin_referer( 'farazsms_account_button_save' );

	$s = farazsms_account_button_settings();
	$s['enabled']      = isset( $_POST['enabled'] ) ? '1' : '0';
	$gl                = isset( $_POST['guest_label'] ) ? sanitize_text_field( wp_unslash( $_POST['guest_label'] ) ) : '';
	$s['guest_label']  = trim( $gl ) !== '' ? $gl : 'ورود و ثبت‌نام'; // خالی نماند → دکمه‌ی بی‌متن نشود.
	$s['login_url']    = isset( $_POST['login_url'] ) ? esc_url_raw( wp_unslash( $_POST['login_url'] ) ) : '';
	$s['account_url']  = isset( $_POST['account_url'] ) ? esc_url_raw( wp_unslash( $_POST['account_url'] ) ) : '';
	$allowed_presets   = array( 'default', 'outline', 'pill', 'minimal' );
	$preset            = isset( $_POST['preset'] ) ? sanitize_text_field( wp_unslash( $_POST['preset'] ) ) : 'default';
	$s['preset']       = in_array( $preset, $allowed_presets, true ) ? $preset : 'default';
	$s['accent_color'] = isset( $_POST['accent_color'] ) ? sanitize_hex_color( wp_unslash( $_POST['accent_color'] ) ) : $s['accent_color'];
	if ( ! $s['accent_color'] ) {
		$s['accent_color'] = '#2271b1';
	}
	$s['show_icon']    = isset( $_POST['show_icon'] ) ? '1' : '0';
	$s['greeting']     = isset( $_POST['greeting'] ) ? sanitize_text_field( wp_unslash( $_POST['greeting'] ) ) : '';
	$s['upgrade_menu'] = isset( $_POST['upgrade_menu'] ) ? '1' : '0';
	$s['match_extra']  = isset( $_POST['match_extra'] ) ? farazsms_sanitize_pattern_text( $_POST['match_extra'] ) : '';

	update_option( 'farazsms_account_button_settings', $s );
	wp_safe_redirect( add_query_arg( array( 'page' => 'farazsms-account-button', 'saved' => '1' ), admin_url( 'admin.php' ) ) );
	exit;
}

function farazsms_account_button_render_admin() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$s = farazsms_account_button_settings();
	?>
	<div class="wrap" dir="rtl" style="max-width:820px">
		<h1>👤 دکمه‌ی هوشمندِ حساب / ورود</h1>
		<?php if ( isset( $_GET['saved'] ) ) : ?>
			<div class="notice notice-success is-dismissible"><p>✓ ذخیره شد.</p></div>
		<?php endif; ?>
		<p style="background:#f0f6fc;border:1px solid #c3d9ed;padding:12px 16px;border-radius:8px;line-height:2">
			این دکمه با هر قالبی کار می‌کند. چهار راهِ گذاشتنش:
		</p>
		<ul style="line-height:2.2">
			<li><b>خودکار (بدونِ زحمت):</b> اگر لینکِ «ورود و ثبت‌نام» را در منوی سایت دارید، همان خودکار هوشمند می‌شود (گزینه‌ی «ارتقای منو» پایین باید روشن باشد).</li>
			<li><b>کلاسِ CSS:</b> کلاسِ <code dir="ltr">farazsms-account</code> را روی هر لینک/دکمه بگذارید.</li>
			<li><b>شورت‌کد:</b> <code dir="ltr">[farazsms_account_button]</code></li>
			<li><b>بلاکِ گوتنبرگ / ویجتِ Elementor:</b> بلاک «دکمه‌ی حساب فراز» را جست‌وجو کنید.</li>
		</ul>

		<details style="margin:8px 0 18px;border:1px solid #e1e1e1;border-radius:8px;padding:4px 14px;background:#fff">
			<summary style="cursor:pointer;font-weight:600;padding:8px 0">📘 راهنمای کامل و رفعِ اشکال (قبل از تماس با پشتیبانی این را بخوانید)</summary>
			<div style="line-height:2.1;padding:6px 2px 14px">
				<p><b>این دکمه چه می‌کند؟</b> وقتی بازدیدکننده وارد نشده، «ورود و ثبت‌نام» نشان می‌دهد و به صفحه‌ی ورود می‌برد. وقتی کاربر وارد شده، نامِ او (یا اگر نامی ثبت نکرده، شماره‌ی موبایلش) را نشان می‌دهد و با کلیک به حساب کاربری (My Account) می‌رود. با کش هم سازگار است.</p>

				<h3 style="margin:14px 0 4px">۱) روشِ خودکار (پیشنهادی — بدونِ هیچ کارِ اضافه)</h3>
				<p>همان لینکِ «ورود» که الان در منوی سایت دارید را دست نزنید. کافی است این فیچر «فعال» و گزینه‌ی «ارتقای خودکارِ منو» روشن باشد. افزونه لینک را می‌شناسد و هوشمندش می‌کند. برای شناختِ درست، آدرسِ صفحه‌ی ورود باید بالا در «URLِ صفحه‌ی ورود» درست باشد (یا خالی تا خودکار پیدا شود).</p>

				<h3 style="margin:14px 0 4px">۲) شورت‌کد (هر جای صفحه/فوتر)</h3>
				<p>این را در هر برگه/نوشته/ابزارکِ متنی بگذارید:</p>
				<p><code dir="ltr" style="display:block;background:#f6f7f7;padding:8px 12px;border-radius:6px">[farazsms_account_button]</code></p>
				<p>با تنظیماتِ اختیاری:</p>
				<p><code dir="ltr" style="display:block;background:#f6f7f7;padding:8px 12px;border-radius:6px">[farazsms_account_button preset="outline" guest_label="ورود به حساب" icon="1"]</code></p>
				<p><span class="description"><b>preset</b>: default | outline | pill | minimal · <b>guest_label</b>: متنِ حالتِ خروج · <b>icon</b>: 1 یا 0</span></p>

				<h3 style="margin:14px 0 4px">۳) المنتور</h3>
				<p>در ویرایشگرِ المنتور، در جست‌وجوی ویجت‌ها تایپ کنید «<b>دکمه‌ی حساب فراز</b>»، ویجت را به هدر/هر جا بکشید. متن و استایل را همان‌جا در پنلِ المنتور تنظیم کنید.</p>

				<h3 style="margin:14px 0 4px">۴) بلاکِ گوتنبرگ</h3>
				<p>در ویرایشگرِ برگه، دکمه‌ی + را بزنید و «<b>دکمه‌ی حساب فراز</b>» را جست‌وجو کنید.</p>

				<h3 style="margin:14px 0 4px">۵) هر دکمه‌ی دلخواه (روشِ کلاس)</h3>
				<p>اگر دکمه‌ای در قالب/صفحه‌ساز دارید، فقط کلاسِ زیر را به آن اضافه کنید تا هوشمند شود:</p>
				<p><code dir="ltr" style="display:block;background:#f6f7f7;padding:8px 12px;border-radius:6px">farazsms-account</code></p>

				<h3 style="margin:16px 0 4px;color:#b26a00">رفعِ اشکالِ رایج</h3>
				<ul style="list-style:disc;padding-right:22px">
					<li><b>دکمه اصلاً نمایش داده نمی‌شود؟</b> مطمئن شوید بالا «فعال» را تیک زده و ذخیره کرده‌اید.</li>
					<li><b>لینکِ منو خودکار هوشمند نمی‌شود؟</b> «ارتقای خودکارِ منو» روشن باشد و «URLِ صفحه‌ی ورود» دقیقاً همان صفحه‌ای باشد که لینکِ منو به آن می‌رود. اگر آدرس فرق دارد، در «الگوهای اضافه‌ی لینک» مسیرِ کاملِ صفحه (با «/» شروع شود) را بنویسید.</li>
					<li><b>صفحه‌ی ورودتان همان صفحه‌ی اصلیِ سایت است؟</b> در این حالت ارتقای خودکار عمداً خاموش می‌ماند تا همه‌ی لینک‌های سایت خراب نشوند؛ از شورت‌کد یا ویجت استفاده کنید.</li>
					<li><b>بعد از ورود هنوز چند لحظه «ورود» می‌بینید؟</b> اگر سایت کش دارد، دکمه بلافاصله پس از بارگذاری به‌طور خودکار اصلاح می‌شود. اگر اصلاح نشد، افزونه‌ی کش را روی صفحه‌ی حساب کاربری غیرفعال/استثنا کنید.</li>
					<li><b>استایل با قالب هماهنگ نیست؟</b> از preset «minimal» استفاده کنید یا رنگِ اصلی را در همین صفحه تغییر دهید؛ در المنتور می‌توانید کاملاً استایل بدهید.</li>
				</ul>
			</div>
		</details>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="farazsms_account_button_save">
			<?php wp_nonce_field( 'farazsms_account_button_save' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row">فعال</th>
					<td><label><input type="checkbox" name="enabled" value="1" <?php checked( $s['enabled'], '1' ); ?>> فعال‌سازیِ دکمه‌ی حساب</label></td>
				</tr>
				<tr>
					<th scope="row">متنِ حالتِ خروج</th>
					<td><input type="text" name="guest_label" value="<?php echo esc_attr( $s['guest_label'] ); ?>" class="regular-text"><p class="description">وقتی کاربر لاگین نیست.</p></td>
				</tr>
				<tr>
					<th scope="row">پیش از نام (اختیاری)</th>
					<td><input type="text" name="greeting" value="<?php echo esc_attr( $s['greeting'] ); ?>" class="regular-text" placeholder="مثلاً: سلام، "><p class="description">مثلاً «سلام، » که می‌شود «سلام، علی».</p></td>
				</tr>
				<tr>
					<th scope="row">URLِ صفحه‌ی ورود</th>
					<td><input type="url" name="login_url" value="<?php echo esc_attr( $s['login_url'] ); ?>" class="regular-text" dir="ltr" placeholder="خالی = تشخیصِ خودکار"><p class="description">خالی بگذارید تا خودکار پیدا شود.</p></td>
				</tr>
				<tr>
					<th scope="row">URLِ مای‌اکانت</th>
					<td><input type="url" name="account_url" value="<?php echo esc_attr( $s['account_url'] ); ?>" class="regular-text" dir="ltr" placeholder="خالی = مای‌اکانتِ ووکامرس"></td>
				</tr>
				<tr>
					<th scope="row">استایل</th>
					<td>
						<select name="preset">
							<?php
							$presets = array( 'default' => 'پیش‌فرض (پُر)', 'outline' => 'خط‌دار', 'pill' => 'قرصی', 'minimal' => 'ساده (بدونِ کادر)' );
							foreach ( $presets as $k => $lbl ) {
								printf( '<option value="%s" %s>%s</option>', esc_attr( $k ), selected( $s['preset'], $k, false ), esc_html( $lbl ) );
							}
							?>
						</select>
						<input type="text" name="accent_color" value="<?php echo esc_attr( $s['accent_color'] ); ?>" dir="ltr" style="width:110px" placeholder="#2271b1">
						<p class="description">رنگِ اصلی (hex). در Elementor استایل را همان‌جا هم می‌توانید بدهید.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">آیکون</th>
					<td><label><input type="checkbox" name="show_icon" value="1" <?php checked( $s['show_icon'], '1' ); ?>> نمایشِ آیکونِ کاربر کنارِ متن</label></td>
				</tr>
				<tr>
					<th scope="row">ارتقای خودکارِ منو</th>
					<td>
						<label><input type="checkbox" name="upgrade_menu" value="1" <?php checked( $s['upgrade_menu'], '1' ); ?>> لینک‌های منویی که به صفحه‌ی ورود اشاره می‌کنند خودکار هوشمند شوند</label>
						<p class="description">همان لینکِ فعلیِ «ورود و ثبت‌نام» در منو را دست‌نخورده بگذارید؛ خودش هوشمند می‌شود.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">الگوهای اضافه‌ی لینک</th>
					<td>
						<textarea name="match_extra" rows="3" class="large-text" dir="ltr" placeholder="/login/&#10;/ورود/"><?php echo esc_textarea( $s['match_extra'] ); ?></textarea>
						<p class="description">اگر لینکِ ورودتان آدرسِ دیگری دارد، <b>مسیرِ کاملِ صفحه</b> (که با «/» شروع شود) یا URLِ کامل را در هر خط بنویسید. تطبیق دقیق است (نه بخشی از URL)؛ توکنِ نسبی مثلِ <code dir="ltr">wp-login.php</code> نادیده گرفته می‌شود.</p>
					</td>
				</tr>
			</table>
			<?php submit_button( 'ذخیره' ); ?>
		</form>
	</div>
	<?php
}
