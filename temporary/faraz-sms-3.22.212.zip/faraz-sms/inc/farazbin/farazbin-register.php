<?php
/**
 * فرازبین — ثبت‌نامِ سایت (POST /api/register).
 *
 * بدنه‌ی flat: { mobile (اجباری), site_url (اجباری), shop_name, logo_url, province, city }.
 * پاسخ ۲۰۱: { seller_site_id, token }. توکن فقط یک‌بار برمی‌گردد و باید امن ذخیره شود.
 * register idempotent است (با همان site_url سایت را به‌روز و توکنِ جدید می‌دهد).
 * اجرا در cron تا بارگذاریِ صفحه بلاک نشود.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'admin_init', 'farazbin_register_maybe_schedule' );
function farazbin_register_maybe_schedule() {
	if ( ! farazbin_is_enabled() || farazbin_is_registered() ) {
		return;
	}
	if ( farazbin_get_mobile() === '' ) {
		return; // بدونِ موبایل نمی‌توان ثبت کرد؛ مدیر باید در صفحه‌ی فرازبین واردش کند.
	}
	if ( get_transient( 'farazbin_register_backoff' ) ) {
		return;
	}
	if ( ! wp_next_scheduled( 'farazbin_register_cron' ) ) {
		wp_schedule_single_event( time() + 20, 'farazbin_register_cron' );
	}
}

add_action( 'farazbin_register_cron', 'farazbin_register_run' );

/**
 * استان/شهرِ فروشگاه از تنظیماتِ آدرسِ ووکامرس (برای «فروشگاه‌های نزدیکِ شما»).
 */
function farazbin_register_location() {
	$province = '';
	$country_code = '';
	$state_code = '';
	$base = (string) get_option( 'woocommerce_default_country', '' ); // "IR:THR"
	if ( strpos( $base, ':' ) !== false ) {
		list( $country_code, $state_code ) = explode( ':', $base, 2 );
		if ( function_exists( 'WC' ) && WC()->countries ) {
			$states = WC()->countries->get_states( $country_code );
			$province = ( is_array( $states ) && isset( $states[ $state_code ] ) ) ? $states[ $state_code ] : $state_code;
		}
	} else {
		$country_code = $base;
	}
	return array(
		'province'     => $province,
		'city'         => (string) get_option( 'woocommerce_store_city', '' ),
		'country_code' => $country_code,
		'state_code'   => $state_code,
	);
}

/**
 * لوگوی فروشگاه (نمادکِ سایت در صورتِ وجود).
 */
function farazbin_register_logo_url() {
	if ( function_exists( 'get_site_icon_url' ) ) {
		$u = get_site_icon_url();
		if ( $u ) {
			return $u;
		}
	}
	return '';
}

/**
 * کلیدِ دسترسیِ فراز اس‌ام‌اس؛ برای قراردادهای قدیمی‌تر ثبت‌نام هم ارسال می‌شود.
 */
function farazbin_register_access_key() {
	return (string) farazsms_get_apikey();
}

/**
 * پاسخ موفق ثبت‌نام ممکن است با کلیدهای نسل قدیم یا جدید برگردد.
 */
function farazbin_register_response_has_credentials( $data ) {
	if ( ! is_array( $data ) || empty( $data['token'] ) ) {
		return false;
	}
	return isset( $data['seller_site_id'] ) || isset( $data['shop_id'] );
}

function farazbin_register_store_meta( $loc, $profile ) {
	$currency = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : (string) get_option( 'woocommerce_currency', 'IRR' );
	$price_unit = get_option( 'farazsms_farazbin_price_unit', 'auto' );
	if ( $price_unit === 'auto' ) {
		$price_unit = in_array( strtoupper( (string) $currency ), array( 'IRT', 'TOMAN', 'TMN' ), true ) ? 'toman' : 'rial';
	}

	return array(
		'platform'        => 'woocommerce',
		'site_url'        => home_url(),
		'store_name'      => (string) get_bloginfo( 'name' ),
		'store_email'     => (string) get_option( 'woocommerce_email_from_address', get_option( 'admin_email', '' ) ),
		'logo_url'        => farazbin_register_logo_url(),
		'owner_name'      => isset( $profile['display_name'] ) ? (string) $profile['display_name'] : '',
		'province'        => $loc['province'],
		'city'            => $loc['city'],
		'country_code'    => $loc['country_code'],
		'state_code'      => $loc['state_code'],
		'address'         => trim( (string) get_option( 'woocommerce_store_address', '' ) . ' ' . (string) get_option( 'woocommerce_store_address_2', '' ) ),
		'postcode'        => (string) get_option( 'woocommerce_store_postcode', '' ),
		'currency'        => $currency,
		'currency_symbol' => function_exists( 'get_woocommerce_currency_symbol' ) ? html_entity_decode( get_woocommerce_currency_symbol() ) : '',
		'currency_pos'    => (string) get_option( 'woocommerce_currency_pos', 'right' ),
		'thousand_sep'    => (string) get_option( 'woocommerce_price_thousand_sep', ',' ),
		'decimal_sep'     => (string) get_option( 'woocommerce_price_decimal_sep', '.' ),
		'num_decimals'    => (int) get_option( 'woocommerce_price_num_decimals', 0 ),
		'price_unit'      => $price_unit,
		'weight_unit'     => (string) get_option( 'woocommerce_weight_unit', 'kg' ),
		'dimension_unit'  => (string) get_option( 'woocommerce_dimension_unit', 'cm' ),
		'locale'          => (string) get_locale(),
		'wp_version'      => get_bloginfo( 'version' ),
		'wc_version'      => defined( 'WC_VERSION' ) ? WC_VERSION : '',
		'plugin_version'  => defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '',
	);
}

/**
 * ارسال درخواست ثبت‌نام با fallback مسیر، چون نصب‌های مختلف فرازبین قراردادهای متفاوتی دارند.
 */
function farazbin_register_request( $body ) {
	$access_key = farazbin_register_access_key();
	$headers    = array( 'Content-Type' => 'application/json' );
	if ( $access_key !== '' ) {
		$headers['X-Farazbin-Access-Key'] = $access_key;
	}

	$paths = array( '/api/register', '/register' );
	$last  = null;

	foreach ( $paths as $path ) {
		$resp = wp_remote_post( farazbin_api_base() . $path, array(
			'timeout' => 15,
			'headers' => $headers,
			'body'    => $body,
		) );

		$last = $resp;
		if ( is_wp_error( $resp ) ) {
			break;
		}

		$code = (int) wp_remote_retrieve_response_code( $resp );
		farazbin_diag_set( 'last_register_endpoint', $path );

		if ( $code !== 404 && $code !== 405 ) {
			break;
		}
	}

	return $last;
}

/**
 * اجرای واقعیِ ثبت‌نام (در cron).
 */
function farazbin_register_run() {
	if ( ! farazbin_is_enabled() || farazbin_is_registered() ) {
		return;
	}
	$mobile = farazbin_get_mobile();
	if ( $mobile === '' ) {
		farazbin_diag_set( 'last_register_error', 'موبایلِ مالک از پروفایل فراز اس‌ام‌اس دریافت نشد؛ Api-Key را بررسی کنید.' );
		farazbin_diag_set( 'last_register_at', farazbin_iso8601() );
		set_transient( 'farazbin_register_backoff', 1, 2 * HOUR_IN_SECONDS );
		return;
	}

	$loc     = farazbin_register_location();
	$profile = function_exists( 'farazbin_get_profile_data' ) ? farazbin_get_profile_data() : array();
	$meta    = farazbin_register_store_meta( $loc, $profile );
	$body    = wp_json_encode( array(
		'mobile'    => $mobile,
		'site_url'  => home_url(),
		'shop_name' => $meta['store_name'],
		'logo_url'  => $meta['logo_url'],
		'province'  => $loc['province'],
		'city'      => $loc['city'],
		'site_meta' => $meta,
	) );

	$resp = farazbin_register_request( $body );

	farazbin_diag_set( 'last_register_at', farazbin_iso8601() );

	if ( is_wp_error( $resp ) ) {
		farazbin_diag_set( 'last_register_error', $resp->get_error_message() );
		set_transient( 'farazbin_register_backoff', 1, 2 * HOUR_IN_SECONDS );
		return;
	}

	$code = (int) wp_remote_retrieve_response_code( $resp );
	$data = json_decode( wp_remote_retrieve_body( $resp ), true );

	if ( ( $code === 200 || $code === 201 ) && farazbin_register_response_has_credentials( $data ) ) {
		farazbin_store_credentials( $data );
		farazbin_diag_set( 'last_register_error', '' );
		delete_transient( 'farazbin_register_backoff' );
		// پس از اولین اتصال، همگام‌سازیِ کاملِ کاتالوگ را زمان‌بندی کن (بکفیلِ اولیه).
		if ( function_exists( 'farazbin_backfill_schedule' ) ) {
			farazbin_backfill_schedule();
		}
		return;
	}

	$msg = is_array( $data ) && isset( $data['message'] ) ? (string) $data['message']
		: ( is_array( $data ) && isset( $data['code'] ) ? (string) $data['code'] : ( 'HTTP ' . $code ) );
	farazbin_diag_set( 'last_register_error', $msg );
	set_transient( 'farazbin_register_backoff', 1, 2 * HOUR_IN_SECONDS );
}

/**
 * ثبت‌نامِ مجدد/چرخشِ توکن (idempotent با site_url).
 */
function farazbin_register_force() {
	farazbin_clear_token();
	delete_option( 'farazsms_farazbin_seller_site_id' );
	delete_transient( 'farazbin_register_backoff' );
	farazbin_register_run();
}
