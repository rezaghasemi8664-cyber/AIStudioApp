<?php
/**
 * فرازبین — امضای HMAC دوطرفه (طبقِ قرارداد).
 *
 * signature = HMAC-SHA256( key = per-site token, message = timestamp + "." + raw_body )
 * هدرها: X-Farazbin-Timestamp, X-Farazbin-Signature (sha256=<hex>), X-Farazbin-Site
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * ساختِ امضا برای یک درخواستِ خروجی (Push).
 *
 * @param int    $timestamp Unix timestamp.
 * @param string $raw_body  بدنه‌ی خامِ JSON.
 * @param string $token     توکنِ اختصاصیِ سایت.
 * @return string  مثلِ "sha256=abcd..."
 */
function farazbin_hmac_sign( $timestamp, $raw_body, $token ) {
	$message = (string) $timestamp . '.' . (string) $raw_body;
	return 'sha256=' . hash_hmac( 'sha256', $message, (string) $token );
}

/**
 * هدرهای امضاشده برای یک بدنه‌ی خروجی.
 *
 * @return array{headers: array<string,string>, body: string}|null  null اگر توکن نباشد.
 */
function farazbin_hmac_signed_request( $body_array ) {
	$token = farazbin_get_token();
	if ( $token === '' ) {
		return null;
	}
	$raw       = wp_json_encode( $body_array );
	$timestamp = time();
	$sig       = farazbin_hmac_sign( $timestamp, $raw, $token );
	return array(
		'headers' => array(
			'Content-Type'         => 'application/json',
			'X-Farazbin-Timestamp' => (string) $timestamp,
			'X-Farazbin-Signature' => $sig,
			'X-Farazbin-Site'      => home_url(),
		),
		'body'    => $raw,
	);
}

/**
 * خواندنِ یک هدرِ HTTP از $_SERVER (با و بدونِ HTTP_).
 */
function farazbin_read_header( $name ) {
	$key = 'HTTP_' . strtoupper( str_replace( '-', '_', $name ) );
	if ( isset( $_SERVER[ $key ] ) ) {
		return (string) wp_unslash( $_SERVER[ $key ] );
	}
	return '';
}

/**
 * تأییدِ امضای یک درخواستِ ورودی (Pull از سرورِ فرازبین).
 *
 * @param string $raw_body بدنه‌ی خامِ درخواست (برای GET معمولاً خالی).
 * @return bool
 */
function farazbin_hmac_verify_incoming( $raw_body = '' ) {
	$token = farazbin_get_token();
	if ( $token === '' ) {
		return false; // هنوز ثبت‌نام نشده؛ نمی‌توان تأیید کرد.
	}
	$timestamp = farazbin_read_header( 'X-Farazbin-Timestamp' );
	$signature = farazbin_read_header( 'X-Farazbin-Signature' );
	if ( $timestamp === '' || $signature === '' ) {
		return false;
	}
	// دفاع در برابر replay: اختلافِ بیش از ۳۰۰ ثانیه رد می‌شود.
	if ( abs( time() - (int) $timestamp ) > 300 ) {
		return false;
	}
	$expected = farazbin_hmac_sign( $timestamp, $raw_body, $token );
	// مقایسه‌ی constant-time.
	return hash_equals( $expected, $signature );
}
