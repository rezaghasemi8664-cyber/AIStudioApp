<?php
/**
 * فرازبین — صفحه‌ی وضعیتِ ادمین (slug: farazsms-farazbin).
 *
 * خودکار + قابلِ خاموش‌کردن. ورودِ موبایلِ مالک (اجباری برای ثبت‌نام)، دکمه‌ی اتصال،
 * همگام‌سازیِ کاملِ کاتالوگ، و دیاگنوستیک.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'admin_menu', 'farazbin_admin_register_menu', 28 );
function farazbin_admin_register_menu() {
	add_submenu_page(
		'farazsms',
		__( 'فراز بین', 'farazsms' ),
		__( 'فراز بین', 'farazsms' ),
		'manage_options',
		'farazsms-farazbin',
		'farazbin_admin_render_page'
	);
}

// ذخیره‌ی تنظیمات (روشن/خاموش + موبایل + واحدِ قیمت).
add_action( 'admin_post_farazbin_save_settings', 'farazbin_admin_save_settings' );
function farazbin_admin_save_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	check_admin_referer( 'farazbin_save_settings' );
	update_option( 'farazsms_farazbin_enabled', isset( $_POST['farazbin_enabled'] ) ? '1' : '0', false );
	if ( isset( $_POST['farazbin_mobile'] ) ) {
		$mobile = sanitize_text_field( wp_unslash( $_POST['farazbin_mobile'] ) );
		if ( $mobile !== '' ) {
			$mobile = farazsms_normalize_phone( $mobile );
		}
		update_option( 'farazsms_farazbin_mobile', $mobile, false );
	}
	if ( isset( $_POST['farazbin_price_unit'] ) ) {
		$unit = sanitize_key( $_POST['farazbin_price_unit'] );
		update_option( 'farazsms_farazbin_price_unit', in_array( $unit, array( 'auto', 'rial', 'toman' ), true ) ? $unit : 'auto', false );
	}
	wp_safe_redirect( add_query_arg( 'farazbin_saved', '1', admin_url( 'admin.php?page=farazsms-farazbin' ) ) );
	exit;
}

// اتصالِ فوری (ثبت‌نام همین حالا).
add_action( 'admin_post_farazbin_connect_now', 'farazbin_admin_connect_now' );
function farazbin_admin_connect_now() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	check_admin_referer( 'farazbin_connect_now' );
	update_option( 'farazsms_farazbin_enabled', '1', false );
	delete_transient( 'farazbin_register_backoff' );
	if ( function_exists( 'farazbin_register_run' ) ) {
		farazbin_register_run();
	}
	$status = farazbin_is_registered() ? 'ok' : 'fail';
	wp_safe_redirect( add_query_arg( 'farazbin_connect', $status, admin_url( 'admin.php?page=farazsms-farazbin' ) ) );
	exit;
}

// چرخشِ توکن (ثبت‌نامِ مجدد).
add_action( 'admin_post_farazbin_reregister', 'farazbin_admin_reregister' );
function farazbin_admin_reregister() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	check_admin_referer( 'farazbin_reregister' );
	if ( function_exists( 'farazbin_register_force' ) ) {
		farazbin_register_force();
	}
	wp_safe_redirect( add_query_arg( 'farazbin_reregistered', '1', admin_url( 'admin.php?page=farazsms-farazbin' ) ) );
	exit;
}

// همگام‌سازیِ کاملِ کاتالوگ (بکفیل).
add_action( 'admin_post_farazbin_backfill', 'farazbin_admin_backfill' );
function farazbin_admin_backfill() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	check_admin_referer( 'farazbin_backfill' );
	if ( function_exists( 'farazbin_backfill_schedule' ) ) {
		farazbin_backfill_schedule();
	}
	wp_safe_redirect( add_query_arg( 'farazbin_backfill', '1', admin_url( 'admin.php?page=farazsms-farazbin' ) ) );
	exit;
}

function farazbin_admin_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	$enabled    = get_option( 'farazsms_farazbin_enabled', '1' ) === '1';
	$registered = farazbin_is_registered();
	$wc         = farazbin_wc_active();
	$diag       = farazbin_diag_get();
	$unit       = get_option( 'farazsms_farazbin_price_unit', 'auto' );
	$mobile     = farazbin_get_mobile();
	$backfilling = get_option( 'farazsms_farazbin_backfill_running', '0' ) === '1';
	?>
	<div class="wrap" style="max-width:880px; direction:rtl;">
		<h1 style="font-size:22px; font-weight:800;">🔎 فراز بین — موتورِ مقایسه‌ی قیمت</h1>
		<p style="color:#9b9b9b; font-size:13px;">محصولاتِ فروشگاهِ شما به‌صورتِ خودکار و رایگان در فرازبین (مقایسه‌ی قیمت) دیده می‌شوند و خریدارِ گوگل، فروشگاهِ شما را پیدا می‌کند. هنگامِ اولین اتصال، اعتبارِ هدیه به موبایلِ شما داده می‌شود.</p>

		<?php if ( isset( $_GET['farazbin_saved'] ) ) : ?>
			<div class="notice notice-success"><p>تنظیمات ذخیره شد.</p></div>
		<?php endif; ?>
		<?php if ( isset( $_GET['farazbin_reregistered'] ) ) : ?>
			<div class="notice notice-success"><p>درخواستِ ثبت‌نامِ مجدد ارسال شد.</p></div>
		<?php endif; ?>
		<?php if ( isset( $_GET['farazbin_backfill'] ) ) : ?>
			<div class="notice notice-success"><p>همگام‌سازیِ کاملِ محصولات آغاز شد (در پس‌زمینه انجام می‌شود).</p></div>
		<?php endif; ?>
		<?php if ( isset( $_GET['farazbin_connect'] ) && $_GET['farazbin_connect'] === 'ok' ) : ?>
			<div class="notice notice-success"><p>✓ اتصال به فرازبین برقرار شد و فروشگاه ثبت شد. همگام‌سازیِ محصولات آغاز می‌شود.</p></div>
		<?php elseif ( isset( $_GET['farazbin_connect'] ) ) : ?>
			<div class="notice notice-error"><p>اتصال برقرار نشد — به «خطای ثبت‌نام» در جدولِ پایین نگاه کنید.</p></div>
		<?php endif; ?>
		<?php if ( ! $wc ) : ?>
			<div class="notice notice-warning"><p>فرازبین نیازمندِ ووکامرس است.</p></div>
		<?php endif; ?>
		<?php if ( ! $registered && $mobile === '' ) : ?>
			<div class="notice notice-warning"><p>شماره موبایلِ مالک از پروفایل فراز اس‌ام‌اس پیدا نشد. Api-Key را بررسی کنید؛ فیلد دستی پایین فقط پشتیبان است.</p></div>
		<?php endif; ?>

		<!-- وضعیت -->
		<div style="background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:18px 20px; margin:16px 0;">
			<h2 style="margin-top:0; font-size:15px;">وضعیتِ اتصال</h2>
			<table class="widefat striped" style="border:none;">
				<tbody>
					<tr><td style="width:210px;">وضعیتِ ثبت‌نام</td><td>
						<?php if ( $registered ) : ?>
							<strong style="color:#0c9765;">✓ ثبت‌شده</strong>
							(<span style="direction:ltr; display:inline-block;">site_id: <?php echo esc_html( farazbin_get_shop_id() ); ?></span>)
						<?php else : ?>
							<strong style="color:#83620d;">ثبت نشده</strong>
						<?php endif; ?>
					</td></tr>
					<tr><td>همگام‌سازیِ کاتالوگ</td><td><?php echo $backfilling ? '⏳ در حالِ انجام (پس‌زمینه)' : '—'; ?></td></tr>
					<tr><td>آخرین تلاشِ ثبت‌نام</td><td style="direction:ltr; text-align:right;"><?php echo esc_html( $diag['last_register_at'] ?? '—' ); ?></td></tr>
					<tr><td>آخرین مسیرِ ثبت‌نام</td><td style="direction:ltr; text-align:right;"><?php echo esc_html( $diag['last_register_endpoint'] ?? '—' ); ?></td></tr>
					<tr><td>خطای ثبت‌نام</td><td><?php echo esc_html( $diag['last_register_error'] ?? '' ) ?: '—'; ?></td></tr>
					<tr><td>آخرین ارسالِ محصول</td><td style="direction:ltr; text-align:right;"><?php echo esc_html( $diag['last_push_at'] ?? '—' ); ?></td></tr>
					<tr><td>خطای ارسالِ محصول</td><td><?php echo esc_html( $diag['last_push_error'] ?? '' ) ?: '—'; ?></td></tr>
				</tbody>
			</table>
			<div style="margin-top:12px; display:flex; gap:8px; flex-wrap:wrap;">
				<?php if ( ! $registered ) : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="farazbin_connect_now">
						<?php wp_nonce_field( 'farazbin_connect_now' ); ?>
						<button type="submit" class="button button-primary">🔌 اتصال به فرازبین (ثبت‌نام همین حالا)</button>
					</form>
				<?php else : ?>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="farazbin_backfill">
						<?php wp_nonce_field( 'farazbin_backfill' ); ?>
						<button type="submit" class="button button-primary">🔄 همگام‌سازیِ کاملِ همه‌ی محصولات</button>
					</form>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="farazbin_reregister">
						<?php wp_nonce_field( 'farazbin_reregister' ); ?>
						<button type="submit" class="button">↻ چرخشِ توکن</button>
					</form>
				<?php endif; ?>
			</div>
		</div>

		<!-- تنظیمات -->
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:18px 20px;">
			<input type="hidden" name="action" value="farazbin_save_settings">
			<?php wp_nonce_field( 'farazbin_save_settings' ); ?>
			<h2 style="margin-top:0; font-size:15px;">تنظیمات</h2>

			<div style="margin-bottom:14px;">
				<label style="display:block; font-weight:600; font-size:12px; margin-bottom:5px;">شماره موبایلِ مالکِ فروشگاه</label>
				<input type="text" name="farazbin_mobile" value="<?php echo esc_attr( $mobile ); ?>" placeholder="مثلاً 09120000000" dir="ltr" style="width:220px; padding:8px 12px; border:1px solid #e1e1e1; border-radius:8px; text-align:left;">
				<p style="font-size:11.5px; color:#9b9b9b; margin:5px 0 0;">خودکار از پروفایل فراز اس‌ام‌اس خوانده می‌شود؛ فقط اگر خالی بود، دستی وارد کنید.</p>
			</div>

			<label style="display:flex; align-items:center; gap:8px; margin-bottom:14px;">
				<input type="checkbox" name="farazbin_enabled" value="1" <?php checked( $enabled ); ?>>
				<span><strong>نمایشِ محصولاتم در فرازبین</strong> (پیش‌فرض روشن — برای خاموش‌کردن تیک را بردارید)</span>
			</label>

			<div style="margin-bottom:14px;">
				<label style="display:block; font-weight:600; font-size:12px; margin-bottom:5px;">واحدِ قیمتِ فروشگاه</label>
				<select name="farazbin_price_unit" style="padding:7px 10px; border:1px solid #e1e1e1; border-radius:8px;">
					<option value="auto" <?php selected( $unit, 'auto' ); ?>>تشخیصِ خودکار (پیشنهادی)</option>
					<option value="rial" <?php selected( $unit, 'rial' ); ?>>ریال</option>
					<option value="toman" <?php selected( $unit, 'toman' ); ?>>تومان (×۱۰ به ریال)</option>
				</select>
				<p style="font-size:11.5px; color:#9b9b9b; margin:5px 0 0;">فرازبین قیمت را به ریال می‌گیرد؛ اگر فروشگاه تومانی است «تومان» را انتخاب کنید.</p>
			</div>

			<button type="submit" class="button button-primary">💾 ذخیره</button>
		</form>
	</div>
	<?php
}
