<?php
/**
 * فرازبین (سمتِ افزونه) — پیکربندی و وضعیت.
 *
 * نقشِ افزونه: «منبعِ داده»ی موتورِ مقایسه‌ی قیمتِ فرازبین. طبقِ
 * plugin-integration-guide (قراردادِ واقعی و تست‌شده):
 *   - POST https://farazbin.co/api/register        → seller_site_id + token
 *   - POST https://farazbin.co/api/webhook/delta    → پوشِ هر محصول (هدرِ X-Farazbin-Token)
 * بدونِ فیدِ Pull و بدونِ HMAC (مدلِ ساده‌ی توکن).
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

// آدرسِ پایه‌ی سرورِ فرازبین (HTTPS). همه‌ی APIها زیرِ پیشوندِ /api هستند.
if ( ! defined( 'FARAZBIN_API_BASE_DEFAULT' ) ) {
	define( 'FARAZBIN_API_BASE_DEFAULT', 'https://farazbin.co' );
}

if ( ! defined( 'FARAZBIN_SCHEMA_VERSION' ) ) {
	define( 'FARAZBIN_SCHEMA_VERSION', 1 );
}

/**
 * آدرسِ پایه: ثابتِ wp-config > آپشن > پیش‌فرض. بدونِ اسلشِ انتها.
 */
function farazbin_api_base() {
	if ( defined( 'FARAZBIN_API_BASE' ) && FARAZBIN_API_BASE ) {
		return rtrim( (string) FARAZBIN_API_BASE, '/' );
	}
	$opt = (string) get_option( 'farazsms_farazbin_api_base', '' );
	if ( $opt !== '' ) {
		return rtrim( $opt, '/' );
	}
	return rtrim( FARAZBIN_API_BASE_DEFAULT, '/' );
}

function farazbin_wc_active() {
	return farazsms_is_wc_active();
}

/**
 * فعال‌بودنِ فرازبین: خودکار + قابلِ خاموش‌کردن (opt-out). پیش‌فرض روشن. نیازمندِ ووکامرس.
 */
function farazbin_is_enabled() {
	if ( ! farazbin_wc_active() ) {
		return false;
	}
	return get_option( 'farazsms_farazbin_enabled', '1' ) === '1';
}

/**
 * توکنِ اختصاصیِ سایت. خالی = هنوز ثبت‌نام نشده. در همه‌ی webhookها در هدر می‌رود.
 */
function farazbin_get_token() {
	return (string) get_option( 'farazsms_farazbin_token', '' );
}

/**
 * شناسه‌ی فروشگاه که سرور در /register برمی‌گرداند (مبنای external_id).
 */
function farazbin_get_seller_site_id() {
	return (string) get_option( 'farazsms_farazbin_seller_site_id', '' );
}

function farazbin_get_shop_id() {
	$shop_id = (string) get_option( 'farazsms_farazbin_shop_id', '' );
	if ( $shop_id !== '' ) {
		return $shop_id;
	}
	return farazbin_get_seller_site_id();
}

function farazbin_is_registered() {
	return farazbin_get_token() !== '' && farazbin_get_shop_id() !== '';
}

/**
 * موبایلِ مالکِ فروشگاه (هویتِ شخص). اجباری برای /register.
 * اولویت: مقداری که مدیر در صفحه‌ی فرازبین وارد کرده > منابعِ خودکار.
 */
function farazbin_get_mobile() {
	$m = trim( (string) get_option( 'farazsms_farazbin_mobile', '' ) );
	if ( $m === '' ) {
		$profile = farazsms_get_profile();
		if ( is_array( $profile ) && ! empty( $profile['mobile'] ) ) {
			$m = trim( (string) $profile['mobile'] );
			update_option( 'farazsms_farazbin_mobile', $m, false );
		}
	}
	if ( $m === '' ) {
		foreach ( array(
			(string) get_option( 'farazsms_admin_mobile', '' ),
			(string) get_option( 'farazsms_mobile', '' ),
		) as $cand ) {
			if ( trim( $cand ) !== '' ) {
				$m = trim( $cand );
				break;
			}
		}
	}
	if ( $m !== '' ) {
		$m = farazsms_normalize_phone( $m );
	}
	return $m;
}

function farazbin_get_profile_data() {
	$profile = farazsms_get_profile();
	if ( is_array( $profile ) ) {
		return $profile;
	}
	return array();
}

/**
 * ذخیره‌ی نتیجه‌ی ثبت‌نام: token + seller_site_id. (autoload خیر.)
 */
function farazbin_store_credentials( $data ) {
	if ( ! empty( $data['token'] ) ) {
		update_option( 'farazsms_farazbin_token', (string) $data['token'], false );
	}
	if ( isset( $data['seller_site_id'] ) ) {
		update_option( 'farazsms_farazbin_seller_site_id', (string) $data['seller_site_id'], false );
	}
	if ( isset( $data['shop_id'] ) ) {
		update_option( 'farazsms_farazbin_shop_id', (string) $data['shop_id'], false );
	}
	if ( isset( $data['customer_id'] ) ) {
		update_option( 'farazsms_farazbin_customer_id', (string) $data['customer_id'], false );
	}
	if ( isset( $data['profile_id'] ) ) {
		update_option( 'farazsms_farazbin_profile_id', (string) $data['profile_id'], false );
	}
}

function farazbin_clear_token() {
	delete_option( 'farazsms_farazbin_token' );
}

/**
 * external_id پایدار: "<seller_site_id>:<product_id>".
 */
function farazbin_external_id( $product_id ) {
	return farazbin_get_shop_id() . ':' . (string) $product_id;
}

/**
 * قیمت به ریال. آپشن farazsms_farazbin_price_unit: 'rial' یا 'toman' (×۱۰) — پیش‌فرض auto.
 */
function farazbin_price_to_rial( $price ) {
	if ( $price === '' || $price === null ) {
		return null;
	}
	$price = (int) round( (float) $price );
	$unit  = get_option( 'farazsms_farazbin_price_unit', 'auto' );
	if ( $unit === 'auto' ) {
		$cur  = function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'IRR';
		$unit = in_array( strtoupper( (string) $cur ), array( 'IRT', 'TOMAN', 'TMN' ), true ) ? 'toman' : 'rial';
	}
	return $unit === 'toman' ? $price * 10 : $price;
}

function farazbin_diag_set( $key, $value ) {
	$diag = get_option( 'farazsms_farazbin_diag', array() );
	if ( ! is_array( $diag ) ) {
		$diag = array();
	}
	$diag[ $key ] = $value;
	update_option( 'farazsms_farazbin_diag', $diag, false );
}

function farazbin_diag_get() {
	$diag = get_option( 'farazsms_farazbin_diag', array() );
	return is_array( $diag ) ? $diag : array();
}

function farazbin_iso8601( $timestamp = null ) {
	$ts = $timestamp ? (int) $timestamp : time();
	return gmdate( 'Y-m-d\TH:i:s\Z', $ts );
}
