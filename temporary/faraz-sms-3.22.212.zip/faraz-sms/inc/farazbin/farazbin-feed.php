<?php
/**
 * فرازبین — فیدِ محصولاتِ نرمال‌شده (Pull).
 *
 * endpoint روی خودِ سایتِ فروشگاه:
 *   GET /wp-json/farazbin/v1/products?cursor=<id>&updated_since=<ISO8601>&limit=100
 *
 * سرورِ فرازبین با نرخِ کنترل‌شده‌ی خودش این فید را می‌خواند. فقط با امضای معتبرِ HMAC
 * پاسخ داده می‌شود (تا رقبا قیمت‌ها را اسکرپ نکنند). پشتیبانی از ETag/304.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'rest_api_init', 'farazbin_feed_register_route' );
function farazbin_feed_register_route() {
	register_rest_route( 'farazbin/v1', '/products', array(
		'methods'             => 'GET',
		'callback'            => 'farazbin_feed_handle',
		'permission_callback' => 'farazbin_feed_permission',
	) );
}

/**
 * مجوز: فقط درخواستِ امضاشده‌ی معتبرِ سرورِ فرازبین. (GET → بدنه‌ی خام خالی است.)
 */
function farazbin_feed_permission() {
	if ( ! farazbin_is_enabled() || ! farazbin_is_registered() ) {
		return new WP_Error( 'farazbin_unavailable', 'فرازبین فعال/ثبت نشده است.', array( 'status' => 403 ) );
	}
	if ( ! farazbin_hmac_verify_incoming( '' ) ) {
		return new WP_Error( 'invalid_signature', 'امضای نامعتبر.', array( 'status' => 401 ) );
	}
	return true;
}

function farazbin_feed_handle( WP_REST_Request $request ) {
	global $wpdb;

	$cursor        = (int) $request->get_param( 'cursor' );
	$updated_since = (string) $request->get_param( 'updated_since' );
	$limit         = (int) $request->get_param( 'limit' );
	$limit         = $limit > 0 ? min( $limit, 500 ) : 100;

	$args = array(
		'post_type'        => 'product',
		'post_status'      => 'publish',
		'posts_per_page'   => $limit,
		'orderby'          => 'ID',
		'order'            => 'ASC',
		'fields'           => 'ids',
		'no_found_rows'    => true,
		'suppress_filters' => false,
	);
	if ( $updated_since !== '' ) {
		$ts = strtotime( $updated_since );
		if ( $ts ) {
			$args['date_query'] = array(
				array(
					'column'    => 'post_modified_gmt',
					'after'     => gmdate( 'Y-m-d H:i:s', $ts ),
					'inclusive' => true,
				),
			);
		}
	}

	// صفحه‌بندیِ cursor: ID > cursor (پایدارتر از offset روی کاتالوگِ بزرگ).
	$farazbin_cursor = $cursor;
	$where_cb        = function ( $where ) use ( $farazbin_cursor, $wpdb ) {
		if ( $farazbin_cursor > 0 ) {
			$where .= $wpdb->prepare( " AND {$wpdb->posts}.ID > %d", $farazbin_cursor );
		}
		return $where;
	};
	add_filter( 'posts_where', $where_cb );
	$query = new WP_Query( $args );
	remove_filter( 'posts_where', $where_cb );

	$ids   = $query->posts;
	$items = array();
	$last_modified_ts = 0;
	foreach ( $ids as $pid ) {
		$product = wc_get_product( $pid );
		if ( ! $product ) {
			continue;
		}
		$items[] = farazbin_feed_normalize_product( $product );
		$mod = get_post_modified_time( 'U', true, $pid );
		if ( $mod > $last_modified_ts ) {
			$last_modified_ts = $mod;
		}
	}

	$has_more    = count( $ids ) === $limit;
	$next_cursor = ! empty( $ids ) ? (string) end( $ids ) : '';

	$payload = array(
		'schema_version' => FARAZBIN_SCHEMA_VERSION,
		'shop_id'        => farazbin_get_shop_id(),
		'site_url'       => home_url(),
		'generated_at'   => farazbin_iso8601(),
		'next_cursor'    => $next_cursor,
		'has_more'       => $has_more,
		'items'          => $items,
	);

	// ETag/304: بر پایه‌ی cursor + تعداد + جدیدترین تغییر.
	$etag      = '"' . md5( $cursor . '|' . count( $items ) . '|' . $last_modified_ts . '|' . $updated_since ) . '"';
	$inm       = farazbin_read_header( 'If-None-Match' );
	$farazbin_diag_now = farazbin_iso8601();
	farazbin_diag_set( 'last_pull_at', $farazbin_diag_now );

	if ( $inm !== '' && trim( $inm ) === $etag ) {
		$resp = new WP_REST_Response( null, 304 );
		$resp->header( 'ETag', $etag );
		return $resp;
	}

	$resp = new WP_REST_Response( $payload, 200 );
	$resp->header( 'ETag', $etag );
	if ( $last_modified_ts > 0 ) {
		$resp->header( 'Last-Modified', gmdate( 'D, d M Y H:i:s', $last_modified_ts ) . ' GMT' );
	}
	$resp->header( 'Cache-Control', 'private, max-age=0' );
	return $resp;
}

/**
 * نرمال‌سازیِ یک محصولِ ووکامرس به فیلدهای قرارداد.
 *
 * @param WC_Product $product
 * @return array
 */
function farazbin_feed_normalize_product( $product ) {
	$pid = $product->get_id();

	// تصاویر: شاخص + گالری (URLِ کامل).
	$images = array();
	$main   = get_the_post_thumbnail_url( $pid, 'full' );
	if ( $main ) {
		$images[] = $main;
	}
	foreach ( (array) $product->get_gallery_image_ids() as $img_id ) {
		$url = wp_get_attachment_image_url( $img_id, 'full' );
		if ( $url ) {
			$images[] = $url;
		}
	}

	// دسته: مسیرِ «والد > فرزند» از عمیق‌ترین دسته.
	$category = '';
	$terms    = get_the_terms( $pid, 'product_cat' );
	if ( $terms && ! is_wp_error( $terms ) ) {
		$leaf = end( $terms );
		$path = array( $leaf->name );
		$parent = $leaf->parent;
		$guard = 0;
		while ( $parent && $guard < 6 ) {
			$pt = get_term( $parent, 'product_cat' );
			if ( ! $pt || is_wp_error( $pt ) ) {
				break;
			}
			array_unshift( $path, $pt->name );
			$parent = $pt->parent;
			$guard++;
		}
		$category = implode( ' > ', $path );
	}

	// برند: تکسونومیِ product_brand یا attribute pa_brand.
	$brand = '';
	foreach ( array( 'product_brand', 'pa_brand', 'pwb-brand' ) as $tax ) {
		$bt = get_the_terms( $pid, $tax );
		if ( $bt && ! is_wp_error( $bt ) ) {
			$brand = $bt[0]->name;
			break;
		}
	}

	$stock = $product->get_stock_status(); // instock | outofstock | onbackorder

	return array(
		'external_id'    => farazbin_external_id( $pid ),
		'product_id'     => (string) $pid,
		'title'          => $product->get_name(),
		'price'          => farazbin_price_to_rial( $product->get_price() ),
		'currency'       => 'IRR',
		'stock'          => $stock,
		'category'       => $category,
		'brand'          => $brand,
		'images'         => $images,
		'product_url'    => get_permalink( $pid ),
		'rating'         => array(
			'average' => (float) $product->get_average_rating(),
			'count'   => (int) $product->get_rating_count(),
		),
		'updated_at'     => farazbin_iso8601( get_post_modified_time( 'U', true, $pid ) ),
		'schema_version' => FARAZBIN_SCHEMA_VERSION,
	);
}
