<?php
/**
 * فرازبین — پوشِ محصول (POST /api/webhook/delta).
 *
 * هر تغییرِ محصول (ساخت/ویرایش/قیمت/موجودی/حذف) = یک درخواستِ سبکِ غیرمسدودکننده.
 * بدنه per-product و flat؛ احراز فقط با هدرِ X-Farazbin-Token. اجرا در cron.
 * بکفیلِ اولیه: همه‌ی محصولات با cursor پیمایش و delta فرستاده می‌شوند.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

// ---- هوک‌های تغییرِ محصول ----
add_action( 'woocommerce_update_product', 'farazbin_push_on_change', 20, 1 );
add_action( 'woocommerce_new_product', 'farazbin_push_on_change', 20, 1 );
add_action( 'woocommerce_product_set_stock_status', 'farazbin_push_on_change', 20, 1 );
add_action( 'woocommerce_variation_set_stock_status', 'farazbin_push_on_change', 20, 1 );
function farazbin_push_on_change( $product_id ) {
	farazbin_push_mark_changed( (int) $product_id );
}
// حذف/پیش‌نویس → in_stock:false (در flush بر اساسِ وضعیت محاسبه می‌شود).
add_action( 'wp_trash_post', 'farazbin_push_on_trash' );
function farazbin_push_on_trash( $post_id ) {
	if ( get_post_type( $post_id ) === 'product' ) {
		farazbin_push_mark_changed( (int) $post_id );
	}
}

/**
 * افزودنِ محصول به صفِ پوش + زمان‌بندیِ flush (غیرمسدودکننده).
 */
function farazbin_push_mark_changed( $product_id ) {
	if ( $product_id <= 0 || ! farazbin_is_enabled() || ! farazbin_is_registered() ) {
		return;
	}
	$queue = get_option( 'farazsms_farazbin_push_queue', array() );
	if ( ! is_array( $queue ) ) {
		$queue = array();
	}
	$queue[ $product_id ] = time();
	if ( count( $queue ) > 5000 ) {
		$queue = array_slice( $queue, -5000, null, true );
	}
	update_option( 'farazsms_farazbin_push_queue', $queue, false );
	if ( ! wp_next_scheduled( 'farazbin_push_cron' ) ) {
		wp_schedule_single_event( time() + 60, 'farazbin_push_cron' );
	}
}

add_action( 'farazbin_push_cron', 'farazbin_push_flush' );

/**
 * خالی‌کردنِ صف: حداکثر ۵۰ محصول در هر اجرا؛ بقیه دوباره زمان‌بندی می‌شوند.
 */
function farazbin_push_flush() {
	if ( ! farazbin_is_enabled() || ! farazbin_is_registered() ) {
		return;
	}

	// v3.22.42 (#1) circuit-breaker: اگر farazbin اخیراً خطا داده (مثلِ 502)، تا پایانِ backoff
	// اصلاً تلاش نکن — وگرنه هر دقیقه ۵۰ درخواستِ ناموفقِ ۵ثانیه‌ای، کرون/loopback را می‌لولاند.
	$backoff_until = (int) get_option( 'farazsms_farazbin_push_backoff', 0 );
	if ( $backoff_until > time() ) {
		if ( ! wp_next_scheduled( 'farazbin_push_cron' ) ) {
			wp_schedule_single_event( $backoff_until + 5, 'farazbin_push_cron' );
		}
		return;
	}

	$queue = get_option( 'farazsms_farazbin_push_queue', array() );
	if ( ! is_array( $queue ) || empty( $queue ) ) {
		return;
	}
	$ids   = array_map( 'intval', array_keys( $queue ) );
	$batch = array_slice( $ids, 0, 50 );

	$hard_fail = false;
	foreach ( $batch as $pid ) {
		$result = farazbin_push_send_one( $pid );
		if ( $result === 'fail' ) {
			// خطای گذرا/سرور → توقفِ batch (بقیه در صف می‌ماند) و فعال‌سازیِ backoff.
			$hard_fail = true;
			break;
		}
		// 'ok' یا 'skip' → از صف حذف شود (skip = محصولِ سمیِ دائمی؛ نباید صف را قفل کند).
		unset( $queue[ $pid ] );
	}
	update_option( 'farazsms_farazbin_push_queue', $queue, false );

	if ( $hard_fail ) {
		$fails = (int) get_option( 'farazsms_farazbin_push_fails', 0 ) + 1;
		$delay = min( 3600, 300 * $fails ); // backoffِ تصاعدی: ۵دقیقه، ۱۰، ... تا سقفِ ۱ساعت.
		update_option( 'farazsms_farazbin_push_fails', $fails, false );
		update_option( 'farazsms_farazbin_push_backoff', time() + $delay, false );
		if ( ! wp_next_scheduled( 'farazbin_push_cron' ) ) {
			wp_schedule_single_event( time() + $delay + 5, 'farazbin_push_cron' );
		}
		return;
	}

	// موفق → شمارنده‌ی شکست و backoff را ریست کن.
	if ( (int) get_option( 'farazsms_farazbin_push_fails', 0 ) > 0 ) {
		update_option( 'farazsms_farazbin_push_fails', 0, false );
		delete_option( 'farazsms_farazbin_push_backoff' );
	}

	if ( ! empty( $queue ) && ! wp_next_scheduled( 'farazbin_push_cron' ) ) {
		wp_schedule_single_event( time() + 60, 'farazbin_push_cron' );
	}
}

/**
 * ساختِ بدنه‌ی یک محصول طبقِ قرارداد.
 *
 * @return array|null  null اگر محصول معتبر نباشد.
 */
function farazbin_push_build_item( $product_id ) {
	if ( ! function_exists( 'wc_get_product' ) ) {
		return null;
	}
	$product = wc_get_product( $product_id );
	if ( ! $product ) {
		return null;
	}
	$in_stock = ( $product->get_status() === 'publish' ) && $product->is_in_stock();

	$image = get_the_post_thumbnail_url( $product_id, 'full' );

	$category = '';
	$terms    = get_the_terms( $product_id, 'product_cat' );
	if ( $terms && ! is_wp_error( $terms ) ) {
		$leaf     = end( $terms );
		$category = $leaf->name;
	}

	$item = array(
		'external_id' => farazbin_external_id( $product_id ),
		'title'       => $product->get_name(),
		'in_stock'    => (bool) $in_stock,
		'product_url' => get_permalink( $product_id ),
	);
	$price = farazbin_price_to_rial( $product->get_price() );
	if ( $price !== null ) {
		$item['price_rial'] = $price;
	}
	if ( $image ) {
		$item['image_url'] = $image;
	}
	if ( $category !== '' ) {
		$item['source_category'] = $category;
	}
	return $item;
}

/**
 * ارسالِ یک محصول به /api/webhook/delta با هدرِ توکن.
 */
/**
 * @return string 'ok' (ارسال شد) | 'skip' (خطای دائمیِ همین محصول — از صف حذف شود) |
 *                'fail' (خطای گذرا/سرور — batch متوقف و circuit-breaker فعال شود).
 */
function farazbin_push_send_one( $product_id ) {
	$item = farazbin_push_build_item( $product_id );
	if ( $item === null ) {
		return 'skip'; // محصولِ نامعتبر = از صف حذف، نه شکستِ سرور.
	}
	$resp = wp_remote_post( farazbin_api_base() . '/api/webhook/delta', array(
		// v3.22.44 (بازبینی T2): از ۵ به ۸ برگشت — روی cron اجرا می‌شود (صفحه‌ی کاربر را بلاک
		// نمی‌کند)، و ۵ثانیه زیرِ اینترنتِ ملی برای farazbinِ سالمِ کند خیلی تند بود و circuit-breaker
		// را بی‌جهت فعال می‌کرد. مقاومتِ اصلی از خودِ breaker می‌آید نه از timeoutِ کوتاه.
		'timeout' => 8,
		'headers' => array(
			'Content-Type'    => 'application/json',
			'X-Farazbin-Token' => farazbin_get_token(),
		),
		'body'    => wp_json_encode( $item ),
	) );

	farazbin_diag_set( 'last_push_at', farazbin_iso8601() );

	if ( is_wp_error( $resp ) ) {
		farazbin_diag_set( 'last_push_error', $resp->get_error_message() );
		return 'fail'; // خطای ارتباط/timeout = گذرا.
	}
	$code = (int) wp_remote_retrieve_response_code( $resp );
	if ( $code === 401 ) {
		// توکن نامعتبر → چرخه‌ی ثبت‌نامِ مجدد (این محصول را رد کن، breaker را فعال نکن).
		farazbin_diag_set( 'last_push_error', 'unauthorized (401) — token نامعتبر' );
		if ( function_exists( 'farazbin_register_force' ) ) {
			farazbin_register_force();
		}
		return 'skip';
	}
	if ( $code >= 200 && $code < 300 ) {
		farazbin_diag_set( 'last_push_error', '' );
		return 'ok';
	}
	// v3.22.44 (بازبینی T1): 4xxِ دائمی (به‌جز 429) = مشکلِ همین محصول → skip (از صف حذف) تا یک
	// «محصولِ سمی» کلِ صف را برای همیشه قفل نکند. فقط 429/5xx = گذرا → circuit-breaker.
	if ( $code >= 400 && $code < 500 && $code !== 429 ) {
		farazbin_diag_set( 'last_push_error', 'HTTP ' . $code . ' (محصولِ نامعتبر، رد شد)' );
		return 'skip';
	}
	farazbin_diag_set( 'last_push_error', 'HTTP ' . $code );
	return 'fail'; // 429/5xx = گذرا.
}

// ============================================================================
// بکفیلِ اولیه — پیمایشِ همه‌ی محصولات با cursor و ارسالِ delta.
// ============================================================================

add_action( 'farazbin_backfill_cron', 'farazbin_backfill_run' );

/**
 * شروعِ بکفیل (پس از اولین ثبت‌نام یا با دکمه‌ی ادمین).
 */
function farazbin_backfill_schedule() {
	if ( ! farazbin_is_enabled() || ! farazbin_is_registered() ) {
		return;
	}
	update_option( 'farazsms_farazbin_backfill_cursor', 0, false );
	update_option( 'farazsms_farazbin_backfill_running', '1', false );
	if ( ! wp_next_scheduled( 'farazbin_backfill_cron' ) ) {
		wp_schedule_single_event( time() + 15, 'farazbin_backfill_cron' );
	}
	farazbin_diag_set( 'backfill_started_at', farazbin_iso8601() );
}

/**
 * یک صفحه از بکفیل (۵۰ محصول)؛ اگر بیشتر بود، دوباره زمان‌بندی می‌کند.
 */
function farazbin_backfill_run() {
	if ( ! farazbin_is_enabled() || ! farazbin_is_registered() ) {
		update_option( 'farazsms_farazbin_backfill_running', '0', false );
		return;
	}
	global $wpdb;
	$cursor = (int) get_option( 'farazsms_farazbin_backfill_cursor', 0 );

	$where_cb = function ( $where ) use ( $cursor, $wpdb ) {
		if ( $cursor > 0 ) {
			$where .= $wpdb->prepare( " AND {$wpdb->posts}.ID > %d", $cursor );
		}
		return $where;
	};
	add_filter( 'posts_where', $where_cb );
	$q = new WP_Query( array(
		'post_type'      => 'product',
		'post_status'    => 'publish',
		'posts_per_page' => 50,
		'orderby'        => 'ID',
		'order'          => 'ASC',
		'fields'         => 'ids',
		'no_found_rows'  => true,
	) );
	remove_filter( 'posts_where', $where_cb );

	$ids = $q->posts;
	if ( empty( $ids ) ) {
		update_option( 'farazsms_farazbin_backfill_running', '0', false );
		farazbin_diag_set( 'backfill_done_at', farazbin_iso8601() );
		return;
	}
	foreach ( $ids as $pid ) {
		farazbin_push_send_one( (int) $pid );
	}
	update_option( 'farazsms_farazbin_backfill_cursor', (int) end( $ids ), false );
	if ( ! wp_next_scheduled( 'farazbin_backfill_cron' ) ) {
		wp_schedule_single_event( time() + 30, 'farazbin_backfill_cron' );
	}
}
