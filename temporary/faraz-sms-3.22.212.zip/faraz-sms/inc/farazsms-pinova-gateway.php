<?php
/**
 * یکپارچه‌سازیِ افزونه‌ی «پینوا» (ورود/ثبت‌نام با OTP) با فراز اس‌ام‌اس.
 *
 * چرا این شکل؟ پینوا درگاه‌ها را فقط با
 *
 *   glob( PINOVA_DIR . '/src/Gateways/*.php' )
 *
 * و namespaceِ ثابتِ Pinova\Gateways کشف می‌کند — هیچ hook/filterی برای ثبتِ
 * درگاهِ بیرونی ندارد. پس تنها راهِ ظاهرشدنِ «فراز اس‌ام‌اس» در فهرستِ سرویس‌دهنده‌ها
 * این است که یک فایلِ کلاس فیزیکی داخلِ پوشه‌ی خودِ پینوا باشد.
 *
 * این ماژول (داخلِ افزونه‌ی فراز) آن فایل را به‌صورتِ self-healing مدیریت می‌کند:
 *   - وقتی پینوا فعال است، فایلِ درگاه را داخلِ پوشه‌ی پینوا می‌نویسد.
 *   - بعد از هر آپدیتِ پینوا (که فایل را پاک می‌کند) دوباره می‌سازد.
 *   - اگر هاست فقط‌خواندنی بود، اخطار با راهنمای دستی نشان می‌دهد.
 *   - با غیرفعال‌شدنِ افزونه‌ی فراز، فایل را پاک می‌کند تا درگاهِ بی‌کار نماند.
 *
 * منطقِ پترن در همین‌جا (سمتِ فراز) می‌ماند؛ فایلِ درگاه نازک است و فقط به توابعِ
 * سراسریِ فراز delegate می‌کند.
 *
 * مطابقِ خواسته: دسته‌بندیِ پترن = ۱، یک متغیر (%code%)، انتهای متنِ پترن دامنه‌ی
 * سایت (که farazsms_create_pattern خودش اضافه می‌کند)، احراز با «کلید دسترسی»،
 * خطِ پیش‌فرضِ ارسال = 90008361.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

// با تغییرِ این نسخه، فایلِ درگاه روی همه‌ی سایت‌ها دوباره نوشته (به‌روزرسانی) می‌شود.
const FARAZSMS_PINOVA_GATEWAY_VERSION = '1';
const FARAZSMS_PINOVA_DEFAULT_LINE    = '90008361';

// ============================================================================
// تشخیصِ پینوا و مسیرِ هدف
// ============================================================================

/**
 * آیا پینوا روی این سایت حضور دارد؟
 *
 * @return bool
 */
function farazsms_pinova_present() {
	if ( defined( 'PINOVA_VERSION' ) || class_exists( '\\Pinova\\Gateways\\BaseGateway' ) ) {
		return true;
	}
	return defined( 'WP_PLUGIN_DIR' ) && is_dir( WP_PLUGIN_DIR . '/pinova/src/Gateways' );
}

/**
 * مسیرِ فایلِ درگاه داخلِ پوشه‌ی پینوا.
 *
 * @return string مسیرِ کامل یا '' اگر پیدا نشد.
 */
function farazsms_pinova_gateway_target() {
	if ( defined( 'PINOVA_DIR' ) ) {
		return rtrim( PINOVA_DIR, '/\\' ) . '/src/Gateways/FarazSMS.php';
	}
	if ( defined( 'WP_PLUGIN_DIR' ) && is_dir( WP_PLUGIN_DIR . '/pinova/src/Gateways' ) ) {
		return WP_PLUGIN_DIR . '/pinova/src/Gateways/FarazSMS.php';
	}
	return '';
}

// ============================================================================
// قالبِ فایلِ درگاه (نوشته‌شده داخلِ پینوا)
// ============================================================================

/**
 * متنِ کاملِ فایلِ کلاسِ درگاه. (nowdoc — هیچ درون‌یابی‌ای نمی‌شود؛ کاملاً literal.)
 *
 * @return string
 */
function farazsms_pinova_gateway_template() {
	$tpl = <<<'PHP'
<?php
/**
 * درگاه «فراز اس ام اس» برای پینوا.
 *
 * این فایل به‌صورتِ خودکار توسطِ افزونه‌ی فراز اس ام اس ساخته و نگه‌داری می‌شود.
 * دست‌کاری نکنید؛ افزونه‌ی فراز آن را دوباره می‌سازد.
 *
 * Gateway-Template-Version: __TPLVER__
 */

namespace Pinova\Gateways;

use Exception;

// اگر کلاسِ پایه (پینوا) موجود نبود، این فایل بی‌اثر می‌ماند.
if ( ! class_exists( '\\Pinova\\Gateways\\BaseGateway' ) ) {
	return;
}

class FarazSMS extends BaseGateway {

	protected string $name = 'فراز اس ام اس';

	protected string $url = 'farazsms.com';

	protected function farazsms_apikey(): string {
		$k = (string) $this->get_option( 'api_key' );
		if ( $k === '' && function_exists( 'farazsms_get_apikey' ) ) {
			$k = (string) farazsms_get_apikey();
		}
		return $k;
	}

	protected function farazsms_sender(): string {
		$s = trim( (string) $this->get_option( 'sender' ) );
		return $s !== '' ? $s : '90008361';
	}

	public function is_enable(): bool {
		return $this->farazsms_apikey() !== ''
			&& function_exists( 'farazsms_send_pattern_sms_raw' );
	}

	/**
	 * @throws Exception
	 */
	public function send( string $mobile, string $message ): bool {

		if ( $this->farazsms_apikey() === '' || ! function_exists( 'farazsms_send_pattern_sms_raw' ) ) {
			throw new Exception( 'افزونه فراز اس ام اس فعال یا پیکربندی نشده است.' );
		}

		if ( function_exists( 'farazsms_normalize_phone' ) ) {
			$mobile = farazsms_normalize_phone( $mobile );
		}

		// پترنِ صریح: pattern:CODE\nvar:val
		if ( $this->is_pattern( $message ) ) {
			$p = $this->parse_pattern( $message );
			return $this->farazsms_send_pattern( $mobile, $p['code'], $p['vars'] );
		}

		// کدِ یکبارمصرف (عددی) → پترنِ تک‌متغیرهٔ خودکارساخته‌شده.
		$trimmed = trim( $message );
		if ( $trimmed !== '' && is_numeric( $trimmed ) ) {
			$code = $this->farazsms_pattern_code();
			if ( $code === '' ) {
				throw new Exception( 'پترن فراز اس ام اس هنوز ساخته یا تأیید نشده است.' );
			}
			return $this->farazsms_send_pattern( $mobile, $code, array( 'code' => $trimmed ) );
		}

		// متنِ آزاد → پیامکِ ساده.
		return $this->farazsms_send_simple( $mobile, $message );
	}

	protected function farazsms_pattern_code(): string {
		$code = (string) $this->get_option( 'pattern_code' );
		if ( $code === '' && function_exists( 'farazsms_pinova_ensure_pattern' ) ) {
			$code = (string) farazsms_pinova_ensure_pattern();
			if ( $code !== '' ) {
				$this->set_option( 'pattern_code', $code );
			}
		}
		return $code;
	}

	/**
	 * @throws Exception
	 */
	protected function farazsms_send_pattern( string $mobile, string $code, array $vars ): bool {
		if ( $code === '' ) {
			throw new Exception( 'کد پترن مشخص نیست.' );
		}
		$vars   = array_map( 'strval', $vars );
		$result = farazsms_send_pattern_sms_raw( $mobile, $code, $vars, $this->farazsms_sender() );
		if ( $result === 'success' ) {
			return true;
		}
		throw new Exception( is_string( $result ) && $result !== '' ? $result : 'خطا در ارسال پیامک فراز اس ام اس.' );
	}

	/**
	 * @throws Exception
	 */
	protected function farazsms_send_simple( string $mobile, string $text ): bool {
		$body = wp_json_encode( array(
			'text'          => $text,
			'line_number'   => $this->farazsms_sender(),
			'recipients'    => array( $mobile ),
			'number_format' => 'english',
		) );

		$curl = curl_init();
		curl_setopt_array( $curl, array(
			CURLOPT_URL            => farazsms_sms_api_url( 'sms/simple' ),
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_CONNECTTIMEOUT => 5,
			CURLOPT_TIMEOUT        => 15,
			CURLOPT_CUSTOMREQUEST  => 'POST',
			CURLOPT_POSTFIELDS     => $body,
			CURLOPT_HTTPHEADER     => array(
				'Accept: application/json',
				'Content-Type: application/json',
				'Api-Key: ' . $this->farazsms_apikey(),
			),
		) );
		$response = curl_exec( $curl );
		if ( curl_errno( $curl ) ) {
			$err = curl_error( $curl );
			curl_close( $curl );
			throw new Exception( $err );
		}
		curl_close( $curl );

		$data = json_decode( $response, true );
		if ( isset( $data['status'] ) && $data['status'] === 'success' ) {
			return true;
		}
		throw new Exception( isset( $data['message'] ) ? (string) $data['message'] : 'خطا در ارسال پیامک فراز اس ام اس.' );
	}

	public function options(): array {

		$ready    = function_exists( 'farazsms_get_apikey' );
		$auto_key = $ready ? (string) farazsms_get_apikey() : '';
		$pattern  = (string) $this->get_option( 'pattern_code' );

		$key_desc = $auto_key !== ''
			? 'به‌صورتِ پیش‌فرض از کلیدِ دسترسیِ افزونه فراز اس ام اس خوانده می‌شود. برای خطِ متفاوت می‌توانید کلیدِ دیگری وارد کنید.'
			: 'کلیدِ دسترسیِ سامانه فراز را وارد کنید (از تنظیماتِ افزونه فراز اس ام اس).';

		$pattern_desc = $pattern !== ''
			? 'پترن ساخته شد: ' . $pattern . ' — پس از تأییدِ پنلِ فراز فعال می‌شود.'
			: 'خالی بگذارید؛ هنگامِ ذخیره به‌صورتِ خودکار ساخته می‌شود (دسته ۱، یک متغیر، پایان با دامنه‌ی سایت).';

		return array(
			array(
				'label'       => 'کلید دسترسی',
				'key'         => 'api_key',
				'field_class' => 'ltr',
				'default'     => $auto_key,
				'description' => $key_desc,
			),
			array(
				'label'       => 'خط فرستنده',
				'key'         => 'sender',
				'field_class' => 'ltr',
				'default'     => '90008361',
				'description' => 'خطِ پیش‌فرضِ ارسال 90008361 است. در صورتِ داشتنِ خطِ اختصاصی، شماره‌ی آن را وارد کنید.',
			),
			array(
				'label'       => 'کد پترن',
				'key'         => 'pattern_code',
				'field_class' => 'ltr',
				'description' => $pattern_desc,
			),
		);
	}
}
PHP;

	return str_replace( '__TPLVER__', FARAZSMS_PINOVA_GATEWAY_VERSION, $tpl );
}

// ============================================================================
// نوشتن/به‌روزرسانیِ فایل (self-healing)
// ============================================================================

add_action( 'admin_init', 'farazsms_pinova_sync_gateway' );
add_action( 'upgrader_process_complete', 'farazsms_pinova_after_upgrade', 10, 0 );

function farazsms_pinova_after_upgrade() {
	// بعد از آپدیتِ هر افزونه‌ای (از جمله پینوا) ممکن است فایل پاک شده باشد.
	delete_option( 'farazsms_pinova_synced' );
	delete_transient( 'farazsms_pinova_write_failed' );
	farazsms_pinova_sync_gateway();
}

function farazsms_pinova_sync_gateway() {
	if ( ! farazsms_pinova_present() ) {
		return;
	}
	$target = farazsms_pinova_gateway_target();
	if ( $target === '' ) {
		return;
	}

	// اگر همین نسخه قبلاً نوشته شده و فایل هنوز هست، کاری نکن (کم‌هزینه).
	if ( get_option( 'farazsms_pinova_synced', '' ) === FARAZSMS_PINOVA_GATEWAY_VERSION && file_exists( $target ) ) {
		return;
	}

	$dir = dirname( $target );
	if ( ! is_dir( $dir ) ) {
		return;
	}
	if ( ! is_writable( $dir ) || ( file_exists( $target ) && ! is_writable( $target ) ) ) {
		set_transient( 'farazsms_pinova_write_failed', $target, DAY_IN_SECONDS );
		return;
	}

	$written = @file_put_contents( $target, farazsms_pinova_gateway_template() );
	if ( $written === false ) {
		set_transient( 'farazsms_pinova_write_failed', $target, DAY_IN_SECONDS );
		return;
	}

	update_option( 'farazsms_pinova_synced', FARAZSMS_PINOVA_GATEWAY_VERSION, false );
	delete_transient( 'farazsms_pinova_write_failed' );
}

/**
 * با غیرفعال‌شدنِ افزونه‌ی فراز، فایلِ درگاه را پاک کن تا پینوا درگاهِ بی‌کار نشان ندهد.
 */
function farazsms_pinova_remove_gateway() {
	$target = farazsms_pinova_gateway_target();
	if ( $target !== '' && file_exists( $target ) && is_writable( $target ) ) {
		@unlink( $target );
	}
	delete_option( 'farazsms_pinova_synced' );
}
if ( defined( 'FARAZSMS_PLUGIN_FILE' ) ) {
	register_deactivation_hook( FARAZSMS_PLUGIN_FILE, 'farazsms_pinova_remove_gateway' );
}

// ============================================================================
// ساختِ خودکارِ پترن (سمتِ فراز — منطق این‌جا می‌ماند)
// ============================================================================

/**
 * اطمینان از وجودِ پترنِ ورودِ پینوا؛ در صورتِ نبود، می‌سازد و کش می‌کند.
 *
 * دسته‌بندی = ۱، یک متغیر (%code%)، و farazsms_create_pattern انتهای متن را
 * با دامنه‌ی سایت تکمیل می‌کند.
 *
 * @return string کدِ پترن یا '' در صورتِ ناتوانی.
 */
function farazsms_pinova_ensure_pattern() {
	$code = (string) get_option( 'farazsms_pinova_pattern_code', '' );
	if ( $code !== '' ) {
		return $code;
	}
	if ( ! farazsms_is_ready() ) {
		return '';
	}

	$resp = farazsms_create_pattern( 'کد ورود شما: %code%', 1, 'افزونه فراز اس ام اس / ورود پینوا' );
	$data = is_string( $resp ) ? json_decode( $resp, true ) : $resp;

	$code = '';
	if ( is_array( $data ) ) {
		if ( ! empty( $data['data']['code'] ) ) {
			$code = (string) $data['data']['code'];
		} elseif ( ! empty( $data['data'] ) && is_string( $data['data'] ) ) {
			$code = (string) $data['data'];
		} elseif ( ! empty( $data['code'] ) ) {
			$code = (string) $data['code'];
		}
	}

	if ( $code !== '' ) {
		update_option( 'farazsms_pinova_pattern_code', $code, false );
		farazsms_pinova_store_pattern_in_gateway( $code );
	}
	return $code;
}

/**
 * کدِ پترن را داخلِ تنظیماتِ درگاهِ پینوا هم می‌نویسد تا در فیلدِ «کد پترن» دیده شود.
 *
 * @param string $code
 */
function farazsms_pinova_store_pattern_in_gateway( $code ) {
	$opt = get_option( 'pinova_gateway_farazsms', array() );
	if ( ! is_array( $opt ) ) {
		$opt = array();
	}
	if ( ( $opt['pattern_code'] ?? '' ) !== $code ) {
		$opt['pattern_code'] = $code;
		update_option( 'pinova_gateway_farazsms', $opt );
	}
}

// وقتی مدیر تنظیماتِ درگاهِ فراز را در پینوا ذخیره کرد، پترن را خودکار بساز.
add_action( 'add_option_pinova_gateway_farazsms', 'farazsms_pinova_on_gateway_saved', 10, 0 );
add_action( 'update_option_pinova_gateway_farazsms', 'farazsms_pinova_on_gateway_saved', 10, 0 );
function farazsms_pinova_on_gateway_saved() {
	if ( (string) get_option( 'farazsms_pinova_pattern_code', '' ) === '' ) {
		farazsms_pinova_ensure_pattern();
	}
}

// ============================================================================
// اخطارِ هاستِ فقط‌خواندنی (راهنمای دستی)
// ============================================================================

add_action( 'admin_notices', 'farazsms_pinova_write_failed_notice' );
function farazsms_pinova_write_failed_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	$target = get_transient( 'farazsms_pinova_write_failed' );
	if ( ! $target ) {
		return;
	}
	?>
	<div class="notice notice-warning" style="padding:12px 16px;">
		<p style="font-size:13px; line-height:2; margin:0;">
			برای افزودنِ «فراز اس ام اس» به سرویس‌دهنده‌های پینوا، باید فایلِ درگاه داخلِ پوشه‌ی پینوا نوشته شود،
			ولی این مسیر روی هاستِ شما <strong>قابلِ نوشتن نیست</strong>:
		</p>
		<p style="margin:6px 0;">
			<code style="direction:ltr; display:inline-block; background:#f6f7f7; border:1px solid #ddd; padding:4px 8px; border-radius:4px;"><?php echo esc_html( (string) $target ); ?></code>
		</p>
		<p style="font-size:12.5px; color:#555; margin:0;">
			لطفاً دسترسیِ نوشتنِ پوشه‌ی پینوا را موقتاً فعال کنید (یا از پشتیبانیِ هاست بخواهید)، سپس این صفحه را تازه کنید.
		</p>
	</div>
	<?php
}
