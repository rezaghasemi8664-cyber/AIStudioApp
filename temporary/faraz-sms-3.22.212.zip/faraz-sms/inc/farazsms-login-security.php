<?php
/**
 * تنظیماتِ امنیتی — پیامکِ هشدارِ ورودِ ادمین.
 *
 * هر بار که کاربری با نقشِ مدیر (یا نقش‌های انتخابیِ دیگر مثلِ ویرایشگر) وارد سایت
 * وردپرسی می‌شود، یک پیامک به مدیرِ اصلی (شماره‌ی تنظیماتِ امور فروش) ارسال می‌شود:
 * «ورود با نام کاربریِ فلان، سطح دسترسیِ فلان، در تاریخ/ساعتِ فلان».
 *
 * - پیش‌فرض فعال (فقط برای نقشِ مدیر). مدیر می‌تواند نقش‌های دیگر را هم اضافه کند.
 * - پترنِ پیش‌فرض از پیش ساخته شده (کدِ t7LzFBay0o)؛ مدیر می‌تواند پترنِ دلخواه بسازد.
 * - ارسالِ پیامک به‌صورتِ non-blocking (با wp_schedule_single_event) تا ورود کند نشود.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const FARAZSMS_LOGIN_SECURITY_OPTION = 'farazsms_login_security_settings';

/**
 * تنظیمات + پیش‌فرض‌ها.
 *
 * @return array
 */
function farazsms_login_security_settings() {
	$defaults = array(
		'enabled'      => '1',                       // پیش‌فرض فعال
		'roles'        => array( 'administrator' ),  // نقش‌هایی که ورودشان هشدار می‌دهد
		'recipient'    => '',                        // خالی = شماره‌ی مدیرِ امور فروش (زنجیره‌ی fallback)
		'pattern_code' => 't7LzFBay0o',              // پترنِ از پیش ساخته‌شده
		'message'      => farazsms_login_security_default_message(),
	);
	$saved = get_option( FARAZSMS_LOGIN_SECURITY_OPTION, array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}
	$s = array_merge( $defaults, $saved );
	if ( ! is_array( $s['roles'] ) || empty( $s['roles'] ) ) {
		$s['roles'] = array( 'administrator' );
	}
	if ( trim( (string) $s['message'] ) === '' ) {
		$s['message'] = $defaults['message'];
	}
	return $s;
}

/**
 * متنِ پیش‌فرضِ پترن (برای ساختِ پترنِ دلخواه). متغیرها: username, role, time.
 *
 * @return string
 */
function farazsms_login_security_default_message() {
	return "هشدار\n"
		. "ورود به ادمین سایت\n"
		. "نام کاربری\n"
		. "%username%\n"
		. "سطح دسترسی\n"
		. "%role%\n"
		. "تاریخ ورود\n"
		. "%time%";
}

/**
 * دامنه‌ی سایت — همان مقداری که در متغیرهای پترن می‌رود.
 *
 * @return string
 */
function farazsms_login_security_site_domain() {
	return farazsms_pattern_site_domain();
}

/**
 * برچسبِ فارسیِ نقش.
 *
 * @param string $role
 * @return string
 */
function farazsms_login_security_role_label( $role ) {
	$map = array(
		'administrator' => 'مدیر کل',
		'editor'        => 'ویرایشگر',
		'author'        => 'نویسنده',
		'contributor'   => 'مشارکت‌کننده',
		'subscriber'    => 'مشترک',
		'shop_manager'  => 'مدیر فروشگاه',
		'customer'      => 'مشتری',
	);
	if ( isset( $map[ $role ] ) ) {
		return $map[ $role ];
	}
	// fallback به نامِ ترجمه‌شده‌ی وردپرس.
	$wp_roles = function_exists( 'wp_roles' ) ? wp_roles() : null;
	if ( $wp_roles && isset( $wp_roles->role_names[ $role ] ) ) {
		return translate_user_role( $wp_roles->role_names[ $role ] );
	}
	return (string) $role;
}

/**
 * شماره(های) گیرنده‌ی هشدار — زنجیره‌ی fallback:
 * تنظیماتِ امنیتی → تنظیماتِ گزارشِ فروش → شماره‌ی دیدگاه → شماره‌ی مالکِ پنل.
 *
 * @return array
 */
function farazsms_login_security_recipients() {
	$s   = farazsms_login_security_settings();
	$raw = trim( (string) $s['recipient'] );

	if ( $raw === '' ) {
		$ds = get_option( 'farazsms_daily_sales_settings', array() );
		if ( is_array( $ds ) && ! empty( $ds['admin_phones'] ) ) {
			$raw = (string) $ds['admin_phones'];
		}
	}
	if ( $raw === '' ) {
		$raw = (string) get_option( 'farazsms_comment_admin_phones', '' );
	}
	if ( $raw === '' ) {
		$p = farazsms_get_profile();
		if ( is_array( $p ) && ! empty( $p['mobile'] ) ) {
			$raw = (string) $p['mobile'];
		}
	}
	return array_values( array_filter( array_map( 'trim', explode( ',', $raw ) ) ) );
}

/**
 * هوکِ ورود — اگر نقشِ کاربر در فهرستِ انتخابی بود، ارسالِ هشدار را زمان‌بندی می‌کند
 * (non-blocking: خودِ ارسال در یک رویدادِ cronِ فوری انجام می‌شود تا ورود کند نشود).
 *
 * @param string  $user_login
 * @param WP_User $user
 */
function farazsms_login_security_on_login( $user_login, $user = null ) {
	if ( ! ( $user instanceof WP_User ) ) {
		$user = get_user_by( 'login', $user_login );
	}
	if ( ! $user instanceof WP_User ) {
		return;
	}

	$s = farazsms_login_security_settings();
	if ( $s['enabled'] !== '1' ) {
		return;
	}
	$watch_roles = (array) $s['roles'];
	$user_roles  = (array) $user->roles;
	$matched     = array_values( array_intersect( $user_roles, $watch_roles ) );
	if ( empty( $matched ) ) {
		return; // نقشِ این کاربر در فهرستِ هشدار نیست.
	}

	$pattern = trim( (string) $s['pattern_code'] );
	if ( $pattern === '' ) {
		return;
	}
	$recipients = farazsms_login_security_recipients();
	if ( empty( $recipients ) ) {
		return;
	}

	// v3.22.30: ساعتِ هشدارِ ورود باید همیشه به وقتِ ایران (Asia/Tehran, +03:30) باشد.
	// قبلاً current_time() (رشته‌ی از-قبل-localize) دوباره در helper پارس می‌شد و آفست دوبار
	// اعمال می‌شد؛ یا اگر timezoneِ سایت روی UTC بود، ساعتِ UTC می‌رفت. حالا timestampِ خامِ UTC
	// را با منطقه‌ی زمانیِ صریحِ تهران به helper می‌دهیم تا دقیقاً یک‌بار و درست تبدیل شود.
	$now  = time();
	$time = farazsms_send_reports_to_jalali( $now, true, new DateTimeZone( 'Asia/Tehran' ) ); // fallback: UTC + 3:30 = تهران

	$payload = array(
		'pattern'    => $pattern,
		'recipients' => $recipients,
		'attrs'      => array(
			'username' => (string) $user->user_login,
			'role'     => farazsms_login_security_role_label( $matched[0] ),
			'time'     => (string) $time,
			// ⚠️ v3.22.205 — دامنه به‌عنوانِ متغیرِ **اختیاری** هم می‌رود.
			// پترنِ فروشنده می‌تواند متغیرِ دامنه داشته باشد (روی سایتِ واقعی
			// «domin» دیده شد) و پنل پترنی را که متغیرِ اعلام‌شده‌اش نیامده با
			// ۴۰۰ رد می‌کند — یعنی هشدارِ ورود بی‌صدا قطع می‌شد. متغیرِ اضافه
			// را پنل نادیده می‌گیرد، پس هر دو املا امن است.
			'domain'   => farazsms_login_security_site_domain(),
			'domin'    => farazsms_login_security_site_domain(),
			// v3.21.94: متغیرِ %site% حذف شد — آدرسِ دامنه به‌صورتِ ثابت به انتهای پترن افزوده می‌شود
			// (پنلِ فراز پترنِ بدونِ آدرسِ ثابت را رد می‌کند)؛ همان آدرس، سایت را مشخص می‌کند.
		),
	);

	// non-blocking: ارسال در رویدادِ فوریِ بعدی (ورودِ کاربر بلافاصله کامل می‌شود).
	if ( ! wp_next_scheduled( 'farazsms_login_security_dispatch', array( $payload ) ) ) {
		wp_schedule_single_event( time(), 'farazsms_login_security_dispatch', array( $payload ) );
	}
}
add_action( 'wp_login', 'farazsms_login_security_on_login', 25, 2 );

/**
 * ارسالِ واقعیِ پیامک (در رویدادِ cron — خارج از مسیرِ ورود).
 *
 * @param array $payload
 */
function farazsms_login_security_dispatch( $payload ) {
	if ( ! is_array( $payload ) || ! function_exists( 'farazsms_send_pattern_sms_raw' ) ) {
		return;
	}
	$pattern = isset( $payload['pattern'] ) ? (string) $payload['pattern'] : '';
	$attrs   = isset( $payload['attrs'] ) && is_array( $payload['attrs'] ) ? $payload['attrs'] : array();
	$recips  = isset( $payload['recipients'] ) && is_array( $payload['recipients'] ) ? $payload['recipients'] : array();
	if ( $pattern === '' || empty( $recips ) ) {
		return;
	}
	// ⚠️ همان تشخیصِ خطای پیکربندیِ مسیرِ اطلاعِ به‌روزرسانی، این‌جا هم لازم است.
	//
	// هر دو ویژگی روی پترنِ هاردکد و مشترکِ همه‌ی نصب‌ها می‌روند و پنل پترنی را
	// که متغیرِ اعلام‌شده‌اش نیامده با ۴۰۰ رد می‌کند. تا امروز فقط یکی از این دو
	// مسیر این را می‌فهمید و به مدیر می‌گفت؛ آن یکی بی‌صدا می‌مرد — یعنی
	// تغییرنامِ بعدی دقیقاً همان تیکتِ اولیه را بازتولید می‌کرد.
	$missing = '';
	foreach ( $recips as $phone ) {
		$res = farazsms_send_pattern_sms_raw( $phone, $pattern, $attrs );
		if ( $missing === '' && function_exists( 'farazsms_updates_missing_pattern_field' ) ) {
			$missing = farazsms_updates_missing_pattern_field( $res );
		}
	}

	if ( $missing !== '' ) {
		update_option( 'farazsms_login_alert_pattern_error', array(
			'field'      => $missing,
			'pattern'    => $pattern,
			'noticed_at' => time(),
		), false );
		farazsms_send_diag_log(
			isset( $recips[0] ) ? (string) $recips[0] : '',
			$pattern,
			'api_error:پترنِ هشدارِ ورود متغیرِ «' . $missing . '» می‌خواهد که افزونه نمی‌فرستد',
			array(
				'source'    => 'login-alert',
				'http_code' => 400,
			)
		);
	}
}
add_action( 'farazsms_login_security_dispatch', 'farazsms_login_security_dispatch', 10, 1 );

/* ───────────────────────────── AJAX: ذخیره و ساختِ پترن ───────────────────── */

add_action( 'wp_ajax_farazsms_login_security_save', 'farazsms_login_security_ajax_save' );
function farazsms_login_security_ajax_save() {
	check_ajax_referer( 'farazsms_login_security', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
	}
	$s = farazsms_login_security_settings();

	$s['enabled']   = ( isset( $_POST['enabled'] ) && $_POST['enabled'] === '1' ) ? '1' : '0';
	$s['recipient'] = isset( $_POST['recipient'] ) ? sanitize_text_field( wp_unslash( $_POST['recipient'] ) ) : '';

	$roles_in = isset( $_POST['roles'] ) ? (array) wp_unslash( $_POST['roles'] ) : array();
	$valid    = function_exists( 'wp_roles' ) ? array_keys( wp_roles()->roles ) : array( 'administrator', 'editor', 'author', 'contributor', 'subscriber' );
	$roles    = array_values( array_intersect( array_map( 'sanitize_key', $roles_in ), $valid ) );
	$s['roles'] = ! empty( $roles ) ? $roles : array( 'administrator' );

	if ( isset( $_POST['message'] ) ) {
		$s['message'] = farazsms_sanitize_pattern_text( $_POST['message'] );
	}
	update_option( FARAZSMS_LOGIN_SECURITY_OPTION, $s, false );
	wp_send_json_success( array( 'message' => 'تنظیماتِ امنیتی ذخیره شد.' ) );
}

add_action( 'wp_ajax_farazsms_login_security_build_pattern', 'farazsms_login_security_ajax_build_pattern' );
function farazsms_login_security_ajax_build_pattern() {
	check_ajax_referer( 'farazsms_login_security', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
	}
	$message = isset( $_POST['message'] ) ? farazsms_sanitize_pattern_text( $_POST['message'] ) : '';
	if ( trim( $message ) === '' ) {
		wp_send_json_error( array( 'message' => 'متنِ پترن خالی است.' ) );
	}
	$desc = farazsms_pattern_brand_description( 'security' );

	// آپدیتِ پترنِ موجود به‌جای ساختِ جدید (قانونِ پروژه)، با fallback به ساخت.
	$s        = farazsms_login_security_settings();
	$existing = trim( (string) $s['pattern_code'] );
	$did_update = false;
	if ( $existing !== '' ) {
		$resp = farazsms_update_pattern( $existing, $message, 255, $desc );
		$tmp  = is_string( $resp ) ? json_decode( $resp, true ) : $resp;
		$not_found = is_array( $tmp ) && isset( $tmp['status'] ) && $tmp['status'] !== 'success'
			&& ( ( isset( $tmp['error_code'] ) && $tmp['error_code'] === 'pattern_not_found' )
				|| ( farazsms_is_pattern_not_found_response( $tmp ) ) );
		$did_update = ! $not_found;
		if ( $not_found ) {
			$resp = farazsms_create_pattern( $message, 255, $desc );
		}
	} else {
		$resp = farazsms_create_pattern( $message, 255, $desc );
	}

	$data = is_string( $resp ) ? json_decode( $resp, true ) : $resp;
	$code = '';
	if ( is_array( $data ) ) {
		if ( ! empty( $data['data']['code'] ) ) {
			$code = (string) $data['data']['code'];
		} elseif ( ! empty( $data['data'] ) && is_string( $data['data'] ) ) {
			$code = (string) $data['data'];
		} elseif ( ! empty( $data['code'] ) ) {
			$code = (string) $data['code'];
		}
	}
	if ( $code === '' && $did_update && $existing !== '' ) {
		$code = $existing; // آپدیتِ موفق ممکن است کد را برنگرداند.
	}
	if ( $code === '' ) {
		$em = is_array( $data ) && isset( $data['message'] ) ? (string) $data['message'] : 'پاسخِ نامعتبر از سرور';
		wp_send_json_error( array( 'message' => $em ) );
	}

	$s['pattern_code'] = $code;
	$s['message']      = $message;
	update_option( FARAZSMS_LOGIN_SECURITY_OPTION, $s, false );
	wp_send_json_success( array(
		'pattern_code' => $code,
		'message'      => ( $did_update ? 'پترن به‌روزرسانی شد' : 'پترن ساخته شد' ) . ' (' . $code . ') — پس از تأییدِ پنلِ فراز فعال می‌شود (۱ تا ۲۴ ساعت).',
	) );
}

/* ───────────────────────────── رندرِ تبِ تنظیماتِ امنیتی ───────────────────── */

/**
 * محتوای تبِ «تنظیمات امنیتی» در صفحه‌ی تنظیمات. از farazsms_admin_settings_page صدا زده می‌شود.
 */
function farazsms_login_security_render_tab_content() {
	$s     = farazsms_login_security_settings();
	$nonce = wp_create_nonce( 'farazsms_login_security' );

	$all_roles = array();
	if ( function_exists( 'wp_roles' ) ) {
		foreach ( wp_roles()->roles as $rk => $rv ) {
			$all_roles[ $rk ] = farazsms_login_security_role_label( $rk );
		}
	}
	$recips_preview = farazsms_login_security_recipients();
	?>
	<div class="content__wrapper" style="max-width:760px;">
		<div style="background:#faf1da; border:1px solid #e2a916; border-radius:10px; padding:12px 14px; margin-bottom:16px; font-size:12.5px; color:#83620d; line-height:1.9;">
			🔒 با هر ورودِ کاربری که نقشش انتخاب شده باشد (پیش‌فرض: مدیر کل)، یک پیامکِ هشدار به مدیرِ اصلی ارسال می‌شود تا از ورودهای پنل باخبر باشید.
		</div>

		<label style="display:inline-flex; align-items:center; gap:10px; font-size:13.5px; font-weight:700; color:#4d4d4d; cursor:pointer; margin-bottom:16px;">
			<input type="checkbox" class="farazsms-toggle" id="farazsms-ls-enabled" <?php checked( $s['enabled'], '1' ); ?>>
			فعال‌سازیِ پیامکِ هشدارِ ورود
		</label>

		<div style="font-size:13px; font-weight:700; color:#4d4d4d; margin:6px 0 8px;">برای کدام نقش‌ها پیامک ارسال شود؟</div>
		<div style="display:flex; flex-wrap:wrap; gap:10px; margin-bottom:18px;">
			<?php foreach ( $all_roles as $rk => $rlabel ) : ?>
				<label style="display:inline-flex; align-items:center; gap:6px; padding:7px 12px; border:1px solid #e1e1e1; border-radius:8px; font-size:12.5px; cursor:pointer; background:#fff;">
					<input type="checkbox" class="farazsms-ls-role" value="<?php echo esc_attr( $rk ); ?>" <?php checked( in_array( $rk, (array) $s['roles'], true ) ); ?>>
					<?php echo esc_html( $rlabel ); ?>
				</label>
			<?php endforeach; ?>
		</div>

		<label style="display:block; font-size:13px; font-weight:700; color:#4d4d4d; margin-bottom:6px;">شماره‌ی گیرنده‌ی هشدار</label>
		<input type="text" id="farazsms-ls-recipient" value="<?php echo esc_attr( $s['recipient'] ); ?>" placeholder="<?php echo esc_attr( ! empty( $recips_preview ) ? implode( ', ', $recips_preview ) . ' (شماره‌ی مدیرِ امور فروش)' : '09120000000' ); ?>" style="width:100%; max-width:360px; padding:9px 12px; border:1px solid #e1e1e1; border-radius:8px; font-size:13px; direction:ltr; text-align:left; font-family:Menlo,Consolas,monospace;">
		<p style="margin:5px 0 18px; font-size:11.5px; color:#9b9b9b;">خالی بگذارید تا به شماره‌ی مدیرِ «امور فروش» ارسال شود. چند شماره را با «،» جدا کنید.</p>

		<div style="background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:16px; margin-bottom:16px;">
			<div style="font-size:13px; font-weight:700; color:#263f67; margin-bottom:8px;">پترنِ پیامک</div>
			<p style="margin:0 0 10px; font-size:11.5px; color:#9b9b9b; line-height:1.9;">متغیرها: <code>%username%</code> (نام کاربری)، <code>%role%</code> (سطح دسترسی)، <code>%time%</code> (تاریخ/ساعت). آدرسِ سایت خودکار (متنِ ثابت) به انتهای پترن افزوده می‌شود. متن را دلخواه کنید و «ساخت پترن» را بزنید؛ یا از پترنِ پیش‌فرض استفاده کنید. اگر ساعتِ پیامک نادرست است، «تنظیمات وردپرس ← عمومی ← منطقه‌ی زمانی» را روی تهران بگذارید.</p>
			<label style="display:block; font-size:12px; font-weight:600; color:#4d4d4d; margin-bottom:4px;">کد پترن</label>
			<input type="text" id="farazsms-ls-pattern-code" value="<?php echo esc_attr( $s['pattern_code'] ); ?>" style="width:100%; max-width:260px; padding:8px 12px; border:1px solid #e1e1e1; border-radius:8px; font-size:13px; direction:ltr; text-align:left; font-family:Menlo,Consolas,monospace; margin-bottom:12px;">
			<label style="display:block; font-size:12px; font-weight:600; color:#4d4d4d; margin-bottom:4px;">متن پترن</label>
			<textarea id="farazsms-ls-message" rows="9" style="width:100%; padding:10px 12px; border:1px solid #e1e1e1; border-radius:8px; font-size:13px; font-family:inherit; line-height:1.9; direction:rtl; resize:vertical;"><?php echo esc_textarea( $s['message'] ); ?></textarea>
			<div style="margin-top:10px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
				<button type="button" id="farazsms-ls-build" style="background:#0c9765; color:#fff; border:none; padding:8px 18px; font-size:13px; font-weight:700; border-radius:8px; cursor:pointer; font-family:inherit;">⚡ ساخت/به‌روزرسانیِ پترن</button>
				<span id="farazsms-ls-build-status" style="font-size:12px; color:#9b9b9b;"></span>
			</div>
		</div>

		<button type="button" id="farazsms-ls-save" class="farazsms_button" style="background:#365891; color:#fff; border:none; padding:10px 26px; font-size:14px; font-weight:700; border-radius:10px; cursor:pointer; font-family:inherit;">ذخیره تنظیمات امنیتی</button>
		<span id="farazsms-ls-save-status" style="font-size:12.5px; margin-right:10px;"></span>
	</div>

	<script>
	(function(){
		var nonce = '<?php echo esc_js( $nonce ); ?>';
		var ajaxurl = '<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>';
		function roles(){ return Array.prototype.map.call(document.querySelectorAll('.farazsms-ls-role:checked'), function(c){ return c.value; }); }

		var buildBtn = document.getElementById('farazsms-ls-build');
		if (buildBtn) buildBtn.addEventListener('click', function(){
			var st = document.getElementById('farazsms-ls-build-status');
			var msg = document.getElementById('farazsms-ls-message').value || '';
			if (msg.trim() === '') { st.textContent = '✗ متنِ پترن خالی است'; st.style.color = '#d52a16'; return; }
			buildBtn.disabled = true; buildBtn.style.opacity = '.6'; st.textContent = 'در حال ساخت…'; st.style.color = '#9b9b9b';
			var fd = new FormData();
			fd.append('action', 'farazsms_login_security_build_pattern');
			fd.append('nonce', nonce);
			fd.append('message', msg);
			fetch(ajaxurl, { method:'POST', credentials:'same-origin', body: fd }).then(function(r){return r.json();}).then(function(res){
				if (res && res.success && res.data && res.data.pattern_code) {
					document.getElementById('farazsms-ls-pattern-code').value = res.data.pattern_code;
					st.textContent = '✓ ' + res.data.message; st.style.color = '#0c9765';
				} else { st.textContent = '✗ ' + ((res && res.data && res.data.message) || 'خطا'); st.style.color = '#d52a16'; }
			}).catch(function(){ st.textContent = '✗ خطای ارتباط'; st.style.color = '#d52a16'; }).finally(function(){ buildBtn.disabled = false; buildBtn.style.opacity = '1'; });
		});

		var saveBtn = document.getElementById('farazsms-ls-save');
		if (saveBtn) saveBtn.addEventListener('click', function(){
			var st = document.getElementById('farazsms-ls-save-status');
			saveBtn.disabled = true; saveBtn.style.opacity = '.6'; st.textContent = 'در حال ذخیره…'; st.style.color = '#9b9b9b';
			var fd = new FormData();
			fd.append('action', 'farazsms_login_security_save');
			fd.append('nonce', nonce);
			fd.append('enabled', document.getElementById('farazsms-ls-enabled').checked ? '1' : '0');
			fd.append('recipient', document.getElementById('farazsms-ls-recipient').value || '');
			fd.append('message', document.getElementById('farazsms-ls-message').value || '');
			roles().forEach(function(r){ fd.append('roles[]', r); });
			fetch(ajaxurl, { method:'POST', credentials:'same-origin', body: fd }).then(function(r){return r.json();}).then(function(res){
				if (res && res.success) { st.textContent = '✓ ' + res.data.message; st.style.color = '#0c9765'; }
				else { st.textContent = '✗ ' + ((res && res.data && res.data.message) || 'خطا'); st.style.color = '#d52a16'; }
			}).catch(function(){ st.textContent = '✗ خطای ارتباط'; st.style.color = '#d52a16'; }).finally(function(){ saveBtn.disabled = false; saveBtn.style.opacity = '1'; });
		});
	})();
	</script>
	<?php
}


add_action( 'admin_notices', 'farazsms_login_alert_pattern_error_notice' );
/**
 * هشدارِ «پترنِ هشدارِ ورود با افزونه نمی‌خوانَد».
 *
 * ⚠️ بدونِ این، قطع‌شدنِ هشدارِ ورود هیچ نشانه‌ای جز یک ردیفِ لاگ ندارد و مدیر
 * فقط می‌فهمد «مدتی است پیامکِ ورود نمی‌آید».
 *
 * @return void
 */
function farazsms_login_alert_pattern_error_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$e = get_option( 'farazsms_login_alert_pattern_error', array() );
	if ( ! is_array( $e ) || empty( $e['field'] ) ) {
		return;
	}
	?>
	<div class="notice notice-warning is-dismissible" style="direction:rtl;">
		<p>
			<strong>فراز اس ام اس:</strong>
			<?php
			printf(
				/* translators: 1: نامِ متغیر 2: کدِ پترن */
				esc_html__( 'پیامکِ هشدارِ ورود به پیشخوان ارسال نشد: پترنِ «%2$s» در پنل متغیری به نامِ «%1$s» دارد که افزونه آن را نمی‌فرستد. در پنلِ فراز آن متغیر را از پترن بردارید تا هشدار دوباره برقرار شود.', 'farazsms' ),
				esc_html( (string) $e['field'] ),
				esc_html( (string) ( $e['pattern'] ?? '' ) )
			);
			?>
		</p>
		<p>
			<a href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'farazsms_dismiss_login_alert_error', '1' ), 'farazsms_dismiss_login_alert_error' ) ); ?>">
				<?php esc_html_e( 'متوجه شدم، دیگر نشان نده', 'farazsms' ); ?>
			</a>
		</p>
	</div>
	<?php
}

add_action( 'admin_init', 'farazsms_login_alert_pattern_error_dismiss' );
/**
 * بستنِ دستیِ هشدارِ ناهم‌خوانیِ پترنِ ورود.
 *
 * @return void
 */
function farazsms_login_alert_pattern_error_dismiss() {
	if ( empty( $_GET['farazsms_dismiss_login_alert_error'] ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'farazsms_dismiss_login_alert_error' ) ) {
		return;
	}
	delete_option( 'farazsms_login_alert_pattern_error' );
}
