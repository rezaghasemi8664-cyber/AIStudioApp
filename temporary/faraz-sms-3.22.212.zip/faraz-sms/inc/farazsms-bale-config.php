<?php
/**
 * لایه‌ی کانفیگِ کانالِ بله (MVP) — تنها منبعِ base-URL و کلیدِ دسترسیِ بله.
 *
 * چرا یک لایه‌ی جدا (AD-5)؟ در آینده کلیدِ جداگانه حذف می‌شود و ارسال به سرورِ اصلیِ
 * پروداکشن منتقل می‌گردد. اگر endpoint و کلید فقط از همین‌جا خوانده شوند، آن انتقال =
 * تغییرِ همین یک نقطه، بدونِ دست‌زدن به فیچرها.
 *
 * امنیتِ کلید (AD-7): کلیدِ بله در option جدا با «همان» الگوی رمزنگاری/ماسکِ کلیدِ پیامک
 * ذخیره می‌شود — از توابعِ مشترکِ
 *   farazsms_apikey_encrypt / farazsms_apikey_decrypt
 * بازاستفاده می‌کنیم (secret مشترک است؛ فقط option جداست). پس این فایل باید بعد از
 * farazsms-apikey-security.php بار شود.
 *
 * این فایل «سبک» است: فقط تعریفِ تابع + ثبتِ فیلترِ option. بارگذاریِ مشروطِ بخش‌های
 * سنگین (سرویس/ادمین) در farazsms-bale-init.php انجام می‌شود (AD-8).
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/** پایه‌ی پیش‌فرضِ وب‌سرویسِ بله (سرورِ MVP؛ در آینده به پروداکشن منتقل می‌شود). */
const FARAZSMS_BALE_DEFAULT_BASE_URL = 'https://bale.farazsms.com/api/v1/';

/**
 * نرمال‌سازیِ base-URL: خالی → پیش‌فرض؛ همیشه با یک اسلشِ پایانی.
 * (تابعِ خالص و تست‌پذیر — منطقِ اصلیِ accessor اینجاست.)
 *
 * @param mixed $raw
 * @return string
 */
function farazsms_bale_normalize_base_url( $raw ) {
	$raw = is_string( $raw ) ? trim( $raw ) : '';
	if ( $raw === '' ) {
		$raw = FARAZSMS_BALE_DEFAULT_BASE_URL;
	}
	return rtrim( $raw, '/' ) . '/';
}

/**
 * base-URLِ فعالِ بله (تک‌منبع). فیچرها/ترنسپورت فقط این را صدا بزنند.
 *
 * @return string
 */
function farazsms_bale_base_url() {
	return farazsms_bale_normalize_base_url( get_option( 'farazsms_bale_base_url', '' ) );
}

/**
 * کلیدِ دسترسیِ بله به‌صورتِ متنِ ساده (فیلترِ option آن را رمزگشایی می‌کند).
 *
 * @return string
 */
function farazsms_bale_apikey() {
	$k = get_option( 'farazsms_bale_apikey', '' );
	return is_string( $k ) ? trim( $k ) : '';
}

/**
 * آیا کلیدِ بله تنظیم شده است؟ (گِیتِ AD-3 و بارگذاریِ مشروطِ AD-8 روی این تکیه می‌کنند.)
 *
 * @return bool
 */
function farazsms_bale_is_configured() {
	// kill-switchِ اصلی هم این‌جا لحاظ می‌شود: اگر بله «کاملاً خاموش» شده باشد، انگار
	// اصلاً کلیدی تنظیم نیست — پس همه‌ی مسیرها (ارسال، بارگذاریِ ادمین، نوارِ وضعیت) که به
	// is_configured تکیه دارند، یک‌جا غیرفعال می‌شوند. تنها نقطه‌ی حقیقت برای «بله فعال است؟».
	if ( ! farazsms_bale_active() ) {
		return false;
	}
	return farazsms_bale_apikey() !== '';
}

/**
 * کلیدِ اصلیِ کانالِ بله (master kill-switch). اگر false شود، بله «کاملاً» غیرفعال است:
 * نه ارسالی، نه UIای، نه صفحه‌ای. برای خاموش‌کردنِ سراسری (اگر MVP بازخوردِ بد داشت) بدونِ
 * برگرداندنِ کلِ افزونه به نسخه‌ی قبلی.
 *
 * سه راهِ خاموش‌کردن (هر کدام کافی است):
 *   1) ثابتِ FARAZSMS_BALE_DISABLED === true (در wp-config.php یا کد) — قطعی و محلی، برای یک سایت.
 *   2) option 'farazsms_bale_kill' === '1' — قابلِ‌ست از راه دور یا با یک آپدیتِ کوچک، سراسری.
 *   3) فیلترِ 'farazsms_bale_active' → false — برای توسعه‌دهنده/mu-plugin.
 *
 * برای خاموش‌کردنِ فوریِ همه‌ی سایت‌ها با یک هاتفیکس: کافی است در همین تابع
 *
 *   return false;
 *
 * قرار داده و نسخه‌ی جدید منتشر شود؛ سایت‌هایی که آپدیت می‌کنند بله‌شان بی‌صدا خاموش می‌شود،
 * بدونِ آسیب به بقیه‌ی افزونه.
 *
 * @return bool
 */
function farazsms_bale_active() {
	if ( defined( 'FARAZSMS_BALE_DISABLED' ) && FARAZSMS_BALE_DISABLED ) {
		return false;
	}
	// مقدارِ truthy را بپذیر (نه فقط رشته‌ی دقیقِ '1') — تا ست‌کردن با WP-CLI به‌صورتِ عددِ 1 یا
	// true هم kill را فعال کند.
	$kill = get_option( 'farazsms_bale_kill' );
	if ( $kill === '1' || $kill === 1 || $kill === true || $kill === 'yes' || $kill === 'true' ) {
		return false;
	}
	return (bool) apply_filters( 'farazsms_bale_active', true );
}

// --- فیلترهای شفافِ رمزنگاری/ماسکِ کلیدِ بله (AD-7؛ بازاستفاده از کریپتوی مشترک) ---

// ذخیره: متنِ ساده → رمزنگاری‌شده. گاردِ خالی=حفظ (چون کلید در UI ماسک است و فرم آن را
// خالی می‌فرستد؛ خالی یعنی «تغییر نده»، نه پاک‌کردن) — دقیقاً مثلِ کلیدِ پیامک.
add_filter( 'pre_update_option_farazsms_bale_apikey', 'farazsms_bale_apikey_pre_update', 10, 2 );
function farazsms_bale_apikey_pre_update( $value, $old_value ) {
	$value = is_string( $value ) ? $value : '';
	if ( trim( $value ) === '' && is_string( $old_value ) && $old_value !== '' ) {
		return $old_value; // مقدارِ رمزنگاری‌شده‌ی موجود دست‌نخورده می‌ماند
	}
	return farazsms_apikey_encrypt( $value );
}

// افزودنِ اولیه (add_option) هم رمزنگاری شود.
add_filter( 'pre_add_option_farazsms_bale_apikey', 'farazsms_bale_apikey_pre_add', 10, 1 );
function farazsms_bale_apikey_pre_add( $value ) {
	$value = is_string( $value ) ? $value : '';
	return farazsms_apikey_encrypt( $value );
}

// خواندن: رمزنگاری‌شده → متنِ ساده (شفاف برای همه‌ی خواننده‌ها).
add_filter( 'option_farazsms_bale_apikey', 'farazsms_bale_apikey_decrypt_read', 10, 1 );
function farazsms_bale_apikey_decrypt_read( $value ) {
	return farazsms_apikey_decrypt( $value );
}
