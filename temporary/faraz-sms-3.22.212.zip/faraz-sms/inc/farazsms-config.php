<?php
/**
 * لایه‌ی پیکربندیِ کانونی (Config Accessor Layer).
 *
 * هدف: «منبعِ حقیقتِ واحد» برای مقادیری که تا امروز از چند جا خوانده می‌شدند
 * (کلید API، خطِ ارسال، شماره‌ی مدیر، کدِ پترن). این فایل هیچ optionی را
 * تغییرِ نام نمی‌دهد و چیزی را migrate نمی‌کند؛ فقط یک نقطه‌ی خواندنِ یکدست
 * روی همان optionهای موجود می‌گذارد تا کدِ جدید از این‌جا بخواند و دیگر هر
 * ماژول fallbackِ دستیِ خودش را نسازد.
 *
 * سازگاریِ کامل با کدِ قدیمی: توابعِ قدیمی (farazsms_get_apikey و …) دست‌نخورده‌اند
 * و خودشان نیز می‌توانند به این لایه delegate کنند.
 *
 * @package FarazSMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * بیشترین مخاطبی که روی همان درخواستِ AJAX به دفترچه‌تلفن فرستاده می‌شود.
 *
 * ⚠️ بالاتر از این، کار تکه‌تکه به صفِ مشترک می‌رود. از v3.22.207 واردسازی
 * همگام است (هر ۵۰۰ مخاطب یک درخواستِ HTTP با مهلتِ ۶۰ ثانیه)، پس فهرستِ
 * بزرگ روی یک درخواست یعنی مرگِ وسطِ کار بدونِ راهِ ادامه.
 *
 * این‌جا زندگی می‌کند چون هر دو مسیرِ واردسازی (گرویتی و متای اختصاصی) به آن
 * تکیه می‌کنند و این فایل پیش از هر دو بار می‌شود.
 */
if ( ! defined( 'FARAZSMS_PB_SYNC_MAX_INLINE' ) ) {
	define( 'FARAZSMS_PB_SYNC_MAX_INLINE', 1000 );
}

/* ---------------------------------------------------------------------------
 *  کلید API و خطِ ارسال
 * ------------------------------------------------------------------------- */

/**
 * کلیدِ API کانونی. منبعِ حقیقت: option «farazsms_apikey».
 *
 * @return string
 */
function farazsms_cfg_apikey() {
	$v = (string) get_option( 'farazsms_apikey', '' );
	// fallbackِ امن: اگر مهاجرتِ نام‌گذاری هنوز اجرا نشده، از کلیدِ قدیمی بخوان.
	if ( $v === '' ) {
		$v = (string) get_option( 'wto_apikey', '' );
	}
	return $v;
}

/**
 * خطِ ارسالِ کانونی. منبعِ حقیقت: option «farazsms_sender».
 *
 * @return string
 */
function farazsms_cfg_sender() {
	$v = (string) get_option( 'farazsms_sender', '' );
	if ( $v === '' ) {
		$v = (string) get_option( 'wto_sender', '' );
	}
	return $v;
}

/**
 * خطِ ارسالِ «تبلیغاتی». پیامک‌های ترویجی/تبلیغاتی (سبدِ خریدِ رهاشده، موجود شد
 * خبرم کن و موارد مشابه) باید از این خط بروند، نه از خطِ تراکنشیِ OTP.
 *
 * منبعِ حقیقت: option «farazsms_ad_sender». پیش‌فرض: PRO (با حروفِ بزرگ).
 *
 * @return string
 */
function farazsms_get_ad_sender() {
	$raw = trim( (string) get_option( 'farazsms_ad_sender', '' ) );
	if ( $raw === '' ) {
		return 'PRO';
	}
	// اعمالِ زمانِ خواندن (گاردِ گذشته‌نگر و ضدِ دور‌زدن): اگر مقدارِ ذخیره‌شده نامعتبر باشد — چه از قبل
	// (پیش از افزودنِ اعتبارسنجی) و چه با ویرایشِ مستقیمِ دیتابیس/WP-CLI — برای ارسالِ تبلیغاتی هرگز
	// استفاده نمی‌شود و به PRO برمی‌گردد. پس هیچ پیامکِ تبلیغاتی‌ای روی خطِ خدماتی نمی‌رود.
	$check = farazsms_validate_ad_sender( $raw );
	if ( empty( $check['ok'] ) ) {
		return 'PRO';
	}
	return $check['value'] !== '' ? $check['value'] : 'PRO';
}

/**
 * اعتبارسنجیِ «خطِ تبلیغاتی» هنگامِ ذخیره.
 *
 * پیامکِ تبلیغاتی طبقِ مقررات فقط از خطِ تبلیغاتی/غیردرخواستی مجاز است، نه خطِ خدماتی.
 * برای اینکه کاربر نتواند سیستم را دور بزند و یک خطِ خدماتی (مثلِ ۳۰۰۰…/۲۰۰۰…/۵۰۰۰…/۹۰۰۰۸۳۶۱)
 * را در فیلدِ خطِ تبلیغاتی بگذارد و برای تبلیغ استفاده کند، فقط این مقادیر پذیرفته می‌شوند:
 *   - «PRO» (خطِ اشتراکیِ تبلیغاتیِ فراز) — پیش‌فرض؛ خالی هم به PRO تبدیل می‌شود.
 *   - خطِ عددی که با «998» یا «9998» شروع شود (خطِ «غیردرخواستی» تبلیغاتیِ پنلِ فراز).
 * هر چیزِ دیگر (به‌ویژه خطوطِ خدماتی) رد می‌شود.
 *
 * قابلِ override با فیلترِ farazsms_ad_sender_allow (پیش‌فرض: رد) برای مواردِ خاص.
 *
 * @param string $raw مقدارِ خام از فرم.
 * @return array{ok: bool, value: string, error: string}
 */
function farazsms_validate_ad_sender( $raw ) {
	// نرمال‌سازی: ارقامِ فارسی/عربی → انگلیسی، حذفِ فاصله/خط‌تیره، حروفِ بزرگ.
	$fa = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );
	$ar = array( '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' );
	$en = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
	$v  = str_replace( $ar, $en, str_replace( $fa, $en, (string) $raw ) );
	$v  = strtoupper( trim( $v ) );

	if ( $v === '' || $v === 'PRO' ) {
		return array( 'ok' => true, 'value' => 'PRO', 'error' => '' );
	}

	// حذفِ فاصله/خط‌تیره و نیز فاصله‌های یونیکد و نیم‌فاصله/nbsp/BOM که در کپی‌وپیستِ فارسی رایج‌اند
	// (وگرنه یک خطِ ۹۹۸ِ کاملاً معتبر که با nbsp چسبانده شده، اشتباهاً رد می‌شد).
	$digits = preg_replace( '/[\s\-\x{200C}\x{200B}\x{00A0}\x{FEFF}]+/u', '', $v );
	if ( $digits === null ) {
		// UTF-8 نامعتبر → preg با /u شکست می‌خورد و null می‌دهد. با نسخه‌ی بایتی (بدونِ /u) fallback
		// می‌کنیم تا خطِ ۹۹۸ِ معتبرِ دارای یک بایتِ خراب اشتباهاً رد نشود.
		$digits = preg_replace( '/[\s\-]+/', '', $v );
	}
	// تحملِ صفرِ ابتدایی؛ خطِ عددیِ تبلیغاتی باید با 998 یا 9998 شروع شود (بعد از صفرهای احتمالی).
	if ( preg_match( '/^\d+$/', (string) $digits ) && preg_match( '/^0*(?:9998|998)/', (string) $digits ) ) {
		return array( 'ok' => true, 'value' => $digits, 'error' => '' );
	}

	if ( apply_filters( 'farazsms_ad_sender_allow', false, $v ) ) {
		return array( 'ok' => true, 'value' => $v, 'error' => '' );
	}

	return array(
		'ok'    => false,
		'value' => $v,
		'error' => 'برای بخشِ تبلیغات باید از خطِ «PRO» استفاده شود، یا از پنلِ فراز مسیرِ «مدیریت خطوط ← خط غیردرخواستی ← ۹۹۸» یک خط تهیه کنید. خطِ خدماتی (مثلِ ۳۰۰۰…، ۲۰۰۰…، ۵۰۰۰…، ۹۰۰۰۸۳۶۱) برای پیامکِ تبلیغاتی مجاز نیست.',
	);
}

/**
 * آیا افزونه برای ارسال آماده است؟ (کلید موجود است)
 *
 * @return bool
 */
function farazsms_cfg_is_ready() {
	return farazsms_cfg_apikey() !== '';
}

/* ---------------------------------------------------------------------------
 *  شماره‌ی مدیر / گیرنده‌ی اعلان‌ها
 * ------------------------------------------------------------------------- */

/**
 * نرمال‌سازیِ ورودیِ شماره‌ها (رشته‌ی کاما/خط‌جدا یا آرایه) به آرایه‌ی یکتا.
 *
 * @param mixed $raw رشته یا آرایه.
 * @return string[] آرایه‌ی شماره‌های تمیزشده‌ی یکتا.
 */
function farazsms_cfg_phones_normalize( $raw ) {
	if ( is_array( $raw ) ) {
		$parts = $raw;
	} else {
		$parts = preg_split( '/[\s,،;]+/u', (string) $raw );
	}
	$out = array();
	foreach ( (array) $parts as $p ) {
		$p = trim( (string) $p );
		if ( $p === '' ) {
			continue;
		}
		$p = farazsms_normalize_phone( $p );
		if ( $p !== '' ) {
			$out[ $p ] = true; // dedup
		}
	}
	return array_keys( $out );
}

/**
 * شماره‌های مدیرِ کانونی (گیرنده‌ی اعلان‌های مدیریتی).
 *
 * زنجیره‌ی منبع — اولین غیرخالی برنده است، تا رفتارِ تاریخیِ ماژول‌ها حفظ شود:
 *   1) option «farazsms_comment_admin_phones»            (قدیمی‌ترین / اصلی)
 *   2) option «farazsms_daily_sales_settings[admin_phones]»
 *   3) option «farazsms_login_security_settings[admin_phones]»
 *   4) موبایلِ پروفایلِ ادمینِ اصلی (در صورت وجود)
 *
 * این همان fallbackی است که قبلاً در چند ماژول دستی تکرار می‌شد؛ حالا یک‌جا.
 *
 * @return string[]
 */
function farazsms_cfg_admin_phones() {
	$p = farazsms_cfg_phones_normalize( get_option( 'farazsms_comment_admin_phones', '' ) );
	if ( $p ) {
		return $p;
	}

	$ds = get_option( 'farazsms_daily_sales_settings', array() );
	if ( is_array( $ds ) && ! empty( $ds['admin_phones'] ) ) {
		$p = farazsms_cfg_phones_normalize( $ds['admin_phones'] );
		if ( $p ) {
			return $p;
		}
	}

	$ls = get_option( 'farazsms_login_security_settings', array() );
	if ( is_array( $ls ) && ! empty( $ls['admin_phones'] ) ) {
		$p = farazsms_cfg_phones_normalize( $ls['admin_phones'] );
		if ( $p ) {
			return $p;
		}
	}

	// آخرین fallback: موبایلِ کاربرِ ادمینِ اصلی (مدیرِ سایت).
	$admin_email = get_option( 'admin_email' );
	if ( $admin_email ) {
		$user = get_user_by( 'email', $admin_email );
		if ( $user ) {
			$mobile = get_user_meta( $user->ID, 'mobile', true );
			if ( ! $mobile ) {
				$mobile = get_user_meta( $user->ID, 'billing_phone', true );
			}
			if ( $mobile ) {
				return farazsms_cfg_phones_normalize( $mobile );
			}
		}
	}

	return array();
}

/**
 * اولین شماره‌ی مدیر (برای موارد تک‌گیرنده).
 *
 * @return string
 */
function farazsms_cfg_primary_admin_phone() {
	$all = farazsms_cfg_admin_phones();
	return $all ? $all[0] : '';
}

/* ---------------------------------------------------------------------------
 *  کدهای پترن — رجیستریِ مرکزی
 * ------------------------------------------------------------------------- */

/**
 * خواندنِ کدِ پترن از رجیستریِ مرکزیِ «farazsms_patterns».
 *
 * ساختارِ رجیستری: array مسطح key => code (نسخه‌ی ساده‌شده) یا تو‌در‌تو
 * [section][status]. این accessor از هر دو پشتیبانی می‌کند: اگر $key شاملِ
 * «/» باشد به‌صورتِ section/status تفسیر می‌شود.
 *
 * @param string $key     کلیدِ منطقی (مثلاً 'otp' یا 'tracking/post').
 * @param string $default مقدارِ پیش‌فرض اگر یافت نشد.
 * @return string کدِ پترن.
 */
function farazsms_cfg_pattern( $key, $default = '' ) {
	$reg = get_option( 'farazsms_patterns', array() );
	if ( ! is_array( $reg ) ) {
		$reg = array();
	}
	if ( strpos( $key, '/' ) !== false ) {
		list( $section, $status ) = array_pad( explode( '/', $key, 2 ), 2, '' );
		if ( isset( $reg[ $section ][ $status ] ) && $reg[ $section ][ $status ] !== '' ) {
			return (string) $reg[ $section ][ $status ];
		}
	} elseif ( isset( $reg[ $key ] ) && is_string( $reg[ $key ] ) && $reg[ $key ] !== '' ) {
		return (string) $reg[ $key ];
	}
	return (string) $default;
}

/**
 * نوشتنِ کدِ پترن در رجیستریِ مرکزی (به‌علاوه‌ی هر جای دیگری که فراخواننده لازم دارد).
 *
 * @param string $key  کلیدِ منطقی ('otp' یا 'tracking/post').
 * @param string $code کدِ پترن.
 * @return void
 */
function farazsms_cfg_set_pattern( $key, $code ) {
	$reg = get_option( 'farazsms_patterns', array() );
	if ( ! is_array( $reg ) ) {
		$reg = array();
	}
	if ( strpos( $key, '/' ) !== false ) {
		list( $section, $status ) = array_pad( explode( '/', $key, 2 ), 2, '' );
		if ( ! isset( $reg[ $section ] ) || ! is_array( $reg[ $section ] ) ) {
			$reg[ $section ] = array();
		}
		$reg[ $section ][ $status ] = (string) $code;
	} else {
		$reg[ $key ] = (string) $code;
	}
	update_option( 'farazsms_patterns', $reg, false );
}

// ============================================================================
// زمان — تبدیلِ «ساعتِ محلیِ سایت» به مهرِ زمانیِ واقعی
// ============================================================================
// current_time('mysql') ساعتِ دیواریِ سایت را بدونِ نشانه‌ی منطقه برمی‌گرداند، ولی وردپرس
// منطقه‌ی پیش‌فرضِ PHP را UTC می‌کند؛ پس strtotime همان رشته را UTC می‌خواند و نتیجه به اندازه‌ی
// اختلافِ منطقه جلو می‌افتد (تهران: ۱۲۶۰۰ ثانیه). هر جا رشته‌ی محلی با مهرِ زمانیِ واقعی مقایسه
// می‌شود — مثلِ تاریخِ ساختِ سفارش یا time() — باید از این‌جا رد شود.
// ریشه‌ی باگِ کش‌بک در ۳٫۲۲٫۱۸۹ و باگِ عمرِ لینکِ سبدِ رهاشده همین بود.

/**
 * منطقه‌ی زمانیِ سایت (با پشتیبانِ امن).
 *
 * @return DateTimeZone
 */
function farazsms_site_timezone() {
	if ( function_exists( 'wp_timezone' ) ) {
		$tz = wp_timezone();
		if ( $tz instanceof DateTimeZone ) {
			return $tz;
		}
	}
	$offset = (float) get_option( 'gmt_offset', 0 );
	$sign   = $offset < 0 ? '-' : '+';
	$abs    = abs( $offset );
	try {
		return new DateTimeZone( sprintf( '%s%02d:%02d', $sign, (int) $abs, (int) round( ( $abs - (int) $abs ) * 60 ) ) );
	} catch ( Exception $e ) {
		// مقدارِ خرابِ gmt_offset نباید وسطِ یک هوکِ سفارش فاتال بدهد.
		return new DateTimeZone( 'UTC' );
	}
}

/**
 * رشته‌ی Y-m-d H:i:s به وقتِ محلیِ سایت → مهرِ زمانیِ واقعی.
 *
 * @param string            $mysql رشته‌ی زمانِ محلی.
 * @param DateTimeZone|null $tz    منطقه؛ نبود یعنی منطقه‌ی سایت.
 * @return int مهرِ زمانی؛ صفر یعنی غیرقابلِ تفسیر.
 */
function farazsms_local_mysql_to_ts( $mysql, $tz = null ) {
	$mysql = trim( (string) $mysql );
	if ( $mysql === '' ) {
		return 0;
	}
	if ( ! ( $tz instanceof DateTimeZone ) ) {
		$tz = farazsms_site_timezone();
	}
	try {
		$dt = new DateTimeImmutable( $mysql, $tz );
	} catch ( Exception $e ) {
		return 0;
	}
	return $dt->getTimestamp();
}

/**
 * آیا صفحه‌ی جاریِ پیشخوان همین صفحه‌ی افزونه است؟
 *
 * ⚠️ چرا وجود دارد (v3.22.200): هفت نقطه در افزونه با **رشته‌ی نامِ هوک** مقایسه
 * می‌کردند، مثلِ
 *
 * 'farazsms_page_farazsms-automation'
 *
 * ولی آن نام را وردپرس از sanitize_title عنوانِ منوی والد می‌سازد و عنوانِ ما
 * فارسی است. یعنی این رشته یک ثابتِ تضمین‌شده نیست؛ به عنوانِ منو گره خورده و
 * با هر تغییرِ آن بی‌صدا از کار می‌افتد — بدونِ خطا، فقط اسکریپت بار نمی‌شود.
 *
 * نشانه‌اش در خودِ مخزن بود: یکی از مصرف‌کننده‌ها کنارِ همان مقایسه نوشته بود
 * «Also check by page parameter as fallback». یعنی قبلاً به این برخورده‌اند و
 * فقط همان یک نقطه وصله خورده بود.
 *
 * منبعِ معتبر خودِ اسلاگِ صفحه است. نامِ هوک به‌عنوانِ مسیرِ دوم پذیرفته می‌شود
 * تا اگر روی نصبی مقدارِ درست داشت، رفتار عوض نشود.
 *
 * فقط برای تصمیمِ «چه چیزی بار شود» است، نه دروازه‌ی دسترسی — هیچ حالتی را
 * تغییر نمی‌دهد، پس نانس لازم ندارد.
 *
 * @param string $slug اسلاگِ صفحه، مثلاً 'farazsms-automation'.
 * @param string $hook نامِ هوکی که وردپرس به admin_enqueue_scripts می‌دهد.
 * @return bool
 */
function farazsms_is_admin_page( $slug, $hook = '' ) {
	$slug = (string) $slug;
	if ( $slug === '' ) {
		return false;
	}
	if ( isset( $_GET['page'] ) ) {
		$current = sanitize_key( wp_unslash( $_GET['page'] ) );
		if ( $current === $slug ) {
			return true;
		}
	}
	// فقط صفحه‌ی سطح‌بالا نامِ هوکِ قابلِ‌پیش‌بینی دارد. پیشوندِ زیرمنوها از
	// sanitize_title عنوانِ منوی والد ساخته می‌شود که فارسی و درصد-کدشده است،
	// پس 'farazsms_page_...' روی هیچ نصبی تطبیق نمی‌کند — شاخه‌اش را نگه
	// نداشتیم چون کدِ مرده، مستندسازیِ یک قالبِ ناموجود است.
	return $hook === 'toplevel_page_' . $slug;
}

/**
 * همان تصمیم برای چند صفحه.
 *
 * @param string[] $slugs
 * @param string   $hook
 * @return bool
 */
function farazsms_is_any_admin_page( $slugs, $hook = '' ) {
	foreach ( (array) $slugs as $slug ) {
		if ( farazsms_is_admin_page( $slug, $hook ) ) {
			return true;
		}
	}
	return false;
}

/**
 * دامنه‌ی سایت برای متغیرهای پترن — **تنها پیاده‌سازی**.
 *
 * ⚠️ تا v3.22.207 سه نسخه از همین کار وجود داشت: دو کپیِ درون‌خطی (اطلاعِ
 * به‌روزرسانی و هشدارِ ورود) و `farazsms_lws_clean_domain()` که علاوه بر مسیر،
 * `www.` را هم می‌کَند. نتیجه این بود که یک سایت بسته به اینکه کدام پیامک
 * برود، دو دامنه‌ی متفاوت گزارش می‌کرد. سخت‌گیرترین نسخه برنده شد.
 *
 * @return string
 */
function farazsms_pattern_site_domain() {
	$host = function_exists( 'wp_parse_url' ) ? (string) wp_parse_url( home_url(), PHP_URL_HOST ) : '';
	if ( $host === '' ) {
		$host = preg_replace( '#^https?://#i', '', (string) home_url() ); // بدونِ اسکیم
		$host = preg_replace( '#/.*$#', '', (string) $host );              // بدونِ مسیر
	}
	return (string) preg_replace( '/^www\./i', '', (string) $host );      // بدونِ www
}

/**
 * شرطِ **واحدِ** «این سبد را افزونه بازگرداند» — تنها تعریفِ معتبر.
 *
 * ⚠️ چرا این تابع وجود دارد (تیکتِ «۶۲ از ۶۲ سفارش سبد رهاشده شمرده شده»،
 * ۱۴۰۵/۰۶/۱۶):
 *
 * وضعیتِ `recovered` روی **هر** سفارشِ پرداخت‌شده نوشته می‌شود، و درست هم هست:
 * کارش این است که جلوی یادآوریِ بعدی به کسی که خرید کرده را بگیرد. ولی همان
 * وضعیت به‌عنوانِ «ما این را بازگرداندیم» هم خوانده می‌شد — در حالی که افزونه
 * سبدِ هر مشتری را از لحظه‌ی افزودن به سبد رصد می‌کند، پس هر خریدِ کاملاً
 * عادی هم یک ردیفِ `active` دارد که همان‌جا `recovered` می‌شد. نتیجه: افزونه
 * اعتبارِ کلِ فروشِ فروشگاه را به خودش نسبت می‌داد.
 *
 * انتساب فقط وقتی درست است که **پیامکِ ما رفته باشد و بازگشت بعد از آن باشد**.
 * صفحه‌ی سبدِ رهاشده از اول همین را می‌شمرد؛ صفحه‌ی سودآوری شمارشِ خام را
 * می‌خواند. حالا هر دو از این یک تعریف می‌خوانند.
 *
 * @return string شرطِ SQL بدونِ WHERE.
 */
function farazsms_abandoned_attributed_where( $extra = array() ) {
	$clauses = array( 'recovered_at IS NOT NULL', 'sent_at IS NOT NULL', 'recovered_at >= sent_at' );

	// ⚠️ بندهای اضافیِ مصرف‌کننده هم از همین‌جا رد می‌شوند.
	//
	// بازبینی نشان داد گشادکردنِ محمول **در خودِ مصرف‌کننده** — مثلاً
	// «( … ) OR status = 'recovered'» — باگِ تیکت را عیناً برمی‌گرداند و از
	// همه‌ی گاردها رد می‌شود، چون تعریفِ مشترک هنوز صدا زده شده بود. حالا
	// مصرف‌کننده محمول نمی‌سازد؛ بندش را به این‌جا می‌دهد و خروجی همیشه یک
	// زنجیره‌ی AND است که تست می‌تواند کاملش را ارزیابی کند.
	foreach ( (array) $extra as $clause ) {
		$clause = trim( (string) $clause );
		if ( $clause !== '' ) {
			$clauses[] = $clause;
		}
	}
	return implode( ' AND ', $clauses );
}
