<?php
/**
 * Admin «بازخورد»: ارسال تیکت به پنل فراز (POST /ws/v1/ticket).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * شناسه دپارتمان پشتیبانی (ثابت: ۷).
 *
 * @return string
 */
function farazsms_feedback_get_support_department_id() {
	return (string) apply_filters( 'farazsms_feedback_support_department_id', '3' );
}

/**
 * عنوان ثابت تیکت بازخورد.
 *
 * @return string
 */
function farazsms_feedback_get_ticket_title() {
	return (string) apply_filters( 'farazsms_feedback_ticket_title', 'بازخورد افزونه پیامکی فراز اس ام اس' );
}

/**
 * POST به یکی از مسیرهای تیکت با بدنه‌ی multipart (فرمتِ موردِ انتظارِ وب‌سرویسِ فراز).
 *
 * @param string               $api_key Api-Key header.
 * @param array<string,string> $fields  Form fields.
 * @param string               $path    مسیرِ نسبی؛ پیش‌فرض ساختِ تیکتِ جدید.
 * @return array|\WP_Error
 */
function farazsms_feedback_ticket_api_post( $api_key, $fields, $path = 'ticket' ) {
	$boundary = '----WTO' . wp_generate_password( 16, false );
	$body     = '';
	foreach ( $fields as $name => $value ) {
		$body .= '--' . $boundary . "\r\n";
		$body .= 'Content-Disposition: form-data; name="' . $name . '"' . "\r\n\r\n";
		$body .= $value . "\r\n";
	}
	$body .= '--' . $boundary . "--\r\n";

	$url  = farazsms_sms_api_url( $path );
	$args = array(
		'timeout' => 45,
		'headers' => array(
			'Accept'       => 'application/json',
			'Api-Key'      => $api_key,
			'Content-Type' => 'multipart/form-data; boundary=' . $boundary,
		),
		'body'    => $body,
	);

	return farazsms_remote_post_with_fallback( $url, $args );
}

// ============================================================================
// v3.22.145 — بازخوردِ دوطرفه: خواندنِ گفت‌وگوها و پاسخ‌دادن، داخلِ خودِ افزونه.
//
// همه‌ی درخواست‌ها فقط در پیشخوان و فقط با بازکردنِ همین صفحه اجرا می‌شوند؛ هیچ‌کدام روی
// رندرِ سایت یا کرانِ عمومی نیستند. پاسخ‌ها کوتاه‌مدت کش می‌شوند تا رفرشِ صفحه سرویس را
// نکوبد، و هر پاسخ/بستن کش را باطل می‌کند.
// ============================================================================

/**
 * نسخه‌ی ساختارِ داده‌ی کش‌شده. با هر تغییرِ شکلِ آرایه‌ی خروجی یک واحد جلو می‌رود تا کشِ
 * نسخه‌ی قبلیِ افزونه (که فیلدهای متفاوتی داشت) هرگز به کدِ جدید نرسد.
 */
const FARAZSMS_FEEDBACK_CACHE_VERSION = 2;

/**
 * کلیدِ دسترسی (خواندنِ یک‌جا برای همه‌ی مسیرهای این ماژول).
 *
 * @return string
 */
function farazsms_feedback_api_key() {
	return (string) farazsms_get_apikey();
}

/**
 * انتخابِ اولین کلیدِ موجود از میانِ نام‌های محتمل (شکلِ پاسخِ سرویس یکدست نیست).
 *
 * @param array $row
 * @param array $keys
 * @param mixed $default
 * @return mixed
 */
function farazsms_feedback_pick( $row, $keys, $default = '' ) {
	if ( ! is_array( $row ) ) {
		return $default;
	}
	foreach ( (array) $keys as $key ) {
		if ( isset( $row[ $key ] ) && $row[ $key ] !== null && $row[ $key ] !== '' ) {
			return $row[ $key ];
		}
	}
	return $default;
}

/**
 * v3.22.146: همان انتخاب، ولی همیشه رشته‌ی قابلِ‌نمایش برمی‌گرداند.
 *
 * بعضی فیلدهای پاسخ (مثلِ دپارتمان یا فرستنده) خودشان شیء هستند؛ cast مستقیمِ آن‌ها به
 * رشته هم اخطارِ PHP می‌دهد و هم «Array» چاپ می‌کند. این‌جا اگر مقدار آرایه بود، نامِ
 * خوانا از داخلش برداشته می‌شود.
 *
 * @param array $row
 * @param array $keys
 * @param string $default
 * @return string
 */
function farazsms_feedback_pick_str( $row, $keys, $default = '' ) {
	$value = farazsms_feedback_pick( $row, $keys, null );
	if ( $value === null ) {
		return $default;
	}
	if ( is_array( $value ) ) {
		$inner = farazsms_feedback_pick( $value, array( 'name', 'title', 'label', 'value', 'text' ), null );
		if ( is_array( $inner ) || $inner === null ) {
			return $default;
		}
		$value = $inner;
	}
	if ( is_bool( $value ) ) {
		return $value ? '1' : '';
	}
	if ( is_scalar( $value ) ) {
		$value = trim( (string) $value );
		return $value !== '' ? $value : $default;
	}
	return $default;
}

/**
 * تاریخِ شمسیِ خوانا از تاریخِ ISO سرویس (که به وقتِ UTC است).
 *
 * @param string $raw
 * @return string
 */
function farazsms_feedback_date( $raw ) {
	$raw = trim( (string) $raw );
	if ( $raw === '' ) {
		return '—';
	}
	// وقتِ تهران، مستقل از منطقه‌ی زمانیِ سایت (که اغلب روی UTC مانده است).
	$tz = class_exists( 'DateTimeZone' ) ? new DateTimeZone( 'Asia/Tehran' ) : null;
	return farazsms_send_reports_to_jalali( $raw, true, $tz );
}

/**
 * بیرون‌کشیدنِ فهرستِ ردیف‌ها از پاسخ (data / data.data / items / tickets / خودِ آرایه).
 *
 * @param mixed $data
 * @return array<int,array>
 */
function farazsms_feedback_extract_rows( $data ) {
	if ( ! is_array( $data ) ) {
		return array();
	}
	$candidates = array( $data );
	foreach ( array( 'data', 'items', 'tickets', 'result', 'messages', 'conversations' ) as $key ) {
		if ( isset( $data[ $key ] ) && is_array( $data[ $key ] ) ) {
			$candidates[] = $data[ $key ];
			foreach ( array( 'data', 'items', 'tickets', 'messages', 'conversations' ) as $inner ) {
				if ( isset( $data[ $key ][ $inner ] ) && is_array( $data[ $key ][ $inner ] ) ) {
					$candidates[] = $data[ $key ][ $inner ];
				}
			}
		}
	}
	foreach ( $candidates as $candidate ) {
		$list = array_filter( $candidate, 'is_array' );
		// فهرستِ واقعی = آرایه‌ی عددیِ غیرخالی از آرایه‌ها.
		if ( ! empty( $list ) && array_keys( $list ) === range( 0, count( $list ) - 1 ) ) {
			return array_values( $list );
		}
	}
	return array();
}

/**
 * برچسبِ فارسیِ وضعیتِ تیکت + رنگِ آن.
 *
 * @param string $status
 * @return array{label:string, bg:string, fg:string}
 */
function farazsms_feedback_status_badge( $status ) {
	// v3.22.146: رنگ‌ها از کلاس‌های مشترکِ افزونه می‌آیند، نه استایلِ درون‌خطی.
	$map = array(
		'answered' => array( 'پاسخ داده شد', 'success' ),
		'asked'    => array( 'در انتظار پاسخ', 'warning' ),
		'pending'  => array( 'در انتظار بررسی', 'warning' ),
		'referred' => array( 'ارجاع به کارشناس', 'info' ),
		'closed'   => array( 'بسته شده', 'muted' ),
	);
	$key = strtolower( trim( (string) $status ) );
	$row = isset( $map[ $key ] ) ? $map[ $key ] : array( ( $status !== '' ? (string) $status : '—' ), 'muted' );
	return array(
		'label' => $row[0],
		'class' => 'farazsms-status farazsms-status-' . $row[1],
	);
}

/**
 * فهرستِ تیکت‌ها — GET /ws/v1/ticket
 *
 * @param bool $force نادیده‌گرفتنِ کش.
 * @return array{ok:bool, rows:array, raw:array|null, error:string}
 */
function farazsms_feedback_tickets_fetch( $force = false ) {
	$cache_key = 'farazsms_fb_tickets_v' . FARAZSMS_FEEDBACK_CACHE_VERSION;
	if ( ! $force ) {
		$cached = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
	}

	$out = array( 'ok' => false, 'rows' => array(), 'raw' => null, 'error' => '' );
	$key = farazsms_feedback_api_key();
	if ( $key === '' ) {
		$out['error'] = __( 'کلید دسترسی (Api-Key) ثبت نشده است.', 'farazsms' );
		return $out;
	}

	$response = farazsms_sms_request( 'GET', 'ticket', array( 'apikey' => $key, 'timeout' => 20 ) );
	if ( is_wp_error( $response ) ) {
		$out['error'] = $response->get_error_message();
		return $out;
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	$data = farazsms_sms_decode( $response );
	if ( $code < 200 || $code >= 300 ) {
		$out['error'] = is_array( $data ) && ! empty( $data['message'] ) && is_string( $data['message'] )
			? $data['message']
			: sprintf( 'HTTP %d', $code );
		return $out;
	}

	$rows = array();
	foreach ( farazsms_feedback_extract_rows( $data ) as $row ) {
		$id = farazsms_feedback_pick_str( $row, array( 'id', 'ticket_id', 'ticketId' ), '' );
		if ( $id === '' ) {
			continue;
		}
		$rows[] = array(
			'id'         => $id,
			'title'      => farazsms_feedback_pick_str( $row, array( 'title', 'subject', 'ticket_title' ), '—' ),
			'status'     => farazsms_feedback_pick_str( $row, array( 'status', 'ticket_status', 'state' ), '' ),
			'department' => farazsms_feedback_pick_str( $row, array( 'support_department', 'department', 'department_name' ), '' ),
			'created'    => farazsms_feedback_pick_str( $row, array( 'created_at', 'create_date', 'created', 'date' ), '' ),
			'updated'    => farazsms_feedback_pick_str( $row, array( 'updated_at', 'last_reply_at', 'modified_at', 'update_date' ), '' ),
		);
	}

	$out['ok']  = true;
	$out['rows'] = $rows;
	$out['raw'] = is_array( $data ) ? $data : null;
	// کشِ کوتاه: رفرشِ پشت‌سرهمِ صفحه نباید سرویس را بکوبد؛ دکمه‌ی «به‌روزرسانی» force می‌کند.
	set_transient( $cache_key, $out, 2 * MINUTE_IN_SECONDS );
	return $out;
}

/**
 * گفت‌وگوی یک تیکت — GET /ws/v1/ticket/{id}
 *
 * @param string $ticket_id
 * @param bool   $force
 * @return array{ok:bool, ticket:array, messages:array, raw:array|null, error:string}
 */
function farazsms_feedback_ticket_fetch_one( $ticket_id, $force = false ) {
	$ticket_id = preg_replace( '/\D+/', '', (string) $ticket_id );
	$out       = array( 'ok' => false, 'ticket' => array(), 'messages' => array(), 'raw' => null, 'error' => '' );
	if ( $ticket_id === '' ) {
		$out['error'] = __( 'شناسه‌ی گفت‌وگو نامعتبر است.', 'farazsms' );
		return $out;
	}
	$cache_key = 'farazsms_fb_ticket_v' . FARAZSMS_FEEDBACK_CACHE_VERSION . '_' . $ticket_id;
	if ( ! $force ) {
		$cached = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
	}

	$key = farazsms_feedback_api_key();
	if ( $key === '' ) {
		$out['error'] = __( 'کلید دسترسی (Api-Key) ثبت نشده است.', 'farazsms' );
		return $out;
	}

	$response = farazsms_sms_request( 'GET', 'ticket/' . $ticket_id, array( 'apikey' => $key, 'timeout' => 20 ) );
	if ( is_wp_error( $response ) ) {
		$out['error'] = $response->get_error_message();
		return $out;
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	$data = farazsms_sms_decode( $response );
	if ( $code < 200 || $code >= 300 ) {
		$out['error'] = is_array( $data ) && ! empty( $data['message'] ) && is_string( $data['message'] )
			? $data['message']
			: sprintf( 'HTTP %d', $code );
		return $out;
	}

	// ساختارِ واقعیِ پاسخ (تأییدشده روی داده‌ی زنده):
	// data: { id, status, title, department:{id,title}, messages:[ {
	//     id, type: question|answer|system, text (HTML), files: array|null,
	//     customer_id, admin_id, created_at, customer:{first_name,last_name}|null,
	//     admin:{first_name,last_name,username}|null } ] }
	$payload  = isset( $data['data'] ) && is_array( $data['data'] ) ? $data['data'] : array();
	$dept     = isset( $payload['department'] ) && is_array( $payload['department'] ) ? $payload['department'] : array();
	$out['ticket'] = array(
		'id'         => farazsms_feedback_pick_str( $payload, array( 'id' ), $ticket_id ),
		'title'      => farazsms_feedback_pick_str( $payload, array( 'title' ), '' ),
		'status'     => farazsms_feedback_pick_str( $payload, array( 'status' ), '' ),
		'department' => farazsms_feedback_pick_str( $dept, array( 'title', 'name' ), '' ),
	);

	$messages = isset( $payload['messages'] ) && is_array( $payload['messages'] ) ? $payload['messages'] : array();
	foreach ( $messages as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$type = strtolower( farazsms_feedback_pick_str( $row, array( 'type' ), '' ) );
		$text = farazsms_feedback_pick_str( $row, array( 'text' ), '' );
		if ( $text === '' ) {
			continue;
		}

		// نامِ فرستنده از همان بلوکی که سرویس می‌دهد: پاسخ = admin، پرسش = customer.
		$person = array();
		if ( $type === 'answer' && isset( $row['admin'] ) && is_array( $row['admin'] ) ) {
			$person = $row['admin'];
		} elseif ( isset( $row['customer'] ) && is_array( $row['customer'] ) ) {
			$person = $row['customer'];
		}
		$sender = trim(
			farazsms_feedback_pick_str( $person, array( 'first_name' ), '' ) . ' ' .
			farazsms_feedback_pick_str( $person, array( 'last_name' ), '' )
		);
		if ( $sender === '' ) {
			$sender = farazsms_feedback_pick_str( $person, array( 'username', 'name' ), '' );
		}

		// files: آرایه‌ی مسیرهای سمتِ سرور (یا null). خودِ مسیر قابلِ‌بازکردن نیست؛ دانلود از
		// مسیرِ اختصاصیِ سرویس با شناسه‌ی پیام و اندیسِ فایل انجام می‌شود.
		$files = array();
		if ( ! empty( $row['files'] ) && is_array( $row['files'] ) ) {
			foreach ( array_values( $row['files'] ) as $index => $path ) {
				if ( ! is_scalar( $path ) ) {
					continue;
				}
				$files[] = array(
					'index' => (int) $index,
					'name'  => basename( str_replace( '\\', '/', (string) $path ) ),
				);
			}
		}

		$out['messages'][] = array(
			'id'      => farazsms_feedback_pick_str( $row, array( 'id' ), '' ),
			'type'    => $type,
			'text'    => $text,
			'sender'  => $sender,
			'created' => farazsms_feedback_pick_str( $row, array( 'created_at' ), '' ),
			'files'   => $files,
		);
	}

	$out['ok']  = true;
	$out['raw'] = is_array( $data ) ? $data : null;
	set_transient( $cache_key, $out, MINUTE_IN_SECONDS );
	return $out;
}

/**
 * نشانیِ دانلودِ یک فایلِ ضمیمه (از داخلِ پیشخوان).
 *
 * مسیرهایی که سرویس در فیلدِ files می‌دهد، مسیرِ داخلیِ سرورِ فراز هستند و مستقیم باز
 * نمی‌شوند؛ دریافتِ فایل فقط با هدرِ کلیدِ دسترسی ممکن است، پس از داخلِ افزونه پراکسی
 * می‌شود (GET /ws/v1/ticket/file/download).
 *
 * @param string $message_id
 * @param int    $file_index
 * @return string
 */
function farazsms_feedback_file_url( $message_id, $file_index, $name = '' ) {
	return add_query_arg(
		array(
			'action'     => 'farazsms_feedback_file',
			'message_id' => (int) $message_id,
			'file_index' => (int) $file_index,
			'name'       => rawurlencode( sanitize_file_name( (string) $name ) ),
			'_wpnonce'   => wp_create_nonce( 'farazsms_feedback_file' ),
		),
		admin_url( 'admin-ajax.php' )
	);
}

add_action( 'wp_ajax_farazsms_feedback_file', 'farazsms_feedback_download_file' );
/**
 * پراکسیِ دانلودِ فایلِ ضمیمه‌ی تیکت — فقط مدیر، فقط با nonce.
 *
 * @return void
 */
function farazsms_feedback_download_file() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'farazsms_feedback_file' );

	$message_id = isset( $_GET['message_id'] ) ? (int) $_GET['message_id'] : 0;
	$file_index = isset( $_GET['file_index'] ) ? (int) $_GET['file_index'] : 0;
	$api_key    = farazsms_feedback_api_key();
	if ( $message_id <= 0 || $api_key === '' ) {
		wp_die( esc_html__( 'درخواستِ نامعتبر.', 'farazsms' ), '', array( 'response' => 400 ) );
	}

	$response = farazsms_sms_request(
		'GET',
		add_query_arg(
			array(
				'ticket_message_id' => $message_id,
				'file_index'        => $file_index,
			),
			farazsms_sms_api_url( 'ticket/file/download' )
		),
		array( 'apikey' => $api_key, 'timeout' => 30 )
	);

	if ( is_wp_error( $response ) ) {
		wp_die( esc_html( $response->get_error_message() ), '', array( 'response' => 502 ) );
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	$body = wp_remote_retrieve_body( $response );
	if ( $code < 200 || $code >= 300 || $body === '' ) {
		wp_die( esc_html__( 'دریافتِ فایل از سرویس ممکن نشد.', 'farazsms' ), '', array( 'response' => 502 ) );
	}

	$type = wp_remote_retrieve_header( $response, 'content-type' );
	$type = is_array( $type ) ? (string) reset( $type ) : (string) $type;
	if ( $type === '' || stripos( $type, 'application/json' ) === 0 ) {
		$type = 'application/octet-stream';
	}
	// نامِ فایل: نامی که در خودِ گفت‌وگو دیده شده، وگرنه هدرِ سرویس، وگرنه نامِ عمومی.
	// کدریویو v3.22.152: پیش از این، نامِ عمومی قبل از خواندنِ هدر ست می‌شد و شاخه‌ی هدر
	// هرگز اجرا نمی‌شد (کدِ مرده) — یعنی فایل بی‌پسوند ذخیره می‌شد.
	$name = ( isset( $_GET['name'] ) && is_scalar( $_GET['name'] ) ) ? sanitize_file_name( rawurldecode( (string) wp_unslash( $_GET['name'] ) ) ) : '';
	if ( $name === '' ) {
		$disp = wp_remote_retrieve_header( $response, 'content-disposition' );
		$disp = is_array( $disp ) ? (string) reset( $disp ) : (string) $disp;
		if ( preg_match( '/filename="?([^";]+)"?/i', $disp, $m ) ) {
			$name = sanitize_file_name( $m[1] );
		}
	}
	if ( $name === '' ) {
		$name = 'farazsms-ticket-' . $message_id . '-' . $file_index;
	}

	// بافرِ خروجی/فشرده‌سازی باید پیش از ارسالِ بایت‌های فایل خالی شود، وگرنه طولِ اعلام‌شده
	// با محتوا نمی‌خواند و فایلِ دانلودشده خراب می‌شود.
	while ( ob_get_level() > 0 ) {
		@ob_end_clean();
	}
	nocache_headers();
	header( 'Content-Type: ' . $type );
	header( 'Content-Length: ' . strlen( $body ) );
	header( 'Content-Disposition: attachment; filename="' . $name . '"' );
	header( 'X-Content-Type-Options: nosniff' );
	echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- بدنه‌ی باینریِ فایل.
	exit;
}

/**
 * باطل‌کردنِ کشِ فهرست/گفت‌وگو (بعد از پاسخ یا بستن).
 *
 * @param string $ticket_id
 * @return void
 */
function farazsms_feedback_cache_flush( $ticket_id = '' ) {
	delete_transient( 'farazsms_fb_tickets_v' . FARAZSMS_FEEDBACK_CACHE_VERSION );
	$ticket_id = preg_replace( '/\D+/', '', (string) $ticket_id );
	if ( $ticket_id !== '' ) {
		delete_transient( 'farazsms_fb_ticket_v' . FARAZSMS_FEEDBACK_CACHE_VERSION . '_' . $ticket_id );
	}
}

/**
 * @return int
 */
function farazsms_feedback_ticket_rate_count() {
	$key = 'farazsms_fb_ticket_rl_' . get_current_user_id();
	$n   = (int) get_transient( $key );
	return max( 0, $n );
}

/**
 * @return void
 */
function farazsms_feedback_ticket_rate_bump() {
	$key = 'farazsms_fb_ticket_rl_' . get_current_user_id();
	$n   = farazsms_feedback_ticket_rate_count() + 1;
	set_transient( $key, $n, HOUR_IN_SECONDS );
}

/**
 * ثبت زیرمنو در انتهای منوی فراز اس ام اس.
 */
add_action( 'admin_menu', 'farazsms_register_feedback_submenu', 999 );
function farazsms_register_feedback_submenu() {
	add_submenu_page(
		'farazsms',
		__( 'بازخورد', 'farazsms' ),
		__( 'بازخورد', 'farazsms' ),
		'manage_options',
		'farazsms-feedback',
		'farazsms_render_feedback_ticket_page'
	);
}

add_action( 'admin_init', 'farazsms_feedback_ticket_handle_post', 1 );
function farazsms_feedback_ticket_handle_post() {
	if ( ! is_admin() ) {
		return;
	}
	if ( ! isset( $_GET['page'] ) || sanitize_text_field( wp_unslash( $_GET['page'] ) ) !== 'farazsms-feedback' ) {
		return;
	}
	if ( ( $_SERVER['REQUEST_METHOD'] ?? '' ) !== 'POST' ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	// v3.22.145: پاسخ‌دادن/بستنِ گفت‌وگو — هرکدام nonce و مسیرِ خودش را دارد.
	if ( ! empty( $_POST['farazsms_feedback_reply_submit'] ) ) {
		farazsms_feedback_handle_reply();
		return;
	}
	if ( ! empty( $_POST['farazsms_feedback_close_submit'] ) ) {
		farazsms_feedback_handle_close();
		return;
	}
	if ( empty( $_POST['farazsms_feedback_ticket_submit'] ) ) {
		return;
	}
	check_admin_referer( 'farazsms_feedback_ticket', 'farazsms_feedback_ticket_nonce' );

	$redirect_base = admin_url( 'admin.php?page=farazsms-feedback' );

	if ( farazsms_feedback_ticket_rate_count() >= 8 ) {
		wp_safe_redirect( add_query_arg( 'farazsms_ticket', 'ratelimit', $redirect_base ) );
		exit;
	}

	$api_key = farazsms_get_apikey();
	if ( $api_key === '' ) {
		wp_safe_redirect( add_query_arg( 'farazsms_ticket', 'noapikey', $redirect_base ) );
		exit;
	}

	$dept = farazsms_feedback_get_support_department_id();

	$question = isset( $_POST['ticket_question'] ) ? farazsms_sanitize_pattern_text( $_POST['ticket_question'] ) : '';
	$question = trim( $question );
	if ( $question === '' ) {
		wp_safe_redirect( add_query_arg( 'farazsms_ticket', 'needbody', $redirect_base ) );
		exit;
	}

	$title = farazsms_feedback_get_ticket_title();

	$user = wp_get_current_user();
	$ctx  = sprintf(
		"\n\n---\nسایت: %s\nوردپرس: %s\nافزونه: %s\nکاربر مدیر: %s (%s)\n",
		home_url( '/' ),
		get_bloginfo( 'version' ),
		defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '',
		$user->display_name,
		$user->user_email
	);
	$question .= $ctx;

	$fields = array(
		'support_department_id' => $dept,
		'title'                 => $title,
		'importance'            => 'normal',
		'question'              => $question,
	);

	$response = farazsms_feedback_ticket_api_post( $api_key, $fields );

	if ( is_wp_error( $response ) ) {
		farazsms_feedback_ticket_rate_bump();
		wp_safe_redirect(
			add_query_arg(
				array(
					'farazsms_ticket' => 'error',
					'farazsms_err'    => rawurlencode( $response->get_error_message() ),
				),
				$redirect_base
			)
		);
		exit;
	}

	$code = wp_remote_retrieve_response_code( $response );
	$raw  = wp_remote_retrieve_body( $response );
	$data = json_decode( $raw, true );

	if ( is_array( $data ) && isset( $data['status'] ) && $data['status'] === 'success' ) {
		farazsms_feedback_ticket_rate_bump();
		wp_safe_redirect( add_query_arg( 'farazsms_ticket', 'sent', $redirect_base ) );
		exit;
	}

	farazsms_feedback_ticket_rate_bump();
	$msg = is_array( $data ) && isset( $data['message'] )
		? ( is_string( $data['message'] ) ? $data['message'] : wp_json_encode( $data['message'], JSON_UNESCAPED_UNICODE ) )
		: ( 'HTTP ' . (int) $code . ' ' . ( function_exists( 'mb_substr' ) ? mb_substr( $raw, 0, 200 ) : substr( $raw, 0, 200 ) ) );

	wp_safe_redirect(
		add_query_arg(
			array(
				'farazsms_ticket' => 'error',
				'farazsms_err'    => rawurlencode( $msg ),
			),
			$redirect_base
		)
	);
	exit;
}

/**
 * ارسالِ پاسخ به یک گفت‌وگو — POST /ws/v1/ticket/reply
 *
 * @return void
 */
function farazsms_feedback_handle_reply() {
	check_admin_referer( 'farazsms_feedback_reply', 'farazsms_feedback_reply_nonce' );

	$ticket_id     = ( isset( $_POST['ticket_id'] ) && is_scalar( $_POST['ticket_id'] ) ) ? preg_replace( '/\D+/', '', (string) wp_unslash( $_POST['ticket_id'] ) ) : '';
	$redirect_base = add_query_arg(
		array( 'page' => 'farazsms-feedback', 'tab' => 'conversations', 'ticket_id' => $ticket_id ),
		admin_url( 'admin.php' )
	);
	$fail = function ( $flag, $err = '' ) use ( $redirect_base ) {
		$args = array( 'farazsms_ticket' => $flag );
		if ( $err !== '' ) {
			$args['farazsms_err'] = rawurlencode( $err );
		}
		wp_safe_redirect( add_query_arg( $args, $redirect_base ) );
		exit;
	};

	if ( $ticket_id === '' ) {
		$fail( 'error', __( 'شناسه‌ی گفت‌وگو نامعتبر است.', 'farazsms' ) );
	}
	if ( farazsms_feedback_ticket_rate_count() >= 8 ) {
		$fail( 'ratelimit' );
	}
	$api_key = farazsms_feedback_api_key();
	if ( $api_key === '' ) {
		$fail( 'noapikey' );
	}
	$text = isset( $_POST['reply_text'] ) ? trim( farazsms_sanitize_pattern_text( $_POST['reply_text'] ) ) : '';
	if ( $text === '' ) {
		$fail( 'needbody' );
	}

	// v3.22.151: نامِ مسیر در مستندات «ticket/replay» نوشته شده، ولی مسیرِ واقعیِ سرویس
	// «ticket/reply» است (غلطِ املایی در مستندات). با آزمونِ روتینگِ خودِ سرویس تأیید شد:
	//     POST ticket/replay → 405 (وجود ندارد؛ به ticket/{id} می‌افتد)
	//     POST ticket/reply  → 401 (مسیر هست، فقط کلید می‌خواهد)
	// مسیرِ PUT ticket/{id} هم وجود دارد ولی مالِ پنلِ پشتیبانی است و کلیدِ مشتری
	// اجازه‌اش را ندارد («شما دسترسی کافی برای دسترسی به این روت را ندارید»).
	// بدنه طبقِ همان مستندات: multipart با ticket_id و text.
	$response = farazsms_feedback_ticket_api_post(
		$api_key,
		array( 'ticket_id' => $ticket_id, 'text' => $text ),
		'ticket/reply'
	);
	farazsms_feedback_ticket_rate_bump();

	if ( is_wp_error( $response ) ) {
		$fail( 'error', $response->get_error_message() );
	}
	$code = (int) wp_remote_retrieve_response_code( $response );
	$data = farazsms_sms_decode( $response );
	$ok   = ( $code >= 200 && $code < 300 ) && ( ! is_array( $data ) || ! isset( $data['status'] ) || $data['status'] !== 'error' );
	if ( ! $ok ) {
		$msg = is_array( $data ) && ! empty( $data['message'] ) && is_string( $data['message'] ) ? $data['message'] : sprintf( 'HTTP %d', $code );
		$fail( 'error', $msg );
	}

	farazsms_feedback_cache_flush( $ticket_id );
	wp_safe_redirect( add_query_arg( 'farazsms_ticket', 'replied', $redirect_base ) );
	exit;
}

/**
 * بستنِ گفت‌وگو — POST /ws/v1/ticket/closed
 *
 * @return void
 */
function farazsms_feedback_handle_close() {
	check_admin_referer( 'farazsms_feedback_close', 'farazsms_feedback_close_nonce' );

	$ticket_id     = ( isset( $_POST['ticket_id'] ) && is_scalar( $_POST['ticket_id'] ) ) ? preg_replace( '/\D+/', '', (string) wp_unslash( $_POST['ticket_id'] ) ) : '';
	$redirect_base = add_query_arg(
		array( 'page' => 'farazsms-feedback', 'tab' => 'conversations', 'ticket_id' => $ticket_id ),
		admin_url( 'admin.php' )
	);
	$api_key = farazsms_feedback_api_key();
	if ( $ticket_id === '' || $api_key === '' ) {
		wp_safe_redirect( add_query_arg( 'farazsms_ticket', $api_key === '' ? 'noapikey' : 'error', $redirect_base ) );
		exit;
	}

	$response = farazsms_sms_request( 'POST', 'ticket/closed', array(
		'apikey'  => $api_key,
		'timeout' => 20,
		'body'    => array( 'ticket_id' => (int) $ticket_id ),
	) );

	$err = '';
	if ( is_wp_error( $response ) ) {
		$err = $response->get_error_message();
	} else {
		$code = (int) wp_remote_retrieve_response_code( $response );
		$data = farazsms_sms_decode( $response );
		// کدریویو v3.22.152: بعضی مسیرها با ۲۰۰ ولی status=error پاسخ می‌دهند؛ همان گاردی که
		// مسیرِ پاسخ دارد این‌جا هم لازم است، وگرنه پیامِ «بسته شد» دروغ می‌شد.
		$api_err = is_array( $data ) && isset( $data['status'] ) && $data['status'] === 'error';
		if ( $code < 200 || $code >= 300 || $api_err ) {
			$err = is_array( $data ) && ! empty( $data['message'] ) && is_string( $data['message'] ) ? $data['message'] : sprintf( 'HTTP %d', $code );
		}
	}

	farazsms_feedback_cache_flush( $ticket_id );
	if ( $err !== '' ) {
		wp_safe_redirect( add_query_arg( array( 'farazsms_ticket' => 'error', 'farazsms_err' => rawurlencode( $err ) ), $redirect_base ) );
		exit;
	}
	wp_safe_redirect( add_query_arg( 'farazsms_ticket', 'closed', $redirect_base ) );
	exit;
}

/**
 * پیام وضعیت برای نمایش در صفحه بازخورد.
 *
 * @param string $flag
 * @param string $err
 * @return string HTML یا خالی
 */
function farazsms_feedback_ticket_status_message( $flag, $err = '' ) {
	if ( $flag === 'sent' ) {
		return '<div class="farazsms_notice farazsms_notice--success"><p>' . esc_html__( 'بازخورد شما با موفقیت ثبت شد.', 'farazsms' ) . '</p></div>';
	}
	if ( $flag === 'replied' ) {
		return '<div class="farazsms_notice farazsms_notice--success"><p>' . esc_html__( 'پاسخ شما ارسال شد.', 'farazsms' ) . '</p></div>';
	}
	if ( $flag === 'closed' ) {
		return '<div class="farazsms_notice farazsms_notice--success"><p>' . esc_html__( 'گفت‌وگو بسته شد.', 'farazsms' ) . '</p></div>';
	}
	if ( $flag === 'ratelimit' ) {
		return '<div class="farazsms_notice"><p>' . esc_html__( 'تعداد درخواست‌ها زیاد است؛ یک ساعت بعد دوباره تلاش کنید.', 'farazsms' ) . '</p></div>';
	}
	if ( $flag === 'error' && $err !== '' ) {
		return '<div class="farazsms_notice"><p>' . esc_html( $err ) . '</p></div>';
	}
	if ( $flag === 'needbody' ) {
		return '<div class="farazsms_notice"><p>' . esc_html__( 'لطفاً نظر خود را بنویسید.', 'farazsms' ) . '</p></div>';
	}
	if ( $flag === 'noapikey' ) {
		return '<div class="farazsms_notice"><p>' . esc_html__( 'ابتدا در تب «تنظیمات» کلید دسترسی (Api-Key) را ذخیره کنید.', 'farazsms' ) . '</p></div>';
	}
	return '';
}

/**
 * @return void
 */
function farazsms_render_feedback_ticket_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'شما به این صفحه دسترسی ندارید.', 'farazsms' ) );
	}

	$api_key = farazsms_get_apikey();
	$flag    = isset( $_GET['farazsms_ticket'] ) ? sanitize_text_field( wp_unslash( $_GET['farazsms_ticket'] ) ) : '';
	$err     = isset( $_GET['farazsms_err'] ) ? sanitize_text_field( rawurldecode( wp_unslash( $_GET['farazsms_err'] ) ) ) : '';
	$status     = farazsms_feedback_ticket_status_message( $flag, $err );
	$can_submit = ( $api_key !== '' );

	// v3.22.145: دو تب — «ارسال بازخورد» و «گفت‌وگوها». درخواستِ وب‌سرویس فقط وقتی زده
	// می‌شود که تبِ گفت‌وگوها باز باشد، تا بازکردنِ فرمِ ارسال هیچ انتظاری نداشته باشد.
	$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'send';
	if ( $tab === 'conversations' ) {
		farazsms_feedback_render_conversations_tab( $status );
		return;
	}
	farazsms_feedback_render_tabs( 'send' );

	// v3.13.19 REWRITE: ساختار قدیمی section.wrapper + ul.tabs + ul.tab__content حذف شد.
	// قاب یکپارچه (Unified Frame) خودش این chrome را فراهم می‌کند، بنابراین تکرار
	// آن باعث تداخل CSS و در شرایط خاص صفحه سفید می‌شد. حالا فقط فرم را با
	// inline style مستقیم render می‌کنیم — هیچ class قدیمی استفاده نمی‌شود.
	?>
	<div class="farazsms-feedback-wrapper">
		<?php if ( $status !== '' ) : ?>
			<div class="farazsms-fb-status"><?php echo $status; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper ?></div>
		<?php endif; ?>

		<?php if ( $api_key === '' ) : ?>
			<div class="farazsms-fb-card farazsms-fb-card--warn">
				⚠️
				<?php esc_html_e( 'ابتدا در صفحه «تنظیمات» کلید دسترسی (Api-Key) را ذخیره کنید.', 'farazsms' ); ?>
				<a class="farazsms-fb-inline-link" href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-settings' ) ); ?>"><?php esc_html_e( 'رفتن به تنظیمات', 'farazsms' ); ?></a>
			</div>
		<?php endif; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-feedback' ) ); ?>" id="farazsms_feedback_ticket_form" class="farazsms-fb-card farazsms-fb-send">
			<?php wp_nonce_field( 'farazsms_feedback_ticket', 'farazsms_feedback_ticket_nonce' ); ?>

			<p class="farazsms-fb-send__intro">
				💬 <?php esc_html_e( 'نظر، پیشنهاد یا گزارش مشکل خود را بنویسید؛ پس از ثبت، مستقیماً به پشتیبانی فراز اس‌ام‌اس ارسال می‌شود.', 'farazsms' ); ?>
			</p>

			<label for="ticket_question" class="farazsms-fb-send__field">
				<span class="farazsms-fb-reply__label">
					<?php esc_html_e( 'متن بازخورد', 'farazsms' ); ?>
					<span class="farazsms-fb-req">*</span>
				</span>
				<textarea
					name="ticket_question"
					id="ticket_question"
					rows="10"
					required
					dir="rtl"
					placeholder="<?php esc_attr_e( 'بازخورد یا گزارش مشکل خود را اینجا بنویسید...', 'farazsms' ); ?>"
					class="farazsms-fb-reply__text farazsms-fb-send__text"
				><?php echo isset( $_POST['ticket_question'] ) ? esc_textarea( wp_unslash( $_POST['ticket_question'] ) ) : ''; ?></textarea>
			</label>

			<div class="farazsms-fb-reply__actions">
				<button
					type="submit"
					name="farazsms_feedback_ticket_submit"
					value="1"
					<?php disabled( ! $can_submit ); ?>
					class="button button-primary"
				>
					📨 <?php esc_html_e( 'ثبت بازخورد', 'farazsms' ); ?>
				</button>
				<?php if ( ! $can_submit ) : ?>
					<span class="farazsms-fb-req"><?php esc_html_e( 'برای ثبت بازخورد، Api-Key لازم است.', 'farazsms' ); ?></span>
				<?php endif; ?>
			</div>
		</form>
	</div>
	<?php
}

/**
 * نوارِ تب‌ها (ارسالِ بازخورد / گفت‌وگوها).
 *
 * @param string $active
 * @return void
 */
function farazsms_feedback_render_tabs( $active ) {
	// v3.22.146: کامپوننتِ تبِ مشترکِ افزونه (همان ظاهرِ بقیه‌ی صفحات) به‌جای تبِ دست‌ساز.
	farazsms_render_tabs(
		array(
			'send'          => array( 'label' => __( 'ارسال بازخورد', 'farazsms' ), 'icon' => 'dashicons-edit' ),
			'conversations' => array( 'label' => __( 'گفت‌وگوها و پاسخ‌ها', 'farazsms' ), 'icon' => 'dashicons-format-chat' ),
		),
		$active,
		array( 'param' => 'tab', 'base_url' => admin_url( 'admin.php?page=farazsms-feedback' ) )
	);
}

/**
 * تبِ گفت‌وگوها: یا فهرستِ تیکت‌ها، یا صفحه‌ی یک گفت‌وگو با امکانِ پاسخ.
 *
 * @param string $status_html پیامِ وضعیت (از پیش escape شده).
 * @return void
 */
function farazsms_feedback_render_conversations_tab( $status_html ) {
	farazsms_feedback_render_tabs( 'conversations' );

	$ticket_id = ( isset( $_GET['ticket_id'] ) && is_scalar( $_GET['ticket_id'] ) ) ? preg_replace( '/\D+/', '', (string) wp_unslash( $_GET['ticket_id'] ) ) : '';
	$force     = ! empty( $_GET['refresh'] );

	echo '<div class="farazsms-feedback-wrapper">';
	if ( $status_html !== '' ) {
		echo '<div class="farazsms-fb-status">' . $status_html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in helper
	}

	if ( farazsms_feedback_api_key() === '' ) {
		echo '<div class="farazsms-fb-card farazsms-fb-card--warn">⚠️ '
			. esc_html__( 'ابتدا در صفحه «تنظیمات» کلید دسترسی (Api-Key) را ذخیره کنید.', 'farazsms' ) . '</div></div>';
		return;
	}

	if ( $ticket_id !== '' ) {
		farazsms_feedback_render_single_conversation( $ticket_id, $force );
	} else {
		farazsms_feedback_render_ticket_list( $force );
	}
	echo '</div>';
}

/**
 * فهرستِ گفت‌وگوها.
 *
 * @param bool $force
 * @return void
 */
function farazsms_feedback_render_ticket_list( $force ) {
	$result   = farazsms_feedback_tickets_fetch( $force );
	$base     = add_query_arg( array( 'page' => 'farazsms-feedback', 'tab' => 'conversations' ), admin_url( 'admin.php' ) );
	$refresh  = add_query_arg( 'refresh', '1', $base );
	$answered = 0;
	foreach ( $result['rows'] as $row ) {
		if ( strtolower( $row['status'] ) === 'answered' ) {
			$answered++;
		}
	}
	?>
	<div class="farazsms-fb-bar">
		<p>
			<?php esc_html_e( 'بازخوردهایی که فرستاده‌اید و پاسخِ پشتیبانی، همین‌جا دیده و پاسخ داده می‌شوند — بدونِ رفتن به پنل.', 'farazsms' ); ?>
			<?php if ( $answered > 0 ) : ?>
				<strong>
					<?php printf( esc_html__( '%s گفت‌وگو پاسخِ تازه دارد.', 'farazsms' ), esc_html( number_format_i18n( $answered ) ) ); ?>
				</strong>
			<?php endif; ?>
		</p>
		<a class="button" href="<?php echo esc_url( $refresh ); ?>">🔄 <?php esc_html_e( 'به‌روزرسانی', 'farazsms' ); ?></a>
	</div>

	<?php if ( ! $result['ok'] ) : ?>
		<div class="farazsms-fb-card farazsms-fb-card--error">
			<?php esc_html_e( 'دریافتِ فهرستِ گفت‌وگوها ممکن نشد:', 'farazsms' ); ?>
			<span dir="ltr" class="farazsms-fb-date"><?php echo esc_html( $result['error'] ); ?></span>
		</div>
		<?php return; ?>
	<?php endif; ?>

	<?php if ( empty( $result['rows'] ) ) : ?>
		<div class="farazsms-fb-card farazsms-fb-card--empty">
			<?php esc_html_e( 'هنوز گفت‌وگویی ثبت نشده است. از تبِ «ارسال بازخورد» اولین پیام را بفرستید.', 'farazsms' ); ?>
			<?php if ( is_array( $result['raw'] ) ) : ?>
				<details>
					<summary><?php esc_html_e( 'پاسخِ خامِ سرویس (برای پشتیبانی)', 'farazsms' ); ?></summary>
					<pre dir="ltr"><?php echo esc_html( wp_json_encode( $result['raw'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) ); ?></pre>
				</details>
			<?php endif; ?>
		</div>
		<?php return; ?>
	<?php endif; ?>

	<table class="widefat striped farazsms-feedback-table">
		<thead>
			<tr>
				<th class="farazsms-fb-col-id"><?php esc_html_e( 'شناسه', 'farazsms' ); ?></th>
				<th><?php esc_html_e( 'موضوع', 'farazsms' ); ?></th>
				<th class="farazsms-fb-col-status"><?php esc_html_e( 'وضعیت', 'farazsms' ); ?></th>
				<th class="farazsms-fb-col-date"><?php esc_html_e( 'آخرین به‌روزرسانی', 'farazsms' ); ?></th>
				<th class="farazsms-fb-col-action"></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $result['rows'] as $row ) :
				$badge = farazsms_feedback_status_badge( $row['status'] );
				$view  = add_query_arg( 'ticket_id', $row['id'], $base );
				$when  = $row['updated'] !== '' ? $row['updated'] : $row['created'];
			?>
				<tr>
					<td dir="ltr" class="farazsms-fb-date"><?php echo esc_html( $row['id'] ); ?></td>
					<td><a href="<?php echo esc_url( $view ); ?>"><?php echo esc_html( $row['title'] ); ?></a></td>
					<td><span class="<?php echo esc_attr( $badge['class'] ); ?>"><?php echo esc_html( $badge['label'] ); ?></span></td>
					<td class="farazsms-fb-date"><?php echo esc_html( farazsms_feedback_date( $when ) ); ?></td>
					<td><a class="button button-small" href="<?php echo esc_url( $view ); ?>"><?php esc_html_e( 'مشاهده و پاسخ', 'farazsms' ); ?></a></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php
}

/**
 * صفحه‌ی یک گفت‌وگو + فرمِ پاسخ + بستنِ گفت‌وگو.
 *
 * @param string $ticket_id
 * @param bool   $force
 * @return void
 */
function farazsms_feedback_render_single_conversation( $ticket_id, $force ) {
	$result = farazsms_feedback_ticket_fetch_one( $ticket_id, $force );
	$base   = add_query_arg( array( 'page' => 'farazsms-feedback', 'tab' => 'conversations' ), admin_url( 'admin.php' ) );
	$self   = add_query_arg( 'ticket_id', $ticket_id, $base );
	$badge  = farazsms_feedback_status_badge( $result['ticket']['status'] ?? '' );
	$closed = strtolower( (string) ( $result['ticket']['status'] ?? '' ) ) === 'closed';
	?>
	<p class="farazsms-fb-back">
		<a href="<?php echo esc_url( $base ); ?>">« <?php esc_html_e( 'بازگشت به فهرستِ گفت‌وگوها', 'farazsms' ); ?></a>
		<a href="<?php echo esc_url( add_query_arg( 'refresh', '1', $self ) ); ?>">🔄 <?php esc_html_e( 'به‌روزرسانی', 'farazsms' ); ?></a>
	</p>

	<?php if ( ! $result['ok'] ) : ?>
		<div class="farazsms-fb-card farazsms-fb-card--error">
			<?php esc_html_e( 'دریافتِ این گفت‌وگو ممکن نشد:', 'farazsms' ); ?>
			<span dir="ltr" class="farazsms-fb-date"><?php echo esc_html( $result['error'] ); ?></span>
		</div>
		<?php return; ?>
	<?php endif; ?>

	<div class="farazsms-fb-card farazsms-fb-head">
		<h2><?php echo esc_html( $result['ticket']['title'] !== '' ? $result['ticket']['title'] : __( 'گفت‌وگو', 'farazsms' ) ); ?></h2>
		<span class="<?php echo esc_attr( $badge['class'] ); ?>"><?php echo esc_html( $badge['label'] ); ?></span>
		<span class="farazsms-fb-id" dir="ltr">#<?php echo esc_html( $ticket_id ); ?></span>
	</div>

	<?php if ( empty( $result['messages'] ) ) : ?>
		<div class="farazsms-fb-card farazsms-fb-card--empty">
			<?php esc_html_e( 'پیامی برای نمایش نیست.', 'farazsms' ); ?>
			<?php if ( is_array( $result['raw'] ) ) : ?>
				<details>
					<summary><?php esc_html_e( 'پاسخِ خامِ سرویس (برای پشتیبانی)', 'farazsms' ); ?></summary>
					<pre dir="ltr"><?php echo esc_html( wp_json_encode( $result['raw'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) ); ?></pre>
				</details>
			<?php endif; ?>
		</div>
	<?php else : ?>
		<div class="farazsms-fb-thread">
			<?php foreach ( $result['messages'] as $msg ) : ?>
				<?php if ( $msg['type'] === 'system' ) : ?>
					<?php // رویدادِ سیستم (مثلِ «تیکت بسته شد») پیامِ گفت‌وگو نیست؛ نواری باریک و خنثی. ?>
					<div class="farazsms-fb-event">
						<span><?php echo esc_html( wp_strip_all_tags( $msg['text'] ) ); ?></span>
						<span class="farazsms-fb-date"><?php echo esc_html( farazsms_feedback_date( $msg['created'] ) ); ?></span>
					</div>
					<?php continue; ?>
				<?php endif; ?>
				<?php $support = ( $msg['type'] === 'answer' ); ?>
				<div class="farazsms-fb-msg<?php echo $support ? ' is-support' : ''; ?>">
					<div class="farazsms-fb-msg__meta">
						<strong>
							<?php
							if ( $support ) {
								echo esc_html(
									$msg['sender'] !== ''
										/* translators: %s: نام کارشناس پشتیبانی */
										? sprintf( __( 'پشتیبانی فراز — %s', 'farazsms' ), $msg['sender'] )
										: __( 'پشتیبانی فراز', 'farazsms' )
								);
							} else {
								echo esc_html( $msg['sender'] !== '' ? $msg['sender'] : __( 'شما', 'farazsms' ) );
							}
							?>
						</strong>
						<span class="farazsms-fb-date"><?php echo esc_html( farazsms_feedback_date( $msg['created'] ) ); ?></span>
					</div>
					<?php // متنِ تیکت در پنل HTML است (پاراگراف/لینک)؛ با esc_html خامِ تگ‌ها چاپ می‌شد. ?>
					<div class="farazsms-fb-msg__text"><?php echo wp_kses_post( $msg['text'] ); ?></div>
					<?php if ( ! empty( $msg['files'] ) && $msg['id'] !== '' ) : ?>
						<div class="farazsms-fb-msg__files">
							<?php foreach ( $msg['files'] as $file ) : ?>
								<a class="button button-small" href="<?php echo esc_url( farazsms_feedback_file_url( $msg['id'], $file['index'], $file['name'] ) ); ?>">
									📎 <?php echo esc_html( $file['name'] ); ?>
								</a>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>
				</div>
			<?php endforeach; ?>
		</div>
		<?php // دیدنِ پاسخِ خامِ سرویس برای عیب‌یابیِ پشتیبانی — فقط با افزودنِ raw=1 به نشانی. ?>
		<?php if ( ! empty( $_GET['raw'] ) && is_array( $result['raw'] ) ) : ?>
			<details class="farazsms-fb-card farazsms-fb-raw">
				<summary><?php esc_html_e( 'داده‌ی خامِ این گفت‌وگو (برای پشتیبانی)', 'farazsms' ); ?></summary>
				<pre dir="ltr"><?php echo esc_html( wp_json_encode( $result['raw'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT ) ); ?></pre>
			</details>
		<?php endif; ?>
	<?php endif; ?>

	<?php if ( $closed ) : ?>
		<div class="farazsms-fb-card farazsms-fb-card--closed">
			<?php esc_html_e( 'این گفت‌وگو بسته شده است. برای پیگیریِ جدید، از تبِ «ارسال بازخورد» پیامِ تازه بفرستید.', 'farazsms' ); ?>
		</div>
	<?php else : ?>
		<form method="post" action="<?php echo esc_url( $self ); ?>" class="farazsms-fb-card farazsms-fb-reply">
			<?php wp_nonce_field( 'farazsms_feedback_reply', 'farazsms_feedback_reply_nonce' ); ?>
			<input type="hidden" name="ticket_id" value="<?php echo esc_attr( $ticket_id ); ?>">
			<label class="farazsms-fb-reply__label"><?php esc_html_e( 'پاسخ شما', 'farazsms' ); ?></label>
			<textarea name="reply_text" rows="5" required dir="rtl" class="farazsms-fb-reply__text" placeholder="<?php esc_attr_e( 'پاسخ خود را بنویسید…', 'farazsms' ); ?>"></textarea>
			<div class="farazsms-fb-reply__actions">
				<button type="submit" name="farazsms_feedback_reply_submit" value="1" class="button button-primary">📨 <?php esc_html_e( 'ارسال پاسخ', 'farazsms' ); ?></button>
				<button type="submit" name="farazsms_feedback_close_submit" value="1" class="button" formnovalidate
					onclick="return confirm('<?php echo esc_js( __( 'این گفت‌وگو بسته شود؟', 'farazsms' ) ); ?>');">
					<?php esc_html_e( 'بستنِ گفت‌وگو', 'farazsms' ); ?>
				</button>
			</div>
			<?php wp_nonce_field( 'farazsms_feedback_close', 'farazsms_feedback_close_nonce' ); ?>
		</form>
	<?php endif; ?>
	<?php
}
