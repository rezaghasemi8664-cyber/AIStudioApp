<?php
/**
 * محاسبه‌ی خالصِ مبلغِ کش‌بک — جدا از منطقِ DB تا قابلِ تستِ واحد باشد.
 *
 * قاعده (همان رفتارِ قبلیِ farazsms_cashback_grant، فقط استخراج‌شده):
 *   - زیرِ حداقلِ سفارش → کش‌بکی تعلق نمی‌گیرد (۰).
 *   - مبلغ = round( paid × percent / 100 )، با percent محدود به ۰..۱۰۰.
 *   - سقفِ هر سفارش (در صورتِ مثبت‌بودن) اعمال می‌شود.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * @param float|int|string $paid_amount    مبلغِ پرداخت‌شده.
 * @param float|int|string $percent        درصدِ کش‌بک (۰..۱۰۰).
 * @param float|int|string $min_order      حداقلِ سفارش برای تعلقِ کش‌بک (۰ = بدونِ حداقل).
 * @param float|int|string $max_per_order  سقفِ کش‌بکِ هر سفارش (۰ = بدونِ سقف).
 * @return float مبلغِ کش‌بک؛ ۰.۰ یعنی کش‌بکی تعلق نمی‌گیرد.
 */
function farazsms_cashback_calc_amount( $paid_amount, $percent, $min_order = 0, $max_per_order = 0 ) {
	$paid_amount = (float) $paid_amount;
	if ( $paid_amount <= 0 ) {
		return 0.0;
	}

	$min_order = (float) $min_order;
	if ( $min_order > 0 && $paid_amount < $min_order ) {
		return 0.0;
	}

	$percent = max( 0, min( 100, (float) $percent ) );
	$amount  = round( $paid_amount * $percent / 100, 2 );

	$max_per_order = (float) $max_per_order;
	if ( $max_per_order > 0 && $amount > $max_per_order ) {
		$amount = $max_per_order;
	}

	return $amount > 0 ? $amount : 0.0;
}
