<?php
/**
 * SMS Invoice — v3.21.97
 *
 * فاکتورِ پیامکی: در پیامکِ سفارش یک لینکِ کوتاهِ توکن‌دار می‌رود؛ مشتری روی آن می‌زند و صفحه‌ی
 * فاکتورِ رسمیِ سفارش (اقلام، مبالغ، مالیات، اطلاعاتِ فروشگاه) با دکمه‌ی «چاپ / ذخیره‌ی PDF» باز
 * می‌شود — بدونِ نیاز به ورود (با توکنِ اختصاصیِ همان سفارش).
 *
 * متغیرِ پیامک: %invoice_url% (به متغیرهای پیامکِ سفارشات اضافه می‌شود).
 * صفحه به‌صورتِ مستقل رندر می‌شود (بدونِ قالبِ سایت) تا چاپ/PDF تمیز باشد.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

function farazsms_invoice_settings() {
	$d = array(
		'enabled'     => '1',
		'footer_note' => 'با تشکر از خرید شما 🌱',
		'show_logo'   => '1',
	);
	$s = get_option( 'farazsms_invoice_settings', array() );
	return array_merge( $d, is_array( $s ) ? $s : array() );
}

function farazsms_invoice_is_enabled() {
	$s = farazsms_invoice_settings();
	return $s['enabled'] === '1' && function_exists( 'wc_get_order' );
}

/** توکنِ اختصاصیِ فاکتورِ سفارش (ساختِ تنبل). */
function farazsms_invoice_token_for_order( $order ) {
	if ( ! $order instanceof WC_Order ) {
		return '';
	}
	$token = (string) $order->get_meta( '_farazsms_invoice_token', true );
	if ( $token === '' ) {
		$token = bin2hex( random_bytes( 16 ) );
		$order->update_meta_data( '_farazsms_invoice_token', $token );
		$order->save();
	}
	return $token;
}

/** لینکِ عمومیِ فاکتورِ یک سفارش. */
function farazsms_invoice_url( $order ) {
	if ( ! $order instanceof WC_Order ) {
		return '';
	}
	return add_query_arg(
		array(
			'farazsms_invoice' => $order->get_id(),
			'tok'              => farazsms_invoice_token_for_order( $order ),
		),
		home_url( '/' )
	);
}

// ── سِروِ صفحه‌ی فاکتور ────────────────────────────────────────────────────
add_action( 'template_redirect', 'farazsms_invoice_maybe_render', 1 );
function farazsms_invoice_maybe_render() {
	if ( empty( $_GET['farazsms_invoice'] ) || empty( $_GET['tok'] ) ) {
		return;
	}
	if ( ! farazsms_invoice_is_enabled() ) {
		return;
	}
	$order_id = (int) $_GET['farazsms_invoice'];
	$token    = sanitize_text_field( wp_unslash( $_GET['tok'] ) );
	$order = wc_get_order( $order_id );
	// v3.22.1: سفارشِ حذف‌شده (سطلِ زباله) فاکتور ندارد. همچنین برای بستنِ «oracleِ شمارشِ سفارش»،
	// چه سفارش نباشد چه توکن غلط باشد، یک پاسخِ ۴۰۴ِ یکسان می‌دهیم (تا با پیمایشِ IDها نتوان فهمید
	// کدام شناسه سفارشِ واقعی است).
	$not_found = ! $order instanceof WC_Order || $order->get_status() === 'trash';
	if ( ! $not_found ) {
		$expected = (string) $order->get_meta( '_farazsms_invoice_token', true );
		if ( $expected === '' || ! hash_equals( $expected, $token ) ) {
			$not_found = true;
		}
	}
	if ( $not_found ) {
		wp_die( 'فاکتور یافت نشد.', 'فاکتور', array( 'response' => 404 ) );
	}
	nocache_headers();
	farazsms_invoice_render_html( $order );
	exit;
}

/** قالبِ مبلغ (با واحدِ پولِ سایت). */
function farazsms_invoice_price( $amount ) {
	return farazsms_price_plain( $amount );
}

function farazsms_invoice_render_html( $order ) {
	$s        = farazsms_invoice_settings();
	$shop     = get_bloginfo( 'name' );
	$store    = trim( (string) get_option( 'woocommerce_store_address' ) . ' ' . (string) get_option( 'woocommerce_store_address_2' ) );
	$city     = (string) get_option( 'woocommerce_store_city' );
	$number   = method_exists( $order, 'get_order_number' ) ? $order->get_order_number() : $order->get_id();
	$created  = $order->get_date_created();
	$date_str = '';
	if ( $created ) {
		$mysql    = $created->date( 'Y-m-d H:i:s' );
		$date_str = farazsms_send_reports_to_jalali( $mysql );
	}
	$cust    = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
	$phone   = (string) $order->get_billing_phone();
	$address = trim( (string) $order->get_billing_address_1() . ' ' . (string) $order->get_billing_address_2() . '، ' . (string) $order->get_billing_city() );
	$logo    = '';
	if ( $s['show_logo'] === '1' && function_exists( 'get_custom_logo' ) && has_custom_logo() ) {
		$logo_id  = (int) get_theme_mod( 'custom_logo' );
		$logo_src = $logo_id ? wp_get_attachment_image_url( $logo_id, 'medium' ) : '';
		if ( $logo_src ) {
			$logo = '<img src="' . esc_url( $logo_src ) . '" alt="" style="max-height:64px;max-width:180px;">';
		}
	}
	$status_label = function_exists( 'wc_get_order_status_name' ) ? wc_get_order_status_name( $order->get_status() ) : $order->get_status();
	$first        = trim( (string) $order->get_billing_first_name() );

	// ردیابیِ ناشناسِ استفاده (فقط شمارش، بدونِ داده‌ی شخصی) — تا بسنجیم این قابلیت چقدر واقعاً استفاده
	// می‌شود و «آیا سرمایه‌گذاریِ بیشتر می‌ارزد؟». فقط اگر متمو فعال باشد و مدیر خاموشش نکرده باشد.
	$mtk_on   = function_exists( 'farazsms_matomo_is_enabled' ) && farazsms_matomo_is_enabled();
	$mtk_url  = ( $mtk_on && function_exists( 'farazsms_matomo_url' ) ) ? (string) farazsms_matomo_url() : '';
	$mtk_site = ( $mtk_on && function_exists( 'farazsms_matomo_site_id' ) ) ? (string) farazsms_matomo_site_id() : '';
	if ( $mtk_url === '' || $mtk_site === '' ) {
		$mtk_on = false;
	}
	?><!doctype html>
<html lang="fa" dir="rtl">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex,nofollow">
	<title><?php echo esc_html( 'فاکتور سفارش ' . $number . ' — ' . $shop ); ?></title>
	<style>
		*{box-sizing:border-box}
		body{font-family:Tahoma,Vazirmatn,"Segoe UI",sans-serif;background:#eef2f7;color:#1f2937;margin:0;padding:24px 12px;direction:rtl;line-height:1.9}
		.inv{max-width:760px;margin:0 auto;background:#fff;border:1px solid #e5e7eb;border-radius:14px;overflow:hidden}
		.inv-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;padding:22px 26px;border-bottom:2px solid #365891;flex-wrap:wrap}
		.inv-shop{font-size:19px;font-weight:800;color:#312e81}
		.inv-shop small{display:block;font-weight:400;color:#6b7280;font-size:12px;margin-top:4px}
		.inv-meta{text-align:left;font-size:12.5px;color:#475569}
		.inv-meta b{color:#111827}
		.inv-badge{display:inline-block;background:#eef2ff;color:#365891;border-radius:6px;padding:2px 10px;font-size:12px;font-weight:700;margin-top:4px}
		.inv-body{padding:22px 26px}
		.inv-cust{background:#f8fafc;border:1px solid #eef2f7;border-radius:10px;padding:12px 14px;font-size:13px;margin-bottom:18px}
		.inv-cust span{color:#6b7280}
		table{width:100%;border-collapse:collapse;font-size:13px}
		th,td{padding:10px 12px;text-align:right}
		thead th{background:#f1f5f9;color:#334155;font-size:12.5px;border-bottom:1px solid #e2e8f0}
		tbody td{border-bottom:1px solid #f1f5f9}
		tbody tr:last-child td{border-bottom:none}
		.num{font-variant-numeric:tabular-nums}
		.totals{margin-top:8px;margin-right:auto;max-width:320px}
		.totals .row{display:flex;justify-content:space-between;padding:6px 2px;font-size:13px}
		.totals .grand{border-top:2px solid #e2e8f0;margin-top:4px;padding-top:10px;font-size:15px;font-weight:800;color:#312e81}
		.inv-foot{padding:16px 26px;border-top:1px dashed #e5e7eb;color:#6b7280;font-size:12.5px;text-align:center}
		.bar{max-width:760px;margin:16px auto 0;display:flex;gap:10px;justify-content:center}
		.btn{border:none;border-radius:10px;padding:11px 22px;font-size:14px;font-weight:700;cursor:pointer;font-family:inherit}
		.btn-print{background:#365891;color:#fff}
		.btn-close{background:#e5e7eb;color:#374151;text-decoration:none;display:inline-flex;align-items:center}
		.inv-thanks{margin:18px 26px 0;background:linear-gradient(135deg,#ecfdf5,#eff6ff);border:1px solid #d1fae5;border-radius:12px;padding:12px 16px;font-size:14px;font-weight:700;color:#065f46;text-align:center}
		.bar-hint{max-width:760px;margin:8px auto 0;text-align:center;color:#94a3b8;font-size:11.5px;padding:0 14px;line-height:1.8}
		@media print{
			body{background:#fff;padding:0}
			.inv{border:none;border-radius:0;max-width:100%}
			.bar,.bar-hint{display:none}
			@page{margin:12mm}
		}
	</style>
</head>
<body>
	<div class="inv">
		<div class="inv-head">
			<div>
				<div class="inv-shop"><?php echo $logo ? $logo : esc_html( $shop ); ?>
					<?php if ( $logo ) : ?><small><?php echo esc_html( $shop ); ?></small><?php endif; ?>
					<small><?php echo esc_html( trim( $store . ' ' . $city, ' ' ) ); ?></small>
				</div>
			</div>
			<div class="inv-meta">
				<div>فاکتور فروش</div>
				<div>شماره سفارش: <b class="num"><?php echo esc_html( $number ); ?></b></div>
				<div>تاریخ: <b><?php echo esc_html( $date_str ); ?></b></div>
				<div class="inv-badge"><?php echo esc_html( $status_label ); ?></div>
			</div>
		</div>
		<?php if ( $first !== '' ) : ?>
			<div class="inv-thanks">ممنون از خریدت، <?php echo esc_html( $first ); ?> جان 🌿</div>
		<?php endif; ?>
		<div class="inv-body">
			<div class="inv-cust">
				<span>خریدار:</span> <b><?php echo esc_html( $cust ?: 'مشتری' ); ?></b>
				&nbsp;·&nbsp; <span>موبایل:</span> <b class="num" dir="ltr"><?php echo esc_html( $phone ); ?></b>
				<?php if ( trim( $address, '، ' ) !== '' ) : ?><br><span>نشانی:</span> <?php echo esc_html( $address ); ?><?php endif; ?>
			</div>

			<table>
				<thead>
					<tr><th>#</th><th>محصول</th><th>تعداد</th><th>مبلغ</th></tr>
				</thead>
				<tbody>
				<?php $i = 1; foreach ( $order->get_items() as $item ) : ?>
					<tr>
						<td class="num"><?php echo (int) $i; ?></td>
						<td><?php echo esc_html( $item->get_name() ); ?></td>
						<td class="num"><?php echo esc_html( $item->get_quantity() ); ?></td>
						<td class="num"><?php echo esc_html( farazsms_invoice_price( $item->get_total() ) ); ?></td>
					</tr>
				<?php $i++; endforeach; ?>
				</tbody>
			</table>

			<div class="totals">
				<div class="row"><span>جمع اقلام</span><span class="num"><?php echo esc_html( farazsms_invoice_price( $order->get_subtotal() ) ); ?></span></div>
				<?php if ( (float) $order->get_total_discount() > 0 ) : ?>
					<div class="row"><span>تخفیف</span><span class="num">− <?php echo esc_html( farazsms_invoice_price( $order->get_total_discount() ) ); ?></span></div>
				<?php endif; ?>
				<?php if ( (float) $order->get_shipping_total() > 0 ) : ?>
					<div class="row"><span>هزینه ارسال</span><span class="num"><?php echo esc_html( farazsms_invoice_price( $order->get_shipping_total() ) ); ?></span></div>
				<?php endif; ?>
				<?php if ( (float) $order->get_total_tax() > 0 ) : ?>
					<div class="row"><span>مالیات</span><span class="num"><?php echo esc_html( farazsms_invoice_price( $order->get_total_tax() ) ); ?></span></div>
				<?php endif; ?>
				<div class="row grand"><span>مبلغ کل</span><span class="num"><?php echo esc_html( farazsms_invoice_price( $order->get_total() ) ); ?></span></div>
			</div>
		</div>
		<?php if ( trim( (string) $s['footer_note'] ) !== '' ) : ?>
			<div class="inv-foot"><?php echo esc_html( $s['footer_note'] ); ?></div>
		<?php endif; ?>
	</div>
	<div class="bar">
		<button class="btn btn-print" id="fz-inv-dl" onclick="fzInvDownload()">📥 دانلود فاکتور (PDF)</button>
		<a class="btn btn-close" href="<?php echo esc_url( home_url( '/' ) ); ?>">بازگشت به سایت</a>
	</div>
	<p class="bar-hint">روی موبایل: در پنجره‌ی بازشده گزینه‌ی «ذخیره به PDF» / «Save as PDF» را انتخاب کنید تا فاکتور روی گوشی‌تان ذخیره شود.</p>
	<script>
	function fzInvDownload(){
		try { if ( window._paq ) { _paq.push(['trackEvent','FarazSMS Invoice','download']); } } catch(e){}
		window.print();
	}
	</script>
	<?php if ( $mtk_on ) : ?>
	<!-- سنجشِ ناشناسِ استفاده (بدونِ داده‌ی شخصی) — async و غیرمسدودکننده -->
	<script>
	var _paq = window._paq = window._paq || [];
	_paq.push(['setTrackerUrl', <?php echo wp_json_encode( $mtk_url . 'matomo.php' ); ?>]);
	_paq.push(['setSiteId', <?php echo wp_json_encode( $mtk_site ); ?>]);
	// مهم (امنیت/حریمِ خصوصی): URLِ این صفحه شاملِ توکنِ مخفیِ فاکتور و عنوانش شاملِ شماره‌ی سفارش است.
	// پیش‌فرضِ متمو کلِ URL و عنوان را می‌فرستد → توکن/سفارش لو می‌رود. پس آدرس/عنوان/ارجاع را ناشناس می‌کنیم
	// تا فقط یک شمارشِ کاملاً بی‌هویت ثبت شود.
	_paq.push(['setCustomUrl', '/farazsms-invoice']);
	_paq.push(['setDocumentTitle', 'FarazSMS Invoice']);
	_paq.push(['setReferrerUrl', '']);
	_paq.push(['trackEvent','FarazSMS Invoice','view']);
	(function(){ var d=document,g=d.createElement('script'),s=d.getElementsByTagName('script')[0];
		g.async=true; g.onerror=function(){}; g.src=<?php echo wp_json_encode( $mtk_url . 'matomo.js' ); ?>; s.parentNode.insertBefore(g,s); })();
	</script>
	<?php endif; ?>
</body>
</html>
	<?php
}

// ── تنظیماتِ ادمین ────────────────────────────────────────────────────────
add_action( 'admin_menu', 'farazsms_invoice_menu', 61 );
function farazsms_invoice_menu() {
	// زیرِ منوی افزونه.
	add_submenu_page(
		'farazsms',
		'فاکتور پیامکی',
		'🧾 فاکتور پیامکی',
		'manage_options',
		'farazsms-invoice',
		'farazsms_invoice_render_page'
	);
	// v3.22.110: زیرمنوی «فاکتور پیامکی» از منوی ووکامرس حذف شد (به‌درخواستِ کاربر — شلوغیِ
	// منوی ووکامرس). صفحه همچنان از منوی خودِ افزونه در دسترس است.
}

add_action( 'admin_post_farazsms_invoice_save', 'farazsms_invoice_handle_save' );
function farazsms_invoice_handle_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die();
	}
	check_admin_referer( 'farazsms_invoice_save' );
	$s = farazsms_invoice_settings();
	$s['enabled']     = isset( $_POST['invoice_enabled'] ) ? '1' : '0';
	$s['show_logo']   = isset( $_POST['invoice_show_logo'] ) ? '1' : '0';
	$s['footer_note'] = sanitize_text_field( wp_unslash( $_POST['invoice_footer_note'] ?? '' ) );
	update_option( 'farazsms_invoice_settings', $s, false );
	wp_safe_redirect( add_query_arg( 'saved', '1', admin_url( 'admin.php?page=farazsms-invoice' ) ) );
	exit;
}

function farazsms_invoice_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی غیرمجاز.' );
	}
	$s = farazsms_invoice_settings();
	?>
	<div class="wrap" style="direction:rtl;max-width:820px;">
		<h1 style="font-size:21px;">🧾 فاکتور پیامکی</h1>
		<?php if ( isset( $_GET['saved'] ) ) : ?>
			<div style="background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46;padding:10px 14px;border-radius:8px;margin:10px 0;">✓ ذخیره شد.</div>
		<?php endif; ?>
		<p style="color:#64748b;font-size:13.5px;line-height:1.9;max-width:60ch;">در پیامکِ سفارش یک لینکِ کوتاهِ امن می‌رود؛ مشتری روی آن می‌زند و فاکتورِ رسمیِ سفارشش را — <b>بدونِ نیاز به ورود</b> — می‌بیند و می‌تواند چاپ یا به‌صورتِ PDF ذخیره کند.</p>

		<!-- جریان کار -->
		<h2 style="font-size:15px;color:#0f172a;margin:22px 0 10px;">چطور کار می‌کند؟</h2>
		<div style="display:flex;gap:12px;flex-wrap:wrap;">
			<?php
			$flow = array(
				array( '۱', 'پیامکِ سفارش با لینک', 'اگر متنِ پیامکِ سفارش شاملِ متغیرِ %invoice_url% باشد، افزونه یک لینکِ کوتاهِ توکن‌دارِ همان سفارش می‌سازد.' ),
				array( '۲', 'مشتری کلیک می‌کند', 'لینک به آدرسِ سایتِ شما با شناسه‌ی سفارش و یک توکنِ مخفی می‌رود. بدونِ توکنِ درست، فاکتور دیده نمی‌شود.' ),
				array( '۳', 'صفحه‌ی فاکتور باز می‌شود', 'فاکتورِ رسمی (اقلام، مبالغ، مالیات، اطلاعاتِ فروشگاه) با دکمه‌ی چاپ/PDF نمایش داده می‌شود — بدونِ قالبِ سایت و بدونِ ورود.' ),
			);
			foreach ( $flow as $f ) : ?>
				<div style="flex:1 1 220px;background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:15px 16px;">
					<div style="width:28px;height:28px;border-radius:8px;background:#365891;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:14px;margin-bottom:8px;"><?php echo esc_html( $f[0] ); ?></div>
					<div style="font-weight:800;font-size:14px;color:#111827;margin-bottom:4px;"><?php echo esc_html( $f[1] ); ?></div>
					<div style="font-size:12.5px;color:#64748b;line-height:1.85;"><?php echo esc_html( $f[2] ); ?></div>
				</div>
			<?php endforeach; ?>
		</div>

		<!-- قدمِ کلیدی -->
		<div style="background:#fff;border:2px solid #365891;border-radius:12px;padding:16px 18px;margin-top:18px;">
			<div style="font-weight:800;font-size:15px;color:#312e81;margin-bottom:6px;">⭐ مهم‌ترین قدم برای فعال‌شدن</div>
			<p style="margin:0 0 8px;font-size:13.5px;color:#334155;line-height:1.95;">این قابلیت به‌صورتِ پیش‌فرض روشن است، ولی <b>به‌تنهایی هیچ کاری نمی‌کند</b>. باید متغیرِ <code dir="ltr">%invoice_url%</code> را در <b>متنِ پیامکِ سفارشات</b> بگذارید و پترن را بسازید (تا فراز آن را تأیید کند). نمونه:</p>
			<code dir="ltr" style="display:block;background:#eef2ff;color:#263f67;padding:10px 12px;border-radius:8px;font-size:12.5px;line-height:1.9;text-align:left;">سفارش %order_id% ثبت شد. مبلغ: %total%.
مشاهده‌ی فاکتور: %invoice_url%</code>
			<p style="margin:8px 0 0;font-size:12px;color:#64748b;">اطلاعاتِ فروشگاه (نام/نشانی) از «ووکامرس ← تنظیمات» و لوگو از قالب خوانده می‌شود.</p>
		</div>

		<!-- فرم تنظیمات -->
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="background:#fff;border:1px solid #e5e7eb;border-radius:12px;padding:20px;margin-top:18px;">
			<input type="hidden" name="action" value="farazsms_invoice_save">
			<?php wp_nonce_field( 'farazsms_invoice_save' ); ?>

			<label style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
				<input type="checkbox" class="farazsms-toggle" name="invoice_enabled" value="1" <?php checked( $s['enabled'], '1' ); ?> style="width:18px;height:18px;">
				<span style="font-weight:700;">فعال بودنِ فاکتور پیامکی</span>
			</label>
			<label style="display:flex;align-items:center;gap:10px;margin-bottom:14px;">
				<input type="checkbox" class="farazsms-toggle" name="invoice_show_logo" value="1" <?php checked( $s['show_logo'], '1' ); ?> style="width:18px;height:18px;">
				<span style="font-weight:600;">نمایشِ لوگوی سایت در فاکتور</span>
			</label>
			<p><label style="display:block;font-size:12.5px;font-weight:600;margin-bottom:4px;">یادداشتِ پایینِ فاکتور</label>
			<input type="text" name="invoice_footer_note" value="<?php echo esc_attr( $s['footer_note'] ); ?>" style="width:100%;max-width:420px;padding:9px 12px;border:1px solid #cbd5e1;border-radius:7px;"></p>

			<button type="submit" class="button button-primary" style="padding:8px 26px;">💾 ذخیره</button>
		</form>

		<!-- چرا کار نمی‌کند + تست -->
		<h2 style="font-size:15px;color:#0f172a;margin:24px 0 10px;">لینکِ فاکتور در پیامک نیست؟</h2>
		<div style="background:#fff7ed;border:1px solid #fed7aa;color:#9a3412;padding:14px 16px;border-radius:10px;font-size:13px;line-height:2;">
			به‌ترتیبِ احتمال بررسی کنید:
			<ol style="margin:8px 0 0;padding-inline-start:20px;">
				<li><b>متغیرِ <code dir="ltr" style="background:#fff;padding:1px 5px;border-radius:4px;">%invoice_url%</code> در متنِ پیامکِ سفارش نیست</b> (محتمل‌ترین) → قدمِ کلیدیِ بالا را انجام دهید.</li>
				<li>پترنِ حاویِ این متغیر ساخته/تأیید نشده → پترن را دوباره بسازید و منتظرِ تأییدِ فراز بمانید.</li>
				<li>خودِ پیامکِ آن وضعیتِ سفارش خاموش است یا ارسال نمی‌شود → لینک هم که داخلِ همان پیامک است نمی‌رود.</li>
				<li>ووکامرس غیرفعال است.</li>
			</ol>
		</div>
		<div style="background:#f8fafc;border:1px dashed #cbd5e1;border-radius:10px;padding:14px 16px;margin-top:12px;font-size:13px;line-height:1.95;color:#334155;">
			<b style="color:#312e81;">تستِ سریع:</b> یک سفارشِ تستی بزنید (یا وضعیتِ یک سفارش را عوض کنید تا پیامک برود) → پیامکِ رسیده باید یک <b>لینک</b> داشته باشد → روی لینک بزنید، باید صفحه‌ی فاکتور باز شود. اگر «فاکتور یافت نشد» دیدید، توکن/لینک ناقص است؛ اگر اصلاً باز نشد، افزونه‌ی کش/امنیتیِ سایت ممکن است پارامترِ لینک را حذف کند.
		</div>
	</div>
	<?php
}
