<?php
/**
 * دروازهٔ تداخلِ افزونه‌های پیامکی.
 *
 * سیاست: فراز اس‌ام‌اس هم‌زمان با افزونه‌های آن سرویسِ پیامکیِ خاص کار نمی‌کند.
 * تا وقتی چنین افزونه‌ای فعال باشد، تنظیماتِ فراز اس‌ام‌اس در دسترس نیست و مدیر
 * باید یکی از دو مسیر را انتخاب کند.
 *
 * ⚠️ چرا تشخیص از روی «شناسه‌ی افزونه» است و نه محتوای کد (دو دلیلِ قاطع):
 *
 *   ۱) آن افزونه‌ها سورسشان را encode می‌کنند؛ اسکنِ محتوا هیچ‌چیز پیدا نمی‌کند.
 *      ولی **هدرِ افزونه هرگز encode نمی‌شود** — وردپرس باید بتواند آن را به‌صورتِ
 *      متنِ ساده بخواند تا افزونه را بشناسد. پس شناسه همیشه خواناست.
 *
 *   ۲) بسیاری از افزونه‌های پرکاربردِ عمومی (مثلِ افزونه‌های پیامکیِ چنددرگاهی)
 *      یک فایلِ درگاه برای آن سرویس دارند، در حالی که مدیر می‌خواهد از درگاهِ ما
 *      استفاده کند. اسکنِ محتوا آن‌ها را هم قفل می‌کرد — یعنی مجازاتِ کسی که
 *      اصلاً تداخلی ندارد.
 *
 * شناسه = مسیرِ افزونه + نام + توسعه‌دهنده + نشانیِ توسعه‌دهنده/افزونه + دامنه‌ی متن.
 * توضیحاتِ افزونه عمداً بررسی نمی‌شود (اشاره‌ی صرف، تداخل نیست).
 *
 * این فایل از مسیرِ farazsms_require_protected() بارگذاری می‌شود تا در بیلدهای
 * encode-شده جزوِ فایل‌های محافظت‌شده باشد.
 *
 * کارایی: فقط در پیشخوان، فقط خواندنِ هدر (بدونِ پیمایشِ فایل‌سیستم)، و نتیجه تا
 * تغییرِ فهرستِ افزونه‌های فعال کش می‌شود.
 *
 * @package farazsms
 */


if ( ! defined( 'WPINC' ) ) {
	die;
}

/** نشانه‌ی شناسه‌ای. تنها جایی است که این نام در افزونه باقی مانده. */
const FARAZSMS_CONFLICT_NEEDLE = 'ippanel';

const FARAZSMS_CONFLICT_CACHE_OPT = 'farazsms_conflict_scan';
const FARAZSMS_CONFLICT_PAGE      = 'farazsms-conflict';

// ============================================================================
// اسکن
// ============================================================================

/**
 * امضای فهرستِ افزونه‌های فعال — تا اسکن فقط با تغییرِ این فهرست تکرار شود.
 *
 * @return string
 */
function farazsms_conflict_signature() {
	$active = (array) get_option( 'active_plugins', array() );
	if ( is_multisite() ) {
		$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
	}
	sort( $active );
	// فیلترِ استثنا هم بخشی از ورودیِ نتیجه است؛ اگر در امضا نباشد، افزودنِ استثنا
	// کش را باطل نمی‌کند و سایت تا فعال/غیرفعال‌سازیِ یک افزونه قفل می‌ماند.
	$ignore = (array) apply_filters( 'farazsms_conflict_ignore_plugins', array() );
	sort( $ignore );
	return md5( implode( '|', $active ) . '#' . implode( '|', $ignore ) );
}

/**
 * آیا این مجموعه فیلدِ شناسه‌ای متعلق به آن سرویس است؟
 *
 * تابعِ خالص (آرایه‌ی رشته → bool) تا قابلِ تست باشد.
 *
 * @param array $fields
 * @return bool
 */
function farazsms_conflict_identity_matches( $fields ) {
	$haystack = '';
	foreach ( (array) $fields as $value ) {
		if ( is_scalar( $value ) ) {
			$haystack .= ' ' . (string) $value;
		}
	}
	return stripos( $haystack, FARAZSMS_CONFLICT_NEEDLE ) !== false;
}

/**
 * اسکنِ کاملِ افزونه‌های فعال.
 *
 * @return array نگاشتِ basename → نامِ افزونه
 */
function farazsms_conflict_scan() {
	if ( ! function_exists( 'get_plugin_data' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	$active = (array) get_option( 'active_plugins', array() );
	if ( is_multisite() ) {
		$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
	}

	$self   = defined( 'FARAZSMS_PLUGIN_FILE' ) ? plugin_basename( FARAZSMS_PLUGIN_FILE ) : '';
	// شیرِ اطمینانِ پشتیبانی: اگر روزی افزونه‌ای به‌اشتباه شناسایی شد، بدونِ تغییرِ
	// کد قابلِ استثنا کردن است.
	$ignore = (array) apply_filters( 'farazsms_conflict_ignore_plugins', array() );
	$found  = array();

	foreach ( array_unique( $active ) as $basename ) {
		if ( $basename === $self || in_array( $basename, $ignore, true ) ) {
			continue;
		}
		$file = WP_PLUGIN_DIR . '/' . $basename;
		if ( ! file_exists( $file ) ) {
			continue;
		}
		$data = get_plugin_data( $file, false, false );

		// فقط فیلدهای «هویتی». توضیحاتِ افزونه عمداً نیست: افزونه‌ای که در
		// توضیحش از پشتیبانی از آن سرویس نوشته، خودش آن افزونه نیست.
		$identity = array(
			$basename,
			$data['Name'] ?? '',
			$data['Author'] ?? '',
			$data['AuthorURI'] ?? '',
			$data['PluginURI'] ?? '',
			$data['TextDomain'] ?? '',
		);
		if ( ! farazsms_conflict_identity_matches( $identity ) ) {
			continue;
		}
		$name = ! empty( $data['Name'] ) ? (string) $data['Name'] : dirname( $basename );
		$found[ $basename ] = $name;
	}
	return $found;
}

/**
 * نتیجه‌ی کش‌شده‌ی اسکن.
 *
 * @param bool $force اسکنِ دوباره حتی اگر امضا عوض نشده باشد
 * @return array
 */
function farazsms_conflict_found( $force = false ) {
	$sig    = farazsms_conflict_signature();
	$cached = get_option( FARAZSMS_CONFLICT_CACHE_OPT, array() );

	if ( ! $force && is_array( $cached ) && isset( $cached['sig'] ) && $cached['sig'] === $sig ) {
		return isset( $cached['found'] ) && is_array( $cached['found'] ) ? $cached['found'] : array();
	}
	$found = farazsms_conflict_scan();
	update_option( FARAZSMS_CONFLICT_CACHE_OPT, array( 'sig' => $sig, 'found' => $found ), false );
	return $found;
}

/**
 * آیا تداخل وجود دارد؟ (فقط در پیشخوان معنا دارد.)
 *
 * @return bool
 */
function farazsms_conflict_exists() {
	if ( ! is_admin() ) {
		return false;
	}
	return ! empty( farazsms_conflict_found() );
}

// ============================================================================
// مسدودسازیِ صفحاتِ افزونه
// ============================================================================

add_filter( 'farazsms_sidebar_visible_slugs', 'farazsms_conflict_whitelist_slug' );
/**
 * صفحه‌ی رفعِ تداخل باید در سایدبارِ وردپرس دیده شود.
 *
 * سایدبار فقط اسلاگ‌های فهرستِ سفید را نشان می‌دهد و بقیه را با CSS پنهان می‌کند؛
 * بدونِ این، در همان حالتی که تنها راهِ نجات همین صفحه است، زیرمنو خالی می‌شد.
 *
 * @param array $slugs
 * @return array
 */
function farazsms_conflict_whitelist_slug( $slugs ) {
	$slugs[] = FARAZSMS_CONFLICT_PAGE;
	return $slugs;
}

// ── کلیدِ کش باید فیلترِ استثنا را هم بپوشاند، وگرنه «شیرِ اطمینان» کار نمی‌کند ──
add_action( 'admin_menu', 'farazsms_conflict_take_over_menu', 9999 );
/**
 * وقتی تداخل هست، همه‌ی زیرمنوهای افزونه برداشته و یک صفحه‌ی «رفعِ تداخل»
 * جایگزین می‌شود. منویِ اصلی می‌ماند تا مدیر گم نشود.
 */
function farazsms_conflict_take_over_menu() {
	if ( ! farazsms_conflict_exists() ) {
		return;
	}
	global $submenu;
	if ( isset( $submenu['farazsms'] ) && is_array( $submenu['farazsms'] ) ) {
		foreach ( $submenu['farazsms'] as $item ) {
			if ( isset( $item[2] ) ) {
				remove_submenu_page( 'farazsms', $item[2] );
			}
		}
	}
	add_submenu_page(
		'farazsms',
		__( 'رفع تداخل', 'farazsms' ),
		__( 'رفع تداخل', 'farazsms' ),
		'manage_options',
		FARAZSMS_CONFLICT_PAGE,
		'farazsms_conflict_render_page'
	);
}

add_action( 'admin_init', 'farazsms_conflict_block_direct_access', 1 );
/**
 * دسترسیِ مستقیم با URL هم بسته می‌شود — وگرنه برداشتنِ منو فقط پنهان‌کاری بود.
 */
function farazsms_conflict_block_direct_access() {
	if ( wp_doing_ajax() ) {
		return;
	}
	// ابتدا ارزان‌ترین بررسی: اصلاً صفحه‌ی افزونه است؟ (این هوک روی *هر* صفحه‌ی
	// پیشخوان اجرا می‌شود؛ خواندنِ آپشنِ اسکن نباید هزینه‌ی همیشگی داشته باشد.)
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	if ( $page === '' || $page === FARAZSMS_CONFLICT_PAGE ) {
		return;
	}
	// صفحه‌ی فیدهای المنتور اسلاگش با farazsms شروع نمی‌شود ولی صفحه‌ی همین افزونه است.
	$ours = ( strpos( $page, 'farazsms' ) === 0 ) || ( strpos( $page, 'fwss' ) === 0 ) || strpos( $page, 'farazsms' ) !== false;
	if ( ! $ours ) {
		return;
	}
	if ( ! farazsms_conflict_exists() ) {
		return;
	}
	wp_safe_redirect( admin_url( 'admin.php?page=' . FARAZSMS_CONFLICT_PAGE ) );
	exit;
}

// ============================================================================
// اعلان و صفحه
// ============================================================================

add_action( 'admin_notices', 'farazsms_conflict_admin_notice' );
function farazsms_conflict_admin_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	$found = farazsms_conflict_found();
	if ( empty( $found ) ) {
		return;
	}
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( $screen && isset( $_GET['page'] ) && sanitize_key( wp_unslash( $_GET['page'] ) ) === FARAZSMS_CONFLICT_PAGE ) {
		return; // در خودِ صفحه‌ی تداخل تکرار نشود.
	}
	?>
	<div class="notice notice-error">
		<p style="font-size:14px;font-weight:700;margin:8px 0 6px">تداخلِ افزونه‌های پیامکی — تنظیماتِ فراز اس‌ام‌اس در دسترس نیست</p>
		<p style="line-height:2;margin:0 0 10px">
			<?php echo esc_html( farazsms_conflict_message() ); ?>
		</p>
		<p style="margin:0 0 10px">
			<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=' . FARAZSMS_CONFLICT_PAGE ) ); ?>">مشاهده و رفعِ تداخل</a>
		</p>
	</div>
	<?php
}

/**
 * متنِ توضیح.
 *
 * عمداً فقط دو چیز می‌گوید: یک واقعیتِ فنیِ قابلِ‌بررسی (اجرای هم‌زمانِ دو افزونهٔ
 * پیامکی تداخل می‌سازد) و یک محدودیتِ خودمان (در این حالت درستیِ عملکردِ خودمان
 * را تضمین نمی‌کنیم). هیچ ادعایی دربارهٔ محصول، شرکت یا مالکیتِ شخصِ ثالث
 * نمی‌کند و هیچ نامِ تجاری‌ای را قضاوت نمی‌کند.
 *
 * @return string
 */
function farazsms_conflict_message() {
	return 'روی این سایت افزونهٔ پیامکیِ دیگری فعال است که به وب‌سرویسِ نسلِ قبل درخواست می‌فرستد. '
		. 'اجرای هم‌زمانِ دو افزونهٔ پیامکی روی یک وردپرس باعثِ ثبتِ هوک‌های تکراری، ارسالِ دوبارهٔ پیامک و ناسازگاریِ تنظیمات می‌شود؛ '
		. 'در این حالت فراز اس‌ام‌اس نمی‌تواند درستیِ عملکردِ خود را تضمین کند. '
		. 'برای استفاده از فراز اس‌ام‌اس، افزونهٔ زیر را غیرفعال یا حذف کنید.';
}

function farazsms_conflict_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$found = farazsms_conflict_found( isset( $_GET['farazsms_rescan'] ) );
	?>
	<div class="wrap" dir="rtl">
		<h1>تداخلِ افزونه‌های پیامکی</h1>

		<?php if ( empty( $found ) ) : ?>
			<div class="notice notice-success"><p>
				تداخلی یافت نشد. صفحهٔ افزونه را دوباره باز کنید — تنظیمات در دسترس است.
			</p></div>
			<p><a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-dashboard' ) ); ?>">رفتن به داشبورد</a></p>
			</div>
			<?php return; ?>
		<?php endif; ?>

		<div class="farazsms-int-intro" style="max-width:900px">
			<?php echo esc_html( farazsms_conflict_message() ); ?>
		</div>

		<table class="widefat striped" style="max-width:900px">
			<thead><tr><th>افزونهٔ دارای تداخل</th><th style="width:200px">عملیات</th></tr></thead>
			<tbody>
			<?php foreach ( $found as $basename => $name ) :
				$deactivate = wp_nonce_url(
					self_admin_url( 'plugins.php?action=deactivate&plugin=' . rawurlencode( $basename ) ),
					'deactivate-plugin_' . $basename
				);
				?>
				<tr>
					<td><strong><?php echo esc_html( $name ); ?></strong></td>
					<td><a class="button button-primary" href="<?php echo esc_url( $deactivate ); ?>">غیرفعال‌سازی</a></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>

		<p style="margin-top:16px">
			<a class="button" href="<?php echo esc_url( add_query_arg( 'farazsms_rescan', '1' ) ); ?>">🔄 بررسیِ دوباره</a>
			<a class="button" href="<?php echo esc_url( self_admin_url( 'plugins.php' ) ); ?>">رفتن به فهرستِ افزونه‌ها</a>
		</p>

		<p style="color:#888;font-size:12px;line-height:2;max-width:900px;margin-top:14px">
			ارسالِ پیامک‌های جاری (مثلِ پیامکِ سفارش) متوقف نشده است؛ فقط تنظیماتِ افزونه تا رفعِ تداخل بسته است.
			پس از غیرفعال‌سازی، این صفحه به‌صورتِ خودکار باز می‌شود.
		</p>
	</div>
	<?php
}

// اسکن پس از هر فعال/غیرفعال‌سازیِ افزونه دوباره انجام می‌شود (امضا عوض می‌شود)،
// ولی برای اطمینان، کشِ اسکن را صریح هم پاک می‌کنیم.
add_action( 'activated_plugin', 'farazsms_conflict_flush_cache' );
add_action( 'deactivated_plugin', 'farazsms_conflict_flush_cache' );
function farazsms_conflict_flush_cache() {
	delete_option( FARAZSMS_CONFLICT_CACHE_OPT );
}
