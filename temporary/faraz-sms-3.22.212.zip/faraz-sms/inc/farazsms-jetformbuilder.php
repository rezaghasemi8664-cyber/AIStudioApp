<?php
/**
 * یکپارچه‌سازی با JetFormBuilder — ارسالِ پیامکِ پترن پس از ثبتِ فرم.
 *
 * MVP خودبسنده: فقط وقتی JetFormBuilder فعال است بار می‌شود. مدیر برای هر فرم یک «قانون»
 * تعریف می‌کند (شناسه‌ی فرم، فیلدِ موبایلِ کاربر، کدِ پترن، متنِ پیامک با {فیلد}ها، شماره‌ی مدیر).
 * هنگامِ ثبتِ فرم، پیامک با پترن به کاربر و/یا مدیر می‌رود. کلِ مسیر در try/catch است تا
 * هرگز ثبتِ فرم را نشکند.
 *
 * توجه: چون نسخه‌های مختلفِ JetFormBuilder API کمی فرق دارند، خواندنِ form_id و داده‌ها
 * با چند fallback انجام می‌شود. روی سایتِ خودتان تست کنید و در صورتِ نیاز خبر دهید.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

function farazsms_jfb_is_active() {
	return class_exists( '\Jet_Form_Builder\Plugin' ) || function_exists( 'jet_form_builder' ) || function_exists( 'jet_fb_request_handler' );
}

const FARAZSMS_JFB_OPTION = 'farazsms_jfb_rules';

/**
 * قانون‌ها: آرایه‌ای از rule (form_id, phone_field, pattern_code, message, admin_phone, enabled).
 */
function farazsms_jfb_get_rules() {
	$r = get_option( FARAZSMS_JFB_OPTION, array() );
	return is_array( $r ) ? $r : array();
}

// ============================================================================
// هوکِ ثبتِ فرم — ارسالِ پیامک (fail-open)
// ============================================================================

add_action( 'jet-form-builder/form-handler/after-send', 'farazsms_jfb_on_submit', 100, 1 );
function farazsms_jfb_on_submit( $handler = null ) {
	try {
		// form_id + دادهٔ فرم را با چند fallback می‌خوانیم (سازگاری با نسخه‌های JFB).
		$form_id = 0;
		$data    = array();
		if ( is_object( $handler ) ) {
			if ( method_exists( $handler, 'get_form_id' ) ) {
				$form_id = (int) $handler->get_form_id();
			}
			if ( isset( $handler->request_data ) && is_array( $handler->request_data ) ) {
				$data = $handler->request_data;
			}
		}
		if ( empty( $data ) && function_exists( 'jet_fb_request_handler' ) ) {
			$req = jet_fb_request_handler();
			if ( $req && method_exists( $req, 'get_request' ) ) {
				$data = (array) $req->get_request();
			}
		}
		if ( ! $form_id && function_exists( 'jet_fb_handler' ) ) {
			$h = jet_fb_handler();
			if ( $h && method_exists( $h, 'get_form_id' ) ) {
				$form_id = (int) $h->get_form_id();
			}
		}
		if ( ! $form_id ) {
			return;
		}

		$sender = farazsms_cfg_sender();

		foreach ( farazsms_jfb_get_rules() as $rule ) {
			if ( empty( $rule['enabled'] ) || (int) ( $rule['form_id'] ?? 0 ) !== $form_id ) {
				continue;
			}
			$pattern = trim( (string) ( $rule['pattern_code'] ?? '' ) );
			if ( $pattern === '' ) {
				continue;
			}
			$message = (string) ( $rule['message'] ?? '' );

			// متغیرهای پترن از روی {field}های متن — مقدارشان از دادهٔ فرم.
			$attrs = array();
			if ( preg_match_all( '/[{%]([a-zA-Z0-9_]+)[}%]/', $message, $m ) ) {
				foreach ( array_unique( $m[1] ) as $key ) {
					$attrs[ $key ] = isset( $data[ $key ] ) ? (string) ( is_array( $data[ $key ] ) ? implode( ', ', $data[ $key ] ) : $data[ $key ] ) : '';
				}
			}

			// گیرنده‌ی کاربر: مقدارِ فیلدِ موبایل.
			$phone_field = trim( (string) ( $rule['phone_field'] ?? '' ) );
			$user_phone  = ( $phone_field !== '' && isset( $data[ $phone_field ] ) ) ? (string) $data[ $phone_field ] : '';
			if ( $user_phone !== '' ) {
				$user_phone = farazsms_normalize_phone( $user_phone );
				farazsms_queue_send( 'jetformbuilder', $user_phone, $pattern, $attrs, array( 'to' => 'user' ), $sender );
			}

			// گیرنده‌ی مدیر (اختیاری، می‌تواند چند شماره با کاما باشد).
			$admin_phones = trim( (string) ( $rule['admin_phone'] ?? '' ) );
			if ( $admin_phones !== '' ) {
				foreach ( preg_split( '/[\s,،]+/u', $admin_phones ) as $ap ) {
					$ap = trim( $ap );
					if ( $ap === '' ) {
						continue;
					}
					$ap = farazsms_normalize_phone( $ap );
					farazsms_queue_send( 'jetformbuilder', $ap, $pattern, $attrs, array( 'to' => 'admin' ), $sender );
				}
			}
		}
	} catch ( \Throwable $e ) {
		error_log( 'farazsms JetFormBuilder send failed: ' . $e->getMessage() );
	}
}

// ============================================================================
// صفحه‌ی تنظیمات (فقط وقتی JFB فعال است)
// ============================================================================

add_action( 'admin_menu', 'farazsms_jfb_register_submenu', 990 );
function farazsms_jfb_register_submenu() {
	if ( ! farazsms_jfb_is_active() ) {
		return;
	}
	add_submenu_page(
		'farazsms',
		__( 'JetFormBuilder', 'farazsms' ),
		__( 'JetFormBuilder', 'farazsms' ),
		'manage_options',
		'farazsms-jetformbuilder',
		'farazsms_jfb_render_page'
	);
}

function farazsms_jfb_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	if ( isset( $_POST['farazsms_jfb_submit'] ) && check_admin_referer( 'farazsms_jfb_save', 'farazsms_jfb_nonce' ) ) {
		$rules   = array();
		$ids     = isset( $_POST['rule_form_id'] ) && is_array( $_POST['rule_form_id'] ) ? $_POST['rule_form_id'] : array();
		$count   = count( $ids );
		for ( $i = 0; $i < $count; $i++ ) {
			$fid = (int) ( $ids[ $i ] ?? 0 );
			if ( $fid <= 0 ) {
				continue;
			}
			$rules[] = array(
				'enabled'      => ! empty( $_POST['rule_enabled'][ $i ] ) ? '1' : '0',
				'form_id'      => $fid,
				'phone_field'  => sanitize_text_field( wp_unslash( $_POST['rule_phone_field'][ $i ] ?? '' ) ),
				'pattern_code' => sanitize_text_field( wp_unslash( $_POST['rule_pattern_code'][ $i ] ?? '' ) ),
				'admin_phone'  => sanitize_text_field( wp_unslash( $_POST['rule_admin_phone'][ $i ] ?? '' ) ),
				'message'      => farazsms_sanitize_pattern_text( $_POST['rule_message'][ $i ] ?? '' ),
			);
		}
		update_option( FARAZSMS_JFB_OPTION, $rules, false );
		echo '<div class="notice notice-success"><p>قوانینِ JetFormBuilder ذخیره شد.</p></div>';
	}

	$rules = farazsms_jfb_get_rules();
	// یک ردیفِ خالی برای افزودنِ قانونِ جدید.
	$rules[] = array( 'enabled' => '1', 'form_id' => '', 'phone_field' => '', 'pattern_code' => '', 'admin_phone' => '', 'message' => '' );
	?>
	<div class="wrap" style="direction:rtl; max-width:900px;">
		<h1 style="font-size:20px;">🧩 ارسال پیامک با JetFormBuilder</h1>
		<p style="font-size:13px; color:#4d4d4d; line-height:2;">
			برای هر فرمِ JetFormBuilder یک قانون بسازید: هنگامِ ثبتِ فرم، پیامک با پترن به کاربر و/یا مدیر ارسال می‌شود.
			<strong>شناسه‌ی فرم</strong> را از منوی JetFormBuilder ← Forms بردارید. <strong>نامِ فیلدِ موبایل</strong> همان
			«Name/Field Name»ِ فیلد در فرمِ شماست. متغیرهای پترن را در متن به‌صورتِ <code dir="ltr">%field_name%</code> بنویسید.
		</p>
		<form method="post">
			<?php wp_nonce_field( 'farazsms_jfb_save', 'farazsms_jfb_nonce' ); ?>
			<?php foreach ( $rules as $r ) : ?>
				<div style="background:#fff; border:1px solid #e1e1e1; border-radius:10px; padding:16px; margin-bottom:14px; display:grid; grid-template-columns:1fr 1fr; gap:12px;">
					<label>شناسه‌ی فرم (Form ID)
						<input type="number" name="rule_form_id[]" value="<?php echo esc_attr( $r['form_id'] ); ?>" style="width:100%; padding:8px; border:1px solid #e1e1e1; border-radius:6px; direction:ltr;"></label>
					<label>نامِ فیلدِ موبایلِ کاربر
						<input type="text" name="rule_phone_field[]" value="<?php echo esc_attr( $r['phone_field'] ); ?>" placeholder="مثلاً: mobile یا phone" style="width:100%; padding:8px; border:1px solid #e1e1e1; border-radius:6px; direction:ltr;"></label>
					<label>کدِ پترن
						<input type="text" name="rule_pattern_code[]" value="<?php echo esc_attr( $r['pattern_code'] ); ?>" style="width:100%; padding:8px; border:1px solid #e1e1e1; border-radius:6px; direction:ltr;"></label>
					<label>شماره‌ی مدیر (اختیاری، با کاما)
						<input type="text" name="rule_admin_phone[]" value="<?php echo esc_attr( $r['admin_phone'] ); ?>" placeholder="مثلاً: 09120000000" style="width:100%; padding:8px; border:1px solid #e1e1e1; border-radius:6px; direction:ltr;"></label>
					<label style="grid-column:1/3;">متنِ پیامک (با <code dir="ltr">%field_name%</code>)
						<textarea name="rule_message[]" rows="3" style="width:100%; padding:8px; border:1px solid #e1e1e1; border-radius:6px;"><?php echo esc_textarea( $r['message'] ); ?></textarea></label>
					<label style="grid-column:1/3; display:flex; align-items:center; gap:8px;">
						<input type="checkbox" name="rule_enabled[]" value="1" <?php checked( ! empty( $r['enabled'] ) && $r['enabled'] !== '0', true ); ?>> فعال
					</label>
				</div>
			<?php endforeach; ?>
			<p style="font-size:12px; color:#9b9b9b;">ردیفِ خالیِ پایین برای افزودنِ قانونِ جدید است. برای حذفِ یک قانون، شناسه‌ی فرمش را خالی کنید و ذخیره بزنید.</p>
			<button type="submit" name="farazsms_jfb_submit" class="button button-primary button-hero">💾 ذخیره قوانین</button>
		</form>
	</div>
	<?php
}

add_filter( 'farazsms_compatibility_registry', 'farazsms_jfb_register_compat' );
/**
 * @param array $registry
 * @return array
 */
function farazsms_jfb_register_compat( $registry ) {
	$registry['jetformbuilder'] = array(
		'name'   => 'JetFormBuilder',
		'what'   => 'پیامک پس از ثبتِ فرمِ JetFormBuilder',
		'group'  => 'forms',
		'detect' => 'farazsms_jfb_is_active',
	);
	return $registry;
}
