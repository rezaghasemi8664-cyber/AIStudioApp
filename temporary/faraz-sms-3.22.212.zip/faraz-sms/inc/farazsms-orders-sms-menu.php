<?php
/**
 * Native WooCommerce order SMS settings for FarazSMS.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_PWSMS_SETTINGS_PAGE = 'persian-woocommerce-sms-pro';
const FARAZSMS_PWSMS_SLUG          = 'persian-woocommerce-sms';
const FARAZSMS_ORDER_SMS_OPTION    = 'farazsms_order_sms_settings';

add_action( 'admin_menu', 'farazsms_orders_sms_register_submenu', 988 );
function farazsms_orders_sms_register_submenu() {
	$wc_active = farazsms_is_wc_active();
	if ( ! $wc_active ) {
		return;
	}
	add_submenu_page(
		'farazsms',
		__( 'پیامک سفارشات ووکامرس', 'farazsms' ),
		__( 'پیامک سفارشات ووکامرس', 'farazsms' ),
		'manage_options',
		'farazsms-orders-sms',
		'farazsms_orders_sms_render_page'
	);
}

function farazsms_order_sms_default_customer_message() {
	return "سفارش %order_id% در وضعیت %status% ثبت شد.\nمبلغ: %total%";
}

function farazsms_order_sms_default_admin_message() {
	return "سفارش %order_id% با وضعیت %status% در سایت ثبت شد.\nمشتری: %customer_name%\nمبلغ: %total%";
}

function farazsms_order_sms_status_keys() {
	$fallback = array(
		'pending'    => 'در انتظار پرداخت',
		'processing' => 'در حال انجام',
		'on-hold'    => 'در انتظار بررسی',
		'completed'  => 'تکمیل شده',
		'cancelled'  => 'لغو شده',
		'refunded'   => 'مسترد شده',
		'failed'     => 'ناموفق',
	);
	if ( function_exists( 'wc_get_order_statuses' ) ) {
		$statuses = array();
		foreach ( wc_get_order_statuses() as $key => $label ) {
			$status_key              = str_replace( 'wc-', '', (string) $key );
			$statuses[ $status_key ] = $fallback[ $status_key ] ?? $label;
		}
		return $statuses;
	}
	return $fallback;
}

function farazsms_order_sms_status_label( $status, $label = '' ) {
	$labels = farazsms_order_sms_status_keys();
	$status = sanitize_key( (string) $status );
	if ( isset( $labels[ $status ] ) ) {
		return $labels[ $status ];
	}
	$label = wp_strip_all_tags( (string) $label );
	return $label !== '' ? $label : str_replace( array( '-', '_' ), ' ', $status );
}

function farazsms_order_sms_status_description( $status ) {
	$descriptions = array(
		'pending'    => 'وقتی سفارش ساخته شده اما پرداخت هنوز انجام نشده است.',
		'processing' => 'وقتی پرداخت موفق شده و سفارش وارد مرحله آماده‌سازی/ارسال می‌شود.',
		'on-hold'    => 'وقتی سفارش نیاز به بررسی یا پرداخت غیرآنلاین دارد.',
		'completed'  => 'وقتی سفارش کامل شده و کار فروش/تحویل تمام شده است.',
		'cancelled'  => 'وقتی سفارش توسط مدیر یا مشتری لغو می‌شود.',
		'refunded'   => 'وقتی مبلغ سفارش برگشت داده می‌شود.',
		'failed'     => 'وقتی پرداخت یا ثبت سفارش ناموفق می‌شود.',
	);
	$status = sanitize_key( (string) $status );
	return $descriptions[ $status ] ?? 'وقتی وضعیت سفارش به این حالت تغییر کند، پیامک همین ردیف ارسال می‌شود.';
}

function farazsms_order_sms_profile_mobile() {
	$profile = farazsms_get_profile();
	if ( is_array( $profile ) && ! empty( $profile['mobile'] ) ) {
		return trim( (string) $profile['mobile'] );
	}
	return '';
}

function farazsms_order_sms_admin_phones_value( $settings ) {
	$phones = trim( (string) ( $settings['admin_phones'] ?? '' ) );
	if ( $phones !== '' ) {
		return $phones;
	}
	$profile_mobile = farazsms_order_sms_profile_mobile();
	if ( $profile_mobile !== '' ) {
		return $profile_mobile;
	}
	return implode( ',', farazsms_cfg_admin_phones() );
}

function farazsms_order_sms_has_pwsms_history() {
	if ( function_exists( 'PWSMS' ) ) {
		return true;
	}
	$active_plugins = (array) get_option( 'active_plugins', array() );
	if ( is_multisite() ) {
		$active_plugins = array_merge( $active_plugins, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
	}
	foreach ( $active_plugins as $plugin_path ) {
		if ( strpos( (string) $plugin_path, 'persian-woocommerce-sms' ) !== false ) {
			return true;
		}
	}
	$pwsms_options = array( 'sms_main_settings', 'woocommerce_sms_settings' );
	foreach ( $pwsms_options as $option_name ) {
		$value = get_option( $option_name, null );
		if ( ! empty( $value ) ) {
			return true;
		}
	}
	return false;
}

function farazsms_order_sms_default_mode() {
	$saved = get_option( FARAZSMS_ORDER_SMS_OPTION, null );
	if ( is_array( $saved ) && ! empty( $saved['mode'] ) ) {
		return in_array( $saved['mode'], array( 'native', 'pwsms' ), true ) ? $saved['mode'] : 'native';
	}
	$is_fresh_install = get_option( 'farazsms_installed_from_version', '' ) !== '';
	if ( ! $is_fresh_install && farazsms_order_sms_has_pwsms_history() ) {
		return 'pwsms';
	}
	return 'native';
}

function farazsms_order_sms_settings() {
	$defaults = array(
		'mode'          => farazsms_order_sms_default_mode(),
		'admin_phones'  => '',
		'statuses'      => array(),
	);
	foreach ( farazsms_order_sms_status_keys() as $status => $label ) {
		// v3.22.56: فقط «در حال انجام» (processing) پیش‌فرض روشن است — هم‌راستا با تنها وضعیتی که
		// autobuild برایش پترن می‌سازد. قبلاً «completed» هم روشن بود ولی پترنی برایش ساخته نمی‌شد
		// و حالتِ گیج‌کننده‌ی «روشن ولی بی‌اثر» می‌داد. (انتخابِ ذخیره‌شده‌ی مدیر حفظ می‌شود.)
		$default_on = ( $status === 'processing' ) ? '1' : '0';
		$defaults['statuses'][ $status ] = array(
			'customer_enabled' => $default_on,
			'customer_pattern' => '',
			'customer_message' => farazsms_order_sms_default_customer_message(),
			'admin_enabled'    => $default_on,
			'admin_pattern'    => '',
			'admin_message'    => farazsms_order_sms_default_admin_message(),
		);
	}
	$saved = get_option( FARAZSMS_ORDER_SMS_OPTION, array() );
	$saved = is_array( $saved ) ? $saved : array();
	$saved = wp_parse_args( $saved, $defaults );
	foreach ( $defaults['statuses'] as $status => $row_defaults ) {
		$saved['statuses'][ $status ] = wp_parse_args( isset( $saved['statuses'][ $status ] ) && is_array( $saved['statuses'][ $status ] ) ? $saved['statuses'][ $status ] : array(), $row_defaults );
	}
	return $saved;
}

function farazsms_order_sms_save_settings() {
	if ( ( $_SERVER['REQUEST_METHOD'] ?? '' ) !== 'POST' || ! isset( $_POST['farazsms_order_sms_save'] ) ) {
		return false;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return false;
	}
	check_admin_referer( 'farazsms_order_sms_settings', 'farazsms_order_sms_nonce' );
	$current = farazsms_order_sms_settings();
	$mode    = isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : 'native';
	$current['mode']         = in_array( $mode, array( 'native', 'pwsms' ), true ) ? $mode : 'native';
	$current['admin_phones'] = isset( $_POST['admin_phones'] ) ? sanitize_text_field( wp_unslash( $_POST['admin_phones'] ) ) : '';
	$posted_statuses = isset( $_POST['statuses'] ) && is_array( $_POST['statuses'] ) ? wp_unslash( $_POST['statuses'] ) : array();
	foreach ( farazsms_order_sms_status_keys() as $status => $label ) {
		$row = isset( $posted_statuses[ $status ] ) && is_array( $posted_statuses[ $status ] ) ? $posted_statuses[ $status ] : array();
		$current['statuses'][ $status ]['customer_enabled'] = ! empty( $row['customer_enabled'] ) ? '1' : '0';
		$current['statuses'][ $status ]['admin_enabled']    = ! empty( $row['admin_enabled'] ) ? '1' : '0';
		$current['statuses'][ $status ]['customer_pattern'] = isset( $row['customer_pattern'] ) ? sanitize_text_field( $row['customer_pattern'] ) : '';
		$current['statuses'][ $status ]['admin_pattern']    = isset( $row['admin_pattern'] ) ? sanitize_text_field( $row['admin_pattern'] ) : '';
		$current['statuses'][ $status ]['customer_message'] = isset( $row['customer_message'] ) ? farazsms_sanitize_pattern_text( $row['customer_message'], false ) : farazsms_order_sms_default_customer_message();
		$current['statuses'][ $status ]['admin_message']    = isset( $row['admin_message'] ) ? farazsms_sanitize_pattern_text( $row['admin_message'], false ) : farazsms_order_sms_default_admin_message();
	}
	update_option( FARAZSMS_ORDER_SMS_OPTION, $current, false );

	// v3.22.20: بخشِ «پیامکِ موجودی» حالا داخلِ همین فرم است و با همین یک دکمه ذخیره می‌شود
	// (فرم و دکمه‌ی جداگانه‌اش حذف شد — علتِ سردرگمیِ «دو دکمه‌ی ذخیره»). فقط وقتی آن بخش روی
	// صفحه رندر شده (فیلدِ نشانگرش حاضر است) ذخیره می‌کنیم تا مقادیرِ موجود پاک نشوند.
	if ( isset( $_POST['farazsms_low_stock_present'] ) ) {
		$low = get_option( 'farazsms_low_stock_settings', array() );
		$low = is_array( $low ) ? $low : array();
		$no  = get_option( 'farazsms_nostock_settings', array() );
		$no  = is_array( $no ) ? $no : array();
		$low['enabled']      = isset( $_POST['low_stock_enabled'] ) ? '1' : '0';
		$low['admin_phones'] = sanitize_text_field( wp_unslash( $_POST['low_stock_admin_phones'] ?? '' ) );
		$low['pattern_code'] = sanitize_text_field( wp_unslash( $_POST['low_stock_pattern_code'] ?? '' ) );
		$no['pattern_code']  = sanitize_text_field( wp_unslash( $_POST['no_stock_pattern_code'] ?? '' ) );
		update_option( 'farazsms_low_stock_settings', $low, false );
		update_option( 'farazsms_nostock_settings', $no, false );
		wp_cache_delete( 'farazsms_low_stock_settings', 'options' );
		wp_cache_delete( 'farazsms_nostock_settings', 'options' );
	}

	// v3.22.12: گاردِ کشِ آبجکت/autoload — روی هاست‌های با آبجکت‌کشِ پایدار، خواندنِ بعدی از DB بیاید.
	wp_cache_delete( FARAZSMS_ORDER_SMS_OPTION, 'options' );
	wp_cache_delete( 'alloptions', 'options' );
	return true;
}

/** لینکِ فاکتور برای متغیرِ %invoice_url% — کوتاه‌شده و فقط وقتی قابلیتِ فاکتور فعال است. */
function farazsms_order_sms_invoice_url( $order ) {
	if ( ! farazsms_invoice_is_enabled() ) {
		return '';
	}
	$url = farazsms_invoice_url( $order );
	if ( $url === '' ) {
		return '';
	}
	$short = farazsms_shorten_link( $url, 'invoice', 'فاکتور سفارش ' . $order->get_id() );
	if ( is_string( $short ) && $short !== '' ) {
		return $short;
	}
	return $url;
}

/**
 * v3.22.69: خلاصه‌ی محصولاتِ سفارش برای متغیرِ %items% — نامِ محصول + ویژگی‌های تنوع
 * (رنگ/سایز/…) + تعداد. مثال: «سرویس قاشق (رنگ: طلایی، سایز: ۳۰ نفره) ×۲ | محصولِ دوم».
 * ویژگی‌های تنوع از get_formatted_meta_data (خوانا، بدونِ متای داخلیِ _) می‌آیند.
 *
 * @param WC_Order $order
 * @return string
 */
function farazsms_order_sms_items_summary( $order ) {
	if ( ! method_exists( $order, 'get_items' ) ) {
		return '';
	}
	$lines = array();
	foreach ( $order->get_items() as $item ) {
		if ( ! method_exists( $item, 'get_name' ) ) {
			continue;
		}
		$name = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) $item->get_name() ) ) );
		$qty  = method_exists( $item, 'get_quantity' ) ? (int) $item->get_quantity() : 1;
		$bits = array();
		if ( method_exists( $item, 'get_formatted_meta_data' ) ) {
			// پیش‌فرضِ '_' تا متای داخلی (مثلِ _reduced_stock) نشت نکند؛ فقط ویژگی‌های خوانا (رنگ/سایز).
			foreach ( $item->get_formatted_meta_data( '_' ) as $meta ) {
				$k = trim( wp_strip_all_tags( (string) $meta->display_key ) );
				$v = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) $meta->display_value ) ) );
				if ( $k !== '' && $v !== '' ) {
					$bits[] = $k . ': ' . $v;
				}
			}
		}
		$line = $name;
		if ( ! empty( $bits ) ) {
			$line .= ' (' . implode( '، ', $bits ) . ')';
		}
		if ( $qty > 1 ) {
			$line .= ' ×' . $qty;
		}
		if ( $line !== '' ) {
			$lines[] = $line;
		}
	}
	$summary = implode( ' | ', $lines );
	// سقفِ طولِ محافظه‌کارانه: حدِ دقیقِ طولِ متغیرِ پترنِ فراز مستند نیست و مقدارِ بیش‌ازحد ممکن است
	// کلِ پیامک را رد کند؛ ۱۵۰ کاراکتر هم برای فهرست کافی است و پیامکِ چندبخشیِ گران نمی‌سازد.
	$max = 150;
	if ( function_exists( 'mb_strlen' ) ) {
		if ( mb_strlen( $summary, 'UTF-8' ) > $max ) {
			$summary = rtrim( mb_substr( $summary, 0, $max - 1, 'UTF-8' ) ) . '…';
		}
	} elseif ( strlen( $summary ) > $max * 3 ) {
		// fallback بدونِ mbstring: هر کاراکترِ فارسی ~۲ بایت (UTF-8)؛ سقفِ بایتیِ محافظه‌کارانه.
		$cut = substr( $summary, 0, $max * 3 );
		// برش روی مرزِ کاراکترِ UTF-8: آخرین کاراکترِ چندبایتی را کامل حذف می‌کنیم (چه ناقص چه کامل)
		// تا هیچ بایتِ نیمه‌کاره‌ای نماند و رشته معتبر بماند (وگرنه downstream کلِ مقدار را «-» می‌کند).
		// الگو = یک بایتِ شروعِ چندبایتی (\xC0-\xFF) + هر تعداد بایتِ ادامه (\x80-\xBF) در انتها.
		$cut = preg_replace( '/[\xC0-\xFF][\x80-\xBF]*$/', '', $cut );
		$summary = rtrim( $cut ) . '…';
	}
	return $summary;
}

if ( ! function_exists( 'farazsms_order_extra_pattern_vars' ) ) {
	/**
	 * متغیرهای «اضافه»ی سفارش (آدرس/کدپستی/شهر/استان/کشور/ایمیل/تلفن/تاریخ/حمل‌ونقل/…) را
	 * فقط برای توکن‌هایی که «دقیقاً» در $message هستند می‌سازد و به طولِ اعلام‌شده برش می‌دهد.
	 * مشترک بینِ پیامکِ سفارش، کد رهگیری و نظرسنجی. فراخواننده با اتحاد (union) ادغام می‌کند.
	 *
	 * @param WC_Order|object $order
	 * @param string          $message
	 * @return array<string,string>
	 */
	function farazsms_order_extra_pattern_vars( $order, $message ) {
		$fz_extra = array();
		if ( ! is_object( $order ) ) {
			return $fz_extra;
		}
		// v3.22.116: متغیرهای بیشترِ سفارش — مثلِ افزونهٔ پیامکِ ووکامرس (آدرس، کدپستی، شهر،
		// استان، کشور، ایمیل، تلفن، تاریخ، روشِ ارسال، لینکِ پرداخت، یادداشت، فیلدهای حمل‌ونقل).
		// فقط متغیری که «دقیقاً» در متن هست تزریق می‌شود (متغیرِ اعلام‌نشده → ردِ پیامک توسطِ فراز).
		$farazsms_order_ref = function ( $vk ) use ( $message ) {
			return strpos( (string) $message, '%' . $vk . '%' ) !== false
				|| strpos( (string) $message, '{' . $vk . '}' ) !== false;
		};
		$farazsms_order_simple = array(
			'email'               => 'get_billing_email',
			'phone'               => 'get_billing_phone',
			'mobile'              => 'get_billing_phone',
			'company'             => 'get_billing_company',
			'city'                => 'get_billing_city',
			'postcode'            => 'get_billing_postcode',
			'address_1'           => 'get_billing_address_1',
			'address_2'           => 'get_billing_address_2',
			'customer_note'       => 'get_customer_note',
			'transaction_id'      => 'get_transaction_id',
			'shipping_first_name' => 'get_shipping_first_name',
			'shipping_last_name'  => 'get_shipping_last_name',
			'shipping_company'    => 'get_shipping_company',
			'shipping_city'       => 'get_shipping_city',
			'shipping_postcode'   => 'get_shipping_postcode',
			'shipping_address_1'  => 'get_shipping_address_1',
			'shipping_address_2'  => 'get_shipping_address_2',
		);
		foreach ( $farazsms_order_simple as $vk => $vmethod ) {
			if ( isset( $fz_extra[ $vk ] ) || ! $farazsms_order_ref( $vk ) ) {
				continue;
			}
			$fz_extra[ $vk ] = method_exists( $order, $vmethod ) ? trim( wp_strip_all_tags( (string) $order->$vmethod() ) ) : '';
		}
		$farazsms_wc_country = function ( $code ) {
			$code = (string) $code;
			if ( $code !== '' && function_exists( 'WC' ) && WC()->countries && isset( WC()->countries->countries[ $code ] ) ) {
				return (string) WC()->countries->countries[ $code ];
			}
			return $code;
		};
		$farazsms_wc_state = function ( $country, $state ) {
			$country = (string) $country;
			$state   = (string) $state;
			if ( $state !== '' && function_exists( 'WC' ) && WC()->countries ) {
				$states = WC()->countries->get_states( $country );
				if ( is_array( $states ) && isset( $states[ $state ] ) ) {
					return (string) $states[ $state ];
				}
			}
			return $state;
		};
		if ( ! isset( $fz_extra['country'] ) && $farazsms_order_ref( 'country' ) ) {
			$fz_extra['country'] = $farazsms_wc_country( method_exists( $order, 'get_billing_country' ) ? $order->get_billing_country() : '' );
		}
		if ( ! isset( $fz_extra['state'] ) && $farazsms_order_ref( 'state' ) ) {
			$fz_extra['state'] = $farazsms_wc_state( method_exists( $order, 'get_billing_country' ) ? $order->get_billing_country() : '', method_exists( $order, 'get_billing_state' ) ? $order->get_billing_state() : '' );
		}
		if ( ! isset( $fz_extra['shipping_country'] ) && $farazsms_order_ref( 'shipping_country' ) ) {
			$fz_extra['shipping_country'] = $farazsms_wc_country( method_exists( $order, 'get_shipping_country' ) ? $order->get_shipping_country() : '' );
		}
		if ( ! isset( $fz_extra['shipping_state'] ) && $farazsms_order_ref( 'shipping_state' ) ) {
			$fz_extra['shipping_state'] = $farazsms_wc_state( method_exists( $order, 'get_shipping_country' ) ? $order->get_shipping_country() : '', method_exists( $order, 'get_shipping_state' ) ? $order->get_shipping_state() : '' );
		}
		if ( ! isset( $fz_extra['address'] ) && $farazsms_order_ref( 'address' ) && method_exists( $order, 'get_formatted_billing_address' ) ) {
			$fz_extra['address'] = trim( wp_strip_all_tags( str_replace( array( '<br/>', '<br>' ), '، ', (string) $order->get_formatted_billing_address() ) ) );
		}
		if ( ! isset( $fz_extra['shipping_address'] ) && $farazsms_order_ref( 'shipping_address' ) && method_exists( $order, 'get_formatted_shipping_address' ) ) {
			$fz_extra['shipping_address'] = trim( wp_strip_all_tags( str_replace( array( '<br/>', '<br>' ), '، ', (string) $order->get_formatted_shipping_address() ) ) );
		}
		if ( ! isset( $fz_extra['date'] ) && $farazsms_order_ref( 'date' ) && method_exists( $order, 'get_date_created' ) ) {
			$fz_d = $order->get_date_created();
			if ( $fz_d ) {
				$fz_ts        = $fz_d->getTimestamp();
				$fz_extra['date'] = farazsms_send_reports_to_jalali( $fz_ts, false );
			} else {
				$fz_extra['date'] = '';
			}
		}
		if ( ! isset( $fz_extra['shipping_method'] ) && $farazsms_order_ref( 'shipping_method' ) ) {
			$fz_extra['shipping_method'] = method_exists( $order, 'get_shipping_method' ) ? trim( wp_strip_all_tags( (string) $order->get_shipping_method() ) ) : '';
		}
		if ( ! isset( $fz_extra['payment_url'] ) && $farazsms_order_ref( 'payment_url' ) && method_exists( $order, 'get_checkout_payment_url' ) ) {
			$fz_pay = (string) $order->get_checkout_payment_url();
			if ( $fz_pay !== '' ) {
				$fz_short = farazsms_shorten_link( $fz_pay, 'orderpay', 'پرداخت سفارش ' . $order->get_id() );
				if ( is_string( $fz_short ) && $fz_short !== '' ) {
					$fz_pay = $fz_short;
				}
			}
			$fz_extra['payment_url'] = $fz_pay;
		}
		// برشِ ایمنِ مقادیر به طولِ اعلام‌شدهٔ همان متغیر — فقط روی متغیرهای «جدید»
		// (متغیرهای قدیمی مثلِ customer_name دست‌نخورده می‌مانند).
		$farazsms_order_new_keys = array_merge( array_keys( $farazsms_order_simple ), array( 'country', 'state', 'shipping_country', 'shipping_state', 'address', 'shipping_address', 'date', 'shipping_method', 'payment_url' ) );
		if ( function_exists( 'mb_substr' ) ) {
			foreach ( $farazsms_order_new_keys as $vk ) {
				if ( ! isset( $fz_extra[ $vk ] ) ) {
					continue;
				}
				// URLها هرگز برش داده نمی‌شوند (لینکِ بریده = خراب)؛ کوتاه‌سازی جداگانه انجام شده.
				if ( farazsms_pattern_var_is_url( $vk ) ) {
					continue;
				}
				$fz_tl  = farazsms_tracking_pattern_var_type_length( $vk );
				$fz_max = isset( $fz_tl['length'] ) ? (int) $fz_tl['length'] : 25;
				if ( $fz_max > 0 && mb_strlen( (string) $fz_extra[ $vk ], 'UTF-8' ) > $fz_max ) {
					$fz_extra[ $vk ] = mb_substr( (string) $fz_extra[ $vk ], 0, $fz_max, 'UTF-8' );
				}
			}
		}
		return $fz_extra;
	}
}

function farazsms_order_sms_replace_vars( $message, $order, $status_label ) {
	$first_name = method_exists( $order, 'get_billing_first_name' ) ? $order->get_billing_first_name() : '';
	$last_name  = method_exists( $order, 'get_billing_last_name' ) ? $order->get_billing_last_name() : '';
	// v3.21.88: مبلغ با واحدِ پولِ سایتِ ووکامرس (ریال/تومان) و جداکننده‌ی هزارگان نمایش داده شود،
	// نه کدِ خامِ ISO مثل «IRT». farazsms_price_plain از wc_price سمبلِ درستِ سایت را می‌گیرد.
	$raw_total = method_exists( $order, 'get_total' ) ? $order->get_total() : '';
	if ( $raw_total !== '' ) {
		$total = farazsms_price_plain( $raw_total );
	} elseif ( function_exists( 'get_woocommerce_currency_symbol' ) ) {
		$total = trim( number_format_i18n( (float) $raw_total ) . ' ' . get_woocommerce_currency_symbol() );
	} else {
		$total = (string) $raw_total;
	}
	$vars       = array(
		'order_id'      => (string) $order->get_id(),
		'order_number'  => method_exists( $order, 'get_order_number' ) ? (string) $order->get_order_number() : (string) $order->get_id(),
		'status'        => $status_label,
		'total'         => $total,
		'customer_name' => trim( $first_name . ' ' . $last_name ),
		'first_name'    => $first_name,
		'last_name'     => $last_name,
		// v3.21.94: متغیرِ %site% حذف شد — آدرسِ دامنه به‌صورتِ ثابت به انتهای پترن اضافه می‌شود
		// (پنلِ فراز پترنِ بدونِ آدرسِ ثابت را رد می‌کند).
	);
	// v3.22.1: لینکِ فاکتور فقط وقتی ساخته شود که متنِ پیامک واقعاً به %invoice_url% اشاره دارد —
	// وگرنه ساختِ توکن + $order->save() روی هرِ پیامکِ سفارش اجرا می‌شد (اثرِ جانبی و بارِ اضافه).
	if ( strpos( (string) $message, 'invoice_url' ) !== false ) {
		$vars['invoice_url'] = farazsms_order_sms_invoice_url( $order );
	}
	// v3.22.90: %payment_method% — عنوانِ روشِ پرداخت (مثلِ «پرداخت در محل»، «درگاه بانکی»). مخصوصاً
	// برای پیامکِ مدیر مفید است. فقط وقتی متن به آن اشاره دارد تزریق می‌شود (متغیرِ اعلام‌نشده = ردِ پیامک).
	if ( strpos( (string) $message, 'payment_method' ) !== false ) {
		$pm = method_exists( $order, 'get_payment_method_title' ) ? trim( wp_strip_all_tags( (string) $order->get_payment_method_title() ) ) : '';
		// برش به طولِ اعلام‌شده‌ی پترن (۵۰) تا مقدارِ بلند کلِ پیامک را رد نکند (مثلِ گاردِ %items%).
		if ( $pm !== '' ) {
			$pm = function_exists( 'mb_substr' ) ? mb_substr( $pm, 0, 50, 'UTF-8' ) : substr( $pm, 0, 50 );
		}
		$vars['payment_method'] = $pm !== '' ? $pm : '—';
	}
	// v3.22.69: %items% / %products% — فهرستِ محصولات + ویژگی‌های تنوع (رنگ/سایز/…) و تعداد.
	// فقط توکنی که واقعاً در متن هست به‌عنوانِ متغیر تزریق می‌شود — تزریقِ متغیرِ اضافه‌ای که در پترن
	// اعلام نشده، می‌تواند باعثِ ردِ کلِ پیامک توسطِ فراز شود. summary فقط یک‌بار محاسبه می‌شود.
	$want_items    = strpos( (string) $message, 'items' ) !== false;
	$want_products = strpos( (string) $message, 'products' ) !== false;
	if ( $want_items || $want_products ) {
		$items_summary = farazsms_order_sms_items_summary( $order );
		if ( $want_items ) {
			$vars['items'] = $items_summary;
		}
		if ( $want_products ) {
			$vars['products'] = $items_summary;
		}
	}
	// v3.22.117: متغیرهای اضافه از تابعِ مشترک (اتحاد؛ متغیرهای پایه حفظ می‌شوند).
	$vars += farazsms_order_extra_pattern_vars( $order, $message );
	$attributes = array();
	foreach ( $vars as $key => $value ) {
		$message = str_replace( array( '%' . $key . '%', '{' . $key . '}' ), (string) $value, $message );
		$attributes[ $key ] = (string) $value;
	}
	return array( $message, $attributes );
}

function farazsms_order_sms_admin_recipients( $settings ) {
	$phones = farazsms_order_sms_admin_phones_value( $settings );
	if ( $phones !== '' ) {
		return farazsms_cfg_phones_normalize( $phones );
	}
	return array();
}

function farazsms_order_sms_send_pattern_to_phone( $phone, $pattern_code, $message, $attrs, $sender = '' ) {
	if ( $pattern_code !== '' ) {
		return farazsms_send_pattern_sms_raw( $phone, $pattern_code, $attrs, $sender );
	}
	return 'missing_pattern';
}

/**
 * پیامکِ سفارش را به صفِ ارسالِ مشترک می‌سپارد.
 *
 * تا v3.22.197 این ماژول **صفِ دومِ** افزونه بود: هوکِ shutdownِ خودش، آرایه‌ی
 * درون‌حافظه‌ی خودش، و فراخوانیِ finish_requestِ خودش. کامنتِ همان کد دلیلش را
 * نوشته بود — «پیامکِ سفارش catch-up ندارد و روی هاستِ بدونِ کرون گم می‌شد» —
 * که آن‌موقع درست بود، ولی صفِ مشترک از آن زمان هر سه چیزِ لازم را گرفت:
 * ذخیره‌ی باقی‌مانده، اجراکننده، و کچ‌آپِ پیشخوان.
 *
 * نتیجه‌ی نگه‌داشتنِ دوگانگی این بود که مسیرِ سفارش — داغ‌ترین مسیرِ افزونه —
 * روی mod_php همچنان ارسالِ همگام داشت و باقی‌مانده‌اش اگر فرایند وسطِ کار
 * می‌مرد بی‌صدا گم می‌شد.
 *
 * «کار» است نه «ارسالِ پترن»، چون جای‌گذاریِ متغیرها (و کوتاه‌کردنِ لینکِ فاکتور
 * درونِ آن) هم باید از درخواست خارج شود.
 *
 * @param int    $order_id
 * @param string $phone
 * @param string $pattern_code
 * @param string $message_template متنِ خامِ پترن (قبل از جایگذاریِ متغیرها)
 * @param string $status_label
 * @param string $sender
 */
function farazsms_order_sms_dispatch_send( $order_id, $phone, $pattern_code, $message_template, $status_label, $sender = '' ) {
	$order_id = (int) $order_id;
	if ( $order_id <= 0 || $phone === '' || trim( (string) $pattern_code ) === '' ) {
		return;
	}
	farazsms_queue_task(
		'order-sms',
		'farazsms_order_sms_deferred_send',
		array( $order_id, $phone, trim( (string) $pattern_code ), (string) $message_template, (string) $status_label, (string) $sender ),
		array( 'order_id' => $order_id )
	);
}

/**
 * کارِ واقعیِ به‌تأخیرافتاده: جایگذاریِ متغیرها (+کوتاه‌کردنِ لینک) و سپس ارسالِ پترن.
 *
 * @param int    $order_id
 * @param string $phone
 * @param string $pattern_code
 * @param string $message_template
 * @param string $status_label
 * @param string $sender
 */
function farazsms_order_sms_deferred_send( $order_id, $phone, $pattern_code, $message_template, $status_label, $sender = '' ) {
	$order = function_exists( 'wc_get_order' ) ? wc_get_order( (int) $order_id ) : null;
	if ( ! $order ) {
		return;
	}
	list( $message, $attrs ) = farazsms_order_sms_replace_vars( (string) $message_template, $order, (string) $status_label );
	$res = farazsms_order_sms_send_pattern_to_phone( $phone, (string) $pattern_code, $message, $attrs, $sender );

	// کانالِ بله (MVP): بلافاصله پس از ارسالِ موفقِ پیامک، همان متنِ حل‌شده در بله هم برود
	// (AD-3: هم‌زمان با پیامکِ تاییدشده، همان متن). خود-گِیت + async + هرگز-بلاک داخلِ maybe_send.
	if ( $res === 'success' ) {
		farazsms_bale_maybe_send( 'order', $phone, $message );
	}
}

/**
 * v3.22.49 (بازبینی Story 1.1 / AC-5): آیا این سفارش، تمدیدِ اشتراک یا خودِ آبجکتِ اشتراک است؟
 * فقط وقتی افزونه‌ی WooCommerce Subscriptions فعال باشد معنا دارد؛ در غیرِ این‌صورت no-op و false.
 *
 * @param int    $order_id
 * @param object $order
 * @return bool
 */
function farazsms_order_sms_is_subscription_renewal( $order_id, $order = null ) {
	// خودِ آبجکتِ اشتراک (shop_subscription) — نه سفارشِ خرید.
	if ( $order && method_exists( $order, 'get_type' ) && $order->get_type() === 'shop_subscription' ) {
		return true;
	}
	// سفارشِ تمدید (renewal) از افزونه‌ی WooCommerce Subscriptions.
	if ( function_exists( 'wcs_order_contains_renewal' ) && wcs_order_contains_renewal( $order_id ) ) {
		return true;
	}
	return false;
}

function farazsms_order_sms_handle_status_changed( $order_id, $old_status, $new_status, $order = null ) {
	$settings = farazsms_order_sms_settings();
	if ( ( $settings['mode'] ?? 'native' ) !== 'native' ) {
		return;
	}
	$order = $order && is_object( $order ) ? $order : ( function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null );
	if ( ! $order ) {
		return;
	}
	// v3.22.49 (بازبینی Story 1.1 / AC-5): سفارشِ تمدیدِ اشتراک را کاملاً از پیامکِ خودکار مستثنا
	// کن — این چوک‌پوینتِ مشترکِ هر دو مسیر (status_changed و payment_complete) است، پس گارد اینجا
	// هر دو را می‌گیرد. تمدیدِ خودکار یک پرداختِ واقعی است و payment_complete را fire می‌کند، ولی
	// نباید پیامکِ «خریدِ موفق» + هزینهٔ اضافه برای هر تمدید برود (رگرسیونِ v3.22.36).
	if ( farazsms_order_sms_is_subscription_renewal( (int) $order_id, $order ) ) {
		return;
	}
	$new_status = sanitize_key( (string) $new_status );
	$row = $settings['statuses'][ $new_status ] ?? null;
	if ( ! is_array( $row ) ) {
		return;
	}
	$statuses     = farazsms_order_sms_status_keys();
	$status_label = isset( $statuses[ $new_status ] ) ? wp_strip_all_tags( $statuses[ $new_status ] ) : $new_status;
	$sender       = farazsms_cfg_sender();

	if ( ( $row['customer_enabled'] ?? '0' ) === '1' ) {
		$phone = method_exists( $order, 'get_billing_phone' ) ? (string) $order->get_billing_phone() : '';
		if ( $phone !== '' && ( ! function_exists( 'farazsms_order_sms_should_send_once' ) || farazsms_order_sms_should_send_once( $order->get_id(), 2, $new_status, $phone ) ) ) {
			// v3.22.44 (بازبینی T4): should_send_once بالا «اسلاتِ ارسال را مصرف کرد»؛ اگر مدیر تیک
			// را برداشته باشد فقط ارسال نمی‌کنیم — ولی چون اسلات مصرف شده، triggerِ بعدیِ همین
			// وضعیت (مثلِ woocommerce_payment_complete که بعداً fire می‌شود) هم دوباره نمی‌فرستد.
			if ( ! farazsms_order_sms_customer_suppressed( $order->get_id() ) ) {
				// D-1: ارسال بعد از بستنِ پاسخ (غیرمسدود روی FPM/LiteSpeed).
				farazsms_order_sms_dispatch_send( $order->get_id(), $phone, (string) $row['customer_pattern'], (string) $row['customer_message'], $status_label, $sender );
			}
		}
	}

	if ( ( $row['admin_enabled'] ?? '0' ) === '1' ) {
		// ⚠️ هر شماره‌ی مدیر «اسلاتِ» خودش را دارد. پیش از این، قفلِ ضدِتکرار فقط از
		// (نوع + وضعیت) ساخته می‌شد؛ شماره‌ی اول قفل را مصرف می‌کرد و شماره‌های دوم
		// به بعد **هرگز** پیامک نمی‌گرفتند — بی‌هیچ خطا و بی‌هیچ ردی در لاگ.
		$recipients = farazsms_order_sms_admin_recipients( $settings );
		$slots      = array();
		foreach ( $recipients as $phone ) {
			$slots[ $phone ] = function_exists( 'farazsms_order_sms_recipient_slot' ) ? farazsms_order_sms_recipient_slot( $phone ) : '';
		}

		// مهاجرتِ سفارش‌های پیش از نسخه‌ی اسلات‌دار — مستقل از ترتیبِ فهرست.
		$migrated = function_exists( 'farazsms_order_sms_group_migrated' )
			&& farazsms_order_sms_group_migrated( $order->get_id(), 4, $new_status, $slots );

		if ( ! $migrated ) {
			foreach ( $recipients as $phone ) {
				if ( $phone === '' ) {
					continue;
				}
				if ( function_exists( 'farazsms_order_sms_should_send_once' )
					&& ! farazsms_order_sms_should_send_once( $order->get_id(), 4, $new_status, $phone, $slots[ $phone ] ) ) {
					continue;
				}
				// D-1: ارسال بعد از بستنِ پاسخ (غیرمسدود روی FPM/LiteSpeed).
				farazsms_order_sms_dispatch_send( $order->get_id(), $phone, (string) $row['admin_pattern'], (string) $row['admin_message'], $status_label, $sender );
			}

			// ⚠️ مهرِ پایانِ رسیدگی — **بدونِ قید به اینکه چیزی ارسال شد یا نه**.
			// کلیدِ گروهی تنها چیزی است که مسیرِ «پیامک حرفه‌ای ووکامرس» را ساکت
			// نگه می‌دارد (همین هوک، اولویتِ ۹۸، بی‌اعتنا به تنظیمِ حالت). اگر آن را
			// به «آیا ارسالی انجام شد؟» گره بزنیم، سفارش‌هایی که همه‌ی گیرنده‌هایشان
			// از قبل مهر خورده‌اند (نسخه‌ی میانی، یا تکرارِ همان وضعیت) کلید نمی‌گیرند
			// و مدیر دوباره پیامکِ تکراری می‌گیرد.
			if ( function_exists( 'farazsms_order_sms_mark_group_handled' ) ) {
				// نگاشتِ وضعیتِ مسیرِ دوم هم مهر می‌شود: آن مسیر کلید را با وضعیتِ
				// ترجمه‌شده‌ی خودش می‌سازد و برابریِ این دو رشته تضمین‌شده نیست.
				$aliases = array();
				if ( function_exists( 'PWSMS' ) ) {
					try {
						$mapped = PWSMS()->modify_status( $new_status );
						if ( is_scalar( $mapped ) && (string) $mapped !== '' ) {
							$aliases[] = (string) $mapped;
						}
					} catch ( \Throwable $e ) {
						$aliases = array();
					}
				}
				farazsms_order_sms_mark_group_handled( $order, 4, $new_status, $aliases );
			}
		}
	}
}
add_action( 'woocommerce_order_status_changed', 'farazsms_order_sms_handle_status_changed', 90, 4 );

/**
 * v3.22.43 (#5): آیا در «ذخیره‌ی صفحه‌ی ویرایشِ سفارش» مدیر تیکِ «ارسال پیامک به مشتری» را برداشته؟
 *
 * جایگزینِ همان قابلیتِ حیاتیِ افزونه‌ی پیامک حرفه‌ای ووکامرس: هنگامِ تغییرِ دستیِ وضعیت، مدیر
 * می‌تواند جلوی ارسالِ پیامکِ اضافه (و هزینه‌اش) به مشتری را بگیرد. فقط وقتی چک‌باکسِ ما در فرمِ
 * ذخیره حاضر است اثر دارد؛ در چک‌اوت/انتقالِ خودکار (که فرم نیست) پیامک طبقِ تنظیمات می‌رود.
 *
 * @return bool true = پیامکِ مشتری برای این ذخیره سرکوب شود.
 */
function farazsms_order_sms_customer_suppressed( $order_id = 0 ) {
	// phpcs:disable WordPress.Security.NonceVerification.Missing — این هوک داخلِ ذخیره‌ی خودِ WC اجرا
	// می‌شود که nonce را قبلاً تأیید کرده؛ ما فقط ارسالِ خودمان را gate می‌کنیم، نه تغییرِ state.
	if ( ! isset( $_POST['farazsms_status_sms_present'] ) ) {
		return false;
	}
	// v3.22.44 (بازبینی T5): سرکوب فقط برای همان سفارشی که در فرمِ ویرایش ذخیره می‌شود — نه هر
	// سفارشی که در همان request به‌صورتِ زنجیره‌ای (سفارشِ گروهی/مرتبط) تغییرِ وضعیت می‌دهد.
	// شناسه‌ی فرمِ ویرایش: post_ID (کلاسیک) یا id (HPOS).
	if ( (int) $order_id > 0 ) {
		$edited_id = 0;
		if ( isset( $_POST['post_ID'] ) ) {
			$edited_id = (int) $_POST['post_ID'];
		} elseif ( isset( $_POST['id'] ) ) {
			$edited_id = (int) $_POST['id'];
		} elseif ( isset( $_POST['order_id'] ) ) {
			$edited_id = (int) $_POST['order_id'];
		}
		if ( $edited_id > 0 && $edited_id !== (int) $order_id ) {
			return false; // این سفارش، سفارشِ در حالِ ویرایش نیست → سرکوب نکن.
		}
	}
	return empty( $_POST['farazsms_send_status_sms'] );
	// phpcs:enable
}

/**
 * v3.22.43 (#5): رندرِ چک‌باکس زیرِ جزئیاتِ سفارش در صفحه‌ی ویرایش (کلاسیک + HPOS).
 */
add_action( 'woocommerce_admin_order_data_after_order_details', 'farazsms_order_sms_render_edit_toggle' );
function farazsms_order_sms_render_edit_toggle( $order ) {
	$settings = farazsms_order_sms_settings();
	if ( ( $settings['mode'] ?? 'native' ) !== 'native' ) {
		return; // فقط وقتی حالتِ ارسالِ سفارشات «بومی» است این چک‌باکس معنا دارد.
	}
	?>
	<p class="form-field form-field-wide" style="margin-top:10px; padding-top:8px; border-top:1px solid #eee;">
		<input type="hidden" name="farazsms_status_sms_present" value="1">
		<label style="display:flex; align-items:center; gap:7px; cursor:pointer; font-weight:600;">
			<?php // v3.22.95: ووکامرس روی input های پنلِ سفارش width:100% می‌گذارد و چک‌باکس را تمام‌عرض کِش می‌داد؛
			// width/flex اینجا آن را به مربعِ کوچکِ طبیعی برمی‌گرداند. ?>
			<input type="checkbox" name="farazsms_send_status_sms" value="1" checked style="width:16px; height:16px; min-width:16px; flex:0 0 auto; margin:0;">
			<span>📩 <?php esc_html_e( 'ارسال پیامکِ تغییر وضعیت به مشتری', 'farazsms' ); ?></span>
		</label>
		<span style="color:#787c82; font-size:11.5px; display:block; margin-top:3px;">
			<?php esc_html_e( 'اگر وضعیت را دستی تغییر می‌دهید و نمی‌خواهید پیامکِ اضافه به مشتری برود (و هزینه بپردازید)، تیک را بردارید.', 'farazsms' ); ?>
		</span>
	</p>
	<?php
}

/**
 * v3.22.30: هوکِ سفارشِ جدید.
 *
 * سفارشِ تازه مستقیماً در وضعیتِ «در انتظار پرداخت» (pending) ساخته می‌شود؛ این یک
 * «تغییرِ وضعیت» نیست، پس woocommerce_order_status_changed برایش fire نمی‌شود و پیامکِ
 * pending هیچ‌وقت ارسال نمی‌شد. اینجا رویدادِ ساختِ سفارش (checkout + هر منبعِ دیگر) را هم
 * می‌گیریم و همان هندلر را با وضعیتِ فعلی صدا می‌زنیم. dedupe (should_send_once) از ارسالِ
 * دوباره در صورتِ رخ‌دادنِ transitionِ واقعیِ بعدی به همان وضعیت جلوگیری می‌کند.
 *
 * @param int $order_id
 */
function farazsms_order_sms_handle_new_order( $order_id ) {
	$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
	if ( ! $order ) {
		return;
	}
	farazsms_order_sms_handle_status_changed( (int) $order_id, '', $order->get_status(), $order );
}
// v3.22.36 (F3): فقط سفارشِ واقعیِ checkout — کلاسیک + Store API (بلاک). قبلاً هوکِ عمومیِ
// woocommerce_new_order بود که برای سفارشِ دستیِ ادمین، REST، importِ CSV و تمدیدِ اشتراک هم
// fire می‌شد و پیامکِ ناخواسته به مشتری می‌رفت (هدرِ اعتبار + شکایتِ فروشنده). این دو هوک فقط
// روی خریدِ واقعیِ مشتری اجرا می‌شوند و سفارشِ pendingِ تازه را هم پوشش می‌دهند.
add_action( 'woocommerce_checkout_order_processed', 'farazsms_order_sms_handle_new_order', 90, 1 );
add_action( 'woocommerce_store_api_checkout_order_processed', 'farazsms_order_sms_handle_new_order', 90, 1 );

// v3.22.41 (Story 1.1 / تیکت‌های 21012 · 19303): درگاهِ واسط/اقساطی (مثلِ DigiPay) سفارش را
// از مسیرِ callback به «processing» می‌رساند و اغلب نه woocommerce_checkout_order_processed را
// fire می‌کند و نه یک transitionِ واقعیِ pending→processing که woocommerce_order_status_changed
// را تریگر کند؛ در نتیجه پیامکِ خریدِ موفقِ مشتری و پیامکِ مدیر ارسال نمی‌شد (با ZarinPal که از
// مسیرِ استانداردِ checkout عبور می‌کند کار می‌کرد). woocommerce_payment_complete برای «همهٔ»
// درگاه‌ها هنگامِ تکمیلِ پرداختِ واقعی fire می‌شود و مستقل از مسیرِ ساختِ سفارش است — پس نقطهٔ
// درستِ پوششِ این حالت است. رگرسیونِ v3.22.36 (عدمِ ارسال برای سفارشِ دستی/REST/CSV/تمدید) نقض
// نمی‌شود چون این هوک فقط با پرداختِ واقعی fire می‌شود، و لایهٔ dedupe (should_send_once) از
// ارسالِ دوباره وقتی هم status_changed و هم payment_complete رخ دهند جلوگیری می‌کند.
add_action( 'woocommerce_payment_complete', 'farazsms_order_sms_handle_new_order', 90, 1 );

// v3.22.93 (تیکت DigiPay اقساطی): درگاهِ اقساطی/واسط مثلِ DigiPay اغلب نه payment_complete را صدا
// می‌زند (اقساط ≠ پرداختِ کامل) و نه همیشه یک transitionِ استانداردی که سه هوکِ بالا را تریگر کند —
// در نتیجه سفارشِ processingِ آن پیامک نمی‌گرفت (ولی درگاهِ آنلاین کار می‌کرد). این هوک روی «ذخیره‌ی
// سفارش» (HPOS-safe؛ هر روشِ ست‌کردنِ وضعیت که سفارش را save کند این را fire می‌کند) به‌عنوانِ شبکه‌ی
// ایمنیِ نهایی عمل می‌کند. برای پرهیز از رگرسیونِ v3.22.36 فقط سفارشِ واقعیِ فرانت پذیرفته می‌شود
// (created_via ∉ admin/rest-api). لایه‌ی dedupe (should_send_once — static+transient، بدونِ ذخیره‌ی
// سفارش) از ارسالِ دوباره در کنارِ هوک‌های دیگر جلوگیری می‌کند و چون dispatch غیرهمزمان (shutdown)
// است، این هوک سفارش را دوباره save نمی‌کند؛ پس بازگشتی رخ نمی‌دهد و نیازی به گاردِ per-request نیست
// (که می‌توانست transitionِ همان‌ریکوئستِ بعدی را از دست بدهد).
add_action( 'woocommerce_update_order', 'farazsms_order_sms_handle_order_update', 90, 1 );
function farazsms_order_sms_handle_order_update( $order_id ) {
	$order_id = (int) $order_id;
	if ( $order_id <= 0 ) {
		return;
	}
	$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
	if ( ! $order instanceof WC_Order ) {
		return; // refund/غیرسفارش رد شود.
	}
	// v3.22.94: allowlist (نه denylist) — فقط سفارشِ واقعیِ خریدِ فرانت. سفارشِ درگاه (از جمله دیجی‌پی)
	// از چک‌اوتِ استاندارد created_via='checkout' (یا 'store-api' در بلاک) دارد. importِ CSV / POS /
	// مهاجرت / اسکریپت اغلب created_via='' یا مقداری دیگر دارند و نباید پیامکِ خودکار بگیرند
	// (رگرسیونِ v3.22.36). سفارشِ دستیِ ادمین 'admin' و REST 'rest-api' هم طبعاً رد می‌شوند.
	$via = method_exists( $order, 'get_created_via' ) ? (string) $order->get_created_via() : '';
	if ( ! in_array( $via, array( 'checkout', 'store-api' ), true ) ) {
		return;
	}
	farazsms_order_sms_handle_status_changed( $order_id, '', $order->get_status(), $order );
}

add_action( 'wp_ajax_farazsms_order_sms_build_pattern', 'farazsms_order_sms_build_pattern_ajax' );
function farazsms_order_sms_build_pattern_ajax() {
	check_ajax_referer( 'farazsms_order_sms_build_pattern', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
	}
	$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';
	$target = isset( $_POST['target'] ) ? sanitize_key( wp_unslash( $_POST['target'] ) ) : '';
	$message = isset( $_POST['message'] ) ? farazsms_sanitize_pattern_text( $_POST['message'] ) : '';
	if ( $status === '' || ! in_array( $target, array( 'customer', 'admin' ), true ) || trim( $message ) === '' ) {
		wp_send_json_error( array( 'message' => 'اطلاعات پترن کامل نیست.' ) );
	}
	$settings = farazsms_order_sms_settings();
	if ( ! isset( $settings['statuses'][ $status ] ) ) {
		wp_send_json_error( array( 'message' => 'وضعیت سفارش نامعتبر است.' ) );
	}
	// v3.22.2: دو حالتِ صریح — 'edit' (ویرایشِ پترنِ فعلی با همان کد) و 'new' (ساختِ پترنِ تازه).
	// برای سایت‌هایی که از دیتابیسِ داپلیکیت‌شده بالا آمده‌اند: کدپترن قدیمی است و «ویرایش» همان
	// پترنِ مشترک را عوض می‌کند؛ با «ساخت پترن جدید» یک کدِ مستقل برای دامنه‌ی جدید ساخته می‌شود.
	$mode        = isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : 'edit';
	$pattern_key = $target . '_pattern';
	$message_key = $target . '_message';
	$existing    = trim( (string) ( $settings['statuses'][ $status ][ $pattern_key ] ?? '' ) );
	$desc        = farazsms_pattern_brand_description( 'order' );
	$did_update  = false;
	if ( $mode === 'new' ) {
		// ساختِ صریحِ پترنِ جدید — کدِ قبلی نادیده گرفته می‌شود.
		$resp = farazsms_create_pattern( $message, 3, $desc );
	} elseif ( $existing !== '' ) {
		// ویرایشِ پترنِ فعلی.
		$resp = farazsms_update_pattern( $existing, $message, 3, $desc );
		$tmp  = is_string( $resp ) ? json_decode( $resp, true ) : $resp;
		$not_found = is_array( $tmp ) && isset( $tmp['status'] ) && $tmp['status'] !== 'success'
			&& ( ( isset( $tmp['error_code'] ) && $tmp['error_code'] === 'pattern_not_found' )
				|| ( farazsms_is_pattern_not_found_response( $tmp ) ) );
		$did_update = ! $not_found;
		if ( $not_found ) {
			$resp = farazsms_create_pattern( $message, 3, $desc );
		}
	} else {
		// چیزی برای ویرایش نیست → ساختِ جدید.
		$resp = farazsms_create_pattern( $message, 3, $desc );
	}
	$code = farazsms_autobuild_extract_code( $resp );
	if ( $code === '' && $did_update && $existing !== '' ) {
		$code = $existing;
	}
	if ( $code === '' ) {
		$data = is_string( $resp ) ? json_decode( $resp, true ) : $resp;
		wp_send_json_error( array( 'message' => is_array( $data ) && isset( $data['message'] ) ? (string) $data['message'] : 'پاسخ نامعتبر از سرور' ) );
	}
	$settings['statuses'][ $status ][ $pattern_key ] = $code;
	$settings['statuses'][ $status ][ $message_key ] = $message;
	update_option( FARAZSMS_ORDER_SMS_OPTION, $settings, false );
	wp_send_json_success( array( 'pattern_code' => $code, 'message' => ( $did_update ? 'پترنِ فعلی به‌روزرسانی شد' : 'پترنِ جدید ساخته شد' ) . ' (' . $code . ')' ) );
}

function farazsms_orders_sms_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	$saved        = farazsms_order_sms_save_settings();
	$settings     = farazsms_order_sms_settings();
	$admin_phones_value = farazsms_order_sms_admin_phones_value( $settings );
	$pwsms_active = function_exists( 'PWSMS' );
	$settings_url = admin_url( 'admin.php?page=' . FARAZSMS_PWSMS_SETTINGS_PAGE );
	$install_url  = current_user_can( 'install_plugins' ) ? wp_nonce_url( self_admin_url( 'update.php?action=install-plugin&plugin=' . FARAZSMS_PWSMS_SLUG ), 'install-plugin_' . FARAZSMS_PWSMS_SLUG ) : self_admin_url( 'plugin-install.php?tab=plugin-information&plugin=' . FARAZSMS_PWSMS_SLUG . '&TB_iframe=true&width=772&height=600' );
	$nonce        = wp_create_nonce( 'farazsms_order_sms_build_pattern' );
	?>
	<div class="wrap" style="direction:rtl; max-width:1180px;">
		<h1 style="font-size:20px;">📦 پیامک سفارشات ووکامرس</h1>
		<?php
		// دکمه‌ی ویدیو را بیرونِ h1 می‌گذاریم: «قابِ اپ» اولین h1/h2ِ صفحه را display:none می‌کند
		// (تا با عنوانِ خودِ قاب تکراری نشود) و اگر دکمه داخلِ h1 باشد، آن هم مخفی می‌شود.
		echo '<div style="margin:0 0 14px;">';
		farazsms_help_video_button( 'orders' );
		echo '</div>';
		?>
		<?php if ( $saved ) : ?><div class="notice notice-success"><p>تنظیمات ذخیره شد.</p></div><?php endif; ?>
		<form method="post">
			<?php wp_nonce_field( 'farazsms_order_sms_settings', 'farazsms_order_sms_nonce' ); ?>
			<div style="background:#fff; border:1px solid #e1e1e1; border-radius:14px; padding:18px 20px; margin:16px 0;">
				<h2 style="margin:0 0 12px; font-size:15px;">حالت ارسال</h2>
				<label style="display:block; margin-bottom:10px;"><input type="radio" name="mode" value="native" <?php checked( $settings['mode'], 'native' ); ?>> ارسال با تنظیمات بومی افزونه فراز اس‌ام‌اس</label>
				<label style="display:block;"><input type="radio" name="mode" value="pwsms" <?php checked( $settings['mode'], 'pwsms' ); ?>> استفاده از پیامک حرفه‌ای ووکامرس <?php echo $pwsms_active ? '<span style="color:#0c9765;">(فعال)</span>' : '<span style="color:#d52a16;">(نصب/فعال نیست)</span>'; ?></label>
				<?php if ( $pwsms_active ) : ?><p><a class="button" href="<?php echo esc_url( $settings_url ); ?>">ورود به تنظیمات PWSMS</a></p><?php else : ?><p><a class="button <?php echo current_user_can( 'install_plugins' ) ? '' : 'thickbox'; ?>" href="<?php echo esc_url( $install_url ); ?>">نصب پیامک حرفه‌ای ووکامرس</a></p><?php endif; ?>
				<div style="margin-top:12px; padding:12px 14px; background:#e2f8f0; border:1px solid #10c282; border-right:4px solid #0c9765; border-radius:8px; color:#096d49; line-height:1.9; font-size:12.5px;">
					<strong>پیشنهاد ما:</strong> با حالت بومی فراز اس‌ام‌اس، برای پیامک‌های سفارشات ووکامرس نیازی به نصب چند افزونه جداگانه ندارید. تنظیمات، ساخت پترن و ارسال پیامک مدیر و مشتری همین‌جا انجام می‌شود؛ سایت سبک‌تر می‌ماند و مدیریت پیامک‌ها یکپارچه‌تر می‌شود.
				</div>
				<?php if ( $settings['mode'] === 'pwsms' ) : ?>
					<p style="margin:10px 0 0; color:#83620d; font-size:12px; line-height:1.8;">برای احترام به تنظیمات قبلی شما، چون قبلاً از پیامک حرفه‌ای ووکامرس استفاده شده، حالت فعلی روی PWSMS مانده است. هر زمان خواستید می‌توانید به حالت بومی فراز اس‌ام‌اس تغییر دهید.</p>
				<?php endif; ?>
				<label style="display:block; margin-top:14px; font-weight:600;">شماره‌های مدیر برای پیامک سفارش</label>
				<input type="text" name="admin_phones" value="<?php echo esc_attr( $admin_phones_value ); ?>" placeholder="09120000000,09130000000" style="width:360px; max-width:100%; direction:ltr; text-align:left; padding:8px 10px;">
				<p style="margin:6px 0 0; color:#9b9b9b; font-size:12px;">پیش‌فرض از موبایل پروفایل پنل فراز خوانده می‌شود؛ اگر خواستید می‌توانید همین‌جا تغییرش دهید.</p>
			</div>
			<div style="display:grid; gap:14px;">
			<?php foreach ( farazsms_order_sms_status_keys() as $status => $label ) : $row = $settings['statuses'][ $status ]; $status_label = farazsms_order_sms_status_label( $status, $label ); ?>
				<div style="background:#fff; border:1px solid #e1e1e1; border-radius:14px; padding:16px 18px;">
					<h3 style="margin:0 0 6px; font-size:14px; color:#263f67;">وضعیت: <?php echo esc_html( $status_label ); ?></h3>
					<p style="margin:0 0 12px; color:#9b9b9b; font-size:12px; line-height:1.8;"><?php echo esc_html( farazsms_order_sms_status_description( $status ) ); ?> <span dir="ltr" style="color:#9b9b9b;">(<?php echo esc_html( $status ); ?>)</span></p>
					<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(320px,1fr)); gap:14px;">
						<?php foreach ( array( 'customer' => 'مشتری', 'admin' => 'مدیر' ) as $target => $target_label ) : $prefix = "statuses[$status][$target"; ?>
							<div style="border:1px solid #e1e1e1; border-radius:10px; padding:12px; background:#f5f8fe;">
								<label style="font-weight:700;"><input type="checkbox" name="statuses[<?php echo esc_attr( $status ); ?>][<?php echo esc_attr( $target ); ?>_enabled]" value="1" <?php checked( $row[ $target . '_enabled' ], '1' ); ?>> ارسال پیامک به <?php echo esc_html( $target_label ); ?></label>
								<label style="display:block; margin-top:10px; font-size:12px; font-weight:600;">کد پترن</label>
								<input id="farazsms-order-<?php echo esc_attr( $status . '-' . $target ); ?>-pattern" type="text" name="statuses[<?php echo esc_attr( $status ); ?>][<?php echo esc_attr( $target ); ?>_pattern]" value="<?php echo esc_attr( $row[ $target . '_pattern' ] ); ?>" style="width:100%; direction:ltr; padding:7px 9px;">
								<label style="display:block; margin-top:10px; font-size:12px; font-weight:600;">متن پترن</label>
								<textarea id="farazsms-order-<?php echo esc_attr( $status . '-' . $target ); ?>-message" name="statuses[<?php echo esc_attr( $status ); ?>][<?php echo esc_attr( $target ); ?>_message]" rows="5" style="width:100%; padding:8px 10px; line-height:1.8; direction:rtl;"><?php echo esc_textarea( $row[ $target . '_message' ] ); ?></textarea>
								<div style="font-size:11.5px; color:#4d4d4d; line-height:2; background:#fff; border:1px solid #e1e1e1; border-radius:8px; padding:8px 10px; margin-top:6px;">
									<strong style="color:#263f67;">راهنمای متغیرها:</strong>
									<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:2px 14px; margin-top:4px;">
										<span><code>%order_id%</code> = شماره سفارش</span>
										<span><code>%order_number%</code> = شماره‌ی نمایشی سفارش</span>
										<span><code>%status%</code> = وضعیت سفارش</span>
										<span><code>%total%</code> = مبلغ کل سفارش</span>
										<span><code>%customer_name%</code> = نام و نام‌خانوادگی مشتری</span>
										<span><code>%first_name%</code> = نام مشتری</span>
										<span><code>%last_name%</code> = نام‌خانوادگی مشتری</span>
										<span><code>%invoice_url%</code> = لینکِ فاکتور (چاپ/PDF)</span>
										<span><code>%items%</code> = محصولات + رنگ/سایز و تعداد</span>
										<span><code>%payment_method%</code> = روشِ پرداخت (مناسبِ پیامکِ مدیر)</span>
										<span><code>%payment_url%</code> = لینکِ پرداخت</span>
										<span><code>%shipping_method%</code> = روشِ ارسال</span>
										<span><code>%date%</code> = تاریخِ ثبتِ سفارش (شمسی)</span>
										<span><code>%email%</code> = ایمیلِ مشتری</span>
										<span><code>%phone%</code> = تلفن/موبایلِ مشتری</span>
										<span><code>%company%</code> = نامِ شرکت</span>
										<span><code>%address%</code> = آدرسِ کاملِ صورتحساب</span>
										<span><code>%address_1%</code> = آدرسِ ۱</span>
										<span><code>%address_2%</code> = آدرسِ ۲</span>
										<span><code>%city%</code> = شهر</span>
										<span><code>%state%</code> = استان</span>
										<span><code>%country%</code> = کشور</span>
										<span><code>%postcode%</code> = کدپستی</span>
										<span><code>%customer_note%</code> = یادداشتِ مشتری</span>
										<span><code>%transaction_id%</code> = شماره تراکنش</span>
										<span style="grid-column:1/-1; color:#9b9b9b; margin-top:2px;">— آدرسِ حمل‌ونقل: <code>%shipping_address%</code>، <code>%shipping_address_1%</code>، <code>%shipping_address_2%</code>، <code>%shipping_city%</code>، <code>%shipping_state%</code>، <code>%shipping_country%</code>، <code>%shipping_postcode%</code>، <code>%shipping_company%</code>، <code>%shipping_first_name%</code>، <code>%shipping_last_name%</code></span>
									</div>
									<div style="margin-top:6px; color:#9b9b9b;">📌 آدرسِ سایت به‌صورتِ خودکار (متنِ ثابت، بدونِ www) به انتهای پترن افزوده می‌شود؛ نیازی به نوشتنِ آن نیست و متغیرِ <code>%site%</code> وجود ندارد.</div>
								</div>
								<div style="display:flex; flex-wrap:wrap; gap:8px; align-items:center; margin-top:6px;">
									<?php $farazsms_has_pattern = trim( (string) ( $row[ $target . '_pattern' ] ?? '' ) ) !== ''; ?><?php if ( $farazsms_has_pattern ) : ?><button type="button" class="button button-primary farazsms-order-build-pattern" data-mode="edit" data-status="<?php echo esc_attr( $status ); ?>" data-target="<?php echo esc_attr( $target ); ?>" data-nonce="<?php echo esc_attr( $nonce ); ?>" style="padding:8px 20px; font-size:14px; font-weight:600; height:auto;">✏️ ویرایشِ پترنِ فعلی</button>
									<button type="button" class="button farazsms-order-build-pattern" data-mode="new" data-status="<?php echo esc_attr( $status ); ?>" data-target="<?php echo esc_attr( $target ); ?>" data-nonce="<?php echo esc_attr( $nonce ); ?>">➕ ساخت پترنِ جدید</button><?php else : ?><button type="button" class="button button-primary farazsms-order-build-pattern" data-mode="edit" data-status="<?php echo esc_attr( $status ); ?>" data-target="<?php echo esc_attr( $target ); ?>" data-nonce="<?php echo esc_attr( $nonce ); ?>" style="padding:8px 20px; font-size:14px; font-weight:600; height:auto;">⚡ ساخت پترن</button><?php endif; ?>
									<span id="farazsms-order-<?php echo esc_attr( $status . '-' . $target ); ?>-status" style="color:#9b9b9b; font-size:12px;"></span>
								</div>
								<p style="margin:6px 0 0; font-size:11px; color:#9b9b9b;">«ویرایش» متنِ پترنِ فعلی را به‌روزرسانی می‌کند (همان کد). اگر سایت را از دیتابیسِ سایتِ دیگری داپلیکیت کرده‌اید و دامنه عوض شده، «ساخت پترنِ جدید» را بزنید تا یک کدِ مستقل ساخته شود و پترنِ سایتِ قبلی دست‌نخورده بماند.</p>
							</div>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endforeach; ?>
			</div>
			
		
			<?php
			// v3.22.20: بخشِ «پیامکِ موجودی» داخلِ همین فرم رندر می‌شود تا با یک دکمه ذخیره شود.
			do_action( 'farazsms_orders_sms_extra_sections' );
			?>
			<!-- نوارِ ذخیره‌ی شناور — همیشه پایینِ صفحه دیده می‌شود -->
			<div style="position:sticky; bottom:0; z-index:60; margin-top:22px; padding:14px 18px; background:#ffffff; border:1px solid #e1e1e1; border-radius:12px; box-shadow:0 -4px 18px rgba(15,23,42,0.10); display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
				<button type="submit" name="farazsms_order_sms_save" value="1" class="button button-primary" style="padding:11px 34px; font-size:15px; font-weight:800; height:auto;">💾 ذخیره‌ی همه‌ی تنظیمات</button>
				<span style="color:#9b9b9b; font-size:12.5px;">این تنها دکمه‌ی ذخیره است و <strong>همه‌ی</strong> تنظیماتِ این صفحه (سفارشات + موجودی) را با هم ذخیره می‌کند.</span>
			</div>
		</form>
		<script>
		(function(){
			document.addEventListener('click', function(e){
				var btn = e.target && e.target.closest ? e.target.closest('.farazsms-order-build-pattern') : null;
				if (!btn) return;
				e.preventDefault();
				var mode = btn.dataset.mode || 'edit';
				if (mode === 'new' && !confirm('یک پترنِ کاملاً جدید (کدِ جدید) ساخته شود؟ برای سایتی که دامنه‌اش عوض شده مناسب است.')) { return; }
				var key = btn.dataset.status + '-' + btn.dataset.target;
				var msg = document.getElementById('farazsms-order-' + key + '-message');
				var pat = document.getElementById('farazsms-order-' + key + '-pattern');
				var stat = document.getElementById('farazsms-order-' + key + '-status');
				var fd = new FormData();
				fd.append('action', 'farazsms_order_sms_build_pattern');
				fd.append('nonce', btn.dataset.nonce);
				fd.append('status', btn.dataset.status);
				fd.append('target', btn.dataset.target);
				fd.append('mode', mode);
				fd.append('message', msg ? msg.value : '');
				btn.disabled = true; if (stat) stat.textContent = (mode === 'new' ? 'در حال ساختِ پترنِ جدید…' : 'در حال ویرایش…');
				fetch(ajaxurl, {method:'POST', credentials:'same-origin', body:fd}).then(function(r){return r.json();}).then(function(res){
					if (res && res.success && res.data && res.data.pattern_code) { if (pat) pat.value = res.data.pattern_code; if (stat) { stat.textContent = '✓ ' + res.data.message; stat.style.color = '#0c9765'; } }
					else { var m = res && res.data && res.data.message ? res.data.message : 'خطای ناشناخته'; if (stat) { stat.textContent = '✗ ' + m; stat.style.color = '#d52a16'; } }
				}).catch(function(){ if (stat) { stat.textContent = '✗ خطای ارتباط'; stat.style.color = '#d52a16'; } }).finally(function(){ btn.disabled = false; });
			});
		})();
		</script>
	</div>
	<?php
}
