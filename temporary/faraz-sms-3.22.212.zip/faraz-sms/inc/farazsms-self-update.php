<?php
/**
 * Self-Hosted Update System — v3.16.0
 *
 * این ماژول به افزونه اجازه می‌دهد بدون نیاز به مخزن WordPress.org،
 * مستقیم از GitLab خودی شرکت (gitlab.faraz.club) به‌روز شود.
 *
 * چطور کار می‌کند:
 *  ۱) هر ۱۲ ساعت یک‌بار WP خودش transient `update_plugins` را refresh می‌کند.
 *  ۲) ما به filter `pre_set_site_transient_update_plugins` hook می‌زنیم،
 *     آخرین release را از GitLab Releases API می‌خوانیم.
 *  ۳) اگر version جدیدتر بود، آن را به لیست آپدیت‌های WP اضافه می‌کنیم.
 *  ۴) WP خودش zip را دانلود می‌کند، extract، فعال‌سازی مجدد.
 *  ۵) اگر toggle auto-update روشن باشد، **کاربر مداخله‌ای نمی‌کند**.
 *
 * چگونه release بسازیم در GitLab:
 *  ۱) tag بزنید: `git tag v3.16.5 && git push --tags`
 *  ۲) در GitLab UI → Deployments → Releases → New Release از این tag.
 *  ۳) zip را به‌عنوان Asset Link آپلود کنید (URL باید با .zip تمام شود).
 *  ۴) (اختیاری) خط GitLab CI:
 *       release:
 *         stage: release
 *         script:
 *           - zip -r faraz-sms-${CI_COMMIT_TAG}.zip faraz-sms
 *           - 'curl --request POST --header "JOB-TOKEN: $CI_JOB_TOKEN" ...'
 *
 * ساختار release expected:
 *   - tag_name: "v3.16.5"  (با یا بدون پیشوند v)
 *   - assets.links[]: حداقل یک URL که با .zip تمام شود
 *   - description: changelog (markdown)
 *
 * ملاحظات امنیتی:
 *  - فقط HTTPS — هیچ HTTP fallback.
 *  - timeout کوتاه (۸ ثانیه) تا admin pages کند نشوند.
 *  - cache منفی ۱ ساعته اگر سرور down باشد.
 *  - SHA256 verification optional (اگر در description تگ release موجود باشد).
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

// ============================================================================
// Configuration — قابل override از wp-config.php
// ============================================================================

if ( ! defined( 'FARAZSMS_UPDATE_GITLAB_BASE' ) ) {
	define( 'FARAZSMS_UPDATE_GITLAB_BASE', 'https://gitlab.faraz.club' );
}

if ( ! defined( 'FARAZSMS_UPDATE_PROJECT' ) ) {
	// مسیر namespace/project در GitLab — قابل override در wp-config.php
	define( 'FARAZSMS_UPDATE_PROJECT', 'wordpress/farazsms-dedicated-plugin' );
}

if ( ! defined( 'FARAZSMS_UPDATE_CACHE_TTL' ) ) {
	define( 'FARAZSMS_UPDATE_CACHE_TTL', 12 * HOUR_IN_SECONDS );
}

/** از چند روز سکوت به بعد، «کهنه» شمرده می‌شود. */
if ( ! defined( 'FARAZSMS_UPDATE_STALE_DAYS' ) ) {
	define( 'FARAZSMS_UPDATE_STALE_DAYS', 14 );
}

const FARAZSMS_SELF_UPDATE_TRANSIENT     = 'farazsms_self_update_info_v2';
const FARAZSMS_SELF_UPDATE_FAIL_TRANSIENT = 'farazsms_self_update_fail';

// ============================================================================
// Fetch latest release from GitLab API
// ============================================================================

/**
 * ساختِ یک ساختارِ شبه‌Release از آخرین tag (وقتی Release رسمی وجود ندارد).
 * بالاترین tagِ نسخه‌ای (vX.Y.Z) را پیدا و آرشیوِ سورسِ آن را به‌عنوان لینکِ دانلود برمی‌گرداند.
 * (.gitattributes آرشیو را تمیز می‌کند و فیلترِ upgrader_source_selection پوشه را faraz-sms می‌کند.)
 *
 * @return array|null
 */
function farazsms_self_update_release_from_latest_tag() {
	$project = rawurlencode( FARAZSMS_UPDATE_PROJECT );
	$url     = trailingslashit( FARAZSMS_UPDATE_GITLAB_BASE )
	           // ⚠️ ترتیب **صریح** است، نه پیش‌فرضِ سرور: مخزن ۲۷۰+ تگ دارد و ما
	           // فقط صفحه‌ی اول را می‌گیریم؛ با ترتیبِ ناگفته، تازه‌ترین تگ
	           // می‌توانست بیرون از این ۱۰۰ بیفتد و تشخیصِ نسخه دوباره کور شود —
	           // همان باگی که این مسیر برای رفعش نوشته شد.
	           . 'api/v4/projects/' . $project . '/repository/tags?per_page=100&order_by=updated&sort=desc';

	$response = wp_remote_get( $url, array(
		'timeout'    => 8,
		'sslverify'  => true,
		'user-agent' => 'FarazSMS-Updater/' . FARAZSMS_PLUGIN_VERSION,
	) );
	if ( is_wp_error( $response ) || (int) wp_remote_retrieve_response_code( $response ) !== 200 ) {
		return null;
	}
	$tags = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( ! is_array( $tags ) || empty( $tags ) ) {
		return null;
	}

	$best_tag = '';
	$best_ver = '0.0.0';
	foreach ( $tags as $t ) {
		$name = isset( $t['name'] ) ? (string) $t['name'] : '';
		$ver  = ltrim( $name, 'vV' );
		if ( ! preg_match( '/^\d+(\.\d+){1,3}$/', $ver ) ) {
			continue;
		}
		if ( version_compare( $ver, $best_ver, '>' ) ) {
			$best_ver = $ver;
			$best_tag = $name;
		}
	}
	if ( $best_tag === '' ) {
		return null;
	}

	$archive = trailingslashit( FARAZSMS_UPDATE_GITLAB_BASE )
	           . 'api/v4/projects/' . $project . '/repository/archive.zip?sha=' . rawurlencode( $best_tag );

	return array(
		'tag_name'    => $best_tag,
		'released_at' => '',
		'description' => 'ساخته‌شده از tag (بدون Release رسمی).',
		'assets'      => array(
			'sources' => array(
				array( 'format' => 'zip', 'url' => $archive ),
			),
		),
	);
}

/**
 * تازه‌ترینِ دو کاندیدای نسخه (Release رسمی و tag).
 *
 * ⚠️ چرا تابعِ جدا: تصمیمِ «کدام تازه‌تر است» باید یک‌جا و آزمودنی باشد. همین
 * مقایسه‌ی ساده بود که نبودش، کلِ کانالِ به‌روزرسانی را برای همه‌ی سایت‌ها کور
 * کرده بود.
 *
 * Releaseِ رسمی در تساوی برنده است: اگر برای همان نسخه Release ساخته شده
 * باشد، asset و SHA256 دارد و آن مسیر بهتر است.
 *
 * @param array|null $release
 * @param array|null $from_tag
 * @return array|null
 */
function farazsms_self_update_newer_of( $release, $from_tag ) {
	$ver = static function ( $candidate ) {
		if ( ! is_array( $candidate ) || empty( $candidate['tag_name'] ) ) {
			return '';
		}
		$v = ltrim( (string) $candidate['tag_name'], 'vV' );
		return preg_match( '/^\d+(\.\d+){1,3}$/', $v ) ? $v : '';
	};
	$rv = $ver( $release );
	$tv = $ver( $from_tag );

	if ( $rv === '' ) {
		return $tv === '' ? null : $from_tag;
	}
	if ( $tv === '' ) {
		return $release;
	}
	return version_compare( $tv, $rv, '>' ) ? $from_tag : $release;
}

/**
 * Fetch آخرین release از GitLab — با cache.
 *
 * @return object|null
 */
function farazsms_self_update_fetch_remote_info() {
	$cached = get_transient( FARAZSMS_SELF_UPDATE_TRANSIENT );
	if ( $cached !== false ) {
		// cache می‌تواند null باشد (یعنی fail شد و don't retry) یا object معتبر
		return is_object( $cached ) ? $cached : null;
	}

	$project = rawurlencode( FARAZSMS_UPDATE_PROJECT );
	$url     = trailingslashit( FARAZSMS_UPDATE_GITLAB_BASE )
	           . 'api/v4/projects/' . $project . '/releases?per_page=1';

	$response = wp_remote_get( $url, array(
		'timeout'     => 8,
		'sslverify'   => true,
		'redirection' => 3,
		'user-agent'  => 'FarazSMS-Updater/' . FARAZSMS_PLUGIN_VERSION,
	) );

	if ( is_wp_error( $response ) ) {
		// cache منفی کوتاه — اگر شبکه قطع بود، دائماً retry نکن
		set_transient( FARAZSMS_SELF_UPDATE_TRANSIENT, 0, HOUR_IN_SECONDS );
		set_transient( FARAZSMS_SELF_UPDATE_FAIL_TRANSIENT, $response->get_error_message(), DAY_IN_SECONDS );
		return null;
	}

	$code = (int) wp_remote_retrieve_response_code( $response );
	$body = wp_remote_retrieve_body( $response );

	if ( $code !== 200 ) {
		// ۴۰۴ معمولاً یعنی منبعِ آپدیت در دسترس نیست. متنِ کاربرپسند (بدونِ افشای جزئیاتِ سرور).
		$hint = $code === 404
			? 'در حالِ حاضر نسخه‌ای روی سرورِ فراز اس‌ام‌اس در دسترس نیست. کمی بعد دوباره تلاش کنید.'
			: 'خطای ' . $code . ' در ارتباط با سرورِ فراز اس‌ام‌اس';
		set_transient( FARAZSMS_SELF_UPDATE_TRANSIENT, 0, HOUR_IN_SECONDS );
		set_transient( FARAZSMS_SELF_UPDATE_FAIL_TRANSIENT, $hint, DAY_IN_SECONDS );
		return null;
	}

	$json    = json_decode( $body, true );
	$release = ( is_array( $json ) && ! empty( $json[0] ) ) ? $json[0] : null;

	// ⚠️ v3.22.205 — **تازه‌ترینِ** بین Release و tag، نه «Release وگرنه tag».
	//
	// شرطِ قبلی فقط وقتی سراغِ tag می‌رفت که هیچ Releaseای وجود نداشته باشد. ولی
	// حالتِ عادیِ این مخزن این است: Release برای بعضی نسخه‌ها ساخته شده و برای
	// بعضی نه. آن‌وقت آخرین Release از آخرین tag عقب می‌مانْد و به‌روزرسانی
	// **برای همه‌ی سایت‌ها** می‌گفت «نسخه‌ی جدیدی نیست» — نسخه منتشر شده بود،
	// تگ پوش شده بود، و هیچ‌کس آن را نمی‌گرفت. (روی سایتِ واقعی دیده شد: آخرین
	// Release ۳٫۲۲٫۲۰۳ بود و آخرین tag ۳٫۲۲٫۲۰۴.)
	$from_tag = farazsms_self_update_release_from_latest_tag();
	$release  = farazsms_self_update_newer_of( $release, $from_tag );
	if ( ! is_array( $release ) ) {
		set_transient( FARAZSMS_SELF_UPDATE_TRANSIENT, 0, HOUR_IN_SECONDS );
		set_transient( FARAZSMS_SELF_UPDATE_FAIL_TRANSIENT, 'نسخه‌ی معتبری روی سرورِ فراز اس‌ام‌اس یافت نشد', DAY_IN_SECONDS );
		return null;
	}
	$tag     = isset( $release['tag_name'] ) ? (string) $release['tag_name'] : '';
	$version = ltrim( $tag, 'vV' );

	if ( ! $version || ! preg_match( '/^\d+(\.\d+){1,3}$/', $version ) ) {
		set_transient( FARAZSMS_SELF_UPDATE_TRANSIENT, 0, HOUR_IN_SECONDS );
		set_transient( FARAZSMS_SELF_UPDATE_FAIL_TRANSIENT, 'فرمتِ نسخه نامعتبر: ' . $tag, DAY_IN_SECONDS );
		return null;
	}

	// تعیینِ لینکِ دانلود:
	// ۱) اگر کاربر یک فایلِ .zip به‌عنوان asset link به Release چسبانده باشد، همان (تمیزترین).
	// ۲) وگرنه آرشیوِ سورسِ tag را خودمان با https و endpointِ API می‌سازیم.
	// مهم (رفع خطای «cURL error 7: port 80»): از URLِ source که خودِ گیت‌لب می‌سازد استفاده
	// نمی‌کنیم چون ممکن است http باشد و به پورت 80 وصل شود (که بسته است). URLِ خودمان https است.
	$download_url = '';
	if ( ! empty( $release['assets']['links'] ) && is_array( $release['assets']['links'] ) ) {
		foreach ( $release['assets']['links'] as $link ) {
			$lurl = isset( $link['url'] ) ? (string) $link['url'] : '';
			if ( $lurl && preg_match( '/\.zip(\?|$)/i', $lurl ) ) {
				$download_url = $lurl;
				break;
			}
		}
	}
	if ( $download_url === '' ) {
		$download_url = trailingslashit( FARAZSMS_UPDATE_GITLAB_BASE )
		                . 'api/v4/projects/' . rawurlencode( FARAZSMS_UPDATE_PROJECT )
		                . '/repository/archive.zip?sha=' . rawurlencode( $tag );
	}
	// اجبارِ https — هرگز نباید روی پورت 80 (http) وصل شود.
	$download_url = preg_replace( '#^http://#i', 'https://', $download_url );

	// استخراج SHA256 (اختیاری) از description — اگر کاربر در changelog نوشت "SHA256: abc..."
	$sha256 = '';
	if ( ! empty( $release['description'] ) && preg_match( '/SHA256:\s*([a-f0-9]{64})/i', $release['description'], $m ) ) {
		$sha256 = strtolower( $m[1] );
	}

	$info = (object) array(
		'version'      => $version,
		'tag_name'     => $tag,
		'name'         => 'فراز اس ام اس',
		'slug'         => 'faraz-sms',
		'download_url' => $download_url,
		'sha256'       => $sha256,
		'description'  => isset( $release['description'] ) ? (string) $release['description'] : '',
		'released_at'  => isset( $release['released_at'] ) ? (string) $release['released_at'] : '',
		'homepage'     => 'https://farazsms.com/',
		'author'       => '<a href="https://farazsms.com">FarazSMS</a>',
		'tested'       => '6.7',
		'requires'     => '5.8',
		'requires_php' => '7.4',
		'fetched_at'   => current_time( 'mysql' ),
	);

	set_transient( FARAZSMS_SELF_UPDATE_TRANSIENT, $info, FARAZSMS_UPDATE_CACHE_TTL );
	delete_transient( FARAZSMS_SELF_UPDATE_FAIL_TRANSIENT );
	// v3.22.176: زمانِ آخرین بررسیِ **موفق**. transientِ خطا ۲۴ ساعته است، پس یک سایتِ
	// ماه‌ها بی‌به‌روزرسانی هیچ نشانه‌ی دائمی نداشت؛ این مهر باعث می‌شود سکوتِ طولانی دیده شود.
	update_option( 'farazsms_self_update_last_ok', time(), false );
	return $info;
}

/**
 * چند روز از آخرین بررسیِ موفقِ به‌روزرسانی گذشته؟ (null یعنی هرگز موفق نبوده)
 *
 * @return int|null
 */
function farazsms_self_update_days_since_ok() {
	$ts = (int) get_option( 'farazsms_self_update_last_ok', 0 );
	if ( $ts <= 0 ) {
		// سایتی که تا پیش از این نسخه مهرِ موفقیت نداشت ولی کشِ سالمِ نسخه دارد، در واقع
		// در حال به‌روزرسانی بوده؛ همین حالا مهر بزن تا هشدارِ کاذب نگیرد.
		if ( get_transient( FARAZSMS_SELF_UPDATE_TRANSIENT ) ) {
			update_option( 'farazsms_self_update_last_ok', time(), false );
			return 0;
		}
		return null;
	}
	return (int) floor( ( time() - $ts ) / DAY_IN_SECONDS );
}

/**
 * اعلانِ پیشخوان وقتی به‌روزرسانی مدت‌هاست بررسی نشده.
 *
 * چرا لازم است: مسیرِ به‌روزرسانی بی‌صدا شکست می‌خورد (کشِ منفی، شبکه‌ی مسدود، خطای
 * سرور) و تنها ردش صفحه‌ی «به‌روزرسانی افزونه» بود که مدیر معمولاً بازش نمی‌کند.
 * نتیجه: سایت ماه‌ها روی نسخه‌ی قدیمی می‌مانْد و باگ‌های رفع‌شده «همچنان باز» به‌نظر می‌رسیدند.
 */
add_action( 'admin_notices', 'farazsms_self_update_stale_notice' );
function farazsms_self_update_stale_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	// فقط روی صفحاتِ خودِ افزونه، تا پیشخوانِ سایت شلوغ نشود.
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	if ( strpos( $page, 'farazsms' ) !== 0 ) {
		return;
	}
	if ( get_option( 'farazsms_self_update_enabled', '1' ) !== '1' ) {
		return; // مدیر خودش خاموشش کرده.
	}

	// صفحه‌ی خودِ به‌روزرسانی وضعیت را کامل نشان می‌دهد؛ هشدارِ تکراری آنجا لازم نیست.
	if ( $page === 'farazsms-updates' ) {
		return;
	}

	$days  = farazsms_self_update_days_since_ok();
	$error = farazsms_self_update_last_error();

	// ⚠️ «یک خطای گذرا» با «سکوتِ طولانی» یکی نیست: transientِ خطا ۲۴ ساعت می‌ماند، پس
	// یک قطعیِ لحظه‌ایِ شبکه نباید روی سایتی که دیروز موفق بوده هشدارِ کهنگی بدهد.
	// شرط فقط کهنگیِ واقعی است: یا مدت‌هاست موفق نبوده، یا هرگز موفق نبوده و خطا هم دارد.
	$stale = ( $days !== null && $days >= FARAZSMS_UPDATE_STALE_DAYS )
		|| ( $days === null && ! empty( $error ) );
	if ( ! $stale ) {
		return;
	}

	// مدیر می‌تواند هشدار را برای یک هفته ببندد (سایتی که عمداً به سرور دسترسی ندارد).
	if ( get_transient( 'farazsms_self_update_stale_dismissed' ) ) {
		return;
	}

	$when = ( $days === null )
		? __( 'تا کنون هیچ بررسیِ موفقی ثبت نشده است.', 'farazsms' )
		: sprintf(
			/* translators: %d: تعداد روز */
			__( 'آخرین بررسیِ موفق حدود %d روز پیش بوده است.', 'farazsms' ),
			$days
		);

	echo '<div class="notice notice-warning is-dismissible" style="border-right:4px solid #dba617; padding:12px 16px;">';
	echo '<p><strong>' . esc_html__( 'به‌روزرسانیِ فراز اس ام اس مدتی است بررسی نشده', 'farazsms' ) . '</strong></p>';
	echo '<p>' . esc_html( $when ) . ' ' . esc_html__( 'تا وقتی این وضعیت ادامه دارد، نسخه‌های تازه (و رفعِ باگ‌های آن‌ها) به این سایت نمی‌رسد و پیامکِ اطلاع‌رسانیِ بروزرسانی هم ارسال نمی‌شود.', 'farazsms' ) . '</p>';
	if ( ! empty( $error ) ) {
		echo '<p>' . esc_html__( 'آخرین خطا:', 'farazsms' ) . ' <code>' . esc_html( (string) $error ) . '</code></p>';
	}
	echo '<p><a class="button button-primary" href="' . esc_url( admin_url( 'admin.php?page=farazsms-updates' ) ) . '">'
		. esc_html__( 'بررسیِ دستیِ به‌روزرسانی', 'farazsms' ) . '</a> ';
	echo '<a class="button" href="' . esc_url( wp_nonce_url( admin_url( 'admin.php?page=' . $page . '&farazsms_dismiss_stale=1' ), 'farazsms_dismiss_stale' ) ) . '">'
		. esc_html__( 'یک هفته یادآوری نکن', 'farazsms' ) . '</a></p>';
	echo '</div>';
}

/** بستنِ هشدارِ کهنگی برای یک هفته. */
add_action( 'admin_init', 'farazsms_self_update_stale_dismiss' );
function farazsms_self_update_stale_dismiss() {
	if ( empty( $_GET['farazsms_dismiss_stale'] ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'farazsms_dismiss_stale' ) ) {
		return;
	}
	set_transient( 'farazsms_self_update_stale_dismissed', 1, 7 * DAY_IN_SECONDS );
}

/**
 * هنگام نصبِ آپدیت، نامِ پوشه‌ی استخراج‌شده را به «faraz-sms» تغییر بده.
 *
 * چرا لازم است: zipِ سورسِ خودکارِ گیت‌لب، پوشه‌ای با نامی مثل
 * «farazsms-dedicated-plugin-v3.20.30-<sha>» می‌سازد، نه «faraz-sms». بدونِ این فیلتر،
 * وردپرس آن را به‌عنوان افزونه‌ی جدید نصب می‌کند نه آپدیتِ افزونه‌ی فعلی. با این فیلتر،
 * کاربر فقط کافی است یک Release بسازد (نیازی به آپلودِ دستیِ zip نیست).
 * فقط روی آپدیتِ همین افزونه اثر دارد (سایر افزونه‌ها دست‌نخورده).
 */
add_filter( 'upgrader_source_selection', 'farazsms_self_update_rename_source', 10, 4 );
function farazsms_self_update_rename_source( $source, $remote_source, $upgrader, $hook_extra = array() ) {
	global $wp_filesystem;
	if ( empty( $hook_extra['plugin'] ) ) {
		return $source;
	}
	$basename = defined( 'FARAZSMS_PLUGIN_BASENAME' ) ? FARAZSMS_PLUGIN_BASENAME : 'faraz-sms/faraz-sms.php';
	if ( $hook_extra['plugin'] !== $basename ) {
		return $source; // آپدیتِ افزونه‌ی دیگری است — کاری نکن.
	}
	if ( ! $wp_filesystem ) {
		return $source;
	}
	$desired_dir = trailingslashit( $remote_source ) . 'faraz-sms';
	// از قبل درست است (asset zipِ آماده یا پوشه‌ی درست).
	if ( untrailingslashit( $source ) === untrailingslashit( $desired_dir )
		|| basename( untrailingslashit( $source ) ) === 'faraz-sms' ) {
		return $source;
	}
	// اگر مقصد از قبل وجود دارد (تلاشِ قبلی)، پاکش کن تا move/copy تمیز باشد.
	if ( $wp_filesystem->exists( $desired_dir ) ) {
		$wp_filesystem->delete( $desired_dir, true );
	}
	// ۱) اول move (سریع‌ترین).
	if ( $wp_filesystem->move( untrailingslashit( $source ), untrailingslashit( $desired_dir ) ) ) {
		return trailingslashit( $desired_dir );
	}
	// ۲) v3.22.9: fallback — روی هاست‌هایی که move() شکست می‌خورد (cross-device / FTPِ فایل‌سیستم /
	//    مجوزها)، به‌جای رهاکردن (که باعث می‌شد افزونه در پوشه‌ی اشتباه نصب شود و آپدیت «هیچ اثری
	//    نداشته باشد»)، کلِ پوشه را با copy_dir کپی و سپس منبع را پاک می‌کنیم.
	if ( ! function_exists( 'copy_dir' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}
	$wp_filesystem->mkdir( $desired_dir );
	$copied = copy_dir( untrailingslashit( $source ), untrailingslashit( $desired_dir ) );
	if ( $copied === true ) {
		$wp_filesystem->delete( untrailingslashit( $source ), true );
		return trailingslashit( $desired_dir );
	}
	// اگر هیچ‌کدام نشد، دستِ‌کم پوشه‌ی نیمه‌ساخته را پاک کن تا زباله نماند.
	if ( $wp_filesystem->exists( $desired_dir ) ) {
		$wp_filesystem->delete( $desired_dir, true );
	}
	return $source;
}

/**
 * پیام آخرین خطای ارتباط (برای نمایش در UI تنظیمات)
 */
function farazsms_self_update_last_error() {
	return get_transient( FARAZSMS_SELF_UPDATE_FAIL_TRANSIENT );
}

// ============================================================================
// Hook 1: تزریق آپدیت به update transient
// ============================================================================

add_filter( 'pre_set_site_transient_update_plugins', 'farazsms_self_update_inject' );
/**
 * آیکونِ افزونه برای صفحه‌ی به‌روزرسانیِ وردپرس (لوگوی فراز).
 * اگر فایلِ آیکون موجود نباشد، آرایه‌ی خالی برمی‌گرداند تا تصویرِ شکسته نمایش داده نشود.
 *
 * @return array
 */
function farazsms_self_update_icons() {
	if ( ! defined( 'FARAZSMS_PLUGIN_FILE' ) ) {
		return array();
	}
	$dir = plugin_dir_path( FARAZSMS_PLUGIN_FILE ) . 'assets/img/';
	$url = plugins_url( 'assets/img/', FARAZSMS_PLUGIN_FILE );
	if ( ! file_exists( $dir . 'icon-256x256.png' ) ) {
		return array();
	}
	$icons = array(
		'2x'      => $url . 'icon-256x256.png',
		'default' => $url . 'icon-256x256.png',
	);
	if ( file_exists( $dir . 'icon-128x128.png' ) ) {
		$icons['1x'] = $url . 'icon-128x128.png';
	}
	return $icons;
}

function farazsms_self_update_inject( $transient ) {
	if ( empty( $transient ) || ! is_object( $transient ) ) {
		return $transient;
	}
	// در صورت empty($transient->checked) هم adding می‌کنیم — تا «Check for updates»
	// در صفحه افزونه‌ها بلافاصله جواب بدهد.

	$info = farazsms_self_update_fetch_remote_info();
	if ( ! $info || empty( $info->version ) || empty( $info->download_url ) ) {
		return $transient;
	}

	$basename = defined( 'FARAZSMS_PLUGIN_BASENAME' ) ? FARAZSMS_PLUGIN_BASENAME : 'faraz-sms/faraz-sms.php';
	$current  = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '0.0.0';

	if ( version_compare( $info->version, $current, '>' ) ) {
		$obj = (object) array(
			'slug'         => 'faraz-sms',
			'plugin'       => $basename,
			'new_version'  => $info->version,
			'url'          => $info->homepage,
			'package'      => $info->download_url,
			'tested'       => $info->tested,
			'requires_php' => $info->requires_php,
			'icons'        => farazsms_self_update_icons(),
			'banners'      => array(),
			'compatibility'=> new stdClass(),
		);
		if ( ! isset( $transient->response ) ) {
			$transient->response = array();
		}
		$transient->response[ $basename ] = $obj;
	} else {
		// در no_update تزریق کنیم تا «هیچ آپدیت موجود نیست» در WP درست نمایش داده شود
		if ( ! isset( $transient->no_update ) ) {
			$transient->no_update = array();
		}
		$transient->no_update[ $basename ] = (object) array(
			'slug'        => 'faraz-sms',
			'plugin'      => $basename,
			'new_version' => $info->version,
			'url'         => $info->homepage,
			'package'     => '',
			'icons'       => farazsms_self_update_icons(),
			'banners'     => array(),
		);
	}

	return $transient;
}

// ============================================================================
// Hook 2: پاپ‌آپ «جزئیات» در صفحه افزونه‌ها
// ============================================================================

add_filter( 'plugins_api', 'farazsms_self_update_plugin_info', 20, 3 );
function farazsms_self_update_plugin_info( $res, $action, $args ) {
	if ( $action !== 'plugin_information' ) {
		return $res;
	}
	if ( empty( $args->slug ) || $args->slug !== 'faraz-sms' ) {
		return $res;
	}

	$info = farazsms_self_update_fetch_remote_info();
	if ( ! $info ) {
		return $res;
	}

	$res = new stdClass();
	$res->name           = $info->name;
	$res->slug           = 'faraz-sms';
	$res->version        = $info->version;
	$res->tested         = $info->tested;
	$res->requires       = $info->requires;
	$res->requires_php   = $info->requires_php;
	$res->author         = $info->author;
	$res->author_profile = $info->homepage;
	$res->homepage       = $info->homepage;
	$res->download_link  = $info->download_url;
	$res->trunk          = $info->download_url;
	$res->last_updated   = $info->released_at;

	// تبدیل markdown changelog به HTML ساده (بدون پارسر کامل — basic newline → br)
	$changelog_html = '<h4>' . esc_html( $info->tag_name ) . '</h4>';
	$changelog_html .= '<pre style="white-space:pre-wrap; direction:rtl; font-family:inherit;">'
	                   . esc_html( $info->description )
	                   . '</pre>';

	$res->sections = array(
		'description' => 'افزونه فراز اس‌ام‌اس — سیستم جامع پیامک‌رسانی برای ووکامرس، فرم‌ها، نظرسنجی، سبد رهاشده، کش‌بک و بسیار بیشتر.',
		'changelog'   => $changelog_html,
	);
	$res->banners = array();
	$res->icons   = farazsms_self_update_icons();

	return $res;
}

// ============================================================================
// Hook 3: auto-update — فعال به‌صورت پیش‌فرض، با toggle قابل خاموش‌سازی
// ============================================================================

add_filter( 'auto_update_plugin', 'farazsms_self_update_auto_decision', 10, 2 );
function farazsms_self_update_auto_decision( $update, $item ) {
	$basename = defined( 'FARAZSMS_PLUGIN_BASENAME' ) ? FARAZSMS_PLUGIN_BASENAME : 'faraz-sms/faraz-sms.php';
	if ( ! is_object( $item ) || empty( $item->plugin ) || $item->plugin !== $basename ) {
		return $update;
	}
	$enabled = get_option( 'farazsms_self_update_enabled', '1' );
	return ( $enabled === '1' );
}

// v3.22.9: فیلترِ دومِ تکراریِ upgrader_source_selection حذف شد — تغییرِنامِ پوشه اکنون
// به‌صورتِ یکجا و مقاوم (با fallbackِ copy_dir) در farazsms_self_update_rename_source انجام می‌شود.

// ============================================================================
// امنیت: تأییدِ یکپارچگیِ فایل با SHA256 پیش از نصب (روشِ استانداردِ دنیا).
// اگر Release مقدارِ «SHA256: <hash>» را در توضیحات داشته باشد، فایلِ دانلودشده را خودمان
// دانلود و هش را بررسی می‌کنیم؛ اگر نخواند، نصب برای امنیت متوقف می‌شود. اگر checksum نباشد،
// رفتار مثلِ قبل است (WP خودش دانلود می‌کند) — پس هیچ رگرسیونی روی نصب‌های بدونِ checksum نیست.
// ============================================================================

add_filter( 'upgrader_pre_download', 'farazsms_self_update_verify_download', 10, 4 );
function farazsms_self_update_verify_download( $reply, $package, $upgrader, $hook_extra = array() ) {
	if ( false !== $reply ) {
		return $reply; // پلاگینِ دیگری قبلاً جواب داده.
	}
	$info = farazsms_self_update_fetch_remote_info();
	if ( ! $info || empty( $info->download_url ) || $package !== $info->download_url ) {
		return $reply; // این پکیجِ ما نیست.
	}
	if ( empty( $info->sha256 ) ) {
		// ⚠️ نصبِ بدونِ راستی‌آزمایی — و از v3.22.205 این دیگر حالتِ نادر نیست.
		//
		// checksum فقط از توضیحاتِ Release خوانده می‌شود؛ کاندیدایی که از tag
		// ساخته می‌شود هرگز آن را ندارد. حالا که تازه‌ترینِ دو کاندیدا برنده
		// می‌شود، مسیرِ tag حالتِ **عادی** است، پس بی‌صدا ردشدن از این دروازه
		// یعنی امنیتِ نمایشی. متوقف نمی‌کنیم (وگرنه به‌روزرسانی برای همه
		// می‌ایستد) ولی رد می‌گذاریم تا قابلِ دیدن باشد.
		farazsms_send_diag_log( '', '', 'api_error:بسته‌ی نسخه‌ی ' . ( isset( $info->version ) ? $info->version : '?' ) . ' بدونِ checksum نصب شد (برای این نسخه Release ساخته نشده است)', array(
			'source'    => 'self-update',
			'http_code' => 0,
			'detail'    => isset( $info->tag_name ) ? (string) $info->tag_name : '',
		) );
		return $reply; // روالِ عادیِ WP.
	}
	if ( ! function_exists( 'download_url' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}
	$tmp = download_url( $package );
	if ( is_wp_error( $tmp ) ) {
		return $tmp;
	}
	$actual = strtolower( (string) hash_file( 'sha256', $tmp ) );
	if ( ! hash_equals( $info->sha256, $actual ) ) {
		if ( file_exists( $tmp ) ) {
			wp_delete_file( $tmp );
		}
		return new WP_Error(
			'farazsms_checksum_mismatch',
			'checksumِ فایلِ دانلودشده با نسخه‌ی سرورِ فراز اس‌ام‌اس مطابقت ندارد؛ نصب برای امنیت متوقف شد (احتمالِ خرابیِ دانلود یا دستکاری).'
		);
	}
	return $tmp; // مسیرِ فایلِ محلیِ تأییدشده — WP از همین برای نصب استفاده می‌کند.
}

// ============================================================================
// Force-check handler — کاربر دکمه «بررسی اکنون» را می‌زند
// ============================================================================

/**
 * v3.22.65: ریدایرکتِ مقاوم. اگر روی هاست، display_errors روشن باشد و یک نوتیسِ PHP
 * (مثلِ اخطارِ ترجمه‌ی زودهنگامِ WP 6.7) پیش از این چاپ شده باشد، wp_safe_redirect
 * به‌خاطرِ «headers already sent» می‌شکند و صفحه سفید می‌شود. اینجا به‌جای صفحه‌سفید،
 * با JS/meta ریدایرکت می‌کنیم تا کاربر گیر نکند و آپدیت رها نشود.
 */
function farazsms_self_update_safe_redirect( $url ) {
	if ( ! headers_sent() ) {
		wp_safe_redirect( $url );
		exit;
	}
	// اعتبارسنجیِ host مثلِ مسیرِ اصلی (wp_safe_redirect) تا این شاخه هم open-redirect نشود.
	$safe = wp_validate_redirect( $url, admin_url( 'admin.php?page=farazsms-updates' ) );
	$safe = wp_sanitize_redirect( $safe );
	echo '<meta http-equiv="refresh" content="0;url=' . esc_attr( $safe ) . '">';
	echo '<script>window.location.replace(' . wp_json_encode( $safe ) . ');</script>';
	echo '<p style="font-family:Tahoma,sans-serif;direction:rtl;padding:16px">در حال انتقال… اگر منتقل نشدید <a href="' . esc_url( $safe ) . '">اینجا کلیک کنید</a>.</p>';
	exit;
}

add_action( 'admin_post_farazsms_self_update_force_check', 'farazsms_self_update_force_check_handler' );
function farazsms_self_update_force_check_handler() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی غیرمجاز.', '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'farazsms_self_update_force_check' );

	delete_transient( FARAZSMS_SELF_UPDATE_TRANSIENT );
	delete_transient( FARAZSMS_SELF_UPDATE_FAIL_TRANSIENT );
	delete_site_transient( 'update_plugins' );

	$ref = wp_get_referer();
	farazsms_self_update_safe_redirect( add_query_arg( 'farazsms_checked', '1', $ref ?: admin_url( 'admin.php?page=farazsms-updates' ) ) );
}

// ============================================================================
// Toggle handler — auto-update on/off
// ============================================================================

add_action( 'admin_post_farazsms_self_update_toggle', 'farazsms_self_update_toggle_handler' );
function farazsms_self_update_toggle_handler() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی غیرمجاز.', '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'farazsms_self_update_toggle' );

	$new_val = isset( $_POST['enabled'] ) && $_POST['enabled'] === '1' ? '1' : '0';
	update_option( 'farazsms_self_update_enabled', $new_val, false );

	$ref = wp_get_referer();
	farazsms_self_update_safe_redirect( add_query_arg( 'farazsms_toggled', '1', $ref ?: admin_url( 'admin.php?page=farazsms-updates' ) ) );
}

// ============================================================================
// Submenu — اولویت ۱۳، بعد از داشبورد ROI
// ============================================================================

add_action( 'admin_menu', 'farazsms_self_update_register_submenu', 13 );
function farazsms_self_update_register_submenu() {
	add_submenu_page(
		'farazsms',
		'به‌روزرسانی افزونه',
		'🔄 به‌روزرسانی',
		'manage_options',
		'farazsms-updates',
		'farazsms_self_update_render_page'
	);
}

// ============================================================================
// Render settings page
// ============================================================================

function farazsms_self_update_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) return;

	$info       = farazsms_self_update_fetch_remote_info();
	$last_error = farazsms_self_update_last_error();
	$enabled    = get_option( 'farazsms_self_update_enabled', '1' ) === '1';
	$current    = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '0.0.0';
	$has_update = ( $info && version_compare( $info->version, $current, '>' ) );

	$apikey = get_option( 'farazsms_apikey', '' );
	?>
	<section class="wrapper">
		<div id="farazsms_header">
			<div>
				<a href="https://farazsms.com" target="_blank">
					<img src="<?php echo esc_url( FARAZSMS_CORE_IMG . 'logo-1.png' ); ?>" alt="پنل ارسال اس ام اس">
				</a>
			</div>
			<?php if ( ! empty( $apikey ) ) :
				$credit = farazsms_get_credit(); ?>
				<div id="farazsms_account_info">
					<div class="farazsms_credit_amount">
						<span>میزان اعتبار: </span><?php echo esc_html( $credit ); ?>
						<span> تومان</span>
					</div>
					<?php if ( function_exists( 'farazsms_render_profile_block' ) ) farazsms_render_profile_block(); ?>
				</div>
			<?php endif; ?>
		</div>

		<?php if ( isset( $_GET['farazsms_checked'] ) ) : ?>
			<div style="background:#e2f8f0; border:1px solid #10c282; color:#096d49; padding:10px 14px; border-radius:8px; margin-bottom:14px; direction:rtl;">✓ بررسی اکنون انجام شد.</div>
		<?php endif; ?>
		<?php if ( isset( $_GET['farazsms_toggled'] ) ) : ?>
			<div style="background:#e2f8f0; border:1px solid #10c282; color:#096d49; padding:10px 14px; border-radius:8px; margin-bottom:14px; direction:rtl;">✓ تنظیمات به‌روزرسانی خودکار ذخیره شد.</div>
		<?php endif; ?>

		<!-- Hero — وضعیت نسخه -->
		<?php if ( $has_update ) : ?>
			<div style="background:linear-gradient(135deg, #d52a16 0%, #e2a916 100%); color:#fff; border-radius:14px; padding:24px 28px; margin-bottom:18px; direction:rtl; box-shadow:0 8px 24px rgba(220,38,38,0.22);">
				<div style="display:flex; align-items:center; gap:18px; flex-wrap:wrap;">
					<div style="font-size:48px; line-height:1;">⬆️</div>
					<div style="flex:1; min-width:240px;">
						<div style="font-size:13px; opacity:0.92; margin-bottom:4px;">نسخه جدید‌تری از افزونه موجود است</div>
						<div style="font-size:22px; font-weight:800; margin-bottom:4px;">
							نسخه <?php echo esc_html( $info->version ); ?> منتشر شده است
						</div>
						<div style="font-size:13px; opacity:0.92;">نسخه فعلی شما: <?php echo esc_html( $current ); ?></div>
					</div>
					<a href="<?php echo esc_url( admin_url( 'update-core.php' ) ); ?>" style="background:#fff; color:#d52a16; padding:12px 26px; border-radius:10px; text-decoration:none; font-size:14px; font-weight:700; box-shadow:0 6px 14px rgba(0,0,0,0.18);">
						🚀 به‌روزرسانی اکنون
					</a>
				</div>
			</div>
		<?php elseif ( $info ) : ?>
			<div style="background:linear-gradient(135deg, #0c9765 0%, #10c282 100%); color:#fff; border-radius:14px; padding:24px 28px; margin-bottom:18px; direction:rtl; box-shadow:0 8px 24px rgba(5,150,105,0.22);">
				<div style="display:flex; align-items:center; gap:18px; flex-wrap:wrap;">
					<div style="font-size:48px; line-height:1;">✓</div>
					<div style="flex:1; min-width:240px;">
						<div style="font-size:13px; opacity:0.92; margin-bottom:4px;">افزونه به‌روز است</div>
						<div style="font-size:22px; font-weight:800; margin-bottom:4px;">
							نسخه <?php echo esc_html( $current ); ?> آخرین نسخه است
						</div>
						<div style="font-size:12.5px; opacity:0.9;">آخرین بررسی:
							<?php echo esc_html( $info->fetched_at ); ?>
						</div>
					</div>
				</div>
			</div>
		<?php else : ?>
			<div style="background:#faf1da; border:1px solid #e2a916; color:#83620d; padding:18px 22px; border-radius:12px; margin-bottom:18px; direction:rtl;">
				<div style="display:flex; gap:14px; align-items:center; flex-wrap:wrap;">
					<div style="font-size:32px;">⚠️</div>
					<div style="flex:1;">
						<div style="font-weight:700; margin-bottom:4px;">دسترسی به سرور آپدیت ممکن نیست</div>
						<?php if ( $last_error ) : ?>
							<div style="font-size:12.5px; line-height:1.7;">خطا: <code style="background:#fff; padding:2px 6px; border-radius:4px;"><?php echo esc_html( $last_error ); ?></code></div>
						<?php endif; ?>
						<div style="font-size:12px; margin-top:6px; color:#a16207;">
							احتمالاً نسخه‌ی جدیدی منتشر نشده، یا ارتباط با سرورِ فراز اس‌ام‌اس موقتاً برقرار نیست.
						</div>
					</div>
				</div>
			</div>
		<?php endif; ?>

		<!-- کارت‌های info — version + source + toggle -->
		<div style="display:grid; grid-template-columns:repeat(auto-fit, minmax(280px, 1fr)); gap:14px; margin-bottom:18px; direction:rtl;">

			<!-- کارت ۱: مقایسه نسخه -->
			<div style="background:#fff; border:1.5px solid #c1d0e8; border-radius:12px; padding:18px 20px;">
				<div style="display:flex; align-items:center; gap:10px; margin-bottom:12px;">
					<div style="font-size:24px;">📦</div>
					<div style="font-weight:700; color:#263f67;">نسخه افزونه</div>
				</div>
				<div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid #f5f8fe;">
					<span style="color:#9b9b9b; font-size:12.5px;">نسخه نصب‌شده روی این سایت:</span>
					<strong style="color:#263f67; font-family:Menlo,Consolas,monospace; direction:ltr;"><?php echo esc_html( $current ); ?></strong>
				</div>
				<div style="display:flex; justify-content:space-between; padding:8px 0;">
					<span style="color:#9b9b9b; font-size:12.5px;">آخرین نسخه روی سرورِ فراز:</span>
					<strong style="color:<?php echo $has_update ? '#d52a16' : '#0c9765'; ?>; font-family:Menlo,Consolas,monospace; direction:ltr;">
						<?php echo $info ? esc_html( $info->version ) : '—'; ?>
					</strong>
				</div>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:12px;">
					<input type="hidden" name="action" value="farazsms_self_update_force_check">
					<?php wp_nonce_field( 'farazsms_self_update_force_check' ); ?>
					<button type="submit" style="background:#365891; color:#fff; border:none; padding:9px 18px; border-radius:7px; font-size:12.5px; font-weight:600; cursor:pointer; width:100%;">
						↻ بررسی اکنون
					</button>
				</form>
			</div>

			<!-- کارت ۲: toggle auto-update -->
			<div style="background:#fff; border:1.5px solid <?php echo $enabled ? '#10c282' : '#d52a16'; ?>; border-radius:12px; padding:18px 20px;">
				<div style="display:flex; align-items:center; gap:10px; margin-bottom:12px;">
					<div style="font-size:24px;"><?php echo $enabled ? '🟢' : '🔴'; ?></div>
					<div style="font-weight:700; color:#263f67;">به‌روزرسانی خودکار</div>
				</div>
				<p style="font-size:12.5px; color:#4d4d4d; line-height:1.7; margin:0 0 14px;">
					اگر فعال باشد، هر نسخه‌ی جدید بدون مداخله شما روی سایت نصب می‌شود (در پس‌زمینه، در ساعت‌های کم‌ترافیک).
				</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="farazsms_self_update_toggle">
					<input type="hidden" name="enabled" value="<?php echo $enabled ? '0' : '1'; ?>">
					<?php wp_nonce_field( 'farazsms_self_update_toggle' ); ?>
					<button type="submit" style="background:<?php echo $enabled ? '#d52a16' : '#0c9765'; ?>; color:#fff; border:none; padding:9px 18px; border-radius:7px; font-size:12.5px; font-weight:600; cursor:pointer; width:100%;">
						<?php echo $enabled ? '⏸ غیرفعال کردن به‌روزرسانی خودکار' : '▶ فعال کردن به‌روزرسانی خودکار'; ?>
					</button>
				</form>
			</div>

			<!-- کارت ۳: منبع آپدیت -->
			<div style="background:#fff; border:1.5px solid #10c282; border-radius:12px; padding:18px 20px;">
				<div style="display:flex; align-items:center; gap:10px; margin-bottom:12px;">
					<div style="font-size:24px;">🔒</div>
					<div style="font-weight:700; color:#263f67;">منبع به‌روزرسانی</div>
				</div>
				<div style="background:#e2f8f0; border:1px solid #10c282; border-radius:6px; padding:10px 12px; margin-bottom:10px;">
					<strong style="font-size:13px; color:#096d49;">سرور رسمیِ فراز اس‌ام‌اس</strong>
				</div>
				<p style="font-size:11.5px; color:#9b9b9b; line-height:1.7; margin:0;">
					به‌روزرسانی‌ها مستقیماً از سرورِ فراز اس‌ام‌اس دریافت می‌شوند.
				</p>
			</div>
		</div>

		<!-- changelog -->
		<?php if ( $info && ! empty( $info->description ) ) : ?>
			<div style="background:#fff; border:1.5px solid #e1e1e1; border-radius:12px; padding:20px 24px; direction:rtl;">
				<h3 style="margin:0 0 14px; font-size:15px; color:#263f67; font-weight:700;">
					📝 یادداشت‌های نسخه <?php echo esc_html( $info->tag_name ); ?>
				</h3>
				<pre style="background:#f5f8fe; border:1px solid #e1e1e1; border-radius:8px; padding:14px 16px; font-family:inherit; font-size:12.5px; line-height:1.9; color:#263f67; white-space:pre-wrap; max-height:340px; overflow-y:auto; margin:0;"><?php echo esc_html( $info->description ); ?></pre>
				<?php if ( ! empty( $info->released_at ) ) : ?>
					<div style="margin-top:10px; font-size:11.5px; color:#9b9b9b;">منتشر شده در:
						<code style="direction:ltr; background:#f5f8fe; padding:2px 6px; border-radius:4px;"><?php echo esc_html( $info->released_at ); ?></code>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<?php // v3.21.59: بخشِ توضیحِ فنیِ مکانیزمِ به‌روزرسانی حذف شد تا جزئیاتِ سرور برای کاربر نمایش داده نشود. ?>

		<?php // v3.22.45 (#6e): چنج‌لاگ (لیستِ تغییرات) همین‌جا زیرِ کنترلِ به‌روزرسانی رندر می‌شود. ?>
		<?php do_action( 'farazsms_updates_page_after' ); ?>
	</section>
	<?php
}
