<?php
/**
 * Short Link helper — v3.21.17
 *
 * لینک‌هایی که در پیامک‌های اطلاع‌رسانی می‌روند (پاسخ/اطلاعِ کامنت، «موجود شد خبرم کن»،
 * و …) به‌جای پیوندیکتای بلندِ فارسی، با شناسه‌ی وردپرس کوتاه می‌شوند:
 *
 *     home_url( '/?p=ID' )
 *
 * چرا: پیوندیکتای فارسیِ پست/محصول هنگام URL-encode بسیار طولانی و زشت می‌شود و طولِ
 * پیامک (و هزینه) را بالا می‌برد. شناسه‌ی عددی کوتاه و تمیز است. بعد از کلیک، خودِ
 * وردپرس به نشانیِ کاملِ صفحه canonical-redirect می‌کند؛ پس مقصد درست می‌ماند و فقط
 * متنِ پیامک کوتاه می‌شود.
 *
 * نکته: ?p=ID فقط برای post_type='post' مستقیم resolve می‌شود. برای page از page_id و
 * برای CPT (مثلِ product) از p + post_type استفاده می‌کنیم تا لینک ۴۰۴ نشود.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * ساختِ لینکِ کوتاهِ مبتنی بر شناسه برای یک پست/برگه/محصول.
 *
 * @param int    $post_id  شناسه‌ی پست/برگه/محصول.
 * @param string $fragment لنگرِ اختیاری (مثلِ 'comment-15' یا '#comment-15').
 * @return string لینکِ کوتاه، یا '' اگر شناسه نامعتبر/ناموجود باشد.
 */
function farazsms_short_post_link( $post_id, $fragment = '' ) {
	$post_id = (int) $post_id;
	if ( $post_id <= 0 ) {
		return '';
	}
	$post = get_post( $post_id );
	if ( ! $post ) {
		return '';
	}
	// v3.21.24: برای پستِ غیرمنتشر (draft/private/pending) لینکِ کوتاه نساز؛ caller به
	// رفتارِ پیش‌فرض (permalink) برمی‌گردد و لینکِ شناسه‌ایِ گمراه‌کننده ساخته نمی‌شود.
	if ( get_post_status( $post ) !== 'publish' ) {
		return '';
	}

	if ( $post->post_type === 'page' ) {
		$url = home_url( '/?page_id=' . $post_id );
	} elseif ( $post->post_type === 'post' ) {
		$url = home_url( '/?p=' . $post_id );
	} else {
		// CPT (مثلِ product): بدونِ post_type، ?p=ID به‌صورتِ post خوانده می‌شود و ۴۰۴ می‌دهد.
		$url = add_query_arg(
			array(
				'p'         => $post_id,
				'post_type' => $post->post_type,
			),
			home_url( '/' )
		);
	}

	$fragment = ltrim( (string) $fragment, '#' );
	if ( $fragment !== '' ) {
		$url .= '#' . $fragment;
	}

	return $url;
}

/**
 * v3.22.142: خواناترین لینکِ «هم‌دامنه» برای متنِ پیامک.
 *
 * پیوندِ یکتای محصول/نوشته وقتی نامکِ فارسی داشته باشد، در URL درصد-کد می‌شود و در پیامک به
 * یک رشته‌ی صد-و-چند کاراکتریِ ناخوانا تبدیل می‌گردد (هم زشت، هم چند برابر هزینه). در این
 * حالت لینکِ شناسه‌ای کوتاه و تمیز است و وردپرس پس از کلیک به همان صفحه canonical-redirect
 * می‌کند. اگر نامک انگلیسی باشد، خودِ پیوندِ یکتا هم کوتاه و هم گویاست، پس همان می‌رود.
 *
 * @param int    $post_id
 * @param string $fragment لنگرِ اختیاری (مثلِ 'comment-15').
 * @return string لینک، یا '' اگر شناسه نامعتبر باشد.
 */
function farazsms_sms_readable_post_link( $post_id, $fragment = '' ) {
	$post_id   = (int) $post_id;
	$permalink = (string) get_permalink( $post_id );
	$id_link   = farazsms_short_post_link( $post_id, $fragment );

	if ( $permalink === '' ) {
		return $id_link;
	}
	// خوانا = فقط کاراکترهای چاپیِ ASCII و بدونِ درصد-کدگذاری.
	$readable = ! preg_match( '/[^\x20-\x7E]/', $permalink ) && strpos( $permalink, '%' ) === false;

	// کدریویو v3.22.152: سقفِ طول. متغیرهای لینک با طولِ اعلام‌شده به پنلِ فراز ساخته می‌شوند و
	// مقدارِ بلندتر از آن رد می‌شود؛ پس پیوندِ یکتای زیبا فقط تا همان سقف قابلِ‌استفاده است و
	// بعد از آن لینکِ شناسه‌ای (که همیشه کوتاه است) می‌رود. بدونِ این سقف، یک محصولِ
	// انگلیسی‌نامک با مسیرِ دسته‌بندیِ طولانی می‌توانست کلِ پیامک را رد کند.
	$limit = 80;
	$declared = farazsms_tracking_pattern_var_type_length( 'product_link' );
	if ( is_array( $declared ) && ! empty( $declared['length'] ) ) {
		$limit = (int) $declared['length'];
	}
	$fits = ( function_exists( 'mb_strlen' ) ? mb_strlen( $permalink ) : strlen( $permalink ) ) <= $limit;

	if ( ( ! $readable || ! $fits ) && $id_link !== '' ) {
		return $id_link;
	}

	$fragment = ltrim( (string) $fragment, '#' );
	return $fragment !== '' ? $permalink . '#' . $fragment : $permalink;
}
