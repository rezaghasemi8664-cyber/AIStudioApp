<?php
/**
 * نمای پیشخوانِ افزونه — ناوبری، سایدبار و تب‌ها.
 *
 * v3.22.167: نمای دوم و کلیدِ خاموش/روشنش حذف شدند؛ فقط یک نما وجود دارد.
 * افزودنِ صفحه‌ی تازه با فیلترِ farazsms_nav_extra انجام می‌شود، نه ویرایشِ فهرست.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * ساختارِ گروه‌بندیِ نمای جدید (تأییدشده). از نگاشتِ واحدِ slug→متادیتا ساخته می‌شود.
 * «ادغامِ حساب» عمداً اینجا نیست (تبِ داخلِ ورود می‌شود).
 */
function farazsms_dashboard_nav_groups_v2() {
	$has_wc   = farazsms_is_wc_active();
	$has_gf   = farazsms_is_gf_active();
	$has_elem = farazsms_is_elementor_active();
	$has_jfb  = farazsms_jfb_is_active();

	$m = array(
		'farazsms-dashboard'      => array( 'داشبورد', 'dashicons-dashboard', 'نمای کلی، اعتبار، آمار سریع' ),
		'farazsms-roi'            => array( 'محاسبه سود افزونه', 'dashicons-chart-line', 'این ماه چقدر فروش از پیامک آمد؟' ),
		'farazsms-settings'       => array( 'تنظیمات افزونه', 'dashicons-admin-settings', 'کلید دسترسی (Api-Key) و خط ارسال' ),
		'farazsms-send-sms'       => array( 'ارسال پیامک', 'dashicons-email-alt', 'ارسال پیامک تکی یا انبوه از داخل سایت' ),
		'farazsms-reports'        => array( 'گزارشات ارسال', 'dashicons-chart-area', 'گزارش‌گیری از API فراز اس‌ام‌اس' ),
		'farazsms-updates'        => array( 'به‌روزرسانی افزونه', 'dashicons-update', 'به‌روزرسانی خودکار از سرور فراز اس‌ام‌اس' ),
		'farazsms-developers'     => array( 'برنامه‌نویسان', 'dashicons-editor-code', 'مستندات API برای توسعه‌دهندگان' ),
		'farazsms-feedback'       => array( 'بازخورد', 'dashicons-format-status', 'ارسال تیکت و گزارش مشکل' ),
		'farazsms-segments'       => array( 'باشگاه مشتریان', 'dashicons-groups', 'سگمنت‌بندی مشتریان (پرخرید، در حال ریزش، …)' ),
		'farazsms-spin'           => array( '🎡 گردونه شانس', 'dashicons-marker', 'قرعه‌کشیِ گیمیفیکیشن + جمع‌آوری موبایل' ),
		'farazsms-phonebook'      => array( 'دفترچه تلفن', 'dashicons-book-alt', 'دفترچه تلفن + سینک فرم‌ها' ),
		'farazsms-newsletter'     => array( 'خبرنامه پیامکی', 'dashicons-megaphone', 'شورت‌کد، ویجت، ارسال انبوه' ),
		'farazsms-lead-magnet'    => array( 'لید مگنت', 'dashicons-tickets-alt', 'تخفیف در ازای شماره موبایل' ),
		'farazsms-birthday'       => array( '🎂 تبریک تولد + کوپن', 'dashicons-buddicons-friends', 'پیامک تبریک با کد تخفیف انحصاری' ),
		'farazsms-automation'     => array( 'اتومیشن مارکتینگ', 'dashicons-clock', 'پیامک زمان‌دار و کمپین‌های خودکار' ),
		'farazsms-cashback'       => array( 'کش‌بک هوشمند', 'dashicons-money-alt', 'بازگشت درصدی + کیف پول + پیامک یادآوری' ),
		'farazsms-user-panel'     => array( 'پنل کاربری', 'dashicons-id', 'پنل مشتری: خریدها، کیف پول، کش‌بک، تولد' ),
		'farazsms-farazbin'       => array( 'فراز بین', 'dashicons-search', 'موتور جستجوی قیمت + ایندکس محصولات' ),
		'farazsms'                => array( 'کد رهگیری سفارش', 'dashicons-location', 'ارسال خودکار کد رهگیری' ),
		'farazsms-bulk-tracking'  => array( 'افزودن گروهی کد رهگیری', 'dashicons-editor-table', 'ثبتِ گروهیِ شماره سفارش و کد رهگیری در یک جدول' ),
		'farazsms-poll'           => array( 'نظرسنجی پس از خرید', 'dashicons-star-filled', 'بازخورد مشتری بعد از خرید' ),
		'farazsms-notify'         => array( 'موجود شد خبرم کن', 'dashicons-bell', 'پیامک بازگشت موجودی محصول' ),
		'farazsms-abandoned'      => array( 'سبد خرید رهاشده', 'dashicons-cart', 'بازگردانی سبد + گزارش بازگشت' ),
		'farazsms-orders-sms'     => array( 'پیامک سفارشات', 'dashicons-cart', 'تنظیماتِ پیامک حرفه‌ای ووکامرس' ),
		'farazsms-invoice'        => array( '🧾 فاکتور پیامکی', 'dashicons-media-text', 'لینکِ فاکتور با قابلیتِ چاپ و PDF' ),
		'farazsms-sms-forms'      => array( 'فرم ساز ها', 'dashicons-feedback', 'پیامکِ همه‌ی فرم‌سازها + تأییدِ موبایل' ),
		'farazsms-comments'       => array( 'دیدگاه سایت', 'dashicons-format-chat', 'پیامکِ دیدگاهِ مقالات و نوشته‌های وردپرس' ),
		'farazsms-login-register' => array( 'ورود و ثبت نام', 'dashicons-admin-users', 'ورود با پیامک، ظاهرِ فرم، امنیت، ادغامِ حساب' ),
		'farazsms-account-button' => array( 'دکمه‌ی حساب/ورود', 'dashicons-id-alt', 'دکمه‌ی هوشمندِ ورود/حساب برای هدرِ قالب' ),
	);

	$blueprint = array(
		'general' => array( 'تنظیمات اصلی', 'dashicons-admin-generic', array( 'farazsms-dashboard', 'farazsms-roi', 'farazsms-settings', 'farazsms-send-sms', 'farazsms-reports', 'farazsms-updates', 'farazsms-developers', 'farazsms-feedback' ) ),
		'club'    => array( 'باشگاه مشتریان و فروش', 'dashicons-groups', array( 'farazsms-segments', 'farazsms-spin', 'farazsms-phonebook', 'farazsms-newsletter', 'farazsms-lead-magnet', 'farazsms-birthday', 'farazsms-automation', 'farazsms-cashback', 'farazsms-user-panel', 'farazsms-farazbin' ) ),
		'woo'     => array( 'ووکامرس و سفارشات', 'dashicons-cart', array( 'farazsms-orders-sms', 'farazsms', 'farazsms-bulk-tracking', 'farazsms-abandoned', 'farazsms-notify', 'farazsms-poll', 'farazsms-invoice' ) ),
		'wp'      => array( 'وردپرس', 'dashicons-wordpress', array( 'farazsms-sms-forms', 'farazsms-comments' ) ),
		'login'   => array( 'ورود و ثبت نام', 'dashicons-admin-users', array( 'farazsms-login-register', 'farazsms-account-button' ) ),
	);

	/**
	 * ⚠️ نقطهٔ خودثبتیِ ماژول‌ها — این تنها جایی است که ناوبریِ زنده ساخته می‌شود.
	 *
	 * تا v3.22.165 ورودی‌های تازه به تابعِ *قدیمیِ* ناوبری اضافه می‌شدند که فقط با
	 * مسیرِ دومِ ناوبری صدا زده می‌شد — یعنی صفحه ثبت می‌شد ولی هیچ‌جا
	 * دیده نمی‌شد. حالا هر ماژول خودش را با این فیلتر معرفی می‌کند:
	 *
	 *   add_filter( 'farazsms_nav_extra', function ( $n ) {
	 *       $n['farazsms-x'] = array( 'title' => '…', 'icon' => 'dashicons-…', 'desc' => '…', 'group' => 'wp', 'when' => 'callable' );
	 *       return $n;
	 *   } );
	 */
	foreach ( (array) apply_filters( 'farazsms_nav_extra', array() ) as $slug => $extra ) {
		if ( ! is_array( $extra ) || empty( $extra['title'] ) || empty( $extra['group'] ) ) {
			continue;
		}
		if ( isset( $extra['when'] ) && is_callable( $extra['when'] ) && ! call_user_func( $extra['when'] ) ) {
			continue; // ماژولی که افزونه‌ی مقصدش نصب نیست، در منو شلوغی نمی‌کند.
		}
		if ( ! isset( $blueprint[ $extra['group'] ] ) ) {
			continue;
		}
		$m[ $slug ] = array( $extra['title'], $extra['icon'] ?? 'dashicons-admin-generic', $extra['desc'] ?? '' );
		$blueprint[ $extra['group'] ][2][] = $slug;
	}

	$wc_only = array( 'farazsms', 'farazsms-bulk-tracking', 'farazsms-poll', 'farazsms-notify', 'farazsms-abandoned', 'farazsms-orders-sms', 'farazsms-automation', 'farazsms-invoice' );
	$groups  = array();
	foreach ( $blueprint as $gkey => $g ) {
		list( $label, $icon, $slugs ) = $g;
		$items = array();
		foreach ( $slugs as $slug ) {
			if ( ! $has_wc && in_array( $slug, $wc_only, true ) ) {
				continue;
			}
			// صفحه‌ی واحدِ فرم‌سازها: اگر دستِ‌کم یکی از فرم‌سازهای پشتیبانی‌شده نصب
			// باشد نمایش داده می‌شود. (پیش‌تر سه منویِ جدا برای یک کار وجود داشت.)
			if ( $slug === 'farazsms-sms-forms' ) {
				$has_fb = farazsms_fb_any_source_active();
				// قانونِ ذخیره‌شده هم صفحه را نگه می‌دارد: با غیرفعال‌کردنِ موقتِ
				// یک فرم‌ساز، قانون‌های نوشته‌شده نباید بی‌درِ‌ورودی شوند.
				$has_rules = ( farazsms_fb_get_rules() )
					|| ( farazsms_jfb_get_rules() );
				if ( ! $has_gf && ! $has_elem && ! $has_jfb && ! $has_fb && ! $has_rules ) {
					continue;
				}
			}
			if ( ! isset( $m[ $slug ] ) ) {
				continue;
			}
			$items[] = array( 'slug' => $slug, 'title' => $m[ $slug ][0], 'icon' => $m[ $slug ][1], 'desc' => $m[ $slug ][2] );
		}
		if ( $items ) {
			$groups[ $gkey ] = array( 'label' => $label, 'icon' => $icon, 'items' => $items );
		}
	}
	return $groups;
}

/**
 * مجموعه‌تبِ افقیِ «ورود و ثبت‌نام» (ادغامِ حساب به‌صورتِ تب).
 */
function farazsms_ux_v2_login_tabset() {
	return array(
		'farazsms-login-register' => __( 'ورود و ثبت‌نام', 'farazsms' ),
		'farazsms-account-button' => __( 'دکمه‌ی حساب/ورود', 'farazsms' ),
		'farazsms-account-dedupe' => __( 'حساب‌های تکراری', 'farazsms' ),
	);
}

/**
 * رندرِ سایدبارِ آکاردئونی + جستجو. گروهِ تک‌آیتمی = لینکِ مستقیم.
 */
function farazsms_ux_v2_render_sidebar( $current_gkey, $current_item ) {
	farazsms_ux_v2_inline_css();
	$current_slug = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	// صفحه‌ی ادغامِ حساب از نظرِ سایدبار، «ورود و ثبت‌نام» محسوب می‌شود (هایلایتِ درست).
	$login_tabset = farazsms_ux_v2_login_tabset();
	$treat_as_login = isset( $login_tabset[ $current_slug ] );
	?>
	<nav class="farazsms-app-sidebar__nav farazsms-ux2-nav" aria-label="<?php esc_attr_e( 'ناوبری فراز اس‌ام‌اس', 'farazsms' ); ?>">
		<div class="farazsms-ux2-search">
			<span class="dashicons dashicons-search"></span>
			<input type="search" placeholder="<?php esc_attr_e( 'جستجوی سریعِ قابلیت…', 'farazsms' ); ?>" oninput="farazsmsUx2Filter(this.value)">
		</div>
		<?php foreach ( farazsms_dashboard_nav_groups() as $gkey => $group ) :
			$is_single = ( count( $group['items'] ) === 1 );
			if ( $is_single ) :
				$item = $group['items'][0];
				$active = ( $current_item && $item['slug'] === $current_item['slug'] ) || ( $gkey === 'login' && $treat_as_login );
				?>
				<a class="farazsms-ux2-navlink<?php echo $active ? ' is-active' : ''; ?>" href="<?php echo esc_url( farazsms_dashboard_item_url( $item['slug'] ) ); ?>">
					<span class="dashicons <?php echo esc_attr( $group['icon'] ); ?>"></span>
					<span class="farazsms-ux2-label"><?php echo esc_html( $group['label'] ); ?></span>
				</a>
			<?php else :
				$group_active = ( $gkey === $current_gkey ) || ( $gkey === 'login' && $treat_as_login );
				?>
				<div class="farazsms-ux2-group<?php echo $group_active ? ' is-open' : ''; ?>" data-ux2-group>
					<button type="button" class="farazsms-ux2-grouphead" onclick="farazsmsUx2Toggle(this)">
						<span class="dashicons <?php echo esc_attr( $group['icon'] ); ?>"></span>
						<span class="farazsms-ux2-label"><?php echo esc_html( $group['label'] ); ?></span>
						<span class="farazsms-ux2-count"><?php echo esc_html( count( $group['items'] ) ); ?></span>
						<span class="dashicons dashicons-arrow-down-alt2 farazsms-ux2-chev"></span>
					</button>
					<div class="farazsms-ux2-items">
						<?php foreach ( $group['items'] as $item ) :
							$active = ( $current_item && $item['slug'] === $current_item['slug'] );
							?>
							<a class="farazsms-ux2-item<?php echo $active ? ' is-active' : ''; ?>" href="<?php echo esc_url( farazsms_dashboard_item_url( $item['slug'] ) ); ?>">
								<span class="dashicons <?php echo esc_attr( $item['icon'] ); ?>"></span>
								<span><?php echo esc_html( $item['title'] ); ?></span>
							</a>
						<?php endforeach; ?>
					</div>
				</div>
			<?php endif; ?>
		<?php endforeach; ?>
	</nav>
	<script>
	function farazsmsUx2Toggle(btn){ btn.parentNode.classList.toggle('is-open'); }
	function farazsmsUx2Filter(q){
		q = (q || '').trim();
		document.querySelectorAll('.farazsms-ux2-nav [data-ux2-group]').forEach(function(g){
			var any = false;
			g.querySelectorAll('.farazsms-ux2-item').forEach(function(it){
				var hit = !q || it.textContent.indexOf(q) !== -1;
				it.style.display = hit ? '' : 'none';
				if (hit) any = true;
			});
			g.style.display = (q && !any) ? 'none' : '';
			if (q) { g.classList.toggle('is-open', any); }
		});
		document.querySelectorAll('.farazsms-ux2-nav .farazsms-ux2-navlink').forEach(function(a){
			a.style.display = (!q || a.textContent.indexOf(q) !== -1) ? '' : 'none';
		});
	}
	</script>
	<?php
}

/**
 * نوارِ تبِ افقیِ «ورود و ثبت‌نام / ادغامِ حساب» — فقط روی این دو صفحه.
 */
function farazsms_ux_v2_render_login_tabs() {
	$current_slug = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	$tabset = farazsms_ux_v2_login_tabset();
	if ( ! isset( $tabset[ $current_slug ] ) ) {
		return;
	}
	echo '<nav class="farazsms-ux2-htabs" aria-label="' . esc_attr__( 'ورود و ثبت‌نام', 'farazsms' ) . '">';
	foreach ( $tabset as $slug => $title ) {
		$active = ( $slug === $current_slug );
		echo '<a class="farazsms-ux2-htab' . ( $active ? ' is-active' : '' ) . '" href="' . esc_url( admin_url( 'admin.php?page=' . $slug ) ) . '">' . esc_html( $title ) . '</a>';
	}
	echo '</nav>';
}

/**
 * v3.21.67: دکمه‌ی toggle حذف شد — نمای جدید پیش‌فرضِ همه است. این تابع برای سازگاری
 * (فراخوانی از فریم) نگه داشته شده ولی چیزی چاپ نمی‌کند.
 */
function farazsms_ux_v2_topbar_toggle() {
	return;
}

/**
 * CSSِ نمای جدید — یک‌بار در هر درخواست.
 */
function farazsms_ux_v2_inline_css() {
	static $printed = false;
	if ( $printed ) {
		return;
	}
	$printed = true;
	?>
	<style id="farazsms-ux2-css">
	.farazsms-ux2-nav{ padding:6px 8px; }
	.farazsms-ux2-search{ position:relative; margin-bottom:10px; }
	.farazsms-ux2-search .dashicons{ position:absolute; right:8px; top:7px; color:#9b9b9b; font-size:17px; }
	.farazsms-ux2-search input{ width:100%; padding:8px 32px 8px 10px; border:1px solid #e1e1e1; border-radius:8px; font-family:inherit; font-size:12.5px; box-sizing:border-box; }
	.farazsms-ux2-search input:focus{ outline:none; border-color:#365891; box-shadow:0 0 0 3px #eaeff7; }
	.farazsms-ux2-navlink,.farazsms-ux2-grouphead{ display:flex; align-items:center; gap:9px; width:100%; padding:10px 10px; margin-bottom:3px; border-radius:8px; font-weight:700; font-size:13px; color:#263f67; text-decoration:none; background:none; border:none; cursor:pointer; font-family:inherit; text-align:right; }
	.farazsms-ux2-navlink .dashicons,.farazsms-ux2-grouphead .dashicons:first-child{ font-size:18px; width:22px; text-align:center; color:#9b9b9b; }
	.farazsms-ux2-navlink:hover,.farazsms-ux2-grouphead:hover{ background:#f5f8fe; }
	.farazsms-ux2-navlink.is-active{ background:#eaeff7; color:#365891; }
	.farazsms-ux2-navlink.is-active .dashicons{ color:#365891; }
	.farazsms-ux2-label{ flex:1; }
	.farazsms-ux2-count{ font-size:10.5px; font-weight:700; color:#9b9b9b; background:#f5f8fe; border-radius:999px; padding:1px 8px; }
	.farazsms-ux2-chev{ font-size:16px !important; color:#9b9b9b; transition:transform .2s; }
	.farazsms-ux2-group.is-open > .farazsms-ux2-grouphead{ background:#eaeff7; color:#365891; }
	.farazsms-ux2-group.is-open > .farazsms-ux2-grouphead .dashicons:first-child,
	.farazsms-ux2-group.is-open > .farazsms-ux2-grouphead .farazsms-ux2-chev{ color:#365891; }
	.farazsms-ux2-group.is-open > .farazsms-ux2-grouphead .farazsms-ux2-chev{ transform:rotate(180deg); }
	.farazsms-ux2-items{ display:none; padding:2px 6px 6px; }
	.farazsms-ux2-group.is-open > .farazsms-ux2-items{ display:block; }
	.farazsms-ux2-item{ display:flex; align-items:center; gap:9px; padding:7px 10px; margin-bottom:1px; border-radius:8px; color:#9b9b9b; font-size:12.5px; text-decoration:none; }
	.farazsms-ux2-item .dashicons{ font-size:15px; width:20px; text-align:center; }
	.farazsms-ux2-item:hover{ background:#f5f8fe; color:#263f67; }
	.farazsms-ux2-item.is-active{ background:#eaeff7; color:#365891; font-weight:700; }
	.farazsms-ux2-htabs{ display:flex; gap:2px; border-bottom:1px solid #e1e1e1; margin:0 0 18px; overflow-x:auto; }
	.farazsms-ux2-htab{ padding:11px 16px; white-space:nowrap; text-decoration:none; color:#9b9b9b; font-weight:600; font-size:13px; border-bottom:3px solid transparent; margin-bottom:-1px; }
	.farazsms-ux2-htab:hover{ color:#263f67; }
	.farazsms-ux2-htab.is-active{ color:#365891; border-bottom-color:#365891; font-weight:700; }
	</style>
	<?php
}
