<?php
/**
 * Customer Journey / Marketing Automation (rules-based MVP) — v3.22.0 (theme 3)
 *
 * مدیر «اتوماسیون» تعریف می‌کند: تریگر (رویداد) → شرطِ اختیاری → تأخیر → اقدام (ارسالِ پترن).
 * موتور روی رویدادهای ووکامرس/وردپرس گوش می‌دهد، شرط را می‌سنجد، و اقدام را با تأخیرِ انتخابی
 * از طریقِ Action Scheduler (یا WP-Cron) اجرا می‌کند. ضدِتکرار per (journey + order/user).
 *
 * تریگرها: order_processing | order_completed | first_order | user_registered
 * متغیرِ پترن: %name%
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_JOURNEY_HOOK = 'farazsms_journey_execute_hook';

function farazsms_journey_triggers() {
	return array(
		'order_processing' => 'سفارش به «در حال انجام» رسید (پرداخت شد)',
		'order_completed'  => 'سفارش «تکمیل» شد',
		'first_order'      => 'اولین خریدِ مشتری (تکمیل‌شده)',
		'user_registered'  => 'ثبت‌نامِ کاربرِ جدید',
	);
}

function farazsms_journey_all() {
	$j = get_option( 'farazsms_journeys', array() );
	return is_array( $j ) ? $j : array();
}

function farazsms_journey_save_all( $list ) {
	update_option( 'farazsms_journeys', array_values( $list ), false );
}

// ── تریگرهای ووکامرس/وردپرس ────────────────────────────────────────────────
add_action( 'woocommerce_order_status_processing', 'farazsms_journey_on_processing', 20, 1 );
function farazsms_journey_on_processing( $order_id ) {
	farazsms_journey_fire_order( $order_id, 'order_processing' );
}
add_action( 'woocommerce_order_status_completed', 'farazsms_journey_on_completed', 20, 1 );
function farazsms_journey_on_completed( $order_id ) {
	farazsms_journey_fire_order( $order_id, 'order_completed' );
	// v3.22.1: بررسیِ گران‌قیمتِ «اولین خرید» فقط وقتی اجرا شود که اتوماسیونِ first_order وجود دارد
	// (وگرنه روی bulk «تکمیل»ِ صدها سفارش، صدها کوئریِ اضافه = تایم‌اوت).
	if ( ! empty( farazsms_journey_matching( 'first_order' ) ) && farazsms_journey_is_first_order( $order_id ) ) {
		farazsms_journey_fire_order( $order_id, 'first_order' );
	}
}
add_action( 'user_register', 'farazsms_journey_on_register', 20, 1 );
function farazsms_journey_on_register( $user_id ) {
	$phone = get_user_meta( $user_id, 'mobile_number', true );
	if ( $phone === '' ) {
		$phone = get_user_meta( $user_id, 'billing_phone', true );
	}
	$phone = farazsms_normalize_phone( $phone );
	if ( $phone === '' ) {
		return;
	}
	$user = get_userdata( $user_id );
	$name = $user ? $user->display_name : 'کاربر';
	foreach ( farazsms_journey_matching( 'user_registered' ) as $j ) {
		if ( get_user_meta( $user_id, '_farazsms_journey_' . $j['id'], true ) ) {
			continue;
		}
		update_user_meta( $user_id, '_farazsms_journey_' . $j['id'], 1 );
		farazsms_journey_schedule( $j, $phone, $name, 'u' . $user_id );
	}
}

/** آیا این سفارش، اولین سفارشِ تکمیل‌شده‌ی این مشتری است؟ */
function farazsms_journey_is_first_order( $order_id ) {
	if ( ! function_exists( 'wc_get_orders' ) ) {
		return false;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return false;
	}
	$email = $order->get_billing_email();
	if ( $email === '' ) {
		return false;
	}
	$prev = wc_get_orders( array(
		'limit'          => 2,
		'status'         => array( 'completed' ),
		'billing_email'  => $email,
		'return'         => 'ids',
		'orderby'        => 'date',
		'order'          => 'ASC',
	) );
	// اگر فقط همین سفارش (یا اولین در فهرست) است → اولین خرید.
	return is_array( $prev ) && ! empty( $prev ) && (int) $prev[0] === (int) $order_id;
}

function farazsms_journey_matching( $trigger ) {
	$out = array();
	foreach ( farazsms_journey_all() as $j ) {
		if ( ( $j['enabled'] ?? '0' ) === '1' && ( $j['trigger'] ?? '' ) === $trigger && trim( (string) ( $j['pattern_code'] ?? '' ) ) !== '' ) {
			$out[] = $j;
		}
	}
	return $out;
}

function farazsms_journey_fire_order( $order_id, $trigger ) {
	$matching = farazsms_journey_matching( $trigger );
	if ( empty( $matching ) || ! function_exists( 'wc_get_order' ) ) {
		return;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	$phone = farazsms_normalize_phone( $order->get_billing_phone() );
	if ( $phone === '' ) {
		return;
	}
	$name  = trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() );
	$total = (float) $order->get_total();
	foreach ( $matching as $j ) {
		// شرطِ حداقلِ مبلغ.
		if ( (float) ( $j['cond_min_total'] ?? 0 ) > 0 && $total < (float) $j['cond_min_total'] ) {
			continue;
		}
		// ضدِتکرار per journey per order.
		$meta_key = '_farazsms_journey_' . $j['id'];
		if ( $order->get_meta( $meta_key ) ) {
			continue;
		}
		$order->update_meta_data( $meta_key, 1 );
		$order->save();
		farazsms_journey_schedule( $j, $phone, $name !== '' ? $name : 'مشتری', (string) $order_id );
	}
}

/**
 * زمان‌بندیِ اجرای اقدام با تأخیر.
 * v3.22.1: $ref (شناسه‌ی سفارش/کاربر) به args اضافه شد تا روی مسیرِ WP-Cron، رویدادهای مختلفِ
 * همان مشتری «تکراری» تلقی و حذف نشوند (wp_schedule_single_event رویدادِ hook+argsِ یکسان در
 * ۱۰ دقیقه را رد می‌کند).
 */
function farazsms_journey_schedule( $j, $phone, $name, $ref = '' ) {
	$delay = max( 0, (int) ( $j['delay_hours'] ?? 0 ) ) * HOUR_IN_SECONDS;
	$args  = array( (string) $j['id'], (string) $phone, (string) $name, (string) $ref );
	if ( $delay === 0 && function_exists( 'as_enqueue_async_action' ) ) {
		as_enqueue_async_action( FARAZSMS_JOURNEY_HOOK, $args, 'farazsms' );
	} elseif ( function_exists( 'as_schedule_single_action' ) ) {
		as_schedule_single_action( time() + $delay, FARAZSMS_JOURNEY_HOOK, $args, 'farazsms' );
	} else {
		wp_schedule_single_event( time() + max( 1, $delay ), FARAZSMS_JOURNEY_HOOK, $args );
	}
}

add_action( FARAZSMS_JOURNEY_HOOK, 'farazsms_journey_execute', 10, 4 );
function farazsms_journey_execute( $journey_id, $phone, $name, $ref = '' ) {
	$journey = null;
	foreach ( farazsms_journey_all() as $j ) {
		if ( (string) $j['id'] === (string) $journey_id ) {
			$journey = $j;
			break;
		}
	}
	if ( ! $journey || ( $journey['enabled'] ?? '0' ) !== '1' ) {
		return;
	}
	$pattern = trim( (string) $journey['pattern_code'] );
	if ( $pattern === '' || $phone === '' ) {
		return;
	}
	// v3.22.1: اتوماسیون‌ها ماهیتِ تبلیغاتی/بازاریابی دارند (خوش‌آمد، پیگیریِ پس‌ازخرید، بازگردانی)،
	// پس مثلِ سایرِ قابلیت‌های تبلیغاتی از خطِ تبلیغاتی (PRO) ارسال شوند، نه خطِ خدماتی.
	$ad = farazsms_get_ad_sender();
	farazsms_send_pattern_sms_raw( $phone, $pattern, array( 'name' => $name !== '' ? $name : 'مشتری' ), $ad );
}

// ── ذخیره / حذف / تغییرِ وضعیت ─────────────────────────────────────────────
add_action( 'admin_post_farazsms_journey_add', 'farazsms_journey_handle_add' );
function farazsms_journey_handle_add() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die();
	}
	check_admin_referer( 'farazsms_journey_add' );
	$trigger = sanitize_key( wp_unslash( $_POST['trigger'] ?? '' ) );
	if ( ! array_key_exists( $trigger, farazsms_journey_triggers() ) ) {
		wp_safe_redirect( admin_url( 'admin.php?page=farazsms-journey' ) );
		exit;
	}
	$list   = farazsms_journey_all();
	$list[] = array(
		'id'             => uniqid( 'j' ),
		'enabled'        => '1',
		'name'           => sanitize_text_field( wp_unslash( $_POST['name'] ?? 'اتوماسیون' ) ),
		'trigger'        => $trigger,
		'delay_hours'    => max( 0, (int) ( $_POST['delay_hours'] ?? 0 ) ),
		'cond_min_total' => max( 0, (float) ( $_POST['cond_min_total'] ?? 0 ) ),
		'pattern_code'   => sanitize_text_field( wp_unslash( $_POST['journey_pattern_code'] ?? '' ) ),
	);
	farazsms_journey_save_all( $list );
	wp_safe_redirect( add_query_arg( 'added', '1', admin_url( 'admin.php?page=farazsms-journey' ) ) );
	exit;
}

add_action( 'admin_post_farazsms_journey_action', 'farazsms_journey_handle_action' );
function farazsms_journey_handle_action() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die();
	}
	check_admin_referer( 'farazsms_journey_action' );
	$id  = sanitize_text_field( wp_unslash( $_GET['jid'] ?? '' ) );
	$act = sanitize_key( wp_unslash( $_GET['act'] ?? '' ) );
	$list = farazsms_journey_all();
	foreach ( $list as $k => $j ) {
		if ( (string) $j['id'] !== $id ) {
			continue;
		}
		if ( $act === 'delete' ) {
			unset( $list[ $k ] );
		} elseif ( $act === 'toggle' ) {
			$list[ $k ]['enabled'] = ( ( $j['enabled'] ?? '0' ) === '1' ) ? '0' : '1';
		}
		break;
	}
	farazsms_journey_save_all( $list );
	wp_safe_redirect( admin_url( 'admin.php?page=farazsms-journey' ) );
	exit;
}

// ── صفحه‌ی ادمین ───────────────────────────────────────────────────────────
add_action( 'admin_menu', 'farazsms_journey_menu', 57 );
function farazsms_journey_menu() {
	add_submenu_page(
		'farazsms',
		'اتوماسیون (سفر مشتری)',
		'🔀 اتوماسیون',
		'manage_options',
		'farazsms-journey',
		'farazsms_journey_render_page'
	);
}

function farazsms_journey_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی غیرمجاز.' );
	}
	$triggers = farazsms_journey_triggers();
	$list     = farazsms_journey_all();
	$in       = 'width:100%;max-width:260px;padding:8px 10px;border:1px solid #e1e1e1;border-radius:7px;';
	?>
	<div class="wrap" style="direction:rtl;max-width:960px;">
		<h1 style="font-size:21px;">🔀 اتوماسیونِ سفرِ مشتری</h1>
		<p style="color:#9b9b9b;font-size:13px;">قانون بسازید: وقتی رویدادی رخ داد، پس از تأخیرِ دلخواه، پیامکی خودکار ارسال شود. مناسبِ خوش‌آمدگویی، پیگیریِ پس‌ازخرید و بازگردانی.</p>

		<div style="background:#fff;border:1px solid #e1e1e1;border-radius:12px;padding:0;margin:14px 0;overflow:hidden;">
			<table style="width:100%;border-collapse:collapse;font-size:13px;">
				<thead><tr style="background:#f5f8fe;text-align:right;">
					<th style="padding:10px 14px;">نام</th><th style="padding:10px 14px;">تریگر</th><th style="padding:10px 14px;">تأخیر</th><th style="padding:10px 14px;">وضعیت</th><th style="padding:10px 14px;">عملیات</th>
				</tr></thead>
				<tbody>
				<?php if ( empty( $list ) ) : ?>
					<tr><td colspan="5" style="padding:22px;text-align:center;color:#9b9b9b;">هنوز اتوماسیونی نساخته‌اید. از فرمِ پایین اضافه کنید.</td></tr>
				<?php else : foreach ( $list as $j ) :
					$on   = ( $j['enabled'] ?? '0' ) === '1';
					$togg = wp_nonce_url( admin_url( 'admin-post.php?action=farazsms_journey_action&act=toggle&jid=' . rawurlencode( $j['id'] ) ), 'farazsms_journey_action' );
					$del  = wp_nonce_url( admin_url( 'admin-post.php?action=farazsms_journey_action&act=delete&jid=' . rawurlencode( $j['id'] ) ), 'farazsms_journey_action' );
					?>
					<tr style="border-top:1px solid #f5f8fe;">
						<td style="padding:10px 14px;font-weight:600;"><?php echo esc_html( $j['name'] ); ?></td>
						<td style="padding:10px 14px;color:#4d4d4d;"><?php echo esc_html( $triggers[ $j['trigger'] ] ?? $j['trigger'] ); ?></td>
						<td style="padding:10px 14px;"><?php echo (int) $j['delay_hours'] === 0 ? 'فوری' : ( (int) $j['delay_hours'] . ' ساعت' ); ?></td>
						<td style="padding:10px 14px;"><?php echo $on ? '<span style="color:#0c9765;font-weight:700;">فعال ✓</span>' : '<span style="color:#9b9b9b;">غیرفعال</span>'; ?></td>
						<td style="padding:10px 14px;">
							<a href="<?php echo esc_url( $togg ); ?>" class="button button-small"><?php echo $on ? 'غیرفعال' : 'فعال'; ?></a>
							<a href="<?php echo esc_url( $del ); ?>" class="button button-small" style="color:#b32817;" onclick="return confirm('حذف شود؟')">حذف</a>
						</td>
					</tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
		</div>

		<div style="background:#fff;border:1px solid #e1e1e1;border-radius:12px;padding:20px;">
			<h3 style="margin:0 0 12px;font-size:15px;">افزودنِ اتوماسیون</h3>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="farazsms_journey_add">
				<?php wp_nonce_field( 'farazsms_journey_add' ); ?>
				<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px;margin-bottom:12px;">
					<label>نامِ اتوماسیون<br><input type="text" name="name" value="" placeholder="مثلاً پیگیریِ پس از خرید" style="<?php echo $in; ?>"></label>
					<label>تریگر (رویداد)<br>
						<select name="trigger" style="<?php echo $in; ?>">
							<?php foreach ( $triggers as $k => $lbl ) : ?>
								<option value="<?php echo esc_attr( $k ); ?>"><?php echo esc_html( $lbl ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>
					<label>تأخیر (ساعت، ۰ = فوری)<br><input type="number" name="delay_hours" value="0" min="0" style="<?php echo $in; ?>"></label>
					<label>شرط: حداقلِ مبلغِ سفارش (فقط تریگرهای سفارش)<br><input type="number" name="cond_min_total" value="0" min="0" style="<?php echo $in; ?>"></label>
				</div>
				<div style="font-size:12px;color:#9b9b9b;margin-bottom:4px;">متنِ پیامک — متغیر: <code>%name%</code> (نامِ مشتری). آدرسِ سایت خودکار افزوده می‌شود.</div>
				<input type="hidden" name="journey_pattern_code" id="j-pattern-code" value="">
				<?php
				farazsms_feature_pattern_builder_ui( 'journey', "%name% عزیز، از خریدت ممنونیم! 🌟", array( '%name%' ), 'journey_pattern_code' );
				?>
				<button type="submit" class="button button-primary" style="margin-top:8px;">➕ افزودنِ اتوماسیون</button>
				<p style="font-size:11.5px;color:#9b9b9b;margin-top:8px;">💡 برای زمان‌بندیِ دقیق، سرورتان باید کرونِ فعال داشته باشد (Action Scheduler ووکامرس استفاده می‌شود).</p>
			</form>
		</div>
	</div>
	<?php
}
