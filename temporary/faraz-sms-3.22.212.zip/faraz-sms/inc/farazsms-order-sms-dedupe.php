<?php
/**
 * جلوگیری از ارسال تکراری پیامک سفارش در یک تغییر وضعیت / یک درخواست.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * @return bool
 */
function farazsms_is_farazsmsnext_active_gateway() {
	if ( ! function_exists( 'PWSMS' ) ) {
		return false;
	}
	$active_gateway = PWSMS()->get_option( 'sms_gateway' );
	return farazsms_is_farazsmsnext_gateway_class( $active_gateway );
}

/**
 * حذف همهٔ callbackهای send_order_sms از PW\PWSMS\Orders (همهٔ هوک‌ها).
 *
 * @return void
 */
function farazsms_pwsms_detach_order_sms_hooks() {
	static $detached = false;
	if ( $detached ) {
		return;
	}
	$detached = true;

	$targets = array(
		'woocommerce_order_status_changed'    => 99,
		'woocommerce_checkout_order_processed' => 99,
		'woocommerce_process_shop_order_meta' => 999,
	);

	global $wp_filter;

	foreach ( $targets as $hook_name => $priority ) {
		if ( ! isset( $wp_filter[ $hook_name ] ) ) {
			continue;
		}
		$hook = $wp_filter[ $hook_name ];
		if ( ! $hook instanceof WP_Hook ) {
			continue;
		}
		if ( ! isset( $hook->callbacks[ $priority ] ) ) {
			continue;
		}
		foreach ( $hook->callbacks[ $priority ] as $callback ) {
			if ( empty( $callback['function'] ) || ! is_array( $callback['function'] ) ) {
				continue;
			}
			if ( empty( $callback['function'][1] ) || $callback['function'][1] !== 'send_order_sms' ) {
				continue;
			}
			if ( empty( $callback['function'][0] ) || ! is_object( $callback['function'][0] ) ) {
				continue;
			}
			$class = get_class( $callback['function'][0] );
			if ( $class === 'PW\PWSMS\Orders' || is_a( $callback['function'][0], 'PW\PWSMS\Orders' ) ) {
				remove_action( $hook_name, $callback['function'], $priority );
			}
		}
	}
}

/**
 * کلید یکتا برای dedupe: سفارش + نوع پیامک + وضعیت + گیرنده.
 *
 * @param int    $order_id
 * @param int    $sms_type 2=buyer, 4=super_admin, 5=product_admin
 * @param string $status   وضعیت اصلاح‌شده PWSMS
 * @param string $mobile   شماره یا لیست
 * @return string
 */
function farazsms_order_sms_dedupe_key( $order_id, $sms_type, $status, $mobile ) {
	$order_id = (int) $order_id;
	$sms_type = (int) $sms_type;
	$status   = sanitize_key( (string) $status );
	$mobile   = (string) $mobile;
	if ( strpos( $mobile, ',' ) !== false ) {
		$parts = array_map( 'trim', explode( ',', $mobile ) );
		$parts = array_filter( $parts );
		sort( $parts );
		$mobile = implode( ',', $parts );
	}
	return $order_id . '|' . $sms_type . '|' . $status . '|' . md5( $mobile );
}

/**
 * آیا برای این کلید هنوز می‌توان یک‌بار در این بازه ارسال کرد؟
 *
 * @param string $key
 * @return bool true = ارسال مجاز، false = تکراری
 */
function farazsms_order_sms_try_acquire_send( $key ) {
	static $request_sent = array();

	$key = (string) $key;
	if ( isset( $request_sent[ $key ] ) ) {
		return false;
	}

	$transient_key = 'farazsms_osd_' . md5( $key );
	if ( get_transient( $transient_key ) ) {
		return false;
	}

	$request_sent[ $key ] = true;
	// v3.22.94: قبلاً ۲ دقیقه بود — فقط برای dedupِ همان چک‌اوت (status_changed + payment_complete که
	// ثانیه‌ای فاصله دارند). ولی هوکِ woocommerce_update_order (v3.22.93) روی هر ذخیره‌ی بعدیِ سفارش هم
	// اجرا می‌شود؛ اگر مدیر ساعت‌ها/روزها بعد سفارش را ویرایش کند یا مرجوعیِ جزئی ثبت شود، transientِ
	// ۲دقیقه‌ای منقضی شده و پیامکِ تکراری می‌رفت. با ۳۰ روز، ارسال عملاً «یک‌بار به‌ازای وضعیت» می‌شود.
	set_transient( $transient_key, 1, 30 * DAY_IN_SECONDS );

	/**
	 * @param bool   $allow
	 * @param string $key
	 */
	return (bool) apply_filters( 'farazsms_order_sms_try_acquire_send', true, $key );
}

/**
 * کلیدِ متایِ ماندگارِ «این پیامک رفته».
 *
 * ⚠️ چرا اسلات لازم شد: کلید فقط از (نوع + وضعیت) ساخته می‌شد و عمداً مستقل از
 * شماره بود — که برای گیرنده‌ی **یکتا** (خریدار) درست است، چون ویرایشِ شماره‌ی
 * سفارش نباید قفلِ ارسال را باز کند. ولی دو مسیر روی چند گیرنده حلقه می‌زنند:
 *
 *   نوعِ ۴ — چند شماره‌ی مدیر
 *   نوعِ ۵ — چند فروشنده در یک سفارش
 *
 * آنجا کلیدِ مشترک یعنی گیرنده‌ی اول قفل را مصرف می‌کرد و بقیه برای همیشه
 * حذف می‌شدند — بی‌هیچ خطا و بی‌هیچ ردی در لاگ. «اسلات» همان تفکیک‌کننده‌ی
 * گیرنده است و فقط در همان مسیرهای چندگیرنده‌ای پر می‌شود.
 *
 * @param int    $sms_type
 * @param string $status
 * @param string $slot تفکیک‌کننده‌ی گیرنده (خالی = گیرنده‌ی یکتا، رفتارِ قبلی)
 * @return string
 */
function farazsms_order_sms_meta_key( $sms_type, $status, $slot = '' ) {
	$key = '_farazsms_osms_sent_' . (int) $sms_type . '_' . sanitize_key( (string) $status );
	$slot = sanitize_key( (string) $slot );
	return $slot !== '' ? ( $key . '_' . $slot ) : $key;
}

/**
 * اسلاتِ پایدارِ یک گیرنده — از شماره‌ی نرمال‌شده، تا نوشتنِ ۰۹۱۲... و +۹۸۹۱۲...
 * یک اسلات بدهند و پیامکِ تکراری نرود.
 *
 * @param string $phone
 * @return string
 */
function farazsms_order_sms_recipient_slot( $phone ) {
	$phone = (string) farazsms_normalize_phone( $phone );
	if ( $phone === '' ) {
		return '';
	}
	return substr( md5( $phone ), 0, 8 );
}

/**
 * آیا کلیدِ قدیمیِ بدونِ اسلات برای این (سفارش، نوع، وضعیت) ثبت شده؟
 *
 * @param int    $order_id
 * @param int    $sms_type
 * @param string $status
 * @return bool
 */
function farazsms_order_sms_legacy_sent( $order_id, $sms_type, $status ) {
	$order_id = (int) $order_id;
	if ( $order_id <= 0 || ! function_exists( 'wc_get_order' ) ) {
		return false;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order instanceof WC_Order ) {
		return false;
	}
	return (string) $order->get_meta( farazsms_order_sms_meta_key( $sms_type, $status ) ) === '1';
}

/**
 * نشانگرِ «این گروه را نسخه‌ی اسلات‌دار رسیدگی کرده».
 *
 * ⚠️ چرا کلیدِ جدا لازم شد: کلیدِ گروهی حالا **دو کار** می‌کرد — هم مسیرِ دومِ
 * ارسال را ساکت می‌کرد و هم نشانه‌ی «سفارشِ قدیمی» بود. چون خودِ کدِ جاری آن را
 * می‌نویسد، از دومین رویداد به بعد هر سفارشِ تازه هم «مهاجرت‌شده» تشخیص داده
 * می‌شد و شماره‌ی مدیرِ تازه‌اضافه‌شده بی‌آنکه پیامکی بگیرد مهر می‌خورد و برای
 * همیشه محروم می‌شد. یک سیگنال نمی‌تواند دو حقیقت را حمل کند.
 *
 * @param int    $sms_type
 * @param string $status
 * @return string
 */
function farazsms_order_sms_slotted_meta_key( $sms_type, $status ) {
	return '_farazsms_osms_slotted_' . (int) $sms_type . '_' . sanitize_key( (string) $status );
}

/**
 * ثبتِ صریحِ یک کلید (بدون گذشتن از قفلِ transient).
 *
 * @param int|WC_Order $order سفارش یا شناسه‌اش (پاس‌دادنِ آبجکت از بارگذاریِ تکراری جلوگیری می‌کند)
 * @param int          $sms_type
 * @param string       $status
 * @param string       $slot
 * @return void
 */
function farazsms_order_sms_stamp( $order, $sms_type, $status, $slot = '' ) {
	$order = farazsms_order_sms_resolve_order( $order );
	if ( ! $order ) {
		return;
	}
	$order->update_meta_data( farazsms_order_sms_meta_key( $sms_type, $status, $slot ), '1' );
	$order->save_meta_data();
}

/**
 * @param int|WC_Order $order
 * @return WC_Order|false
 */
function farazsms_order_sms_resolve_order( $order ) {
	if ( $order instanceof WC_Order ) {
		return $order;
	}
	$order_id = (int) $order;
	if ( $order_id <= 0 || ! function_exists( 'wc_get_order' ) ) {
		return false;
	}
	$loaded = wc_get_order( $order_id );
	return $loaded instanceof WC_Order ? $loaded : false;
}

/**
 * پایانِ رسیدگیِ یک گروهِ چندگیرنده‌ای را ثبت می‌کند.
 *
 * دو مهر با دو معنیِ کاملاً جدا، در **یک** ذخیره‌سازی:
 *
 *   کلیدِ گروهی    → مسیرِ دومِ ارسال (همان هوک، اولویتِ ۹۸) ساکت بماند
 *   نشانگرِ اسلات  → این سفارش دیگر «قدیمی» نیست و نباید مهاجرت شود
 *
 * ⚠️ مهرِ گروهی نباید به «آیا واقعاً چیزی رفت؟» گره بخورد. اگر همه‌ی گیرنده‌ها
 * از قبل مهر خورده باشند (سفارش‌های نسخه‌ی میانی، یا تکرارِ همان وضعیت)، باز هم
 * این مسیر رسیدگی کرده است و مسیرِ دوم باید ساکت بماند — وگرنه همان پیامکِ
 * تکراریِ مدیر برمی‌گردد.
 *
 * @param int|WC_Order $order
 * @param int          $sms_type
 * @param string       $status
 * @param array        $status_aliases وضعیت‌های هم‌ارز (مثلاً نگاشتِ افزونه‌ی ثالث)
 * @return void
 */
function farazsms_order_sms_mark_group_handled( $order, $sms_type, $status, $status_aliases = array() ) {
	$order = farazsms_order_sms_resolve_order( $order );
	if ( ! $order ) {
		return;
	}
	$all = array_unique( array_merge( array( (string) $status ), (array) $status_aliases ) );
	foreach ( $all as $one ) {
		if ( (string) $one === '' ) {
			continue;
		}
		$order->update_meta_data( farazsms_order_sms_meta_key( $sms_type, $one ), '1' );
		$order->update_meta_data( farazsms_order_sms_slotted_meta_key( $sms_type, $one ), '1' );
	}
	$order->save_meta_data();
}

/**
 * مهاجرتِ سفارش‌های پیش از نسخه‌ی اسلات‌دار.
 *
 * ⚠️ نسخه‌ی اولِ این مهاجرت کلیدِ قدیمی را به «گیرنده‌ی ایندکسِ صفر» نسبت می‌داد.
 * آن فرض غلط بود: ترتیبِ فهرستِ شماره‌های مدیر را خودِ مدیر تایپ می‌کند و ترتیبِ
 * فروشنده‌ها هیچ قراردادی ندارد. با جابه‌جا شدنِ یک شماره، کلیدِ قدیمی به گیرنده‌ی
 * اشتباه نسبت داده می‌شد و گیرنده‌ی واقعی پیامکِ تکراری می‌گرفت.
 *
 * رفتارِ درست و مستقل از ترتیب: کلیدِ قدیمی یعنی «این رویداد قبلاً پردازش شده».
 * پس کلِ گروه یک‌بار مهر می‌خورد و رد می‌شود. بدترین حالت این است که گیرنده‌های
 * دوم به بعد یک رویدادِ **تاریخی** را از دست می‌دهند — رویدادی که با کدِ قبلی هم
 * هرگز دریافت نمی‌کردند. در عوض هیچ پیامکِ تکراری‌ای فرستاده نمی‌شود.
 *
 * @param int    $order_id
 * @param int    $sms_type
 * @param string $status
 * @param array  $slots اسلاتِ همه‌ی گیرنده‌های فعلی
 * @return bool true = این گروه قبلاً پردازش شده، رد شود
 */
function farazsms_order_sms_group_migrated( $order_id, $sms_type, $status, $slots ) {
	$order = farazsms_order_sms_resolve_order( $order_id );
	if ( ! $order ) {
		return false;
	}

	// ⚠️ اول نشانگرِ اسلات: اگر این نسخه قبلاً به همین گروه رسیدگی کرده، سفارش
	// «قدیمی» نیست و مهاجرت نباید فعال شود. بدونِ این بررسی، کلیدِ گروهی‌ای که
	// خودمان می‌نویسیم به‌عنوانِ ردِ نسخه‌ی قدیمی خوانده می‌شد و گیرنده‌ی تازه
	// بی‌آنکه پیامکی بگیرد مهر می‌خورد.
	if ( (string) $order->get_meta( farazsms_order_sms_slotted_meta_key( $sms_type, $status ) ) === '1' ) {
		return false;
	}
	if ( (string) $order->get_meta( farazsms_order_sms_meta_key( $sms_type, $status ) ) !== '1' ) {
		return false; // نه نشانگرِ اسلات، نه کلیدِ قدیمی → سفارشِ تازه است.
	}

	// سفارشِ واقعاً قدیمی: کلِ گروه یک‌بار مهر می‌خورد (مستقل از ترتیبِ گیرنده‌ها).
	$stamped = 0;
	foreach ( (array) $slots as $slot ) {
		if ( (string) $slot !== '' ) {
			$order->update_meta_data( farazsms_order_sms_meta_key( $sms_type, $status, $slot ), '1' );
			$stamped++;
		}
	}
	$order->update_meta_data( farazsms_order_sms_slotted_meta_key( $sms_type, $status ), '1' );
	$order->save_meta_data();

	// فهرستِ گیرنده‌ی خالی: چیزی برای مهرزدن نبود، پس ادعای «مهاجرت شد» هم
	// نکنیم — وگرنه گروه بی‌دلیل سرکوب می‌شود.
	return $stamped > 0;
}

/**
 * @param int    $order_id
 * @param int    $sms_type
 * @param string $status
 * @param string $mobile
 * @param string $slot تفکیک‌کننده‌ی گیرنده در مسیرهای چندگیرنده‌ای (نوعِ ۴ و ۵)
 * @return bool
 */
function farazsms_order_sms_should_send_once( $order_id, $sms_type, $status, $mobile, $slot = '' ) {
	$order_id   = (int) $order_id;
	$sms_type   = (int) $sms_type;
	$status_key = sanitize_key( (string) $status );

	// لایه‌ی ماندگارِ order-meta (کدریویو): مستقل از انقضا/evictionِ transient و مستقل از تغییرِ
	// شماره‌ی موبایل. این علتِ اصلیِ «پیامکِ وضعیت دوبار رفت» را می‌بندد:
	// هوکِ woocommerce_update_order روی «هر» ذخیره‌ی سفارش fire می‌شود؛ اگر transient منقضی/evict شده بود
	// یا مدیر شماره‌ی موبایل را ویرایش کرده بود (کلیدِ transient حاویِ md5(mobile) است)، dedupeِ transient
	// آن را نمی‌گرفت و پیامکِ تکراری می‌رفت. order-meta تا ابد باقی می‌مانَد.
	// اسلات فقط گیرنده‌ها را از هم جدا می‌کند و این استقلال را نمی‌شکند.
	$order    = ( $order_id > 0 && function_exists( 'wc_get_order' ) ) ? wc_get_order( $order_id ) : false;
	$meta_key = '';
	if ( $order instanceof WC_Order ) {
		$meta_key = farazsms_order_sms_meta_key( $sms_type, $status_key, $slot );
		if ( (string) $order->get_meta( $meta_key ) === '1' ) {
			return false; // قبلاً برای همین (سفارش، نوع، وضعیت، گیرنده) ارسال شده — دیگر نه.
		}
	}

	$allow = farazsms_order_sms_try_acquire_send( farazsms_order_sms_dedupe_key( $order_id, $sms_type, $status, $mobile ) );

	if ( $allow && $order instanceof WC_Order && $meta_key !== '' ) {
		$order->update_meta_data( $meta_key, '1' );
		// فقط متا را ذخیره می‌کند؛ woocommerce_update_order را fire نمی‌کند، پس بازگشتِ به این هوک رخ نمی‌دهد.
		$order->save_meta_data();
	}

	return $allow;
}
