<?php
/**
 * بوت‌استرپِ کانالِ بله (MVP) — registryِ سرویس‌ها + بارگذاریِ مشروطِ بخشِ دیدنی.
 *
 * AD-9 (تک‌منبعِ سرویس‌ها): یک registryِ واحد `slug → برچسبِ فارسی` تنها منبعِ حقیقتِ
 * فهرستِ سرویس‌هاست؛ تیک‌های UI (استوریِ ۲.۳)، option خاموش‌ها، و slugای که فیچرها به
 * farazsms_bale_maybe_send می‌دهند همه از همین slugها استفاده می‌کنند. «فعال = نبودن در
 * option خاموش‌ها».
 *
 * AD-8 (بارگذاریِ مشروط): بخشِ دیدنی/اجراییِ بله (صفحه‌ی محصور، نوارِ وضعیت، تیک‌ها) فقط
 * وقتی بار می‌شود که کلیدِ بله تنظیم است — تا برای فروشگاهی که بله ندارد هیچ اثری (منو/
 * نوتیس/دارایی) دیده نشود و افزونه سبک بماند.
 *
 * تفکیکِ عمدی: فایل‌های config/service فقط «تعریفِ تابع» دارند (بی‌رندر، بی‌اثر)، پس همیشه
 * بار می‌شوند تا farazsms_bale_maybe_send همیشه در دسترس باشد و خودش را گِیت کند. فیلدِ
 * «کلیدِ بله» هم در صفحه‌ی تنظیماتِ اصلی است (استوریِ ۲.۱) و مشروط نیست — وگرنه واردکردنِ
 * اولین کلید ناممکن می‌شد. فقط بخشِ محصورِ ادمین این‌جا مشروط بار می‌شود.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * registryِ واحدِ سرویس‌های قابلِ‌ارسال در بله: slug → برچسبِ فارسی (AD-9).
 * slugها همان هویتِ فیچر در افزونه‌اند؛ با فیلترِ `farazsms_bale_services` قابلِ توسعه.
 * (وصل‌شدنِ واقعیِ هر فیچر در Epic 3 با ممیزیِ فیچر‌به‌فیچر انجام می‌شود.)
 *
 * @return array<string,string>
 */
function farazsms_bale_service_registry() {
	// فقط سرویس‌هایی که «متنِ حل‌شده» دارند و واقعاً به بله وصل‌اند (Epic 3 فاز ۱). بقیه
	// چون فقط pattern_code می‌فرستند و endpointِ پترنِ بله غیرفعال است، فعلاً بیرون‌اند و در
	// صفحه‌ی بله به‌عنوان «به‌زودی» نمایش داده می‌شوند (farazsms_bale_coming_soon_services).
	return apply_filters( 'farazsms_bale_services', array(
		'order'        => 'پیامکِ وضعیتِ سفارش',
		'tracking'     => 'کدِ رهگیریِ مرسوله',
		'abandoned'    => 'سبدِ خریدِ رهاشده',
		'bulk'         => 'ارسالِ گروهیِ پیامک',
		// یک اسلاگِ واحد برای هر سه دوره‌ی گزارشِ فروش؛ برچسب باید همین را بگوید، وگرنه
		// فروشنده از روی UI نمی‌فهمد که این یک تیک، هفتگی و ماهانه را هم خاموش می‌کند.
		'admin_report' => 'گزارشِ فروشِ مدیر (روزانه، هفتگی و ماهانه)',
	) );
}

/**
 * سرویس‌هایی که هنوز به بله وصل نشده‌اند (فقط pattern_code دارند) — برای نمایشِ «به‌زودی»
 * در صفحه‌ی «ارسال در بله». صرفاً برچسب؛ نه تیک، نه گِیت.
 *
 * @return string[] برچسب‌های فارسی
 */
function farazsms_bale_coming_soon_services() {
	return apply_filters( 'farazsms_bale_coming_soon', array(
		'تبریکِ تولد',
		'کش‌بک',
		'اطلاع‌رسانیِ موجودیِ کالا',
		'گردونهٔ شانس',
		'لیدمگنت',
		'خبرنامه',
		'نظرسنجی',
		'خوش‌آمدگویی',
	) );
}

/**
 * فهرستِ همه‌ی slugهای شناخته‌شده (کلیدهای registry).
 *
 * @return string[]
 */
function farazsms_bale_service_slugs() {
	return array_keys( farazsms_bale_service_registry() );
}

/**
 * برچسبِ فارسیِ یک سرویس (fallback: خودِ slug).
 *
 * @param string $slug
 * @return string
 */
function farazsms_bale_service_label( $slug ) {
	$reg = farazsms_bale_service_registry();
	return isset( $reg[ (string) $slug ] ) ? $reg[ (string) $slug ] : (string) $slug;
}

/**
 * فهرستِ slugهای «خاموش‌شده» از option (نرمال‌شده به آرایه‌ی رشته‌ای).
 * منبعِ واحدِ گِیت — همان option که farazsms_bale_service_enabled می‌خواند.
 *
 * @return string[]
 */
function farazsms_bale_disabled_services() {
	$d = get_option( 'farazsms_bale_disabled_services', array() );
	if ( ! is_array( $d ) ) {
		return array();
	}
	// فقط عناصرِ اسکالر — عنصرِ آرایه/آبجکتِ خرابِ option باعثِ noticeِ «Array to string» در strval می‌شد.
	$d = array_filter( $d, 'is_scalar' );
	return array_values( array_filter( array_map( 'strval', $d ), 'strlen' ) );
}

/**
 * فهرستِ سرویس‌های فعال = registry منهای خاموش‌ها (AD-9).
 *
 * @return string[]
 */
function farazsms_bale_enabled_services() {
	$disabled = farazsms_bale_disabled_services();
	return array_values( array_filter(
		farazsms_bale_service_slugs(),
		static function ( $slug ) use ( $disabled ) {
			return ! in_array( $slug, $disabled, true );
		}
	) );
}

/**
 * از روی فهرستِ slugهایی که کاربر «تیکِ روشن» گذاشته، آرایه‌ی خاموش‌ها را می‌سازد
 * (خاموش = registry منهای روشن‌ها). منبعِ واحدِ ذخیره‌ی تیک‌های صفحه‌ی «ارسال در بله».
 * پیش‌فرضِ MVP «همه روشن» است؛ پس اگر همه تیک بخورند، خاموش‌ها خالی می‌شود.
 *
 * @param array $enabled_slugs slugهای تیک‌خورده (روشن).
 * @return string[] slugهای خاموش برای option.
 */
function farazsms_bale_disabled_from_enabled( $enabled_slugs ) {
	$enabled_slugs = is_array( $enabled_slugs ) ? array_map( 'strval', $enabled_slugs ) : array();
	$disabled      = array();
	foreach ( farazsms_bale_service_slugs() as $slug ) {
		if ( ! in_array( $slug, $enabled_slugs, true ) ) {
			$disabled[] = $slug;
		}
	}
	return $disabled;
}

/**
 * بارگذاریِ مشروطِ بخشِ محصورِ ادمین (صفحه‌ی «ارسال در بله» + نوارِ وضعیت + تیک‌ها) —
 * فقط وقتی کلیدِ بله تنظیم است (AD-8). فایلِ ادمین در Epic 2 ساخته می‌شود؛ تا آن زمان
 * این هوک بی‌اثر است (file_exists = false).
 */
add_action( 'plugins_loaded', 'farazsms_bale_maybe_load_admin', 20 );
function farazsms_bale_maybe_load_admin() {
	if ( ! function_exists( 'is_admin' ) || ! is_admin() ) {
		return;
	}
	if ( ! farazsms_bale_is_configured() ) {
		return; // بدونِ کلید: هیچ چیزِ دیدنیِ بله بار/اجرا نمی‌شود
	}
	if ( defined( 'FARAZSMS_CORE_INC' ) ) {
		$admin = FARAZSMS_CORE_INC . 'farazsms-bale-admin.php';
		if ( file_exists( $admin ) ) {
			require_once $admin;
		}
	}
}
