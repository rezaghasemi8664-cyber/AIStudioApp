<?php
/**
 * فراز اس ام اس - بخش دیدگاه سایت
 *
 * v3.17.3 — رفتار جدید فرم دیدگاه:
 *   - فیلد شماره موبایل اختیاری (toggle قابل تنظیم)
 *   - فیلد ایمیل پیش‌فرض حذف می‌شود (toggle قابل تنظیم)
 *   - اگر WP ایمیل را الزامی بداند، fake email از روی موبایل ساخته می‌شود
 *     (مثلاً 09120000000@my-domain.com) — تا بازدیدکننده با فقط نام + موبایل
 *     بتواند دیدگاه ثبت کند
 *   - برای کاربر لاگین: شماره موبایل یکبار در user_meta ذخیره می‌شود و
 *     دفعات بعدی دیگر پرسیده نمی‌شود
 */
if ( ! defined( 'WPINC' ) ) {
	die;
}

// ============================================================================
// تنظیمات بخش فرم دیدگاه — با defaults منطقی
// ============================================================================

function farazsms_comment_form_settings() {
	$defaults = array(
		'phone_enabled'        => '1',  // نمایش فیلد موبایل
		'phone_required'       => '0',  // الزامی بودن موبایل
		'hide_email'           => '1',  // پنهان کردن فیلد ایمیل
		'fake_email_domain'    => '',   // domain برای ایمیل ساختگی (خالی = خودکار از site_url)
		'remember_user_phone'  => '1',  // یادآوری شماره موبایل کاربر لاگین
	);
	$saved = get_option( 'farazsms_comment_form_settings', array() );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
}

// Save handler — v3.17.3
add_action( 'admin_post_farazsms_save_comment_form_settings', 'farazsms_save_comment_form_settings' );
function farazsms_save_comment_form_settings() {
	if ( ! current_user_can( 'manage_options' ) ) wp_die();
	check_admin_referer( 'farazsms_save_comment_form_settings' );

	$new = array(
		'phone_enabled'        => isset( $_POST['phone_enabled'] ) ? '1' : '0',
		'phone_required'       => isset( $_POST['phone_required'] ) ? '1' : '0',
		'hide_email'           => isset( $_POST['hide_email'] ) ? '1' : '0',
		'fake_email_domain'    => isset( $_POST['fake_email_domain'] ) ? sanitize_text_field( wp_unslash( $_POST['fake_email_domain'] ) ) : '',
		'remember_user_phone'  => isset( $_POST['remember_user_phone'] ) ? '1' : '0',
	);
	update_option( 'farazsms_comment_form_settings', $new, false );

	wp_safe_redirect( add_query_arg( 'comment_form_saved', '1', wp_get_referer() ) );
	exit;
}

// ============================================================================
// فیلد موبایل + پنهان‌سازی ایمیل
// ============================================================================

// حذفِ فیلدِ ایمیلِ مهمان (در صورتِ hide_email) — این فیلتر برای مهمان‌هاست.
add_filter( 'comment_form_default_fields', 'farazsms_comment_form_hide_email', 20 );
function farazsms_comment_form_hide_email( $fields ) {
	$s = farazsms_comment_form_settings();
	if ( $s['hide_email'] === '1' && isset( $fields['email'] ) ) {
		unset( $fields['email'] );
	}
	return $fields;
}

/**
 * HTMLِ فیلدِ موبایل (مشترکِ مهمان و کاربرِ لاگین). برای کاربرِ لاگین با remember،
 * اگر شماره از قبل ذخیره شده باشد، یک inputِ مخفی برمی‌گرداند.
 */
function farazsms_comment_mobile_field_html( $s ) {
	if ( is_user_logged_in() && $s['remember_user_phone'] === '1' ) {
		$existing = (string) get_user_meta( get_current_user_id(), 'farazsms_comment_mobile', true );
		if ( $existing !== '' ) {
			return '<input type="hidden" name="farazsms_comment_mobile" value="' . esc_attr( $existing ) . '">';
		}
	}
	$placeholder = $s['phone_required'] === '1' ? 'مثال: 09123456789' : 'اختیاری — برای اطلاع از پاسخ دیدگاه';
	$req_mark    = $s['phone_required'] === '1' ? ' <span class="required" style="color:#d52a16;">*</span>' : '';
	$req_attr    = $s['phone_required'] === '1' ? ' required="required" aria-required="true"' : '';
	$value       = esc_attr( isset( $_POST['farazsms_comment_mobile'] ) ? wp_unslash( $_POST['farazsms_comment_mobile'] ) : '' );
	// v3.21.53: بدونِ استایلِ inline + کلاسِ comment-form-author تا مثلِ فیلدِ نام/ایمیلِ همان قالب باشد.
	return '<p class="comment-form-author comment-form-farazsms-mobile">' .
		'<label for="farazsms_comment_mobile">📱 شماره موبایل' . $req_mark . '</label> ' .
		'<input id="farazsms_comment_mobile" name="farazsms_comment_mobile" type="tel" value="' . $value .
		'" size="30" maxlength="15" placeholder="' . esc_attr( $placeholder ) . '"' . $req_attr . ' /></p>';
}

/**
 * v3.21.53: تزریقِ فیلدِ موبایل از طریقِ comment_form_fields (نه comment_form_default_fields).
 * این فیلتر شاملِ همه‌ی فیلدها (از جمله متنِ دیدگاه) است و تقریباً همه‌ی قالب‌ها — حتی
 * قالب‌های فارسیِ سفارشی — از آن عبور می‌کنند. قبلاً فقط روی comment_form_default_fields
 * بودیم که بعضی قالب‌ها آن را اجرا نمی‌کنند و فیلد «حتی با فعال‌بودن» نمایش داده نمی‌شد.
 * برای مهمان و کاربرِ لاگین یکدست عمل می‌کند.
 */
add_filter( 'comment_form_fields', 'farazsms_comment_inject_mobile_field', 20 );
function farazsms_comment_inject_mobile_field( $fields ) {
	$s = farazsms_comment_form_settings();
	if ( $s['phone_enabled'] !== '1' || isset( $fields['farazsms_comment_mobile'] ) ) {
		return $fields;
	}
	$html = farazsms_comment_mobile_field_html( $s );

	// بعد از آخرین فیلدِ نام/ایمیل/سایت قرار بده؛ اگر نبود (کاربرِ لاگین)، ابتدای فرم.
	$anchor = null;
	foreach ( array( 'url', 'email', 'author' ) as $k ) {
		if ( isset( $fields[ $k ] ) ) { $anchor = $k; break; }
	}
	if ( $anchor === null ) {
		return array( 'farazsms_comment_mobile' => $html ) + $fields;
	}
	$new = array();
	foreach ( $fields as $key => $val ) {
		$new[ $key ] = $val;
		if ( $key === $anchor ) {
			$new['farazsms_comment_mobile'] = $html;
		}
	}
	return $new;
}

/**
 * v3.17.3: اگر hide_email روشن است، WP option ای که ایمیل را الزامی می‌کند
 * را در runtime override کن — تا comment submit بدون ایمیل fail نشود.
 *
 * v3.20.6 BUG: این filter روی هر صفحه‌ای که option را می‌خواند fire می‌شود،
 * نه فقط روی صفحات comment. حتی WC checkout هم از این option استفاده می‌کند.
 * اضافه‌ی escape hatch + محدود کردن به صفحات غیر-checkout.
 */
add_filter( 'pre_option_require_name_email', 'farazsms_comment_relax_email_requirement' );
function farazsms_comment_relax_email_requirement( $value ) {
	// v3.20.6 ESCAPE HATCH
	if ( defined( 'FARAZSMS_DISABLE_COMMENTS_FILTER' ) && FARAZSMS_DISABLE_COMMENTS_FILTER ) return $value;
	// روی صفحات checkout این override را اعمال نکن — WC به این option وابسته است
	if ( function_exists( 'is_checkout' ) && is_checkout() ) return $value;
	if ( function_exists( 'is_admin' ) && is_admin() ) return $value;

	$s = farazsms_comment_form_settings();
	if ( $s['hide_email'] === '1' ) {
		return '0';
	}
	return $value;
}

/**
 * Validate + auto-generate fake email از موبایل، در preprocess_comment.
 */
add_filter( 'preprocess_comment', 'farazsms_comment_validate_mobile' );
function farazsms_comment_validate_mobile( $commentdata ) {
	$s = farazsms_comment_form_settings();

	$mobile     = isset( $_POST['farazsms_comment_mobile'] ) ? sanitize_text_field( wp_unslash( $_POST['farazsms_comment_mobile'] ) ) : '';
	$normalized = '';

	if ( ! empty( trim( $mobile ) ) ) {
		$normalized = farazsms_comment_normalize_mobile( $mobile );
		if ( ! $normalized ) {
			wp_die( 'شماره موبایل معتبر نیست. فرمت صحیح: 09123456789', 'خطا', array( 'back_link' => true ) );
		}
	}

	// پاسخِ مدیر از پیشخان نباید نیازمند شماره موبایل باشد. وقتی مدیر به دیدگاه کاربر
	// پاسخ می‌دهد، فیلد موبایلِ فرانت‌اند وجود ندارد و نباید اجباری‌بودن موبایل اعمال شود؛
	// پیامکِ پاسخ جداگانه به صاحب دیدگاهِ والد ارسال می‌شود.
	$is_admin_reply = is_admin() || current_user_can( 'moderate_comments' );

	// v3.17.3: اگر موبایل اجباری است ولی وارد نشده، خطا (به‌جز پاسخ مدیر)
	if ( ! $is_admin_reply && $s['phone_enabled'] === '1' && $s['phone_required'] === '1' && $normalized === '' ) {
		wp_die( 'وارد کردن شماره موبایل برای ثبت دیدگاه الزامی است.', 'خطا', array( 'back_link' => true ) );
	}

	// v3.17.3: اگر ایمیل خالی است (چون فیلد را پنهان کرده‌ایم) و موبایل داریم،
	// fake email از روی موبایل بساز — مثل 09120000000@mydomain.com
	if ( $s['hide_email'] === '1' && empty( $commentdata['comment_author_email'] ) && $normalized !== '' ) {
		$commentdata['comment_author_email'] = farazsms_comment_generate_fake_email( $normalized, $s['fake_email_domain'] );
	}

	return $commentdata;
}

/**
 * تولید ایمیل ساختگی از روی شماره موبایل — برای رضایت WP بدون نیاز به فیلد ایمیل.
 */
function farazsms_comment_generate_fake_email( $mobile, $custom_domain = '' ) {
	$domain = trim( (string) $custom_domain );
	if ( $domain === '' ) {
		$domain = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$domain = preg_replace( '#^www\.#i', '', $domain );
	}
	if ( $domain === '' ) {
		$domain = 'example.com';
	}
	return $mobile . '@' . $domain;
}

function farazsms_comment_normalize_mobile( $phone ) {
	if ( empty( $phone ) ) {
		return '';
	}
	$phone = preg_replace( '/\s+/', '', $phone );
	$phone = farazsms_normalize_phone( $phone );
	if ( preg_match( '/^09\d{9}$/', $phone ) ) {
		return $phone;
	}
	return false;
}

add_action( 'comment_post', 'farazsms_comment_save_mobile_meta', 10, 3 );
function farazsms_comment_save_mobile_meta( $comment_id, $comment_approved, $commentdata ) {
	$mobile = isset( $_POST['farazsms_comment_mobile'] ) ? sanitize_text_field( wp_unslash( $_POST['farazsms_comment_mobile'] ) ) : '';
	if ( empty( $mobile ) ) {
		return;
	}
	$normalized = farazsms_comment_normalize_mobile( $mobile );
	if ( ! $normalized ) {
		return;
	}
	add_comment_meta( $comment_id, 'farazsms_mobile', $normalized, true ) || update_comment_meta( $comment_id, 'farazsms_mobile', $normalized );

	// v3.17.3: اگر کاربر لاگین است و toggle remember روشن، در user_meta ذخیره کن
	$s = farazsms_comment_form_settings();
	if ( $s['remember_user_phone'] === '1' && is_user_logged_in() ) {
		update_user_meta( get_current_user_id(), 'farazsms_comment_mobile', $normalized );
	}
}

// --- ارسال پیامک در رویدادها ---

/**
 * ساخت attributes از متن پترن و مقادیر داده‌شده و ارسال با farazsms_send_pattern_sms_raw
 */
function farazsms_comment_send_pattern( $recipient, $pattern_code, $message_template, $all_values ) {
	if ( empty( $pattern_code ) || empty( $recipient ) || ! function_exists( 'farazsms_send_pattern_sms_raw' ) ) {
		return false;
	}
	$keys = farazsms_tracking_pattern_var_keys_from_message( $message_template );
	if ( empty( $keys ) && is_string( $message_template ) ) {
		preg_match_all( '/%([a-zA-Z0-9_]+)%/', $message_template, $matches );
		$keys = ! empty( $matches[1] ) ? array_unique( $matches[1] ) : array();
	}
	$attributes = array();
	foreach ( $keys as $key ) {
		if ( isset( $all_values[ $key ] ) ) {
			$attributes[ $key ] = $all_values[ $key ];
		}
	}
	$result = farazsms_send_pattern_sms_raw( $recipient, $pattern_code, $attributes, '' );
	return $result === 'success';
}

/**
 * ۱) اطلاع به مدیر هنگام ثبت دیدگاه
 * ۲) اطلاع به کاربر هنگام پاسخ به دیدگاه
 */
add_action( 'comment_post', 'farazsms_comment_on_comment_post_sms', 20, 3 );
/**
 * ثبتِ دیدگاه یک درخواستِ کاملاً فرانت است. تا v3.22.197 کلِ کارِ اطلاع‌رسانی
 * — یک تماس با کوتاه‌کننده و یک ارسال به ازای هر شماره‌ی مدیر — روی همین
 * درخواست انجام می‌شد. با سه شماره‌ی مدیر و قطعیِ شبکه یعنی نویسنده‌ی دیدگاه
 * تا ۴۵ ثانیه صفحه‌ی معلق می‌دید.
 *
 * حالا فقط یک ردیف وارد صف می‌شود؛ خودِ کار در کارگر اجرا می‌شود. کارِ سنگین
 * عمداً یک «کار» است نه «ارسالِ پترن»، چون کوتاه‌کردنِ لینک پیش از ساختِ
 * متغیرها لازم است و اگر بماند نیمی از هزینه روی درخواستِ کاربر می‌ماند.
 */
function farazsms_comment_on_comment_post_sms( $comment_id, $comment_approved, $commentdata ) {
	// گاردِ واجدشرایط‌بودن باید **پیش از** صف‌گذاری باشد. با صف‌گذاریِ بی‌قید،
	// هر دیدگاه روی هر سایتی — از جمله سایت‌هایی که این قابلیت را هرگز روشن
	// نکرده‌اند — یک ردیفِ صف، یک نوشتنِ آپشن و یک اجراکننده می‌ساخت.
	if ( get_option( 'farazsms_comment_admin_pattern', '' ) === ''
		&& get_option( 'farazsms_comment_user_reply_pattern', '' ) === '' ) {
		return;
	}
	farazsms_queue_task( 'comments', 'farazsms_comment_dispatch_post_sms', array( (int) $comment_id ) );
}

/**
 * کارگرِ اطلاع‌رسانیِ ثبتِ دیدگاه (خارج از درخواستِ بازدیدکننده).
 *
 * @param int $comment_id
 */
function farazsms_comment_dispatch_post_sms( $comment_id ) {
	$comment = get_comment( $comment_id );
	if ( ! $comment ) {
		return;
	}
	$parent_id = (int) $comment->comment_parent;

	if ( $parent_id === 0 ) {
		// دیدگاه جدید → اطلاع به مدیر
		$pattern  = get_option( 'farazsms_comment_admin_pattern', '' );
		$message  = get_option( 'farazsms_comment_admin_message', '' );
		$phones   = get_option( 'farazsms_comment_admin_phones', '' );
		if ( empty( $pattern ) || empty( trim( $phones ) ) ) {
			return;
		}
		$all_values = array(
			'comment_author'       => $comment->comment_author,
			'comment_author_email' => $comment->comment_author_email,
		);
		$phones = farazsms_split_mobile_list( $phones );
		foreach ( $phones as $phone ) {
			if ( $phone !== '' ) {
				farazsms_comment_send_pattern( $phone, $pattern, $message, $all_values );
			}
		}
		return;
	}

	// پاسخ به دیدگاه → اطلاع به صاحب نظر والد
	$pattern = get_option( 'farazsms_comment_user_reply_pattern', '' );
	$message = get_option( 'farazsms_comment_user_reply_message', '' );
	if ( empty( $pattern ) ) {
		return;
	}
	$parent = get_comment( $parent_id );
	if ( ! $parent ) {
		return;
	}
	$parent_mobile = get_comment_meta( $parent_id, 'farazsms_mobile', true );
	if ( empty( $parent_mobile ) ) {
		return;
	}
	// v3.22.143: لینکِ خوانا — نوشته‌ی انگلیسی‌نامک پیوندِ یکتای خودش، نوشته‌ی فارسی‌نامک
	// لینکِ شناسه‌ای (?p=ID#comment-X) تا متنِ پیامک با URLِ درصد-کدشده بلند نشود.
	$reply_link = farazsms_sms_readable_post_link( $comment->comment_post_ID, 'comment-' . (int) $comment_id );
	if ( $reply_link === '' ) {
		$reply_link = get_comment_link( $comment_id );
	}
	// کوتاه‌کننده‌ی فراز (پیش‌فرض) — مگر کاربر برای ماژولِ «دیدگاه» لینکِ سایتِ اصلی را انتخاب کرده باشد.
	$reply_link = farazsms_shorten_link( $reply_link, 'comments', 'ماژول دیدگاه‌های سایت / پاسخ به دیدگاه' );
	$all_values = array(
		'comment_author' => $comment->comment_author,
		'comment_link'   => $reply_link,
	);
	farazsms_comment_send_pattern( $parent_mobile, $pattern, $message, $all_values );
}

/**
 * ۳) اطلاع به کاربر هنگام تایید یا رد دیدگاه
 */
add_action( 'transition_comment_status', 'farazsms_comment_on_status_transition_sms', 10, 3 );
function farazsms_comment_on_status_transition_sms( $new_status, $old_status, $comment ) {
	if ( ! $comment instanceof WP_Comment ) {
		return;
	}
	if ( get_option( 'farazsms_comment_user_approve_pattern', '' ) === '' ) {
		return;
	}
	farazsms_queue_task( 'comments', 'farazsms_comment_dispatch_status_sms', array(
		(string) $new_status,
		(int) $comment->comment_ID,
	) );
}

/**
 * کارگرِ اطلاع‌رسانیِ تایید/ردِ دیدگاه.
 *
 * @param string $new_status
 * @param int    $comment_id
 */
function farazsms_comment_dispatch_status_sms( $new_status, $comment_id ) {
	$comment = get_comment( $comment_id );
	if ( ! $comment ) {
		return;
	}
	$pattern = get_option( 'farazsms_comment_user_approve_pattern', '' );
	$message = get_option( 'farazsms_comment_user_approve_message', '' );
	if ( empty( $pattern ) ) {
		return;
	}
	// فقط هنگام تایید (approved) یا رد (hold, spam, trash)
	$send_on = array( 'approved', 'hold', 'spam', 'trash' );
	if ( ! in_array( $new_status, $send_on, true ) ) {
		return;
	}
	$mobile = get_comment_meta( $comment->comment_ID, 'farazsms_mobile', true );
	if ( empty( $mobile ) ) {
		return;
	}
	$status_label = ( $new_status === 'approved' ) ? 'تایید' : 'رد';
	$comment_link = farazsms_sms_readable_post_link( $comment->comment_post_ID, 'comment-' . (int) $comment->comment_ID );
	if ( $comment_link === '' ) {
		$comment_link = get_comment_link( $comment );
	}
	// کوتاه‌کننده‌ی فراز (پیش‌فرض) — مگر کاربر برای ماژولِ «دیدگاه» لینکِ سایتِ اصلی را انتخاب کرده باشد.
	$comment_link = farazsms_shorten_link( $comment_link, 'comments', 'ماژول دیدگاه‌های سایت / وضعیتِ دیدگاه' );
	$all_values   = array(
		'comment_author' => $comment->comment_author,
		'comment_link'   => $comment_link,
		'status'         => $status_label,
	);
	farazsms_comment_send_pattern( $mobile, $pattern, $message, $all_values );
}
