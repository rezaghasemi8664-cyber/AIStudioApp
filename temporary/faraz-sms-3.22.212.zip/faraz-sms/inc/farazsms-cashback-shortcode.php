<?php
/**
 * شورت‌کدِ نمایشِ کش‌بکِ کاربر — [farazsms_cashback]
 *
 * در المنتور، پروفایل، یا هر جای ناحیه‌ی کاربری قابلِ استفاده است. میزانِ کش‌بکِ
 * «قابلِ استفاده»، «استفاده‌شده» و «سوخت‌شده (منقضی)» کاربرِ لاگین را نشان می‌دهد.
 *
 * نمونه‌ها:
 *   [farazsms_cashback]
 *   [farazsms_cashback show="usable"]                 فقط قابلِ استفاده
 *   [farazsms_cashback show="usable,used,expired" title="کش‌بکِ من"]
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * خلاصه‌ی کش‌بکِ یک کاربر.
 *
 * @param int $user_id
 * @return array{usable:float, used:float, expired:float}
 */
function farazsms_cashback_user_summary( $user_id ) {
	$user_id = (int) $user_id;
	$out = array( 'usable' => 0.0, 'used' => 0.0, 'expired' => 0.0 );
	if ( $user_id <= 0 || ! function_exists( 'farazsms_cashback_credits_table' ) ) {
		return $out;
	}
	global $wpdb;
	$table = farazsms_cashback_credits_table();
	$now   = current_time( 'mysql' );

	// قابلِ استفاده: اعتبارِ فعالِ منقضی‌نشده (همان منطقِ get_balance).
	if ( function_exists( 'farazsms_cashback_get_balance' ) ) {
		$out['usable'] = (float) farazsms_cashback_get_balance( $user_id );
	} else {
		$out['usable'] = (float) $wpdb->get_var( $wpdb->prepare(
			"SELECT COALESCE(SUM(amount - used_amount),0) FROM $table WHERE user_id = %d AND status = %s AND expires_at > %s",
			$user_id, 'active', $now
		) );
	}

	// استفاده‌شده: مجموعِ مبلغِ مصرف‌شده (هر اعتبار).
	$out['used'] = (float) $wpdb->get_var( $wpdb->prepare(
		"SELECT COALESCE(SUM(used_amount),0) FROM $table WHERE user_id = %d",
		$user_id
	) );

	// سوخت‌شده: باقیمانده‌ی اعتبارهایی که منقضی شده‌اند (هرگز استفاده نشد).
	$out['expired'] = (float) $wpdb->get_var( $wpdb->prepare(
		"SELECT COALESCE(SUM(amount - used_amount),0) FROM $table WHERE user_id = %d AND expires_at <= %s AND (amount - used_amount) > 0",
		$user_id, $now
	) );

	return $out;
}

/**
 * فرمتِ مبلغ (با wc_price اگر هست، وگرنه عدد + «تومان»).
 */
function farazsms_cashback_format_amount( $amount ) {
	if ( function_exists( 'wc_price' ) ) {
		return farazsms_price_plain( (float) $amount );
	}
	return number_format_i18n( (float) $amount ) . ' تومان';
}

add_shortcode( 'farazsms_cashback', 'farazsms_cashback_shortcode' );
function farazsms_cashback_shortcode( $atts ) {
	$atts = shortcode_atts( array(
		'show'         => 'usable,used,expired', // کدام موارد
		'title'        => '',                    // عنوانِ اختیاری
		'user_id'      => 0,                     // پیش‌فرض: کاربرِ فعلی
		'login_notice' => '1',                   // اگر مهمان بود، پیام بده
	), $atts, 'farazsms_cashback' );

	$user_id = (int) $atts['user_id'];
	if ( $user_id <= 0 ) {
		$user_id = get_current_user_id();
	}
	if ( $user_id <= 0 ) {
		return $atts['login_notice'] === '1'
			? '<div class="farazsms-cashback-box farazsms-cashback-guest">برای مشاهده‌ی کش‌بک، وارد شوید.</div>'
			: '';
	}

	$summary = farazsms_cashback_user_summary( $user_id );
	$want    = array_filter( array_map( 'trim', explode( ',', strtolower( (string) $atts['show'] ) ) ) );
	if ( empty( $want ) ) {
		$want = array( 'usable', 'used', 'expired' );
	}

	$labels = array(
		'usable'  => 'قابل استفاده',
		'used'    => 'استفاده‌شده',
		'expired' => 'سوخت‌شده',
	);
	$colors = array(
		'usable'  => '#16a34a',
		'used'    => '#365891',
		'expired' => '#dc2626',
	);

	ob_start();
	?>
	<div class="farazsms-cashback-box" style="display:flex; flex-wrap:wrap; gap:12px; align-items:stretch;">
		<?php if ( trim( (string) $atts['title'] ) !== '' ) : ?>
			<div class="farazsms-cashback-title" style="flex-basis:100%; font-weight:700; margin-bottom:4px;"><?php echo esc_html( $atts['title'] ); ?></div>
		<?php endif; ?>
		<?php foreach ( $want as $key ) :
			if ( ! isset( $labels[ $key ] ) ) { continue; }
			?>
			<div class="farazsms-cashback-item farazsms-cashback-<?php echo esc_attr( $key ); ?>" style="flex:1; min-width:130px; border:1px solid #e5e7eb; border-radius:12px; padding:14px 16px; text-align:center;">
				<div class="farazsms-cashback-amount" style="font-size:18px; font-weight:800; color:<?php echo esc_attr( $colors[ $key ] ); ?>;">
					<?php echo esc_html( farazsms_cashback_format_amount( $summary[ $key ] ) ); ?>
				</div>
				<div class="farazsms-cashback-label" style="font-size:12.5px; color:#64748b; margin-top:4px;"><?php echo esc_html( $labels[ $key ] ); ?></div>
			</div>
		<?php endforeach; ?>
	</div>
	<?php
	return ob_get_clean();
}
