<?php
/**
 * Cashback Module — Phase 12 (v3.14.0+)
 *
 * سیستم کش‌بک خودکار بر اساس درصد فروش با تاریخ انقضا و یادآوری پیامکی.
 *
 * ┌─ Table of Contents ──────────────────────────────────────────────────────┐
 * │  L29-77    │ Constants, Schema names, Settings helpers                    │
 * │  L79-140   │ Schema install (dbDelta, 2 tables)                           │
 * │  L142-309  │ Balance + Operations: grant, consume (FIFO)                  │
 * │  L311-466  │ WC checkout integration: fee, checkbox, persist              │
 * │  L468-498  │ Admin order panel (per-order cashback meta)                  │
 * │  L500-575  │ Cron: expire old records + reminder SMS                      │
 * │  L576-683  │ Stats aggregation (used in admin dashboard)                  │
 * │  rest      │ Admin menu + Settings page + Users list render               │
 * └──────────────────────────────────────────────────────────────────────────┘
 *
 * مدل عملکرد:
 *   ۱) مشتری سفارش می‌دهد → وقتی به وضعیت trigger (پیش‌فرض: completed) رسید،
 *      x٪ از مبلغ پرداختی واقعی به کیف پول کش‌بک اضافه می‌شود (با expiry).
 *   ۲) در checkout بعدی، موجودی فعال (غیرمنقضی) به‌صورت fee منفی روی cart اعمال
 *      می‌شود — اختیاری با checkbox.
 *   ۳) از مبلغ پرداخت جدید (بدون استفاده از کش‌بک)، مجدداً x٪ کش‌بک اعطا می‌شود.
 *   ۴) cron روزانه — پیامک یادآوری N روز قبل از انقضا، انقضای رکوردهای منقضی.
 *
 * طراحی برای 100k سایت:
 *   - دو جدول جداگانه با index های بهینه (user_id+status+expires_at، order_id+credit_id)
 *   - balance با static cache در request — هر pageload فقط یک query
 *   - cron در batch با LIMIT — هرگز کل جدول scan نمی‌شود
 *   - hookهای checkout روی calculate_fees نسبتاً سبک (یک SELECT با index)
 *   - ارسال SMS با fallback API helper موجود + برای cron timeout 30s
 *   - default disabled — تا toggle on نشده، هیچ hook روی frontend اجرا نمی‌شود
 *   - HPOS-aware: $order->update_meta_data() نه update_post_meta
 *
 * NOTE برای maintainer ها:
 *   شکستن این فایل به ۴ فایل (schema, credits, cron, admin) برای v3.21 برنامه‌ریزی
 *   شده. الان به‌صورت یک فایل با ToC بالا نگه داشته شده تا regression در سیستم
 *   پولی نخوریم. هر کسی این فایل را ویرایش می‌کند، ToC را به‌روز کند.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

// v3.20.6 ESCAPE HATCH — debug کمک می‌کند بفهمیم cashback مقصر crash پرداخت است یا نه
if ( defined( 'FARAZSMS_DISABLE_CASHBACK' ) && FARAZSMS_DISABLE_CASHBACK ) {
	return; // کل فایل بدون اجرا — هیچ hook ای register نمی‌شود
}
if ( defined( 'FARAZSMS_DISABLE_CHECKOUT_HOOKS' ) && FARAZSMS_DISABLE_CHECKOUT_HOOKS ) {
	return;
}

// ============================================================================
// Constants & Schema
// ============================================================================

const FARAZSMS_CASHBACK_TABLE_CREDITS     = 'farazsms_cashback_credits';
const FARAZSMS_CASHBACK_TABLE_REDEMPTIONS = 'farazsms_cashback_redemptions';
const FARAZSMS_CASHBACK_CRON_HOOK         = 'farazsms_cashback_daily_cron';
const FARAZSMS_CASHBACK_SCHEMA_VERSION    = '1.0';

function farazsms_cashback_credits_table() {
	global $wpdb;
	return $wpdb->prefix . FARAZSMS_CASHBACK_TABLE_CREDITS;
}
function farazsms_cashback_redemptions_table() {
	global $wpdb;
	return $wpdb->prefix . FARAZSMS_CASHBACK_TABLE_REDEMPTIONS;
}

// ============================================================================
// Settings + Helpers
// ============================================================================

function farazsms_cashback_get_settings() {
	$defaults = array(
		'enabled'        => '0',
		'percent'        => 10,
		'expiry_days'    => 7,
		'min_order'      => 0,
		'max_per_order'  => 0,            // 0 = no cap
		'status_trigger' => 'completed',  // wc-{status} پیش‌فرض
		'reminders'      => array( 7, 3, 1 ),
		'pattern_code'   => '',           // برای پیامک یادآوری
		'in_cart_notice' => '1',          // نمایش نوتیس روی cart/checkout
	);
	$saved = get_option( 'farazsms_cashback_settings', array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}
	$merged = array_merge( $defaults, $saved );
	if ( ! is_array( $merged['reminders'] ) ) {
		$merged['reminders'] = $defaults['reminders'];
	}
	return $merged;
}

	function farazsms_cashback_is_enabled() {
		$s = farazsms_cashback_get_settings();
		return $s['enabled'] === '1';
	}

	function farazsms_cashback_default_pattern_message() {
		return "مشتری عزیز، %balance% تومان اعتبار کش‌بک شما تا %days_left% روز دیگر منقضی می‌شود.\n" .
			"برای استفاده، خرید بعدی خود را تکمیل کنید.\n" .
			get_site_url();
	}

// ============================================================================
// Schema (lazy — فقط وقتی toggle on می‌شود ساخته می‌شود)
// ============================================================================

function farazsms_cashback_maybe_install_schema() {
	if ( get_option( 'farazsms_cashback_schema_version' ) === FARAZSMS_CASHBACK_SCHEMA_VERSION ) {
		return;
	}
	global $wpdb;
	$charset_collate = $wpdb->get_charset_collate();
	$credits         = farazsms_cashback_credits_table();
	$redemptions     = farazsms_cashback_redemptions_table();

	$sql_credits = "CREATE TABLE $credits (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		user_id BIGINT(20) UNSIGNED NOT NULL,
		order_id BIGINT(20) UNSIGNED NOT NULL,
		amount DECIMAL(20,2) NOT NULL DEFAULT 0,
		used_amount DECIMAL(20,2) NOT NULL DEFAULT 0,
		status VARCHAR(20) NOT NULL DEFAULT 'active',
		created_at DATETIME NOT NULL,
		expires_at DATETIME NOT NULL,
		KEY user_status_expires (user_id, status, expires_at),
		KEY order_id (order_id),
		KEY expires_at (expires_at),
		PRIMARY KEY (id)
	) $charset_collate;";

	$sql_redemptions = "CREATE TABLE $redemptions (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		credit_id BIGINT(20) UNSIGNED NOT NULL,
		user_id BIGINT(20) UNSIGNED NOT NULL,
		order_id BIGINT(20) UNSIGNED NOT NULL,
		amount DECIMAL(20,2) NOT NULL DEFAULT 0,
		created_at DATETIME NOT NULL,
		KEY user_id (user_id),
		KEY order_id (order_id),
		KEY credit_id (credit_id),
		PRIMARY KEY (id)
	) $charset_collate;";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql_credits );
	dbDelta( $sql_redemptions );
	// v3.21.7: فقط وقتی هر دو جدول واقعاً ساخته شدند latch کن (شکستِ dbDelta = مرگِ بی‌صدا).
	$credits_ok     = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $credits ) ) === $credits );
	$redemptions_ok = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $redemptions ) ) === $redemptions );
	if ( $credits_ok && $redemptions_ok ) {
		update_option( 'farazsms_cashback_schema_version', FARAZSMS_CASHBACK_SCHEMA_VERSION, false );
	}
}

// Install schema هنگام toggle on
add_action( 'update_option_farazsms_cashback_settings', 'farazsms_cashback_on_settings_update', 10, 2 );
function farazsms_cashback_on_settings_update( $old, $new ) {
	if ( is_array( $new ) && ! empty( $new['enabled'] ) && $new['enabled'] === '1' ) {
		farazsms_cashback_maybe_install_schema();
		// Ensure cron scheduled
		if ( ! wp_next_scheduled( FARAZSMS_CASHBACK_CRON_HOOK ) ) {
			wp_schedule_event( time() + 60, 'daily', FARAZSMS_CASHBACK_CRON_HOOK );
		}
		// v3.21.88: زمانِ اولین فعال‌سازی را ثبت کن تا کش‌بک به سفارش‌های قدیمیِ پیش از فعال‌سازی
		// تعلق نگیرد (باگ: مارک‌کردنِ سفارش‌های قدیمی به‌عنوان تکمیل‌شده، کش‌بکِ گذشته‌نگر می‌داد).
		if ( ! get_option( 'farazsms_cashback_enabled_at' ) ) {
			update_option( 'farazsms_cashback_enabled_at', current_time( 'mysql' ), false );
		}
	}
}
add_action( 'add_option_farazsms_cashback_settings', 'farazsms_cashback_on_settings_added', 10, 2 );
function farazsms_cashback_on_settings_added( $name, $value ) {
	farazsms_cashback_on_settings_update( array(), $value );
}

// ============================================================================
// Balance + DB Operations
// ============================================================================

/**
 * موجودی فعال کش‌بک کاربر (مجموع باقیمانده غیرمنقضی).
 * Cache static در request — تا چندین فراخوانی روی هر pageload فقط یک query بزند.
 */
function farazsms_cashback_get_balance( $user_id ) {
	static $cache = array();
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return 0.0;
	}
	if ( isset( $cache[ $user_id ] ) ) {
		return $cache[ $user_id ];
	}
	global $wpdb;
	$table   = farazsms_cashback_credits_table();
	$balance = $wpdb->get_var( $wpdb->prepare(
		"SELECT COALESCE(SUM(amount - used_amount), 0) FROM $table
		 WHERE user_id = %d AND status = %s AND expires_at > %s",
		$user_id,
		'active',
		current_time( 'mysql' )
	) );
	$cache[ $user_id ] = (float) $balance;
	return $cache[ $user_id ];
}

function farazsms_cashback_invalidate_balance_cache( $user_id = null ) {
	// با reset کردن static از یک تابع helper — در همان request اعمال نمی‌شود مگر با ترفند.
	// در عمل، تغییرات balance فقط در پایان request اعمال می‌شود که OK است.
	// این تابع placeholder برای آینده.
	return;
}

/**
 * اعطای کش‌بک پس از تکمیل سفارش — idempotent.
 */
function farazsms_cashback_grant( $user_id, $order_id, $amount ) {
	$user_id  = (int) $user_id;
	$order_id = (int) $order_id;
	$amount   = (float) $amount;
	if ( $user_id <= 0 || $order_id <= 0 || $amount <= 0 ) {
		return false;
	}

	$expiry_days = max( 1, (int) farazsms_cashback_get_settings()['expiry_days'] );
	$now         = current_time( 'mysql' );
	$expires_at  = date( 'Y-m-d H:i:s', strtotime( $now . ' +' . $expiry_days . ' days' ) );

	global $wpdb;
	$inserted = $wpdb->insert(
		farazsms_cashback_credits_table(),
		array(
			'user_id'     => $user_id,
			'order_id'    => $order_id,
			'amount'      => $amount,
			'used_amount' => 0,
			'status'      => 'active',
			'created_at'  => $now,
			'expires_at'  => $expires_at,
		),
		array( '%d', '%d', '%f', '%f', '%s', '%s', '%s' )
	);
	if ( ! $inserted ) {
		return false;
	}

	$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
	if ( $order ) {
		$order->update_meta_data( 'farazsms_cashback_granted', 'yes' );
		$order->update_meta_data( 'farazsms_cashback_granted_amount', $amount );
		$order->update_meta_data( 'farazsms_cashback_granted_expires', $expires_at );
		$order->save_meta_data();
	}
	farazsms_cashback_invalidate_balance_cache( $user_id );
	return $wpdb->insert_id;
}

/**
 * مصرف کش‌بک — FIFO (قدیمی‌ترین expiry اول، تا کاربر اعتبارش از دست نرود).
 */
function farazsms_cashback_consume( $user_id, $order_id, $amount ) {
	$user_id  = (int) $user_id;
	$order_id = (int) $order_id;
	$amount   = (float) $amount;
	if ( $user_id <= 0 || $order_id <= 0 || $amount <= 0 ) {
		return 0.0;
	}
	global $wpdb;
	$credits_table     = farazsms_cashback_credits_table();
	$redemptions_table = farazsms_cashback_redemptions_table();
	$now               = current_time( 'mysql' );

	// v3.21.27 (P3) امنیتی/مالی — قفلِ advisoryِ per-user ضدِ double-spendِ هم‌زمان (مثلِ کیف‌پول).
	$cb_lock_name = 'fz_cashback_' . $user_id;
	$cb_got_lock  = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $cb_lock_name ) );

	// قدیمی‌ترین رکوردهای فعال غیرمنقضی — FIFO (close-to-expiry اول)
	$rows = $wpdb->get_results( $wpdb->prepare(
		"SELECT id, amount, used_amount FROM $credits_table
		 WHERE user_id = %d AND status = %s AND expires_at > %s
		 ORDER BY expires_at ASC, id ASC",
		$user_id,
		'active',
		$now
	), ARRAY_A );

	$consumed = 0.0;
	foreach ( $rows as $row ) {
		if ( $amount <= 0 ) break;
		$remaining = (float) $row['amount'] - (float) $row['used_amount'];
		if ( $remaining <= 0 ) continue;

		$take = min( $remaining, $amount );

		// آپدیت used_amount + در صورت اتمام، status='used'
		$new_used   = (float) $row['used_amount'] + $take;
		$new_status = ( $new_used >= (float) $row['amount'] ) ? 'used' : 'active';
		$wpdb->update(
			$credits_table,
			array( 'used_amount' => $new_used, 'status' => $new_status ),
			array( 'id' => $row['id'] ),
			array( '%f', '%s' ),
			array( '%d' )
		);
		// ثبت redemption
		$wpdb->insert(
			$redemptions_table,
			array(
				'credit_id'  => $row['id'],
				'user_id'    => $user_id,
				'order_id'   => $order_id,
				'amount'     => $take,
				'created_at' => $now,
			),
			array( '%d', '%d', '%d', '%f', '%s' )
		);
		$consumed += $take;
		$amount   -= $take;
	}

	if ( $cb_got_lock === 1 ) {
		$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $cb_lock_name ) );
	}
	return $consumed;
}

// ============================================================================
// WooCommerce Integration — Apply on Cart/Checkout
// ============================================================================

/**
 * فقط اگر toggle فعال است، WC hookها را register کن — جلوگیری از overhead.
 */
function farazsms_cashback_register_wc_hooks() {
	if ( ! farazsms_cashback_is_enabled() ) {
		return;
	}
	if ( ! function_exists( 'WC' ) ) {
		return;
	}
	add_action( 'woocommerce_cart_calculate_fees', 'farazsms_cashback_apply_fee', 20 );
	add_action( 'woocommerce_review_order_before_payment', 'farazsms_cashback_render_checkbox' );
	add_action( 'woocommerce_checkout_update_order_review', 'farazsms_cashback_persist_choice' );

		// اعطای کش‌بک دقیقاً فقط روی وضعیت انتخاب‌شده توسط مدیر.
		// قبلاً برای «امنیت پرداخت» processing/completed هم اضافه می‌شد و باعث اعطای زودهنگام
		// در وضعیت‌هایی مثل در حال انجام/بسته‌بندی می‌شد.
		$trigger = farazsms_cashback_normalize_status( farazsms_cashback_get_settings()['status_trigger'] ?? 'completed' );
		if ( $trigger !== '' ) {
			add_action( 'woocommerce_order_status_' . $trigger, 'farazsms_cashback_handle_order_complete', 20, 2 );
		}

	// مصرف کش‌بک هنگام ساخت سفارش
	add_action( 'woocommerce_checkout_order_processed', 'farazsms_cashback_finalize_consumption', 20, 3 );
}
	add_action( 'init', 'farazsms_cashback_register_wc_hooks', 20 );

	function farazsms_cashback_normalize_status( $status ) {
		$status = sanitize_key( preg_replace( '/^wc-/', '', (string) $status ) );
		return $status !== '' ? $status : 'completed';
	}

/**
 * اعمال fee منفی روی cart — اختیاری با checkbox.
 */
function farazsms_cashback_apply_fee() {
	if ( is_admin() && ! ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
		return;
	}
	if ( ! is_user_logged_in() ) {
		return;
	}
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return;
	}
	$use_cashback = WC()->session ? WC()->session->get( 'farazsms_use_cashback', '1' ) : '1';
	if ( $use_cashback !== '1' ) {
		return;
	}
	$user_id = get_current_user_id();
	$balance = farazsms_cashback_get_balance( $user_id );
	if ( $balance <= 0 ) {
		return;
	}
	// مبلغ قابل پرداخت = subtotal بدون این fee
	$cart_subtotal = (float) WC()->cart->get_subtotal();
	if ( $cart_subtotal <= 0 ) {
		return;
	}
	$apply = min( $balance, $cart_subtotal );
	if ( $apply > 0 ) {
		WC()->cart->add_fee( __( 'پرداخت از کیف پول کش‌بک', 'farazsms' ), -$apply, false );
	}
}

/**
 * نمایش checkbox روی صفحه پرداخت.
 */
function farazsms_cashback_render_checkbox() {
	if ( ! is_user_logged_in() ) {
		return;
	}
	$settings = farazsms_cashback_get_settings();
	if ( $settings['in_cart_notice'] !== '1' ) {
		return;
	}
	$user_id = get_current_user_id();
	$balance = farazsms_cashback_get_balance( $user_id );
	if ( $balance <= 0 ) {
		return;
	}
	$use_cashback = WC()->session ? WC()->session->get( 'farazsms_use_cashback', '1' ) : '1';
	?>
	<div style="background:#ecfdf5; border:1px solid #a7f3d0; padding:14px 16px; border-radius:10px; margin:14px 0; direction:rtl; box-sizing:border-box; min-width:min(100%, 260px);">
		<label style="display:flex; flex-flow:row nowrap; align-items:center; gap:10px; cursor:pointer; margin:0; writing-mode:horizontal-tb;">
			<input type="checkbox" name="farazsms_use_cashback" value="1" <?php checked( $use_cashback === '1' ); ?> onchange="if(window.jQuery){jQuery('body').trigger('update_checkout');}" style="margin:0; flex:0 0 auto; width:18px; height:18px;">
			<?php // بدونِ overflow-wrap:break-word — در ستونِ باریک، شکستنِ میانِ کلمه متن را حرف‌به‌حرف می‌کند؛ سرریزِ محترمانه بهتر از متنِ ناخواناست. ?>
			<span style="flex:1 1 auto; min-width:0; white-space:normal; word-break:normal; line-height:1.6; font-size:14px; font-weight:600; color:#065f46;">
				💰 از کیف پول کش‌بک خود استفاده کنم:
				<strong style="color:#047857;"><?php echo esc_html( number_format_i18n( $balance ) ); ?></strong>
				<?php
				if ( function_exists( 'get_woocommerce_currency_symbol' ) ) {
					echo ' ' . esc_html( get_woocommerce_currency_symbol() );
				}
				?>
			</span>
		</label>
	</div>
	<?php
}

/**
 * ذخیره انتخاب کاربر در session هنگام update_order_review.
 */
function farazsms_cashback_persist_choice( $post_data ) {
	parse_str( (string) $post_data, $data );
	if ( ! WC()->session ) {
		return;
	}
	$use = isset( $data['farazsms_use_cashback'] ) && $data['farazsms_use_cashback'] === '1' ? '1' : '0';
	WC()->session->set( 'farazsms_use_cashback', $use );
}

/**
 * Finalize: ثبت redemption بعد از ساخت سفارش.
 */
function farazsms_cashback_finalize_consumption( $order_id, $posted_data, $order ) {
	if ( ! ( $order instanceof WC_Order ) ) {
		$order = wc_get_order( $order_id );
		if ( ! $order ) return;
	}
	$user_id = $order->get_user_id();
	if ( $user_id <= 0 ) return;

	// fee کش‌بک — نام fee را با add_fee ست کرده‌ایم
	$applied = 0.0;
	foreach ( $order->get_fees() as $fee ) {
		if ( $fee->get_name() === __( 'پرداخت از کیف پول کش‌بک', 'farazsms' ) ) {
			$amt = abs( (float) $fee->get_amount() );
			if ( $amt > 0 ) {
				$applied += $amt;
			}
		}
	}
	if ( $applied <= 0 ) {
		return;
	}
	$consumed = farazsms_cashback_consume( $user_id, $order_id, $applied );
	$order->update_meta_data( 'farazsms_cashback_used_amount', $consumed );
	$order->save();
}

// ============================================================================
// واجدِ شرایط بودنِ سفارش — منطقِ خالص + دلیلِ ردشدن
// ============================================================================

/**
 * آیا سفارش از نظرِ «زمانِ فعال‌سازی» واجدِ شرایط است؟ (منطقِ خالص و آزمودنی)
 *
 * @param int  $created_ts      زمانِ ساختِ سفارش.
 * @param int  $enabled_at_ts   زمانِ فعال‌سازیِ کش‌بک.
 * @param bool $just_backfilled آیا همین حالا زمانِ فعال‌سازی را خودمان نوشتیم؟
 * @return bool
 */
function farazsms_cashback_order_is_eligible( $created_ts, $enabled_at_ts, $just_backfilled, $backfill_floor_ts = 0 ) {
	// نگهبان نباید سفارشی را که خودش بیدارش کرد بخورد: وقتی گزینه نبود و همین‌جا با «الان»
	// پُرش کردیم، سفارشِ جاری قطعاً پیش از «الان» ساخته شده و همیشه رد می‌شد.
	// ولی این استثنا باید کران داشته باشد، وگرنه اولین سفارشِ پس از ارتقا می‌تواند یک سفارشِ
	// دوساله باشد و همان حفره‌ی «کش‌بکِ گذشته‌نگر» را که نگهبان برایش هست دوباره باز کند.
	if ( $just_backfilled ) {
		return (int) $backfill_floor_ts <= 0 || (int) $created_ts >= (int) $backfill_floor_ts;
	}
	// زمانِ نامعتبر نباید فیچر را بی‌صدا بکشد؛ نبودِ محدودیت بهتر از خاموشیِ خاموش است.
	if ( (int) $enabled_at_ts <= 0 || (int) $created_ts <= 0 ) {
		return true;
	}
	return (int) $created_ts >= (int) $enabled_at_ts;
}

/**
 * قواعدِ واجدشرایط‌بودنِ کش‌بک — یک فهرستِ مرتبِ داده‌ای، نه شرط‌های پخش‌شده در چند تابع.
 *
 * چرا داده و نه کد: پیش از این همین قواعد در دو تابع و هفت نقطه‌ی بازگشت پخش بودند. وقتی
 * هسته‌ی مشترک ساخته شد، شرطِ وضعیت جا ماند و روی سفارشِ مسترد اعتبارِ مالی ساخته شد. با
 * فهرستِ واحد، «مسیرِ دوم یک شرط را جا انداخت» از نظرِ ساختاری ممکن نیست.
 *
 * ترتیب معنادار است: هر قاعده فرض می‌کند قاعده‌های بالاتر گذشته‌اند.
 * skipped_by نامِ مسیرهایی است که از آن قاعده معاف‌اند.
 *
 * @return array<string,array{test:callable,skipped_by:string[]}>
 */
function farazsms_cashback_rules() {
	return array(
		'invalid_order'   => array(
			'test'       => static function ( $c ) { return $c['order'] instanceof WC_Order; },
			'skipped_by' => array(),
		),
		'disabled'        => array(
			'test'       => static function ( $c ) { return ( $c['settings']['enabled'] ?? '0' ) === '1'; },
			'skipped_by' => array(),
		),
		'status_mismatch' => array(
			'test'       => static function ( $c ) { return $c['expected_status'] === '' || $c['status'] === $c['expected_status']; },
			'skipped_by' => array(),
		),
		'no_customer'     => array(
			'test'       => static function ( $c ) { return $c['user_id'] > 0; },
			'skipped_by' => array(),
		),
		// تنها قاعده‌ای که جبرانِ دستی از آن معاف است: سفارش‌هایی که پیش از ۳٫۲۲٫۱۸۹ در
		// باگِ زمان سوختند دقیقاً همین‌جا رد می‌شدند و هدفِ دکمه‌ی جبران‌اند.
		'before_enabled'  => array(
			'test'       => static function ( $c ) {
				return farazsms_cashback_order_is_eligible( $c['created_ts'], $c['enabled_at_ts'], $c['just_backfilled'], $c['backfill_floor'] );
			},
			'skipped_by' => array( 'manual' ),
		),
		'already_granted' => array(
			'test'       => static function ( $c ) { return ! $c['already_granted']; },
			'skipped_by' => array(),
		),
		'zero_payable'    => array(
			'test'       => static function ( $c ) { return $c['payable'] > 0; },
			'skipped_by' => array(),
		),
		'amount_zero'     => array(
			'test'       => static function ( $c ) { return $c['amount'] > 0; },
			'skipped_by' => array(),
		),
	);
}

/**
 * همه‌ی واقعیت‌هایی که قواعد به آن‌ها نگاه می‌کنند — یک‌بار محاسبه می‌شوند.
 *
 * @param mixed $order
 * @return array
 */
function farazsms_cashback_build_context( $order ) {
	$settings = farazsms_cashback_get_settings();
	$ctx      = array(
		'order'           => $order,
		'settings'        => $settings,
		'expected_status' => farazsms_cashback_normalize_status( $settings['status_trigger'] ?? 'completed' ),
		'status'          => '',
		'user_id'         => 0,
		'payable'         => 0.0,
		'amount'          => 0.0,
		'already_granted' => false,
		'created_ts'      => 0,
		'enabled_at_ts'   => 0,
		'just_backfilled' => false,
		'backfill_floor'  => 0,
	);
	if ( ! ( $order instanceof WC_Order ) ) {
		return $ctx;
	}

	$ctx['status']          = farazsms_cashback_normalize_status( $order->get_status() );
	$ctx['user_id']         = (int) $order->get_user_id();
	$ctx['already_granted'] = ( $order->get_meta( 'farazsms_cashback_granted' ) === 'yes' );
	$ctx['payable']         = max( 0, (float) $order->get_total() - (float) $order->get_meta( 'farazsms_cashback_used_amount' ) );
	$ctx['amount']          = farazsms_cashback_calc_amount(
		$ctx['payable'],
		$settings['percent'] ?? 0,
		$settings['min_order'] ?? 0,
		$settings['max_per_order'] ?? 0
	);

	// زمانِ فعال‌سازی؛ اگر ثبت نشده بود همین‌جا ثبت می‌شود و همان اجرا معاف است.
	$enabled_at = get_option( 'farazsms_cashback_enabled_at' );
	if ( ! $enabled_at ) {
		$enabled_at              = current_time( 'mysql' );
		$ctx['just_backfilled']  = true;
		$ctx['backfill_floor']   = time() - ( max( 1, (int) apply_filters( 'farazsms_cashback_backfill_window_days', 30 ) ) * DAY_IN_SECONDS );
		update_option( 'farazsms_cashback_enabled_at', $enabled_at, false );
	}
	$ctx['enabled_at_ts'] = farazsms_local_mysql_to_ts( $enabled_at );
	$created              = $order->get_date_created();
	$ctx['created_ts']    = $created ? (int) $created->getTimestamp() : 0;

	return $ctx;
}

/**
 * اولین قاعده‌ی نقض‌شده.
 *
 * @param array  $ctx  خروجیِ سازنده‌ی زمینه.
 * @param string $path 'auto' | 'manual'
 * @return string کدِ دلیل؛ رشته‌ی خالی یعنی هیچ مانعی نیست.
 */
function farazsms_cashback_first_blocker( $ctx, $path = 'auto' ) {
	foreach ( farazsms_cashback_rules() as $code => $rule ) {
		if ( in_array( $path, $rule['skipped_by'], true ) ) {
			continue;
		}
		if ( ! call_user_func( $rule['test'], $ctx ) ) {
			return $code;
		}
	}
	return '';
}

/**
 * آیا این دلیل ارزشِ نوشتن روی سفارش را دارد؟ (سیاستِ گزارش، جدا از خودِ قاعده)
 *
 * @param string $code
 * @param string $path
 * @return bool
 */
function farazsms_cashback_should_record( $code, $path ) {
	if ( $path === 'manual' ) {
		return true; // مدیر صریحاً کلیک کرده و جوابش را می‌خواهد.
	}
	if ( $code === 'status_mismatch' ) {
		return false; // هر تغییرِ وضعیتی یک نوشتنِ متا می‌شد.
	}
	if ( $code === 'no_customer' ) {
		return ! farazsms_cashback_guest_orders_are_expected();
	}
	return true;
}

/** برچسبِ فارسیِ هر دلیل — برای نمایش در پنلِ سفارش. */
function farazsms_cashback_skip_reason_label( $code ) {
	// status_mismatch از مسیرِ خودکار ثبت نمی‌شود (هر تغییرِ وضعیت یک نوشتنِ متا می‌شد)، ولی
	// جبرانِ دستی آن را برمی‌گرداند و مدیر باید بداند چرا دکمه کار نکرد.
	$map = array(
		'status_mismatch' => __( 'وضعیتِ سفارش با وضعیتی که در تنظیماتِ کش‌بک انتخاب شده یکی نیست.', 'farazsms' ),
		'invalid_order'   => __( 'سفارش قابلِ خواندن نبود.', 'farazsms' ),
		'no_customer'     => __( 'سفارش به هیچ کاربرِ ثبت‌شده‌ای وصل نیست (سفارشِ مهمان). کش‌بک به حسابِ کاربری تعلق می‌گیرد.', 'farazsms' ),
		'before_enabled'  => __( 'سفارش پیش از فعال‌سازیِ کش‌بک ثبت شده است.', 'farazsms' ),
		'disabled'        => __( 'کش‌بک در تنظیمات خاموش است.', 'farazsms' ),
		'already_granted' => __( 'برای این سفارش قبلاً کش‌بک اعطا شده است.', 'farazsms' ),
		'zero_payable'    => __( 'مبلغِ قابلِ محاسبه صفر است (کلِ سفارش با کش‌بک پرداخت شده).', 'farazsms' ),
		'amount_zero'     => __( 'مبلغِ محاسبه‌شده صفر شد — حداقلِ سفارش یا درصدِ کش‌بک را بررسی کنید.', 'farazsms' ),
		'insert_failed'   => __( 'ثبت در جدولِ اعتبارها انجام نشد.', 'farazsms' ),
	);
	return $map[ (string) $code ] ?? (string) $code;
}

/**
 * آیا سفارشِ مهمان روی این فروشگاه «عادی» است؟
 *
 * وقتی تسویه‌ی مهمانِ ووکامرس روشن است، سفارشِ بدونِ کاربر رفتارِ طبیعیِ فروشگاه است و
 * هشدار دادن برایش فقط نویز می‌سازد. وقتی خاموش است، غیرمنتظره است و باید گزارش شود.
 *
 * @return bool
 */
function farazsms_cashback_guest_orders_are_expected() {
	// پیش‌فرضِ خودِ ووکامرس «بله» است؛ سخت‌گیرانه‌تر از هسته رفتار نکنیم.
	return get_option( 'woocommerce_enable_guest_checkout', 'yes' ) === 'yes';
}

/**
 * اعطای کش‌بک به یک سفارش — تنها نقطه‌ی تصمیم، برای هر دو مسیر.
 *
 * @param mixed  $order
 * @param string $path 'auto' (تغییرِ وضعیت) | 'manual' (دکمه‌ی جبران)
 * @return string کدِ دلیل؛ رشته‌ی خالی یعنی اعطا انجام شد.
 */
function farazsms_cashback_apply_to_order( $order, $path = 'auto' ) {
	$ctx     = farazsms_cashback_build_context( $order );
	$blocker = farazsms_cashback_first_blocker( $ctx, $path );
	if ( $blocker !== '' ) {
		return $blocker;
	}
	if ( ! farazsms_cashback_grant( $ctx['user_id'], (int) $order->get_id(), $ctx['amount'] ) ) {
		return 'insert_failed';
	}
	return '';
}

/**
 * نتیجه‌ی یک تلاشِ اعطا را روی سفارش ثبت می‌کند: یا یادداشتِ دلیل، یا پاک‌کردنِ یادداشتِ کهنه.
 *
 * @param mixed  $order
 * @param string $reason خروجیِ apply؛ خالی یعنی موفق.
 * @param string $path
 */
function farazsms_cashback_record_outcome( $order, $reason, $path ) {
	if ( ! ( $order instanceof WC_Order ) ) {
		return;
	}
	if ( $reason === '' ) {
		if ( (string) $order->get_meta( 'farazsms_cashback_skip_reason' ) !== '' ) {
			$order->delete_meta_data( 'farazsms_cashback_skip_reason' );
			$order->save_meta_data();
		}
		return;
	}
	if ( ! farazsms_cashback_should_record( $reason, $path ) ) {
		return;
	}
	$order->update_meta_data( 'farazsms_cashback_skip_reason', (string) $reason );
	// save_meta_data و نه save: ذخیره‌ی کاملِ سفارش هوکِ woocommerce_update_order را شلیک
	// می‌کند که در همین افزونه به هندلرِ پیامکِ سفارش وصل است.
	$order->save_meta_data();
}

/**
 * اعطای کش‌بک هنگام تکمیل سفارش.
 */
function farazsms_cashback_handle_order_complete( $order_id, $order = null ) {
	if ( ! ( $order instanceof WC_Order ) ) {
		$order = wc_get_order( $order_id );
	}
	$reason = farazsms_cashback_apply_to_order( $order, 'auto' );
	farazsms_cashback_record_outcome( $order, $reason, 'auto' );
}

// ============================================================================
// نمایش در صفحه سفارش (Admin) + Order Details (Customer)
// ============================================================================

/** نشانیِ بازگشت به صفحه‌ی ویرایشِ سفارش (سازگار با ذخیره‌سازیِ پرکارِ سفارش). */
function farazsms_cashback_order_edit_url( $order ) {
	if ( ! ( $order instanceof WC_Order ) ) {
		return admin_url( 'admin.php?page=wc-orders' );
	}
	if ( method_exists( $order, 'get_edit_order_url' ) ) {
		$url = (string) $order->get_edit_order_url();
		if ( $url !== '' ) {
			return $url;
		}
	}
	// پشتیبان فقط برای ذخیره‌سازیِ کلاسیکِ سفارش (post) معنا دارد؛ روی ذخیره‌سازیِ پرکار
	// سفارش اصلاً post نیست، پس به فهرستِ سفارش‌ها برمی‌گردیم نه به نشانیِ نامعتبر.
	return admin_url( 'admin.php?page=wc-orders&id=' . (int) $order->get_id() . '&action=edit' );
}

/**
 * جبرانِ دستیِ یک سفارش — همان مسیرِ اعطا، ولی بدونِ گیتِ «زمانِ فعال‌سازی».
 *
 * چرا لازم است: سفارش‌هایی که پیش از ۳٫۲۲٫۱۸۹ در باگِ مقایسه‌ی ساعتِ محلی با ساعتِ جهانی
 * بی‌صدا رد شدند، خودبه‌خود ترمیم نمی‌شوند. مدیر همان چند سفارشی را که مشتری شکایت کرده
 * از روی همین پنل درست می‌کند — نه مهاجرتِ خودکار، چون اعتبارِ کش‌بک عملاً پول است.
 */
add_action( 'admin_post_farazsms_cashback_grant_order', 'farazsms_cashback_handle_manual_order_grant' );
function farazsms_cashback_handle_manual_order_grant() {
	$order_id = isset( $_GET['order'] ) ? (int) $_GET['order'] : 0;
	if ( $order_id <= 0 ) {
		wp_die( esc_html__( 'سفارشِ نامعتبر.', 'farazsms' ) );
	}
	check_admin_referer( 'farazsms_cashback_grant_order_' . $order_id );
	if ( ! current_user_can( 'edit_shop_orders' ) && ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : false;
	if ( ! ( $order instanceof WC_Order ) ) {
		wp_die( esc_html__( 'سفارش پیدا نشد.', 'farazsms' ) );
	}

	$reason = farazsms_cashback_apply_to_order( $order, 'manual' );
	farazsms_cashback_record_outcome( $order, $reason, 'manual' );

	set_transient( 'farazsms_cb_repair_' . (int) $order->get_id(), $reason === '' ? 'ok' : $reason, 60 );
	wp_safe_redirect( farazsms_cashback_order_edit_url( $order ) );
	exit;
}

add_action( 'woocommerce_admin_order_data_after_order_details', 'farazsms_cashback_admin_order_panel' );
function farazsms_cashback_admin_order_panel( $order ) {
	if ( ! ( $order instanceof WC_Order ) ) return;
	$used    = (float) $order->get_meta( 'farazsms_cashback_used_amount' );
	$granted = (float) $order->get_meta( 'farazsms_cashback_granted_amount' );
	$skip    = (string) $order->get_meta( 'farazsms_cashback_skip_reason' );
	// نتیجه از ترنزینتِ یک‌بارمصرف خوانده می‌شود، نه از نشانی: پیش از این هر کسی با افزودنِ
	// یک پارامتر به نشانیِ ویرایشِ سفارش می‌توانست بنرِ «با موفقیت اعطا شد» را نمایش بدهد.
	$repair_key = 'farazsms_cb_repair_' . (int) $order->get_id();
	$repair     = (string) get_transient( $repair_key );
	if ( $repair !== '' ) {
		delete_transient( $repair_key );
	}
	// دکمه فقط جایی که جبران اصلاً معنا دارد: کاربرِ ثبت‌شده دارد و هنوز کش‌بکی نگرفته.
	// دکمه فقط جایی که کلیکش می‌تواند موفق شود. عمداً «داشتنِ دلیلِ ثبت‌شده» شرط نیست:
	// سفارش‌هایی که پیش از ۳٫۲۲٫۱۸۹ سوختند اصلاً متای دلیل ندارند و دقیقاً هدفِ جبران‌اند.
	$trigger    = farazsms_cashback_normalize_status( farazsms_cashback_get_settings()['status_trigger'] ?? 'completed' );
	$can_repair = (
		$granted <= 0
		&& (int) $order->get_user_id() > 0
		&& farazsms_cashback_is_enabled()
		&& farazsms_cashback_normalize_status( $order->get_status() ) === $trigger
	);
	$repair_url = $can_repair ? wp_nonce_url(
		admin_url( 'admin-post.php?action=farazsms_cashback_grant_order&order=' . (int) $order->get_id() ),
		'farazsms_cashback_grant_order_' . (int) $order->get_id()
	) : '';
	if ( $used <= 0 && $granted <= 0 && $skip === '' && $repair === '' && ! $can_repair ) return;
	?>
	<div style="background:#f8fafc; border:1px solid #e2e8f0; border-radius:8px; padding:12px 14px; margin-top:12px; direction:rtl;">
		<h4 style="margin:0 0 8px; font-size:13px; color:#0f172a;">💰 <?php esc_html_e( 'کش‌بک این سفارش', 'farazsms' ); ?></h4>
		<?php if ( $used > 0 ) : ?>
			<p style="margin:0 0 4px; font-size:12px; color:#475569;">
				<strong><?php esc_html_e( 'استفاده از کیف پول:', 'farazsms' ); ?></strong>
				<?php echo esc_html( number_format_i18n( $used ) ); ?>
				<?php echo function_exists( 'get_woocommerce_currency_symbol' ) ? esc_html( get_woocommerce_currency_symbol() ) : ''; ?>
			</p>
		<?php endif; ?>
		<?php if ( $granted > 0 ) : ?>
			<p style="margin:0; font-size:12px; color:#475569;">
				<strong><?php esc_html_e( 'کش‌بک اعطا شده:', 'farazsms' ); ?></strong>
				<?php echo esc_html( number_format_i18n( $granted ) ); ?>
				<?php echo function_exists( 'get_woocommerce_currency_symbol' ) ? esc_html( get_woocommerce_currency_symbol() ) : ''; ?>
				(انقضا: <?php echo esc_html( (string) $order->get_meta( 'farazsms_cashback_granted_expires' ) ); ?>)
			</p>
		<?php endif; ?>
		<?php if ( $repair === 'ok' ) : ?>
			<p style="margin:0 0 8px; font-size:12px; color:#065f46; background:#ecfdf5; border:1px solid #a7f3d0; border-radius:6px; padding:8px 10px;">
				<?php esc_html_e( 'کش‌بکِ این سفارش با موفقیت اعطا شد.', 'farazsms' ); ?>
			</p>
		<?php elseif ( $repair !== '' ) : ?>
			<p style="margin:0 0 8px; font-size:12px; color:#92400e; background:#fffbeb; border:1px solid #fde68a; border-radius:6px; padding:8px 10px;">
				<strong><?php esc_html_e( 'جبران انجام نشد:', 'farazsms' ); ?></strong>
				<?php echo esc_html( farazsms_cashback_skip_reason_label( $repair ) ); ?>
			</p>
		<?php endif; ?>
		<?php if ( $granted <= 0 && $skip !== '' ) : ?>
			<p style="margin:0; font-size:12px; color:#92400e; background:#fffbeb; border:1px solid #fde68a; border-radius:6px; padding:8px 10px;">
				<strong><?php esc_html_e( 'کش‌بک اعطا نشد:', 'farazsms' ); ?></strong>
				<?php echo esc_html( farazsms_cashback_skip_reason_label( $skip ) ); ?>
			</p>
		<?php endif; ?>
		<?php if ( $can_repair ) : ?>
			<p style="margin:8px 0 0;">
				<a href="<?php echo esc_url( $repair_url ); ?>" class="button button-secondary" style="font-size:12px;">
					💰 <?php esc_html_e( 'کش‌بکِ این سفارش را بده', 'farazsms' ); ?>
				</a>
				<span style="font-size:11px; color:#94a3b8; margin-right:8px;">
					<?php esc_html_e( 'برای سفارش‌هایی که به هر دلیل کش‌بکشان جا مانده است.', 'farazsms' ); ?>
				</span>
			</p>
		<?php endif; ?>
	</div>
	<?php
}

// ============================================================================
// Cron: انقضای رکوردها + پیامک یادآوری
// ============================================================================

add_action( FARAZSMS_CASHBACK_CRON_HOOK, 'farazsms_cashback_cron_runner' );
function farazsms_cashback_cron_runner() {
	if ( ! farazsms_cashback_is_enabled() ) return;
	farazsms_cashback_expire_old_records();
	farazsms_cashback_send_reminder_smses();
}

function farazsms_cashback_expire_old_records() {
	global $wpdb;
	$table = farazsms_cashback_credits_table();
	$now   = current_time( 'mysql' );
	// در batch — جلوگیری از long-running query روی سایت با میلیون‌ها رکورد
	$wpdb->query( $wpdb->prepare(
		"UPDATE $table SET status = %s WHERE status = %s AND expires_at <= %s LIMIT 5000",
		'expired',
		'active',
		$now
	) );
}

function farazsms_cashback_send_reminder_smses() {
	$settings = farazsms_cashback_get_settings();
	$pattern  = trim( (string) $settings['pattern_code'] );
	if ( $pattern === '' ) return;
	$reminders = $settings['reminders'];
	if ( ! is_array( $reminders ) || empty( $reminders ) ) return;

	global $wpdb;
	$table = farazsms_cashback_credits_table();
	$now   = current_time( 'mysql' );

	foreach ( $reminders as $days_ahead ) {
		$days_ahead = (int) $days_ahead;
		if ( $days_ahead <= 0 ) continue;
		$window_start = date( 'Y-m-d 00:00:00', strtotime( "+{$days_ahead} days", strtotime( $now ) ) );
		$window_end   = date( 'Y-m-d 23:59:59', strtotime( "+{$days_ahead} days", strtotime( $now ) ) );

		// رکوردهای کاربر که در این روز خاص expire می‌شوند
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT user_id, SUM(amount - used_amount) AS balance, MIN(expires_at) AS soonest
			 FROM $table
			 WHERE status = %s AND expires_at BETWEEN %s AND %s
			 GROUP BY user_id LIMIT 500",
			'active',
			$window_start,
			$window_end
		), ARRAY_A );

		foreach ( $rows as $row ) {
			$user_id   = (int) $row['user_id'];
			$balance   = (float) $row['balance'];
			$mobile    = (string) get_user_meta( $user_id, 'billing_phone', true );
			if ( $mobile === '' ) {
				$mobile = (string) get_user_meta( $user_id, 'mobile_number', true );
			}
			if ( $mobile === '' || $balance <= 0 ) continue;

			$reminder_key = 'farazsms_cb_remind_' . $days_ahead . '_' . $user_id . '_' . md5( $row['soonest'] );
			if ( get_transient( $reminder_key ) ) continue; // قبلاً فرستاده شده

			// v3.21.96: نام‌های هگز‌ناامن (%balance%/%days_left%) را پنلِ فراز خراب می‌کرد → پیامکِ
			// خالی. متنِ پترن هنگام ساخت به %var1%/%var2% نگاشت می‌شود، پس اینجا هم با همان کلیدها
			// می‌فرستیم: var1 = موجودیِ کش‌بک، var2 = روزهای باقی‌مانده.
			//
			// ⚠️ v3.22.176: افزونه **دو** طرحِ امن‌سازی دارد و پترن ممکن است با هرکدام ثبت شده باشد:
			//   ۱) نگاشتِ سطحِ فیچر  → %var1% / %var2%       (سازنده‌ی پترنِ همین بخش)
			//   ۲) نگاشتِ سطحِ API  → %vbalance% / %vdays_left%  (پیشوندِ v روی هر نامِ hex-ناامن)
			// اگر پترن با طرحِ ۲ ثبت شده باشد ولی فقط var1/var2 بفرستیم، پنل جای متغیرها را
			// خالی می‌گذارد و پیامکِ ناقص می‌رود — دقیقاً شکایتِ «پترن را دوباره ساختم، باز کار نکرد».
			// هر دو مجموعه فرستاده می‌شود؛ متغیرِ اضافی را فراز نادیده می‌گیرد.
			$attrs = farazsms_cashback_reminder_attrs( $balance, $days_ahead, (string) ( $settings['pattern_message'] ?? '' ) );
			// v3.21.44: خطِ تبلیغاتیِ PRO پترن را هم می‌فرستد؛ این اعلانِ تبلیغاتی از خطِ تبلیغات (پیش‌فرض PRO) می‌رود.
			$ad_sender = farazsms_get_ad_sender();
			farazsms_send_pattern_sms_raw( $mobile, $pattern, $attrs, $ad_sender );
			set_transient( $reminder_key, '1', DAY_IN_SECONDS * 2 );
		}
	}
}

/**
 * متغیرهای پیامکِ یادآوریِ کش‌بک — پوشش‌دهنده‌ی **هر دو** طرحِ امن‌سازیِ نام.
 *
 * کلیدها از **همان متنی** استخراج می‌شوند که پترن با آن ثبت شده است، نه از یک فهرستِ
 * ثابت. دلیل: افزونه دو طرحِ امن‌سازیِ نام دارد —
 *   ۱) نگاشتِ سطحِ فیچر  → %var1% / %var2%
 *   ۲) نگاشتِ سطحِ API   → %vbalance% / %vdays_left%  (پیشوندِ v روی نامِ hex-ناامن)
 * و اگر پترنِ سایت با یکی ثبت شده باشد ولی ارسال با دیگری انجام شود، پنل جای متغیرها را
 * خالی می‌گذارد. فرستادنِ «هر دو مجموعه» هم راهِ درستی نیست: رفتارِ پنل با متغیرِ اضافه
 * آزموده نشده و می‌تواند سایت‌های سالم را بشکند. پس دقیقاً همان نام‌هایی فرستاده می‌شود
 * که در متنِ ثبت‌شده هستند.
 *
 * @param float  $balance         موجودیِ کش‌بک
 * @param int    $days_ahead      روزهای باقی‌مانده تا انقضا
 * @param string $pattern_message متنِ ذخیره‌شده‌ی پترن (خالی = متنِ پیش‌فرض)
 * @return array<string,string>
 */
function farazsms_cashback_reminder_attrs( $balance, $days_ahead, $pattern_message = '' ) {
	$amount = number_format( (float) $balance );
	$days   = (string) (int) $days_ahead;

	$message = trim( (string) $pattern_message );
	if ( $message === '' && function_exists( 'farazsms_cashback_default_pattern_message' ) ) {
		$message = farazsms_cashback_default_pattern_message();
	}
	// ⚠️ این مسیر از کران اجرا می‌شود و می‌تواند پیش از مهاجرتِ ترمیم (که به بازدیدِ
	// پیشخوانِ مدیر گره خورده) فعال شود. پس متنِ خرابِ پیش از v3.22.177 همین‌جا هم
	// ترمیم می‌شود، وگرنه متغیرهای ارسال با پترن نمی‌خوانند و پیامکِ ناقص می‌رود.
	$message = farazsms_pattern_text_repair( $message );
	// همان تبدیلی که هنگام ساختِ پترن انجام شده است.
	$message = farazsms_pattern_hexsafe_build( 'cashback', $message );
	if ( function_exists( 'farazsms_pattern_hexsafe_name' ) ) {
		$message = preg_replace_callback(
			'/%([A-Za-z0-9_]+)%/',
			function ( $m ) {
				return '%' . farazsms_pattern_hexsafe_name( $m[1] ) . '%';
			},
			$message
		);
	}

	// نام‌های هم‌معنا در دو طرح.
	$alias = array(
		'var1' => $amount, 'balance' => $amount, 'vbalance' => $amount,
		'var2' => $days,   'days_left' => $days, 'vdays_left' => $days,
	);

	$attrs = array();
	if ( preg_match_all( '/%([A-Za-z0-9_]+)%/', (string) $message, $m ) ) {
		foreach ( array_unique( $m[1] ) as $name ) {
			if ( isset( $alias[ $name ] ) ) {
				$attrs[ $name ] = $alias[ $name ];
			}
		}
	}
	if ( empty( $attrs ) ) {
		// متنِ ناشناخته/دست‌کاری‌شده — به طرحِ پیش‌فرضِ سازنده برگرد تا ارسال بی‌متغیر نماند.
		$attrs = array( 'var1' => $amount, 'var2' => $days );
	}
	return $attrs;
}

// ============================================================================
// Dashboard Stats
// ============================================================================

function farazsms_cashback_get_stats() {
	if ( ! farazsms_cashback_is_enabled() ) {
		return array(
			'enabled'              => false,
			'total_granted'        => 0,
			'total_used'           => 0,
			'total_expired'        => 0,
			'active_balance'       => 0,
			'users_count'          => 0,
			'orders_with_cashback' => 0,
			'sales_with_cashback'  => 0,
			'repeat_customers'     => 0,
			'avg_repeat_orders'    => 0,
			'conversion_rate'      => 0,
			'lift_estimate'        => 0,
		);
	}
	$cached = get_transient( 'farazsms_cashback_stats' );
	if ( $cached !== false ) {
		return $cached;
	}
	global $wpdb;
	$cr = farazsms_cashback_credits_table();
	$rd = farazsms_cashback_redemptions_table();

	// مبالغ کلی
	$total_granted  = (float) $wpdb->get_var( "SELECT COALESCE(SUM(amount),0) FROM $cr" );
	$total_used     = (float) $wpdb->get_var( "SELECT COALESCE(SUM(amount),0) FROM $rd" );
	$total_expired  = (float) $wpdb->get_var( "SELECT COALESCE(SUM(amount - used_amount),0) FROM $cr WHERE status = 'expired'" );
	$active_balance = (float) $wpdb->get_var( $wpdb->prepare(
		"SELECT COALESCE(SUM(amount - used_amount),0) FROM $cr WHERE status = %s AND expires_at > %s",
		'active', current_time( 'mysql' )
	) );

	// تعداد مشتری
	$granted_users = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM $cr" );
	$used_users    = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM $rd" );

	// تعداد سفارش‌های پرداخت‌شده با کش‌بک
	$orders_with_cashback = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT order_id) FROM $rd" );

	// مجموع total سفارش‌هایی که از کش‌بک استفاده کرده‌اند
	// (lift estimate — این فروش به‌خاطر سیستم کش‌بک رخ داده)
	// v3.19.0: حذف N+1 — به‌جای foreach با wc_get_order، یک bulk query (HPOS-aware)
	// از تابع مشترک farazsms_roi_sum_order_totals (در farazsms-roi-dashboard.php).
	$order_ids = $wpdb->get_col( "SELECT DISTINCT order_id FROM $rd LIMIT 5000" );
	$sales_with_cashback = 0.0;
	if ( ! empty( $order_ids ) ) {
		if ( function_exists( 'farazsms_roi_sum_order_totals' ) ) {
			// مسیر سریع: یک query با IN(...)
			$sales_with_cashback = farazsms_roi_sum_order_totals( $order_ids );
		} elseif ( function_exists( 'wc_get_order' ) ) {
			// fallback به مسیر قدیمی — فقط اگر helper روی این سایت نباشد
			foreach ( $order_ids as $oid ) {
				$o = wc_get_order( (int) $oid );
				if ( $o ) {
					$sales_with_cashback += (float) $o->get_total();
				}
			}
		}
	}

	// مشتریان بازگشتی — کاربرانی که بعد از دریافت اولین کش‌بک، حداقل ۲ سفارش
	// از کیف پولشان استفاده کرده‌اند.
	$repeat_customers = (int) $wpdb->get_var(
		"SELECT COUNT(*) FROM (
			SELECT user_id, COUNT(DISTINCT order_id) AS c FROM $rd GROUP BY user_id HAVING c >= 2
		) t"
	);

	// میانگین تعداد سفارش هر مشتری بازگشتی
	$avg_repeat_orders = $repeat_customers > 0
		? (float) $wpdb->get_var(
			"SELECT AVG(c) FROM (
				SELECT user_id, COUNT(DISTINCT order_id) AS c FROM $rd GROUP BY user_id HAVING c >= 2
			) t"
		)
		: 0.0;

	// نرخ تبدیل — درصد کاربرانی که کش‌بک گرفتند و واقعاً استفاده کردند
	$conversion_rate = $granted_users > 0 ? round( ( $used_users / $granted_users ) * 100, 1 ) : 0;

	// تخمین lift فروش = فروش با کش‌بک − مبلغ کش‌بک استفاده شده
	$lift_estimate = max( 0, $sales_with_cashback - $total_used );

	$out = array(
		'enabled'              => true,
		'total_granted'        => $total_granted,
		'total_used'           => $total_used,
		'total_expired'        => $total_expired,
		'active_balance'       => $active_balance,
		'users_count'          => $used_users,
		'granted_users'        => $granted_users,
		'orders_with_cashback' => $orders_with_cashback,
		'sales_with_cashback'  => $sales_with_cashback,
		'repeat_customers'     => $repeat_customers,
		'avg_repeat_orders'    => round( $avg_repeat_orders, 2 ),
		'conversion_rate'      => $conversion_rate,
		'lift_estimate'        => $lift_estimate,
	);
	set_transient( 'farazsms_cashback_stats', $out, 5 * MINUTE_IN_SECONDS );
	return $out;
}


// ============================================================================
// Admin Settings Page
// ============================================================================

add_action( 'admin_menu', 'farazsms_cashback_register_menu', 25 );
function farazsms_cashback_register_menu() {
	// v3.14.3: فقط یک منو — تب کاربران به‌صورت inline در همین صفحه نشان داده می‌شود.
	add_submenu_page(
		'farazsms',
		__( 'کش‌بک', 'farazsms' ),
		__( 'کش‌بک', 'farazsms' ),
		'manage_options',
		'farazsms-cashback',
		'farazsms_cashback_render_unified_page'
	);
}

/**
 * صفحه یکپارچه با تب افقی — تنظیمات یا کاربران.
 */
function farazsms_cashback_render_unified_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی غیرمجاز.' );
	}
	$tab = isset( $_GET['ct'] ) ? sanitize_key( $_GET['ct'] ) : 'settings';
	if ( ! in_array( $tab, array( 'settings', 'users' ), true ) ) {
		$tab = 'settings';
	}
	$tab_settings_url = admin_url( 'admin.php?page=farazsms-cashback&ct=settings' );
	$tab_users_url    = admin_url( 'admin.php?page=farazsms-cashback&ct=users' );
	$tab_style = 'display:inline-flex; align-items:center; gap:6px; padding:12px 22px; font-size:13.5px; text-decoration:none; margin-bottom:-2px;';
	?>
	<div style="direction:rtl; font-family:inherit; max-width:1200px;">
		<!-- Horizontal Tabs -->
		<div style="display:flex; gap:4px; border-bottom:2px solid #e5e7eb; margin-bottom:18px; padding:0 4px; flex-wrap:wrap;">
			<a href="<?php echo esc_url( $tab_settings_url ); ?>" style="<?php echo $tab_style; ?> font-weight:<?php echo $tab==='settings'?'700':'500'; ?>; color:<?php echo $tab==='settings'?'#365891':'#64748b'; ?>; border-bottom:3px solid <?php echo $tab==='settings'?'#4571ba':'transparent'; ?>;">
				⚙️ تنظیمات و آمار
			</a>
			<a href="<?php echo esc_url( $tab_users_url ); ?>" style="<?php echo $tab_style; ?> font-weight:<?php echo $tab==='users'?'700':'500'; ?>; color:<?php echo $tab==='users'?'#365891':'#64748b'; ?>; border-bottom:3px solid <?php echo $tab==='users'?'#4571ba':'transparent'; ?>;">
				👥 کاربران و مدیریت دستی
			</a>
		</div>

		<?php
		if ( $tab === 'users' ) {
			farazsms_cashback_render_users_tab_content();
		} else {
			farazsms_cashback_render_settings_tab_content();
		}
		?>
	</div>
	<?php
}

/**
 * Backward-compat: تابع قبلی هنوز callable است (در صورت reference خارجی).
 */
// (Legacy alias removed — render directed by farazsms_cashback_render_unified_page)
function farazsms_cashback_render_settings_tab_content() {
	farazsms_cashback_internal_render_settings();
}
function farazsms_cashback_render_users_tab_content() {
	farazsms_cashback_internal_render_users();
}

/**
 * صفحه لیست کاربران — آمار، جستجو، سورت، pagination، اعطای دستی.
 *
 * Performance: کوئری اصلی JOIN روی farazsms_cashback_credits + farazsms_cashback_redemptions
 * با GROUP BY user_id — برای ۱۰۰k سایت با میلیون رکورد credits، این کوئری روی
 * indexed columns (user_id) سریع است. pagination با LIMIT برای جلوگیری از
 * load سنگین.
 */
function farazsms_cashback_internal_render_users() {
	$saved_ok = false;
	$saved_msg = '';
	// Handle manual grant
	if ( ( $_SERVER['REQUEST_METHOD'] ?? '' ) === 'POST' && isset( $_POST['farazsms_cashback_manual_grant'] ) ) {
		check_admin_referer( 'farazsms_cashback_manual_grant', 'farazsms_cashback_manual_nonce' );
		$user_id = (int) ( $_POST['user_id'] ?? 0 );
		$amount  = (float) ( $_POST['amount'] ?? 0 );
		$days    = max( 1, (int) ( $_POST['days'] ?? farazsms_cashback_get_settings()['expiry_days'] ) );
		if ( $user_id > 0 && $amount > 0 ) {
			$result = farazsms_cashback_grant_manual( $user_id, $amount, $days );
			if ( $result ) {
				$saved_ok = true;
				$saved_msg = sprintf( 'مبلغ %s تومان به کیف پول کاربر #%d اضافه شد.', number_format_i18n( $amount ), $user_id );
				delete_transient( 'farazsms_cashback_stats' );
			} else {
				$saved_msg = 'خطا در اعطای کش‌بک.';
			}
		}
	}

	global $wpdb;
	$cr = farazsms_cashback_credits_table();
	$rd = farazsms_cashback_redemptions_table();
	$currency = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : 'تومان';

	// Filters: search + sort + page
	$search   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
	$orderby  = isset( $_GET['orderby'] ) ? sanitize_key( $_GET['orderby'] ) : 'total_used';
	$order    = isset( $_GET['order'] ) && strtolower( $_GET['order'] ) === 'asc' ? 'ASC' : 'DESC';
	$paged    = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
	$per_page = 20;
	$offset   = ( $paged - 1 ) * $per_page;

	$valid_orderby = array(
		'user_id'      => 'agg.user_id',
		'total_granted' => 'total_granted',
		'total_used'   => 'total_used',
		'total_expired' => 'total_expired',
		'active_balance' => 'active_balance',
	);
	$order_col = isset( $valid_orderby[ $orderby ] ) ? $valid_orderby[ $orderby ] : 'total_used';

	// کوئری تجمعی — یک GROUP BY روی کل credits
	$now = current_time( 'mysql' );
	$inner_sql = $wpdb->prepare(
		"SELECT
			c.user_id,
			SUM(c.amount) AS total_granted,
			SUM(c.used_amount) AS total_used,
			SUM(CASE WHEN c.status = 'expired' THEN (c.amount - c.used_amount) ELSE 0 END) AS total_expired,
			SUM(CASE WHEN c.status = 'active' AND c.expires_at > %s THEN (c.amount - c.used_amount) ELSE 0 END) AS active_balance,
			COUNT(DISTINCT c.order_id) AS credits_count
		 FROM $cr c
		 GROUP BY c.user_id",
		$now
	);

	// Search روی نام/ایمیل/موبایل — JOIN با users اگر search موجود
	$where    = '';
	$where_args = array();
	$search_join = '';
	if ( $search !== '' ) {
		$search_join = " LEFT JOIN {$wpdb->users} u ON u.ID = agg.user_id
		                 LEFT JOIN {$wpdb->usermeta} um1 ON um1.user_id = agg.user_id AND um1.meta_key = 'billing_phone'
		                 LEFT JOIN {$wpdb->usermeta} um2 ON um2.user_id = agg.user_id AND um2.meta_key = 'mobile_number'";
		$like = '%' . $wpdb->esc_like( $search ) . '%';
		$where = " WHERE (u.user_login LIKE %s OR u.user_email LIKE %s OR u.display_name LIKE %s OR um1.meta_value LIKE %s OR um2.meta_value LIKE %s)";
		$where_args = array( $like, $like, $like, $like, $like );
	}

	// v3.14.4 BUG FIX: وقتی search خالی است، where_args هم خالی است و prepare()
	// بدون placeholder خطای «query argument must have a placeholder» می‌دهد.
	// رفع: prepare فقط وقتی صدا زده می‌شود که placeholder وجود داشته باشد.
	// نکته امنیتی: $inner_sql خودش قبلاً prepared است و $search_join با
	// متغیر user-controlled ندارد، پس بدون prepare هم امن است.
	$count_sql = "SELECT COUNT(*) FROM ( $inner_sql ) agg $search_join $where";
	if ( ! empty( $where_args ) ) {
		$count_sql = $wpdb->prepare( $count_sql, ...$where_args );
	}
	$total_rows = (int) $wpdb->get_var( $count_sql );

	$rows_sql = "SELECT agg.* FROM ( $inner_sql ) agg $search_join $where ORDER BY $order_col $order, agg.user_id DESC LIMIT %d OFFSET %d";
	$rows_args = array_merge( $where_args, array( $per_page, $offset ) );
	// rows_args همیشه حداقل ۲ مقدار دارد (per_page + offset)، پس prepare همیشه placeholder دارد.
	$rows = $wpdb->get_results( $wpdb->prepare( $rows_sql, ...$rows_args ), ARRAY_A );

	// Helper برای sort link
	$sort_link = function( $key, $label ) use ( $orderby, $order ) {
		$new_order = ( $orderby === $key && $order === 'DESC' ) ? 'asc' : 'desc';
		$url = add_query_arg( array(
			'page'    => 'farazsms-cashback', 'ct' => 'users',
			'orderby' => $key,
			'order'   => $new_order,
			's'       => isset( $_GET['s'] ) ? $_GET['s'] : '',
		), admin_url( 'admin.php' ) );
		$arrow = $orderby === $key ? ( $order === 'DESC' ? ' ▼' : ' ▲' ) : '';
		return '<a href="' . esc_url( $url ) . '" style="color:inherit; text-decoration:none;">' . esc_html( $label ) . esc_html( $arrow ) . '</a>';
	};
	?>
	<div style="direction:rtl; font-family:inherit; max-width:1200px;">

		<?php if ( $saved_msg !== '' ) : ?>
			<div style="background:<?php echo $saved_ok ? '#ecfdf5' : '#fef2f2'; ?>; border:1px solid <?php echo $saved_ok ? '#a7f3d0' : '#fecaca'; ?>; color:<?php echo $saved_ok ? '#065f46' : '#b91c1c'; ?>; padding:10px 14px; border-radius:8px; margin-bottom:16px;">
				<?php echo $saved_ok ? '✓ ' : '✗ '; ?><?php echo esc_html( $saved_msg ); ?>
			</div>
		<?php endif; ?>

		<!-- Hero -->
		<div style="background:linear-gradient(135deg,#365891 0%,#4571ba 100%); border-radius:12px; padding:16px 22px; margin-bottom:18px; color:#fff;">
			<h3 style="margin:0 0 4px; font-size:16px; font-weight:700;">📋 لیست کاربران کش‌بک</h3>
			<p style="margin:0; font-size:12px; opacity:0.9;">مشاهده وضعیت کیف پول هر کاربر، جستجو، مرتب‌سازی، و اعطای دستی کش‌بک.</p>
		</div>

		<!-- Toolbar: search + back -->
		<div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin-bottom:14px;">
			<form method="get" action="" style="flex:1 1 300px; display:flex; gap:8px;">
				<input type="hidden" name="page" value="farazsms-cashback"><input type="hidden" name="ct" value="users">
				<input type="text" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="🔍 جستجو در نام کاربری/ایمیل/نام/موبایل…" style="flex:1; padding:8px 12px; border:1px solid #cbd5e1; border-radius:6px; font-family:inherit; font-size:13px;">
				<button type="submit" style="background:#365891; color:#fff; border:none; padding:8px 16px; border-radius:6px; font-size:13px; cursor:pointer;">جستجو</button>
				<?php if ( $search !== '' ) : ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-cashback&ct=users' ) ); ?>" style="background:#fff; color:#475569; border:1px solid #cbd5e1; padding:8px 12px; border-radius:6px; text-decoration:none; font-size:13px;">پاک کردن</a>
				<?php endif; ?>
			</form>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-cashback' ) ); ?>" style="background:#f1f5f9; color:#475569; padding:8px 14px; border-radius:6px; text-decoration:none; font-size:13px;">← بازگشت به تنظیمات</a>
		</div>

		<!-- Manual grant form -->
		<details style="background:#fef3c7; border:1px solid #fde68a; border-radius:10px; padding:14px 18px; margin-bottom:18px;">
			<summary style="cursor:pointer; font-size:13px; font-weight:700; color:#78350f;">➕ اعطای دستی کش‌بک به یک کاربر خاص</summary>
			<form method="post" action="" style="margin-top:12px;">
				<?php wp_nonce_field( 'farazsms_cashback_manual_grant', 'farazsms_cashback_manual_nonce' ); ?>
				<div style="display:flex; gap:12px; flex-wrap:wrap; align-items:flex-end;">
					<div style="flex:1 1 280px;">
						<label style="display:block; font-size:11px; font-weight:600; color:#78350f; margin-bottom:4px;">کاربر (جستجوی نام کاربری)</label>
						<div class="farazsms-user-picker" style="position:relative;">
							<input type="hidden" name="user_id" id="farazsms_cb_user_id">
							<input type="text" id="farazsms_cb_user_search" autocomplete="off" placeholder="نام کاربری یا نام را تایپ کنید…" style="width:100%; padding:8px 12px; border:1px solid #fde68a; border-radius:6px; font-size:13px;">
							<div id="farazsms_cb_user_results" style="display:none; position:absolute; z-index:60; top:100%; left:0; right:0; background:#fff; border:1px solid #fde68a; border-top:none; border-radius:0 0 6px 6px; max-height:260px; overflow-y:auto; box-shadow:0 8px 20px rgba(0,0,0,0.14);"></div>
						</div>
					</div>
					<div style="flex:1 1 180px;">
						<label style="display:block; font-size:11px; font-weight:600; color:#78350f; margin-bottom:4px;">مبلغ (تومان)</label>
						<input type="number" name="amount" required min="1" step="1000" style="width:100%; padding:8px 12px; border:1px solid #fde68a; border-radius:6px; font-size:13px;">
					</div>
					<div style="flex:1 1 130px;">
						<label style="display:block; font-size:11px; font-weight:600; color:#78350f; margin-bottom:4px;">روزهای اعتبار</label>
						<input type="number" name="days" min="1" value="<?php echo (int) farazsms_cashback_get_settings()['expiry_days']; ?>" style="width:100%; padding:8px 12px; border:1px solid #fde68a; border-radius:6px; font-size:13px;">
					</div>
					<button type="submit" name="farazsms_cashback_manual_grant" value="1" style="background:#d97706; color:#fff; border:none; padding:9px 20px; font-size:13px; font-weight:600; border-radius:6px; cursor:pointer; font-family:inherit;">💰 اعطا</button>
				</div>
				<p style="margin:8px 0 0; font-size:11px; color:#78350f;">کاربر را با تایپِ نام کاربری جستجو و از فهرست انتخاب کنید — نام و ایمیلِ هر کاربر کنارش نمایش داده می‌شود.</p>
			</form>
			<?php farazsms_cashback_user_picker_script(); ?>
		</details>

		<!-- Users table -->
		<div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; overflow:hidden;">
			<div style="overflow-x:auto;">
				<table style="width:100%; border-collapse:collapse; font-size:12.5px;">
					<thead style="background:#f8fafc;">
						<tr>
							<th style="text-align:right; padding:10px 12px; border-bottom:1px solid #e5e7eb; font-weight:700;"><?php echo $sort_link( 'user_id', 'کاربر' ); ?></th>
							<th style="text-align:right; padding:10px 12px; border-bottom:1px solid #e5e7eb; font-weight:700;">موبایل</th>
							<th style="text-align:right; padding:10px 12px; border-bottom:1px solid #e5e7eb; font-weight:700;">مجموع خرید</th>
							<th style="text-align:right; padding:10px 12px; border-bottom:1px solid #e5e7eb; font-weight:700;"><?php echo $sort_link( 'total_granted', 'دریافتی' ); ?></th>
							<th style="text-align:right; padding:10px 12px; border-bottom:1px solid #e5e7eb; font-weight:700;"><?php echo $sort_link( 'total_used', 'استفاده‌شده' ); ?></th>
							<th style="text-align:right; padding:10px 12px; border-bottom:1px solid #e5e7eb; font-weight:700;"><?php echo $sort_link( 'total_expired', 'منقضی' ); ?></th>
							<th style="text-align:right; padding:10px 12px; border-bottom:1px solid #e5e7eb; font-weight:700;"><?php echo $sort_link( 'active_balance', 'موجودی فعال' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php if ( empty( $rows ) ) : ?>
							<tr><td colspan="7" style="text-align:center; padding:30px 12px; color:#64748b;">هیچ کاربری یافت نشد.</td></tr>
						<?php else : ?>
							<?php foreach ( $rows as $row ) :
								$user = get_user_by( 'ID', (int) $row['user_id'] );
								$display = $user ? $user->display_name : '—';
								$email   = $user ? $user->user_email : '';
								$mobile  = get_user_meta( $row['user_id'], 'billing_phone', true );
								if ( ! $mobile ) {
									$mobile = get_user_meta( $row['user_id'], 'mobile_number', true );
								}
								$total_spent = function_exists( 'wc_get_customer_total_spent' ) ? (float) wc_get_customer_total_spent( $row['user_id'] ) : 0;
								?>
								<tr style="border-bottom:1px solid #f1f5f9;">
									<td style="padding:10px 12px;">
										<div style="font-weight:600; color:#0f172a;"><?php echo esc_html( $display ); ?></div>
										<div style="font-size:10px; color:#64748b;">#<?php echo (int) $row['user_id']; ?> · <?php echo esc_html( $email ); ?></div>
									</td>
									<td style="padding:10px 12px; direction:ltr; text-align:right; font-family:monospace; color:#475569;"><?php echo esc_html( $mobile ?: '—' ); ?></td>
									<td style="padding:10px 12px; font-weight:600; color:#0f172a;"><?php echo esc_html( number_format_i18n( $total_spent ) ); ?> <small style="color:#94a3b8;"><?php echo esc_html( $currency ); ?></small></td>
									<td style="padding:10px 12px; color:#0f172a;"><?php echo esc_html( number_format_i18n( (float) $row['total_granted'] ) ); ?></td>
									<td style="padding:10px 12px; color:#16a34a; font-weight:600;"><?php echo esc_html( number_format_i18n( (float) $row['total_used'] ) ); ?></td>
									<td style="padding:10px 12px; color:#dc2626;"><?php echo esc_html( number_format_i18n( (float) $row['total_expired'] ) ); ?></td>
									<td style="padding:10px 12px; color:#365891; font-weight:700;"><?php echo esc_html( number_format_i18n( (float) $row['active_balance'] ) ); ?></td>
								</tr>
							<?php endforeach; ?>
						<?php endif; ?>
					</tbody>
				</table>
			</div>

			<!-- Pagination -->
			<?php
			$total_pages = max( 1, (int) ceil( $total_rows / $per_page ) );
			if ( $total_pages > 1 ) :
			?>
				<div style="padding:12px 16px; background:#f8fafc; border-top:1px solid #e5e7eb; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
					<div style="font-size:12px; color:#64748b;">صفحه <?php echo $paged; ?> از <?php echo $total_pages; ?> — مجموع <?php echo number_format_i18n( $total_rows ); ?> کاربر</div>
					<div style="display:flex; gap:6px;">
						<?php
						$base_args = array( 'page' => 'farazsms-cashback', 'ct' => 'users', 'orderby' => $orderby, 'order' => strtolower( $order ), 's' => $search );
						if ( $paged > 1 ) {
							echo '<a href="' . esc_url( add_query_arg( array_merge( $base_args, array( 'paged' => $paged - 1 ) ), admin_url( 'admin.php' ) ) ) . '" style="background:#fff; border:1px solid #cbd5e1; padding:6px 12px; border-radius:6px; text-decoration:none; color:#475569; font-size:12px;">قبلی</a>';
						}
						if ( $paged < $total_pages ) {
							echo '<a href="' . esc_url( add_query_arg( array_merge( $base_args, array( 'paged' => $paged + 1 ) ), admin_url( 'admin.php' ) ) ) . '" style="background:#fff; border:1px solid #cbd5e1; padding:6px 12px; border-radius:6px; text-decoration:none; color:#475569; font-size:12px;">بعدی</a>';
						}
						?>
					</div>
				</div>
			<?php endif; ?>
		</div>

	</div>
	<?php
}

/**
 * اعطای کش‌بک دستی — بدون نیاز به سفارش. order_id=0 به‌عنوان سیگنال manual.
 * idempotency بر اساس مبلغ + روز ساخت رد می‌شود.
 */
/**
 * v3.21.60: جستجوی کاربرانِ وردپرس برای انتخاب‌گرِ «اعطای دستی کش‌بک».
 * خروجی JSON با pagination؛ نام کاربری + نام + ایمیلِ هر کاربر.
 */
add_action( 'wp_ajax_farazsms_search_users', 'farazsms_ajax_search_users' );
function farazsms_ajax_search_users() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( 'forbidden', 403 );
	}
	check_ajax_referer( 'farazsms_search_users', 'nonce' );

	$q    = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
	$page = max( 1, (int) ( $_GET['page'] ?? 1 ) );
	$per  = 20;

	$args = array(
		'number'  => $per,
		'offset'  => ( $page - 1 ) * $per,
		'fields'  => array( 'ID', 'user_login', 'display_name', 'user_email' ),
		'orderby' => 'user_login',
		'order'   => 'ASC',
	);
	if ( $q !== '' ) {
		$args['search']         = '*' . $q . '*';
		$args['search_columns'] = array( 'user_login', 'user_email', 'display_name', 'user_nicename' );
	}

	$query   = new WP_User_Query( $args );
	$total   = (int) $query->get_total();
	$results = array();
	foreach ( (array) $query->get_results() as $u ) {
		$results[] = array(
			'id'       => (int) $u->ID,
			'username' => (string) $u->user_login,
			'name'     => (string) $u->display_name,
			'email'    => (string) $u->user_email,
		);
	}
	wp_send_json_success( array(
		'results' => $results,
		'more'    => ( $page * $per ) < $total,
	) );
}

/**
 * v3.21.60: اسکریپتِ خودبسنده‌ی انتخاب‌گرِ کاربر (vanilla JS، بدونِ وابستگی به select2).
 * مستقیماً زیرِ فرمِ اعطای دستی چاپ می‌شود.
 */
function farazsms_cashback_user_picker_script() {
	$ajax  = esc_js( admin_url( 'admin-ajax.php' ) );
	$nonce = esc_js( wp_create_nonce( 'farazsms_search_users' ) );
	?>
	<script>
	(function(){
		var search = document.getElementById('farazsms_cb_user_search');
		var hidden = document.getElementById('farazsms_cb_user_id');
		var box    = document.getElementById('farazsms_cb_user_results');
		if (!search || !hidden || !box || search.dataset.fzInit) return;
		search.dataset.fzInit = '1';
		var ajaxurl = '<?php echo $ajax; ?>', nonce = '<?php echo $nonce; ?>';
		var t, page = 1, lastQ = '', loading = false, hasMore = false;
		function esc(s){ var d=document.createElement('div'); d.textContent=(s==null?'':String(s)); return d.innerHTML; }
		function render(items, append){
			if (!append) box.innerHTML = '';
			var moreBtn = box.querySelector('.fz-more'); if (moreBtn) moreBtn.remove();
			if (!items.length && !append){ box.innerHTML = '<div style="padding:10px 12px; color:#94a3b8; font-size:12px;">کاربری یافت نشد</div>'; box.style.display='block'; return; }
			items.forEach(function(u){
				var row = document.createElement('div');
				row.style.cssText = 'padding:8px 12px; cursor:pointer; font-size:12.5px; border-bottom:1px solid #f1f5f9;';
				row.onmouseover = function(){ row.style.background = '#fffbeb'; };
				row.onmouseout  = function(){ row.style.background = '#fff'; };
				row.innerHTML = '<strong>'+esc(u.username)+'</strong> <span style="color:#64748b;">— '+esc(u.name)+'</span>'+(u.email?'<br><span style="color:#94a3b8; font-size:11px; direction:ltr; display:inline-block;">'+esc(u.email)+'</span>':'')+' <span style="color:#cbd5e1; font-size:10px;">#'+u.id+'</span>';
				row.onclick = function(){ hidden.value = u.id; search.value = u.username + ' — ' + u.name; box.style.display='none'; };
				box.appendChild(row);
			});
			if (hasMore){
				var more = document.createElement('div');
				more.className = 'fz-more';
				more.style.cssText = 'padding:8px 12px; text-align:center; cursor:pointer; font-size:12px; color:#2563eb; background:#f8fafc;';
				more.textContent = 'بارگذاری بیشتر…';
				more.onclick = function(){ page++; fetchUsers(lastQ, true); };
				box.appendChild(more);
			}
			box.style.display = 'block';
		}
		function fetchUsers(q, append){
			if (loading) return; loading = true;
			var url = ajaxurl + '?action=farazsms_search_users&nonce=' + encodeURIComponent(nonce) + '&q=' + encodeURIComponent(q) + '&page=' + page;
			fetch(url, {credentials:'same-origin'}).then(function(r){ return r.json(); }).then(function(res){
				loading = false;
				if (!res || !res.success || !res.data) return;
				hasMore = !!res.data.more;
				render(res.data.results || [], append);
			}).catch(function(){ loading = false; });
		}
		search.addEventListener('input', function(){
			hidden.value = '';
			clearTimeout(t);
			var q = search.value.trim(); lastQ = q; page = 1;
			if (q.length < 1){ box.style.display='none'; return; }
			t = setTimeout(function(){ fetchUsers(q, false); }, 250);
		});
		search.addEventListener('focus', function(){ if (box.children.length){ box.style.display='block'; } });
		document.addEventListener('click', function(e){ if (!box.contains(e.target) && e.target !== search){ box.style.display='none'; } });
		var form = search.closest('form');
		if (form){ form.addEventListener('submit', function(e){ if (!hidden.value){ e.preventDefault(); alert('لطفاً یک کاربر را از فهرست انتخاب کنید.'); search.focus(); } }); }
	})();
	</script>
	<?php
}

function farazsms_cashback_grant_manual( $user_id, $amount, $expiry_days = 0 ) {
	$user_id = (int) $user_id;
	$amount  = (float) $amount;
	if ( $user_id <= 0 || $amount <= 0 ) {
		return false;
	}
	$settings = farazsms_cashback_get_settings();
	if ( $expiry_days <= 0 ) {
		$expiry_days = (int) $settings['expiry_days'];
	}
	$expiry_days = max( 1, $expiry_days );

	global $wpdb;
	$now        = current_time( 'mysql' );
	$expires_at = date( 'Y-m-d H:i:s', strtotime( $now . ' +' . $expiry_days . ' days' ) );
	$inserted   = $wpdb->insert(
		farazsms_cashback_credits_table(),
		array(
			'user_id'     => $user_id,
			'order_id'    => 0, // manual grant — بدون سفارش
			'amount'      => $amount,
			'used_amount' => 0,
			'status'      => 'active',
			'created_at'  => $now,
			'expires_at'  => $expires_at,
		),
		array( '%d', '%d', '%f', '%f', '%s', '%s', '%s' )
	);
	return $inserted ? $wpdb->insert_id : false;
}

function farazsms_cashback_internal_render_settings() {
	$saved_ok = false;
	if ( ( $_SERVER['REQUEST_METHOD'] ?? '' ) === 'POST' && isset( $_POST['farazsms_cashback_save'] ) ) {
		check_admin_referer( 'farazsms_cashback_settings', 'farazsms_cashback_nonce' );
		$current = farazsms_cashback_get_settings();
		$current['enabled']        = isset( $_POST['enabled'] ) ? '1' : '0';
		$current['percent']        = max( 0, min( 100, (float) ( $_POST['percent'] ?? 10 ) ) );
		$current['expiry_days']    = max( 1, (int) ( $_POST['expiry_days'] ?? 7 ) );
		$current['min_order']      = max( 0, (float) ( $_POST['min_order'] ?? 0 ) );
			$current['max_per_order']  = max( 0, (float) ( $_POST['max_per_order'] ?? 0 ) );
			$current['status_trigger'] = farazsms_cashback_normalize_status( $_POST['status_trigger'] ?? 'completed' );
			$current['pattern_code']   = sanitize_text_field( $_POST['pattern_code'] ?? '' );
			$current['pattern_message'] = isset( $_POST['pattern_message'] ) ? farazsms_sanitize_pattern_text( $_POST['pattern_message'] ) : farazsms_cashback_default_pattern_message();
			$current['in_cart_notice'] = isset( $_POST['in_cart_notice'] ) ? '1' : '0';
		$reminders                 = isset( $_POST['reminders'] ) ? sanitize_text_field( $_POST['reminders'] ) : '7,3,1';
		$parts                     = array_filter( array_map( 'trim', explode( ',', $reminders ) ) );
		$current['reminders']      = array_values( array_filter( array_map( 'intval', $parts ), function( $v ) { return $v > 0; } ) );
		update_option( 'farazsms_cashback_settings', $current, false );
		delete_transient( 'farazsms_cashback_stats' );
		$saved_ok = true;
	}

	$s     = farazsms_cashback_get_settings();
	$stats = farazsms_cashback_get_stats();
	$currency = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : 'تومان';
	$statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array( 'wc-completed' => 'تکمیل شده' );
	$wc_active = function_exists( 'WC' );
		$enabled_flag = $s['enabled'] === '1';
		$pattern_message = trim( (string) ( $s['pattern_message'] ?? '' ) );
		if ( $pattern_message === '' ) {
			$pattern_message = farazsms_cashback_default_pattern_message();
		}
	?>
	<div>
		<?php if ( $saved_ok ) : ?>
			<div style="background:#ecfdf5; border:1px solid #a7f3d0; color:#065f46; padding:10px 14px; border-radius:8px; margin-bottom:16px;">✓ تنظیمات ذخیره شد.</div>
		<?php endif; ?>

		<?php if ( ! $wc_active ) : ?>
			<div style="background:#fef2f2; border:1px solid #fecaca; color:#b91c1c; padding:14px 18px; border-radius:10px; margin-bottom:20px;">
				<strong style="font-size:14px;">⚠️ ووکامرس فعال نیست</strong>
				<p style="margin:6px 0 0; font-size:12.5px; line-height:1.8;">
					سیستم کش‌بک به سفارش‌های ووکامرس وابسته است. لطفاً ابتدا افزونه WooCommerce را نصب و فعال کنید.
					تنظیمات این صفحه قابل ذخیره است ولی تا قبل از نصب WC، روی سایت اثری ندارد.
				</p>
			</div>
		<?php endif; ?>

		<?php if ( $wc_active && $s['enabled'] !== '1' ) : ?>
			<div style="background:#fef3c7; border:1px solid #fde68a; color:#78350f; padding:12px 16px; border-radius:10px; margin-bottom:20px;">
				<strong>⚠️ سیستم کش‌بک <u>غیرفعال</u> است.</strong>
				<span style="font-size:12.5px;">
					تنظیمات را وارد کنید و در پایین صفحه «فعال‌سازی سیستم کش‌بک» را تیک بزنید تا KPI ها و آمار شروع به پر شدن کنند.
				</span>
			</div>
		<?php endif; ?>

		<!-- Hero -->
		<div style="background:linear-gradient(135deg,#fef3c7 0%,#fde68a 100%); border:1px solid #fcd34d; border-radius:12px; padding:18px 22px; margin-bottom:20px;">
			<h3 style="margin:0 0 6px; font-size:16px; color:#78350f; font-weight:700;">💰 سیستم کش‌بک هوشمند</h3>
			<p style="margin:0; color:#92400e; font-size:13px; line-height:1.9;">
				مشتری از خرید درصدی بازگشت می‌گیرد که با تاریخ انقضا در کیف پولش ذخیره می‌شود — این او را تحریک می‌کند سریع برگردد و دوباره خرید کند. پیامک یادآوری <strong>قبل از انقضا</strong> نرخ بازگشت را تا ۳ برابر افزایش می‌دهد.
			</p>
		</div>

		<!-- Stats Cards — KPI ها (در حالت غیرفعال: خاکستری + نوتیس) -->
		<?php
		// v3.14.3: حتی در حالت غیرفعال هم کارت‌ها را نمایش می‌دهیم با ظاهر dimmed.
		$dim = ! $enabled_flag;
		$hero_bg = $dim
			? 'background:linear-gradient(135deg,#94a3b8 0%,#64748b 100%); opacity:0.85;'
			: 'background:linear-gradient(135deg,#16a34a 0%,#059669 100%);';
		$card_style = $dim ? 'background:#f8fafc; border-color:#e2e8f0; opacity:0.7;' : 'background:#fff; border-color:#e5e7eb;';
		?>
			<!-- ردیف اصلی: تأثیر بر فروش -->
			<div style="<?php echo esc_attr( $hero_bg ); ?> border-radius:14px; padding:20px 24px; margin-bottom:14px; color:#fff;">
				<div style="font-size:12px; opacity:0.9; margin-bottom:4px;">
					📈 افزایش فروش به‌خاطر سیستم کش‌بک
					<?php if ( $dim ) : ?>
						<span style="background:rgba(255,255,255,0.25); padding:2px 8px; border-radius:4px; font-size:10px; margin-right:6px;">غیرفعال — برای پر شدن، تیک «فعال‌سازی» را بزنید</span>
					<?php endif; ?>
				</div>
				<div style="font-size:28px; font-weight:800;">
					<?php echo esc_html( number_format_i18n( $stats['sales_with_cashback'] ?? 0 ) ); ?>
					<small style="font-size:14px; font-weight:500; opacity:0.9;"><?php echo esc_html( $currency ); ?></small>
				</div>
				<div style="font-size:12px; opacity:0.9; margin-top:8px;">
					<?php echo esc_html( number_format_i18n( $stats['orders_with_cashback'] ?? 0 ) ); ?> سفارش با استفاده از کش‌بک —
					<strong>این فروش‌ها مستقیماً نتیجه سیستم کش‌بک افزونه فراز اس‌ام‌اس است.</strong>
				</div>
			</div>

			<!-- ردیف دوم: مشتریان بازگشتی -->
			<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; margin-bottom:14px;">
				<div style="<?php echo esc_attr( $card_style ); ?> border:1px solid; border-radius:10px; padding:14px;">
					<div style="font-size:11px; color:#64748b;">🔁 مشتریان بازگشتی</div>
					<div style="font-size:20px; font-weight:700; color:<?php echo $dim?'#64748b':'#0f172a'; ?>;"><?php echo esc_html( number_format_i18n( $stats['repeat_customers'] ?? 0 ) ); ?></div>
					<div style="font-size:10px; color:<?php echo $dim?'#94a3b8':'#16a34a'; ?>; margin-top:2px;">‎>‎= ۲ خرید با کش‌بک</div>
				</div>
				<div style="<?php echo esc_attr( $card_style ); ?> border:1px solid; border-radius:10px; padding:14px;">
					<div style="font-size:11px; color:#64748b;">📊 میانگین خرید هر مشتری</div>
					<div style="font-size:20px; font-weight:700; color:<?php echo $dim?'#64748b':'#0f172a'; ?>;"><?php echo esc_html( number_format_i18n( $stats['avg_repeat_orders'] ?? 0 ) ); ?> <small style="font-size:11px;">بار</small></div>
				</div>
				<div style="<?php echo esc_attr( $card_style ); ?> border:1px solid; border-radius:10px; padding:14px;">
					<div style="font-size:11px; color:#64748b;">🎯 نرخ تبدیل کش‌بک</div>
					<div style="font-size:20px; font-weight:700; color:<?php echo $dim?'#64748b':'#16a34a'; ?>;"><?php echo esc_html( $stats['conversion_rate'] ?? 0 ); ?>%</div>
					<div style="font-size:10px; color:#64748b; margin-top:2px;">از کاربرانی که کش‌بک گرفتند</div>
				</div>
				<div style="<?php echo esc_attr( $card_style ); ?> border:1px solid; border-radius:10px; padding:14px;">
					<div style="font-size:11px; color:#64748b;">💼 دریافت‌کنندگان کش‌بک</div>
					<div style="font-size:20px; font-weight:700; color:<?php echo $dim?'#64748b':'#0f172a'; ?>;"><?php echo esc_html( number_format_i18n( $stats['granted_users'] ?? 0 ) ); ?></div>
				</div>
			</div>

			<!-- ردیف سوم: جزئیات مالی -->
			<div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:12px; margin-bottom:20px;">
				<div style="<?php echo esc_attr( $card_style ); ?> border:1px solid; border-radius:10px; padding:14px;">
					<div style="font-size:11px; color:#64748b;">کل اعطا شده</div>
					<div style="font-size:16px; font-weight:700; color:<?php echo $dim?'#64748b':'#0f172a'; ?>;"><?php echo esc_html( number_format_i18n( $stats['total_granted'] ?? 0 ) ); ?> <small style="font-size:10px;"><?php echo esc_html( $currency ); ?></small></div>
				</div>
				<div style="<?php echo esc_attr( $card_style ); ?> border:1px solid; border-radius:10px; padding:14px;">
					<div style="font-size:11px; color:#64748b;">استفاده شده</div>
					<div style="font-size:16px; font-weight:700; color:<?php echo $dim?'#64748b':'#16a34a'; ?>;"><?php echo esc_html( number_format_i18n( $stats['total_used'] ?? 0 ) ); ?> <small style="font-size:10px;"><?php echo esc_html( $currency ); ?></small></div>
				</div>
				<div style="<?php echo esc_attr( $card_style ); ?> border:1px solid; border-radius:10px; padding:14px;">
					<div style="font-size:11px; color:#64748b;">منقضی/سوخت‌شده</div>
					<div style="font-size:16px; font-weight:700; color:<?php echo $dim?'#64748b':'#dc2626'; ?>;"><?php echo esc_html( number_format_i18n( $stats['total_expired'] ?? 0 ) ); ?> <small style="font-size:10px;"><?php echo esc_html( $currency ); ?></small></div>
				</div>
				<div style="<?php echo esc_attr( $card_style ); ?> border:1px solid; border-radius:10px; padding:14px;">
					<div style="font-size:11px; color:#64748b;">موجودی فعال</div>
					<div style="font-size:16px; font-weight:700; color:<?php echo $dim?'#64748b':'#365891'; ?>;"><?php echo esc_html( number_format_i18n( $stats['active_balance'] ?? 0 ) ); ?> <small style="font-size:10px;"><?php echo esc_html( $currency ); ?></small></div>
				</div>
			</div>

		<form method="post" action="">
			<?php wp_nonce_field( 'farazsms_cashback_settings', 'farazsms_cashback_nonce' ); ?>

			<!-- Master toggle -->
			<div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:20px; margin-bottom:18px;">
				<label style="display:flex; align-items:center; gap:14px; padding:12px 16px; background:<?php echo $s['enabled']==='1' ? '#f0fdf4' : '#fff7ed'; ?>; border:1px solid <?php echo $s['enabled']==='1' ? '#bbf7d0' : '#fed7aa'; ?>; border-radius:10px; cursor:pointer;">
					<input type="checkbox" class="farazsms-toggle" name="enabled" value="1" <?php checked( $s['enabled'], '1' ); ?> style="margin:0; width:18px; height:18px;">
					<span style="flex:1; font-size:14px; font-weight:600;">
						فعال‌سازی سیستم کش‌بک
						<?php echo $s['enabled']==='1' ? '<span style="background:#16a34a; color:#fff; font-size:10px; padding:2px 8px; border-radius:4px; margin-right:8px;">فعال ✓</span>' : '<span style="background:#f97316; color:#fff; font-size:10px; padding:2px 8px; border-radius:4px; margin-right:8px;">غیرفعال</span>'; ?>
					</span>
				</label>
				<p style="margin:8px 0 0; font-size:11px; color:#64748b;">در حالت غیرفعال، هیچ کد کش‌بک روی سایت شما اجرا نمی‌شود.</p>
			</div>

			<!-- Cashback rules -->
			<div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:20px; margin-bottom:18px;">
				<h4 style="margin:0 0 14px; font-size:14px; font-weight:700; color:#0f172a;">قوانین کش‌بک</h4>
				<div style="display:flex; flex-wrap:wrap; gap:14px;">
					<div style="flex:1 1 200px; min-width:180px;">
						<label style="display:block; font-size:12px; font-weight:600; color:#334155; margin-bottom:4px;">درصد کش‌بک (%)</label>
						<input type="number" name="percent" min="0" max="100" step="0.1" value="<?php echo esc_attr( $s['percent'] ); ?>" style="width:100%; padding:8px 12px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px;">
					</div>
					<div style="flex:1 1 200px; min-width:180px;">
						<label style="display:block; font-size:12px; font-weight:600; color:#334155; margin-bottom:4px;">روزهای انقضا</label>
						<input type="number" name="expiry_days" min="1" value="<?php echo esc_attr( $s['expiry_days'] ); ?>" style="width:100%; padding:8px 12px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px;">
					</div>
					<div style="flex:1 1 200px; min-width:180px;">
						<label style="display:block; font-size:12px; font-weight:600; color:#334155; margin-bottom:4px;">حداقل سفارش (تومان) — ۰ یعنی بدون حداقل</label>
						<input type="number" name="min_order" min="0" step="1000" value="<?php echo esc_attr( $s['min_order'] ); ?>" style="width:100%; padding:8px 12px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px;">
					</div>
					<div style="flex:1 1 200px; min-width:180px;">
						<label style="display:block; font-size:12px; font-weight:600; color:#334155; margin-bottom:4px;">سقف کش‌بک هر سفارش — ۰ یعنی بدون سقف</label>
						<input type="number" name="max_per_order" min="0" step="1000" value="<?php echo esc_attr( $s['max_per_order'] ); ?>" style="width:100%; padding:8px 12px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px;">
					</div>
					<div style="flex:1 1 200px; min-width:180px;">
						<label style="display:block; font-size:12px; font-weight:600; color:#334155; margin-bottom:4px;">وضعیت سفارش که trigger کش‌بک می‌شود</label>
						<select name="status_trigger" style="width:100%; padding:8px 12px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px;">
							<?php foreach ( $statuses as $key => $label ) :
								$clean = preg_replace( '/^wc-/', '', $key );
								?>
								<option value="<?php echo esc_attr( $clean ); ?>" <?php selected( $s['status_trigger'], $clean ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
			</div>

			<!-- Reminder SMS -->
			<div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:20px; margin-bottom:18px;">
				<h4 style="margin:0 0 14px; font-size:14px; font-weight:700; color:#0f172a;">پیامک یادآوری</h4>
				<div style="display:flex; flex-wrap:wrap; gap:14px;">
					<div style="flex:1 1 300px; min-width:200px;">
						<label style="display:block; font-size:12px; font-weight:600; color:#334155; margin-bottom:4px;">روزهای یادآوری قبل از انقضا (جدا با ,)</label>
						<input type="text" name="reminders" value="<?php echo esc_attr( implode( ',', $s['reminders'] ) ); ?>" placeholder="7,3,1" style="width:100%; padding:8px 12px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px; direction:ltr; text-align:left;">
						<p style="margin:4px 0 0; font-size:11px; color:#64748b;">مثال: <code>7,3,1</code> یعنی ۷ روز، ۳ روز و ۱ روز قبل از انقضا</p>
					</div>
						<div style="flex:1 1 300px; min-width:200px;">
							<label style="display:block; font-size:12px; font-weight:600; color:#334155; margin-bottom:4px;">کد پترن پیامک یادآوری</label>
							<input type="text" id="cashback_pattern_code" name="pattern_code" value="<?php echo esc_attr( $s['pattern_code'] ); ?>" style="width:100%; padding:8px 12px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px; direction:ltr; text-align:left;">
						</div>
						<div style="flex:1 1 100%; min-width:200px;">
							<label style="display:block; font-size:12px; font-weight:600; color:#334155; margin-bottom:4px;">متن پترن پیامک یادآوری کش‌بک</label>
							<textarea id="cashback_pattern_message" name="pattern_message" rows="4" style="width:100%; padding:8px 12px; border:1px solid #cbd5e1; border-radius:6px; font-size:13px; direction:rtl; line-height:1.9;"><?php echo esc_textarea( $pattern_message ); ?></textarea>
							<div style="margin-top:8px; display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
								<button type="button" class="button" id="farazsms-cashback-build-pattern" data-nonce="<?php echo esc_attr( wp_create_nonce( 'farazsms_feature_build' ) ); ?>">ساخت/به‌روزرسانی پترن کش‌بک</button>
								<span id="farazsms-cashback-build-result" style="font-size:12px; color:#64748b;"></span>
							</div>
						</div>
					</div>
				<div style="margin-top:14px; padding:14px 16px; background:#eef2ff; border:1px solid #c7d2fe; border-radius:8px; line-height:2; font-size:12.5px; color:#263f67;">
					<div style="font-weight:700; margin-bottom:6px;">📋 راهنمای کد پترن</div>
					پترنِ پیامکِ یادآوری را در <strong>پنلِ فراز اس ام اس</strong> بسازید، و پس از تأیید، کدِ آن را در فیلدِ «کد پترن پیامک یادآوری» بالا وارد کنید و ذخیره را بزنید.
					<br>برای نمایشِ مقادیرِ پویا، در متنِ پترن از این دو متغیر استفاده کنید:
						<ul style="margin:8px 18px 0 0; padding:0;">
							<li><code style="background:#fff; padding:1px 5px; border-radius:3px;">%balance%</code> — موجودیِ اعتبارِ کش‌بکِ کاربر</li>
							<li><code style="background:#fff; padding:1px 5px; border-radius:3px;">%days_left%</code> — تعدادِ روزهای باقی‌مانده تا انقضا</li>
						</ul>
					</div>
				</div>
				<script>
				(function(){
					var btn = document.getElementById('farazsms-cashback-build-pattern');
					if (!btn || btn.dataset.bound) return;
					btn.dataset.bound = '1';
					btn.addEventListener('click', function(){
						var result = document.getElementById('farazsms-cashback-build-result');
						var msg = document.getElementById('cashback_pattern_message');
						var code = document.getElementById('cashback_pattern_code');
						if (!msg || !msg.value.trim()) { if(result){ result.style.color='#b91c1c'; result.textContent='متن پترن خالی است.'; } return; }
						btn.disabled = true;
						if(result){ result.style.color='#64748b'; result.textContent='در حال ساخت پترن…'; }
						var fd = new FormData();
						fd.append('action', 'farazsms_feature_build_pattern');
						fd.append('nonce', btn.getAttribute('data-nonce') || '');
						fd.append('feature', 'cashback');
						fd.append('message', msg.value);
						fetch(ajaxurl, {method:'POST', credentials:'same-origin', body:fd}).then(function(r){return r.json();}).then(function(res){
							if (res && res.success && res.data) {
								if(code && res.data.pattern_code){ code.value = res.data.pattern_code; }
								if(result){ result.style.color='#047857'; result.textContent=res.data.message || 'پترن ساخته شد.'; }
							} else {
								if(result){ result.style.color='#b91c1c'; result.textContent=(res && res.data && res.data.message) || 'خطا در ساخت پترن.'; }
							}
						}).catch(function(){ if(result){ result.style.color='#b91c1c'; result.textContent='خطا در ارتباط با سرور.'; } }).then(function(){ btn.disabled=false; });
					});
				})();
				</script>

			<!-- Checkout display -->
			<div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:20px; margin-bottom:18px;">
				<label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
					<input type="checkbox" class="farazsms-toggle" name="in_cart_notice" value="1" <?php checked( $s['in_cart_notice'], '1' ); ?> style="margin:0;">
					<span style="font-size:13px; font-weight:600;">نمایش گزینه «استفاده از کیف پول» در صفحه پرداخت</span>
				</label>
				<p style="margin:6px 0 0; font-size:11px; color:#64748b;">اگر خاموش شود، کش‌بک به‌صورت خودکار اعمال می‌شود بدون اجازه از کاربر.</p>
			</div>

			<button type="submit" name="farazsms_cashback_save" value="1" style="background:#365891; color:#fff; border:none; padding:10px 28px; font-size:14px; font-weight:600; border-radius:8px; cursor:pointer; font-family:inherit;">💾 ذخیره تنظیمات</button>
		</form>
	</div>
	<?php
}

/**
 * ============================================================================
 * سگمنت‌بندیِ مشتریان (Customer Segmentation)
 * ----------------------------------------------------------------------------
 * منبعِ داده: جداولِ آنالیتیکسِ ووکامرس (wc_order_stats + wc_customer_lookup) که
 * هم در HPOS و هم حالتِ کلاسیک نگه‌داری می‌شوند، indexed و سریع‌اند. نتیجه ۱ ساعت
 * cache می‌شود (مناسبِ سایت‌های بزرگ). شماره‌ی موبایلِ کاربرانِ عضو به‌صورتِ batch.
 * ============================================================================
 */

/** تعریفِ سگمنت‌ها (برچسب/رنگ/توضیح). */
function farazsms_cashback_segments_meta() {
	return array(
		'vip_active' => array( 'label' => 'پرخریدِ فعال (VIP)',        'color' => '#16a34a', 'bg' => '#dcfce7', 'desc' => 'بیشترین خرید + خریدِ اخیر — بهترین مشتریان' ),
		'vip_atrisk' => array( 'label' => 'پرخریدِ غیرفعال (در خطر)',  'color' => '#dc2626', 'bg' => '#fee2e2', 'desc' => 'پرخرید بوده ولی مدتی است خرید نکرده — اولویتِ بازگردانی' ),
		'churning'   => array( 'label' => 'در حالِ ریزش',              'color' => '#d97706', 'bg' => '#fef3c7', 'desc' => 'چند خرید داشته ولی در حالِ فاصله‌گرفتن است' ),
		'loyal'      => array( 'label' => 'وفادار',                     'color' => '#365891', 'bg' => '#e0e7ff', 'desc' => 'خریدهای تکراری و اخیر' ),
		'onetime'    => array( 'label' => 'تک‌خرید',                    'color' => '#475569', 'bg' => '#f1f5f9', 'desc' => 'فقط یک‌بار خرید کرده — هدفِ تبدیل به مشتریِ دائم' ),
		'regular'    => array( 'label' => 'عادی',                       'color' => '#64748b', 'bg' => '#f8fafc', 'desc' => 'سایر مشتریان' ),
	);
}

/**
 * محاسبه‌ی سگمنت‌ها (cache‌شده). top-N مشتری بر اساسِ مبلغِ خرید.
 *
 * @param int  $limit
 * @param bool $force
 * @return array
 */
function farazsms_cashback_compute_segments( $limit = 500, $force = false ) {
	global $wpdb;
	$limit     = max( 50, min( 2000, (int) $limit ) );
	$cache_key = 'farazsms_cb_segments_v1_' . $limit;
	if ( ! $force ) {
		$cached = get_transient( $cache_key );
		if ( is_array( $cached ) ) {
			return $cached;
		}
	}

	$stats_table  = $wpdb->prefix . 'wc_order_stats';
	$lookup_table = $wpdb->prefix . 'wc_customer_lookup';
	$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $stats_table ) );
	if ( $exists !== $stats_table ) {
		return array( 'available' => false, 'rows' => array(), 'summary' => array(), 'limit' => $limit, 'total' => 0 );
	}

	$sql = "SELECT os.customer_id, cl.user_id, cl.first_name, cl.last_name, cl.email,
				SUM(os.total_sales) AS total_spend,
				COUNT(os.order_id) AS order_count,
				MAX(os.date_created) AS last_order,
				MIN(os.date_created) AS first_order
			FROM {$stats_table} os
			LEFT JOIN {$lookup_table} cl ON cl.customer_id = os.customer_id
			WHERE os.status IN ('wc-completed','wc-processing','completed','processing')
			GROUP BY os.customer_id
			HAVING total_spend > 0
			ORDER BY total_spend DESC
			LIMIT %d";
	$rows = $wpdb->get_results( $wpdb->prepare( $sql, $limit ), ARRAY_A );
	if ( ! is_array( $rows ) ) {
		$rows = array();
	}

	// موبایلِ کاربرانِ عضو — یک کوئریِ batch.
	$user_ids = array();
	foreach ( $rows as $r ) {
		if ( (int) $r['user_id'] > 0 ) {
			$user_ids[] = (int) $r['user_id'];
		}
	}
	$phones = array();
	if ( ! empty( $user_ids ) ) {
		$user_ids = array_values( array_unique( $user_ids ) );
		$in       = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );
		$args     = array_merge( array( 'billing_phone' ), $user_ids );
		$res      = $wpdb->get_results( $wpdb->prepare( "SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = %s AND user_id IN ($in)", $args ), ARRAY_A );
		foreach ( (array) $res as $pr ) {
			$phones[ (int) $pr['user_id'] ] = (string) $pr['meta_value'];
		}
	}

	// آستانه‌ی VIP = صدکِ ۸۰اُمِ مبلغِ خرید (۲۰٪ بالا).
	$spends = array();
	foreach ( $rows as $r ) {
		$spends[] = (float) $r['total_spend'];
	}
	rsort( $spends );
	$vip_threshold = 0.0;
	if ( ! empty( $spends ) ) {
		$idx           = (int) floor( count( $spends ) * 0.2 );
		$idx           = max( 0, min( count( $spends ) - 1, $idx ) );
		$vip_threshold = (float) $spends[ $idx ];
	}

	$now     = strtotime( current_time( 'mysql' ) );
	$meta    = farazsms_cashback_segments_meta();
	$summary = array();
	foreach ( array_keys( $meta ) as $k ) {
		$summary[ $k ] = array( 'count' => 0, 'revenue' => 0.0 );
	}

	$out = array();
	foreach ( $rows as $r ) {
		$total = (float) $r['total_spend'];
		$count = (int) $r['order_count'];
		$last  = $r['last_order'] ? strtotime( $r['last_order'] ) : 0;
		$days  = $last ? max( 0, (int) floor( ( $now - $last ) / DAY_IN_SECONDS ) ) : 9999;
		$isvip = $vip_threshold > 0 && $total >= $vip_threshold;

		if ( $isvip && $days > 120 ) {
			$seg = 'vip_atrisk';
		} elseif ( $isvip ) {
			$seg = 'vip_active';
		} elseif ( $count >= 2 && $days >= 45 && $days <= 180 ) {
			$seg = 'churning';
		} elseif ( $count >= 3 && $days <= 90 ) {
			$seg = 'loyal';
		} elseif ( $count === 1 ) {
			$seg = 'onetime';
		} else {
			$seg = 'regular';
		}

		$uid  = (int) $r['user_id'];
		$name = trim( (string) $r['first_name'] . ' ' . (string) $r['last_name'] );
		if ( $name === '' ) {
			$name = (string) $r['email'];
		}

		$summary[ $seg ]['count']   += 1;
		$summary[ $seg ]['revenue'] += $total;

		$out[] = array(
			'name'    => $name,
			'phone'   => isset( $phones[ $uid ] ) ? $phones[ $uid ] : '',
			'email'   => (string) $r['email'],
			'spend'   => $total,
			'orders'  => $count,
			'avg'     => $count > 0 ? $total / $count : 0,
			'last'    => (string) $r['last_order'],
			'days'    => $days,
			'segment' => $seg,
		);
	}

	$data = array(
		'available'     => true,
		'rows'          => $out,
		'summary'       => $summary,
		'limit'         => $limit,
		'total'         => count( $out ),
		'vip_threshold' => $vip_threshold,
	);
	set_transient( $cache_key, $data, HOUR_IN_SECONDS );
	return $data;
}

/** رندرِ تبِ سگمنت‌بندی. */
function farazsms_cashback_render_segments_tab_content() {
	$force = isset( $_GET['cbseg_refresh'] );
	$data  = farazsms_cashback_compute_segments( 500, $force );
	$meta  = farazsms_cashback_segments_meta();

	if ( empty( $data['available'] ) ) {
		echo '<div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;padding:16px;color:#9a3412;font-size:13px;line-height:1.9;">برای سگمنت‌بندی، آنالیتیکسِ ووکامرس لازم است (جدولِ <code>wc_order_stats</code>). معمولاً پیش‌فرض فعال است؛ اگر این پیام را می‌بینید یک‌بار به <strong>ووکامرس ← گزارش‌ها</strong> بروید تا جدول‌ها ساخته شوند.</div>';
		return;
	}

	$seg_filter = isset( $_GET['seg'] ) ? sanitize_key( $_GET['seg'] ) : '';
	if ( $seg_filter !== '' && ! isset( $meta[ $seg_filter ] ) ) {
		$seg_filter = '';
	}
	// v3.22.40: این محتوا روی صفحه‌ی farazsms-segments (باشگاه مشتریان) رندر می‌شود، نه صفحه‌ی
	// کش‌بک. قبلاً $base به‌اشتباه page=farazsms-cashback بود (بازمانده‌ی زمانی که segments یک تبِ
	// داخلِ کش‌بک بود)، پس دکمه‌ی «به‌روزرسانی» و کارت‌های سگمنت کاربر را به صفحه‌ی کش‌بک می‌بردند.
	$base        = admin_url( 'admin.php?page=farazsms-segments&ct=segments' );
	$refresh_url = add_query_arg( 'cbseg_refresh', '1', $seg_filter ? add_query_arg( 'seg', $seg_filter, $base ) : $base );

	$fmt = function ( $n ) {
		return number_format( (float) $n );
	};
	?>
	<div style="direction:rtl; font-family:inherit;">
		<div style="display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-bottom:14px;">
			<p style="margin:0; font-size:12.5px; color:#64748b; line-height:1.9;">
				۵۰۰ مشتریِ برترِ شما بر اساسِ مبلغِ خرید، دسته‌بندی‌شده. روی هر کارت بزنید تا فقط همان گروه را ببینید.
				<br>آستانه‌ی «پرخرید (VIP)»: <strong><?php echo esc_html( $fmt( $data['vip_threshold'] ) ); ?> تومان</strong> به بالا.
			</p>
			<a href="<?php echo esc_url( $refresh_url ); ?>" style="background:#fff; color:#475569; border:1px solid #cbd5e1; padding:7px 14px; border-radius:8px; text-decoration:none; font-size:12.5px;">🔄 به‌روزرسانیِ داده</a>
		</div>

		<!-- کارت‌های خلاصه -->
		<div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(190px, 1fr)); gap:12px; margin-bottom:20px;">
			<?php
			$all_active = $seg_filter === '' ? 'box-shadow:0 0 0 2px #4571ba;' : '';
			?>
			<a href="<?php echo esc_url( $base ); ?>" style="<?php echo $all_active; ?> text-decoration:none; background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:14px;">
				<div style="font-size:12px; color:#64748b; font-weight:600;">همه‌ی مشتریان</div>
				<div style="font-size:22px; font-weight:800; color:#0f172a; margin-top:4px;"><?php echo esc_html( $fmt( $data['total'] ) ); ?></div>
			</a>
			<?php foreach ( $meta as $key => $m ) :
				$cnt = isset( $data['summary'][ $key ] ) ? (int) $data['summary'][ $key ]['count'] : 0;
				$rev = isset( $data['summary'][ $key ] ) ? (float) $data['summary'][ $key ]['revenue'] : 0;
				$active = $seg_filter === $key ? 'box-shadow:0 0 0 2px ' . $m['color'] . ';' : '';
				$url = add_query_arg( 'seg', $key, $base );
			?>
				<a href="<?php echo esc_url( $url ); ?>" title="<?php echo esc_attr( $m['desc'] ); ?>" style="<?php echo $active; ?> text-decoration:none; background:<?php echo esc_attr( $m['bg'] ); ?>; border:1px solid <?php echo esc_attr( $m['color'] ); ?>22; border-radius:12px; padding:14px;">
					<div style="font-size:12px; color:<?php echo esc_attr( $m['color'] ); ?>; font-weight:700;"><?php echo esc_html( $m['label'] ); ?></div>
					<div style="font-size:22px; font-weight:800; color:#0f172a; margin-top:4px;"><?php echo esc_html( $fmt( $cnt ) ); ?> <span style="font-size:12px; font-weight:600; color:#64748b;">مشتری</span></div>
					<div style="font-size:11.5px; color:#475569; margin-top:2px;">مجموع خرید: <?php echo esc_html( $fmt( $rev ) ); ?> تومان</div>
				</a>
			<?php endforeach; ?>
		</div>

		<!-- جدول -->
		<div style="overflow-x:auto; background:#fff; border:1px solid #e5e7eb; border-radius:12px;">
			<table style="width:100%; border-collapse:collapse; font-size:12.5px; min-width:760px;">
				<thead>
					<tr style="background:#f8fafc; text-align:right;">
						<th style="padding:11px 12px; color:#475569; font-weight:700;">نام مشتری</th>
						<th style="padding:11px 12px; color:#475569; font-weight:700;">موبایل</th>
						<th style="padding:11px 12px; color:#475569; font-weight:700;">مجموع خرید</th>
						<th style="padding:11px 12px; color:#475569; font-weight:700;">تعداد سفارش</th>
						<th style="padding:11px 12px; color:#475569; font-weight:700;">میانگین سفارش</th>
						<th style="padding:11px 12px; color:#475569; font-weight:700;">آخرین خرید</th>
						<th style="padding:11px 12px; color:#475569; font-weight:700;">روزها از آخرین خرید</th>
						<th style="padding:11px 12px; color:#475569; font-weight:700;">سگمنت</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$shown = 0;
					foreach ( $data['rows'] as $row ) {
						if ( $seg_filter !== '' && $row['segment'] !== $seg_filter ) {
							continue;
						}
						$shown++;
						$m       = $meta[ $row['segment'] ];
						$jdate   = ( $row['last'] ) ? farazsms_send_reports_to_jalali( $row['last'] ) : $row['last'];
						$phone   = $row['phone'] !== '' ? $row['phone'] : '—';
						?>
						<tr style="border-top:1px solid #f1f5f9;">
							<td style="padding:10px 12px; color:#0f172a; font-weight:600;"><?php echo esc_html( $row['name'] ); ?></td>
							<td style="padding:10px 12px; direction:ltr; text-align:right; font-family:Menlo,Consolas,monospace;"><?php echo esc_html( $phone ); ?></td>
							<td style="padding:10px 12px; color:#16a34a; font-weight:700;"><?php echo esc_html( $fmt( $row['spend'] ) ); ?></td>
							<td style="padding:10px 12px;"><?php echo esc_html( $fmt( $row['orders'] ) ); ?></td>
							<td style="padding:10px 12px; color:#64748b;"><?php echo esc_html( $fmt( $row['avg'] ) ); ?></td>
							<td style="padding:10px 12px; color:#64748b; font-size:11.5px;"><?php echo esc_html( $jdate ); ?></td>
							<td style="padding:10px 12px; color:<?php echo $row['days'] > 120 ? '#dc2626' : ( $row['days'] > 45 ? '#d97706' : '#16a34a' ); ?>; font-weight:600;"><?php echo $row['days'] >= 9999 ? '—' : esc_html( $fmt( $row['days'] ) . ' روز' ); ?></td>
							<td style="padding:10px 12px;"><span style="background:<?php echo esc_attr( $m['bg'] ); ?>; color:<?php echo esc_attr( $m['color'] ); ?>; padding:3px 10px; border-radius:20px; font-size:11px; font-weight:700; white-space:nowrap;"><?php echo esc_html( $m['label'] ); ?></span></td>
						</tr>
						<?php
					}
					if ( $shown === 0 ) {
						echo '<tr><td colspan="8" style="padding:24px; text-align:center; color:#94a3b8;">مشتری‌ای در این گروه نیست.</td></tr>';
					}
					?>
				</tbody>
			</table>
		</div>
		<p style="margin:10px 2px 0; font-size:11px; color:#94a3b8;">نمایشِ ۵۰۰ مشتریِ برترِ خرید. موبایلِ مشتریانِ مهمان (بدونِ حسابِ کاربری) ممکن است خالی باشد. داده هر ۱ ساعت به‌روز می‌شود.</p>
	</div>
	<?php
}

/**
 * ============================================================================
 *  منوی «باشگاه مشتریان» — صفحه‌ی تب‌بندی‌شده. تبِ فعلی: «سگمنت‌بندی مشتریان».
 *  (جدا از کش‌بک؛ ساختارِ تب آماده‌ی افزودنِ تب‌های بعدیِ باشگاه است.)
 * ============================================================================
 */
add_action( 'admin_menu', 'farazsms_segments_register_menu', 26 );
function farazsms_segments_register_menu() {
	add_submenu_page(
		'farazsms',
		__( 'باشگاه مشتریان', 'farazsms' ),
		__( '👥 باشگاه مشتریان', 'farazsms' ),
		'manage_options',
		'farazsms-segments',
		'farazsms_segments_render_page'
	);
}

function farazsms_segments_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی غیرمجاز.' );
	}
	$tabs = array( 'segments' => '📊 سگمنت‌بندی مشتریان' );
	$tab  = isset( $_GET['ct'] ) ? sanitize_key( $_GET['ct'] ) : 'segments';
	if ( ! isset( $tabs[ $tab ] ) ) {
		$tab = 'segments';
	}
	$tab_style = 'display:inline-flex; align-items:center; gap:6px; padding:12px 22px; font-size:13.5px; text-decoration:none; margin-bottom:-2px;';
	echo '<div class="wrap" style="direction:rtl; font-family:inherit; max-width:1200px;">';
	echo '<h1 style="font-size:21px; margin:14px 0 6px;">👥 باشگاه مشتریان</h1>';
	echo '<p style="margin:0 0 16px; color:#64748b; font-size:13px;">شناختِ مشتریان و کمپین‌های هدفمند.</p>';
	echo '<div style="display:flex; gap:4px; border-bottom:2px solid #e5e7eb; margin-bottom:18px; padding:0 4px; flex-wrap:wrap;">';
	foreach ( $tabs as $k => $label ) {
		$url = admin_url( 'admin.php?page=farazsms-segments&ct=' . $k );
		$on  = $tab === $k;
		echo '<a href="' . esc_url( $url ) . '" style="' . $tab_style . ' font-weight:' . ( $on ? '700' : '500' ) . '; color:' . ( $on ? '#365891' : '#64748b' ) . '; border-bottom:3px solid ' . ( $on ? '#4571ba' : 'transparent' ) . ';">' . esc_html( $label ) . '</a>';
	}
	echo '</div>';
	if ( $tab === 'segments' && function_exists( 'farazsms_cashback_render_segments_tab_content' ) ) {
		farazsms_cashback_render_segments_tab_content();
	}
	echo '</div>';
}
