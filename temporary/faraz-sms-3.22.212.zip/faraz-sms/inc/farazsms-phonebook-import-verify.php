<?php
/**
 * تأییدِ واردسازیِ دفترچه‌تلفن — تبدیلِ شکستِ بی‌صدا به شکستِ دیده‌شدنی.
 *
 * ⚠️ چرا این فایل هست (تیکتِ ۱۴۰۵/۰۶/۱۲):
 * اندپوینتِ واردسازیِ گروهیِ سرویس **ناهم‌زمان** است: فایل را می‌گیرد، HTTP 200
 * و «در صف» می‌دهد و تمام. هیچ اندپوینتِ وضعیتی وجود ندارد که بپرسیم آن کار
 * انجام شد یا نه. نتیجه‌اش روی سایتِ واقعی این بود: افزونه ۱۲۰ مخاطب فرستاد،
 * سرویس هر سه بخش را پذیرفت، و دفترچه ساعت‌ها بعد هنوز ۱ مخاطب داشت — و
 * **هیچ‌کس خبردار نشد**، چون از دیدِ افزونه همه‌چیز موفق بود.
 *
 * این ماژول همان کاری را می‌کند که بدونِ اندپوینتِ وضعیت ممکن است: چند دقیقه
 * پس از پایانِ انتقال، شمارِ واقعیِ دفترچه را دوباره می‌خواند و با شمارِ پیش از
 * شروع مقایسه می‌کند. اگر رشد نکرده باشد، هم ردِ تشخیص می‌گذارد و هم به مدیر
 * می‌گوید. تشخیص نمی‌دهد **چرا** نرفته — ولی دیگر بی‌صدا نمی‌ماند.
 *
 * @package FarazSMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** هوکِ بررسیِ تأخیری. */
const FARAZSMS_PB_VERIFY_HOOK = 'farazsms_phonebook_verify_import';

/** آپشنِ نتیجه‌ی آخرین بررسی (برای نمایش به مدیر). */
const FARAZSMS_PB_VERIFY_OPTION = 'farazsms_phonebook_verify_result';

/**
 * چند دقیقه پس از پایانِ انتقال بررسی شود.
 *
 * ⚠️ نه زودتر: واردسازیِ سمتِ سرویس صف دارد و بررسیِ بلافاصله همیشه «نرفته»
 * می‌گفت — همان هشدارِ دروغی که کاربر یاد می‌گیرد نادیده بگیرد.
 */
if ( ! defined( 'FARAZSMS_PB_VERIFY_DELAY' ) ) {
	define( 'FARAZSMS_PB_VERIFY_DELAY', 15 * MINUTE_IN_SECONDS );
}

/**
 * زمان‌بندیِ بررسی پس از پایانِ یک انتقال.
 *
 * @param int $phonebook_id
 * @param int $count_before شمارِ مخاطبان پیش از شروعِ انتقال.
 * @param int $queued       تعدادی که افزونه به سرویس سپرد.
 * @return bool
 */
function farazsms_pb_schedule_verify( $phonebook_id, $count_before, $queued ) {
	$phonebook_id = (int) $phonebook_id;
	$queued       = (int) $queued;
	if ( $phonebook_id <= 0 || $queued <= 0 ) {
		return false; // چیزی سپرده نشده که تأییدش کنیم.
	}
	$args = array( $phonebook_id, (int) $count_before, $queued );
	if ( wp_next_scheduled( FARAZSMS_PB_VERIFY_HOOK, $args ) ) {
		return false; // همین بررسی از قبل در راه است.
	}
	return (bool) wp_schedule_single_event( time() + FARAZSMS_PB_VERIFY_DELAY, FARAZSMS_PB_VERIFY_HOOK, $args );
}

/**
 * شمارِ فعلیِ مخاطبانِ یک دفترچه — تنها نقطه‌ای که این ماژول به سرویس می‌زند.
 *
 * ⚠️ درزِ تزریق عمدی است، نه سلیقه: ترنسپورتِ کلاسِ دفترچه curlِ خام است و
 * دوبلِ HTTPِ سوئیت آن را نمی‌بیند (بدهیِ ثبت‌شده‌ی §۱۷٫۹). بدونِ این فیلتر،
 * تنها راهِ تستِ این تصمیم، زدن به سرویسِ واقعی بود — یعنی عملاً بی‌تست.
 * فیلتر فقط مقدارِ **خوانده‌شده** را جایگزین می‌کند؛ هیچ تصمیمی این‌جا نیست.
 *
 * @param int $phonebook_id
 * @return int|false شمارِ فعلی، یا false اگر در دسترس نبود.
 */
function farazsms_pb_contacts_count( $phonebook_id ) {
	// ⚠️ سنتینلِ «تزریق نشده» **null** است، نه false: با شرطِ is_int، تزریقِ
	// false (یعنی «شمارش در دسترس نیست») از فیلتر رد می‌شد و کد به سرویسِ
	// واقعی می‌زد — همان چیزی که تست می‌خواست جلویش را بگیرد.
	$injected = apply_filters( 'farazsms_pb_contacts_count', null, (int) $phonebook_id );
	if ( $injected !== null ) {
		return is_int( $injected ) ? $injected : false;
	}
	$api_key = farazsms_get_apikey();
	if ( $api_key === '' || ! class_exists( 'FarazSMS_Next_Phonebook_API' ) ) {
		return false;
	}
	$api = new FarazSMS_Next_Phonebook_API();
	return $api->get_phonebook_contacts_count( (int) $phonebook_id, $api_key );
}

/**
 * آیا نتیجه‌ی یک بررسی «واردسازی انجام نشد» است؟
 *
 * ⚠️ **تنها** نقطه‌ی این تصمیم. نسخه‌ی قبل دو مصرف‌کننده داشت (ردِ تشخیص و
 * هشدارِ مدیر) و شرطشان از هم جدا افتاد: لاگ درست شد و هشدار نه، پس
 * همگام‌سازیِ دوباره بی‌صدا در لاگ می‌ماند ولی روی پیشخوان یک خطای قرمزِ
 * «به پشتیبانی خبر دهید» می‌ساخت — همان هشدارِ دروغی که کلِ این ماژول برای
 * نساختنش نوشته شد. قانونِ پروژه: شرطِ تصمیم یک‌جا باشد.
 *
 * سه شرط، و هر سه لازم:
 *   ۱. چیزی سپرده شده باشد؛
 *   ۲. هیچ رشدی رخ نداده باشد (اندپوینت upsert است، پس رشدِ صفر به‌تنهایی
 *      شکست نیست — مخاطبانِ تکراری به‌روزرسانی می‌شوند)؛
 *   ۳. دفترچه به‌طورِ **معنادار** کمتر از چیزی باشد که فرستادیم.
 *
 * «معنادار» تلورانس دارد چون شمارِ سپرده‌شده می‌تواند از شمارِ مخاطبانِ یکتا
 * بیشتر باشد: دو کاربرِ ووکامرس با یک شماره در دو دسته‌ی جدا، دو بار شمرده
 * می‌شوند ولی یک مخاطب می‌سازند. بدونِ تلورانس، فروشگاهی با چند شماره‌ی
 * تکراری در هر همگام‌سازیِ دوباره هشدارِ دروغ می‌گرفت.
 *
 * @param array $r نتیجه‌ی ذخیره‌شده‌ی بررسی.
 * @return bool
 */
function farazsms_pb_import_looks_failed( $r ) {
	if ( ! is_array( $r ) ) {
		return false;
	}
	$queued = isset( $r['queued'] ) ? (int) $r['queued'] : 0;
	$after  = isset( $r['after'] ) ? (int) $r['after'] : 0;
	$grew   = isset( $r['grew'] ) ? (int) $r['grew'] : 0;
	if ( $queued <= 0 || $grew > 0 ) {
		return false;
	}
	// ⚠️ کفِ ۱: با floor(1*0.9)=0 هیچ‌وقت شرط برقرار نمی‌شد و انتقالِ
	// تک‌مخاطبی که هیچ‌چیز وارد نکرده بود، بی‌صدا می‌ماند.
	$threshold = max( 1, (int) floor( $queued * 0.9 ) );
	return $after < $threshold;
}

add_action( FARAZSMS_PB_VERIFY_HOOK, 'farazsms_pb_verify_import', 10, 3 );
/**
 * خواندنِ شمارِ واقعی و مقایسه با پیش از شروع.
 *
 * @param int $phonebook_id
 * @param int $count_before
 * @param int $queued
 * @return void
 */
function farazsms_pb_verify_import( $phonebook_id, $count_before, $queued ) {
	$after = farazsms_pb_contacts_count( (int) $phonebook_id );
	if ( ! is_int( $after ) ) {
		return; // شمارش در دسترس نیست؛ ادعای «نرفت» بدونِ داده ساخته نمی‌شود.
	}

	$grew   = $after - (int) $count_before;
	$result = array(
		'checked_at'   => time(),
		'phonebook_id' => (int) $phonebook_id,
		'before'       => (int) $count_before,
		'after'        => $after,
		'queued'       => (int) $queued,
		'grew'         => $grew,
	);
	update_option( FARAZSMS_PB_VERIFY_OPTION, $result, false );

	if ( ! farazsms_pb_import_looks_failed( $result ) ) {
		return; // یا چیزی وارد شده، یا از قبل بوده — خبری نیست.
	}


	farazsms_send_diag_log( 'phonebook', 'bulk-upsert', 'api_error:واردسازی انجام نشد — شمارِ دفترچه پس از ' . ( FARAZSMS_PB_VERIFY_DELAY / MINUTE_IN_SECONDS ) . ' دقیقه کمتر از تعدادِ سپرده‌شده است', array(
		'source'    => 'phonebook-verify',
		'http_code' => 0,
		'detail'    => 'pb=' . (int) $phonebook_id . ' queued=' . (int) $queued . ' before=' . (int) $count_before . ' after=' . $after,
	) );
}

add_action( 'admin_init', 'farazsms_pb_verify_catchup', 25 );
/**
 * جبرانِ کرونِ خاموش — همان الگویی که این مخزن برای نظرسنجی و سبدِ رهاشده دارد.
 *
 * ⚠️ بدونِ این، مکانیزمی که برای «شکست بی‌صدا نماند» ساخته شده، خودش روی
 * هاستِ بدونِ کرون بی‌صدا شکست می‌خورد — و آن هاست دقیقاً همان‌جایی است که
 * تخلیه و واردسازی بیشترین احتمالِ لنگیدن را دارند.
 *
 * @return void
 */
function farazsms_pb_verify_catchup() {
	if ( wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}
	$cron = function_exists( '_get_cron_array' ) ? _get_cron_array() : array();
	if ( ! is_array( $cron ) ) {
		return;
	}
	$now = time();
	foreach ( $cron as $timestamp => $hooks ) {
		if ( (int) $timestamp > $now || ! isset( $hooks[ FARAZSMS_PB_VERIFY_HOOK ] ) ) {
			continue;
		}
		foreach ( (array) $hooks[ FARAZSMS_PB_VERIFY_HOOK ] as $event ) {
			$args = isset( $event['args'] ) && is_array( $event['args'] ) ? $event['args'] : array();
			// ⚠️ اگر برداشتنِ رویداد شکست بخورد (افزونه‌ای که کرون را جایگزین
			// کرده و pre_unschedule_event را کوتاه می‌کند)، ردیفِ کرون سرِ جایش
			// می‌ماند و **هر** بارگذاریِ صفحه‌ی پیشخوان یک بررسیِ دیگر صف
			// می‌کند — هر کدام یک تماسِ شبکه و یک نوشتنِ آپشن، بی‌پایان.
			// چیزی هم گم نمی‌شود: رویداد همان‌جاست و کرونِ سالم اجرایش می‌کند.
			if ( ! wp_unschedule_event( (int) $timestamp, FARAZSMS_PB_VERIFY_HOOK, $args ) ) {
				continue;
			}
			// بررسی خودش شبکه می‌زند، پس روی درخواستِ پیشخوان معطل نمی‌ماند:
			// از همان صفِ مشترکِ افزونه می‌رود.
			farazsms_queue_task( 'phonebook-verify', 'farazsms_pb_verify_import', array_values( $args ) );
		}
		return; // یک دسته در هر بازدید کافی است.
	}
}

add_action( 'admin_notices', 'farazsms_pb_verify_notice' );
/**
 * هشدارِ مدیر — فقط وقتی آخرین بررسی شکست را نشان داده باشد.
 *
 * @return void
 */
function farazsms_pb_verify_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$r = get_option( FARAZSMS_PB_VERIFY_OPTION, array() );
	if ( ! farazsms_pb_import_looks_failed( $r ) ) {
		return; // همان تصمیمِ واحدِ بالا — نه یک شرطِ موازی.
	}
	// یک‌بار نشان بده و خودش را خاموش کند؛ هشدارِ همیشگی خوانده نمی‌شود.
	delete_option( FARAZSMS_PB_VERIFY_OPTION );
	?>
	<div class="notice notice-error is-dismissible" style="direction:rtl;">
		<p>
			<strong>فراز اس ام اس:</strong>
			<?php
			printf(
				/* translators: 1: تعداد سپرده‌شده 2: شناسه‌ی دفترچه */
				esc_html__( '%1$s مخاطب به سرویس فرستاده شد و پاسخِ موفق گرفت، ولی چند دقیقه بعد شمارِ دفترچه (شناسه %2$s) هنوز از این تعداد کمتر است. این را به پشتیبانیِ فراز اطلاع دهید.', 'farazsms' ),
				esc_html( number_format_i18n( (int) $r['queued'] ) ),
				esc_html( (string) $r['phonebook_id'] )
			);
			?>
		</p>
	</div>
	<?php
}
