<?php
/**
 * جلوگیری از حسابِ کاربریِ تکراری با یک شماره موبایل + همگام‌سازیِ متاهای موبایل.
 *
 * مسئله: کاربر می‌تواند با یک شماره دو حساب داشته باشد — یکی «مشترک» (ثبت‌نام از
 * ماژولِ ورودِ فراز، username=موبایل، متای mobile_number) و یکی «مشتری» (ساختِ خودکارِ
 * ووکامرس هنگامِ خرید، کلیدِ ایمیل، متای billing_phone). چون ووکامرس بر اساسِ ایمیل حساب
 * می‌سازد و موبایل را نادیده می‌گیرد، تکراری ایجاد می‌شود.
 *
 * این ماژول دو کار می‌کند:
 *  ۱) همگام‌سازیِ متای موبایل (همیشه، بی‌خطر): شماره را نرمال و در هر سه کلید
 *     (billing_phone / mobile_number / digits_phone_no) آینه می‌کند تا جست‌وجوی هر سیستم
 *     کاربر را پیدا کند (هم برای جلوگیری، هم برای ابزارِ ادغام).
 *  ۲) گاردِ تسویه‌حساب (قابلِ‌فعال‌سازی): اگر مهمان با شماره‌ای که قبلاً حساب دارد قصدِ
 *     خرید/ثبت‌نام کند، با پیامِ «وارد شوید» جلوی ساختِ حسابِ تکراری گرفته می‌شود.
 *     پیش‌فرض خاموش است تا روی فروشگاه‌های زنده ناگهان رفتار عوض نشود.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_DEDUPE_GUARD_OPTION = 'farazsms_prevent_duplicate_mobile';

/**
 * نرمال‌سازیِ شماره به 09xxxxxxxxx (یا '' اگر نامعتبر).
 */
function farazsms_dedupe_normalize_mobile( $raw ) {
	if ( function_exists( 'farazsms_normalize_phone' ) ) {
		$n = preg_replace( '/\D+/', '', (string) farazsms_normalize_phone( $raw ) );
	} else {
		$n = preg_replace( '/\D+/', '', (string) $raw );
	}
	if ( $n === '' ) {
		return '';
	}
	if ( strpos( $n, '0098' ) === 0 ) {
		$n = '0' . substr( $n, 4 );
	} elseif ( strpos( $n, '98' ) === 0 && strlen( $n ) === 12 ) {
		$n = '0' . substr( $n, 2 );
	} elseif ( strlen( $n ) === 10 && $n[0] === '9' ) {
		$n = '0' . $n;
	}
	return preg_match( '/^09\d{9}$/', $n ) ? $n : '';
}

/**
 * فرمت‌های معادلِ یک شماره‌ی کانونی — تک‌منبعِ لایه‌ی هویتِ شماره.
 *
 * کدریویو v3.22.152: پیش از این، تابعِ تکی سه فرمت و تابعِ دسته‌ای پنج فرمت را می‌سنجید؛
 * یعنی دو تابع می‌توانستند برای یک شماره صاحبانِ متفاوتی برگردانند. حالا هر دو از این
 * فهرست می‌خوانند.
 *
 * @param string $mobile شماره‌ی نرمال‌شده (09XXXXXXXXX).
 * @return array<int,string>
 */
function farazsms_dedupe_mobile_variants( $mobile ) {
	$mobile = (string) $mobile;
	if ( $mobile === '' ) {
		return array();
	}
	$no_zero = ltrim( $mobile, '0' );
	return array( $mobile, $no_zero, '+98' . $no_zero, '98' . $no_zero, '0098' . $no_zero );
}

/**
 * همه‌ی شناسه‌های کاربرانی که این شماره را دارند (در هر کلیدِ متا یا به‌عنوانِ user_login).
 *
 * @param string $raw_mobile
 * @param int    $exclude_user_id برای نادیده‌گرفتنِ خودِ کاربر.
 * @return int[] یکتا
 */
function farazsms_find_user_ids_by_mobile( $raw_mobile, $exclude_user_id = 0 ) {
	$mobile = farazsms_dedupe_normalize_mobile( $raw_mobile );
	if ( $mobile === '' ) {
		return array();
	}
	global $wpdb;
	$ids = array();

	// متاها (mobile_number / billing_phone / digits_phone_no) — مقدار ممکن است نرمال‌نشده باشد،
	// پس هم مقدارِ نرمال و هم بدونِ صفر را می‌سنجیم.
	$variants     = farazsms_dedupe_mobile_variants( $mobile );
	$placeholders = implode( ',', array_fill( 0, count( $variants ), '%s' ) );
	$meta_ids = $wpdb->get_col(
		$wpdb->prepare(
			"SELECT DISTINCT user_id FROM {$wpdb->usermeta}
			 WHERE meta_key IN ('mobile_number','billing_phone','digits_phone_no')
			 AND meta_value IN ( $placeholders )",
			$variants
		)
	);
	foreach ( (array) $meta_ids as $uid ) {
		$ids[ (int) $uid ] = true;
	}

	// user_login = موبایل (ماژولِ ورود username را برابرِ شماره می‌گذارد).
	foreach ( $variants as $login ) {
		$u = get_user_by( 'login', $login );
		if ( $u ) {
			$ids[ (int) $u->ID ] = true;
		}
	}

	if ( $exclude_user_id ) {
		unset( $ids[ (int) $exclude_user_id ] );
	}
	return array_map( 'intval', array_keys( $ids ) );
}

/**
 * v3.22.141: نگاشتِ «چند شماره → کاربر» با دو کوئری (نه یکی به‌ازای هر ردیف).
 *
 * برای فهرست‌های ادمین (مثلِ «موجود شد خبرم کن») که باید نامِ صاحبِ شماره را کنارِ ده‌ها ردیف
 * نشان دهند. همان قاعده‌ی لایه‌ی هویت را نگه می‌دارد: فقط «تطابقِ یکتا» پذیرفته می‌شود؛ اگر
 * چند کاربر یک شماره داشته باشند (موردِ گزارشِ ناهم‌سانی) نامِ حدسی نشان نمی‌دهیم.
 *
 * @param string[] $raw_mobiles
 * @return array<string,int> کلید = شماره‌ی نرمال‌شده (09…)، مقدار = شناسه‌ی کاربر.
 */
function farazsms_map_mobiles_to_user_ids( array $raw_mobiles ) {
	global $wpdb;

	$canonical = array();  // variant => canonical
	foreach ( $raw_mobiles as $raw ) {
		$mobile = farazsms_dedupe_normalize_mobile( $raw );
		if ( $mobile === '' ) {
			continue;
		}
		foreach ( farazsms_dedupe_mobile_variants( $mobile ) as $variant ) {
			$canonical[ $variant ] = $mobile;
		}
	}
	if ( empty( $canonical ) ) {
		return array();
	}

	$variants     = array_keys( $canonical );
	$placeholders = implode( ',', array_fill( 0, count( $variants ), '%s' ) );
	$matches      = array(); // canonical => array<int,true>

	$meta_rows = $wpdb->get_results(
		$wpdb->prepare(
			"SELECT user_id, meta_value FROM {$wpdb->usermeta}
			 WHERE meta_key IN ('mobile_number','billing_phone','digits_phone_no')
			 AND meta_value IN ( $placeholders )",
			$variants
		),
		ARRAY_A
	);
	foreach ( (array) $meta_rows as $row ) {
		$key = $canonical[ $row['meta_value'] ] ?? '';
		if ( $key !== '' ) {
			$matches[ $key ][ (int) $row['user_id'] ] = true;
		}
	}

	// نام‌کاربری برابرِ شماره (ماژولِ ورود این‌طور می‌سازد).
	$login_rows = $wpdb->get_results(
		$wpdb->prepare( "SELECT ID, user_login FROM {$wpdb->users} WHERE user_login IN ( $placeholders )", $variants ),
		ARRAY_A
	);
	foreach ( (array) $login_rows as $row ) {
		$key = $canonical[ $row['user_login'] ] ?? '';
		if ( $key !== '' ) {
			$matches[ $key ][ (int) $row['ID'] ] = true;
		}
	}

	$map = array();
	foreach ( $matches as $mobile => $ids ) {
		if ( count( $ids ) === 1 ) {
			$map[ $mobile ] = (int) key( $ids );
		}
	}
	return $map;
}

// ============================================================================
// ۱) همگام‌سازیِ متای موبایل — بی‌خطر، همیشه فعال.
// ============================================================================

/**
 * شماره‌ی کاربر را از هر کلیدِ موجود می‌خواند، نرمال می‌کند و در هر سه کلید آینه می‌کند
 * (فقط کلیدهای خالی را پر می‌کند؛ مقدارِ موجود را بازنویسی نمی‌کند مگر برای نرمال‌سازی).
 */
function farazsms_dedupe_sync_user_mobile( $user_id ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return;
	}
	$keys = array( 'mobile_number', 'billing_phone', 'digits_phone_no' );
	$mobile = '';
	foreach ( $keys as $k ) {
		$v = farazsms_dedupe_normalize_mobile( get_user_meta( $user_id, $k, true ) );
		if ( $v !== '' ) {
			$mobile = $v;
			break;
		}
	}
	if ( $mobile === '' ) {
		return;
	}
	foreach ( $keys as $k ) {
		$cur = (string) get_user_meta( $user_id, $k, true );
		if ( $cur === '' || farazsms_dedupe_normalize_mobile( $cur ) === $mobile ) {
			// خالی یا همان شماره (شاید بدونِ صفر) → مقدارِ نرمالِ یکدست بنویس.
			if ( $cur !== $mobile ) {
				update_user_meta( $user_id, $k, $mobile );
			}
		}
	}
}
add_action( 'user_register', 'farazsms_dedupe_sync_user_mobile', 30 );
add_action( 'profile_update', 'farazsms_dedupe_sync_user_mobile', 30 );
add_action( 'woocommerce_checkout_update_user_meta', 'farazsms_dedupe_sync_user_mobile', 30 );
add_action( 'woocommerce_created_customer', 'farazsms_dedupe_sync_user_mobile', 30 );

// ============================================================================
// ۲) گاردِ تسویه‌حساب — جلوگیری از حسابِ تکراری (قابلِ‌فعال‌سازی).
// ============================================================================

function farazsms_dedupe_guard_enabled() {
	return get_option( FARAZSMS_DEDUPE_GUARD_OPTION, '0' ) === '1';
}

add_action( 'woocommerce_checkout_process', 'farazsms_dedupe_checkout_guard' );
function farazsms_dedupe_checkout_guard() {
	if ( ! farazsms_dedupe_guard_enabled() || is_user_logged_in() ) {
		return;
	}
	$phone = isset( $_POST['billing_phone'] ) ? wp_unslash( $_POST['billing_phone'] ) : '';
	$mobile = farazsms_dedupe_normalize_mobile( $phone );
	if ( $mobile === '' ) {
		return;
	}
	$existing = farazsms_find_user_ids_by_mobile( $mobile );
	if ( empty( $existing ) ) {
		return;
	}
	if ( ! function_exists( 'wc_add_notice' ) ) {
		return;
	}
	// لینکِ ورود: صفحه‌ی ورودِ ماژول (اگر هست) وگرنه my-account.
	$login_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : wp_login_url();
	if ( function_exists( 'get_farazsms_login_page_id' ) ) {
		$pid = (int) get_farazsms_login_page_id();
		if ( $pid > 0 ) {
			$login_url = get_permalink( $pid );
		}
	}
	wc_add_notice(
		sprintf(
			/* translators: %s login url */
			__( 'این شماره موبایل قبلاً در سایت ثبت شده است. برای جلوگیری از ساختِ حسابِ تکراری، لطفاً ابتدا <a href="%s">وارد شوید</a> و سپس خرید را ادامه دهید.', 'farazsms' ),
			esc_url( $login_url )
		),
		'error'
	);
}

// ============================================================================
// ۳) صفحه‌ی مدیریت (v3.22.54): فعال‌سازیِ گارد + گزارشِ فقط‌خواندنیِ حساب‌های تکراری.
//    عمداً «حذف/ادغامِ خودکار» ندارد — حذفِ کاربر داده (کیف‌پول/اشتراک/پروفایل) را از بین می‌برد و
//    ادغامِ اشتباه ریسکِ بالایی دارد؛ پس فقط گزارش می‌دهیم و مدیر خودش در وردپرس تصمیم می‌گیرد.
// ============================================================================

add_action( 'admin_menu', 'farazsms_dedupe_admin_menu', 71 );
function farazsms_dedupe_admin_menu() {
	add_submenu_page(
		'farazsms',
		__( 'حساب‌های تکراری', 'farazsms' ),
		__( '👥 حساب‌های تکراری', 'farazsms' ),
		'manage_options',
		'farazsms-account-dedupe',
		'farazsms_dedupe_render_page'
	);
}

// ذخیره‌ی toggleِ گارد.
add_action( 'admin_post_farazsms_dedupe_save', 'farazsms_dedupe_handle_save' );
function farazsms_dedupe_handle_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( __( 'دسترسی غیرمجاز.', 'farazsms' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'farazsms_dedupe_save' );
	update_option( FARAZSMS_DEDUPE_GUARD_OPTION, isset( $_POST['prevent_duplicate'] ) && $_POST['prevent_duplicate'] === '1' ? '1' : '0', false );
	wp_safe_redirect( add_query_arg( array( 'page' => 'farazsms-account-dedupe', 'saved' => '1' ), admin_url( 'admin.php' ) ) );
	exit;
}

/**
 * گروه‌های حساب‌های تکراری را می‌یابد (فقط‌خواندنی): کاربرانی که شماره‌ی کانونیِ یکسان دارند.
 *
 * @param int $limit_groups سقفِ گروه‌ها برای جلوگیری از سنگین‌شدنِ صفحه.
 * @return array{groups: array<string,int[]>, truncated: bool}
 */
function farazsms_dedupe_scan_duplicates( $limit_groups = 200 ) {
	global $wpdb;

	$rows = $wpdb->get_results(
		"SELECT user_id, meta_value FROM {$wpdb->usermeta}
		 WHERE meta_key IN ('mobile_number','billing_phone','digits_phone_no') AND meta_value <> ''",
		ARRAY_A
	);

	$by_user = array();
	foreach ( (array) $rows as $r ) {
		$c = farazsms_dedupe_normalize_mobile( (string) $r['meta_value'] );
		if ( $c !== '' ) {
			$by_user[ (int) $r['user_id'] ][ $c ] = true;
		}
	}
	// user_login که خودش شماره است.
	$login_rows = $wpdb->get_results( "SELECT ID, user_login FROM {$wpdb->users}", ARRAY_A );
	foreach ( (array) $login_rows as $lr ) {
		$c = farazsms_dedupe_normalize_mobile( (string) $lr['user_login'] );
		if ( $c !== '' ) {
			$by_user[ (int) $lr['ID'] ][ $c ] = true;
		}
	}

	// نگاشتِ canonical => فهرستِ کاربران.
	$groups = array();
	foreach ( $by_user as $uid => $canon_set ) {
		foreach ( array_keys( $canon_set ) as $canon ) {
			$groups[ $canon ][ $uid ] = true;
		}
	}

	$result    = array();
	$truncated = false;
	foreach ( $groups as $canon => $uid_map ) {
		if ( count( $uid_map ) < 2 ) {
			continue;
		}
		if ( count( $result ) >= $limit_groups ) {
			$truncated = true;
			break;
		}
		$result[ $canon ] = array_map( 'intval', array_keys( $uid_map ) );
	}
	return array( 'groups' => $result, 'truncated' => $truncated );
}

function farazsms_dedupe_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	$enabled = farazsms_dedupe_guard_enabled();
	$scan    = farazsms_dedupe_scan_duplicates();
	$groups  = $scan['groups'];
	?>
	<div class="wrap" style="direction:rtl; max-width:960px;">
		<h1 style="font-size:22px;">👥 <?php esc_html_e( 'حساب‌های تکراری', 'farazsms' ); ?></h1>

		<?php if ( isset( $_GET['saved'] ) ) : ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'تنظیمات ذخیره شد.', 'farazsms' ); ?></p></div>
		<?php endif; ?>

		<!-- بخشِ ۱: گاردِ جلوگیری -->
		<div style="background:#fff; border:1px solid #e1e1e1; border-radius:12px; padding:18px 22px; margin:16px 0;">
			<h2 style="font-size:17px; margin:0 0 8px;">🛡️ <?php esc_html_e( 'جلوگیری از حسابِ تکراریِ جدید', 'farazsms' ); ?></h2>
			<p style="color:#4d4d4d; font-size:13px; line-height:1.9; margin:0 0 12px;">
				<?php esc_html_e( 'اگر روشن باشد، وقتی مهمانی با شماره‌ای که قبلاً حساب دارد قصدِ خرید کند، پیامِ «ابتدا وارد شوید» نمایش داده و از ساختِ حسابِ تکراری جلوگیری می‌شود. (روی مشتریانِ فعلی اثری ندارد.)', 'farazsms' ); ?>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="farazsms_dedupe_save">
				<?php wp_nonce_field( 'farazsms_dedupe_save' ); ?>
				<label style="display:flex; align-items:center; gap:10px; font-size:13.5px;">
					<input type="checkbox" name="prevent_duplicate" value="1" <?php checked( $enabled ); ?>>
					<?php esc_html_e( 'جلوگیری از ساختِ حسابِ تکراری در تسویه‌حساب فعال باشد', 'farazsms' ); ?>
				</label>
				<button type="submit" class="button button-primary" style="margin-top:12px;"><?php esc_html_e( 'ذخیره', 'farazsms' ); ?></button>
			</form>
		</div>

		<!-- بخشِ ۲: گزارشِ فقط‌خواندنی -->
		<h2 style="font-size:17px; margin-top:24px;">📋 <?php printf( esc_html__( 'گزارشِ حساب‌های تکراریِ موجود (%d گروه)', 'farazsms' ), count( $groups ) ); ?></h2>
		<p style="color:#4d4d4d; font-size:13px; line-height:1.9;">
			<?php esc_html_e( 'حساب‌هایی که شماره‌موبایلِ معادل دارند (یک نفر، چند حساب). این گزارش فقط‌خواندنی است؛ برای ادغام، ایمیل/نام/سفارشِ هر حساب را بررسی و در صورتِ اطمینان، حساب‌ها را دستی در بخشِ «کاربران»ِ وردپرس مدیریت کنید (حذفِ خودکار عمداً نگذاشته‌ایم چون داده‌ی کیف‌پول/اشتراک را از بین می‌بَرد).', 'farazsms' ); ?>
		</p>

		<?php if ( $scan['truncated'] ) : ?>
			<div class="notice notice-warning"><p><?php esc_html_e( 'تعدادِ گروه‌ها زیاد بود و فهرست کوتاه شد.', 'farazsms' ); ?></p></div>
		<?php endif; ?>

		<?php if ( empty( $groups ) ) : ?>
			<p style="color:#0c9765;"><?php esc_html_e( '✅ حساب‌های تکراری‌ای پیدا نشد.', 'farazsms' ); ?></p>
		<?php else : ?>
			<?php foreach ( $groups as $canonical => $user_ids ) : ?>
				<div style="background:#fff; border:1px solid #e1e1e1; border-radius:10px; padding:10px 14px; margin-bottom:10px;">
					<strong style="direction:ltr; display:inline-block;"><?php echo esc_html( $canonical ); ?></strong>
					<table class="widefat" style="margin-top:8px; background:#fff;">
						<thead><tr>
							<th>ID</th>
							<th><?php esc_html_e( 'نام‌کاربری', 'farazsms' ); ?></th>
							<th><?php esc_html_e( 'ایمیل', 'farazsms' ); ?></th>
							<th><?php esc_html_e( 'نقش', 'farazsms' ); ?></th>
							<th><?php esc_html_e( 'عملیات', 'farazsms' ); ?></th>
						</tr></thead>
						<tbody>
						<?php foreach ( $user_ids as $uid ) :
							$u = get_userdata( $uid );
							if ( ! $u ) { continue; }
							?>
							<tr>
								<td><?php echo (int) $uid; ?></td>
								<td><?php echo esc_html( $u->user_login ); ?></td>
								<td dir="ltr"><?php echo esc_html( $u->user_email ); ?></td>
								<td><?php echo esc_html( implode( ', ', (array) $u->roles ) ); ?></td>
								<td><a href="<?php echo esc_url( get_edit_user_link( $uid ) ); ?>" class="button button-small"><?php esc_html_e( 'مشاهده/ویرایش', 'farazsms' ); ?></a></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>
	<?php
}
