<?php
/**
 * گردونه‌ی شانس (Spin-to-Win) — MVP.
 *
 * حلقه‌ی اصلی: مدیر جوایز و شانسِ هر تکه را تعیین می‌کند → کاربر در فرانت موبایلش را
 * وارد می‌کند → کدِ تأیید (OTP) پیامک می‌شود → پس از تأیید، گردونه را می‌چرخاند →
 * جایزه سمتِ سرور (وزن‌دار، ضدِتقلب) تعیین می‌شود → پیامکِ نتیجه ارسال می‌شود →
 * در دیتابیس ثبت می‌شود. مدیر لیستِ شرکت‌کنندگان، خروجیِ CSV و ارسالِ پیامکِ گروهی دارد.
 *
 * اصول: تعیینِ جایزه فقط سمتِ سرور (کلاینت دست نمی‌برد)، nonce + sanitize، یک چرخش
 * به‌ازای هر موبایل، throttleِ ارسالِ OTP، و بارگذاریِ asset فقط وقتی لازم است.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const FARAZSMS_SPIN_OPTION = 'farazsms_spin_wheel_settings';

/** نامِ جدولِ لاگِ چرخش. */
function farazsms_spin_table() {
	global $wpdb;
	return $wpdb->prefix . 'farazsms_spin_log';
}

/** ساختِ جدول (idempotent). */
function farazsms_spin_maybe_setup_table() {
	if ( get_option( 'farazsms_spin_db_v1' ) === '1' ) {
		return;
	}
	global $wpdb;
	$table   = farazsms_spin_table();
	$collate = $wpdb->get_charset_collate();
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( "CREATE TABLE $table (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		mobile VARCHAR(20) NOT NULL DEFAULT '',
		prize_label VARCHAR(190) NOT NULL DEFAULT '',
		prize_type VARCHAR(20) NOT NULL DEFAULT '',
		prize_value TEXT NULL,
		won TINYINT(1) NOT NULL DEFAULT 0,
		ip VARCHAR(45) NOT NULL DEFAULT '',
		created_at DATETIME NOT NULL,
		PRIMARY KEY (id),
		KEY mobile (mobile),
		KEY created_at (created_at)
	) $collate;" );
	// v3.21.7: فقط وقتی جدول واقعاً ساخته شد latch کن (شکستِ dbDelta = مرگِ بی‌صدا).
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
		update_option( 'farazsms_spin_db_v1', '1', false );
	}
}
add_action( 'admin_init', 'farazsms_spin_maybe_setup_table' );

/** تنظیمات + پیش‌فرض‌ها. */
function farazsms_spin_settings() {
	$defaults = array(
		'enabled'          => '0',
		'title'            => 'گردونه‌ی شانس 🎁',
		'subtitle'         => 'شماره موبایلت را وارد کن، شانست را بچرخان و جایزه ببر!',
		'button_text'      => 'بچرخان!',
		'mobile_label'     => 'شماره موبایل',
		'consent_text'     => 'با شرکت در قرعه‌کشی، دریافتِ پیامکِ اطلاع‌رسانی را می‌پذیرم.',
		'display_location' => 'off',     // off | everywhere | specific
		'display_pages'    => '',        // شناسه‌ها با کاما (وقتی specific)
		'display_frequency'=> 'session', // always | session | daily | once — هر چند وقت یک‌بار به هر بازدیدکننده نشان داده شود (فقط برای پاپ‌آپ خودکار)
		'trigger'          => 'load',    // load | click
		'trigger_delay'    => '4',       // ثانیه (برای load)
		'trigger_selector' => '.spin-wheel-open', // برای click
		'require_otp'      => '1',
		'one_per_mobile'   => '1',
		'otp_pattern'      => '',
		'otp_message'      => "کدِ تأیید برای شرکت در گردونه‌ی شانس: %code%",
		'win_pattern'      => '',
		'win_message'      => "تبریک! شما برنده شدید: %prize%\nبرای استفاده به سایت مراجعه کنید.",
		'lose_text'        => 'این بار شانس نیاوردی، دفعه‌ی بعد حتماً! 🌱',
		'coupon_expiry_days' => '7',   // انقضای کوپنِ برنده (روز) — 0 = بدونِ انقضا
		'slices'           => farazsms_spin_default_slices(),
	);
	$saved = get_option( FARAZSMS_SPIN_OPTION, array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}
	$s = array_merge( $defaults, $saved );
	if ( ! is_array( $s['slices'] ) || empty( $s['slices'] ) ) {
		$s['slices'] = farazsms_spin_default_slices();
	}
	return $s;
}

/** تکه‌های پیش‌فرض. type: none | coupon | link */
function farazsms_spin_default_slices() {
	return array(
		array( 'label' => '۱۰٪ تخفیف', 'type' => 'coupon', 'value' => 'OFF10', 'weight' => 20, 'color' => '#ef4444' ),
		array( 'label' => 'پوچ', 'type' => 'none', 'value' => '', 'weight' => 30, 'color' => '#64748b' ),
		array( 'label' => '۵٪ تخفیف', 'type' => 'coupon', 'value' => 'OFF5', 'weight' => 25, 'color' => '#f59e0b' ),
		array( 'label' => 'ارسال رایگان', 'type' => 'coupon', 'value' => 'FREESHIP', 'weight' => 10, 'color' => '#10b981' ),
		array( 'label' => 'پوچ', 'type' => 'none', 'value' => '', 'weight' => 30, 'color' => '#475569' ),
		array( 'label' => '۲۰٪ تخفیف', 'type' => 'coupon', 'value' => 'OFF20', 'weight' => 5, 'color' => '#8b5cf6' ),
	);
}

/** آیا گردونه باید در صفحه‌ی فعلیِ فرانت رندر شود؟ */
function farazsms_spin_should_render() {
	if ( is_admin() ) {
		return false;
	}
	$s = farazsms_spin_settings();
	if ( $s['enabled'] !== '1' ) {
		return false;
	}
	$loc = $s['display_location'];
	if ( $loc === 'off' ) {
		return false;
	}
	if ( $loc === 'everywhere' ) {
		return true;
	}
	if ( $loc === 'specific' ) {
		$ids = array_filter( array_map( 'absint', explode( ',', (string) $s['display_pages'] ) ) );
		if ( empty( $ids ) ) {
			return false;
		}
		// is_page فقط برگه‌ی معمولی را می‌گیرد؛ برای پوششِ فروشگاه/محصول/صفحه‌ی اصلی، آبجکتِ
		// صفحه‌ی جاری را هم تطبیق می‌دهیم — ولی فقط اگر «نوشته‌ای» (WP_Post) باشد، نه ترم/نویسنده
		// (شناسه‌شان از فضای مجزاست و می‌تواند تصادفاً با شناسه‌ی برگه یکی شود → نمایش در جای اشتباه).
		$qo = function_exists( 'get_queried_object' ) ? get_queried_object() : null;
		if ( $qo instanceof WP_Post && in_array( (int) $qo->ID, $ids, true ) ) {
			return true;
		}
		return is_page( $ids );
	}
	return false;
}

/* ───────────────────────────── فرانت‌اند ───────────────────────────── */

add_action( 'wp_enqueue_scripts', 'farazsms_spin_enqueue' );
function farazsms_spin_enqueue() {
	if ( ! farazsms_spin_should_render() ) {
		return;
	}
	$ver = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1.0';
	wp_enqueue_style( 'farazsms-spin-wheel', FARAZSMS_CORE_CSS . 'spin-wheel.css', array(), $ver );
	wp_enqueue_script( 'farazsms-spin-wheel', FARAZSMS_CORE_JS . 'spin-wheel.js', array(), $ver, true );
	$s = farazsms_spin_settings();
	// فقط داده‌های لازمِ نمایش به کلاینت (نه weightها — تعیینِ جایزه سمتِ سرور است).
	$client_slices = array();
	foreach ( $s['slices'] as $sl ) {
		$client_slices[] = array(
			'label' => (string) $sl['label'],
			'color' => (string) $sl['color'],
		);
	}
	wp_localize_script( 'farazsms-spin-wheel', 'farazsmsSpin', array(
		'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
		'nonce'        => wp_create_nonce( 'farazsms_spin' ),
		'slices'       => $client_slices,
		'title'        => $s['title'],
		'subtitle'     => $s['subtitle'],
		'buttonText'   => $s['button_text'],
		'mobileLabel'  => $s['mobile_label'],
		'consentText'  => $s['consent_text'],
		'loseText'     => $s['lose_text'],
		'requireOtp'   => $s['require_otp'],
		'trigger'      => $s['trigger'],
		'triggerDelay' => (int) $s['trigger_delay'],
		'triggerSel'   => $s['trigger_selector'],
		'frequency'    => $s['display_frequency'], // always | session | daily | once
	) );
}

/* ───────────────────────────── AJAX (فرانت) ───────────────────────────── */

add_action( 'wp_ajax_farazsms_spin_send_otp', 'farazsms_spin_ajax_send_otp' );
add_action( 'wp_ajax_nopriv_farazsms_spin_send_otp', 'farazsms_spin_ajax_send_otp' );
function farazsms_spin_ajax_send_otp() {
	check_ajax_referer( 'farazsms_spin', 'nonce' );
	$s = farazsms_spin_settings();
	if ( $s['enabled'] !== '1' ) {
		wp_send_json_error( array( 'message' => 'گردونه فعال نیست.' ) );
	}
	$mobile = farazsms_spin_normalize_mobile( isset( $_POST['mobile'] ) ? wp_unslash( $_POST['mobile'] ) : '' );
	if ( $mobile === '' ) {
		wp_send_json_error( array( 'message' => 'شماره موبایل معتبر نیست.' ) );
	}
	if ( $s['one_per_mobile'] === '1' && farazsms_spin_already_spun( $mobile ) ) {
		wp_send_json_error( array( 'message' => 'با این شماره قبلاً شرکت کرده‌اید.' ) );
	}
	// v3.21.27 (P1) امنیتی — سقفِ IP/عمومی ضدِ تخلیه‌ی اعتبار با چرخشِ شماره (throttleِ per-mobile
	// تنها کافی نیست؛ مهاجم شماره را عوض می‌کند). گاردِ عمومی: IP ۱۰/دقیقه + شماره ۳/۱۰دقیقه.
	$guard = farazsms_rate_limit_guard_public( 'spin_otp', $mobile );
	if ( is_array( $guard ) && empty( $guard['allowed'] ) ) {
		wp_send_json_error( array( 'message' => isset( $guard['message'] ) ? $guard['message'] : 'تعداد درخواست زیاد است.' ) );
	}
	// سقفِ ساعتیِ عمومی (مستقل از شماره) برای محافظت از اعتبارِ پنل.
	$spin_global_key = 'farazsms_spin_otp_global_hour';
	$spin_global     = (int) get_transient( $spin_global_key );
	if ( $spin_global >= 200 ) {
		wp_send_json_error( array( 'message' => 'تعداد درخواست زیاد است. کمی بعد تلاش کنید.' ) );
	}
	set_transient( $spin_global_key, $spin_global + 1, HOUR_IN_SECONDS );

	// throttle: حداکثر یک کد در هر ۶۰ ثانیه برای هر شماره.
	$throttle_key = 'farazsms_spin_otp_throttle_' . md5( $mobile );
	if ( get_transient( $throttle_key ) ) {
		wp_send_json_error( array( 'message' => 'کمی صبر کنید و دوباره تلاش کنید.' ) );
	}
	$code = (string) wp_rand( 10000, 99999 );
	set_transient( 'farazsms_spin_otp_' . md5( $mobile ), $code, 5 * MINUTE_IN_SECONDS );
	set_transient( $throttle_key, '1', MINUTE_IN_SECONDS );

	$pattern = trim( (string) $s['otp_pattern'] );
	if ( $pattern === '' || ! function_exists( 'farazsms_send_pattern_sms_raw' ) ) {
		wp_send_json_error( array( 'message' => 'پترنِ کدِ تأیید تنظیم نشده است. (به مدیر اطلاع دهید)' ) );
	}
	$res = farazsms_send_pattern_sms_raw( $mobile, $pattern, array( 'code' => $code ) );
	if ( $res === true || $res === 'success' ) {
		wp_send_json_success( array( 'message' => 'کدِ تأیید ارسال شد.' ) );
	}
	wp_send_json_error( array( 'message' => 'ارسالِ پیامک ناموفق بود: ' . ( is_string( $res ) ? $res : 'خطا' ) ) );
}

add_action( 'wp_ajax_farazsms_spin_do', 'farazsms_spin_ajax_do' );
add_action( 'wp_ajax_nopriv_farazsms_spin_do', 'farazsms_spin_ajax_do' );
function farazsms_spin_ajax_do() {
	check_ajax_referer( 'farazsms_spin', 'nonce' );
	$s = farazsms_spin_settings();
	if ( $s['enabled'] !== '1' ) {
		wp_send_json_error( array( 'message' => 'گردونه فعال نیست.' ) );
	}
	$mobile = farazsms_spin_normalize_mobile( isset( $_POST['mobile'] ) ? wp_unslash( $_POST['mobile'] ) : '' );
	if ( $mobile === '' ) {
		wp_send_json_error( array( 'message' => 'شماره موبایل معتبر نیست.' ) );
	}
	// v3.21.27 (P2) امنیتی — قفلِ کوتاهِ per-mobile: بررسیِ already_spun غیرِاتمیک است و
	// درخواست‌های هم‌زمانِ یک شماره می‌توانند چند بار بچرخند/چند جایزه بگیرند. قفل آن را می‌بندد.
	$spin_lock = 'farazsms_spin_lock_' . md5( $mobile );
	if ( get_transient( $spin_lock ) ) {
		wp_send_json_error( array( 'message' => 'لطفاً چند لحظه صبر کنید…' ) );
	}
	set_transient( $spin_lock, '1', 15 );
	if ( $s['one_per_mobile'] === '1' && farazsms_spin_already_spun( $mobile ) ) {
		wp_send_json_error( array( 'message' => 'با این شماره قبلاً شرکت کرده‌اید.' ) );
	}
	if ( $s['require_otp'] === '1' ) {
		$code  = isset( $_POST['code'] ) ? preg_replace( '/\D/', '', wp_unslash( $_POST['code'] ) ) : '';
		$saved = get_transient( 'farazsms_spin_otp_' . md5( $mobile ) );
		if ( ! $saved || ! hash_equals( (string) $saved, (string) $code ) ) {
			wp_send_json_error( array( 'message' => 'کدِ تأیید نادرست است.' ) );
		}
	}

	// انتخابِ وزن‌دارِ تکه‌ی برنده — سمتِ سرور.
	$slices = array_values( $s['slices'] );
	$total  = 0;
	foreach ( $slices as $sl ) {
		$total += max( 0, (int) $sl['weight'] );
	}
	if ( $total <= 0 ) {
		wp_send_json_error( array( 'message' => 'جوایز تنظیم نشده‌اند.' ) );
	}
	$rand = wp_rand( 1, $total );
	$acc  = 0;
	$idx  = 0;
	foreach ( $slices as $i => $sl ) {
		$acc += max( 0, (int) $sl['weight'] );
		if ( $rand <= $acc ) {
			$idx = $i;
			break;
		}
	}
	$prize = $slices[ $idx ];
	$won   = $prize['type'] !== 'none';

	// جایزه‌ی «کوپن» باید یک کوپنِ واقعیِ ووکامرس بسازد؛ وگرنه هنگام اعمال در پرداخت
	// «کد تخفیف وجود ندارد» می‌گیرد (قبلاً value فقط یک رشته‌ی ثابتِ بی‌پشتوانه بود).
	// کدِ نمایش‌داده/پیامک‌شده = همان کدِ واقعیِ ساخته‌شده.
	$coupon_code = (string) $prize['value'];
	if ( $won && $prize['type'] === 'coupon' ) {
		$generated = farazsms_spin_create_coupon( $prize, (int) $s['coupon_expiry_days'] );
		if ( $generated !== '' ) {
			$coupon_code = $generated;
		}
	}

	global $wpdb;
	$wpdb->insert( farazsms_spin_table(), array(
		'mobile'      => $mobile,
		'prize_label' => (string) $prize['label'],
		'prize_type'  => (string) $prize['type'],
		'prize_value' => (string) $coupon_code,
		'won'         => $won ? 1 : 0,
		'ip'          => farazsms_spin_client_ip(),
		'created_at'  => current_time( 'mysql' ),
	) );

	// حذفِ کدِ مصرف‌شده.
	delete_transient( 'farazsms_spin_otp_' . md5( $mobile ) );

	// پیامکِ نتیجه (فقط برنده‌ها) — تبلیغاتی است، پس با خطِ PRO ارسال می‌شود (نه خطِ خدماتی).
	if ( $won && trim( (string) $s['win_pattern'] ) !== '' ) {
		$prize_text = (string) $prize['label'] . ( $coupon_code !== '' ? ' (' . $coupon_code . ')' : '' );
		// پاسخِ AJAX چرخشِ گردونه را نشان می‌دهد؛ پیامکِ جایزه اثرِ جانبی است.
		// (پیامکِ کدِ تأیید در همین فایل عمداً همگام می‌ماند — کاربر منتظرِ خودِ کد است.)
		// خطِ تبلیغاتی از فهرستِ کانال‌های تبلیغاتیِ صف می‌آید.
		farazsms_queue_send( 'spin-wheel', $mobile, trim( (string) $s['win_pattern'] ), array( 'prize' => $prize_text ), array( 'event' => 'win' ) );
	}

	wp_send_json_success( array(
		'index' => (int) $idx,
		'won'   => $won,
		'label' => (string) $prize['label'],
		'type'  => (string) $prize['type'],
		'value' => (string) $coupon_code,
	) );
}

/**
 * ساختِ کوپنِ واقعیِ ووکامرس برای جایزه‌ی برنده و برگرداندنِ کدِ یکتای آن.
 *
 * نوع و مبلغِ تخفیف از کلیدهای اختیاریِ اسلایس (discount_type / amount) خوانده می‌شود؛
 * در نبودِ آن‌ها از برچسب/مقدار استنتاج می‌گردد (٪ → درصدی، «ارسال رایگان»/FREESHIP → ارسالِ رایگان).
 * هر برنده کدِ یکتا با usage_limit=1 و انقضا می‌گیرد. اگر ووکامرس فعال نباشد رشته‌ی خالی برمی‌گردد.
 *
 * @param array $prize        اسلایسِ برنده.
 * @param int   $expiry_days  انقضا به روز (0 = بدونِ انقضا).
 * @return string کدِ کوپنِ ساخته‌شده یا '' در صورتِ ناتوانی.
 */
function farazsms_spin_create_coupon( $prize, $expiry_days = 7 ) {
	if ( ! class_exists( 'WC_Coupon' ) ) {
		return '';
	}

	$label = (string) ( $prize['label'] ?? '' );
	$value = (string) ( $prize['value'] ?? '' );

	// تبدیلِ ارقامِ فارسی/عربی به لاتین برای استخراجِ عدد.
	$fa = array( '۰','۱','۲','۳','۴','۵','۶','۷','۸','۹','٠','١','٢','٣','٤','٥','٦','٧','٨','٩' );
	$en = array( '0','1','2','3','4','5','6','7','8','9','0','1','2','3','4','5','6','7','8','9' );
	$label_en = str_replace( $fa, $en, $label );
	$value_en = str_replace( $fa, $en, $value );

	// نوع و مبلغِ تخفیف.
	$discount_type = isset( $prize['discount_type'] ) ? sanitize_key( $prize['discount_type'] ) : '';
	$amount        = isset( $prize['amount'] ) && $prize['amount'] !== '' ? (float) $prize['amount'] : 0.0;
	$free_shipping = false;

	// «ارسالِ رایگان» در ووکامرس نوعِ تخفیف نیست بلکه یک پرچم است؛ به fixed_cart با مبلغِ ۰ + پرچم نگاشت می‌شود.
	if ( $discount_type === 'free_shipping' ) {
		$discount_type = 'fixed_cart';
		$amount        = 0.0;
		$free_shipping = true;
	}

	if ( $discount_type === '' ) {
		// استنتاج از متن.
		$is_freeship = ( stripos( $value_en, 'free' ) !== false || stripos( $value_en, 'ship' ) !== false
			|| mb_strpos( $label, 'رایگان' ) !== false || mb_strpos( $label, 'ارسال' ) !== false );
		if ( $is_freeship ) {
			$discount_type = 'fixed_cart';
			$amount        = 0.0;
			$free_shipping = true;
		} elseif ( strpos( $label_en, '%' ) !== false || strpos( $label, '٪' ) !== false
			|| strpos( $value_en, '%' ) !== false || strpos( $value_en, '٪' ) !== false ) {
			$discount_type = 'percent';
			if ( preg_match( '/(\d+(?:\.\d+)?)/', $label_en . ' ' . $value_en, $mm ) ) {
				$amount = (float) $mm[1];
			}
		} else {
			// عددِ داخلِ label/value را مبلغِ ثابت فرض کن (مثلاً OFF10 → ۱۰٪ رایج‌تر است، پس درصدی).
			if ( preg_match( '/(\d+(?:\.\d+)?)/', $value_en . ' ' . $label_en, $mm ) ) {
				$amount        = (float) $mm[1];
				$discount_type = 'percent';
			} else {
				$discount_type = 'fixed_cart';
			}
		}
	}

	// کدِ یکتا: پیشوندِ خوانا + عددِ تصادفی، تا زمانی که تکراری نباشد.
	$base = $value_en !== '' ? preg_replace( '/[^A-Za-z0-9\-]/', '', $value_en ) : 'SPIN';
	if ( $base === '' ) {
		$base = 'SPIN';
	}
	$code = '';
	for ( $try = 0; $try < 8; $try++ ) {
		$candidate = strtoupper( $base ) . '-' . wp_rand( 10000, 99999 );
		if ( ! wc_get_coupon_id_by_code( $candidate ) ) {
			$code = $candidate;
			break;
		}
	}
	if ( $code === '' ) {
		return '';
	}

	try {
		$coupon = new WC_Coupon();
		$coupon->set_code( $code );
		$coupon->set_discount_type( $discount_type );
		$coupon->set_amount( $amount );
		$coupon->set_individual_use( true );
		$coupon->set_usage_limit( 1 );
		if ( $free_shipping ) {
			$coupon->set_free_shipping( true );
		}
		if ( (int) $expiry_days > 0 ) {
			$coupon->set_date_expires( time() + ( (int) $expiry_days * DAY_IN_SECONDS ) );
		}
		$coupon->add_meta_data( '_farazsms_spin_prize', $label, true );
		$coupon->save();
	} catch ( Exception $e ) {
		return '';
	}

	return $coupon->get_code();
}

/* ───────────────────────────── کمکی‌ها ───────────────────────────── */

function farazsms_spin_normalize_mobile( $raw ) {
	$m = farazsms_normalize_phone( (string) $raw );
	return preg_match( '/^09\d{9}$/', (string) $m ) ? $m : '';
}

function farazsms_spin_already_spun( $mobile ) {
	global $wpdb;
	$table = farazsms_spin_table();
	return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE mobile = %s", $mobile ) ) > 0;
}

function farazsms_spin_client_ip() {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
	return substr( sanitize_text_field( $ip ), 0, 45 );
}

/* ═════════════════════════════ پنلِ مدیریت ═════════════════════════════ */

add_action( 'admin_menu', 'farazsms_spin_register_menu', 30 );
function farazsms_spin_register_menu() {
	add_submenu_page(
		'farazsms',
		__( 'گردونه شانس', 'farazsms' ),
		__( '🎡 گردونه شانس', 'farazsms' ),
		'manage_options',
		'farazsms-spin',
		'farazsms_spin_render_admin_page'
	);
}

function farazsms_spin_render_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی غیرمجاز.' );
	}
	farazsms_spin_maybe_setup_table();
	$s   = farazsms_spin_settings();
	$tab = isset( $_GET['st'] ) ? sanitize_key( $_GET['st'] ) : 'general';
	if ( ! in_array( $tab, array( 'general', 'prizes', 'sms', 'participants' ), true ) ) {
		$tab = 'general';
	}
	$nonce    = wp_create_nonce( 'farazsms_spin_admin' );
	$tabs     = array(
		'general'      => '⚙️ تنظیمات و نمایش',
		'prizes'       => '🎁 جوایز (تکه‌ها)',
		'sms'          => '✉️ پیامک',
		'participants' => '👥 شرکت‌کنندگان',
	);
	$tab_style = 'display:inline-flex; align-items:center; gap:6px; padding:11px 20px; font-size:13.5px; text-decoration:none; margin-bottom:-2px; border-bottom:3px solid transparent;';
	?>
	<div class="wrap" style="direction:rtl; font-family:inherit; max-width:1100px;">
		<h1 style="font-size:21px; margin:14px 0 6px;">🎡 گردونه شانس</h1>
		<p style="margin:0 0 14px; color:#64748b; font-size:13px;">با گیمیفیکیشن، شماره‌ی موبایلِ بازدیدکنندگان را بگیرید و آن‌ها را به مشتری تبدیل کنید.</p>

		<div style="display:flex; gap:6px; border-bottom:2px solid #e5e7eb; margin-bottom:20px; flex-wrap:wrap;">
			<?php foreach ( $tabs as $k => $label ) :
				$url = add_query_arg( array( 'page' => 'farazsms-spin', 'st' => $k ), admin_url( 'admin.php' ) );
				$on  = $tab === $k;
			?>
				<a href="<?php echo esc_url( $url ); ?>" style="<?php echo $tab_style; ?> font-weight:<?php echo $on ? '700' : '500'; ?>; color:<?php echo $on ? '#365891' : '#64748b'; ?>; border-bottom-color:<?php echo $on ? '#365891' : 'transparent'; ?>;"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</div>

		<div id="farazsms-spin-admin" data-nonce="<?php echo esc_attr( $nonce ); ?>" data-ajax="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>">
			<?php
			if ( $tab === 'prizes' ) {
				farazsms_spin_render_prizes_tab( $s );
			} elseif ( $tab === 'sms' ) {
				farazsms_spin_render_sms_tab( $s );
			} elseif ( $tab === 'participants' ) {
				farazsms_spin_render_participants_tab();
			} else {
				farazsms_spin_render_general_tab( $s );
			}
			?>
		</div>
	</div>
	<?php
}

/** کارتِ یک‌دستِ تنظیمات. */
function farazsms_spin_card_open( $title = '' ) {
	echo '<div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:18px 20px; margin-bottom:16px;">';
	if ( $title !== '' ) {
		echo '<h3 style="margin:0 0 12px; font-size:15px; color:#0f172a;">' . esc_html( $title ) . '</h3>';
	}
}
function farazsms_spin_card_close() {
	echo '</div>';
}
function farazsms_spin_field_row( $label, $html, $hint = '' ) {
	echo '<div style="margin-bottom:14px;"><label style="display:block; font-size:13px; font-weight:600; color:#334155; margin-bottom:6px;">' . esc_html( $label ) . '</label>' . $html;
	if ( $hint !== '' ) {
		echo '<p style="margin:4px 0 0; font-size:11.5px; color:#64748b;">' . esc_html( $hint ) . '</p>';
	}
	echo '</div>';
}
function farazsms_spin_input( $id, $val, $type = 'text', $extra = '' ) {
	return '<input type="' . esc_attr( $type ) . '" id="' . esc_attr( $id ) . '" value="' . esc_attr( $val ) . '" ' . $extra . ' style="width:100%; max-width:420px; padding:9px 12px; border:1px solid #cbd5e1; border-radius:8px; font-size:13px; box-sizing:border-box;">';
}

/** انتخابگرِ چندتاییِ برگه‌ها با عنوان (به‌جای واردکردنِ دستیِ شناسه). id=sp-display_pages */
function farazsms_spin_pages_multiselect( $selected_csv ) {
	$selected = array_filter( array_map( 'absint', explode( ',', (string) $selected_csv ) ) );
	$pages    = function_exists( 'get_pages' )
		? get_pages( array( 'sort_column' => 'menu_order,post_title', 'post_status' => 'publish' ) )
		: array();
	$html = '<select id="sp-display_pages" multiple size="8" style="width:100%; max-width:420px; padding:6px; border:1px solid #cbd5e1; border-radius:8px; font-size:13px; box-sizing:border-box; background:#fff;">';
	if ( empty( $pages ) ) {
		$html .= '<option value="" disabled>برگه‌ای یافت نشد</option>';
	}
	foreach ( $pages as $p ) {
		$sel   = in_array( (int) $p->ID, $selected, true ) ? ' selected' : '';
		$title = $p->post_title !== '' ? $p->post_title : ( '#' . (int) $p->ID );
		$html .= '<option value="' . (int) $p->ID . '"' . $sel . '>' . esc_html( $title ) . '</option>';
	}
	$html .= '</select>';
	return $html;
}
function farazsms_spin_save_button() {
	echo '<button type="button" id="farazsms-spin-save" style="background:#365891; color:#fff; border:none; padding:10px 28px; font-size:14px; font-weight:700; border-radius:10px; cursor:pointer; font-family:inherit;">💾 ذخیره</button> <span id="farazsms-spin-save-status" style="font-size:12.5px; margin-right:10px;"></span>';
}

function farazsms_spin_render_general_tab( $s ) {
	farazsms_spin_card_open( 'وضعیت و متن‌ها' );
	echo '<label style="display:inline-flex; align-items:center; gap:10px; font-size:13.5px; font-weight:700; color:#334155; cursor:pointer; margin-bottom:14px;"><input type="checkbox" class="farazsms-toggle" id="sp-enabled" ' . checked( $s['enabled'], '1', false ) . '> فعال‌سازیِ گردونه</label>';
	// تله‌ی رایج: گردونه «فعال» است ولی «نمایش در» روی «خاموش» مانده → در سایت دیده نمی‌شود.
	// این هشدار همان مشکلِ «فعال کردم ولی نشان داده نمی‌شود» را همین‌جا آشکار می‌کند.
	echo '<div id="sp-off-warning" style="' . ( ( $s['enabled'] === '1' && $s['display_location'] === 'off' ) ? '' : 'display:none;' ) . 'background:#fff7ed; border:1px solid #fed7aa; color:#9a3412; border-radius:8px; padding:10px 14px; font-size:12.5px; line-height:1.9; margin-bottom:14px;">⚠️ گردونه فعال است اما «نمایش در» روی «خاموش» است، پس در سایت نشان داده نمی‌شود. برای نمایش، پایین‌تر «نمایش در» را به «همه‌ی صفحات» یا «برگه‌های خاص» تغییر دهید و ذخیره کنید.</div>';
	farazsms_spin_field_row( 'عنوان', farazsms_spin_input( 'sp-title', $s['title'] ) );
	farazsms_spin_field_row( 'زیرعنوان', farazsms_spin_input( 'sp-subtitle', $s['subtitle'] ) );
	farazsms_spin_field_row( 'متنِ دکمه‌ی چرخش', farazsms_spin_input( 'sp-button_text', $s['button_text'] ) );
	farazsms_spin_field_row( 'برچسبِ فیلدِ موبایل', farazsms_spin_input( 'sp-mobile_label', $s['mobile_label'] ) );
	farazsms_spin_field_row( 'متنِ رضایت (GDPR)', farazsms_spin_input( 'sp-consent_text', $s['consent_text'] ) );
	farazsms_spin_field_row( 'متنِ حالتِ باخت', farazsms_spin_input( 'sp-lose_text', $s['lose_text'] ) );
	farazsms_spin_card_close();

	farazsms_spin_card_open( 'کجا و چگونه نمایش داده شود' );
	$sel_style = 'width:100%; max-width:420px; padding:9px 12px; border:1px solid #cbd5e1; border-radius:8px; font-size:13px; box-sizing:border-box; background:#fff;';

	// ۱) محلِ نمایش.
	$loc = $s['display_location'];
	$loc_html = '<select id="sp-display_location" style="' . $sel_style . '">'
		. '<option value="off" ' . selected( $loc, 'off', false ) . '>خاموش (نمایش داده نشود)</option>'
		. '<option value="everywhere" ' . selected( $loc, 'everywhere', false ) . '>همه‌ی صفحات</option>'
		. '<option value="specific" ' . selected( $loc, 'specific', false ) . '>فقط برگه‌های انتخاب‌شده</option></select>';
	farazsms_spin_field_row( 'در کدام صفحات نمایش داده شود؟', $loc_html, 'برای دیده‌شدنِ گردونه، این گزینه نباید روی «خاموش» بماند.' );

	// ۲) انتخابگرِ برگه‌ها (فقط وقتی «برگه‌های انتخاب‌شده») — لیستِ عنوان‌دار، نه شناسه‌ی دستی.
	echo '<div id="sp-pages-row" style="margin-bottom:14px; ' . ( $loc === 'specific' ? '' : 'display:none;' ) . '">';
	echo '<label style="display:block; font-size:13px; font-weight:600; color:#334155; margin-bottom:6px;">برگه‌ها را انتخاب کنید</label>';
	echo farazsms_spin_pages_multiselect( $s['display_pages'] );
	echo '<p style="margin:4px 0 0; font-size:11.5px; color:#64748b;">با نگه‌داشتنِ Ctrl (یا ⌘ در مک) می‌توانید چند برگه انتخاب کنید. فقط «برگه»های وردپرس این‌جا هستند (نه محصول/نوشته).</p>';
	// هشدار: «برگه‌های انتخاب‌شده» فعال ولی هیچ برگه‌ای انتخاب نشده → گردونه جایی دیده نمی‌شود.
	$nopages = ( $s['enabled'] === '1' && $loc === 'specific' && trim( (string) $s['display_pages'] ) === '' );
	echo '<div id="sp-nopages-warning" style="' . ( $nopages ? '' : 'display:none;' ) . 'background:#fff7ed; border:1px solid #fed7aa; color:#9a3412; border-radius:8px; padding:10px 14px; font-size:12.5px; line-height:1.9; margin-top:10px;">⚠️ حالتِ «فقط برگه‌های انتخاب‌شده» فعال است اما هیچ برگه‌ای انتخاب نشده — پس گردونه جایی نمایش داده نمی‌شود. یک برگه انتخاب کنید یا «همه‌ی صفحات» را بزنید.</div>';
	echo '</div>';

	// ۳) چگونه باز شود.
	$trg = $s['trigger'];
	$trg_html = '<select id="sp-trigger" style="' . $sel_style . '">'
		. '<option value="load" ' . selected( $trg, 'load', false ) . '>خودکار (پس از چند ثانیه پاپ‌آپ شود)</option>'
		. '<option value="click" ' . selected( $trg, 'click', false ) . '>فقط با کلیک روی یک دکمه/لینک</option></select>';
	farazsms_spin_field_row( 'چگونه باز شود؟', $trg_html );

	// ۴) دفعاتِ نمایش (فقط برای پاپ‌آپ خودکار) — جایگزینِ رفتارِ گیج‌کننده‌ی «یک‌بار و تمام».
	$freq = $s['display_frequency'];
	$freq_html = '<select id="sp-display_frequency" style="' . $sel_style . '">'
		. '<option value="always" ' . selected( $freq, 'always', false ) . '>هر بار که صفحه باز می‌شود</option>'
		. '<option value="session" ' . selected( $freq, 'session', false ) . '>یک‌بار در هر بازدید (تا بستنِ مرورگر)</option>'
		. '<option value="daily" ' . selected( $freq, 'daily', false ) . '>یک‌بار در هر روز</option>'
		. '<option value="once" ' . selected( $freq, 'once', false ) . '>فقط یک‌بار برای همیشه</option></select>';
	echo '<div id="sp-freq-row" style="margin-bottom:14px; ' . ( $trg === 'load' ? '' : 'display:none;' ) . '">';
	echo '<label style="display:block; font-size:13px; font-weight:600; color:#334155; margin-bottom:6px;">هر چند وقت یک‌بار به هر بازدیدکننده نشان داده شود؟</label>';
	echo $freq_html;
	echo '<p style="margin:4px 0 0; font-size:11.5px; color:#64748b;">💡 برای تست، «هر بار که صفحه باز می‌شود» را انتخاب کنید تا در هر رفرش ببینید. برای بازدیدکننده‌ی واقعی، «یک‌بار در هر بازدید» یا «یک‌بار در روز» پیشنهاد می‌شود تا مزاحم نباشد.</p>';
	echo '</div>';

	// ۵) تأخیرِ پاپ‌آپ (فقط load).
	echo '<div id="sp-delay-row" style="margin-bottom:14px; ' . ( $trg === 'load' ? '' : 'display:none;' ) . '">';
	echo '<label style="display:block; font-size:13px; font-weight:600; color:#334155; margin-bottom:6px;">چند ثانیه بعد از بازشدنِ صفحه پاپ‌آپ شود؟</label>';
	echo farazsms_spin_input( 'sp-trigger_delay', $s['trigger_delay'], 'number' );
	echo '</div>';

	// ۶) سلکتورِ کلیک (فقط click).
	echo '<div id="sp-selector-row" style="margin-bottom:4px; ' . ( $trg === 'click' ? '' : 'display:none;' ) . '">';
	echo '<label style="display:block; font-size:13px; font-weight:600; color:#334155; margin-bottom:6px;">دکمه/لینکِ بازکننده</label>';
	echo farazsms_spin_input( 'sp-trigger_selector', $s['trigger_selector'] );
	echo '<p style="margin:4px 0 0; font-size:11.5px; color:#64748b;">هر المانی با این کلاس/سلکتورِ CSS — یا شورت‌کدِ <code>[spin_wheel_button]</code> — گردونه را باز می‌کند. پیش‌فرض: <code>.spin-wheel-open</code></p>';
	echo '</div>';
	farazsms_spin_card_close();

	farazsms_spin_card_open( 'احراز هویت' );
	echo '<label style="display:inline-flex; align-items:center; gap:10px; font-size:13px; cursor:pointer; margin-bottom:8px;"><input type="checkbox" class="farazsms-toggle" id="sp-require_otp" ' . checked( $s['require_otp'], '1', false ) . '> الزامِ تأییدِ موبایل با کدِ پیامکی (OTP)</label><br>';
	echo '<label style="display:inline-flex; align-items:center; gap:10px; font-size:13px; cursor:pointer;"><input type="checkbox" class="farazsms-toggle" id="sp-one_per_mobile" ' . checked( $s['one_per_mobile'], '1', false ) . '> هر شماره فقط یک‌بار بتواند بچرخاند</label>';
	farazsms_spin_card_close();

	farazsms_spin_save_button();
	farazsms_spin_admin_js();
}

function farazsms_spin_render_prizes_tab( $s ) {
	farazsms_spin_card_open( 'تکه‌های گردونه و شانسِ برد' );
	echo '<p style="margin:0 0 12px; font-size:12px; color:#64748b; line-height:1.9;">«شانس» وزنِ نسبیِ هر تکه است (هرچه بیشتر، احتمالِ بردِ بیشتر). تعیینِ برنده سمتِ سرور و ضدِتقلب است. نوعِ «پوچ» یعنی بازنده.</p>';
	echo '<div id="farazsms-spin-slices">';
	foreach ( array_values( $s['slices'] ) as $i => $sl ) {
		echo farazsms_spin_slice_row( $sl );
	}
	echo '</div>';
	echo '<button type="button" id="farazsms-spin-add-slice" style="margin-top:8px; background:#e0f2fe; color:#0369a1; border:1px solid #bae6fd; padding:8px 16px; border-radius:8px; font-size:13px; font-weight:600; cursor:pointer;">+ افزودنِ تکه</button>';
	farazsms_spin_card_close();
	farazsms_spin_save_button();
	farazsms_spin_admin_js();
}

/** یک ردیفِ تکه (برای رندرِ اولیه و کلونِ JS). */
function farazsms_spin_slice_row( $sl = array() ) {
	$label  = isset( $sl['label'] ) ? $sl['label'] : '';
	$type   = isset( $sl['type'] ) ? $sl['type'] : 'none';
	$value  = isset( $sl['value'] ) ? $sl['value'] : '';
	$weight = isset( $sl['weight'] ) ? (int) $sl['weight'] : 10;
	$color  = isset( $sl['color'] ) ? $sl['color'] : '#64748b';
	$dtype  = isset( $sl['discount_type'] ) ? $sl['discount_type'] : '';
	$amount = isset( $sl['amount'] ) && $sl['amount'] !== '' ? $sl['amount'] : '';
	ob_start();
	?>
	<div class="farazsms-spin-slice" style="display:flex; gap:8px; align-items:center; flex-wrap:wrap; padding:8px; border:1px solid #e2e8f0; border-radius:8px; margin-bottom:8px; background:#fff;">
		<input type="text" class="sp-s-label" value="<?php echo esc_attr( $label ); ?>" placeholder="عنوان جایزه" style="flex:1 1 140px; min-width:120px; padding:7px 10px; border:1px solid #cbd5e1; border-radius:6px; font-size:12.5px;">
		<select class="sp-s-type" style="padding:7px 8px; border:1px solid #cbd5e1; border-radius:6px; font-size:12.5px;">
			<option value="none" <?php selected( $type, 'none' ); ?>>پوچ</option>
			<option value="coupon" <?php selected( $type, 'coupon' ); ?>>کد تخفیف</option>
			<option value="link" <?php selected( $type, 'link' ); ?>>لینک</option>
		</select>
		<input type="text" class="sp-s-value" value="<?php echo esc_attr( $value ); ?>" placeholder="کد/لینک (اختیاری)" style="flex:1 1 110px; min-width:90px; padding:7px 10px; border:1px solid #cbd5e1; border-radius:6px; font-size:12.5px; direction:ltr; text-align:left;">
		<select class="sp-s-dtype" title="نوعِ تخفیفِ کوپن" style="padding:7px 8px; border:1px solid #cbd5e1; border-radius:6px; font-size:12.5px;">
			<option value="" <?php selected( $dtype, '' ); ?>>تخفیف: خودکار</option>
			<option value="percent" <?php selected( $dtype, 'percent' ); ?>>درصدی</option>
			<option value="fixed_cart" <?php selected( $dtype, 'fixed_cart' ); ?>>مبلغِ ثابت</option>
			<option value="free_shipping" <?php selected( $dtype, 'free_shipping' ); ?>>ارسالِ رایگان</option>
		</select>
		<input type="number" class="sp-s-amount" value="<?php echo esc_attr( $amount ); ?>" min="0" step="0.01" placeholder="مبلغ" title="مبلغِ تخفیف (درصد یا تومان)" style="width:80px; padding:7px 10px; border:1px solid #cbd5e1; border-radius:6px; font-size:12.5px;">
		<input type="number" class="sp-s-weight" value="<?php echo esc_attr( $weight ); ?>" min="0" title="شانس (وزن)" style="width:70px; padding:7px 10px; border:1px solid #cbd5e1; border-radius:6px; font-size:12.5px;">
		<input type="color" class="sp-s-color" value="<?php echo esc_attr( $color ); ?>" title="رنگ" style="width:42px; height:34px; border:1px solid #cbd5e1; border-radius:6px; padding:2px; cursor:pointer;">
		<button type="button" class="sp-s-del" title="حذف" style="background:#fee2e2; color:#b91c1c; border:none; width:32px; height:32px; border-radius:6px; cursor:pointer; font-size:15px;">×</button>
	</div>
	<?php
	return ob_get_clean();
}

function farazsms_spin_render_sms_tab( $s ) {
	farazsms_spin_card_open( 'پترنِ کدِ تأیید (OTP)' );
	echo '<p style="margin:0 0 8px; font-size:12px; color:#64748b;">متغیر: <code dir="ltr">%code%</code> — دسته‌بندیِ این پترن «احراز هویت» (OTP) است.</p>';
	farazsms_spin_field_row( 'کد پترن', farazsms_spin_input( 'sp-otp_pattern', $s['otp_pattern'], 'text', 'dir="ltr"' ) );
	echo '<textarea id="sp-otp_message" rows="3" style="width:100%; padding:10px; border:1px solid #cbd5e1; border-radius:8px; font-size:13px; font-family:inherit; direction:rtl; box-sizing:border-box;">' . esc_textarea( $s['otp_message'] ) . '</textarea>';
	echo '<div style="margin-top:8px;"><button type="button" class="farazsms-spin-build" data-kind="otp" style="background:#16a34a; color:#fff; border:none; padding:8px 16px; border-radius:8px; font-size:13px; font-weight:700; cursor:pointer;">⚡ ساخت/به‌روزرسانیِ پترنِ OTP</button> <span class="farazsms-spin-build-status" data-kind="otp" style="font-size:12px; color:#64748b;"></span></div>';
	farazsms_spin_card_close();

	farazsms_spin_card_open( 'پترنِ پیامکِ برنده' );
	echo '<p style="margin:0 0 8px; font-size:12px; color:#64748b;">متغیر: <code dir="ltr">%prize%</code> — به برنده‌ها ارسال می‌شود.</p>';
	farazsms_spin_field_row( 'کد پترن', farazsms_spin_input( 'sp-win_pattern', $s['win_pattern'], 'text', 'dir="ltr"' ) );
	echo '<textarea id="sp-win_message" rows="3" style="width:100%; padding:10px; border:1px solid #cbd5e1; border-radius:8px; font-size:13px; font-family:inherit; direction:rtl; box-sizing:border-box;">' . esc_textarea( $s['win_message'] ) . '</textarea>';
	echo '<div style="margin-top:8px;"><button type="button" class="farazsms-spin-build" data-kind="win" style="background:#16a34a; color:#fff; border:none; padding:8px 16px; border-radius:8px; font-size:13px; font-weight:700; cursor:pointer;">⚡ ساخت/به‌روزرسانیِ پترنِ برنده</button> <span class="farazsms-spin-build-status" data-kind="win" style="font-size:12px; color:#64748b;"></span></div>';
	farazsms_spin_card_close();

	farazsms_spin_save_button();
	farazsms_spin_admin_js();
}

function farazsms_spin_render_participants_tab() {
	global $wpdb;
	$table = farazsms_spin_table();
	$rows  = $wpdb->get_results( "SELECT * FROM $table ORDER BY id DESC LIMIT 1000", ARRAY_A );
	$csv   = wp_nonce_url( add_query_arg( array( 'page' => 'farazsms-spin', 'st' => 'participants', 'farazsms_spin_csv' => '1' ), admin_url( 'admin.php' ) ), 'farazsms_spin_csv' );
	?>
	<div style="display:flex; gap:10px; align-items:center; justify-content:space-between; flex-wrap:wrap; margin-bottom:12px;">
		<div style="font-size:13px; color:#475569;">مجموعِ شرکت‌کنندگان (۱۰۰۰ موردِ اخیر): <strong><?php echo count( (array) $rows ); ?></strong></div>
		<div style="display:flex; gap:8px; flex-wrap:wrap;">
			<a href="<?php echo esc_url( $csv ); ?>" style="background:#365891; color:#fff; padding:8px 16px; border-radius:8px; text-decoration:none; font-size:12.5px;">⬇️ خروجی CSV</a>
			<button type="button" id="farazsms-spin-bulk" style="background:#7c3aed; color:#fff; border:none; padding:8px 16px; border-radius:8px; font-size:12.5px; font-weight:600; cursor:pointer;">✉️ ارسالِ پیامکِ گروهی به همه</button>
		</div>
	</div>
	<div id="farazsms-spin-bulk-box" style="display:none; background:#faf5ff; border:1px solid #e9d5ff; border-radius:10px; padding:14px; margin-bottom:14px;">
		<p style="margin:0 0 8px; font-size:12px; color:#6b21a8;">پیامکِ ساده به همه‌ی شرکت‌کنندگان (پترن لازم نیست؛ ارسالِ معمولی). آدرسِ سایت خودکار افزوده می‌شود.</p>
		<textarea id="farazsms-spin-bulk-msg" rows="3" placeholder="متنِ پیامک…" style="width:100%; padding:10px; border:1px solid #cbd5e1; border-radius:8px; font-size:13px; font-family:inherit; direction:rtl; box-sizing:border-box;"></textarea>
		<div style="margin-top:8px;"><button type="button" id="farazsms-spin-bulk-send" style="background:#7c3aed; color:#fff; border:none; padding:8px 18px; border-radius:8px; font-size:13px; font-weight:700; cursor:pointer;">ارسال</button> <span id="farazsms-spin-bulk-status" style="font-size:12px; color:#64748b;"></span></div>
	</div>
	<div style="overflow-x:auto; background:#fff; border:1px solid #e5e7eb; border-radius:12px;">
		<table style="width:100%; border-collapse:collapse; font-size:12.5px; min-width:620px;">
			<thead><tr style="background:#f8fafc; text-align:right;">
				<th style="padding:10px 12px; color:#475569;">موبایل</th>
				<th style="padding:10px 12px; color:#475569;">جایزه</th>
				<th style="padding:10px 12px; color:#475569;">نوع</th>
				<th style="padding:10px 12px; color:#475569;">برنده؟</th>
				<th style="padding:10px 12px; color:#475569;">تاریخ</th>
			</tr></thead>
			<tbody>
			<?php if ( empty( $rows ) ) : ?>
				<tr><td colspan="5" style="padding:22px; text-align:center; color:#94a3b8;">هنوز شرکت‌کننده‌ای ثبت نشده.</td></tr>
			<?php else : foreach ( $rows as $r ) :
				$jdate = farazsms_send_reports_to_jalali( $r['created_at'] );
			?>
				<tr style="border-top:1px solid #f1f5f9;">
					<td style="padding:9px 12px; direction:ltr; text-align:right; font-family:Menlo,monospace;"><?php echo esc_html( $r['mobile'] ); ?></td>
					<td style="padding:9px 12px;"><?php echo esc_html( $r['prize_label'] ); ?><?php echo $r['prize_value'] !== '' ? ' <span style="color:#64748b; direction:ltr;">(' . esc_html( $r['prize_value'] ) . ')</span>' : ''; ?></td>
					<td style="padding:9px 12px; color:#64748b;"><?php echo esc_html( $r['prize_type'] ); ?></td>
					<td style="padding:9px 12px;"><?php echo $r['won'] ? '<span style="color:#16a34a; font-weight:700;">✓</span>' : '<span style="color:#94a3b8;">—</span>'; ?></td>
					<td style="padding:9px 12px; color:#64748b; font-size:11.5px;"><?php echo esc_html( $jdate ); ?></td>
				</tr>
			<?php endforeach; endif; ?>
			</tbody>
		</table>
	</div>
	<?php
	farazsms_spin_admin_js();
}

/** JSِ مشترکِ پنل (ذخیره، تکه‌ها، ساختِ پترن، ارسالِ گروهی). یک‌بار چاپ می‌شود. */
function farazsms_spin_admin_js() {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done    = true;
	$row_tpl = farazsms_spin_slice_row();
	?>
	<script>
	(function(){
		var box = document.getElementById('farazsms-spin-admin');
		if (!box) return;
		var nonce = box.getAttribute('data-nonce'), ajax = box.getAttribute('data-ajax');
		function val(id){ var e=document.getElementById(id); return e ? (e.type==='checkbox' ? (e.checked?'1':'0') : e.value) : null; }
		function post(data, cb){ var fd=new FormData(); fd.append('nonce', nonce); for(var k in data){ if(Array.isArray(data[k])){ data[k].forEach(function(v){ fd.append(k+'[]', v); }); } else { fd.append(k, data[k]); } } fetch(ajax,{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json();}).then(cb).catch(function(){ cb({success:false,data:{message:'خطای ارتباط'}}); }); }

		// هشدارِ زنده: «فعال ولی نمایش=خاموش» → گردونه دیده نمی‌شود.
		function syncOffWarning(){
			var en=val('sp-enabled'), loc=val('sp-display_location');
			var w=document.getElementById('sp-off-warning');
			if(w){ w.style.display = (en==='1' && loc==='off') ? '' : 'none'; }
			var w2=document.getElementById('sp-nopages-warning');
			if(w2){ var pg=document.getElementById('sp-display_pages'); var n=pg?(pg.selectedOptions||[]).length:0; w2.style.display = (en==='1' && loc==='specific' && n===0) ? '' : 'none'; }
		}
		// نمایشِ زمینه‌ای: فقط فیلدهای مرتبط با انتخابِ فعلی دیده شوند (رابطِ شسته‌رفته).
		function toggleRow(id, on){ var e=document.getElementById(id); if(e){ e.style.display = on ? '' : 'none'; } }
		function syncDisplayRows(){
			var loc=val('sp-display_location'), trg=val('sp-trigger');
			toggleRow('sp-pages-row', loc==='specific');
			toggleRow('sp-freq-row', trg==='load');
			toggleRow('sp-delay-row', trg==='load');
			toggleRow('sp-selector-row', trg==='click');
		}
		['sp-enabled','sp-display_location','sp-display_pages'].forEach(function(id){ var e=document.getElementById(id); if(e){ e.addEventListener('change', syncOffWarning); } });
		['sp-display_location','sp-trigger'].forEach(function(id){ var e=document.getElementById(id); if(e){ e.addEventListener('change', syncDisplayRows); } });
		syncOffWarning(); syncDisplayRows();

		// تکه‌ها
		var slicesWrap = document.getElementById('farazsms-spin-slices');
		var addBtn = document.getElementById('farazsms-spin-add-slice');
		if (addBtn) addBtn.addEventListener('click', function(){ var d=document.createElement('div'); d.innerHTML=<?php echo wp_json_encode( $row_tpl ); ?>; slicesWrap.appendChild(d.firstElementChild||d.children[0]); });
		document.addEventListener('click', function(e){ if (e.target && e.target.classList && e.target.classList.contains('sp-s-del')) { var row=e.target.closest('.farazsms-spin-slice'); if(row) row.remove(); } });
		function collectSlices(){ var out=[]; document.querySelectorAll('#farazsms-spin-slices .farazsms-spin-slice').forEach(function(r){ out.push(JSON.stringify({ label:r.querySelector('.sp-s-label').value, type:r.querySelector('.sp-s-type').value, value:r.querySelector('.sp-s-value').value, discount_type:(r.querySelector('.sp-s-dtype')||{}).value||'', amount:(r.querySelector('.sp-s-amount')||{}).value||'', weight:r.querySelector('.sp-s-weight').value, color:r.querySelector('.sp-s-color').value })); }); return out; }

		// ذخیره
		var saveBtn = document.getElementById('farazsms-spin-save');
		if (saveBtn) saveBtn.addEventListener('click', function(){
			var st=document.getElementById('farazsms-spin-save-status'); saveBtn.disabled=true; saveBtn.style.opacity='.6'; st.textContent='در حال ذخیره…'; st.style.color='#64748b';
			var data={ action:'farazsms_spin_save' };
			['enabled','title','subtitle','button_text','mobile_label','consent_text','lose_text','display_location','display_frequency','trigger','trigger_delay','trigger_selector','require_otp','one_per_mobile','otp_pattern','otp_message','win_pattern','win_message'].forEach(function(k){ var v=val('sp-'+k); if(v!==null) data[k]=v; });
			// display_pages از multi-select: همه‌ی گزینه‌های انتخاب‌شده را با کاما بفرست.
			var pgSel=document.getElementById('sp-display_pages');
			if (pgSel) data.display_pages = Array.prototype.slice.call(pgSel.selectedOptions||[]).map(function(o){return o.value;}).filter(Boolean).join(',');
			if (document.getElementById('farazsms-spin-slices')) data.slices = collectSlices();
			post(data, function(res){ saveBtn.disabled=false; saveBtn.style.opacity='1'; if(res&&res.success){ st.textContent='✓ ذخیره شد'; st.style.color='#16a34a'; } else { st.textContent='✗ '+((res&&res.data&&res.data.message)||'خطا'); st.style.color='#dc2626'; } });
		});

		// ساختِ پترن
		document.querySelectorAll('.farazsms-spin-build').forEach(function(btn){ btn.addEventListener('click', function(){
			var kind=btn.getAttribute('data-kind'); var st=document.querySelector('.farazsms-spin-build-status[data-kind="'+kind+'"]');
			var msg=val('sp-'+kind+'_message'); btn.disabled=true; btn.style.opacity='.6'; st.textContent='در حال ساخت…'; st.style.color='#64748b';
			post({ action:'farazsms_spin_build_pattern', kind:kind, message:msg }, function(res){ btn.disabled=false; btn.style.opacity='1'; if(res&&res.success&&res.data.pattern_code){ var f=document.getElementById('sp-'+kind+'_pattern'); if(f) f.value=res.data.pattern_code; st.textContent='✓ '+res.data.message; st.style.color='#16a34a'; } else { st.textContent='✗ '+((res&&res.data&&res.data.message)||'خطا'); st.style.color='#dc2626'; } });
		}); });

		// ارسالِ گروهی
		var bulkBtn=document.getElementById('farazsms-spin-bulk');
		if (bulkBtn) bulkBtn.addEventListener('click', function(){ var b=document.getElementById('farazsms-spin-bulk-box'); b.style.display = b.style.display==='none'?'block':'none'; });
		var bulkSend=document.getElementById('farazsms-spin-bulk-send');
		if (bulkSend) bulkSend.addEventListener('click', function(){
			var st=document.getElementById('farazsms-spin-bulk-status'); var msg=document.getElementById('farazsms-spin-bulk-msg').value||'';
			if(msg.trim()===''){ st.textContent='✗ متن خالی است'; st.style.color='#dc2626'; return; }
			if(!confirm('ارسالِ پیامک به همه‌ی شرکت‌کنندگان؟')) return;
			bulkSend.disabled=true; bulkSend.style.opacity='.6'; st.textContent='در حال ارسال…'; st.style.color='#64748b';
			post({ action:'farazsms_spin_bulk_sms', message:msg }, function(res){ bulkSend.disabled=false; bulkSend.style.opacity='1'; if(res&&res.success){ st.textContent='✓ '+res.data.message; st.style.color='#16a34a'; } else { st.textContent='✗ '+((res&&res.data&&res.data.message)||'خطا'); st.style.color='#dc2626'; } });
		});
	})();
	</script>
	<?php
}

/* ───────────────────────────── AJAX (پنل) ───────────────────────────── */

add_action( 'wp_ajax_farazsms_spin_save', 'farazsms_spin_ajax_save' );
function farazsms_spin_ajax_save() {
	check_ajax_referer( 'farazsms_spin_admin', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
	}
	$s = farazsms_spin_settings();
	$text_keys = array( 'title', 'subtitle', 'button_text', 'mobile_label', 'consent_text', 'lose_text', 'display_pages', 'trigger_selector', 'otp_pattern', 'win_pattern' );
	foreach ( $text_keys as $k ) {
		if ( isset( $_POST[ $k ] ) ) {
			$s[ $k ] = sanitize_text_field( wp_unslash( $_POST[ $k ] ) );
		}
	}
	foreach ( array( 'otp_message', 'win_message' ) as $k ) {
		if ( isset( $_POST[ $k ] ) ) {
			$s[ $k ] = farazsms_sanitize_pattern_text( $_POST[ $k ] );
		}
	}
	// v3.22.33: این ۶ فیلد فقط در تبِ «عمومی» رندر می‌شوند. تب‌های «جوایز» و «پیامک» صفحه‌ی
	// جداگانه‌اند و این فیلدها را در POST نمی‌فرستند؛ قبلاً بی‌قید به پیش‌فرض ریست می‌شدند و
	// ذخیره از آن تب‌ها گردونه را خاموش (enabled→0) و مخفی (display→off) می‌کرد. حالا فقط وقتی
	// تبِ عمومی ارسال شده (نشانه: وجودِ display_location در POST) این‌ها را می‌نویسیم.
	if ( isset( $_POST['display_location'] ) ) {
		$s['enabled']        = ( isset( $_POST['enabled'] ) && $_POST['enabled'] === '1' ) ? '1' : '0';
		$s['require_otp']    = ( isset( $_POST['require_otp'] ) && $_POST['require_otp'] === '1' ) ? '1' : '0';
		$s['one_per_mobile'] = ( isset( $_POST['one_per_mobile'] ) && $_POST['one_per_mobile'] === '1' ) ? '1' : '0';
		$loc = sanitize_key( $_POST['display_location'] );
		$s['display_location'] = in_array( $loc, array( 'off', 'everywhere', 'specific' ), true ) ? $loc : 'off';
		// دفعاتِ نمایش (فقط پاپ‌آپ خودکار).
		$freq = isset( $_POST['display_frequency'] ) ? sanitize_key( $_POST['display_frequency'] ) : 'session';
		$s['display_frequency'] = in_array( $freq, array( 'always', 'session', 'daily', 'once' ), true ) ? $freq : 'session';
		// display_pages از multi-select می‌آید؛ به فهرستِ شناسه‌های تمیز نرمال کن.
		$s['display_pages'] = implode( ',', array_filter( array_map( 'absint', explode( ',', (string) $s['display_pages'] ) ) ) );
		$trg = isset( $_POST['trigger'] ) ? sanitize_key( $_POST['trigger'] ) : 'load';
		$s['trigger']       = in_array( $trg, array( 'load', 'click' ), true ) ? $trg : 'load';
		$s['trigger_delay'] = isset( $_POST['trigger_delay'] ) ? (string) max( 0, (int) $_POST['trigger_delay'] ) : '4';
	}

	if ( isset( $_POST['slices'] ) && is_array( $_POST['slices'] ) ) {
		$slices = array();
		foreach ( wp_unslash( $_POST['slices'] ) as $json ) {
			$row = json_decode( (string) $json, true );
			if ( ! is_array( $row ) ) {
				continue;
			}
			$type  = isset( $row['type'] ) ? sanitize_key( $row['type'] ) : 'none';
			$dtype = isset( $row['discount_type'] ) ? sanitize_key( $row['discount_type'] ) : '';
			if ( ! in_array( $dtype, array( 'percent', 'fixed_cart', 'free_shipping' ), true ) ) {
				$dtype = ''; // خالی = استنتاجِ خودکار در ساختِ کوپن.
			}
			$slices[] = array(
				'label'         => isset( $row['label'] ) ? sanitize_text_field( $row['label'] ) : '',
				'type'          => in_array( $type, array( 'none', 'coupon', 'link' ), true ) ? $type : 'none',
				'value'         => isset( $row['value'] ) ? sanitize_text_field( $row['value'] ) : '',
				'discount_type' => $dtype,
				'amount'        => isset( $row['amount'] ) && $row['amount'] !== '' ? (float) $row['amount'] : '',
				'weight'        => isset( $row['weight'] ) ? max( 0, (int) $row['weight'] ) : 0,
				'color'         => isset( $row['color'] ) && preg_match( '/^#[0-9a-fA-F]{3,8}$/', $row['color'] ) ? $row['color'] : '#64748b',
			);
		}
		if ( ! empty( $slices ) ) {
			$s['slices'] = $slices;
		}
	}
	update_option( FARAZSMS_SPIN_OPTION, $s, false );
	wp_send_json_success( array( 'message' => 'ذخیره شد.' ) );
}

add_action( 'wp_ajax_farazsms_spin_build_pattern', 'farazsms_spin_ajax_build_pattern' );
function farazsms_spin_ajax_build_pattern() {
	check_ajax_referer( 'farazsms_spin_admin', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
	}
	$kind    = isset( $_POST['kind'] ) ? sanitize_key( $_POST['kind'] ) : '';
	$message = isset( $_POST['message'] ) ? farazsms_sanitize_pattern_text( $_POST['message'] ) : '';
	if ( ! in_array( $kind, array( 'otp', 'win' ), true ) || trim( $message ) === '' ) {
		wp_send_json_error( array( 'message' => 'ورودیِ نامعتبر.' ) );
	}
	$category = $kind === 'otp' ? 1 : 255; // OTP = 1
	$section  = $kind === 'otp' ? 'otp' : 'security';
	$desc     = farazsms_pattern_brand_description( $section );

	$s        = farazsms_spin_settings();
	$opt_key  = $kind === 'otp' ? 'otp_pattern' : 'win_pattern';
	$existing = trim( (string) $s[ $opt_key ] );
	$did_update = false;
	if ( $existing !== '' ) {
		$resp      = farazsms_update_pattern( $existing, $message, $category, $desc );
		$tmp       = is_string( $resp ) ? json_decode( $resp, true ) : $resp;
		$not_found = is_array( $tmp ) && isset( $tmp['status'] ) && $tmp['status'] !== 'success'
			&& ( ( isset( $tmp['error_code'] ) && $tmp['error_code'] === 'pattern_not_found' )
				|| ( farazsms_is_pattern_not_found_response( $tmp ) ) );
		$did_update = ! $not_found;
		if ( $not_found ) {
			$resp = farazsms_create_pattern( $message, $category, $desc );
		}
	} else {
		$resp = farazsms_create_pattern( $message, $category, $desc );
	}
	$code = farazsms_autobuild_extract_code( $resp );
	if ( $code === '' && $did_update && $existing !== '' ) {
		$code = $existing;
	}
	if ( $code === '' ) {
		$data = is_string( $resp ) ? json_decode( $resp, true ) : $resp;
		$em   = is_array( $data ) && isset( $data['message'] ) ? (string) $data['message'] : 'پاسخِ نامعتبر';
		wp_send_json_error( array( 'message' => $em ) );
	}
	$s[ $opt_key ]              = $code;
	$s[ $kind . '_message' ]    = $message;
	update_option( FARAZSMS_SPIN_OPTION, $s, false );
	wp_send_json_success( array( 'pattern_code' => $code, 'message' => ( $did_update ? 'به‌روزرسانی شد' : 'ساخته شد' ) . ' (' . $code . ') — منتظر تأیید.' ) );
}

add_action( 'wp_ajax_farazsms_spin_bulk_sms', 'farazsms_spin_ajax_bulk_sms' );
function farazsms_spin_ajax_bulk_sms() {
	check_ajax_referer( 'farazsms_spin_admin', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
	}
	$message = isset( $_POST['message'] ) ? farazsms_sanitize_pattern_text( $_POST['message'] ) : '';
	if ( trim( $message ) === '' ) {
		wp_send_json_error( array( 'message' => 'متن خالی است.' ) );
	}
	$apikey = farazsms_get_apikey();
	if ( $apikey === '' ) {
		wp_send_json_error( array( 'message' => 'کلید دسترسی (Api-Key) در تنظیمات وارد نشده است.' ) );
	}
	global $wpdb;
	$table   = farazsms_spin_table();
	$mobiles = $wpdb->get_col( "SELECT DISTINCT mobile FROM $table WHERE mobile <> ''" );
	$mobiles = array_values( array_filter( array_map( 'trim', (array) $mobiles ) ) );
	if ( empty( $mobiles ) ) {
		wp_send_json_error( array( 'message' => 'شماره‌ای برای ارسال نیست.' ) );
	}
	$host = (string) wp_parse_url( get_site_url(), PHP_URL_HOST );
	if ( $host !== '' && stripos( $message, $host ) === false ) {
		$message = rtrim( $message ) . "\n" . get_site_url();
	}
	// v3.21.34: ارسالِ گروهیِ تبلیغاتیِ گردونه → از خطِ تبلیغات (پیش‌فرض PRO).
	$sender = farazsms_get_ad_sender();
	$sent   = 0;
	foreach ( array_chunk( $mobiles, 100 ) as $chunk ) {
		$response = farazsms_remote_post_with_fallback( farazsms_sms_api_url( 'sms/simple' ), array(
			'headers' => array( 'Accept' => 'application/json', 'Content-Type' => 'application/json', 'Api-Key' => $apikey ),
			'body'    => wp_json_encode( array( 'line_number' => $sender, 'recipients' => $chunk, 'text' => $message, 'number_format' => 'english' ) ),
			'timeout' => 30,
		) );
		if ( ! is_wp_error( $response ) && is_array( $response ) ) {
			$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( is_array( $decoded ) && isset( $decoded['status'] ) && $decoded['status'] === 'success' ) {
				$sent += count( $chunk );
			}
		}
	}
	wp_send_json_success( array( 'message' => 'ارسال شد به ' . $sent . ' شماره (از ' . count( $mobiles ) . ').' ) );
}

/* ───────────────────────────── خروجی CSV ───────────────────────────── */

add_action( 'admin_init', 'farazsms_spin_maybe_export_csv' );
function farazsms_spin_maybe_export_csv() {
	if ( empty( $_GET['farazsms_spin_csv'] ) || ! is_admin() ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'farazsms_spin_csv' ) ) {
		return;
	}
	global $wpdb;
	$rows = $wpdb->get_results( 'SELECT mobile, prize_label, prize_type, prize_value, won, created_at FROM ' . farazsms_spin_table() . ' ORDER BY id DESC', ARRAY_A );
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=spin-participants-' . gmdate( 'Y-m-d' ) . '.csv' );
	$out = fopen( 'php://output', 'w' );
	fprintf( $out, "\xEF\xBB\xBF" ); // BOM برای اکسلِ فارسی
	fputcsv( $out, array( 'mobile', 'prize', 'type', 'value', 'won', 'date' ) );
	foreach ( (array) $rows as $r ) {
		fputcsv( $out, array( $r['mobile'], $r['prize_label'], $r['prize_type'], $r['prize_value'], $r['won'] ? '1' : '0', $r['created_at'] ) );
	}
	fclose( $out );
	exit;
}

/* ───────────────────────────── شورت‌کدِ دکمه ───────────────────────────── */

add_shortcode( 'spin_wheel_button', 'farazsms_spin_button_shortcode' );
function farazsms_spin_button_shortcode( $atts ) {
	$a = shortcode_atts( array( 'text' => 'شانست رو امتحان کن! 🎡' ), $atts, 'spin_wheel_button' );
	return '<button type="button" class="spin-wheel-open" style="background:linear-gradient(135deg,#f59e0b,#ef4444);color:#fff;border:none;padding:12px 26px;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;font-family:inherit;">' . esc_html( $a['text'] ) . '</button>';
}
