<?php
/**
 * صفحه‌ی محصورِ «ارسال در بله» — تیکِ سرویس‌ها + یادداشت‌های شفافیت + مدیریتِ کلید/وضعیت.
 *
 * این فایل فقط وقتی بار می‌شود که کلیدِ بله تنظیم است (بارگذاریِ مشروط در
 * farazsms-bale-init.php → farazsms_bale_maybe_load_admin، طبقِ AD-8). پس هر چیزِ این‌جا
 * «دیدنی/اجرایی» است و برای فروشگاهی که بله ندارد اصلاً وجود ندارد.
 *
 * «صفحه‌ی محصور» (containment page): تنها جای شلوغیِ بله؛ بقیه‌ی افزونه دست‌نخورده می‌ماند
 * تا حسِ «سبک» حفظ شود.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

// زیرمنوی «ارسال در بله» زیرِ منوی افزونه (فقط چون این فایل مشروط بار شده = کلید هست).
add_action( 'admin_menu', 'farazsms_bale_register_page', 60 );
function farazsms_bale_register_page() {
	add_submenu_page(
		'farazsms',
		'ارسال در بله',
		'ارسال در بله',
		'manage_options',
		'farazsms-bale',
		'farazsms_bale_render_admin_page'
	);
}

// نمایشِ زیرمنو در سایدبارِ کوتاه‌شده‌ی افزونه (منبعِ واحدِ AD-9 برای منو).
add_filter( 'farazsms_sidebar_visible_slugs', 'farazsms_bale_add_sidebar_slug' );
function farazsms_bale_add_sidebar_slug( $slugs ) {
	if ( is_array( $slugs ) && ! in_array( 'farazsms-bale', $slugs, true ) ) {
		// بعد از «پیامک سفارشات» قرار بگیرد (کنارِ کانال‌های خروجی).
		$slugs[] = 'farazsms-bale';
	}
	return $slugs;
}

/**
 * رِندرِ صفحه‌ی «ارسال در بله».
 */
function farazsms_bale_render_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی مجاز نیست' );
	}
	$registry = farazsms_bale_service_registry();
	$enabled  = farazsms_bale_enabled_services(); // پیش‌فرض همه (خاموش = نبودن در option)
	$nonce    = wp_create_nonce( 'farazsms_bale_page' );
	?>
	<div class="wrap">
		<div class="farazsms-bale-page">

			<div class="farazsms-bale-panel">
				<h2>وضعیتِ اتصال به بله</h2>
				<p class="sub">پیام‌های افزونه علاوه بر پیامک، در پیام‌رسانِ بله هم ارسال می‌شوند (به‌جز کدِ تاییدِ ورود).</p>
				<?php echo farazsms_bale_status_bar_html(); ?>
				<p class="sub" style="margin-top:12px;">
					کلیدِ دسترسی در صفحه‌ی
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-settings' ) ); ?>">تنظیمات</a>
					مدیریت می‌شود.
				</p>
			</div>

			<div class="farazsms-bale-panel">
				<h2>در کدام بخش‌ها در بله هم ارسال شود؟</h2>
				<p class="sub">پیش‌فرض همه فعال است. غیرفعال‌کردنِ هر مورد فقط ارسالِ «بله»ی آن را خاموش می‌کند؛ پیامکِ همان بخش دست‌نخورده ارسال می‌شود.</p>

				<form id="farazsms-bale-services-form" onsubmit="return false;">
					<input type="hidden" name="farazsms_bale_page_nonce" value="<?php echo esc_attr( $nonce ); ?>">
					<div class="farazsms-bale-services">
						<?php foreach ( $registry as $slug => $label ) :
							$checked = in_array( $slug, $enabled, true ) ? 'checked' : ''; ?>
							<label class="farazsms-bale-service">
								<input type="checkbox" name="bale_service[]" value="<?php echo esc_attr( $slug ); ?>" <?php echo $checked; ?>>
								<span><?php echo esc_html( $label ); ?></span>
							</label>
						<?php endforeach; ?>
					</div>

					<div class="farazsms-bale-actions">
						<button type="button" class="farazsms-bale-btn" id="farazsms-bale-save-services">ذخیره‌ی تنظیمات</button>
						<span class="farazsms-bale-resp" id="farazsms-bale-services-resp" role="status"></span>
					</div>
				</form>

				<?php $soon = farazsms_bale_coming_soon_services(); ?>
				<?php if ( ! empty( $soon ) ) : ?>
					<p class="farazsms-bale-soon">
						سرویسِ بله برای بخش‌های زیر <b>به‌زودی</b> فعال می‌شود:
						<?php echo esc_html( implode( '، ', $soon ) ); ?>.
					</p>
				<?php endif; ?>
			</div>

			<div class="farazsms-bale-panel">
				<h2>نکاتِ مهم درباره‌ی ارسال در بله</h2>
				<div class="farazsms-bale-notes">
					ارسال در بله با پیامک فرق دارد؛ لطفاً این نکات را در نظر بگیرید:
					<ul>
						<li>ارسالِ بله <b>آنی نیست</b> و پس از تاییدِ ناظرِ انسانی در سیستمِ بله انجام می‌شود؛ ممکن است تاخیر داشته باشد.</li>
						<li>اگر گیرنده در بله حساب <b>نداشته باشد</b>، پیام تحویل نمی‌شود و در آن صورت هزینه‌ای کسر نمی‌شود.</li>
						<li>ارسالِ بله <b>رایگان نیست</b> و از اعتبارِ پنلِ بله‌ی شما کم می‌شود.</li>
						<li>متنِ بله در این نسخه <b>همان متنِ پیامک</b> است.</li>
						<li>نتیجه‌ی هر ارسال در «<a href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-diagnostics' ) ); ?>">🩺 تشخیصِ ارسال</a>» با برچسبِ <code dir="ltr">bale:</code> ثبت می‌شود.</li>
					</ul>
				</div>
			</div>

		</div>
	</div>
	<?php
	farazsms_bale_print_inline_js(); // JSِ نوارِ وضعیت (مشترک با کارتِ تنظیمات)
	farazsms_bale_print_services_js();
}

/**
 * AJAX: ذخیره‌ی تیکِ سرویس‌ها. خاموش‌ها = registry منهای تیک‌خورده‌ها (منبعِ واحدِ AD-9).
 */
add_action( 'wp_ajax_farazsms_bale_save_services', 'farazsms_bale_ajax_save_services' );
function farazsms_bale_ajax_save_services() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی مجاز نیست' ) );
	}
	check_ajax_referer( 'farazsms_bale_page', 'farazsms_bale_page_nonce' );

	$posted  = isset( $_POST['bale_service'] ) ? (array) wp_unslash( $_POST['bale_service'] ) : array();
	$posted  = array_map( 'sanitize_key', $posted );
	// فقط slugهای معتبرِ registry را بپذیر (ضدِ تزریقِ slugِ نامعتبر).
	$valid   = array_intersect( $posted, farazsms_bale_service_slugs() );
	$disabled = farazsms_bale_disabled_from_enabled( $valid );
	update_option( 'farazsms_bale_disabled_services', array_values( $disabled ), false );

	wp_send_json_success( array(
		'message' => '✓ تنظیماتِ ارسال در بله ذخیره شد.',
		'enabled' => farazsms_bale_enabled_services(),
	) );
}

/**
 * JSِ خطیِ ذخیره‌ی تیکِ سرویس‌ها.
 */
function farazsms_bale_print_services_js() {
	?>
	<script>
	(function($){
		if (!$) { return; }
		$(document).on('click', '#farazsms-bale-save-services', function(){
			var $btn = $(this), $resp = $('#farazsms-bale-services-resp');
			var slugs = $('#farazsms-bale-services-form input[name="bale_service[]"]:checked').map(function(){ return this.value; }).get();
			$btn.prop('disabled', true).addClass('is-loading');
			$resp.text('در حال ذخیره…').removeClass('is-ok is-err');
			$.post(ajaxurl, {
				action: 'farazsms_bale_save_services',
				farazsms_bale_page_nonce: $('#farazsms-bale-services-form input[name=farazsms_bale_page_nonce]').val(),
				'bale_service[]': slugs
			}).done(function(r){
				if (r && r.success){ $resp.text(r.data.message).addClass('is-ok'); }
				else { $resp.text((r && r.data && r.data.message) ? r.data.message : 'خطا در ذخیره').addClass('is-err'); }
			}).fail(function(){ $resp.text('خطا در ارتباط با سرور').addClass('is-err'); })
			  .always(function(){ $btn.prop('disabled', false).removeClass('is-loading'); });
		});
	})(window.jQuery);
	</script>
	<?php
}
