<?php
/**
 * خبرنامه محصولات (Product Newsletter) — Phase 1
 *
 * این ماژول صفحه ادمین، شورت‌کد، ویجت، AJAX subscribe، CSV export، و
 * ارسال گروهی پیامک به اعضای خبرنامه را در پلاگین فراز اس‌ام‌اس فراهم می‌کند.
 *
 * جدول DB:  {$wpdb->prefix}farazsms_newsletter_subscribers
 * Shortcode: [farazsms_newsletter]
 * Widget:    FarazSMS_Newsletter_Widget
 * Submenu:   farazsms-newsletter (priority 985، بین گزارشات و بازخورد)
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

// ============================================================================
// Schema — جدول DB با version gating
// ============================================================================

const FARAZSMS_NEWSLETTER_DB_VERSION        = '1.1.0'; // v3.18.0: composite index status_subscribed_at
const FARAZSMS_NEWSLETTER_DB_VERSION_OPTION = 'farazsms_newsletter_db_version';

/**
 * Returns the subscribers table name (prefixed).
 *
 * @return string
 */
function farazsms_newsletter_table() {
	global $wpdb;
	return $wpdb->prefix . 'farazsms_newsletter_subscribers';
}

/**
 * Create/upgrade the subscribers table. Gated by version so dbDelta does not
 * run on every request (same pattern as Elementor SMS SQL class).
 */
function farazsms_newsletter_maybe_setup_table() {
	if ( get_option( FARAZSMS_NEWSLETTER_DB_VERSION_OPTION ) === FARAZSMS_NEWSLETTER_DB_VERSION ) {
		return;
	}
	if ( ! function_exists( 'dbDelta' ) ) {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	}
	global $wpdb;
	$table           = farazsms_newsletter_table();
	$charset_collate = $wpdb->get_charset_collate();

	// v3.18.0: composite index status_subscribed_at — speeds up
	//   SELECT COUNT(*) FROM ... WHERE status='active' AND subscribed_at >= X
	// که در KPI widget و آمار roi استفاده می‌شود.
	$sql = "CREATE TABLE $table (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		name VARCHAR(255) NOT NULL DEFAULT '',
		mobile VARCHAR(20) NOT NULL,
		source VARCHAR(50) NOT NULL DEFAULT '',
		ip VARCHAR(45) NOT NULL DEFAULT '',
		status VARCHAR(20) NOT NULL DEFAULT 'active',
		subscribed_at DATETIME NOT NULL,
		unsubscribed_at DATETIME NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY mobile (mobile),
		KEY status (status),
		KEY subscribed_at (subscribed_at),
		KEY status_subscribed_at (status, subscribed_at)
	) $charset_collate;";

	dbDelta( $sql );
	// v3.21.7: فقط وقتی جدول واقعاً ساخته شد latch کن (شکستِ dbDelta = مرگِ بی‌صدا).
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
		update_option( FARAZSMS_NEWSLETTER_DB_VERSION_OPTION, FARAZSMS_NEWSLETTER_DB_VERSION, false );
	}
}
add_action( 'admin_init', 'farazsms_newsletter_maybe_setup_table' );

// ============================================================================
// تنظیمات پیش‌فرض
// ============================================================================

/**
 * Read merged newsletter settings, applying sensible defaults.
 *
 * @return array
 */
function farazsms_newsletter_settings() {
	$defaults = array(
		'enabled'              => '1',
		'form_title'           => 'عضویت در خبرنامه',
		'form_description'     => 'با عضویت در خبرنامه، از تخفیف‌ها و محصولات جدید با خبر شوید.',
		'name_label'           => 'نام',
		'mobile_label'         => 'شماره موبایل',
		'button_text'          => 'عضویت',
		'success_message'      => 'با موفقیت در خبرنامه عضو شدید.',
		'duplicate_message'    => 'این شماره قبلاً در خبرنامه ثبت شده است.',
		'error_message'        => 'خطا در ثبت عضویت. لطفاً بعداً تلاش کنید.',
		'welcome_pattern_code' => '', // اختیاری — اگر تنظیم شود، پیامک خوش‌آمد ارسال می‌شود
		'redirect_url'         => '',
		'primary_color'        => '#4571ba', // رنگِ دکمه و اکسنتِ فرم
		'title_color'          => '#1f2937', // رنگِ عنوان
		'bg_color'             => '#ffffff',  // رنگِ پس‌زمینه‌ی فرم
		'custom_css'           => '',
	);
	$saved = get_option( 'farazsms_newsletter_settings', array() );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
}

// ============================================================================
// زیرمنوی ادمین
// ============================================================================

/**
 * Register the newsletter admin page (priority 985 — between Reports at 990
 * and Feedback at 999, so it appears just above Feedback in the menu).
 */
add_action( 'admin_menu', 'farazsms_newsletter_register_submenu', 985 );
function farazsms_newsletter_register_submenu() {
	add_submenu_page(
		'farazsms',
		__( 'خبرنامه', 'farazsms' ),
		__( 'خبرنامه', 'farazsms' ),
		'manage_options',
		'farazsms-newsletter',
		'farazsms_render_newsletter_page'
	);
}

/**
 * پیکرِ رنگِ وردپرس روی صفحه‌ی تنظیماتِ خبرنامه (سواچِ زنده + پالت + اعتبارسنجی).
 */
add_action( 'admin_enqueue_scripts', 'farazsms_newsletter_admin_enqueue' );
function farazsms_newsletter_admin_enqueue( $hook ) {
	if ( ! farazsms_is_admin_page( 'farazsms-newsletter', $hook ) ) {
		return;
	}
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker' );
	add_action( 'admin_footer', 'farazsms_newsletter_color_picker_script' );
}
function farazsms_newsletter_color_picker_script() {
	?>
	<script>
	jQuery(function($){
		if ($.fn.wpColorPicker) { $('.farazsms-newsletter-color-field').wpColorPicker(); }
	});
	</script>
	<?php
}

// ============================================================================
// CRUD ساده روی جدول
// ============================================================================

/**
 * Normalize an Iranian mobile number to the canonical `09xxxxxxxxx` form.
 * Returns '' when the input cannot be canonicalised — callers should treat
 * that as a validation failure.
 *
 * @param string $raw
 * @return string
 */
function farazsms_newsletter_normalize_mobile( $raw ) {
	$raw = (string) $raw;
	$raw = farazsms_tr_num( $raw );
	$digits = preg_replace( '/\D+/', '', $raw );
	if ( $digits === '' ) {
		return '';
	}
	// Strip 98 / +98 prefix or leading 0.
	if ( strpos( $digits, '98' ) === 0 && strlen( $digits ) === 12 ) {
		$digits = '0' . substr( $digits, 2 );
	} elseif ( strlen( $digits ) === 10 && $digits[0] === '9' ) {
		$digits = '0' . $digits;
	}
	if ( strlen( $digits ) !== 11 || strpos( $digits, '09' ) !== 0 ) {
		return '';
	}
	return $digits;
}

/**
 * Insert (or restore) a subscriber. Returns array{success:bool, message:string, code:string, id?:int}.
 *
 * Codes:
 *   ok           — newly inserted
 *   reactivated  — existed but was unsubscribed, now restored
 *   duplicate    — already active
 *   invalid      — invalid mobile
 *   error        — DB error
 *
 * @param string $name
 * @param string $mobile_raw
 * @param string $source
 * @return array
 */
function farazsms_newsletter_insert_subscriber( $name, $mobile_raw, $source = '' ) {
	global $wpdb;
	$mobile = farazsms_newsletter_normalize_mobile( $mobile_raw );
	if ( $mobile === '' ) {
		return array(
			'success' => false,
			'code'    => 'invalid',
			'message' => __( 'شماره موبایل معتبر نیست.', 'farazsms' ),
		);
	}
	$name   = sanitize_text_field( wp_unslash( (string) $name ) );
	$source = sanitize_key( $source );
	if ( $source === '' ) {
		$source = 'shortcode';
	}
	$ip = '';
	if ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
		$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
	}
	$now   = current_time( 'mysql' );
	$table = farazsms_newsletter_table();

	// Check existing row by mobile (unique key).
	$existing = $wpdb->get_row( $wpdb->prepare( "SELECT id, status FROM $table WHERE mobile = %s LIMIT 1", $mobile ), ARRAY_A );

	if ( $existing ) {
		if ( isset( $existing['status'] ) && $existing['status'] === 'active' ) {
			return array(
				'success' => false,
				'code'    => 'duplicate',
				'message' => farazsms_newsletter_settings()['duplicate_message'],
				'id'      => (int) $existing['id'],
			);
		}
		// Reactivate an unsubscribed entry.
		$wpdb->update(
			$table,
			array(
				'name'            => $name,
				'status'          => 'active',
				'subscribed_at'   => $now,
				'unsubscribed_at' => null,
				'ip'              => $ip,
				'source'          => $source,
			),
			array( 'id' => (int) $existing['id'] ),
			array( '%s', '%s', '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);
		farazsms_newsletter_maybe_sync_phonebook( $mobile, $name ); // Story 6-3
		return array(
			'success' => true,
			'code'    => 'reactivated',
			'message' => farazsms_newsletter_settings()['success_message'],
			'id'      => (int) $existing['id'],
		);
	}

	$inserted = $wpdb->insert(
		$table,
		array(
			'name'          => $name,
			'mobile'        => $mobile,
			'source'        => $source,
			'ip'            => $ip,
			'status'        => 'active',
			'subscribed_at' => $now,
		),
		array( '%s', '%s', '%s', '%s', '%s', '%s' )
	);
	if ( $inserted === false ) {
		return array(
			'success' => false,
			'code'    => 'error',
			'message' => farazsms_newsletter_settings()['error_message'],
		);
	}
	farazsms_newsletter_maybe_sync_phonebook( $mobile, $name ); // Story 6-3
	return array(
		'success' => true,
		'code'    => 'ok',
		'message' => farazsms_newsletter_settings()['success_message'],
		'id'      => (int) $wpdb->insert_id,
	);
}

/**
 * v3.22.52 (Story 6-3): همگام‌سازیِ مشترکِ خبرنامه با دفترچه‌تلفنِ فراز — غیرمسدود.
 *
 * v3.22.198: از صفِ مشترک رد می‌شود، نه هوکِ shutdownِ خودش.
 *
 * ⚠️ چرا مهم بود: پیامکِ خوش‌آمد در همین درخواست به صف رفت و کامنتش نوشت
 * «حالا واقعاً از درخواست خارج می‌شود» — ولی این تابع روی همان درخواست یک
 * تماسِ HTTP دیگر داشت که روی mod_php **پیش از** بسته‌شدنِ پاسخ اجرا می‌شد.
 * یعنی نیمی از هزینه سرِ جایش مانده بود و کامنت خلافش را می‌گفت؛ دقیقاً همان
 * الگوی «کامنتِ دروغ‌گو» که ممیزی رویش انگشت گذاشته بود.
 *
 * آرگومان‌ها positional می‌مانند (رفعِ PHP 8 در farazsms_async_call).
 *
 * @param string $mobile شماره‌ی نرمال‌شده (09…).
 * @param string $name
 */
function farazsms_newsletter_maybe_sync_phonebook( $mobile, $name ) {
	if ( (string) get_option( 'farazsms_newsletter_sync_phonebook', '1' ) !== '1' ) {
		return; // مدیر همگام‌سازی را خاموش کرده.
	}
	if ( ! class_exists( 'FarazSMS_Next_Phonebook_API' ) ) {
		return;
	}
	$api_key = farazsms_get_apikey();
	$mobile  = (string) $mobile;
	if ( $api_key === '' || $mobile === '' ) {
		return;
	}
	$name = (string) $name;
	// ⚠️ کلیدِ API عمداً در payload نمی‌رود: کارِ پارک‌شده در آپشنِ باقی‌مانده
	// سریال می‌شود و کلید را به‌صورتِ خام روی دیتابیس می‌نشاند — دور زدنِ
	// رمزگذاریِ در-حالِ-سکونِ کلید. کارگر خودش آن را می‌خواند.
	farazsms_queue_task( 'newsletter-phonebook', 'farazsms_newsletter_pb_sync_worker', array( $mobile, $name ) );
}

/**
 * Worker: دفترچه‌ی «مشترکین خبرنامه» را find-or-create و مخاطب را اضافه می‌کند. Fail-Open.
 *
 * @param string $mobile
 * @param string $name
 * @param string $api_key
 */
function farazsms_newsletter_pb_sync_worker( $mobile, $name, $api_key = '' ) {
	try {
		// کلید در زمانِ اجرا خوانده می‌شود، نه از payload. آرگومانِ سوم فقط برای
		// کارهای پارک‌شده‌ی نسخه‌ی قبل مانده است.
		if ( $api_key === '' ) {
			$api_key = (string) farazsms_get_apikey();
		}
		if ( ! class_exists( 'FarazSMS_Next_Phonebook_API' ) || $api_key === '' || $mobile === '' ) {
			return;
		}
		$phonebook_id = farazsms_newsletter_get_phonebook_id( $api_key );
		if ( $phonebook_id <= 0 ) {
			return;
		}
		if ( $name === '' ) {
			$name = __( 'مشترک خبرنامه', 'farazsms' );
		}
		$api   = new FarazSMS_Next_Phonebook_API();
		$added = $api->add_contact( $phonebook_id, $name, $mobile, $api_key );
		// خودترمیمی: اگر افزودن ناموفق بود (دفترچه حذف شده یا کلید عوض شده)، کشِ id را باطل کن تا
		// مشترکِ بعدی دفترچه را دوباره find-or-create کند (به‌جای گیرکردن روی id‌ِ مرده تا ۱۲ ساعت).
		if ( ! is_array( $added ) || empty( $added['success'] ) ) {
			delete_transient( 'farazsms_newsletter_pb_id_' . md5( (string) $api_key ) );
		}
	} catch ( \Throwable $e ) {
		error_log( 'farazsms newsletter phonebook sync failed: ' . $e->getMessage() );
	}
}

/**
 * دفترچه‌ی «مشترکین خبرنامه» را می‌یابد؛ اگر نبود می‌سازد. با کشِ ۱۲ساعته (کلید بر مبنای api_key).
 *
 * @param string $api_key
 * @return int شناسه‌ی دفترچه یا 0.
 */
function farazsms_newsletter_get_phonebook_id( $api_key ) {
	$title     = 'مشترکین خبرنامه';
	$cache_key = 'farazsms_newsletter_pb_id_' . md5( (string) $api_key );
	$cached    = get_transient( $cache_key );
	if ( $cached !== false ) {
		return (int) $cached;
	}
	$api  = new FarazSMS_Next_Phonebook_API();
	$resp = $api->get_phonebooks( $api_key );
	$items = array();
	if ( is_array( $resp ) ) {
		if ( isset( $resp['data']['items'] ) && is_array( $resp['data']['items'] ) ) {
			$items = $resp['data']['items'];
		} elseif ( isset( $resp['data']['data'] ) && is_array( $resp['data']['data'] ) ) {
			$items = $resp['data']['data'];
		} elseif ( isset( $resp['data'] ) && is_array( $resp['data'] ) && isset( $resp['data'][0]['id'] ) ) {
			$items = $resp['data'];
		}
	}
	foreach ( $items as $pb ) {
		if ( isset( $pb['title'], $pb['id'] ) && (string) $pb['title'] === $title ) {
			set_transient( $cache_key, (int) $pb['id'], 12 * HOUR_IN_SECONDS );
			return (int) $pb['id'];
		}
	}
	// نبود → بساز.
	$created = $api->create_phonebook( $title, $api_key );
	$new_id  = 0;
	if ( is_array( $created ) ) {
		if ( isset( $created['data']['id'] ) ) {
			$new_id = (int) $created['data']['id'];
		} elseif ( isset( $created['data'] ) && is_numeric( $created['data'] ) ) {
			$new_id = (int) $created['data'];
		} elseif ( isset( $created['id'] ) ) {
			$new_id = (int) $created['id'];
		}
	}
	if ( $new_id > 0 ) {
		set_transient( $cache_key, $new_id, 12 * HOUR_IN_SECONDS );
	}
	return $new_id;
}

/**
 * Quick counts grouped by status — used in the admin stats box.
 *
 * @return array{total:int, active:int, unsubscribed:int, last_30_days:int}
 */
function farazsms_newsletter_get_counts() {
	global $wpdb;
	$table = farazsms_newsletter_table();
	$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
	$active = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE status = %s", 'active' ) );
	$unsubscribed = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE status = %s", 'unsubscribed' ) );
	$last_30 = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE subscribed_at >= %s", gmdate( 'Y-m-d H:i:s', strtotime( '-30 days' ) ) ) );
	return array(
		'total'        => $total,
		'active'       => $active,
		'unsubscribed' => $unsubscribed,
		'last_30_days' => $last_30,
	);
}

// ============================================================================
// AJAX — عضویت در خبرنامه (Public)
// ============================================================================

add_action( 'wp_ajax_farazsms_newsletter_subscribe',        'farazsms_newsletter_ajax_subscribe' );
add_action( 'wp_ajax_nopriv_farazsms_newsletter_subscribe', 'farazsms_newsletter_ajax_subscribe' );
function farazsms_newsletter_ajax_subscribe() {
	// nonce
	$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'farazsms_newsletter_subscribe' ) ) {
		wp_send_json_error( array( 'message' => __( 'خطای امنیتی. لطفاً صفحه را رفرش کنید.', 'farazsms' ) ), 403 );
	}
	// v3.19.0: rate-limit دو لایه با helper جدید — IP + شماره موبایل
	$secondary_key = isset( $_POST['mobile'] ) ? wp_unslash( $_POST['mobile'] ) : '';
	$guard = farazsms_rate_limit_guard_public( 'newsletter_subscribe', $secondary_key );
	if ( ! $guard['allowed'] ) {
		wp_send_json_error( array( 'message' => $guard['message'] ), 429 );
	}

	$settings = farazsms_newsletter_settings();
	if ( $settings['enabled'] !== '1' ) {
		wp_send_json_error( array( 'message' => __( 'عضویت در خبرنامه در حال حاضر غیرفعال است.', 'farazsms' ) ) );
	}

	$name   = isset( $_POST['name'] )   ? wp_unslash( $_POST['name'] )   : '';
	$mobile = isset( $_POST['mobile'] ) ? wp_unslash( $_POST['mobile'] ) : '';
	$source = isset( $_POST['source'] ) ? sanitize_key( $_POST['source'] ) : 'shortcode';

	$result = farazsms_newsletter_insert_subscriber( $name, $mobile, $source );
	if ( ! $result['success'] ) {
		wp_send_json_error( array( 'message' => $result['message'] ) );
	}

	// ارسال پیامک خوش‌آمد در صورت تنظیم الگو.
	$welcome = trim( (string) $settings['welcome_pattern_code'] );
	if ( $welcome !== '' ) {
		$mobile_clean = farazsms_newsletter_normalize_mobile( $mobile );
		if ( $mobile_clean !== '' ) {
			// خطِ تبلیغاتی از فهرستِ کانال‌های تبلیغاتیِ صف می‌آید (تصمیمِ یک‌جا).
			$attrs = array(
				'name'     => sanitize_text_field( $name ),
				'sitename' => get_bloginfo( 'name' ),
			);
			// کامنتِ قبلی ادعا می‌کرد «هرگز پاسخِ AJAX را بلاک نمی‌کند» ولی ارسال
			// همان‌جا و همگام بود. حالا واقعاً از درخواست خارج می‌شود.
			farazsms_queue_send( 'newsletter', $mobile_clean, $welcome, $attrs, array( 'event' => 'welcome' ) );
		}
	}

	$payload = array( 'message' => $result['message'] );
	if ( ! empty( $settings['redirect_url'] ) ) {
		$payload['redirect'] = esc_url_raw( $settings['redirect_url'] );
	}
	wp_send_json_success( $payload );
}

// ============================================================================
// AJAX — Bulk operations (Admin only)
// ============================================================================

add_action( 'wp_ajax_farazsms_newsletter_delete', 'farazsms_newsletter_ajax_delete' );
function farazsms_newsletter_ajax_delete() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز.', 'farazsms' ) ), 403 );
	}
	check_ajax_referer( 'farazsms_newsletter_admin', 'nonce' );
	global $wpdb;
	$ids = isset( $_POST['ids'] ) ? (array) $_POST['ids'] : array();
	$ids = array_filter( array_map( 'absint', $ids ) );
	if ( empty( $ids ) ) {
		wp_send_json_error( array( 'message' => __( 'هیچ ردیفی انتخاب نشده.', 'farazsms' ) ) );
	}
	// Cap to 500 per request to prevent very large POSTs.
	$ids   = array_slice( $ids, 0, 500 );
	$table = farazsms_newsletter_table();
	$ph    = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
	$query = $wpdb->prepare( "DELETE FROM $table WHERE id IN ($ph)", $ids );
	$count = (int) $wpdb->query( $query );
	wp_send_json_success( array(
		'message' => sprintf( /* translators: %s deleted count */ __( '%s ردیف حذف شد.', 'farazsms' ), number_format_i18n( $count ) ),
		'deleted' => $count,
	) );
}

add_action( 'admin_post_farazsms_newsletter_export', 'farazsms_newsletter_handle_export' );
function farazsms_newsletter_handle_export() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( __( 'دسترسی غیرمجاز.', 'farazsms' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'farazsms_newsletter_export' );

	global $wpdb;
	$table  = farazsms_newsletter_table();
	$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
	$query  = "SELECT id, name, mobile, source, status, subscribed_at FROM $table";
	$params = array();
	if ( $status !== '' && in_array( $status, array( 'active', 'unsubscribed' ), true ) ) {
		$query .= ' WHERE status = %s';
		$params[] = $status;
	}
	$query .= ' ORDER BY id DESC';
	$rows  = $params ? $wpdb->get_results( $wpdb->prepare( $query, $params ), ARRAY_A ) : $wpdb->get_results( $query, ARRAY_A );

	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: attachment; filename=farazsms-newsletter-' . gmdate( 'Y-m-d' ) . '.csv' );

	$out = fopen( 'php://output', 'w' );
	// BOM for Excel UTF-8 compatibility (Persian text).
	fwrite( $out, "\xEF\xBB\xBF" );
	fputcsv( $out, array( 'ID', 'نام', 'شماره موبایل', 'منبع', 'وضعیت', 'تاریخ عضویت' ) );
	if ( is_array( $rows ) ) {
		foreach ( $rows as $r ) {
			fputcsv( $out, array(
				$r['id'],
				$r['name'],
				$r['mobile'],
				$r['source'],
				$r['status'],
				$r['subscribed_at'],
			) );
		}
	}
	fclose( $out );
	exit;
}

add_action( 'wp_ajax_farazsms_newsletter_send_bulk', 'farazsms_newsletter_ajax_send_bulk' );
function farazsms_newsletter_ajax_send_bulk() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز.', 'farazsms' ) ), 403 );
	}
	check_ajax_referer( 'farazsms_newsletter_admin', 'nonce' );

	$mode    = isset( $_POST['mode'] ) ? sanitize_key( $_POST['mode'] ) : '';
	$pattern = isset( $_POST['pattern_code'] ) ? sanitize_text_field( wp_unslash( $_POST['pattern_code'] ) ) : '';
	$text    = isset( $_POST['text'] ) ? farazsms_sanitize_pattern_text( $_POST['text'] ) : '';

	if ( $mode === 'pattern' && $pattern === '' ) {
		wp_send_json_error( array( 'message' => __( 'کد الگو را وارد کنید.', 'farazsms' ) ) );
	}
	if ( $mode === 'simple' && $text === '' ) {
		wp_send_json_error( array( 'message' => __( 'متن پیامک خالی است.', 'farazsms' ) ) );
	}

	global $wpdb;
	$table       = farazsms_newsletter_table();
	$subscribers = $wpdb->get_results( $wpdb->prepare( "SELECT name, mobile FROM $table WHERE status = %s", 'active' ), ARRAY_A );
	if ( empty( $subscribers ) ) {
		wp_send_json_error( array( 'message' => __( 'هیچ مشترک فعالی در خبرنامه وجود ندارد.', 'farazsms' ) ) );
	}

	// v3.21.44: خطِ تبلیغاتیِ PRO پترن را هم می‌فرستد؛ این اعلانِ تبلیغاتی از خطِ تبلیغات (پیش‌فرض PRO) می‌رود.
	$sender = farazsms_get_ad_sender();
	$sent   = 0;
	$failed = 0;

	if ( $mode === 'pattern' ) {
		foreach ( $subscribers as $sub ) {
			$attrs  = array(
				'name'     => $sub['name'],
				'sitename' => get_bloginfo( 'name' ),
			);
			$result = farazsms_send_pattern_sms_raw( $sub['mobile'], $pattern, $attrs, $sender );
			if ( $result === 'success' ) {
				$sent++;
			} else {
				$failed++;
			}
		}
	} elseif ( $mode === 'simple' ) {
		// ارسال متن آزاد به همه مشترکین در یک batch (ساده — برای حجم بالا باید queue شود).
		$recipients = array_map( function ( $s ) { return $s['mobile']; }, $subscribers );
		$apikey     = farazsms_get_apikey();
		if ( $apikey === '' ) {
			wp_send_json_error( array( 'message' => __( 'کلید دسترسی (Api-Key) در تنظیمات وارد نشده است.', 'farazsms' ) ) );
		}
		// chunk به 100 تا برای جلوگیری از پاسخ‌های بزرگ.
		$chunks = array_chunk( $recipients, 100 );
		foreach ( $chunks as $chunk ) {
			$body = array(
				'line_number'   => $sender,
				'recipients'    => $chunk,
				'text'          => $text,
				'number_format' => 'english',
			);
			$response = farazsms_remote_post_with_fallback( farazsms_sms_api_url( 'sms/simple' ), array(
					'headers' => array(
						'Accept'       => 'application/json',
						'Content-Type' => 'application/json',
						'Api-Key'      => $apikey,
					),
					'body'    => wp_json_encode( $body ),
					'timeout' => 30,
				) );
			if ( ! is_wp_error( $response ) && is_array( $response ) ) {
				$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
				if ( is_array( $decoded ) && isset( $decoded['status'] ) && $decoded['status'] === 'success' ) {
					$sent += count( $chunk );
					continue;
				}
			}
			$failed += count( $chunk );
		}
	} else {
		wp_send_json_error( array( 'message' => __( 'نوع ارسال نامعتبر است.', 'farazsms' ) ) );
	}

	wp_send_json_success( array(
		'message' => sprintf(
			/* translators: 1 sent count, 2 failed count */
			__( 'ارسال انجام شد — موفق: %1$s، ناموفق: %2$s', 'farazsms' ),
			number_format_i18n( $sent ),
			number_format_i18n( $failed )
		),
		'sent'    => $sent,
		'failed'  => $failed,
	) );
}

// Save settings (admin only — POST handler).
add_action( 'admin_post_farazsms_newsletter_save_settings', 'farazsms_newsletter_handle_save_settings' );
function farazsms_newsletter_handle_save_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( __( 'دسترسی غیرمجاز.', 'farazsms' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'farazsms_newsletter_settings' );

	$defaults = farazsms_newsletter_settings();
	$new      = $defaults;
	$fields   = array(
		'form_title', 'form_description', 'name_label', 'mobile_label',
		'button_text', 'success_message', 'duplicate_message', 'error_message',
		'welcome_pattern_code',
	);
	foreach ( $fields as $f ) {
		if ( isset( $_POST[ $f ] ) ) {
			$new[ $f ] = sanitize_text_field( wp_unslash( $_POST[ $f ] ) );
		}
	}
	// رنگ‌ها — sanitize_hex_color؛ مقدارِ نامعتبر به پیش‌فرض برمی‌گردد.
	foreach ( array( 'primary_color' => '#4571ba', 'title_color' => '#1f2937', 'bg_color' => '#ffffff' ) as $ck => $cdef ) {
		$cv          = isset( $_POST[ $ck ] ) ? sanitize_hex_color( wp_unslash( $_POST[ $ck ] ) ) : '';
		$new[ $ck ]  = $cv ? $cv : $cdef;
	}
	$new['enabled']      = isset( $_POST['enabled'] ) && $_POST['enabled'] === '1' ? '1' : '0';
	$new['redirect_url'] = isset( $_POST['redirect_url'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_url'] ) ) : '';
	$new['custom_css']   = isset( $_POST['custom_css'] ) ? str_ireplace( '</style', '<\\/style', wp_strip_all_tags( wp_unslash( $_POST['custom_css'] ) ) ) : '';

	update_option( 'farazsms_newsletter_settings', $new, false );
	// v3.22.52 (Story 6-3): همگام‌سازیِ مشترکین با دفترچه‌تلفنِ فراز (option جدا؛ پیش‌فرض روشن).
	update_option( 'farazsms_newsletter_sync_phonebook', isset( $_POST['sync_phonebook'] ) && $_POST['sync_phonebook'] === '1' ? '1' : '0', false );

	wp_safe_redirect( add_query_arg( array(
		'page'    => 'farazsms-newsletter',
		'updated' => '1',
	), admin_url( 'admin.php' ) ) );
	exit;
}

// ============================================================================
// Shortcode + Widget
// ============================================================================

add_shortcode( 'farazsms_newsletter', 'farazsms_newsletter_render_shortcode' );
function farazsms_newsletter_render_shortcode( $atts ) {
	$settings = farazsms_newsletter_settings();
	if ( $settings['enabled'] !== '1' ) {
		return '';
	}
	$atts = shortcode_atts( array(
		'title'       => $settings['form_title'],
		'description' => $settings['form_description'],
		'source'      => 'shortcode',
		'show_name'   => '1',
	), $atts, 'farazsms_newsletter' );

	farazsms_newsletter_enqueue_frontend_assets();

	ob_start();
	?>
	<div class="farazsms-newsletter-form-wrapper">
		<form class="farazsms-newsletter-form" data-source="<?php echo esc_attr( $atts['source'] ); ?>">
			<?php if ( $atts['title'] !== '' ) : ?>
				<h3 class="farazsms-newsletter-title"><?php echo esc_html( $atts['title'] ); ?></h3>
			<?php endif; ?>
			<?php if ( $atts['description'] !== '' ) : ?>
				<p class="farazsms-newsletter-description"><?php echo esc_html( $atts['description'] ); ?></p>
			<?php endif; ?>
			<div class="farazsms-newsletter-fields">
				<?php if ( $atts['show_name'] === '1' ) : ?>
					<label class="farazsms-newsletter-field">
						<span><?php echo esc_html( $settings['name_label'] ); ?></span>
						<input type="text" name="name" maxlength="100">
					</label>
				<?php endif; ?>
				<label class="farazsms-newsletter-field">
					<span><?php echo esc_html( $settings['mobile_label'] ); ?></span>
					<input type="tel" name="mobile" maxlength="15" required dir="ltr" inputmode="numeric" pattern="[0-9۰-۹]+">
				</label>
			</div>
			<button type="submit" class="farazsms-newsletter-submit"><?php echo esc_html( $settings['button_text'] ); ?></button>
			<div class="farazsms-newsletter-message" role="status" aria-live="polite"></div>
		</form>
	</div>
	<?php
	return ob_get_clean();
}

/**
 * Enqueue frontend assets only on pages that actually use the shortcode or widget.
 */
function farazsms_newsletter_enqueue_frontend_assets() {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done = true;

	// Inline CSS — scoped under .farazsms-newsletter-form-wrapper so it never leaks.
	add_action( 'wp_footer', 'farazsms_newsletter_render_frontend_inline', 5 );
}

/**
 * Inline JS + nonce + AJAX URL for the form.
 */
function farazsms_newsletter_render_frontend_inline() {
	$nonce    = wp_create_nonce( 'farazsms_newsletter_subscribe' );
	$ajax_url = admin_url( 'admin-ajax.php' );
	$settings = farazsms_newsletter_settings();
	$custom_css = trim( (string) ( $settings['custom_css'] ?? '' ) );
	// رنگ‌های قابلِ تنظیم (با sanitize_hex_color؛ در نبودِ مقدار به پیش‌فرض برمی‌گردد).
	$primary = sanitize_hex_color( (string) ( $settings['primary_color'] ?? '' ) );
	$primary = $primary ? $primary : '#4571ba';
	$title_c = sanitize_hex_color( (string) ( $settings['title_color'] ?? '' ) );
	$title_c = $title_c ? $title_c : '#1f2937';
	$bg_c    = sanitize_hex_color( (string) ( $settings['bg_color'] ?? '' ) );
	$bg_c    = $bg_c ? $bg_c : '#ffffff';
	// رنگِ hover کمی تیره‌تر — با mix ساده روی همان primary.
	?>
	<style>
	.farazsms-newsletter-form-wrapper { font-family: inherit; direction: rtl; max-width: 420px; margin: 12px auto; padding: 20px; background: <?php echo esc_attr( $bg_c ); ?>; border: 1px solid #e5e7eb; border-radius: 10px; box-shadow: 0 2px 6px rgba(0,0,0,0.04); }
	.farazsms-newsletter-form-wrapper .farazsms-newsletter-title { margin: 0 0 6px; font-size: 17px; font-weight: 700; color: <?php echo esc_attr( $title_c ); ?>; }
	.farazsms-newsletter-form-wrapper .farazsms-newsletter-description { margin: 0 0 16px; font-size: 13px; line-height: 1.7; color: #4b5563; }
	.farazsms-newsletter-form-wrapper .farazsms-newsletter-fields { display: flex; flex-direction: column; gap: 10px; margin-bottom: 14px; }
	.farazsms-newsletter-form-wrapper .farazsms-newsletter-field { display: flex; flex-direction: column; gap: 4px; }
	.farazsms-newsletter-form-wrapper .farazsms-newsletter-field span { font-size: 12px; color: #374151; }
	.farazsms-newsletter-form-wrapper .farazsms-newsletter-field input { width: 100%; padding: 9px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; box-sizing: border-box; }
	.farazsms-newsletter-form-wrapper .farazsms-newsletter-field input:focus { outline: none; border-color: <?php echo esc_attr( $primary ); ?>; box-shadow: 0 0 0 3px rgba(99,102,241,0.15); }
	.farazsms-newsletter-form-wrapper .farazsms-newsletter-submit { width: 100%; background: <?php echo esc_attr( $primary ); ?>; color: #fff; border: 0; border-radius: 6px; padding: 11px 18px; font-size: 14px; font-weight: 600; cursor: pointer; transition: background .15s, filter .15s; }
	.farazsms-newsletter-form-wrapper .farazsms-newsletter-submit:hover { filter: brightness(0.92); }
	.farazsms-newsletter-form-wrapper .farazsms-newsletter-submit:disabled { opacity: 0.6; cursor: not-allowed; }
	.farazsms-newsletter-form-wrapper .farazsms-newsletter-message { margin-top: 10px; min-height: 20px; font-size: 13px; }
	.farazsms-newsletter-form-wrapper .farazsms-newsletter-message.success { color: #047857; }
	.farazsms-newsletter-form-wrapper .farazsms-newsletter-message.error { color: #b91c1c; }
	<?php if ( $custom_css !== '' ) : ?>
	<?php echo "\n" . str_ireplace( '</style', '<\\/style', $custom_css ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	<?php endif; ?>
	</style>
	<script>
	(function(){
		var endpoints = {
			url: <?php echo wp_json_encode( $ajax_url ); ?>,
			nonce: <?php echo wp_json_encode( $nonce ); ?>
		};
		function persianToAscii(str){
			var p = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
			var a = ['0','1','2','3','4','5','6','7','8','9'];
			for (var i=0;i<p.length;i++){ str = str.split(p[i]).join(a[i]); }
			return str;
		}
		function init(form){
			if (form._wtoBound) return; form._wtoBound = true;
			form.addEventListener('submit', function(ev){
				ev.preventDefault();
				var msg = form.querySelector('.farazsms-newsletter-message');
				var btn = form.querySelector('.farazsms-newsletter-submit');
				var nameI = form.querySelector('input[name="name"]');
				var mobileI = form.querySelector('input[name="mobile"]');
				var mobile = persianToAscii((mobileI && mobileI.value) || '').replace(/\D+/g, '');
				if (!/^0?9\d{9}$/.test(mobile)) {
					msg.className = 'farazsms-newsletter-message error';
					msg.textContent = 'شماره موبایل معتبر نیست.';
					return;
				}
				var data = new FormData();
				data.append('action', 'farazsms_newsletter_subscribe');
				data.append('nonce', endpoints.nonce);
				data.append('mobile', mobile);
				data.append('name', nameI ? nameI.value : '');
				data.append('source', form.getAttribute('data-source') || 'shortcode');
				btn.disabled = true;
				var oldText = btn.textContent;
				btn.textContent = 'در حال ارسال...';
				fetch(endpoints.url, { method: 'POST', credentials: 'same-origin', body: data })
					.then(function(r){ return r.json(); })
					.then(function(json){
						if (json.success) {
							msg.className = 'farazsms-newsletter-message success';
							msg.textContent = (json.data && json.data.message) || 'انجام شد.';
							form.reset();
							if (json.data && json.data.redirect) {
								setTimeout(function(){ window.location.href = json.data.redirect; }, 1500);
							}
						} else {
							msg.className = 'farazsms-newsletter-message error';
							msg.textContent = (json.data && json.data.message) || 'خطا.';
						}
					})
					.catch(function(){
						msg.className = 'farazsms-newsletter-message error';
						msg.textContent = 'خطا در ارتباط با سرور.';
					})
					.then(function(){ btn.disabled = false; btn.textContent = oldText; });
			});
		}
		document.querySelectorAll('.farazsms-newsletter-form').forEach(init);
	})();
	</script>
	<?php
}

/**
 * Sidebar widget — wraps the same shortcode.
 */
class FarazSMS_Newsletter_Widget extends WP_Widget {
	public function __construct() {
		parent::__construct(
			'farazsms_newsletter_widget',
			__( 'خبرنامه فراز اس‌ام‌اس', 'farazsms' ),
			array( 'description' => __( 'فرم عضویت در خبرنامه پیامکی.', 'farazsms' ) )
		);
	}
	public function widget( $args, $instance ) {
		echo $args['before_widget']; // phpcs:ignore — provided by sidebar registration
		$title       = ! empty( $instance['title'] )       ? $instance['title']       : '';
		$description = ! empty( $instance['description'] ) ? $instance['description'] : '';
		echo do_shortcode( sprintf(
			'[farazsms_newsletter title="%s" description="%s" source="widget"]',
			esc_attr( $title ),
			esc_attr( $description )
		) );
		echo $args['after_widget']; // phpcs:ignore
	}
	public function form( $instance ) {
		$title       = isset( $instance['title'] )       ? esc_attr( $instance['title'] )       : '';
		$description = isset( $instance['description'] ) ? esc_attr( $instance['description'] ) : '';
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'عنوان', 'farazsms' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>"><?php esc_html_e( 'توضیح', 'farazsms' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'description' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'description' ) ); ?>" type="text" value="<?php echo esc_attr( $description ); ?>">
		</p>
		<?php
	}
	public function update( $new_instance, $old_instance ) {
		return array(
			'title'       => sanitize_text_field( $new_instance['title'] ?? '' ),
			'description' => sanitize_text_field( $new_instance['description'] ?? '' ),
		);
	}
}
add_action( 'widgets_init', function () {
	register_widget( 'FarazSMS_Newsletter_Widget' );
} );

// ============================================================================
// Admin page render
// ============================================================================

function farazsms_render_newsletter_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	farazsms_newsletter_maybe_setup_table();

	$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'list';
	$tab = in_array( $tab, array( 'list', 'settings', 'send' ), true ) ? $tab : 'list';

	echo '<section class="wrapper farazsms-newsletter-wrapper">';
	farazsms_newsletter_render_header();
	farazsms_newsletter_render_tabs( $tab );

	switch ( $tab ) {
		case 'settings':
			farazsms_newsletter_render_settings_tab();
			break;
		case 'send':
			farazsms_newsletter_render_send_tab();
			break;
		default:
			farazsms_newsletter_render_list_tab();
	}

	farazsms_newsletter_render_inline_styles();
	echo '</section>';
}

function farazsms_newsletter_render_header() {
	$apikey = farazsms_get_apikey();
	?>
	<div id="farazsms_header">
		<div>
			<a href="https://farazsms.com" target="_blank" rel="noopener">
				<img src="<?php echo esc_url( FARAZSMS_CORE_IMG . 'logo-1.png' ); ?>" alt="<?php esc_attr_e( 'فراز اس‌ام‌اس', 'farazsms' ); ?>">
			</a>
		</div>
		<?php if ( ! empty( $apikey ) ) : ?>
			<div id="farazsms_account_info">
				<div class="farazsms_credit_amount">
					<span><?php esc_html_e( 'میزان اعتبار: ', 'farazsms' ); ?></span>
					<?php echo esc_html( (string) farazsms_get_credit() ); ?>
					<span> <?php esc_html_e( 'تومان', 'farazsms' ); ?></span>
				</div>
				<?php if ( function_exists( 'farazsms_render_profile_block' ) ) { farazsms_render_profile_block(); } ?>
			</div>
		<?php endif; ?>
	</div>
	<h1 class="farazsms-newsletter-title-main"><?php esc_html_e( 'خبرنامه پیامکی', 'farazsms' ); ?></h1>
	<?php
}

function farazsms_newsletter_render_tabs( $active ) {
	$tabs = array(
		'list'     => __( 'مشترکین', 'farazsms' ),
		'send'     => __( 'ارسال گروهی', 'farazsms' ),
		'settings' => __( 'تنظیمات', 'farazsms' ),
	);
	?>
	<nav class="farazsms-newsletter-tabs">
		<?php foreach ( $tabs as $key => $label ) :
			$url = add_query_arg( array( 'page' => 'farazsms-newsletter', 'tab' => $key ), admin_url( 'admin.php' ) );
		?>
			<a class="farazsms-newsletter-tab <?php echo $active === $key ? 'is-active' : ''; ?>" href="<?php echo esc_url( $url ); ?>">
				<?php echo esc_html( $label ); ?>
			</a>
		<?php endforeach; ?>
	</nav>
	<?php
}

function farazsms_newsletter_render_list_tab() {
	global $wpdb;
	$table  = farazsms_newsletter_table();
	$counts = farazsms_newsletter_get_counts();

	$page   = isset( $_GET['paged'] )  ? max( 1, (int) $_GET['paged'] )  : 1;
	$limit  = isset( $_GET['limit'] )  ? max( 10, min( 200, (int) $_GET['limit'] ) ) : 25;
	$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
	$search = isset( $_GET['search'] ) ? sanitize_text_field( wp_unslash( $_GET['search'] ) ) : '';
	$where  = ' WHERE 1=1 ';
	$params = array();
	if ( in_array( $status, array( 'active', 'unsubscribed' ), true ) ) {
		$where   .= ' AND status = %s';
		$params[] = $status;
	}
	if ( $search !== '' ) {
		$like     = '%' . $wpdb->esc_like( $search ) . '%';
		$where   .= ' AND (mobile LIKE %s OR name LIKE %s)';
		$params[] = $like;
		$params[] = $like;
	}
	$total = (int) ( $params
		? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table $where", $params ) )
		: $wpdb->get_var( "SELECT COUNT(*) FROM $table $where" ) );
	$total_pages = max( 1, (int) ceil( $total / $limit ) );
	$offset      = ( $page - 1 ) * $limit;
	$query       = "SELECT * FROM $table $where ORDER BY id DESC LIMIT %d OFFSET %d";
	$all_params  = array_merge( $params, array( $limit, $offset ) );
	$rows        = $wpdb->get_results( $wpdb->prepare( $query, $all_params ), ARRAY_A );

	$updated = isset( $_GET['updated'] ) ? sanitize_key( $_GET['updated'] ) : '';
	?>
	<?php if ( $updated === '1' ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'تنظیمات ذخیره شد.', 'farazsms' ); ?></p></div>
	<?php endif; ?>

	<div class="farazsms-newsletter-stats">
		<div class="farazsms-newsletter-stat"><div class="num"><?php echo esc_html( number_format_i18n( $counts['total'] ) ); ?></div><div class="lbl"><?php esc_html_e( 'مجموع', 'farazsms' ); ?></div></div>
		<div class="farazsms-newsletter-stat"><div class="num farazsms-num-success"><?php echo esc_html( number_format_i18n( $counts['active'] ) ); ?></div><div class="lbl"><?php esc_html_e( 'فعال', 'farazsms' ); ?></div></div>
		<div class="farazsms-newsletter-stat"><div class="num farazsms-num-muted"><?php echo esc_html( number_format_i18n( $counts['unsubscribed'] ) ); ?></div><div class="lbl"><?php esc_html_e( 'لغو شده', 'farazsms' ); ?></div></div>
		<div class="farazsms-newsletter-stat"><div class="num farazsms-num-info"><?php echo esc_html( number_format_i18n( $counts['last_30_days'] ) ); ?></div><div class="lbl"><?php esc_html_e( '۳۰ روز اخیر', 'farazsms' ); ?></div></div>
	</div>

	<form method="get" class="farazsms-newsletter-filters">
		<input type="hidden" name="page" value="farazsms-newsletter">
		<label>
			<span><?php esc_html_e( 'جستجو:', 'farazsms' ); ?></span>
			<input type="text" name="search" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'نام یا شماره موبایل', 'farazsms' ); ?>">
		</label>
		<label>
			<span><?php esc_html_e( 'وضعیت:', 'farazsms' ); ?></span>
			<select name="status">
				<option value=""<?php selected( $status, '' ); ?>><?php esc_html_e( 'همه', 'farazsms' ); ?></option>
				<option value="active"<?php selected( $status, 'active' ); ?>><?php esc_html_e( 'فعال', 'farazsms' ); ?></option>
				<option value="unsubscribed"<?php selected( $status, 'unsubscribed' ); ?>><?php esc_html_e( 'لغو شده', 'farazsms' ); ?></option>
			</select>
		</label>
		<label>
			<span><?php esc_html_e( 'تعداد در صفحه:', 'farazsms' ); ?></span>
			<select name="limit">
				<?php foreach ( array( 25, 50, 100, 200 ) as $opt ) : ?>
					<option value="<?php echo esc_attr( $opt ); ?>"<?php selected( $limit, $opt ); ?>><?php echo esc_html( (string) $opt ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>
		<button type="submit" class="button button-primary"><?php esc_html_e( 'اعمال فیلتر', 'farazsms' ); ?></button>
		<?php
		$export_url = wp_nonce_url(
			add_query_arg( array(
				'action' => 'farazsms_newsletter_export',
				'status' => $status,
			), admin_url( 'admin-post.php' ) ),
			'farazsms_newsletter_export'
		);
		?>
		<a class="button" href="<?php echo esc_url( $export_url ); ?>"><?php esc_html_e( 'دانلود CSV', 'farazsms' ); ?></a>
	</form>

	<form id="farazsms-newsletter-bulk-form" method="post">
		<?php wp_nonce_field( 'farazsms_newsletter_admin', 'farazsms_newsletter_admin_nonce' ); ?>
		<div class="farazsms-newsletter-bulk-bar">
			<button type="button" class="button farazsms-newsletter-bulk-delete" disabled><?php esc_html_e( 'حذف انتخاب‌شده‌ها', 'farazsms' ); ?></button>
			<span class="farazsms-newsletter-bulk-info"></span>
		</div>

		<table class="widefat striped farazsms-newsletter-table">
			<thead>
				<tr>
					<th class="check-column"><input type="checkbox" id="farazsms-newsletter-select-all"></th>
					<th><?php esc_html_e( 'شناسه', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'نام', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'موبایل', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'منبع', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'وضعیت', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'تاریخ عضویت', 'farazsms' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $rows ) ) : ?>
					<tr><td colspan="7"><?php esc_html_e( 'هیچ مشترکی یافت نشد.', 'farazsms' ); ?></td></tr>
				<?php else : foreach ( $rows as $r ) :
					$jdate = farazsms_send_reports_to_jalali( $r['subscribed_at'] );
					$status_class = $r['status'] === 'active' ? 'success' : 'muted';
					$status_text  = $r['status'] === 'active' ? __( 'فعال', 'farazsms' ) : __( 'لغو شده', 'farazsms' );
				?>
					<tr>
						<td><input type="checkbox" class="farazsms-newsletter-row" value="<?php echo esc_attr( $r['id'] ); ?>"></td>
						<td><?php echo esc_html( $r['id'] ); ?></td>
						<td><?php echo esc_html( $r['name'] !== '' ? $r['name'] : '—' ); ?></td>
						<td dir="ltr"><?php echo esc_html( $r['mobile'] ); ?></td>
						<td><?php echo esc_html( $r['source'] !== '' ? $r['source'] : '—' ); ?></td>
						<td><span class="farazsms-status farazsms-status-<?php echo esc_attr( $status_class ); ?>"><?php echo esc_html( $status_text ); ?></span></td>
						<td class="farazsms-newsletter-date-cell"><?php echo esc_html( $jdate ); ?></td>
					</tr>
				<?php endforeach; endif; ?>
			</tbody>
		</table>
	</form>

	<?php if ( $total_pages > 1 ) :
		$base = add_query_arg( array(
			'page'   => 'farazsms-newsletter',
			'status' => $status,
			'search' => $search,
			'limit'  => $limit,
		), admin_url( 'admin.php' ) );
		?>
		<div class="farazsms-newsletter-pagination">
			<?php if ( $page > 1 ) : ?>
				<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $page - 1, $base ) ); ?>">« <?php esc_html_e( 'صفحه قبل', 'farazsms' ); ?></a>
			<?php endif; ?>
			<span class="farazsms-newsletter-page-info">
				<?php printf( esc_html__( 'صفحه %1$s از %2$s', 'farazsms' ), esc_html( number_format_i18n( $page ) ), esc_html( number_format_i18n( $total_pages ) ) ); ?>
			</span>
			<?php if ( $page < $total_pages ) : ?>
				<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $page + 1, $base ) ); ?>"><?php esc_html_e( 'صفحه بعد', 'farazsms' ); ?> »</a>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<?php
}

function farazsms_newsletter_render_send_tab() {
	$counts = farazsms_newsletter_get_counts();
	?>
	<div class="farazsms-newsletter-card">
		<h2><?php esc_html_e( 'ارسال پیامک گروهی به مشترکین خبرنامه', 'farazsms' ); ?></h2>
		<p class="farazsms-newsletter-help">
			<?php
			printf(
				/* translators: %s active subscriber count */
				esc_html__( 'تعداد مشترکین فعال: %s', 'farazsms' ),
				'<strong>' . esc_html( number_format_i18n( $counts['active'] ) ) . '</strong>'
			);
			?>
		</p>

		<form id="farazsms-newsletter-send-form" class="farazsms-newsletter-send-form">
			<?php wp_nonce_field( 'farazsms_newsletter_admin', 'farazsms_newsletter_admin_nonce' ); ?>

			<fieldset class="farazsms-newsletter-fieldset">
				<legend><?php esc_html_e( 'نوع ارسال', 'farazsms' ); ?></legend>
				<label><input type="radio" name="mode" value="pattern" checked> <?php esc_html_e( 'الگو (پترن)', 'farazsms' ); ?></label>
				<label><input type="radio" name="mode" value="simple"> <?php esc_html_e( 'متن آزاد', 'farazsms' ); ?></label>
			</fieldset>

			<div class="farazsms-newsletter-field-row farazsms-mode-pattern">
				<label for="farazsms-send-pattern"><?php esc_html_e( 'کد الگو:', 'farazsms' ); ?></label>
				<input id="farazsms-send-pattern" type="text" name="pattern_code" dir="ltr">
				<p class="farazsms-newsletter-help-small">
					<?php esc_html_e( 'الگو می‌تواند متغیر %name% داشته باشد. نام برند را به‌صورت ثابت در متن الگو بنویسید.', 'farazsms' ); ?>
				</p>
			</div>

			<div class="farazsms-newsletter-field-row farazsms-mode-simple" style="display:none">
				<label for="farazsms-send-text"><?php esc_html_e( 'متن پیامک:', 'farazsms' ); ?></label>
				<textarea id="farazsms-send-text" name="text" rows="4" maxlength="500"></textarea>
				<p class="farazsms-newsletter-help-small"><?php esc_html_e( 'ارسال متن آزاد نیازمند تأیید ناظر در پنل فراز اس‌ام‌اس است.', 'farazsms' ); ?></p>
			</div>

			<div class="farazsms-newsletter-send-actions">
				<button type="submit" class="button button-primary"><?php esc_html_e( 'ارسال به همه مشترکین فعال', 'farazsms' ); ?></button>
				<span class="farazsms-newsletter-send-result"></span>
			</div>
		</form>
	</div>
	<?php
}

function farazsms_newsletter_render_settings_tab() {
	$s = farazsms_newsletter_settings();
	?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="farazsms-newsletter-card">
		<input type="hidden" name="action" value="farazsms_newsletter_save_settings">
		<?php wp_nonce_field( 'farazsms_newsletter_settings' ); ?>

		<h2><?php esc_html_e( 'تنظیمات خبرنامه', 'farazsms' ); ?></h2>

		<div class="farazsms-newsletter-settings-grid">
			<label class="farazsms-newsletter-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'فعال‌سازی فرم عضویت', 'farazsms' ); ?></span>
				<label class="farazsms-newsletter-switch">
					<input type="checkbox" class="farazsms-toggle" name="enabled" value="1" <?php checked( $s['enabled'], '1' ); ?>>
					<span><?php esc_html_e( 'فعال', 'farazsms' ); ?></span>
				</label>
			</label>

			<label class="farazsms-newsletter-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'افزودنِ مشترکین به دفترچه‌تلفن فراز', 'farazsms' ); ?></span>
				<label class="farazsms-newsletter-switch">
					<input type="checkbox" class="farazsms-toggle" name="sync_phonebook" value="1" <?php checked( (string) get_option( 'farazsms_newsletter_sync_phonebook', '1' ), '1' ); ?>>
					<span><?php esc_html_e( 'هر مشترکِ جدید به‌صورتِ خودکار در دفترچه‌ی «مشترکین خبرنامه» ذخیره می‌شود.', 'farazsms' ); ?></span>
				</label>
			</label>

			<label class="farazsms-newsletter-setting">
				<span><?php esc_html_e( 'عنوان فرم', 'farazsms' ); ?></span>
				<input type="text" name="form_title" value="<?php echo esc_attr( $s['form_title'] ); ?>">
			</label>

			<label class="farazsms-newsletter-setting">
				<span><?php esc_html_e( 'برچسب فیلد نام', 'farazsms' ); ?></span>
				<input type="text" name="name_label" value="<?php echo esc_attr( $s['name_label'] ); ?>">
			</label>

			<label class="farazsms-newsletter-setting">
				<span><?php esc_html_e( 'برچسب فیلد موبایل', 'farazsms' ); ?></span>
				<input type="text" name="mobile_label" value="<?php echo esc_attr( $s['mobile_label'] ); ?>">
			</label>

			<label class="farazsms-newsletter-setting">
				<span><?php esc_html_e( 'متن دکمه', 'farazsms' ); ?></span>
				<input type="text" name="button_text" value="<?php echo esc_attr( $s['button_text'] ); ?>">
			</label>

			<label class="farazsms-newsletter-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'توضیح زیر عنوان', 'farazsms' ); ?></span>
				<input type="text" name="form_description" value="<?php echo esc_attr( $s['form_description'] ); ?>">
			</label>

			<label class="farazsms-newsletter-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'پیام موفقیت', 'farazsms' ); ?></span>
				<input type="text" name="success_message" value="<?php echo esc_attr( $s['success_message'] ); ?>">
			</label>

			<label class="farazsms-newsletter-setting">
				<span><?php esc_html_e( 'پیام تکراری', 'farazsms' ); ?></span>
				<input type="text" name="duplicate_message" value="<?php echo esc_attr( $s['duplicate_message'] ); ?>">
			</label>

			<label class="farazsms-newsletter-setting">
				<span><?php esc_html_e( 'پیام خطا', 'farazsms' ); ?></span>
				<input type="text" name="error_message" value="<?php echo esc_attr( $s['error_message'] ); ?>">
			</label>

			<label class="farazsms-newsletter-setting">
				<span><?php esc_html_e( 'کد الگوی خوش‌آمدگویی (اختیاری)', 'farazsms' ); ?></span>
				<input type="text" name="welcome_pattern_code" value="<?php echo esc_attr( $s['welcome_pattern_code'] ); ?>" dir="ltr">
				<small class="farazsms-newsletter-help-small">
					<?php esc_html_e( 'متغیر قابل استفاده در متن الگو:', 'farazsms' ); ?>
					<code dir="ltr">%name%</code>
					<br><?php esc_html_e( '⚠ نام برند فروشگاه را به‌صورت ثابت در متن الگو بنویسید (نه به‌صورت متغیر) تا پنل فراز الگو را تأیید کند.', 'farazsms' ); ?>
				</small>
			</label>

				<label class="farazsms-newsletter-setting">
					<span><?php esc_html_e( 'لینک ریدایرکت بعد از عضویت (اختیاری)', 'farazsms' ); ?></span>
					<input type="url" name="redirect_url" value="<?php echo esc_attr( $s['redirect_url'] ); ?>" dir="ltr" placeholder="https://...">
				</label>

				<label class="farazsms-newsletter-setting">
					<span><?php esc_html_e( 'رنگِ دکمه و اکسنت', 'farazsms' ); ?></span>
					<input type="text" class="farazsms-newsletter-color-field" name="primary_color" value="<?php echo esc_attr( $s['primary_color'] ?? '#4571ba' ); ?>" dir="ltr" placeholder="#4571ba">
				</label>

				<label class="farazsms-newsletter-setting">
					<span><?php esc_html_e( 'رنگِ عنوان', 'farazsms' ); ?></span>
					<input type="text" class="farazsms-newsletter-color-field" name="title_color" value="<?php echo esc_attr( $s['title_color'] ?? '#1f2937' ); ?>" dir="ltr" placeholder="#1f2937">
				</label>

				<label class="farazsms-newsletter-setting">
					<span><?php esc_html_e( 'رنگِ پس‌زمینه‌ی فرم', 'farazsms' ); ?></span>
					<input type="text" class="farazsms-newsletter-color-field" name="bg_color" value="<?php echo esc_attr( $s['bg_color'] ?? '#ffffff' ); ?>" dir="ltr" placeholder="#ffffff">
				</label>

				<label class="farazsms-newsletter-setting farazsms-setting-wide">
					<span><?php esc_html_e( 'CSS اختصاصی فرم خبرنامه', 'farazsms' ); ?></span>
					<textarea name="custom_css" rows="8" dir="ltr" spellcheck="false" style="font-family:Menlo,Consolas,monospace;"><?php echo esc_textarea( $s['custom_css'] ?? '' ); ?></textarea>
					<small class="farazsms-newsletter-help-small">
						<?php esc_html_e( 'برای جلوگیری از تداخل، selectorها را با .farazsms-newsletter-form-wrapper شروع کنید. این CSS فقط روی صفحاتی که فرم خبرنامه دارند چاپ می‌شود.', 'farazsms' ); ?>
					</small>
				</label>
			</div>

		<div class="farazsms-newsletter-shortcode-help">
			<strong><?php esc_html_e( 'شورت‌کد نمایش فرم در پست/صفحه/سایدبار:', 'farazsms' ); ?></strong>
			<code dir="ltr">[farazsms_newsletter]</code>
			<p class="farazsms-newsletter-help-small">
				<?php esc_html_e( 'برای نمایش در سایدبار یا فوتر می‌توانید از ویجت «خبرنامه فراز اس‌ام‌اس» در', 'farazsms' ); ?>
				<a href="<?php echo esc_url( admin_url( 'widgets.php' ) ); ?>"><?php esc_html_e( 'ابزارک‌ها', 'farazsms' ); ?></a>
				<?php esc_html_e( 'استفاده کنید.', 'farazsms' ); ?>
			</p>
		</div>

		<div class="farazsms-newsletter-save-row">
			<button type="submit" class="button button-primary"><?php esc_html_e( 'ذخیره تنظیمات', 'farazsms' ); ?></button>
		</div>
	</form>
	<?php
}

function farazsms_newsletter_render_inline_styles() {
	$nonce_admin = wp_create_nonce( 'farazsms_newsletter_admin' );
	?>
	<style>
	/* v3.17.1: Modern card-based design — هماهنگ با ROI/Birthday/Comments
	   تمام class name های قبلی حفظ شده‌اند تا JS و markup نشکنند.
	   v3.17.5: font-family صریح — اگر inherit بگذاریم CSS بعدی override می‌شود. */
	.farazsms-newsletter-wrapper { direction: rtl; font-family: IRANSans, Tahoma, sans-serif; }
	.farazsms-newsletter-wrapper * { box-sizing: border-box; }

	/* Hero عنوان صفحه — به جای h1 لخت */
	.farazsms-newsletter-wrapper .farazsms-newsletter-title-main {
		background: linear-gradient(135deg, #365891 0%, #7c3aed 100%);
		color: #fff;
		margin: 6px 0 20px;
		padding: 22px 28px;
		border-radius: 14px;
		font-size: 20px;
		font-weight: 800;
		box-shadow: 0 8px 24px rgba(67, 56, 202, 0.18);
		position: relative;
		overflow: hidden;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-title-main::before {
		content: '📨';
		position: absolute;
		top: -8px;
		left: -8px;
		font-size: 110px;
		opacity: 0.08;
		line-height: 1;
	}

	/* تب‌های pill-style */
	.farazsms-newsletter-wrapper .farazsms-newsletter-tabs {
		display: flex;
		gap: 8px;
		flex-wrap: wrap;
		border-bottom: 0;
		margin: 0 0 18px;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-tab {
		padding: 9px 20px;
		text-decoration: none;
		color: #475569;
		background: #fff;
		border: 1px solid #cbd5e1;
		border-radius: 8px;
		font-size: 13px;
		font-weight: 600;
		transition: all .15s;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-tab:hover {
		border-color: #94a3b8;
		color: #0f172a;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-tab.is-active {
		background: #0f172a;
		color: #fff;
		border-color: #0f172a;
		box-shadow: 0 4px 12px rgba(15, 23, 42, 0.22);
	}

	/* کارت‌های stat */
	.farazsms-newsletter-wrapper .farazsms-newsletter-stats {
		display: grid;
		grid-template-columns: repeat(4, 1fr);
		gap: 14px;
		margin: 0 0 22px;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-stat {
		background: #fff;
		padding: 18px 16px;
		border: 1.5px solid #e5e7eb;
		border-radius: 12px;
		text-align: center;
		transition: transform .15s, border-color .15s;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-stat:hover {
		transform: translateY(-2px);
		border-color: #c7d2fe;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-stat .num {
		font-size: 28px;
		font-weight: 800;
		line-height: 1;
		color: #0f172a;
		letter-spacing: -0.5px;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-stat .num.farazsms-num-success { color: #16a34a; }
	.farazsms-newsletter-wrapper .farazsms-newsletter-stat .num.farazsms-num-info    { color: #365891; }
	.farazsms-newsletter-wrapper .farazsms-newsletter-stat .num.farazsms-num-muted   { color: #64748b; }
	.farazsms-newsletter-wrapper .farazsms-newsletter-stat .lbl {
		color: #64748b;
		font-size: 12px;
		font-weight: 600;
		margin-top: 8px;
	}

	/* فیلتر بار */
	.farazsms-newsletter-wrapper .farazsms-newsletter-filters {
		background: #fff;
		padding: 16px 18px;
		border: 1px solid #e5e7eb;
		border-radius: 12px;
		margin: 0 0 14px;
		display: flex;
		flex-wrap: wrap;
		gap: 14px;
		align-items: flex-end;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-filters label {
		display: flex;
		flex-direction: column;
		gap: 5px;
		font-size: 12px;
		color: #475569;
		font-weight: 600;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-filters input[type="text"],
	.farazsms-newsletter-wrapper .farazsms-newsletter-filters select {
		min-width: 160px;
		padding: 8px 12px;
		border: 1px solid #cbd5e1;
		border-radius: 7px;
		font-size: 13px;
		color: #0f172a;
		background: #fff;
		transition: border-color .15s, box-shadow .15s;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-filters input[type="text"]:focus,
	.farazsms-newsletter-wrapper .farazsms-newsletter-filters select:focus {
		outline: 0;
		border-color: #365891;
		box-shadow: 0 0 0 3px rgba(67, 56, 202, 0.12);
	}

	/* OVERRIDE دکمه‌های WP در این صفحه — کلید پایان دادن به ظاهر "ویندوز ۹۸" */
	.farazsms-newsletter-wrapper .button,
	.farazsms-newsletter-wrapper button.button {
		background: #fff !important;
		color: #475569 !important;
		border: 1px solid #cbd5e1 !important;
		border-radius: 7px !important;
		padding: 8px 16px !important;
		font-size: 12.5px !important;
		font-weight: 600 !important;
		min-height: auto !important;
		line-height: 1.4 !important;
		text-shadow: none !important;
		box-shadow: none !important;
		cursor: pointer !important;
		transition: all .15s !important;
	}
	.farazsms-newsletter-wrapper .button:hover,
	.farazsms-newsletter-wrapper button.button:hover {
		background: #f8fafc !important;
		border-color: #94a3b8 !important;
		color: #0f172a !important;
	}
	.farazsms-newsletter-wrapper .button-primary,
	.farazsms-newsletter-wrapper button.button-primary {
		background: #365891 !important;
		color: #fff !important;
		border: 1px solid #365891 !important;
		box-shadow: 0 4px 12px rgba(67, 56, 202, 0.22) !important;
	}
	.farazsms-newsletter-wrapper .button-primary:hover,
	.farazsms-newsletter-wrapper button.button-primary:hover {
		background: #263f67 !important;
		border-color: #263f67 !important;
		color: #fff !important;
	}
	.farazsms-newsletter-wrapper .button[disabled],
	.farazsms-newsletter-wrapper button[disabled] {
		opacity: 0.5 !important;
		cursor: not-allowed !important;
	}

	/* bulk bar */
	.farazsms-newsletter-wrapper .farazsms-newsletter-bulk-bar {
		margin: 12px 0;
		display: flex;
		align-items: center;
		gap: 12px;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-bulk-info {
		color: #475569;
		font-size: 12.5px;
		font-weight: 600;
	}

	/* جدول — کاملاً override روی widefat striped */
	.farazsms-newsletter-wrapper .farazsms-newsletter-table {
		background: #fff;
		border: 1px solid #e5e7eb !important;
		border-radius: 12px !important;
		overflow: hidden;
		box-shadow: none !important;
		margin-bottom: 18px;
		width: 100%;
		border-collapse: separate !important;
		border-spacing: 0;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-table thead {
		background: #f8fafc !important;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-table thead th {
		background: #f8fafc !important;
		color: #0f172a !important;
		font-weight: 700 !important;
		font-size: 12.5px !important;
		text-align: right !important;
		padding: 13px 16px !important;
		border-bottom: 1px solid #e5e7eb !important;
		border-top: 0 !important;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-table tbody td {
		padding: 12px 16px !important;
		vertical-align: middle !important;
		font-size: 12.5px !important;
		color: #1f2937 !important;
		border-bottom: 1px solid #f1f5f9 !important;
		background: #fff !important;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-table tbody tr:last-child td {
		border-bottom: 0 !important;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-table tbody tr:hover td {
		background: #f8fafc !important;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-table input[type="checkbox"] {
		margin: 0;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-date-cell {
		direction: ltr;
		font-variant-numeric: tabular-nums;
		color: #64748b !important;
		font-size: 12px !important;
		text-align: right !important;
	}

	/* status pills */
	.farazsms-newsletter-wrapper .farazsms-status {
		display: inline-block;
		padding: 3px 11px;
		border-radius: 14px;
		font-size: 11.5px;
		font-weight: 600;
	}
	.farazsms-newsletter-wrapper .farazsms-status-success { background: #dcfce7; color: #166534; }
	.farazsms-newsletter-wrapper .farazsms-status-muted   { background: #f1f5f9; color: #64748b; }

	/* pagination */
	.farazsms-newsletter-wrapper .farazsms-newsletter-pagination {
		display: flex;
		gap: 8px;
		align-items: center;
		justify-content: center;
		padding: 12px;
		background: #f8fafc;
		border-top: 1px solid #e5e7eb;
		border-radius: 0 0 12px 12px;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-page-info {
		color: #475569;
		font-size: 12.5px;
		font-weight: 600;
	}

	/* کارت اصلی برای send/settings tab */
	.farazsms-newsletter-wrapper .farazsms-newsletter-card {
		background: #fff;
		padding: 24px 28px;
		border: 1.5px solid #e5e7eb;
		border-radius: 14px;
		max-width: none;
		box-shadow: 0 1px 3px rgba(0, 0, 0, 0.02);
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-card h2 {
		margin: 0 0 12px;
		font-size: 17px;
		font-weight: 700;
		color: #0f172a;
		display: flex;
		align-items: center;
		gap: 8px;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-help {
		color: #475569;
		margin: 0 0 18px;
		font-size: 13px;
		line-height: 1.8;
		background: #f8fafc;
		padding: 10px 14px;
		border-radius: 8px;
		border-right: 3px solid #365891;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-help-small {
		color: #64748b;
		font-size: 11.5px;
		margin: 6px 0 0;
		line-height: 1.7;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-help-small code {
		background: #f1f5f9;
		padding: 1px 6px;
		border-radius: 4px;
		direction: ltr;
		display: inline-block;
		font-family: Menlo, Consolas, monospace;
	}

	/* fieldset برای radio mode */
	.farazsms-newsletter-wrapper .farazsms-newsletter-fieldset {
		border: 1.5px solid #c7d2fe;
		border-radius: 10px;
		padding: 14px 18px;
		margin: 0 0 18px;
		background: #fafbff;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-fieldset legend {
		padding: 2px 10px;
		font-weight: 700;
		font-size: 12.5px;
		color: #365891;
		background: #eef2ff;
		border-radius: 5px;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-fieldset label {
		margin-left: 20px;
		font-size: 13px;
		color: #1f2937;
		display: inline-flex;
		align-items: center;
		gap: 6px;
		cursor: pointer;
	}

	/* فیلدهای ورودی فرم */
	.farazsms-newsletter-wrapper .farazsms-newsletter-field-row { margin: 0 0 16px; }
	.farazsms-newsletter-wrapper .farazsms-newsletter-field-row label {
		display: block;
		margin-bottom: 7px;
		font-weight: 600;
		font-size: 13px;
		color: #1f2937;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-field-row input[type="text"],
	.farazsms-newsletter-wrapper .farazsms-newsletter-field-row textarea {
		width: 100%;
		padding: 10px 12px;
		box-sizing: border-box;
		border: 1px solid #cbd5e1;
		border-radius: 8px;
		font-size: 13.5px;
		font-family: inherit;
		line-height: 1.7;
		transition: border-color .15s, box-shadow .15s;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-field-row input[type="text"]:focus,
	.farazsms-newsletter-wrapper .farazsms-newsletter-field-row textarea:focus {
		outline: 0;
		border-color: #365891;
		box-shadow: 0 0 0 3px rgba(67, 56, 202, 0.12);
	}

	/* اکشن‌ها در send tab */
	.farazsms-newsletter-wrapper .farazsms-newsletter-send-actions {
		display: flex;
		align-items: center;
		gap: 14px;
		flex-wrap: wrap;
		padding-top: 8px;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-send-result {
		font-size: 13px;
		font-weight: 600;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-send-result.success { color: #16a34a; }
	.farazsms-newsletter-wrapper .farazsms-newsletter-send-result.error   { color: #b91c1c; }

	/* تنظیمات گرید */
	.farazsms-newsletter-wrapper .farazsms-newsletter-settings-grid {
		display: grid;
		grid-template-columns: 1fr 1fr;
		gap: 16px 20px;
		margin: 14px 0 22px;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-setting {
		display: flex;
		flex-direction: column;
		gap: 6px;
		font-size: 13px;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-setting > span {
		font-weight: 600;
		color: #1f2937;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-setting.farazsms-setting-wide { grid-column: 1 / -1; }
	.farazsms-newsletter-wrapper .farazsms-newsletter-setting input[type="text"],
	.farazsms-newsletter-wrapper .farazsms-newsletter-setting input[type="url"] {
		padding: 9px 12px;
		border: 1px solid #cbd5e1;
		border-radius: 8px;
		font-size: 13px;
		transition: border-color .15s, box-shadow .15s;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-setting input[type="text"]:focus,
	.farazsms-newsletter-wrapper .farazsms-newsletter-setting input[type="url"]:focus {
		outline: 0;
		border-color: #365891;
		box-shadow: 0 0 0 3px rgba(67, 56, 202, 0.12);
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-switch {
		display: inline-flex;
		align-items: center;
		gap: 10px;
		font-size: 13px;
		background: #f8fafc;
		padding: 8px 14px;
		border-radius: 8px;
		border: 1px solid #e5e7eb;
	}

	/* راهنمای shortcode */
	.farazsms-newsletter-wrapper .farazsms-newsletter-shortcode-help {
		background: linear-gradient(135deg, #fef3c7 0%, #fef9c3 100%);
		border: 1.5px solid #fde68a;
		border-radius: 10px;
		padding: 14px 18px;
		margin: 18px 0;
		color: #713f12;
		font-size: 12.5px;
		line-height: 1.8;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-shortcode-help strong { color: #713f12; }
	.farazsms-newsletter-wrapper .farazsms-newsletter-shortcode-help code {
		background: #fff;
		padding: 4px 10px;
		border-radius: 5px;
		border: 1px solid #fcd34d;
		margin-right: 6px;
		font-family: Menlo, Consolas, monospace;
		color: #92400e;
		direction: ltr;
		display: inline-block;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-shortcode-help a {
		color: #92400e;
		text-decoration: underline;
		font-weight: 600;
	}
	.farazsms-newsletter-wrapper .farazsms-newsletter-save-row {
		margin-top: 14px;
		padding-top: 14px;
		border-top: 1px solid #f1f5f9;
		display: flex;
		justify-content: flex-end;
		gap: 10px;
	}

	/* notice موفقیت — کاملاً override روی WP defaults */
	.farazsms-newsletter-wrapper .notice {
		background: #dcfce7 !important;
		border: 1px solid #86efac !important;
		border-right: 3px solid #16a34a !important;
		border-left-width: 1px !important;
		padding: 10px 16px !important;
		border-radius: 8px !important;
		color: #166534 !important;
		margin: 0 0 16px !important;
	}
	.farazsms-newsletter-wrapper .notice p { margin: 0; }

	@media (max-width: 720px) {
		.farazsms-newsletter-wrapper .farazsms-newsletter-stats { grid-template-columns: repeat(2, 1fr); }
		.farazsms-newsletter-wrapper .farazsms-newsletter-settings-grid { grid-template-columns: 1fr; }
		.farazsms-newsletter-wrapper .farazsms-newsletter-filters input[type="text"],
		.farazsms-newsletter-wrapper .farazsms-newsletter-filters select { min-width: 100%; }
	}
	</style>
	<script>
	(function(){
		var ajaxUrl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
		var nonce   = <?php echo wp_json_encode( $nonce_admin ); ?>;

		// Bulk select + delete on the list tab.
		var selectAll = document.getElementById('farazsms-newsletter-select-all');
		var rows = document.querySelectorAll('.farazsms-newsletter-row');
		var deleteBtn = document.querySelector('.farazsms-newsletter-bulk-delete');
		var bulkInfo = document.querySelector('.farazsms-newsletter-bulk-info');
		function updateBulkState(){
			var checked = Array.prototype.filter.call(rows, function(c){ return c.checked; });
			if (deleteBtn) {
				deleteBtn.disabled = checked.length === 0;
				if (bulkInfo) {
					bulkInfo.textContent = checked.length ? (checked.length + ' ردیف انتخاب شده') : '';
				}
			}
		}
		if (selectAll) {
			selectAll.addEventListener('change', function(){
				Array.prototype.forEach.call(rows, function(c){ c.checked = selectAll.checked; });
				updateBulkState();
			});
		}
		Array.prototype.forEach.call(rows, function(c){ c.addEventListener('change', updateBulkState); });
		if (deleteBtn) {
			deleteBtn.addEventListener('click', function(){
				var checked = Array.prototype.filter.call(rows, function(c){ return c.checked; });
				if (checked.length === 0) return;
				if (!confirm('حذف ' + checked.length + ' مشترک — مطمئن هستید؟')) return;
				var data = new FormData();
				data.append('action', 'farazsms_newsletter_delete');
				data.append('nonce', nonce);
				checked.forEach(function(c){ data.append('ids[]', c.value); });
				deleteBtn.disabled = true;
				fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: data })
					.then(function(r){ return r.json(); })
					.then(function(json){
						if (json.success) {
							window.location.reload();
						} else {
							alert((json.data && json.data.message) || 'خطا در حذف.');
							deleteBtn.disabled = false;
						}
					})
					.catch(function(){ alert('خطا در ارتباط با سرور.'); deleteBtn.disabled = false; });
			});
		}

		// Send tab — mode toggle + AJAX submit.
		var modeRadios = document.querySelectorAll('#farazsms-newsletter-send-form input[name="mode"]');
		var modePattern = document.querySelector('#farazsms-newsletter-send-form .farazsms-mode-pattern');
		var modeSimple  = document.querySelector('#farazsms-newsletter-send-form .farazsms-mode-simple');
		Array.prototype.forEach.call(modeRadios, function(r){
			r.addEventListener('change', function(){
				if (modePattern) modePattern.style.display = (r.value === 'pattern' && r.checked) ? '' : 'none';
				if (modeSimple)  modeSimple.style.display  = (r.value === 'simple'  && r.checked) ? '' : 'none';
			});
		});
		var sendForm = document.getElementById('farazsms-newsletter-send-form');
		if (sendForm) {
			sendForm.addEventListener('submit', function(ev){
				ev.preventDefault();
				if (!confirm('ارسال پیامک به همه مشترکین فعال — آیا مطمئن هستید؟')) return;
				var resultEl = sendForm.querySelector('.farazsms-newsletter-send-result');
				var btn = sendForm.querySelector('button[type="submit"]');
				var fd = new FormData(sendForm);
				fd.append('action', 'farazsms_newsletter_send_bulk');
				fd.append('nonce', nonce);
				btn.disabled = true;
				resultEl.className = 'farazsms-newsletter-send-result';
				resultEl.textContent = 'در حال ارسال...';
				fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
					.then(function(r){ return r.json(); })
					.then(function(json){
						resultEl.className = 'farazsms-newsletter-send-result ' + (json.success ? 'success' : 'error');
						resultEl.textContent = (json.data && json.data.message) || 'انجام شد.';
					})
					.catch(function(){ resultEl.className = 'farazsms-newsletter-send-result error'; resultEl.textContent = 'خطا در ارتباط با سرور.'; })
					.then(function(){ btn.disabled = false; });
			});
		}
	})();
	</script>
	<?php
}
