<?php
/**
 * تنظیماتِ کانالِ بله در صفحه‌ی تنظیماتِ اصلی — کارتِ «کلیدِ دسترسیِ بله» + نوارِ وضعیتِ اتصال.
 *
 * چرا این‌جا (نه در فایلِ مشروطِ ادمین)؟ فیلدِ کلید باید «پیش از تنظیم‌شدنِ کلید» هم دیده شود
 * تا واردکردنِ اولین کلید ممکن باشد؛ پس این فایل همیشه بار می‌شود (استثنای آگاهانه‌ی AD-8،
 * دقیقاً مثلِ فیلدِ کلیدِ پیامک). بخشِ محصورِ «ارسال در بله» (تیکِ سرویس‌ها) در
 * farazsms-bale-admin.php است که فقط وقتی کلید تنظیم است بار می‌شود.
 *
 * ذخیره‌ی AJAX (یک‌دست با بقیه‌ی صفحه‌ی تنظیمات، بدونِ رفرش). کلید با فیلترِ رمزنگاریِ
 * bale-config شفاف رمزنگاری/ماسک می‌شود؛ خالی=حفظِ کلیدِ فعلی.
 *
 * نوارِ وضعیت: بررسیِ اتصال (GET /balance) هرگز رویِ رِندر بلاک نمی‌کند — از transient
 * کش می‌خواند و به‌صورتِ lazy با AJAX تازه می‌شود ([[no-blocking-external-calls]]).
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_BALE_CONN_TRANSIENT = 'farazsms_bale_conn_state';
const FARAZSMS_BALE_CONN_TTL       = 600; // ۱۰ دقیقه

/**
 * استایلِ بله را فقط روی صفحه‌ی تنظیمات و صفحه‌ی «ارسال در بله» بار می‌کند (خودکفا، بدونِ
 * دستکاریِ allowlistِ هسته).
 */
add_action( 'admin_enqueue_scripts', 'farazsms_bale_enqueue_admin_css' );
function farazsms_bale_enqueue_admin_css( $hook = '' ) {
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	if ( $page !== 'farazsms-settings' && $page !== 'farazsms-bale' ) {
		return;
	}
	if ( ! defined( 'FARAZSMS_CORE_CSS' ) ) {
		return;
	}
	$ver = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1.0.0';
	wp_enqueue_style( 'farazsms-bale-admin', FARAZSMS_CORE_CSS . 'farazsms-bale-admin.css', array(), $ver, 'all' );
}

/**
 * کارتِ «کلیدِ دسترسیِ بله» را زیرِ تبِ «تنظیمات پنل پیامکی» رندر می‌کند.
 */
add_action( 'farazsms_settings_page_extra_sections', 'farazsms_bale_render_key_card' );
function farazsms_bale_render_key_card() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	// kill-switch: اگر بله کاملاً خاموش است، حتی کارتِ کلید هم نمایش داده نشود (هیچ اثری از بله).
	if ( ! farazsms_bale_active() ) {
		return;
	}
	$is_set = function_exists( 'farazsms_bale_is_configured' ) && farazsms_bale_is_configured();
	$nonce  = wp_create_nonce( 'farazsms_bale_settings' );
	?>
	<div class="farazsms-bale-card" id="farazsms-bale-key-card">
		<div class="farazsms-bale-card__head">
			<span class="farazsms-bale-card__logo">بله</span>
			<div>
				<h3 class="farazsms-bale-card__title">ارسال در پیام‌رسانِ بله <span class="farazsms-bale-beta">نسخه‌ی اولیه · هم‌اکنون فعال</span></h3>
				<p class="farazsms-bale-card__desc">
					پیام‌های افزونه را (به‌جز کدِ تاییدِ ورود) علاوه بر پیامک، در بله هم بفرستید.
				</p>
			</div>
		</div>

		<div class="farazsms-bale-invite">
			✅ کانالِ بله راه‌اندازی شده و <b>همین حالا آماده‌ی استفاده است</b>. کلیدِ دسترسی را از
			<a href="https://bale.farazsms.com" target="_blank" rel="noopener">bale.farazsms.com</a>
			بگیرید، در پنلِ بله اعتبار بگذارید و پیام‌هایتان را علاوه بر پیامک در بله هم بفرستید.
			<span class="farazsms-bale-invite__soft">این نسخه‌ی اولیه است و روزبه‌روز کامل‌تر می‌شود؛ اگر بازخوردی داشتید خوشحال می‌شویم بشنویم.</span>
		</div>

		<?php echo farazsms_bale_status_bar_html(); // نوارِ وضعیتِ اتصال (کش‌شده؛ با AJAX تازه می‌شود) ?>

		<form id="farazsms-bale-key-form" class="farazsms-bale-form" onsubmit="return false;">
			<input type="hidden" name="farazsms_bale_nonce" value="<?php echo esc_attr( $nonce ); ?>">
			<label class="farazsms-bale-label" for="farazsms-bale-apikey">کلیدِ دسترسیِ بله</label>
			<div class="farazsms-bale-field-row">
				<input type="password" id="farazsms-bale-apikey" name="bale_apikey" value="" autocomplete="off"
					class="farazsms-bale-input"
					placeholder="<?php echo $is_set ? esc_attr( '•••••••••• ذخیره شده — برای تغییر کلید جدید را وارد کنید' ) : esc_attr( 'کلیدِ دسترسیِ بله را وارد کنید' ); ?>">
				<button type="button" class="farazsms-bale-btn" id="farazsms-bale-save-key">ذخیره</button>
			</div>
			<p class="farazsms-bale-hint">
				کلید امن (رمزنگاری‌شده) ذخیره می‌شود و در صفحه نمایش داده نمی‌شود. برای حفظِ کلیدِ فعلی، این فیلد را خالی بگذارید.
				<?php if ( $is_set ) : ?>
					تنظیمِ سرویس‌ها در صفحه‌ی «<a href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-bale' ) ); ?>">ارسال در بله</a>».
				<?php endif; ?>
			</p>
			<span class="farazsms-bale-resp" id="farazsms-bale-key-resp" role="status"></span>
		</form>
	</div>
	<?php
	farazsms_bale_print_inline_js();
}

/**
 * HTMLِ نوارِ وضعیتِ اتصالِ بله. از transient کش می‌خواند (بدونِ HTTPِ بلاک‌کننده)؛ اگر
 * کش نبود، حالتِ «در حال بررسی» را می‌گذارد و JS با AJAX آن را تازه می‌کند.
 *
 * @return string
 */
function farazsms_bale_status_bar_html() {
	$configured = function_exists( 'farazsms_bale_is_configured' ) && farazsms_bale_is_configured();
	if ( ! $configured ) {
		return '<div class="farazsms-bale-status farazsms-bale-status--muted" id="farazsms-bale-status">'
			. 'اتصال به سرویسِ بله: <b>تنظیم‌نشده</b> — کلیدِ دسترسی را وارد کنید.'
			. '</div>';
	}
	$state = get_transient( FARAZSMS_BALE_CONN_TRANSIENT );
	if ( $state === 'active' ) {
		$cls = 'success';
		$txt = 'اتصال به سرویسِ بله <b>فعال</b> است.';
	} elseif ( $state === 'inactive' ) {
		$cls = 'danger';
		$txt = 'اتصال به سرویسِ بله <b>برقرار نشد</b> — کلید را بررسی کنید.';
	} else {
		$cls = 'info';
		$txt = 'در حال بررسیِ اتصال به بله…';
	}
	return '<div class="farazsms-bale-status farazsms-bale-status--' . esc_attr( $cls ) . '" id="farazsms-bale-status" data-check="1">'
		. $txt
		. ' <a href="#" class="farazsms-bale-recheck" id="farazsms-bale-recheck">بررسیِ دوباره</a>'
		. '</div>';
}

/**
 * AJAX: ذخیره‌ی کلیدِ بله (خالی=حفظ؛ فیلترِ bale-config رمزنگاری می‌کند).
 */
add_action( 'wp_ajax_farazsms_bale_save_key', 'farazsms_bale_ajax_save_key' );
function farazsms_bale_ajax_save_key() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی مجاز نیست' ) );
	}
	check_ajax_referer( 'farazsms_bale_settings', 'farazsms_bale_nonce' );

	$raw = isset( $_POST['bale_apikey'] ) ? trim( (string) wp_unslash( $_POST['bale_apikey'] ) ) : '';
	// خالی = حفظِ کلیدِ فعلی (فیلترِ pre_update هم این را تضمین می‌کند؛ این‌جا هم صریح).
	if ( $raw !== '' ) {
		update_option( 'farazsms_bale_apikey', $raw );
		delete_transient( FARAZSMS_BALE_CONN_TRANSIENT ); // وضعیت را دوباره بسنج
	}
	$configured = function_exists( 'farazsms_bale_is_configured' ) && farazsms_bale_is_configured();
	wp_send_json_success( array(
		'message'    => $configured ? '✓ کلیدِ بله ذخیره شد.' : 'کلیدی ذخیره نشده است.',
		'configured' => $configured,
	) );
}

/**
 * AJAX: بررسیِ زنده‌ی اتصال به بله (GET /balance) + کشِ نتیجه در transient.
 * این‌جا HTTP انجام می‌شود ولی خارج از مسیرِ رِندرِ صفحه (فراخوانیِ AJAXِ جدا)، پس بلاک نیست.
 */
add_action( 'wp_ajax_farazsms_bale_check_conn', 'farazsms_bale_ajax_check_conn' );
function farazsms_bale_ajax_check_conn() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی مجاز نیست' ) );
	}
	check_ajax_referer( 'farazsms_bale_settings', 'farazsms_bale_nonce' );

	if ( ! farazsms_bale_is_configured() ) {
		wp_send_json_success( array( 'state' => 'muted', 'text' => 'اتصال به سرویسِ بله: تنظیم‌نشده' ) );
	}
	$force = ! empty( $_POST['force'] );
	// کشِ transient را محترم بشمار: اگر force نیست و وضعیتِ تازه‌ای در کش هست، بدونِ HTTPِ زنده
	// همان را برگردان (وگرنه هر بارِ صفحه یک GET /balance با تایم‌اوتِ ۸ثانیه‌ای می‌زد).
	if ( ! $force ) {
		$cached = get_transient( FARAZSMS_BALE_CONN_TRANSIENT );
		if ( $cached === 'active' || $cached === 'inactive' ) {
			wp_send_json_success( array(
				'state'   => $cached,
				'balance' => '',
				'text'    => $cached === 'active' ? 'اتصال به سرویسِ بله فعال است.' : 'اتصال به سرویسِ بله برقرار نشد — کلید را بررسی کنید.',
			) );
		}
	} else {
		delete_transient( FARAZSMS_BALE_CONN_TRANSIENT );
	}
	$res  = farazsms_bale_request( 'GET', 'balance' );
	$http = isset( $res['http_code'] ) ? (int) $res['http_code'] : 0;
	// «اتصال» یعنی کلید احراز شد: پاسخِ HTTP 200 کافی است، حتی اگر envelopeِ GET /balance شکلِ
	// {status:success} نداشته باشد (شکلِ رایجِ منابعِ GET). وگرنه حسابِ سالم «برقرار نشد» نشان می‌داد.
	$state = ( ( isset( $res['result'] ) && $res['result'] === 'success' ) || $http === 200 ) ? 'active' : 'inactive';
	set_transient( FARAZSMS_BALE_CONN_TRANSIENT, $state, FARAZSMS_BALE_CONN_TTL );

	$balance = '';
	if ( $state === 'active' ) {
		// از بدنه‌ی «کامل» decode کن (نه detailِ بریده‌ی ۲۵۵ کاراکتری).
		$data = json_decode( (string) ( $res['body'] ?? '' ), true );
		if ( is_array( $data ) ) {
			$raw = isset( $data['data']['balance'] ) ? $data['data']['balance'] : ( isset( $data['balance'] ) ? $data['balance'] : '' );
			// ارقامِ لاتین/فارسی/عربی + جداکننده نگه داشته می‌شوند؛ markup/تگ حذف می‌شود (ضدِ XSS در .html()).
			$balance = is_scalar( $raw ) ? preg_replace( '/[^0-9۰-۹٠-٩.,\-\s]/u', '', (string) $raw ) : '';
			$balance = trim( (string) $balance );
		}
	}
	wp_send_json_success( array(
		'state'   => $state,
		'balance' => $balance,
		'text'    => $state === 'active' ? 'اتصال به سرویسِ بله فعال است.' : 'اتصال به سرویسِ بله برقرار نشد — کلید را بررسی کنید.',
	) );
}

/**
 * JSِ خطیِ خودکفا برای کارت/نوارِ بله (بدونِ افزودن به enqueueِ هسته). یک‌بار چاپ می‌شود.
 */
function farazsms_bale_print_inline_js() {
	static $printed = false;
	if ( $printed ) {
		return;
	}
	$printed = true;
	$nonce   = wp_create_nonce( 'farazsms_bale_settings' );
	?>
	<script>
	(function($){
		if (!$) { return; }
		var BALE_NONCE = <?php echo wp_json_encode( $nonce ); ?>;
		function setStatus(state, text){
			var $b = $('#farazsms-bale-status');
			if (!$b.length) { return; }
			$b.removeClass('farazsms-bale-status--success farazsms-bale-status--danger farazsms-bale-status--info farazsms-bale-status--muted');
			var map = { active:'success', inactive:'danger', muted:'muted' };
			$b.addClass('farazsms-bale-status--' + (map[state] || 'info'));
			$b.html(text + ' <a href="#" class="farazsms-bale-recheck" id="farazsms-bale-recheck">بررسیِ دوباره</a>');
		}
		function checkConn(force){
			var $b = $('#farazsms-bale-status');
			if (!$b.length || !$b.data('check')) { return; }
			$.post(ajaxurl, { action:'farazsms_bale_check_conn', farazsms_bale_nonce:BALE_NONCE, force: force?1:0 })
			 .done(function(r){
				if (r && r.success && r.data){
					var t = r.data.text + (r.data.balance ? ' (اعتبار: ' + r.data.balance + ')' : '');
					setStatus(r.data.state, t);
				}
			 });
		}
		$(function(){ checkConn(false); });
		$(document).on('click', '#farazsms-bale-recheck', function(e){ e.preventDefault(); setStatus('info','در حال بررسی…'); checkConn(true); });
		$(document).on('click', '#farazsms-bale-save-key', function(){
			var $btn = $(this), $resp = $('#farazsms-bale-key-resp');
			$btn.prop('disabled', true).addClass('is-loading');
			$resp.text('در حال ذخیره…').removeClass('is-ok is-err');
			$.post(ajaxurl, {
				action:'farazsms_bale_save_key',
				farazsms_bale_nonce: $('#farazsms-bale-key-form input[name=farazsms_bale_nonce]').val() || BALE_NONCE,
				bale_apikey: $('#farazsms-bale-apikey').val()
			}).done(function(r){
				if (r && r.success){
					$resp.text(r.data.message).addClass('is-ok');
					$('#farazsms-bale-apikey').val('');
					if (r.data.configured){ $('#farazsms-bale-status').attr('data-check','1'); checkConn(true); }
				} else {
					$resp.text((r && r.data && r.data.message) ? r.data.message : 'خطا در ذخیره').addClass('is-err');
				}
			}).fail(function(){ $resp.text('خطا در ارتباط با سرور').addClass('is-err'); })
			  .always(function(){ $btn.prop('disabled', false).removeClass('is-loading'); });
		});
	})(window.jQuery);
	</script>
	<?php
}
