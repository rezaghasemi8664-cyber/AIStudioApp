<?php
/**
 * فراز بین — لودرِ ماژول (افزونه = منبعِ دادهٔ موتورِ مقایسه‌ی قیمت).
 *
 * طبقِ plugin-integration-guide (قراردادِ واقعی و تست‌شده):
 *   - POST /api/register       → seller_site_id + token
 *   - POST /api/webhook/delta  → پوشِ هر محصول (هدرِ X-Farazbin-Token)
 * بدونِ فیدِ Pull و بدونِ HMAC.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

$farazbin_dir = FARAZSMS_CORE_INC . 'farazbin/';
require_once $farazbin_dir . 'farazbin-config.php';
require_once $farazbin_dir . 'farazbin-register.php';
require_once $farazbin_dir . 'farazbin-push.php';
require_once $farazbin_dir . 'farazbin-admin.php';

// v3.21.x: ماژول‌های قدیمیِ بی‌ضرر غیرفعال شدند. قراردادِ واقعیِ فرازبین فقط push است
// (POST /api/register + /api/webhook/delta با هدرِ X-Farazbin-Token) — نه فید Pull و نه
// HMAC. این دو فایل (از قراردادِ قدیم) بلااستفاده‌اند و دیگر بارگذاری نمی‌شوند:
//   require_once $farazbin_dir . 'farazbin-hmac.php';
//   require_once $farazbin_dir . 'farazbin-feed.php';
