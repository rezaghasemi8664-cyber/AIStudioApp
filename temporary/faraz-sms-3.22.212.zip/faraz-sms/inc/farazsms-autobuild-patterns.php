<?php
/**
 * ساختِ خودکارِ پترن‌های پیش‌فرض (فقط موارد پرکاربرد).
 *
 * v3.22.56: به‌درخواستِ تیمِ مانیتورینگ، ساختِ خودکار فقط برای این ۴ مورد است (بقیه فقط دستی با
 * دکمه‌ی «ساخت الگو» ساخته می‌شوند):
 *   ۱) سبدِ خریدِ رهاشده
 *   ۲) سفارشِ بومی — پیامکِ مشتری، وضعیتِ «در حال انجام» (processing)
 *   ۳) سفارشِ بومی — پیامکِ مدیر، وضعیتِ «در حال انجام»
 *   ۴) کدِ رهگیری — فقط «پست»
 * به‌محضِ در دسترس بودنِ کلیدِ دسترسی (فعال‌سازیِ افزونه یا واردکردنِ کلید) یک‌بار اجرا و لَچ می‌شود.
 *
 * اصول:
 *  - non-blocking: ساختِ پترن (HTTP) در یک رویدادِ cronِ فوری انجام می‌شود، نه در مسیرِ
 *    بارگذاریِ صفحه‌ی ادمین.
 *  - idempotent: فقط پترن‌هایی که هنوز کد ندارند ساخته می‌شوند.
 *  - متغیرهای متنِ پیش‌فرض عمداً با دو کاراکترِ هگز شروع نمی‌شوند (تا پنلِ فراز خرابشان نکند).
 *  - برندِ سایت به‌صورتِ خودکار ته‌ی پترن افزوده می‌شود (در farazsms_create_pattern).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** متن‌های پیش‌فرضِ امن. */
function farazsms_autobuild_default_messages() {
	return array(
		'comment_admin'        => "دیدگاهِ جدیدی از طرفِ %comment_author% (%comment_author_email%) ثبت شد.",
		'comment_user_approve' => "%comment_author% عزیز، وضعیتِ دیدگاهِ شما: %status%\nمشاهده:\n%comment_link%",
		'comment_user_reply'   => "%comment_author% عزیز، به دیدگاهِ شما پاسخ داده شد.\nمشاهده:\n%comment_link%",
		'abandoned'            => "%first_name% عزیز، سبدِ خریدِ شما هنوز تکمیل نشده است.\nتعدادِ اقلام: %items_count% — مبلغ: %total_price%\nبرای ادامه‌ی خرید کلیک کنید:\n%resume_url%",
		'notify'               => "%product_name% که منتظرش بودید موجود شد!\nقیمت: %product_price%\nمشاهده و خرید:\n%product_link%",
		'cashback'             => function_exists( 'farazsms_cashback_default_pattern_message' ) ? farazsms_cashback_default_pattern_message() : "مشتری عزیز، %balance% تومان اعتبار کش‌بک شما تا %days_left% روز دیگر منقضی می‌شود.\nبرای استفاده، خرید بعدی خود را تکمیل کنید.\n" . get_site_url(),
		'survey_reward'        => function_exists( 'farazsms_survey_default_reward_template' ) ? farazsms_survey_default_reward_template() : "ممنون که نظرت رو ثبت کردی.\nکد تخفیف خرید بعدی شما: %code%\nاعتبار تا: %expire%\n" . get_site_url(),
	);
}

/** آیا کلیدِ دسترسی ست شده است؟ */
function farazsms_autobuild_has_key() {
	return function_exists( 'farazsms_get_apikey' ) && trim( (string) farazsms_get_apikey() ) !== '';
}

/** زمان‌بندیِ ساختِ خودکار (non-blocking) — هنگامِ ادمین، یا واردکردنِ کلید. */
function farazsms_autobuild_maybe_schedule() {
	// v3.22.56: فقط یک فلگ — autobuild به‌شدت محدود شد (فقط سبدِ رها‌شده + سفارشِ بومیِ «در حال
	// انجام» + کدِ رهگیریِ پست). فلگ‌های cashback/survey_reward دیگر چک نمی‌شوند.
	if ( get_option( 'farazsms_autobuild_done_v1' ) === '1' ) {
		return;
	}
	if ( ! farazsms_autobuild_has_key() ) {
		return; // بدونِ کلید نمی‌توان ساخت؛ با واردکردنِ کلید دوباره بررسی می‌شود.
	}
	if ( ! wp_next_scheduled( 'farazsms_autobuild_patterns_event' ) ) {
		wp_schedule_single_event( time() + 5, 'farazsms_autobuild_patterns_event' );
	}
}
add_action( 'admin_init', 'farazsms_autobuild_maybe_schedule' );
add_action( 'update_option_farazsms_apikey', 'farazsms_autobuild_maybe_schedule' );
add_action( 'add_option_farazsms_apikey', 'farazsms_autobuild_maybe_schedule' );

/** ساختِ یک پترنِ جدید و برگرداندنِ کد (یا '' در خطا). */
function farazsms_autobuild_create( $message, $section ) {
	$desc = farazsms_pattern_brand_description( $section );
	$resp = farazsms_create_pattern( farazsms_pattern_hexsafe_build( $section, $message ), farazsms_autobuild_pattern_category( $section ), $desc );
	return farazsms_autobuild_extract_code( $resp );
}

/**
 * v3.21.96: نگاشتِ متغیرهای «هگز‌ناامن» به نام‌های امن پیش از ثبتِ پترن در پنلِ فراز.
 * پنل هر متغیری که با دو کاراکترِ هگز (0-9a-f) شروع شود را خراب می‌کند؛ مثلاً %balance% (ba)
 * و %days_left% (da) در کش‌بک → پیامکِ خالی. متنِ نمایشیِ کاربر تغییر نمی‌کند؛ فقط متنی که به
 * API می‌رود امن می‌شود. (الگو مثلِ لید مگنت که به %var1%/%var2% نگاشت می‌کند.)
 *
 * @param string $feature_or_section  نامِ بخش/فیچر
 * @param string $text                متنِ پترن
 * @return string
 */
function farazsms_pattern_hexsafe_build( $feature_or_section, $text ) {
	$map = array(
		'cashback' => array(
			'%balance%'   => '%var1%',
			'%days_left%' => '%var2%',
			'{balance}'   => '%var1%',
			'{days_left}' => '%var2%',
		),
	);
	$key = (string) $feature_or_section;
	if ( isset( $map[ $key ] ) ) {
		return strtr( (string) $text, $map[ $key ] );
	}
	return (string) $text;
}

function farazsms_autobuild_pattern_category( $section ) {
	$section = sanitize_key( (string) $section );
	if ( in_array( $section, array( 'cashback', 'birthday', 'survey' ), true ) || strpos( $section, 'birthday' ) === 0 ) {
		return 2;
	}
	if ( in_array( $section, array( 'order', 'orders', 'woocommerce_order' ), true ) ) {
		return 3;
	}
	if ( $section === 'otp' || $section === 'login' ) {
		return 1;
	}
	return 255;
}

/** استخراجِ کدِ پترن از پاسخِ API. */
function farazsms_autobuild_extract_code( $resp ) {
	$data = is_string( $resp ) ? json_decode( $resp, true ) : $resp;
	if ( is_array( $data ) ) {
		if ( ! empty( $data['data']['code'] ) ) {
			return (string) $data['data']['code'];
		}
		if ( ! empty( $data['data'] ) && is_string( $data['data'] ) ) {
			return (string) $data['data'];
		}
		if ( ! empty( $data['code'] ) ) {
			return (string) $data['code'];
		}
	}
	return '';
}

/** اجرای ساختِ خودکار (در رویدادِ cron — خارج از مسیرِ صفحه). */
function farazsms_autobuild_patterns_run() {
	if ( ! farazsms_autobuild_has_key() || ! function_exists( 'farazsms_create_pattern' ) ) {
		return;
	}
	$msgs = farazsms_autobuild_default_messages();

	// v3.22.56: به‌درخواستِ تیمِ مانیتورینگ، ساختِ خودکارِ پترن فقط برای موارد پرکاربرد است:
	// (۱) سبدِ خریدِ رهاشده  (۲و۳) سفارشِ بومی «در حال انجام» مشتری+مدیر  (۴) کدِ رهگیریِ پست.
	// دیدگاه/موجودشد/نظرسنجی/کش‌بک/پاداش دیگر خودکار ساخته نمی‌شوند (دستی با دکمه‌ی «ساخت الگو»).

	// ── (۱) سبدِ خریدِ رهاشده ──
	$ab = get_option( 'farazsms_abandoned_settings', array() );
	if ( ! is_array( $ab ) ) {
		$ab = array();
	}
	if ( trim( (string) ( $ab['message'] ?? '' ) ) === '' ) {
		$ab['message'] = $msgs['abandoned'];
	}
	// v3.22.55: autobuild عمداً کلیدِ enabled را دست نمی‌زند — کارش فقط ساختِ متن/پترن است، نه
	// فعال‌سازیِ فیچر. اگر مدیر فیچر را خاموش کرده (enabled='0')، باید خاموش بماند؛ اگر هرگز تنظیم
	// نشده، پیش‌فرضِ روشن هنگامِ خواندن اعمال می‌شود. قبلاً این‌جا enabled='1' نوشته می‌شد که ریسکِ
	// «فعال‌شدنِ دوباره پس از آپدیت/ریست» را داشت (گزارشِ کاربر: سبدِ رها‌شده خودش روشن می‌شود).
	if ( trim( (string) ( $ab['pattern_code'] ?? '' ) ) === '' ) {
		$code = farazsms_autobuild_create( $ab['message'], 'abandoned' );
		if ( $code !== '' ) {
			$ab['pattern_code'] = $code;
		}
	}
	update_option( 'farazsms_abandoned_settings', $ab, false );

	// ── (۲و۳) سفارشِ بومی — فقط وضعیتِ «در حال انجام» (processing)، مشتری + مدیر ──
	if ( defined( 'FARAZSMS_ORDER_SMS_OPTION' ) ) {
		$os = get_option( FARAZSMS_ORDER_SMS_OPTION, array() );
		if ( ! is_array( $os ) ) {
			$os = array();
		}
		if ( ! isset( $os['statuses'] ) || ! is_array( $os['statuses'] ) ) {
			$os['statuses'] = array();
		}
		if ( ! isset( $os['statuses']['processing'] ) || ! is_array( $os['statuses']['processing'] ) ) {
			$os['statuses']['processing'] = array();
		}
		$row = $os['statuses']['processing'];
		if ( trim( (string) ( $row['customer_message'] ?? '' ) ) === '' ) {
			$row['customer_message'] = farazsms_order_sms_default_customer_message();
		}
		if ( trim( (string) ( $row['admin_message'] ?? '' ) ) === '' ) {
			$row['admin_message'] = farazsms_order_sms_default_admin_message();
		}
		if ( trim( (string) ( $row['customer_pattern'] ?? '' ) ) === '' && trim( (string) ( $row['customer_message'] ?? '' ) ) !== '' ) {
			$code = farazsms_autobuild_create( $row['customer_message'], 'orders' );
			if ( $code !== '' ) {
				$row['customer_pattern'] = $code;
			}
		}
		if ( trim( (string) ( $row['admin_pattern'] ?? '' ) ) === '' && trim( (string) ( $row['admin_message'] ?? '' ) ) !== '' ) {
			$code = farazsms_autobuild_create( $row['admin_message'], 'orders' );
			if ( $code !== '' ) {
				$row['admin_pattern'] = $code;
			}
		}
		// پیش‌فرض: تیکِ مشتری و مدیرِ «در حال انجام» فعال (فقط اگر قبلاً تنظیم نشده — انتخابِ مدیر حفظ می‌شود).
		if ( ! isset( $row['customer_enabled'] ) ) {
			$row['customer_enabled'] = '1';
		}
		if ( ! isset( $row['admin_enabled'] ) ) {
			$row['admin_enabled'] = '1';
		}
		$os['statuses']['processing'] = $row;
		update_option( FARAZSMS_ORDER_SMS_OPTION, $os, false );
	}

	// ── (۴) کدِ رهگیری — فقط «پست» ──
	if ( trim( (string) get_option( 'farazsms_message_post', '' ) ) === '' ) {
		update_option( 'farazsms_message_post', "مشتری گرامی، سفارش %order_id% ارسال شد.\nکدِ رهگیریِ پستی: %tracking_code%", false );
	}
	if ( trim( (string) get_option( 'farazsms_pattern_post', '' ) ) === '' ) {
		$code = farazsms_autobuild_create( (string) get_option( 'farazsms_message_post', '' ), 'orders' );
		if ( $code !== '' ) {
			update_option( 'farazsms_pattern_post', $code, false );
		}
	}

	update_option( 'farazsms_autobuild_done_v1', '1', false );
}
add_action( 'farazsms_autobuild_patterns_event', 'farazsms_autobuild_patterns_run' );

// v3.22.56: توابعِ خودکارِ کش‌بک و پاداشِ نظرسنجی حذف شدند — این پترن‌ها دیگر خودکار ساخته
// نمی‌شوند (فقط دستی با دکمه‌ی «ساخت الگو» در همان بخش‌ها). پترن‌های موجود دست‌نخورده می‌مانند.

/* ─────────────── AJAX: ساخت/به‌روزرسانیِ پترنِ سبد رهاشده و موجود شد خبرم کن ─────── */

add_action( 'wp_ajax_farazsms_feature_build_pattern', 'farazsms_feature_build_pattern_ajax' );
/**
 * خواندنِ «سطلِ پترن» از داخلِ تنظیمات. مسیرِ خالی یعنی خودِ تنظیمات (رفتارِ قدیمی).
 *
 * @param array $settings
 * @param array $path
 * @return array
 */
function farazsms_feature_pattern_bucket( $settings, $path ) {
	$node = $settings;
	foreach ( $path as $key ) {
		if ( ! is_array( $node ) || ! isset( $node[ $key ] ) ) {
			return array();
		}
		$node = $node[ $key ];
	}
	return is_array( $node ) ? $node : array();
}

/**
 * نوشتنِ سطل در همان مسیر و برگرداندنِ کلِ تنظیمات.
 *
 * @param array $settings
 * @param array $path
 * @param array $bucket
 * @return array
 */
function farazsms_feature_pattern_bucket_set( $settings, $path, $bucket ) {
	if ( empty( $path ) ) {
		return is_array( $bucket ) ? $bucket : array();
	}
	if ( ! is_array( $settings ) ) {
		$settings = array();
	}
	// ارجاع‌محور تا شاخه‌های میانی در صورتِ نبود ساخته شوند.
	$node = &$settings;
	foreach ( $path as $key ) {
		if ( isset( $node[ $key ] ) && ! is_array( $node[ $key ] ) ) {
			// کلیدِ میانی از قبل مقدارِ غیرآرایه دارد: به‌جای بازنویسیِ بی‌صدای
			// داده‌ی موجود، دست نمی‌زنیم.
			return $settings;
		}
		if ( ! isset( $node[ $key ] ) ) {
			$node[ $key ] = array();
		}
		$node = &$node[ $key ];
	}
	$node = $bucket;
	unset( $node );
	return $settings;
}

function farazsms_feature_build_pattern_ajax() {
	check_ajax_referer( 'farazsms_feature_build', 'nonce' );
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
	}
	$feature = isset( $_POST['feature'] ) ? sanitize_key( $_POST['feature'] ) : '';
	$message = isset( $_POST['message'] ) ? farazsms_sanitize_pattern_text( $_POST['message'] ) : '';
		$map     = array(
			'abandoned'    => array( 'opt' => 'farazsms_abandoned_settings', 'section' => 'abandoned' ),
			'notify'       => array( 'opt' => 'farazsms_notify_settings', 'section' => 'notify' ),
			'daily_report' => array( 'opt' => 'farazsms_daily_sales_settings', 'section' => 'daily_report' ),
			'weekly_report'  => array( 'opt' => 'farazsms_weekly_report_settings', 'section' => 'weekly_report' ),
			'monthly_report' => array( 'opt' => 'farazsms_monthly_report_settings', 'section' => 'monthly_report' ),
			'birthday'     => array( 'opt' => 'farazsms_birthday_settings', 'section' => 'birthday' ),
			'birthday_before' => array( 'opt' => 'farazsms_birthday_before_settings', 'section' => 'birthday_before' ),
			'birthday_after'  => array( 'opt' => 'farazsms_birthday_after_settings', 'section' => 'birthday_after' ),
			'cashback'     => array( 'opt' => 'farazsms_cashback_settings', 'section' => 'cashback' ),
			'low_stock'    => array( 'opt' => 'farazsms_low_stock_settings', 'section' => 'low_stock' ),
			'no_stock'     => array( 'opt' => 'farazsms_nostock_settings', 'section' => 'no_stock' ),
			'wallet_topup' => array( 'opt' => 'farazsms_wallet_topup_pattern_opt', 'section' => 'wallet_topup' ),
			'campaign'     => array( 'opt' => 'farazsms_campaign_settings', 'section' => 'campaign' ),
			'journey'      => array( 'opt' => 'farazsms_journey_pattern_tmp', 'section' => 'journey' ),
		);
	/**
	 * ماژول‌ها بخش‌های خودشان را ثبت می‌کنند، به‌جای اینکه این فهرستِ مرکزی دستی
	 * نگه داشته شود (همان درسی که از فهرستِ دستیِ صفحاتِ ادمین گرفتیم: فهرستِ دستی
	 * دیر یا زود از واقعیت عقب می‌ماند).
	 *
	 * هر ورودی: array( 'opt' => نامِ آپشن, 'section' => برای دسته/توضیح,
	 *                  'path' => (اختیاری) مسیرِ تودرتو مثل array('events','booked') )
	 */
	$filtered = apply_filters( 'farazsms_feature_pattern_map', $map );
	if ( is_array( $filtered ) ) {
		// ورودی‌های موجود قابلِ بازنویسی نیستند و آپشنِ مقصد باید پیشوندِ افزونه را
		// داشته باشد — وگرنه یک فیلترِ بدنوشته می‌توانست هر آپشنِ دلخواهی از سایت
		// را بازنویسی کند یا ۱۴ بخشِ موجود را از کار بیندازد.
		foreach ( $filtered as $key => $entry ) {
			if ( isset( $map[ $key ] ) || ! is_array( $entry ) ) {
				continue;
			}
			$opt_name = isset( $entry['opt'] ) ? (string) $entry['opt'] : '';
			if ( strpos( $opt_name, 'farazsms_' ) !== 0 ) {
				continue;
			}
			$map[ $key ] = $entry;
		}
	}
	if ( ! isset( $map[ $feature ] ) ) {
		wp_send_json_error( array( 'message' => 'بخشِ نامعتبر.' ) );
	}
	if ( trim( $message ) === '' ) {
		wp_send_json_error( array( 'message' => 'متنِ پترن خالی است.' ) );
	}

	// v3.21.96: متغیری که با دو کاراکترِ هگز شروع شود را پنلِ فراز خراب می‌کند. متنِ ساخت را به
	// نام‌های امن (%var1%/%var2%) نگاشت می‌کنیم؛ متنِ نمایشیِ کاربر دست‌نخورده می‌ماند.
	$build_message = farazsms_pattern_hexsafe_build( $feature, $message );

	$opt      = $map[ $feature ]['opt'];
	$section  = $map[ $feature ]['section'];
	$settings = get_option( $opt, array() );
	if ( ! is_array( $settings ) ) {
		$settings = array();
	}
	$desc     = farazsms_pattern_brand_description( $section );
	$category = farazsms_autobuild_pattern_category( $section );
	// حالت: 'edit' (پیش‌فرض) پترنِ فعلی را با همان کد به‌روزرسانی می‌کند؛ 'new' همیشه پترنِ
	// کاملاً تازه می‌سازد. حالتِ 'new' برای سایت‌هایی است که از دیتابیسِ سایتِ دیگری کپی شده‌اند
	// و کدپترنِ همان سایتِ قبلی را به ارث برده‌اند — ویرایش، پترنِ آن سایت را هم عوض می‌کند،
	// پس باید پترنِ جدید ساخته شود.
	$mode     = isset( $_POST['mode'] ) ? sanitize_key( $_POST['mode'] ) : 'edit';
	// مسیرِ تودرتو برای ماژول‌هایی که چند پترن در یک آپشن دارند (مثلاً هر رویدادِ
	// بوکلی/تیکت یک پترنِ جدا). نبودش یعنی همان رفتارِ تختِ قبلی.
	$path     = isset( $map[ $feature ]['path'] ) && is_array( $map[ $feature ]['path'] ) ? $map[ $feature ]['path'] : array();
	$bucket   = farazsms_feature_pattern_bucket( $settings, $path );
	$existing = trim( (string) ( $bucket['pattern_code'] ?? '' ) );
	$did_update = false;

	if ( $mode !== 'new' && $existing !== '' ) {
		$resp      = farazsms_update_pattern( $existing, $build_message, $category, $desc );
		$tmp       = is_string( $resp ) ? json_decode( $resp, true ) : $resp;
		$not_found = is_array( $tmp ) && isset( $tmp['status'] ) && $tmp['status'] !== 'success'
			&& ( ( isset( $tmp['error_code'] ) && $tmp['error_code'] === 'pattern_not_found' )
				|| ( farazsms_is_pattern_not_found_response( $tmp ) ) );
		$did_update = ! $not_found;
		if ( $not_found ) {
			$resp = farazsms_create_pattern( $build_message, $category, $desc );
		}
	} else {
		$resp = farazsms_create_pattern( $build_message, $category, $desc );
	}

	$code = farazsms_autobuild_extract_code( $resp );
	if ( $code === '' && $did_update && $existing !== '' ) {
		$code = $existing;
	}
	if ( $code === '' ) {
		$data = is_string( $resp ) ? json_decode( $resp, true ) : $resp;
		$em   = is_array( $data ) && isset( $data['message'] ) ? (string) $data['message'] : 'پاسخِ نامعتبر از سرور';
		wp_send_json_error( array( 'message' => $em ) );
	}

	$bucket['pattern_code'] = $code;
	if ( $feature === 'cashback' ) {
		$bucket['pattern_message'] = $message;
	} else {
		$bucket['message'] = $message;
	}
	$settings = farazsms_feature_pattern_bucket_set( $settings, $path, $bucket );
	update_option( $opt, $settings, false );
	wp_send_json_success( array(
		'pattern_code' => $code,
		'message'      => ( $did_update ? 'پترن به‌روزرسانی شد' : 'پترن ساخته شد' ) . ' (' . $code . ') — پس از تأییدِ پنلِ فراز فعال می‌شود (۱ تا ۲۴ ساعت).',
	) );
}

/**
 * UIِ مشترکِ «متنِ پترن + دکمه‌ی ساخت» برای سبد رهاشده و موجود شد خبرم کن.
 * در فرمِ تنظیماتِ هر کدام صدا زده می‌شود.
 *
 * @param string $feature 'abandoned' | 'notify'
 * @param string $message متنِ ذخیره‌شده/پیش‌فرض
 * @param array  $vars    متغیرهای قابلِ استفاده (برای نمایش)
 */
function farazsms_feature_pattern_builder_ui( $feature, $message, $vars, $field_name = 'pattern_code' ) {
	$nonce = wp_create_nonce( 'farazsms_feature_build' );
	$id    = 'farazsms-fb-' . sanitize_key( $feature );
	?>
	<div style="background:#f5f8fe; border:1px solid #e1e1e1; border-radius:10px; padding:14px; margin:10px 0;">
		<div style="font-size:13px; font-weight:700; color:#263f67; margin-bottom:6px;">متنِ پیامک (قابلِ ویرایش)</div>
		<p style="margin:0 0 8px; font-size:11.5px; color:#9b9b9b; line-height:1.9;">متغیرها:
			<?php foreach ( $vars as $v ) : ?><code dir="ltr" style="background:#fff; padding:1px 5px; border-radius:3px;"><?php echo esc_html( $v ); ?></code> <?php endforeach; ?>
			<br>آدرسِ سایت به‌صورتِ خودکار به انتهای پترن افزوده می‌شود (برای تأییدِ پنلِ فراز).
		</p>
		<textarea id="<?php echo esc_attr( $id ); ?>-msg" rows="6" style="width:100%; padding:10px 12px; border:1px solid #e1e1e1; border-radius:8px; font-size:13px; font-family:inherit; line-height:1.9; direction:rtl; resize:vertical; box-sizing:border-box;"><?php echo esc_textarea( $message ); ?></textarea>
		<div style="margin-top:10px; display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
			<button type="button" id="<?php echo esc_attr( $id ); ?>-btn-edit" class="button button-primary" style="font-size:14px; padding:6px 22px; height:auto;">✏️ ویرایشِ پترنِ فعلی</button>
			<button type="button" id="<?php echo esc_attr( $id ); ?>-btn-new" class="button button-small" style="font-size:11.5px; color:#9b9b9b;">➕ ساخت پترنِ جدید</button>
			<span id="<?php echo esc_attr( $id ); ?>-status" style="font-size:12px; color:#9b9b9b;"></span>
		</div>
		<p id="<?php echo esc_attr( $id ); ?>-hint" style="margin:8px 0 0; font-size:11px; color:#9b9b9b; line-height:1.8;">«ویرایش» پترنِ فعلی را با همان کدپترن به‌روز می‌کند. «ساخت پترنِ جدید» یک پترنِ تازه می‌سازد — مخصوصِ سایت‌هایی که از دیتابیسِ سایتِ دیگری کپی شده‌اند و نباید پترنِ آن سایت تغییر کند.</p>
	</div>
	<script>
	(function(){
		var btnEdit = document.getElementById('<?php echo esc_js( $id ); ?>-btn-edit');
		var btnNew  = document.getElementById('<?php echo esc_js( $id ); ?>-btn-new');
		if (!btnEdit) return;
			var pcField = document.querySelector('input[name="<?php echo esc_js( $field_name ); ?>"]');
			var fbHint  = document.getElementById('<?php echo esc_js( $id ); ?>-hint');
			function reflectState(){
				var has = pcField && pcField.value && pcField.value.trim() !== '';
				btnEdit.textContent = has ? '✏️ ویرایشِ پترنِ فعلی' : '⚡ ساخت پترن';
				if (btnNew) { btnNew.style.display = has ? '' : 'none'; }
				if (fbHint) { fbHint.style.display = has ? '' : 'none'; }
			}
			reflectState();
		function setBusy(b){
			if (btnEdit) { btnEdit.disabled = b; btnEdit.style.opacity = b ? '.6' : '1'; }
			if (btnNew)  { btnNew.disabled  = b; btnNew.style.opacity  = b ? '.6' : '1'; }
		}
		function send(mode){
			var st = document.getElementById('<?php echo esc_js( $id ); ?>-status');
			var msg = document.getElementById('<?php echo esc_js( $id ); ?>-msg').value || '';
			if (msg.trim() === '') { st.textContent = '✗ متن خالی است'; st.style.color = '#d52a16'; return; }
			setBusy(true); st.textContent = (mode === 'new' ? 'در حال ساختِ پترنِ جدید…' : 'در حال ویرایش…'); st.style.color = '#9b9b9b';
			var fd = new FormData();
			fd.append('action', 'farazsms_feature_build_pattern');
			fd.append('nonce', '<?php echo esc_js( $nonce ); ?>');
			fd.append('feature', '<?php echo esc_js( $feature ); ?>');
			fd.append('mode', mode);
			fd.append('message', msg);
			fetch('<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>', { method:'POST', credentials:'same-origin', body: fd })
				.then(function(r){return r.json();}).then(function(res){
					if (res && res.success && res.data && res.data.pattern_code) {
						var pc = document.querySelector('input[name="<?php echo esc_js( $field_name ); ?>"]');
						if (pc) { pc.value = res.data.pattern_code; reflectState(); }
						st.textContent = '✓ ' + res.data.message; st.style.color = '#0c9765';
					} else { st.textContent = '✗ ' + ((res && res.data && res.data.message) || 'خطا'); st.style.color = '#d52a16'; }
				}).catch(function(){ st.textContent = '✗ خطای ارتباط'; st.style.color = '#d52a16'; })
				.finally(function(){ setBusy(false); });
		}
		btnEdit.addEventListener('click', function(){ send('edit'); });
		if (btnNew) btnNew.addEventListener('click', function(){
			if (!confirm('یک پترنِ کاملاً جدید ساخته می‌شود و کدپترنِ فعلی جایگزین می‌گردد. مطمئنید؟')) return;
			send('new');
		});
	})();
	</script>
	<?php
}
