<?php
/**
 * موجود شد خبرم کن (Back-in-stock notifications) — Phase 2
 *
 * این ماژول فرم «موجود شد خبرم کن» را روی صفحه محصولات ناموجود ووکامرس
 * فعال می‌کند، شماره موبایل مشترک را ذخیره می‌کند، و وقتی موجودی محصول
 * به `instock` تغییر کرد، با الگوی تنظیم‌شده پیامک اطلاع‌رسانی می‌فرستد.
 *
 * جدول DB:  {$wpdb->prefix}farazsms_notify_subscribers
 * Submenu:  farazsms-notify (priority 986، بلافاصله بعد از خبرنامه)
 *
 * توجه: تمام بخش‌های وابسته به ووکامرس داخل شرط `function_exists('WC')`
 * قرار دارند تا روی سایت‌های بدون ووکامرس بدون خطا load شوند.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

// ============================================================================
// Schema
// ============================================================================

// v3.22.141 → 1.1.0: ستونِ user_id (شناسه‌ی کاربرِ واردشده در لحظه‌ی ثبتِ درخواست؛ ۰ = مهمان).
const FARAZSMS_NOTIFY_DB_VERSION        = '1.1.0';
const FARAZSMS_NOTIFY_DB_VERSION_OPTION = 'farazsms_notify_db_version';

function farazsms_notify_table() {
	global $wpdb;
	return $wpdb->prefix . 'farazsms_notify_subscribers';
}

function farazsms_notify_maybe_setup_table() {
	if ( get_option( FARAZSMS_NOTIFY_DB_VERSION_OPTION ) === FARAZSMS_NOTIFY_DB_VERSION ) {
		return;
	}
	if ( ! function_exists( 'dbDelta' ) ) {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	}
	global $wpdb;
	$table           = farazsms_notify_table();
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE $table (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		product_id BIGINT(20) UNSIGNED NOT NULL,
		variation_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
		mobile VARCHAR(20) NOT NULL,
		user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
		ip VARCHAR(45) NOT NULL DEFAULT '',
		status VARCHAR(20) NOT NULL DEFAULT 'pending',
		subscribed_at DATETIME NOT NULL,
		notified_at DATETIME NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY product_mobile (product_id, variation_id, mobile),
		KEY status (status),
		KEY user_id (user_id),
		KEY product_id (product_id),
		KEY subscribed_at (subscribed_at)
	) $charset_collate;";

	dbDelta( $sql );
	// v3.21.7: فقط وقتی جدول واقعاً ساخته شد latch کن (شکستِ dbDelta = مرگِ بی‌صدا).
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
		update_option( FARAZSMS_NOTIFY_DB_VERSION_OPTION, FARAZSMS_NOTIFY_DB_VERSION, false );
	}
}
add_action( 'admin_init', 'farazsms_notify_maybe_setup_table' );

// ============================================================================
// Settings
// ============================================================================

function farazsms_notify_settings() {
	$defaults = array(
		'enabled'             => '1',
		'button_text'         => 'موجود شد، خبرم کن',
		'subscribed_text'     => 'ثبت شد ✓ — به‌محض موجود شدن اطلاع‌رسانی می‌شود.',
		'popup_title'         => 'اطلاع‌رسانی موجودی',
		'popup_description'   => 'شماره موبایل خود را وارد کنید تا به‌محض موجود شدن این محصول، اطلاع دهیم.',
		'mobile_label'        => 'شماره موبایل',
		'submit_text'         => 'ثبت',
		'success_message'     => 'با موفقیت ثبت شد. به‌محض موجود شدن، اطلاع داده می‌شود.',
		'duplicate_message'   => 'این شماره قبلاً برای این محصول ثبت شده است.',
		'error_message'       => 'خطا در ثبت. لطفاً مجدداً تلاش کنید.',
		'pattern_code'        => '',
		'message'             => '', // متنِ پترن (قابلِ ویرایش؛ پیش‌فرض هنگامِ ساختِ خودکار پر می‌شود)
		'dispatch_delay'      => '60', // ثانیه — تأخیر بعد از تغییر stock تا ارسال پیامک
		// v3.22.140: پالتِ رنگِ دکمه/فرم (قابلِ‌تنظیم برای هم‌خوانی با هویتِ بصریِ سایت).
		'button_color'        => '#4571ba', // رنگِ دکمه (قبل از ثبت)
		'button_text_color'   => '#ffffff', // رنگِ متنِ دکمه
		'success_color'       => '#047857', // رنگِ دکمه/پیام پس از ثبتِ موفق
	);
	$saved = get_option( 'farazsms_notify_settings', array() );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
}

// ============================================================================
// Submenu (priority 986 — بلافاصله بعد از خبرنامه)
// ============================================================================

add_action( 'admin_menu', 'farazsms_notify_register_submenu', 986 );
function farazsms_notify_register_submenu() {
	add_submenu_page(
		'farazsms',
		__( 'موجود شد خبرم کن', 'farazsms' ),
		__( 'موجود شد خبرم کن', 'farazsms' ),
		'manage_options',
		'farazsms-notify',
		'farazsms_render_notify_page'
	);
}

// ============================================================================
// CRUD helpers
// ============================================================================

function farazsms_notify_normalize_mobile( $raw ) {
	// reuse newsletter helper (same Iranian phone normalization rule)
	if ( function_exists( 'farazsms_newsletter_normalize_mobile' ) ) {
		return farazsms_newsletter_normalize_mobile( $raw );
	}
	$raw    = (string) $raw;
	$digits = preg_replace( '/\D+/', '', $raw );
	if ( strpos( $digits, '98' ) === 0 && strlen( $digits ) === 12 ) {
		$digits = '0' . substr( $digits, 2 );
	} elseif ( strlen( $digits ) === 10 && $digits[0] === '9' ) {
		$digits = '0' . $digits;
	}
	if ( strlen( $digits ) !== 11 || strpos( $digits, '09' ) !== 0 ) {
		return '';
	}
	return $digits;
}

/**
 * Insert (or restore) a subscription for a specific product (+ optional variation).
 *
 * @return array{success:bool, code:string, message:string, id?:int}
 */
function farazsms_notify_insert_subscriber( $product_id, $variation_id, $mobile_raw ) {
	// کدریویو v3.22.152: ساختِ/ارتقای جدول فقط روی admin_init بود؛ اگر بعد از به‌روزرسانی، اولین
	// اتفاق ثبتِ درخواستِ یک بازدیدکننده باشد (پیش از آنکه مدیری وارد پیشخوان شود)، ستونِ تازه
	// هنوز وجود ندارد و INSERT بی‌صدا شکست می‌خورد. این فراخوانی فقط یک خواندنِ option است
	// (نه کوئریِ جدول) مگر واقعاً نسخه عوض شده باشد.
	farazsms_notify_maybe_setup_table();
	global $wpdb;
	$product_id   = (int) $product_id;
	$variation_id = (int) $variation_id;
	$mobile       = farazsms_notify_normalize_mobile( $mobile_raw );
	if ( $mobile === '' ) {
		return array(
			'success' => false,
			'code'    => 'invalid',
			'message' => __( 'شماره موبایل معتبر نیست.', 'farazsms' ),
		);
	}
	if ( $product_id <= 0 ) {
		return array(
			'success' => false,
			'code'    => 'invalid',
			'message' => __( 'محصول نامعتبر است.', 'farazsms' ),
		);
	}
	$ip = '';
	if ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
		$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
	}
	$now   = current_time( 'mysql' );
	$table = farazsms_notify_table();
	// v3.22.141: درخواست‌کننده — کاربرِ واردشده در همین لحظه (۰ = مهمان). برای ستونِ «درخواست‌کننده»
	// در فهرستِ ادمین؛ خواندنِ نام از روی حساب دقیق‌تر از حدس‌زدن از روی شماره است.
	$user_id = get_current_user_id();

	$existing = $wpdb->get_row(
		$wpdb->prepare(
			"SELECT id, status FROM $table WHERE product_id = %d AND variation_id = %d AND mobile = %s LIMIT 1",
			$product_id,
			$variation_id,
			$mobile
		),
		ARRAY_A
	);

	$settings = farazsms_notify_settings();

	if ( $existing ) {
		if ( $existing['status'] === 'pending' ) {
			return array(
				'success' => false,
				'code'    => 'duplicate',
				'message' => $settings['duplicate_message'],
				'id'      => (int) $existing['id'],
			);
		}
		// Already notified or cancelled — re-subscribe (set back to pending).
		$fields  = array(
			'status'        => 'pending',
			'subscribed_at' => $now,
			'notified_at'   => null,
			'ip'            => $ip,
		);
		$formats = array( '%s', '%s', '%s', '%s' );
		if ( $user_id > 0 ) {
			// مهمانِ قبلی حالا وارد شده — درخواست‌کننده را ثبت کن. (اگر مهمان باشد، شناسه‌ی
			// قبلیِ ثبت‌شده پاک نمی‌شود.)
			$fields['user_id'] = $user_id;
			$formats[]         = '%d';
		}
		$wpdb->update(
			$table,
			$fields,
			array( 'id' => (int) $existing['id'] ),
			$formats,
			array( '%d' )
		);
		return array(
			'success' => true,
			'code'    => 'reactivated',
			'message' => $settings['success_message'],
			'id'      => (int) $existing['id'],
		);
	}

	$inserted = $wpdb->insert(
		$table,
		array(
			'product_id'    => $product_id,
			'variation_id'  => $variation_id,
			'mobile'        => $mobile,
			'user_id'       => $user_id,
			'ip'            => $ip,
			'status'        => 'pending',
			'subscribed_at' => $now,
		),
		array( '%d', '%d', '%s', '%d', '%s', '%s', '%s' )
	);
	if ( $inserted === false ) {
		return array(
			'success' => false,
			'code'    => 'error',
			'message' => $settings['error_message'],
		);
	}
	return array(
		'success' => true,
		'code'    => 'ok',
		'message' => $settings['success_message'],
		'id'      => (int) $wpdb->insert_id,
	);
}

function farazsms_notify_get_counts() {
	global $wpdb;
	$table = farazsms_notify_table();
	return array(
		'total'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" ),
		'pending'  => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE status = %s", 'pending' ) ),
		'notified' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE status = %s", 'notified' ) ),
		'products' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT product_id) FROM $table WHERE status = %s", 'pending' ) ),
	);
}

// ============================================================================
// AJAX subscribe (Public)
// ============================================================================

add_action( 'wp_ajax_farazsms_notify_subscribe',        'farazsms_notify_ajax_subscribe' );
add_action( 'wp_ajax_nopriv_farazsms_notify_subscribe', 'farazsms_notify_ajax_subscribe' );
function farazsms_notify_ajax_subscribe() {
	$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
	if ( ! wp_verify_nonce( $nonce, 'farazsms_notify_subscribe' ) ) {
		wp_send_json_error( array( 'message' => __( 'خطای امنیتی. لطفاً صفحه را رفرش کنید.', 'farazsms' ) ), 403 );
	}
	// rate-limit per IP
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	if ( $ip !== '' ) {
		$rl_key = 'farazsms_nfy_rl_' . md5( $ip );
		$count  = (int) get_transient( $rl_key );
		if ( $count >= 15 ) {
			wp_send_json_error( array( 'message' => __( 'تعداد درخواست‌ها زیاد است. لطفاً ۱۵ دقیقه دیگر مجدداً تلاش کنید.', 'farazsms' ) ), 429 );
		}
		set_transient( $rl_key, $count + 1, 15 * MINUTE_IN_SECONDS );
	}

	$settings = farazsms_notify_settings();
	if ( $settings['enabled'] !== '1' ) {
		wp_send_json_error( array( 'message' => __( 'این قابلیت در حال حاضر غیرفعال است.', 'farazsms' ) ) );
	}

	$product_id   = isset( $_POST['product_id'] )   ? (int) $_POST['product_id']   : 0;
	$variation_id = isset( $_POST['variation_id'] ) ? (int) $_POST['variation_id'] : 0;
	$mobile       = isset( $_POST['mobile'] )       ? wp_unslash( $_POST['mobile'] ) : '';

	// Verify product exists and is actually out of stock — otherwise no point subscribing.
	if ( ! function_exists( 'wc_get_product' ) ) {
		wp_send_json_error( array( 'message' => __( 'ووکامرس نصب نیست.', 'farazsms' ) ) );
	}
	$check_id = $variation_id > 0 ? $variation_id : $product_id;
	$product  = wc_get_product( $check_id );
	if ( ! $product ) {
		wp_send_json_error( array( 'message' => __( 'محصول یافت نشد.', 'farazsms' ) ) );
	}
	if ( $product->is_in_stock() ) {
		wp_send_json_error( array( 'message' => __( 'این محصول هم‌اکنون موجود است.', 'farazsms' ) ) );
	}

	$result = farazsms_notify_insert_subscriber( $product_id, $variation_id, $mobile );
	if ( ! $result['success'] ) {
		wp_send_json_error( array( 'message' => $result['message'] ) );
	}
	wp_send_json_success( array( 'message' => $result['message'] ) );
}

// ============================================================================
// Hook: when WC product stock changes, schedule SMS dispatch
// ============================================================================

// ============================================================================
// v3.21.58: تشخیص و لاگ — برای فهمیدنِ «چرا پیامک نرفت»
// ============================================================================

function farazsms_notify_diag_get() {
	$d = get_option( 'farazsms_notify_diag', array() );
	return is_array( $d ) ? $d : array();
}
function farazsms_notify_diag_set( array $patch ) {
	$d = farazsms_notify_diag_get();
	$d = array_merge( $d, $patch );
	update_option( 'farazsms_notify_diag', $d, false );
}

/**
 * ارسالِ دستیِ همه‌ی مشترکینِ pendingِ محصولاتِ موجود — برای دورزدنِ WP-Cron و تست.
 * @return array{products:int, sent:int, failed:int, errors:string[]}
 */
function farazsms_notify_dispatch_all_pending() {
	global $wpdb;
	$table  = farazsms_notify_table();
	$result = array( 'products' => 0, 'sent' => 0, 'failed' => 0, 'errors' => array() );
	$pairs  = $wpdb->get_results( "SELECT DISTINCT product_id, variation_id FROM $table WHERE status = 'pending'", ARRAY_A );
	foreach ( (array) $pairs as $pair ) {
		$pid = (int) $pair['product_id'];
		$vid = (int) $pair['variation_id'];
		$res = farazsms_notify_handle_dispatch( $pid, $vid, true );
		if ( is_array( $res ) ) {
			$result['products']++;
			$result['sent']   += (int) ( $res['sent'] ?? 0 );
			$result['failed'] += (int) ( $res['failed'] ?? 0 );
			if ( ! empty( $res['last_error'] ) ) {
				$result['errors'][] = '#' . $pid . ': ' . $res['last_error'];
			}
		}
	}
	return $result;
}

add_action( 'wp_ajax_farazsms_notify_dispatch_now', 'farazsms_notify_dispatch_now_ajax' );
function farazsms_notify_dispatch_now_ajax() {
	if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'farazsms_notify_dispatch_now', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز' ), 403 );
	}
	$r = farazsms_notify_dispatch_all_pending();
	wp_send_json_success( $r );
}

add_action( 'woocommerce_product_set_stock_status', 'farazsms_notify_on_stock_status_change', 10, 3 );
// v3.21.45: محصولاتِ متغیر هوکِ بالا را fire نمی‌کنند؛ تغییرِ موجودیِ هر تنوع (variation) با
// این هوک می‌آید. خودِ handler از قبل حالتِ variation را تشخیص می‌دهد و parent+variation را
// ذخیره می‌کند، پس فقط کافی است همان تابع را به این هوک هم وصل کنیم.
add_action( 'woocommerce_variation_set_stock_status', 'farazsms_notify_on_stock_status_change', 10, 3 );
function farazsms_notify_on_stock_status_change( $product_id, $stock_status, $product = null ) {
	if ( $stock_status !== 'instock' ) {
		return;
	}
	$settings = farazsms_notify_settings();
	if ( $settings['enabled'] !== '1' ) {
		return;
	}
	$delay = max( 10, (int) $settings['dispatch_delay'] );
	// Variation products also fire on the parent — store both IDs.
	$is_variation = false;
	if ( function_exists( 'wc_get_product' ) ) {
		$p = wc_get_product( $product_id );
		if ( $p && method_exists( $p, 'is_type' ) && $p->is_type( 'variation' ) ) {
			$is_variation = true;
		}
	}
	// v3.22.69: برای تنوع، هم مشترکینِ همان تنوع (variation_id>0) و هم مشترکینِ «کلِ محصول»
	// (variation_id=0 — کسانی که وقتی همه‌ی تنوع‌ها ناموجود بود روی خودِ محصول مشترک شدند) اطلاع
	// بگیرند. قبلاً فقط (parent, variation) زمان‌بندی می‌شد و مشترکینِ variation_id=0 هرگز notify نمی‌شدند.
	if ( $is_variation ) {
		$parent  = (int) $p->get_parent_id();
		$targets = array( array( $parent, (int) $product_id ), array( $parent, 0 ) );
	} else {
		$targets = array( array( (int) $product_id, 0 ) );
	}

	foreach ( $targets as $args ) {
		if ( ! wp_next_scheduled( 'farazsms_notify_dispatch', $args ) ) {
			wp_schedule_single_event( time() + $delay, 'farazsms_notify_dispatch', $args );
		}
	}
	// v3.21.58: ثبتِ آخرین زمان‌بندی برای پنلِ تشخیص.
	farazsms_notify_diag_set( array(
		'last_schedule_time'    => current_time( 'mysql' ),
		'last_schedule_product' => (int) $targets[0][0],
		'last_schedule_delay'   => (int) $delay,
	) );
}

/**
 * v3.22.141 (بازبینیِ خوانایی در v3.22.142): لینکی که در پیامکِ «موجود شد» درج می‌شود.
 *
 * قبلاً همیشه لینکِ شناسه‌ایِ فشرده ساخته می‌شد و بعد به کوتاه‌کننده می‌رفت؛ نتیجه این بود که
 * مدیر حتی وقتی «لینکِ سایتِ اصلی» را انتخاب کرده بود، در پیامک لینکِ کوتاه‌کننده یا آدرسِ
 * شناسه‌ایِ نامفهوم می‌دید، نه پیوندِ خودِ محصول.
 *
 * قاعده‌ی جدید:
 * - حالتِ «لینکِ سایتِ اصلی» → لینکِ خوانای هم‌دامنه: اگر نامکِ محصول انگلیسی باشد خودِ
 *   پیوندِ یکتا، و اگر فارسی باشد (که در URL درصد-کد و ناخوانا می‌شود) لینکِ شناسه‌ای.
 * - حالتِ «کوتاه‌کننده»      → همان لینکِ خوانا به سرویس داده می‌شود، تا اگر سرویس در دسترس
 *   نبود متنِ پیامک باز هم کوتاه و خوانا بماند.
 *
 * @param int    $product_id
 * @param string $product_name برای توضیحِ لینک در پنلِ کوتاه‌کننده.
 * @return string
 */
function farazsms_notify_product_sms_link( $product_id, $product_name = '' ) {
	$product_id = (int) $product_id;
	$target     = farazsms_sms_readable_post_link( $product_id );

	$use_short = ! function_exists( 'farazsms_shortener_mode' ) || farazsms_shortener_mode( 'notify' ) === 'short';
	if ( ! $use_short ) {
		return $target; // انتخابِ مدیر: لینکِ خودِ سایت.
	}

	if ( $target === '' ) {
		return '';
	}
	return farazsms_shorten_link( $target, 'notify', 'ماژول موجود شد خبرم کن / ' . $product_name );
}

add_action( 'farazsms_notify_dispatch', 'farazsms_notify_handle_dispatch', 10, 2 );
function farazsms_notify_handle_dispatch( $product_id, $variation_id = 0, $manual = false ) {
	$product_id   = (int) $product_id;
	$variation_id = (int) $variation_id;
	$out = array( 'sent' => 0, 'failed' => 0, 'last_error' => '', 'reason' => '' );
	$record = function ( $reason ) use ( &$out, $product_id, $manual ) {
		$out['reason'] = $reason;
		farazsms_notify_diag_set( array(
			'last_dispatch_time'    => current_time( 'mysql' ),
			'last_dispatch_product' => $product_id,
			'last_dispatch_sent'    => (int) $out['sent'],
			'last_dispatch_failed'  => (int) $out['failed'],
			'last_dispatch_reason'  => $reason,
			'last_dispatch_error'   => (string) $out['last_error'],
			'last_dispatch_manual'  => $manual ? '1' : '0',
		) );
		return $out;
	};

	if ( $product_id <= 0 ) { return $record( 'bad_product_id' ); }
	if ( ! function_exists( 'wc_get_product' ) ) { return $record( 'no_woocommerce' ); }
	$check_id = $variation_id > 0 ? $variation_id : $product_id;
	$product  = wc_get_product( $check_id );
	if ( ! $product || ! $product->is_in_stock() ) { return $record( 'not_in_stock' ); }

	$settings = farazsms_notify_settings();
	$pattern  = trim( (string) $settings['pattern_code'] );
	if ( $pattern === '' || ! function_exists( 'farazsms_send_pattern_sms_raw' ) ) { return $record( 'no_pattern' ); }

	global $wpdb;
	$table = farazsms_notify_table();
	$rows  = $wpdb->get_results( $wpdb->prepare(
		"SELECT id, mobile FROM $table WHERE product_id = %d AND variation_id = %d AND status = %s LIMIT 200",
		$product_id, $variation_id, 'pending'
	), ARRAY_A );
	if ( empty( $rows ) ) { return $record( 'no_pending_subscriber' ); }

	$sender       = farazsms_get_ad_sender();
	$product_link = farazsms_notify_product_sms_link( $product_id, $product->get_name() );
	$attrs = array(
		'product_name'  => $product->get_name(),
		'product_link'  => $product_link,
		'product_price' => $product->get_price() ? wc_price( $product->get_price() ) : '',
		'sitename'      => get_bloginfo( 'name' ),
	);
	$attrs['product_price'] = farazsms_price_plain( $attrs['product_price'] );

	$now = current_time( 'mysql' );
	foreach ( $rows as $r ) {
		$res = farazsms_send_pattern_sms_raw( $r['mobile'], $pattern, $attrs, $sender );
		if ( $res === 'success' ) {
			$wpdb->update( $table, array( 'status' => 'notified', 'notified_at' => $now ), array( 'id' => (int) $r['id'] ), array( '%s', '%s' ), array( '%d' ) );
			$out['sent']++;
		} else {
			$out['failed']++;
			if ( is_string( $res ) && $res !== '' ) { $out['last_error'] = $res; }
		}
	}

	$remaining = (int) $wpdb->get_var( $wpdb->prepare(
		"SELECT COUNT(*) FROM $table WHERE product_id = %d AND variation_id = %d AND status = %s",
		$product_id, $variation_id, 'pending'
	) );
	if ( $remaining > 0 && ! $manual ) {
		wp_schedule_single_event( time() + 60, 'farazsms_notify_dispatch', array( $product_id, $variation_id ) );
	}
	return $record( $out['failed'] > 0 ? 'sent_with_errors' : 'sent_ok' );
}

// ============================================================================
// Frontend: button on WC product page
// ============================================================================

add_action( 'woocommerce_single_product_summary', 'farazsms_notify_render_button', 31 );

/**
 * v3.21.48: شورت‌کدِ [farazsms_notify_button] — برای صفحه‌سازها (المنتور و …).
 * فرمِ «موجود شد خبرم کن» را هرجا که بگذارید نمایش می‌دهد. اگر product_id ندهید، از محصولِ
 * صفحه‌ی فعلی استفاده می‌کند. مارک‌آپ خودبسنده است (JS/CSS را خودش inline می‌دهد).
 *
 * نمونه: [farazsms_notify_button]  یا  [farazsms_notify_button product_id="123"]
 */
add_shortcode( 'farazsms_notify_button', 'farazsms_notify_button_shortcode' );
function farazsms_notify_button_shortcode( $atts ) {
	$atts     = shortcode_atts( array( 'product_id' => 0 ), $atts, 'farazsms_notify_button' );
	$settings = farazsms_notify_settings();
	$is_admin_view = current_user_can( 'manage_options' );
	// یادداشتِ فقط-مدیر: به‌جای return ''ِ خاموش که کاربر را سردرگم می‌کرد («چیزی نمایش داده نمی‌شود»).
	$admin_note = function ( $text ) {
		return '<div style="font-size:12px;color:#64748b;direction:rtl;border:1px dashed #cbd5e1;padding:8px 10px;border-radius:6px;">[موجود شد خبرم کن] ' . esc_html( $text ) . ' <span style="color:#94a3b8;">(این پیام فقط برای مدیر است.)</span></div>';
	};
	if ( ! function_exists( 'wc_get_product' ) ) {
		return $is_admin_view ? $admin_note( 'ووکامرس فعال نیست.' ) : '';
	}
	if ( $settings['enabled'] !== '1' ) {
		return $is_admin_view ? $admin_note( 'ماژول «موجود شد خبرم کن» غیرفعال است؛ از تنظیماتِ افزونه فعالش کنید.' ) : '';
	}
	$pid = (int) $atts['product_id'];
	if ( $pid <= 0 ) {
		global $product;
		if ( $product instanceof WC_Product ) {
			$pid = (int) $product->get_id();
		} elseif ( function_exists( 'is_product' ) && is_product() && get_the_ID() ) {
			// فقط در صفحه‌ی محصول، ID جاری را محصول فرض کن؛ در صفحه‌ی معمولی get_the_ID شناسه‌ی
			// صفحه است و wc_get_product رویش false می‌دهد (علتِ اصلیِ «خالی بودن» در المنتور).
			$pid = (int) get_the_ID();
		}
	}
	$the_product = $pid > 0 ? wc_get_product( $pid ) : null;
	if ( ! $the_product || ! is_a( $the_product, 'WC_Product' ) ) {
		return $is_admin_view
			? $admin_note( 'محصولی تشخیص داده نشد. در صفحه‌ی غیرمحصول باید شناسه‌ی محصول را بدهید: [farazsms_notify_button product_id="123"]' )
			: '';
	}
	ob_start();
	if ( $the_product->is_type( 'variable' ) ) {
		// v3.22.69: مخفی/نمایان بر اساسِ موجودیِ کلِ محصول. اگر همه‌ی تنوع‌ها ناموجودند → نمایان
		// (همه‌جا، حتی المنتور). اگر بعضی موجودند → روی صفحه‌ی محصول مخفی و JS با انتخابِ تنوعِ ناموجود
		// آشکارش می‌کند؛ بیرونِ صفحه‌ی محصولِ موجود، دیگر دکمه نشان داده نمی‌شود (چون واقعاً موجود است).
		// $persist وقتی کلِ محصول ناموجود است → JS نباید با reset/change دوباره مخفی‌اش کند.
		farazsms_notify_render_form_markup( $the_product, $the_product->is_in_stock(), ! $the_product->is_in_stock() );
	} elseif ( ! $the_product->is_in_stock() ) {
		farazsms_notify_render_form_markup( $the_product, false );
	} elseif ( $is_admin_view ) {
		return $admin_note( 'این محصول موجود است؛ فرم فقط روی محصولِ ناموجود به بازدیدکننده نشان داده می‌شود.' );
	}
	return ob_get_clean();
}
function farazsms_notify_render_button() {
	$settings = farazsms_notify_settings();
	if ( $settings['enabled'] !== '1' ) {
		return;
	}
	global $product;
	if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
		return;
	}
	// Only show on out-of-stock simple/external/grouped products.
	// For variable products, the JS-driven WC variation handler shows the form per-variation.
	if ( $product->is_type( 'variable' ) ) {
		// v3.22.69: اگر کلِ محصولِ متغیر ناموجود است (همه‌ی تنوع‌ها)، دکمه را همان اول نمایان نشان بده
		// (مثلِ محصولِ ساده). قبلاً همیشه مخفی بود و کاربر باید تنوعِ ناموجود را انتخاب می‌کرد تا آشکار
		// شود — که وقتی همه ناموجودند اغلب رخ نمی‌داد و دکمه اصلاً دیده نمی‌شد. اگر بعضی تنوع‌ها موجودند،
		// مخفی بماند و JS با انتخابِ تنوعِ ناموجود آشکارش کند. ($hidden = is_in_stock)
		// $persist وقتی کلِ محصول ناموجود است → JS نباید با reset/change دوباره مخفی‌اش کند.
		farazsms_notify_render_form_markup( $product, $product->is_in_stock(), ! $product->is_in_stock() );
		return;
	}
	if ( $product->is_in_stock() ) {
		return;
	}
	farazsms_notify_render_form_markup( $product, false );
}

/**
 * Render the button + inline expandable form. JS handles toggle + AJAX submit.
 *
 * @param WC_Product $product
 * @param bool       $hidden_initial  When true, the wrapper starts hidden (used for variable products).
 * @param bool       $persist         When true, JS must NOT re-hide this wrapper on variation reset/change
 *                                    (used for a fully-OOS variable product whose button we show up-front).
 */
function farazsms_notify_render_form_markup( $product, $hidden_initial, $persist = false ) {
	$settings = farazsms_notify_settings();
	$nonce    = wp_create_nonce( 'farazsms_notify_subscribe' );
	$ajax_url = admin_url( 'admin-ajax.php' );
	// v3.22.140: استایلِ ترکیبیِ wrapper = (مخفیِ اولیه در محصولِ متغیر) + متغیرهای رنگِ پالت.
	$wrap_style = ( $hidden_initial ? 'display:none;' : '' ) . farazsms_notify_color_style( $settings );
	?>
	<div class="farazsms-notify-wrapper" data-product-id="<?php echo esc_attr( $product->get_id() ); ?>"<?php if ( $persist ) echo ' data-notify-persist="1"'; ?> data-ajax-url="<?php echo esc_url( $ajax_url ); ?>" data-nonce="<?php echo esc_attr( $nonce ); ?>" data-success-text="<?php echo esc_attr( $settings['subscribed_text'] ); ?>"<?php if ( $wrap_style !== '' ) echo ' style="' . esc_attr( $wrap_style ) . '"'; ?>>
		<button type="button" class="farazsms-notify-button" aria-expanded="false">
			<span class="farazsms-notify-icon" aria-hidden="true">
				<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
			</span>
			<span class="farazsms-notify-button-text"><?php echo esc_html( $settings['button_text'] ); ?></span>
		</button>
		<div class="farazsms-notify-form" hidden>
			<h4 class="farazsms-notify-form-title"><?php echo esc_html( $settings['popup_title'] ); ?></h4>
			<p class="farazsms-notify-form-description"><?php echo esc_html( $settings['popup_description'] ); ?></p>
			<label class="farazsms-notify-field">
				<span><?php echo esc_html( $settings['mobile_label'] ); ?></span>
				<input type="tel" name="mobile" dir="ltr" inputmode="numeric" pattern="[0-9۰-۹]+" maxlength="15" required>
			</label>
			<input type="hidden" name="variation_id" value="0">
			<button type="button" class="farazsms-notify-submit"><?php echo esc_html( $settings['submit_text'] ); ?></button>
			<div class="farazsms-notify-message" role="status" aria-live="polite"></div>
		</div>
	</div>
	<?php
	// Render assets once per page-load.
	farazsms_notify_render_frontend_inline();
}

/**
 * v3.22.140: enqueueِ CSS/JSِ فرانت (به‌جای چاپِ inline).
 *
 * دلیل: کش‌پلاگین‌ها (LiteSpeed/WP-Rocket) JS/CSSِ inline را حذف/جابه‌جا/به‌تعویق می‌اندازند و
 * دکمه بی‌جان می‌شد («دکمه در فرانت باز نمی‌شود»). فایلِ enqueue‌شده کش‌مقاوم است. رنگ‌ها با
 * متغیرِ CSS‌اند و پالتِ ادمین به‌صورتِ inline attribute روی خودِ wrapper ست می‌شود (کش‌مقاوم).
 * روی صفحه‌ی محصول از قبل در wp_enqueue_scripts enqueue شده؛ این‌جا برای شورت‌کد در صفحاتِ دیگر
 * (enqueueِ دیرهنگام برای فوتر) به‌عنوان fallback عمل می‌کند. wp خودش دِدوپ می‌کند.
 */
function farazsms_notify_render_frontend_inline() {
	if ( function_exists( 'wp_style_is' ) && ! wp_style_is( 'farazsms-notify', 'enqueued' ) ) {
		wp_enqueue_style( 'farazsms-notify' );
	}
	if ( function_exists( 'wp_script_is' ) && ! wp_script_is( 'farazsms-notify', 'enqueued' ) ) {
		wp_enqueue_script( 'farazsms-notify' );
	}
}

/**
 * v3.22.140: register همیشه + enqueueِ تمیز روی صفحه‌ی محصول (حالتِ اصلی، در head/footer).
 * برای شورت‌کد در صفحاتِ دیگر، render_form_markup آن را دیرهنگام enqueue می‌کند.
 */
add_action( 'wp_enqueue_scripts', 'farazsms_notify_register_assets' );
function farazsms_notify_register_assets() {
	$settings = farazsms_notify_settings();
	if ( ( $settings['enabled'] ?? '0' ) !== '1' ) {
		return;
	}
	$ver = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1.0';
	if ( ! wp_style_is( 'farazsms-notify', 'registered' ) ) {
		wp_register_style( 'farazsms-notify', FARAZSMS_CORE_CSS . 'farazsms-notify.css', array(), $ver );
	}
	if ( ! wp_script_is( 'farazsms-notify', 'registered' ) ) {
		wp_register_script( 'farazsms-notify', FARAZSMS_CORE_JS . 'farazsms-notify.js', array(), $ver, true );
	}
	if ( function_exists( 'is_product' ) && is_product() ) {
		wp_enqueue_style( 'farazsms-notify' );
		wp_enqueue_script( 'farazsms-notify' );
	}
}

/**
 * v3.22.140: متغیرهای رنگِ پالت (به‌صورتِ inline style روی wrapper — کش‌مقاوم و قابلِ override).
 *
 * @param array $settings
 * @return string مثلِ "--fz-notify-btn-bg:#e91e63;--fz-notify-btn-text:#fff;"
 */
function farazsms_notify_color_style( $settings ) {
	$map = array(
		'--fz-notify-btn-bg'       => (string) ( $settings['button_color'] ?? '' ),
		'--fz-notify-btn-text'     => (string) ( $settings['button_text_color'] ?? '' ),
		'--fz-notify-btn-bg-after' => (string) ( $settings['success_color'] ?? '' ),
		'--fz-notify-accent'       => (string) ( $settings['button_color'] ?? '' ),
	);
	$out = '';
	foreach ( $map as $var => $val ) {
		$val = trim( $val );
		// فقط رنگِ معتبرِ hex یا rgb/rgba را بپذیر (جلوگیری از تزریقِ CSS).
		if ( $val !== '' && preg_match( '/^(#[0-9a-fA-F]{3,8}|rgba?\([\d\s.,%]+\))$/', $val ) ) {
			$out .= $var . ':' . $val . ';';
		}
	}
	return $out;
}

// ============================================================================
// Admin: bulk delete + save settings
// ============================================================================

add_action( 'wp_ajax_farazsms_notify_delete', 'farazsms_notify_ajax_delete' );
function farazsms_notify_ajax_delete() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز.', 'farazsms' ) ), 403 );
	}
	check_ajax_referer( 'farazsms_notify_admin', 'nonce' );
	global $wpdb;
	$ids = isset( $_POST['ids'] ) ? (array) $_POST['ids'] : array();
	$ids = array_filter( array_map( 'absint', $ids ) );
	if ( empty( $ids ) ) {
		wp_send_json_error( array( 'message' => __( 'هیچ ردیفی انتخاب نشده.', 'farazsms' ) ) );
	}
	$ids   = array_slice( $ids, 0, 500 );
	$table = farazsms_notify_table();
	$ph    = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
	$count = (int) $wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE id IN ($ph)", $ids ) );
	wp_send_json_success( array(
		'message' => sprintf( /* translators: %s deleted count */ __( '%s ردیف حذف شد.', 'farazsms' ), number_format_i18n( $count ) ),
		'deleted' => $count,
	) );
}

add_action( 'admin_post_farazsms_notify_save_settings', 'farazsms_notify_handle_save_settings' );
function farazsms_notify_handle_save_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( __( 'دسترسی غیرمجاز.', 'farazsms' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'farazsms_notify_settings' );

	$new      = farazsms_notify_settings();
	$fields   = array(
		'button_text', 'subscribed_text', 'popup_title', 'popup_description',
		'mobile_label', 'submit_text', 'success_message', 'duplicate_message',
		'error_message', 'pattern_code',
	);
	foreach ( $fields as $f ) {
		if ( isset( $_POST[ $f ] ) ) {
			$val = sanitize_text_field( wp_unslash( $_POST[ $f ] ) );
			// v3.22.40 (مورد ۱): pattern_code را با مقدارِ خالی بازننویس. اگر ساختِ خودکارِ پترن (AJAX)
			// موفق شده ولی JS فیلد را به‌روز نکرده باشد، زدنِ «ذخیره» نباید کدِ ساخته‌شده را پاک کند.
			if ( $f === 'pattern_code' && $val === '' ) {
				continue;
			}
			$new[ $f ] = $val;
		}
	}
	$new['enabled']         = isset( $_POST['enabled'] ) && $_POST['enabled'] === '1' ? '1' : '0';
	$new['dispatch_delay']  = isset( $_POST['dispatch_delay'] ) ? max( 10, (int) $_POST['dispatch_delay'] ) : 60;
	// v3.22.140: پالتِ رنگ — sanitize_hex_color فقط رنگِ hexِ معتبر را می‌پذیرد (خالی = پیش‌فرض).
	foreach ( array( 'button_color', 'button_text_color', 'success_color' ) as $color_field ) {
		if ( isset( $_POST[ $color_field ] ) ) {
			$hex = sanitize_hex_color( sanitize_text_field( wp_unslash( $_POST[ $color_field ] ) ) );
			$new[ $color_field ] = $hex ? $hex : '';
		}
	}
	if ( isset( $_POST['message'] ) ) {
		$new['message'] = farazsms_sanitize_pattern_text( $_POST['message'] );
	}

	update_option( 'farazsms_notify_settings', $new, false );

	// v3.22.40 (مورد ۲): tab=settings را حفظ کن. قبلاً بدونِ آن، بعد از ذخیره به تبِ «لیست»
	// پرت می‌شدیم و چون toggle آنجا دیده نمی‌شد، کاربر فکر می‌کرد فعال/غیرفعال «کار نمی‌کند»
	// (درحالی‌که مقدار درست ذخیره شده بود).
	wp_safe_redirect( add_query_arg( array(
		'page'    => 'farazsms-notify',
		'tab'     => 'settings',
		'updated' => '1',
	), admin_url( 'admin.php' ) ) );
	exit;
}

// ============================================================================
// Admin page render
// ============================================================================

function farazsms_render_notify_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	farazsms_notify_maybe_setup_table();

	$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'list';
	$tab = in_array( $tab, array( 'list', 'settings' ), true ) ? $tab : 'list';

	echo '<section class="wrapper farazsms-notify-admin-wrapper">';
	farazsms_notify_render_admin_header();
	farazsms_notify_render_admin_tabs( $tab );
	if ( $tab === 'settings' ) {
		farazsms_notify_render_settings_tab();
	} else {
		farazsms_notify_render_list_tab();
	}
	farazsms_notify_render_admin_inline();
	echo '</section>';
}

function farazsms_notify_render_admin_header() {
	$apikey = farazsms_get_apikey();
	?>
	<div id="farazsms_header">
		<div>
			<a href="https://farazsms.com" target="_blank" rel="noopener">
				<img src="<?php echo esc_url( FARAZSMS_CORE_IMG . 'logo-1.png' ); ?>" alt="<?php esc_attr_e( 'فراز اس‌ام‌اس', 'farazsms' ); ?>">
			</a>
		</div>
		<?php if ( ! empty( $apikey ) ) : ?>
			<div id="farazsms_account_info">
				<div class="farazsms_credit_amount">
					<span><?php esc_html_e( 'میزان اعتبار: ', 'farazsms' ); ?></span>
					<?php echo esc_html( (string) farazsms_get_credit() ); ?>
					<span> <?php esc_html_e( 'تومان', 'farazsms' ); ?></span>
				</div>
				<?php if ( function_exists( 'farazsms_render_profile_block' ) ) { farazsms_render_profile_block(); } ?>
			</div>
		<?php endif; ?>
	</div>
	<h1 class="farazsms-notify-title-main"><?php esc_html_e( 'موجود شد خبرم کن', 'farazsms' ); ?></h1>
	<?php if ( ! class_exists( 'WooCommerce' ) ) : ?>
		<div class="notice notice-warning"><p><?php esc_html_e( 'این قابلیت نیازمند ووکامرس است. لطفاً ابتدا ووکامرس را نصب و فعال کنید.', 'farazsms' ); ?></p></div>
	<?php endif; ?>
	<?php
}

function farazsms_notify_render_admin_tabs( $active ) {
	$tabs = array(
		'list'     => __( 'لیست مشترکین', 'farazsms' ),
		'settings' => __( 'تنظیمات', 'farazsms' ),
	);
	?>
	<nav class="farazsms-notify-tabs">
		<?php foreach ( $tabs as $key => $label ) :
			$url = add_query_arg( array( 'page' => 'farazsms-notify', 'tab' => $key ), admin_url( 'admin.php' ) );
		?>
			<a class="farazsms-notify-tab <?php echo $active === $key ? 'is-active' : ''; ?>" href="<?php echo esc_url( $url ); ?>">
				<?php echo esc_html( $label ); ?>
			</a>
		<?php endforeach; ?>
	</nav>
	<?php
}

function farazsms_notify_render_list_tab() {
	global $wpdb;
	$table  = farazsms_notify_table();
	$counts = farazsms_notify_get_counts();

	$page   = isset( $_GET['paged'] )  ? max( 1, (int) $_GET['paged'] )  : 1;
	$limit  = isset( $_GET['limit'] )  ? max( 10, min( 200, (int) $_GET['limit'] ) ) : 25;
	$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
	$search = isset( $_GET['search'] ) ? sanitize_text_field( wp_unslash( $_GET['search'] ) ) : '';
	$where  = ' WHERE 1=1 ';
	$params = array();
	if ( in_array( $status, array( 'pending', 'notified' ), true ) ) {
		$where   .= ' AND status = %s';
		$params[] = $status;
	}
	if ( $search !== '' ) {
		$like     = '%' . $wpdb->esc_like( $search ) . '%';
		$where   .= ' AND mobile LIKE %s';
		$params[] = $like;
	}
	$total = (int) ( $params
		? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table $where", $params ) )
		: $wpdb->get_var( "SELECT COUNT(*) FROM $table $where" ) );
	$total_pages = max( 1, (int) ceil( $total / $limit ) );
	$offset      = ( $page - 1 ) * $limit;
	$query       = "SELECT * FROM $table $where ORDER BY id DESC LIMIT %d OFFSET %d";
	$all_params  = array_merge( $params, array( $limit, $offset ) );
	$rows        = $wpdb->get_results( $wpdb->prepare( $query, $all_params ), ARRAY_A );

	// v3.22.141: ستونِ «درخواست‌کننده». برای ردیف‌هایی که کاربرِ واردشده داشتند از user_id، و
	// برای مهمان‌ها (و ردیف‌های قدیمی، پیش از افزودنِ این ستون) از تطابقِ یکتای شماره با حسابِ
	// موجود استفاده می‌شود. هر دو با دو کوئریِ دسته‌ای؛ نه یک کوئری به‌ازای هر ردیف.
	$owner_by_mobile = array();
	$user_ids        = array();
	$guest_mobiles   = array();
	foreach ( (array) $rows as $r ) {
		if ( (int) ( $r['user_id'] ?? 0 ) > 0 ) {
			$user_ids[] = (int) $r['user_id'];
		} else {
			$guest_mobiles[] = $r['mobile'];
		}
	}
	if ( $guest_mobiles ) {
		$owner_by_mobile = farazsms_map_mobiles_to_user_ids( $guest_mobiles );
		$user_ids        = array_merge( $user_ids, array_values( $owner_by_mobile ) );
	}
	if ( $user_ids ) {
		cache_users( array_unique( $user_ids ) ); // یک کوئری برای همه‌ی نام‌ها.
	}

	$updated = isset( $_GET['updated'] ) ? sanitize_key( $_GET['updated'] ) : '';
	?>
	<?php if ( $updated === '1' ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'تنظیمات ذخیره شد.', 'farazsms' ); ?></p></div>
	<?php endif; ?>

	<div class="farazsms-notify-stats">
		<div class="farazsms-notify-stat"><div class="num"><?php echo esc_html( number_format_i18n( $counts['total'] ) ); ?></div><div class="lbl"><?php esc_html_e( 'مجموع درخواست‌ها', 'farazsms' ); ?></div></div>
		<div class="farazsms-notify-stat"><div class="num farazsms-num-warning"><?php echo esc_html( number_format_i18n( $counts['pending'] ) ); ?></div><div class="lbl"><?php esc_html_e( 'در انتظار', 'farazsms' ); ?></div></div>
		<div class="farazsms-notify-stat"><div class="num farazsms-num-success"><?php echo esc_html( number_format_i18n( $counts['notified'] ) ); ?></div><div class="lbl"><?php esc_html_e( 'اطلاع‌رسانی شده', 'farazsms' ); ?></div></div>
		<div class="farazsms-notify-stat"><div class="num farazsms-num-info"><?php echo esc_html( number_format_i18n( $counts['products'] ) ); ?></div><div class="lbl"><?php esc_html_e( 'محصول در انتظار', 'farazsms' ); ?></div></div>
	</div>

	<form method="get" class="farazsms-notify-filters">
		<input type="hidden" name="page" value="farazsms-notify">
		<label>
			<span><?php esc_html_e( 'جستجو موبایل:', 'farazsms' ); ?></span>
			<input type="text" name="search" value="<?php echo esc_attr( $search ); ?>">
		</label>
		<label>
			<span><?php esc_html_e( 'وضعیت:', 'farazsms' ); ?></span>
			<select name="status">
				<option value=""<?php selected( $status, '' ); ?>><?php esc_html_e( 'همه', 'farazsms' ); ?></option>
				<option value="pending"<?php selected( $status, 'pending' ); ?>><?php esc_html_e( 'در انتظار', 'farazsms' ); ?></option>
				<option value="notified"<?php selected( $status, 'notified' ); ?>><?php esc_html_e( 'اطلاع‌رسانی شده', 'farazsms' ); ?></option>
			</select>
		</label>
		<label>
			<span><?php esc_html_e( 'تعداد در صفحه:', 'farazsms' ); ?></span>
			<select name="limit">
				<?php foreach ( array( 25, 50, 100, 200 ) as $opt ) : ?>
					<option value="<?php echo esc_attr( $opt ); ?>"<?php selected( $limit, $opt ); ?>><?php echo esc_html( (string) $opt ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>
		<button type="submit" class="button button-primary"><?php esc_html_e( 'اعمال فیلتر', 'farazsms' ); ?></button>
	</form>

	<form id="farazsms-notify-bulk-form">
		<?php wp_nonce_field( 'farazsms_notify_admin', 'farazsms_notify_admin_nonce' ); ?>
		<div class="farazsms-notify-bulk-bar">
			<button type="button" class="button farazsms-notify-bulk-delete" disabled><?php esc_html_e( 'حذف انتخاب‌شده‌ها', 'farazsms' ); ?></button>
			<span class="farazsms-notify-bulk-info"></span>
		</div>
		<table class="widefat striped farazsms-notify-table">
			<thead>
				<tr>
					<th class="check-column"><input type="checkbox" id="farazsms-notify-select-all"></th>
					<th class="farazsms-col-id"><?php esc_html_e( 'شناسه', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'محصول', 'farazsms' ); ?></th>
					<th class="farazsms-col-requester"><?php esc_html_e( 'درخواست‌کننده', 'farazsms' ); ?></th>
					<th class="farazsms-col-mobile"><?php esc_html_e( 'موبایل', 'farazsms' ); ?></th>
					<th class="farazsms-col-status"><?php esc_html_e( 'وضعیت', 'farazsms' ); ?></th>
					<th class="farazsms-col-date"><?php esc_html_e( 'تاریخ ثبت', 'farazsms' ); ?></th>
					<th class="farazsms-col-date"><?php esc_html_e( 'اطلاع‌رسانی', 'farazsms' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $rows ) ) : ?>
					<tr><td colspan="8"><?php esc_html_e( 'هیچ درخواستی یافت نشد.', 'farazsms' ); ?></td></tr>
				<?php else : foreach ( $rows as $r ) :
					$prod_title = '';
					$prod_url   = '';
					if ( function_exists( 'wc_get_product' ) ) {
						$p = wc_get_product( (int) $r['product_id'] );
						if ( $p ) {
							$prod_title = $p->get_name();
							$prod_url   = get_edit_post_link( (int) $r['product_id'] );
						}
					}
					if ( $prod_title === '' ) {
						$prod_title = sprintf( '#%d', (int) $r['product_id'] );
					}
					if ( (int) $r['variation_id'] > 0 ) {
						$prod_title .= sprintf( ' (متغیر: %d)', (int) $r['variation_id'] );
					}
					$jdate_sub = farazsms_send_reports_to_jalali( $r['subscribed_at'] );
					$jdate_not = $r['notified_at'] && farazsms_send_reports_to_jalali( $r['notified_at'] );
					$status_class = $r['status'] === 'notified' ? 'success' : 'warning';
					$status_text  = $r['status'] === 'notified' ? __( 'ارسال شده', 'farazsms' ) : __( 'در انتظار', 'farazsms' );

					// درخواست‌کننده: کاربرِ ثبت‌شده‌ی ردیف، وگرنه صاحبِ یکتای همان شماره (اگر باشد).
					$req_user_id = (int) ( $r['user_id'] ?? 0 );
					$req_guest   = $req_user_id <= 0;
					if ( $req_guest ) {
						$norm        = farazsms_dedupe_normalize_mobile( $r['mobile'] );
						$req_user_id = (int) ( $owner_by_mobile[ $norm ] ?? 0 );
					}
					$req_user = $req_user_id > 0 ? get_userdata( $req_user_id ) : false;
					$req_name = '';
					if ( $req_user ) {
						$req_name = trim( $req_user->first_name . ' ' . $req_user->last_name );
						if ( $req_name === '' ) {
							$req_name = $req_user->display_name !== '' ? $req_user->display_name : $req_user->user_login;
						}
					}
				?>
					<tr>
						<td class="check-column"><input type="checkbox" class="farazsms-notify-row" value="<?php echo esc_attr( $r['id'] ); ?>"></td>
						<td class="farazsms-col-id"><?php echo esc_html( $r['id'] ); ?></td>
						<td>
							<?php if ( $prod_url ) : ?>
								<a href="<?php echo esc_url( $prod_url ); ?>" target="_blank"><?php echo esc_html( $prod_title ); ?></a>
							<?php else : ?>
								<?php echo esc_html( $prod_title ); ?>
							<?php endif; ?>
						</td>
						<td class="farazsms-col-requester">
							<?php if ( $req_user ) : ?>
								<a href="<?php echo esc_url( get_edit_user_link( $req_user->ID ) ); ?>" target="_blank"><?php echo esc_html( $req_name ); ?></a>
								<?php if ( $req_guest ) : ?>
									<span class="farazsms-req-tag" title="<?php esc_attr_e( 'هنگام ثبت وارد حساب نشده بود؛ این شماره متعلق به همین مشتری است.', 'farazsms' ); ?>"><?php esc_html_e( 'مهمان', 'farazsms' ); ?></span>
								<?php endif; ?>
							<?php else : ?>
								<span class="farazsms-req-guest" title="<?php esc_attr_e( 'بدون حساب کاربری — فقط شماره ثبت شده است.', 'farazsms' ); ?>"><?php esc_html_e( 'مهمان', 'farazsms' ); ?></span>
							<?php endif; ?>
						</td>
						<td class="farazsms-col-mobile" dir="ltr"><?php echo esc_html( $r['mobile'] ); ?></td>
						<td class="farazsms-col-status"><span class="farazsms-status farazsms-status-<?php echo esc_attr( $status_class ); ?>"><?php echo esc_html( $status_text ); ?></span></td>
						<td class="farazsms-notify-date-cell farazsms-col-date"><?php echo esc_html( $jdate_sub ); ?></td>
						<td class="farazsms-notify-date-cell farazsms-col-date"><?php echo esc_html( $jdate_not ); ?></td>
					</tr>
				<?php endforeach; endif; ?>
			</tbody>
		</table>
	</form>

	<?php if ( $total_pages > 1 ) :
		$base = add_query_arg( array(
			'page'   => 'farazsms-notify',
			'status' => $status,
			'search' => $search,
			'limit'  => $limit,
		), admin_url( 'admin.php' ) );
		?>
		<div class="farazsms-notify-pagination">
			<?php if ( $page > 1 ) : ?>
				<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $page - 1, $base ) ); ?>">« <?php esc_html_e( 'صفحه قبل', 'farazsms' ); ?></a>
			<?php endif; ?>
			<span class="farazsms-notify-page-info">
				<?php printf( esc_html__( 'صفحه %1$s از %2$s', 'farazsms' ), esc_html( number_format_i18n( $page ) ), esc_html( number_format_i18n( $total_pages ) ) ); ?>
			</span>
			<?php if ( $page < $total_pages ) : ?>
				<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $page + 1, $base ) ); ?>"><?php esc_html_e( 'صفحه بعد', 'farazsms' ); ?> »</a>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<?php
}

function farazsms_notify_render_settings_tab() {
	$s = farazsms_notify_settings();
	?>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="farazsms-notify-card">
		<input type="hidden" name="action" value="farazsms_notify_save_settings">
		<?php wp_nonce_field( 'farazsms_notify_settings' ); ?>

		<h2><?php esc_html_e( 'تنظیمات «موجود شد خبرم کن»', 'farazsms' ); ?></h2>

		<div class="farazsms-notify-settings-grid">
			<label class="farazsms-notify-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'فعال‌سازی', 'farazsms' ); ?></span>
				<label class="farazsms-notify-switch">
					<input type="checkbox" class="farazsms-toggle" name="enabled" value="1" <?php checked( $s['enabled'], '1' ); ?>>
					<span><?php esc_html_e( 'فعال — دکمه روی صفحه محصولات ناموجود ووکامرس نمایش داده می‌شود.', 'farazsms' ); ?></span>
				</label>
			</label>

			<label class="farazsms-notify-setting">
				<span><?php esc_html_e( 'متن دکمه', 'farazsms' ); ?></span>
				<input type="text" name="button_text" value="<?php echo esc_attr( $s['button_text'] ); ?>">
			</label>

			<label class="farazsms-notify-setting">
				<span><?php esc_html_e( 'متن دکمه بعد از ثبت', 'farazsms' ); ?></span>
				<input type="text" name="subscribed_text" value="<?php echo esc_attr( $s['subscribed_text'] ); ?>">
			</label>

			<?php // v3.22.140: پالتِ رنگِ دکمه — برای هم‌خوانی با هویتِ بصریِ سایت. ?>
			<div class="farazsms-notify-setting" style="display:flex; flex-wrap:wrap; gap:18px; align-items:flex-start;">
				<label style="display:flex; flex-direction:column; gap:4px;">
					<span><?php esc_html_e( 'رنگ دکمه', 'farazsms' ); ?></span>
					<input type="color" name="button_color" value="<?php echo esc_attr( $s['button_color'] ?: '#4571ba' ); ?>" style="width:56px; height:36px; padding:2px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
				</label>
				<label style="display:flex; flex-direction:column; gap:4px;">
					<span><?php esc_html_e( 'رنگ متن دکمه', 'farazsms' ); ?></span>
					<input type="color" name="button_text_color" value="<?php echo esc_attr( $s['button_text_color'] ?: '#ffffff' ); ?>" style="width:56px; height:36px; padding:2px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
				</label>
				<label style="display:flex; flex-direction:column; gap:4px;">
					<span><?php esc_html_e( 'رنگ بعد از ثبت (موفق)', 'farazsms' ); ?></span>
					<input type="color" name="success_color" value="<?php echo esc_attr( $s['success_color'] ?: '#047857' ); ?>" style="width:56px; height:36px; padding:2px; border:1px solid #cbd5e1; border-radius:6px; cursor:pointer;">
				</label>
			</div>

			<label class="farazsms-notify-setting">
				<span><?php esc_html_e( 'عنوان فرم', 'farazsms' ); ?></span>
				<input type="text" name="popup_title" value="<?php echo esc_attr( $s['popup_title'] ); ?>">
			</label>

			<label class="farazsms-notify-setting">
				<span><?php esc_html_e( 'برچسب فیلد موبایل', 'farazsms' ); ?></span>
				<input type="text" name="mobile_label" value="<?php echo esc_attr( $s['mobile_label'] ); ?>">
			</label>

			<label class="farazsms-notify-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'توضیح فرم', 'farazsms' ); ?></span>
				<input type="text" name="popup_description" value="<?php echo esc_attr( $s['popup_description'] ); ?>">
			</label>

			<label class="farazsms-notify-setting">
				<span><?php esc_html_e( 'متن دکمه ثبت', 'farazsms' ); ?></span>
				<input type="text" name="submit_text" value="<?php echo esc_attr( $s['submit_text'] ); ?>">
			</label>

			<label class="farazsms-notify-setting">
				<span><?php esc_html_e( 'پیام موفقیت', 'farazsms' ); ?></span>
				<input type="text" name="success_message" value="<?php echo esc_attr( $s['success_message'] ); ?>">
			</label>

			<label class="farazsms-notify-setting">
				<span><?php esc_html_e( 'پیام تکراری', 'farazsms' ); ?></span>
				<input type="text" name="duplicate_message" value="<?php echo esc_attr( $s['duplicate_message'] ); ?>">
			</label>

			<label class="farazsms-notify-setting">
				<span><?php esc_html_e( 'پیام خطا', 'farazsms' ); ?></span>
				<input type="text" name="error_message" value="<?php echo esc_attr( $s['error_message'] ); ?>">
			</label>

			<div class="farazsms-setting-wide" style="grid-column:1/-1;">
				<?php
				$nt_msg = trim( (string) ( $s['message'] ?? '' ) ) !== '' ? $s['message'] : ( farazsms_autobuild_default_messages()['notify']);
				farazsms_feature_pattern_builder_ui( 'notify', $nt_msg, array( '%product_name%', '%product_link%', '%product_price%' ) );
				?>
			</div>

			<label class="farazsms-notify-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'کد الگوی اطلاع‌رسانی *', 'farazsms' ); ?></span>
				<input type="text" name="pattern_code" value="<?php echo esc_attr( $s['pattern_code'] ); ?>" dir="ltr">
				<small class="farazsms-notify-help">
					<?php esc_html_e( 'با دکمه‌ی «ساخت پترن» بالا خودکار پر می‌شود. متغیرها:', 'farazsms' ); ?>
					<code dir="ltr">%product_name%</code>
					<code dir="ltr">%product_link%</code>
					<code dir="ltr">%product_price%</code>
				</small>
				<?php // v3.22.141: مدیر باید بداند محتوای %product_link% را کجا انتخاب می‌کند. ?>
				<small class="farazsms-notify-help">
					<?php esc_html_e( 'متغیرِ لینک، بسته به بخشِ «روشِ ارسالِ لینک» در پایینِ همین صفحه، یا لینکِ کوتاه‌شده است یا لینکِ خودِ سایتِ شما. برای محصولاتی که نامِ فارسی دارند، لینکِ کوتاهِ شناسه‌ایِ سایت درج می‌شود تا متنِ پیامک خوانا و کم‌هزینه بماند.', 'farazsms' ); ?>
				</small>
			</label>

			<label class="farazsms-notify-setting">
				<span><?php esc_html_e( 'تأخیر ارسال پس از موجود شدن (ثانیه)', 'farazsms' ); ?></span>
				<input type="number" name="dispatch_delay" value="<?php echo esc_attr( $s['dispatch_delay'] ); ?>" min="10" max="3600" dir="ltr">
				<small class="farazsms-notify-help"><?php esc_html_e( 'حداقل ۱۰ ثانیه. مقدار پیش‌فرض ۶۰ ثانیه برای فرصت undo توسط مدیر.', 'farazsms' ); ?></small>
			</label>

			<div class="farazsms-notify-setting farazsms-setting-wide" style="background:#eff6ff; border:1px solid #bfdbfe; border-radius:10px; padding:14px 16px; margin-top:6px;">
				<strong style="display:block; font-size:13px; color:#1e40af; margin-bottom:8px;">🧩 استفاده در صفحه‌ساز (المنتور و …)</strong>
				<p style="margin:0; font-size:12.5px; line-height:2; color:#1e3a8a;">
					اگر می‌خواهید فرمِ «موجود شد خبرم کن» را جای دلخواهی (مثلاً با المنتور) بگذارید، از این شورت‌کد استفاده کنید:
					<br>
					<code dir="ltr" style="display:inline-block; margin-top:4px; background:#fff; border:1px solid #bfdbfe; padding:3px 8px; border-radius:5px;">[farazsms_notify_button]</code>
					<br>
					در صفحه‌ی خودِ محصول، خودکار همان محصول را می‌گیرد. برای محصولِ مشخص:
					<code dir="ltr" style="display:inline-block; margin-top:4px; background:#fff; border:1px solid #bfdbfe; padding:3px 8px; border-radius:5px;">[farazsms_notify_button product_id="123"]</code>
				</p>
			</div>

			<div class="farazsms-notify-setting farazsms-setting-wide" style="background:#fffbeb; border:1px solid #fde68a; border-radius:10px; padding:14px 16px; margin-top:6px;">
				<strong style="display:block; font-size:13px; color:#92400e; margin-bottom:8px;">🛟 اگر پیامک ارسال نمی‌شود، این دو مورد را بررسی کنید:</strong>
				<ol style="margin:0; padding-right:18px; font-size:12.5px; line-height:2; color:#3f2d00;">
					<li>مطمئن شوید <strong>پترن (الگو)</strong> در پنل فراز <strong>تأیید شده</strong> باشد. تا زمانی که پترن تأیید نشده، پیامک ارسال نمی‌شود.</li>
					<li>از <strong>پشتیبانیِ هاست</strong> بخواهید مطمئن شوند <strong>کران‌جاب (Cron Job)</strong> روی هاستِ شما فعال است؛ ارسالِ این پیامک با تأخیر و از طریقِ زمان‌بندِ وردپرس انجام می‌شود و بدونِ کرانِ فعال ممکن است اجرا نشود.</li>
				</ol>
			</div>
		</div>

		<div class="farazsms-notify-save-row">
			<button type="submit" class="button button-primary"><?php esc_html_e( 'ذخیره تنظیمات', 'farazsms' ); ?></button>
		</div>
	</form>

	<?php
	// v3.21.58: انتخابِ روشِ ارسالِ لینک (کوتاه‌کننده/سایتِ اصلی) — بیرونِ فرمِ بالا.
	farazsms_shortener_render_choice( 'notify', 'موجود شد خبرم کن' );

	// v3.21.58: پنلِ تشخیص — چرا پیامک رفت/نرفت.
	$diag    = farazsms_notify_diag_get();
	global $wpdb;
	$pending = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . farazsms_notify_table() . " WHERE status = 'pending'" );
	$next    = wp_next_scheduled( 'farazsms_notify_dispatch' );
	$cron_off = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
	$reasons = array(
		'sent_ok' => '✅ ارسال موفق', 'sent_with_errors' => '⚠️ ارسال با خطا (به «آخرین خطا» نگاه کنید)',
		'no_pending_subscriber' => 'هیچ مشترکِ در انتظاری برای این محصول نبود',
		'no_pattern' => 'کدِ پترن تنظیم/تأیید نشده', 'not_in_stock' => 'محصول هنگامِ ارسال موجود نبود',
		'bad_product_id' => 'شناسه‌ی محصول نامعتبر', 'no_woocommerce' => 'ووکامرس فعال نیست',
	);
	$last_reason = $diag['last_dispatch_reason'] ?? '';
	?>
	<div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:18px 20px; margin:18px 0; max-width:680px; direction:rtl;">
		<h3 style="margin:0 0 12px; font-size:15px;">🩺 وضعیت و عیب‌یابیِ ارسال</h3>
		<table style="width:100%; font-size:12.5px; border-collapse:collapse;">
			<tr><td style="padding:6px 0; color:#64748b;">مشترکینِ در انتظار (همه‌ی محصولات)</td><td style="font-weight:700;"><?php echo (int) $pending; ?></td></tr>
			<tr><td style="padding:6px 0; color:#64748b;">WP-Cron</td><td style="font-weight:700; color:<?php echo $cron_off ? '#dc2626' : '#16a34a'; ?>;"><?php echo $cron_off ? '⛔ غیرفعال (DISABLE_WP_CRON) — کرانِ سرور لازم است' : '✅ فعال'; ?></td></tr>
			<tr><td style="padding:6px 0; color:#64748b;">اجرای بعدیِ زمان‌بندی‌شده</td><td><?php echo $next ? esc_html( wp_date( 'Y-m-d H:i:s', $next ) ) : '— (چیزی زمان‌بندی نشده)'; ?></td></tr>
			<tr><td style="padding:6px 0; color:#64748b;">آخرین زمان‌بندی (تغییرِ موجودی)</td><td><?php echo ! empty( $diag['last_schedule_time'] ) ? esc_html( $diag['last_schedule_time'] ) . ' (محصول #' . (int) ( $diag['last_schedule_product'] ?? 0 ) . ')' : '— هنوز هیچ تغییرِ موجودی‌ای ثبت نشده'; ?></td></tr>
			<tr><td style="padding:6px 0; color:#64748b;">آخرین اجرای ارسال</td><td><?php echo ! empty( $diag['last_dispatch_time'] ) ? esc_html( $diag['last_dispatch_time'] ) : '— هنوز اجرا نشده'; ?></td></tr>
			<tr><td style="padding:6px 0; color:#64748b;">نتیجه‌ی آخرین اجرا</td><td style="font-weight:700;"><?php echo esc_html( $reasons[ $last_reason ] ?? ( $last_reason !== '' ? $last_reason : '—' ) ); ?> <?php echo isset( $diag['last_dispatch_sent'] ) ? '(' . (int) $diag['last_dispatch_sent'] . ' ارسال، ' . (int) ( $diag['last_dispatch_failed'] ?? 0 ) . ' ناموفق)' : ''; ?></td></tr>
			<?php if ( ! empty( $diag['last_dispatch_error'] ) ) : ?>
				<tr><td style="padding:6px 0; color:#64748b;">آخرین خطای وب‌سرویس</td><td style="color:#b91c1c; direction:ltr; text-align:right;"><?php echo esc_html( $diag['last_dispatch_error'] ); ?></td></tr>
			<?php endif; ?>
		</table>
		<div style="margin-top:14px;">
			<button type="button" id="farazsms-notify-dispatch-now" data-nonce="<?php echo esc_attr( wp_create_nonce( 'farazsms_notify_dispatch_now' ) ); ?>" class="button button-primary">🚀 ارسالِ فوریِ همه‌ی در انتظار (الان، بدونِ کران)</button>
			<span id="farazsms-notify-dispatch-status" style="margin-right:10px; font-size:12.5px; color:#64748b;"></span>
			<p style="margin:8px 0 0; font-size:11.5px; color:#64748b; line-height:1.8;">اگر WP-Cron غیرفعال است یا منتظرِ کران نمی‌مانید، با این دکمه همین حالا برای همه‌ی محصولاتِ موجودِ دارای مشترک ارسال می‌شود. نتیجه + خطا را همین‌جا می‌بینید.</p>
		</div>
		<script>
		(function(){
			var b=document.getElementById('farazsms-notify-dispatch-now'); if(!b) return;
			b.addEventListener('click',function(){
				var st=document.getElementById('farazsms-notify-dispatch-status');
				b.disabled=true; b.style.opacity=.6; st.textContent='در حال ارسال…'; st.style.color='#64748b';
				var fd=new FormData(); fd.append('action','farazsms_notify_dispatch_now'); fd.append('nonce',b.dataset.nonce);
				fetch(ajaxurl,{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json();}).then(function(res){
					if(res&&res.success){var d=res.data; st.innerHTML='✅ '+d.products+' محصول • '+d.sent+' ارسال • '+d.failed+' ناموفق'+(d.errors&&d.errors.length?(' — خطا: '+d.errors.join(' | ')):''); st.style.color=d.failed?'#b91c1c':'#16a34a';}
					else{ st.textContent='✗ '+((res&&res.data&&res.data.message)||'خطا'); st.style.color='#b91c1c';}
				}).catch(function(){st.textContent='✗ خطای ارتباط'; st.style.color='#b91c1c';})
				.finally(function(){b.disabled=false; b.style.opacity=1;});
			});
		})();
		</script>
	</div>
	<?php
}

function farazsms_notify_render_admin_inline() {
	$nonce = wp_create_nonce( 'farazsms_notify_admin' );
	?>
	<style>
	.farazsms-notify-admin-wrapper .farazsms-notify-title-main { margin: 16px 0 8px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-tabs { display: flex; gap: 6px; border-bottom: 2px solid #e5e7eb; margin: 16px 0 22px; flex-wrap: wrap; }
	.farazsms-notify-admin-wrapper .farazsms-notify-tab { padding: 10px 18px; text-decoration: none; color: #64748b; background: none; border: none; border-bottom: 2px solid transparent; margin-bottom: -2px; font-size: 13.5px; font-weight: 600; transition: color .15s, border-color .15s; }
	.farazsms-notify-admin-wrapper .farazsms-notify-tab:hover { color: #365891; }
	.farazsms-notify-admin-wrapper .farazsms-notify-tab.is-active { color: #365891; font-weight: 700; border-bottom-color: #365891; background: none; }
	.farazsms-notify-admin-wrapper .farazsms-notify-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin: 0 0 20px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-stat { background: #fff; padding: 16px; border: 1px solid #e5e7eb; border-radius: 8px; text-align: center; }
	.farazsms-notify-admin-wrapper .farazsms-notify-stat .num { font-size: 26px; font-weight: 700; line-height: 1; color: #1f2937; }
	.farazsms-notify-admin-wrapper .farazsms-notify-stat .num.farazsms-num-success { color: #047857; }
	.farazsms-notify-admin-wrapper .farazsms-notify-stat .num.farazsms-num-warning { color: #b45309; }
	.farazsms-notify-admin-wrapper .farazsms-notify-stat .num.farazsms-num-info    { color: #1d4ed8; }
	.farazsms-notify-admin-wrapper .farazsms-notify-stat .lbl { color: #6b7280; font-size: 12px; margin-top: 6px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-filters { background: #fff; padding: 14px 16px; border: 1px solid #dcdcde; border-radius: 8px; margin: 0 0 14px; display: flex; flex-wrap: wrap; gap: 12px; align-items: end; }
	.farazsms-notify-admin-wrapper .farazsms-notify-filters label { display: flex; flex-direction: column; gap: 4px; font-size: 12px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-bulk-bar { margin: 0 0 10px; display: flex; align-items: center; gap: 10px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-bulk-info { color: #50575e; font-size: 13px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-table th,
	.farazsms-notify-admin-wrapper .farazsms-notify-table td { padding: 10px 12px; vertical-align: middle; }
	/* v3.22.141 هم‌ترازی: دو ریشه داشت — (۱) کلاسِ check-column فقط روی سرستون بود نه ردیف‌ها،
	   پس پهنا/paddingِ وردپرس روی سرستون و بدنه یکسان نمی‌شد؛ (۲) چیدمانِ خودکارِ جدول همه‌ی فضای
	   اضافه را به ستون‌های نشکستنی (تاریخ/موبایل) می‌داد و ستونِ محصول را تا چند حرف در هر خط
	   می‌فشرد. با table-layout: fixed پهنای هر ستون همان است که تعریف شده و باقی‌مانده به ستونِ
	   محصول می‌رسد. اعداد بر اساس اندازه‌ی واقعیِ محتوا (تاریخِ جلالی، شماره‌ی ۱۱رقمی) انتخاب شده‌اند. */
	.farazsms-notify-admin-wrapper .farazsms-notify-table { table-layout: fixed; width: 100%; }
	.farazsms-notify-admin-wrapper .farazsms-notify-table th.check-column,
	.farazsms-notify-admin-wrapper .farazsms-notify-table td.check-column { width: 38px; padding: 10px 8px; text-align: center; vertical-align: middle; }
	.farazsms-notify-admin-wrapper .farazsms-notify-table td.check-column input { margin: 0; }
	.farazsms-notify-admin-wrapper .farazsms-notify-table .farazsms-col-id { width: 78px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-table .farazsms-col-requester { width: 150px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-table .farazsms-col-mobile { width: 122px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-table .farazsms-col-status { width: 96px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-table .farazsms-col-date { width: 128px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-table td { word-break: break-word; }
	.farazsms-notify-admin-wrapper .farazsms-notify-table td.farazsms-col-mobile { font-variant-numeric: tabular-nums; }
	.farazsms-notify-admin-wrapper .farazsms-req-guest,
	.farazsms-notify-admin-wrapper .farazsms-req-tag { display: inline-block; padding: 1px 8px; border-radius: 999px; font-size: 11px; background: #eef2f7; color: #64748b; }
	.farazsms-notify-admin-wrapper .farazsms-req-tag { margin-right: 6px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-date-cell { direction: ltr; font-variant-numeric: tabular-nums; }
	.farazsms-notify-admin-wrapper .farazsms-notify-pagination { display: flex; gap: 8px; align-items: center; }
	.farazsms-notify-admin-wrapper .farazsms-notify-page-info { color: #50575e; }
	.farazsms-notify-admin-wrapper .farazsms-status { display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: 12px; }
	.farazsms-notify-admin-wrapper .farazsms-status-success { background: #d1f5e0; color: #006d28; }
	.farazsms-notify-admin-wrapper .farazsms-status-warning { background: #fef3c7; color: #92400e; }
	.farazsms-notify-admin-wrapper .farazsms-notify-card { background: #fff; padding: 20px 24px; border: 1px solid #e5e7eb; border-radius: 10px; max-width: 760px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-card h2 { margin: 0 0 12px; font-size: 16px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-settings-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px 18px; margin: 12px 0 20px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-setting { display: flex; flex-direction: column; gap: 4px; font-size: 13px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-setting.farazsms-setting-wide { grid-column: 1 / -1; }
	.farazsms-notify-admin-wrapper .farazsms-notify-setting input { padding: 8px 10px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-help { color: #6b7280; font-size: 11px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-help code { background: #f3f4f6; padding: 1px 5px; border-radius: 3px; margin: 0 2px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-switch { display: inline-flex; align-items: center; gap: 8px; font-size: 13px; }
	.farazsms-notify-admin-wrapper .farazsms-notify-save-row { margin-top: 10px; }
	@media (max-width: 720px) {
		.farazsms-notify-admin-wrapper .farazsms-notify-stats { grid-template-columns: repeat(2, 1fr); }
		.farazsms-notify-admin-wrapper .farazsms-notify-settings-grid { grid-template-columns: 1fr; }
	}
	</style>
	<script>
	(function(){
		var ajaxUrl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
		var nonce   = <?php echo wp_json_encode( $nonce ); ?>;
		var selAll  = document.getElementById('farazsms-notify-select-all');
		var rows    = document.querySelectorAll('.farazsms-notify-row');
		var delBtn  = document.querySelector('.farazsms-notify-bulk-delete');
		var info    = document.querySelector('.farazsms-notify-bulk-info');
		function upd(){
			var c = Array.prototype.filter.call(rows, function(x){ return x.checked; });
			if (delBtn) {
				delBtn.disabled = c.length === 0;
				if (info) info.textContent = c.length ? (c.length + ' ردیف انتخاب شده') : '';
			}
		}
		if (selAll) selAll.addEventListener('change', function(){
			Array.prototype.forEach.call(rows, function(x){ x.checked = selAll.checked; });
			upd();
		});
		Array.prototype.forEach.call(rows, function(x){ x.addEventListener('change', upd); });
		if (delBtn) delBtn.addEventListener('click', function(){
			var c = Array.prototype.filter.call(rows, function(x){ return x.checked; });
			if (c.length === 0) return;
			if (!confirm('حذف ' + c.length + ' ردیف — مطمئن هستید؟')) return;
			var fd = new FormData();
			fd.append('action', 'farazsms_notify_delete');
			fd.append('nonce', nonce);
			c.forEach(function(x){ fd.append('ids[]', x.value); });
			delBtn.disabled = true;
			fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
				.then(function(r){ return r.json(); })
				.then(function(json){
					if (json.success) window.location.reload();
					else { alert((json.data && json.data.message) || 'خطا.'); delBtn.disabled = false; }
				})
				.catch(function(){ alert('خطا در ارتباط با سرور.'); delBtn.disabled = false; });
		});
	})();
	</script>
	<?php
}
