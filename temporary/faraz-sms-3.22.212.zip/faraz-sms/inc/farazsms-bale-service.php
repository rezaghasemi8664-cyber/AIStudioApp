<?php
/**
 * سرویسِ کانالِ بله (MVP) — تنها نقطه‌ی خروجِ ارسال + ترنسپورت.
 *
 * پارادایم (AD-1/AD-2): آداپتورِ یک‌طرفه. فیچرها فقط
 *
 *   farazsms_bale_maybe_send( $service_slug, $recipient|$recipients, $resolved_text )
 *
 * را «همگام» صدا می‌زنند؛ خودِ این تابع گِیت + async + timeout + لاگ را می‌بندد. هیچ فیچری
 * مستقیم farazsms_bale_request یا HTTP بله را صدا نمی‌زند.
 *
 * قویترین اینوریانت (AD-4): این مسیر **هرگز throw نمی‌کند** و هرگز render/checkout/ارسالِ
 * پیامک را بلاک نمی‌کند. ارسال بعد از بستنِ پاسخ به مرورگر (fastcgi/litespeed finish_request)
 * انجام می‌شود؛ روی mod_php همان‌جا ولی داخلِ try/catch. هر خطا/timeout → صرف‌نظر + لاگ.
 *
 * قرارداد payload (AD-6): متنِ حل‌شده به‌عنوانِ `message` به POST /messages (هرگز پترن).
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/** timeoutِ سختِ کوتاه برای هر درخواستِ بله (ثانیه). عمداً کوتاه تا هرگز کندی حس نشود. */
const FARAZSMS_BALE_TIMEOUT = 8;

/** سقفِ طولِ پیامِ بله (طبقِ قراردادِ وب‌سرویس). متنِ بلندتر بریده می‌شود تا کلِ POST رد نشود. */
const FARAZSMS_BALE_MAX_LEN = 4000;

/** سقفِ تعدادِ ارسالِ بله در «یک درخواست» — شبکه‌ی ایمنی برای مسیرِ inline/shutdownِ ارسالِ
 *  گروهی روی هاستِ بدونِ Action Scheduler (جلوگیری از runaway/timeout). مسیرِ Action Scheduler
 *  هر ارسال را در درخواستِ جدا اجرا می‌کند، پس این سقف آن‌جا اثری ندارد. */
const FARAZSMS_BALE_MAX_PER_REQUEST = 30;

// ─────────────────────────────────────────────────────────────────────────────
// واحدهای خالص (تست‌پذیر): نرمال‌سازیِ گیرنده، ساختِ payload، گِیت، تفسیرِ پاسخ.
// ─────────────────────────────────────────────────────────────────────────────

/**
 * گیرنده‌ی تکی یا آرایه‌ای را به فهرستِ موبایلِ نرمال‌شده‌ی یکتا تبدیل می‌کند.
 *
 * @param string|array $recipient
 * @return array فهرستِ شماره‌های نرمال‌شده (ممکن است خالی باشد).
 */
function farazsms_bale_normalize_recipients( $recipient ) {
	$list = is_array( $recipient ) ? $recipient : array( $recipient );
	$out  = array();
	foreach ( $list as $r ) {
		$r = is_string( $r ) ? trim( $r ) : ( is_int( $r ) ? (string) $r : '' );
		if ( $r === '' ) {
			continue;
		}
		$n = farazsms_normalize_phone( $r );
		if ( is_string( $n ) && $n !== '' ) {
			$out[] = $n;
		}
	}
	return array_values( array_unique( $out ) );
}

/**
 * بدنه‌ی POST /messages را می‌سازد: تک‌گیرنده → receptor، چندگیرنده → receptors[] (AD-6).
 *
 * @param array  $recipients فهرستِ نرمال‌شده (غیرخالی).
 * @param string $text       متنِ حل‌شده.
 * @return array
 */
function farazsms_bale_build_message_body( $recipients, $text ) {
	$recipients = array_values( array_filter( (array) $recipients, 'strlen' ) );
	$text       = (string) $text;
	// برشِ سختِ طول تا متنِ بلند کلِ POST (و در گروهی یک chunkِ ۱۰۰نفره) را بی‌صدا رد نکند.
	if ( function_exists( 'mb_strlen' ) ? mb_strlen( $text, 'UTF-8' ) > FARAZSMS_BALE_MAX_LEN : strlen( $text ) > FARAZSMS_BALE_MAX_LEN ) {
		$text = function_exists( 'mb_substr' ) ? mb_substr( $text, 0, FARAZSMS_BALE_MAX_LEN, 'UTF-8' ) : substr( $text, 0, FARAZSMS_BALE_MAX_LEN );
	}
	$body = array( 'message' => $text );
	if ( count( $recipients ) === 1 ) {
		$body['receptor'] = $recipients[0];
	} else {
		$body['receptors'] = $recipients;
	}
	return $body;
}

/**
 * آیا این سرویس در بله فعال است؟ «فعال = نبودن در option خاموش‌ها» (AD-9).
 * (registryِ کاملِ برچسب‌ها در استوریِ ۱.۳ اضافه می‌شود؛ این‌جا فقط گِیتِ فعال/خاموش.)
 *
 * @param string $slug
 * @return bool
 */
function farazsms_bale_service_enabled( $slug ) {
	$slug = (string) $slug;
	if ( $slug === '' ) {
		return false;
	}
	$disabled = get_option( 'farazsms_bale_disabled_services', array() );
	if ( ! is_array( $disabled ) ) {
		$disabled = array();
	}
	return ! in_array( $slug, $disabled, true );
}

/**
 * گِیتِ ارسال (AD-3): کلید تنظیم + سرویس فعال + گیرنده‌ی معتبر + متنِ ناتهی.
 * (شرطِ سومِ AD-3 — «پیامکش واقعاً رفته» — با «قاعده‌ی ترتیبِ فراخوانی» در سمتِ فیچر
 * تضمین می‌شود: maybe_send بلافاصله پس از ارسالِ موفقِ پیامک صدا زده می‌شود.)
 *
 * @param string $slug
 * @param array  $recipients
 * @param string $text
 * @return bool
 */
function farazsms_bale_should_send( $slug, $recipients, $text ) {
	if ( ! farazsms_bale_is_configured() ) {
		return false;
	}
	// مقید به registry (AD-9): فقط slugِ شناخته‌شده مجاز است — تا فراخوانیِ با slugِ اشتباه/تایپی
	// بی‌صدا ارسال نشود. (registry منبعِ واحدِ حقیقت است، نه فقط «نبودن در خاموش‌ها».)
	if ( ! in_array( (string) $slug, farazsms_bale_service_slugs(), true ) ) {
		return false;
	}
	if ( ! farazsms_bale_service_enabled( $slug ) ) {
		return false;
	}
	if ( ! is_array( $recipients ) || empty( $recipients ) ) {
		return false;
	}
	if ( ! is_string( $text ) || trim( $text ) === '' ) {
		return false;
	}
	return true;
}

/**
 * بازسازیِ «متنِ حل‌شده» از روی templateِ محلی + مقادیر — برای فیچرهایی که فقط
 * pattern_code+attributes به فراز می‌دهند (رهگیری، سبدِ رهاشده). placeholderها: %key% یا {key}
 * (همان فرمتِ پترنِ افزونه). چون endpointِ پترنِ بله غیرفعال است، بله به متنِ نهایی نیاز دارد.
 *
 * توجه: این متن، templateِ محلیِ افزونه است و ممکن است با متنِ دقیقِ ارسالیِ فراز کمی فرق کند
 * (فراز خطِ دامنه/برند را ته پترن اضافه می‌کند). برای MVP «متنِ یکسانِ تقریبی» کافی است.
 *
 * @param string $template
 * @param array  $values key => value
 * @return string
 */
function farazsms_bale_resolve_local_text( $template, $values ) {
	$template = (string) $template;
	if ( ! is_array( $values ) || empty( $values ) ) {
		return farazsms_bale_strip_unresolved_placeholders( $template );
	}
	// strtr تک‌گذر است: مقدارِ جای‌گذاری‌شده دوباره اسکن نمی‌شود (بر خلافِ str_replaceِ متوالی
	// که می‌گذاشت مقدارِ یک متغیر در placeholderِ متغیرِ دیگر تزریق شود).
	$map = array();
	foreach ( $values as $k => $v ) {
		if ( is_array( $v ) || is_object( $v ) ) {
			continue;
		}
		$k              = (string) $k;
		$map[ '%' . $k . '%' ] = (string) $v;
		$map[ '{' . $k . '}' ] = (string) $v;
	}
	$out = $map ? strtr( $template, $map ) : $template;
	// placeholderهای حل‌نشده (متغیرهایی که افزونه پُر نکرده) نباید عیناً به مشتری برسند.
	return farazsms_bale_strip_unresolved_placeholders( $out );
}

/**
 * حذفِ placeholderهای باقی‌مانده‌ی %key%/{key} که مقداری برایشان نبود — تا `%mobile%` خام به
 * پیامِ بله راه نیابد. فاصله‌های اضافیِ ناشی از حذف هم جمع می‌شوند.
 *
 * @param string $text
 * @return string
 */
function farazsms_bale_strip_unresolved_placeholders( $text ) {
	$text = preg_replace( '/%[a-zA-Z0-9_]+%|\{[a-zA-Z0-9_]+\}/', '', (string) $text );
	// جمع‌کردنِ فاصله‌های دوتاییِ به‌جامانده (نه شکستنِ خطوط).
	$text = preg_replace( '/[ \t]{2,}/', ' ', $text );
	return $text;
}

/**
 * پاسخِ HTTP را به رشته‌ی نتیجه‌ی سازگار با لاگِ «تشخیصِ ارسال» تبدیل می‌کند.
 * قراردادِ envelopeِ بله: {status:"success",data} یا {status:"error",error:{name,message,details}}.
 *
 * @param int          $http_code
 * @param string|array $body بدنه‌ی خام (JSON) یا آرایه‌ی decode-شده.
 * @return string 'success' | 'api_error:…' | 'curl_error:…'
 */
function farazsms_bale_interpret( $http_code, $body ) {
	$http_code = (int) $http_code;
	$data      = is_array( $body ) ? $body : ( is_string( $body ) && $body !== '' ? json_decode( $body, true ) : null );

	if ( is_array( $data ) && isset( $data['status'] ) && $data['status'] === 'success' ) {
		return 'success';
	}
	if ( is_array( $data ) && isset( $data['error'] ) ) {
		$err = $data['error'];
		if ( is_array( $err ) ) {
			$name = isset( $err['name'] ) ? (string) $err['name'] : '';
			$msg  = isset( $err['message'] ) ? (string) $err['message'] : '';
			$out  = trim( $name . ' ' . $msg );
			return 'api_error:' . ( $out !== '' ? $out : 'error' );
		}
		return 'api_error:' . (string) $err;
	}
	if ( $http_code === 0 ) {
		return 'curl_error:no_response';
	}
	return 'api_error:http_' . $http_code;
}

// ─────────────────────────────────────────────────────────────────────────────
// نقطه‌ی ورودِ واحد + async (الگوی صفِ به‌تأخیرافتاده‌ی پیامکِ سفارش، AD-2/AD-4).
// ─────────────────────────────────────────────────────────────────────────────

/**
 * نقطه‌ی ورودِ واحدِ ارسال در بله. فیچرها این را «همگام» صدا می‌زنند؛ خودش گِیت/async/لاگ
 * را می‌بندد و **هرگز throw نمی‌کند**.
 *
 * @param string       $service_slug slugِ فیچر (همان slugِ منوی افزونه).
 * @param string|array $recipient    موبایلِ تکی یا آرایه‌ای.
 * @param string       $resolved_text متنِ حل‌شده (همان متنی که برای پیامک ساخته شد).
 * @return void
 */
function farazsms_bale_maybe_send( $service_slug, $recipient, $resolved_text ) {
	try {
		$recipients = farazsms_bale_normalize_recipients( $recipient );
		if ( ! farazsms_bale_should_send( $service_slug, $recipients, $resolved_text ) ) {
			return;
		}
		$slug = (string) $service_slug;
		$text = (string) $resolved_text;
		$args = array( $slug, $recipients, $text );

		// v3.22.202: سه‌پله‌ی خصوصی (AS → shutdown → inline) حذف شد. صفِ مشترک
		// همان نردبان را دارد و علاوه بر آن ذخیره‌ی باقی‌مانده، اجراکننده و
		// کچ‌آپ. پله‌ی inline هم با آن می‌رود: روی mod_php دقیقاً همان ارسالِ
		// همگامی بود که این فاز از کلِ افزونه حذفش کرد.
		farazsms_queue_task( 'bale', 'farazsms_bale_deferred_send', $args );
		return;
	} catch ( \Throwable $e ) {
		// اینوریانتِ نهایی: هیچ خطایی به فراخواننده (پیامک/چک‌اوت) سرایت نکند.
		farazsms_bale_log_exception( $e, array( (string) $service_slug ) );
	}
}


/**
 * کارِ واقعیِ ارسال: بدنه را می‌سازد، به POST /messages می‌فرستد و نتیجه را لاگ می‌کند.
 *
 * @param string $service_slug
 * @param array  $recipients فهرستِ نرمال‌شده.
 * @param string $text       متنِ حل‌شده.
 */
function farazsms_bale_deferred_send( $service_slug, $recipients, $text ) {
	$recipients = (array) $recipients;
	if ( empty( $recipients ) ) {
		return;
	}
	// بازگِیت در «زمانِ اجرا» (نه فقط زمانِ صف‌گذاری): اگر بینِ صف‌شدن و اجرا، kill-switch روشن
	// شده یا این سرویس خاموش شده باشد، پیامِ صف‌شده هم نباید برود. تکمیلِ کاملِ kill-switch.
	if ( ! farazsms_bale_should_send( $service_slug, $recipients, (string) $text ) ) {
		return;
	}
	// شبکه‌ی ایمنی: روی مسیرِ inline/shutdownِ ارسالِ گروهی (هاستِ بدونِ Action Scheduler)، سقفِ
	// تعدادِ ارسال در همین درخواست تا از runaway/timeout جلوگیری شود. Action Scheduler هر ارسال
	// را در درخواستِ جدا اجرا می‌کند، پس این شمارنده آن‌جا صفر می‌ماند و اثری ندارد.
	static $sent_count = 0;
	if ( $sent_count >= FARAZSMS_BALE_MAX_PER_REQUEST ) {
		farazsms_send_diag_log( '', '', 'skipped:rate_cap', array( 'source' => 'bale:' . (string) $service_slug, 'http_code' => 0 ) );
		return;
	}
	$sent_count++;

	$body = farazsms_bale_build_message_body( $recipients, $text );
	$res  = farazsms_bale_request( 'POST', 'messages', $body );

	$label = count( $recipients ) === 1
		? $recipients[0]
		: ( $recipients[0] . '+' . ( count( $recipients ) - 1 ) );

	farazsms_send_diag_log( $label, '', $res['result'], array(
		'source'    => 'bale:' . (string) $service_slug,
		'http_code' => (int) $res['http_code'],
		'detail'    => (string) $res['detail'],
	) );
}

/**
 * ترنسپورتِ واحدِ بله (AD-5): یک wrapper روی base-URLِ کانفیگ + X-API-KEY، از طریقِ
 * farazsms_remote_*_with_fallback. هرگز throw نمی‌کند؛ همیشه آرایه‌ی نتیجه برمی‌گرداند.
 *
 * @param string $method
 * @param string $path نسبی، مثلِ 'messages' یا 'balance'.
 * @param array  $body
 * @return array {result, http_code, detail}
 */
function farazsms_bale_request( $method, $path, $body = array() ) {
	$method = strtoupper( (string) $method );
	$url    = farazsms_bale_base_url() . ltrim( (string) $path, '/' );
	$key    = farazsms_bale_apikey();
	if ( $key === '' ) {
		return array( 'result' => 'api_error:no_key', 'http_code' => 0, 'detail' => 'کلیدِ بله تنظیم نشده' );
	}

	$args = array(
		'method'  => $method,
		'timeout' => FARAZSMS_BALE_TIMEOUT,
		'headers' => array(
			'X-API-KEY'    => $key,
			'Content-Type' => 'application/json',
			'Accept'       => 'application/json',
		),
	);
	if ( $method !== 'GET' && ! empty( $body ) ) {
		$args['body'] = wp_json_encode( $body );
	}

	$response = ( $method === 'GET' )
		? farazsms_remote_get_with_fallback( $url, $args )
		: farazsms_remote_post_with_fallback( $url, $args );

	if ( is_wp_error( $response ) ) {
		$msg = $response->get_error_message();
		return array( 'result' => 'curl_error:' . $msg, 'http_code' => 0, 'detail' => $msg, 'body' => '' );
	}

	$http_code = (int) wp_remote_retrieve_response_code( $response );
	$body_str  = (string) wp_remote_retrieve_body( $response );
	return array(
		'result'    => farazsms_bale_interpret( $http_code, $body_str ),
		'http_code' => $http_code,
		'detail'    => function_exists( 'mb_substr' ) ? mb_substr( $body_str, 0, 255 ) : substr( $body_str, 0, 255 ), // برای لاگ (بریده)
		'body'      => $body_str, // بدنه‌ی کاملِ خام (برای decodeِ balance و…)
	);
}

/**
 * لاگِ امنِ استثنا (بدونِ throw). فقط اگر لاگِ تشخیص در دسترس باشد.
 *
 * @param \Throwable $e
 * @param array      $args
 */
function farazsms_bale_log_exception( $e, $args ) {
	$slug  = isset( $args[0] ) ? (string) $args[0] : '';
	$label = ( isset( $args[1] ) && is_array( $args[1] ) && ! empty( $args[1] ) ) ? (string) $args[1][0] : '';
	farazsms_send_diag_log( $label, '', 'curl_error:' . $e->getMessage(), array(
		'source'    => 'bale:' . $slug,
		'http_code' => 0,
		'detail'    => 'exception',
	) );
}
