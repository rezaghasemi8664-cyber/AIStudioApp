<?php
/**
 * مودالِ مدرنِ مشترکِ ادمین — به‌جای alert()های قدیمیِ مرورگر.
 *
 * تابعِ سراسریِ window.farazsmsFarazModal(message) را تعریف می‌کند که متنِ کامل را
 * (با حفظِ خطوط، اسکرول‌شونده) در یک پنجره‌ی زیبا نشان می‌دهد و نوعِ پیام را از
 * ایموجیِ ابتدای متن (✅/⚠️/❌) تشخیص می‌دهد. در گرویتی‌فرم و المنتور استفاده می‌شود.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

add_action( 'admin_footer', 'farazsms_admin_modal_assets', 1 );
function farazsms_admin_modal_assets() {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done = true;
	?>
	<style>
	.farazsms-fz-overlay{position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:1000000;display:flex;align-items:center;justify-content:center;padding:16px;direction:rtl;}
	.farazsms-fz-box{background:#fff;border-radius:16px;max-width:500px;width:100%;max-height:85vh;display:flex;flex-direction:column;box-shadow:0 24px 60px rgba(0,0,0,.3);overflow:hidden;font-family:inherit;}
	.farazsms-fz-head{padding:18px 22px 6px;font-size:16px;font-weight:800;display:flex;align-items:center;gap:8px;}
	.farazsms-fz-body{padding:4px 22px 16px;font-size:13.5px;line-height:2.1;color:#4d4d4d;white-space:pre-wrap;overflow-y:auto;flex:1;}
	.farazsms-fz-foot{padding:12px 22px 18px;text-align:left;border-top:1px solid #f5f8fe;}
	.farazsms-fz-ok{border:none;color:#fff;padding:9px 24px;border-radius:10px;font-size:13.5px;font-weight:700;cursor:pointer;font-family:inherit;}
	</style>
	<script type="text/javascript">
	window.farazsmsFarazModal = function( message ) {
		message = String( message );
		var type = message.indexOf('✅') === 0 ? 'success' : ( message.indexOf('⚠️') === 0 ? 'warning' : ( message.indexOf('❌') === 0 ? 'error' : 'info' ) );
		var color = { success:'#0c9765', warning:'#e2a916', error:'#d52a16', info:'#365891' }[ type ];
		var icon  = { success:'✅', warning:'⚠️', error:'❌', info:'💬' }[ type ];
		var title = { success:'انجام شد', warning:'توجه', error:'قابلِ ثبت نیست', info:'پیام' }[ type ];
		var body  = message.replace(/^(✅|⚠️|❌)\s*/, '');
		var old = document.querySelector('.farazsms-fz-overlay'); if ( old ) { old.remove(); }
		var ov = document.createElement('div'); ov.className = 'farazsms-fz-overlay';
		ov.innerHTML =
			'<div class="farazsms-fz-box" role="dialog" aria-modal="true">' +
			'<div class="farazsms-fz-head" style="color:' + color + '"><span>' + icon + '</span><span></span></div>' +
			'<div class="farazsms-fz-body"></div>' +
			'<div class="farazsms-fz-foot"><button type="button" class="farazsms-fz-ok" style="background:' + color + '">باشه، متوجه شدم</button></div>' +
			'</div>';
		ov.querySelector('.farazsms-fz-head span:last-child').textContent = title;
		ov.querySelector('.farazsms-fz-body').textContent = body;
		document.body.appendChild( ov );
		function close(){ ov.remove(); document.removeEventListener('keydown', onKey); }
		function onKey(e){ if ( e.key === 'Escape' ) { close(); } }
		ov.querySelector('.farazsms-fz-ok').addEventListener('click', close);
		ov.addEventListener('click', function(e){ if ( e.target === ov ) { close(); } });
		document.addEventListener('keydown', onKey);
		ov.querySelector('.farazsms-fz-ok').focus();
	};
	</script>
	<?php
}
