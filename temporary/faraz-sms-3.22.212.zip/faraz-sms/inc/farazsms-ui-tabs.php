<?php
/**
 * کامپوننتِ تبِ مشترکِ ادمین (UI Tabs).
 *
 * تا امروز هر صفحه تب را از نو می‌ساخت: پارامترهای URL متفاوت (?ct= ?tab= ?lt= ?st=
 * ?tt=)، گاهی JS، گاهی PHP، با استایل‌های ناهمگن. این فایل یک کامپوننتِ واحد و
 * بدونِ-JS (ناوبریِ مبتنی بر لینک، مقاوم) فراهم می‌کند تا صفحاتِ جدید و بازسازی‌شده
 * همگی یک تبِ یکدست داشته باشند. استایل با همان زبانِ بصریِ مدرنِ افزونه (underline).
 *
 * استفاده:
 *   $tabs = array(
 *       'settings' => 'تنظیمات',
 *       'list'     => array( 'label' => 'فهرست', 'icon' => 'dashicons-list-view', 'badge' => 12 ),
 *   );
 *   $current = farazsms_tabs_current( $tabs, 'tab', 'settings' );
 *   farazsms_render_tabs( $tabs, $current, array( 'param' => 'tab' ) );
 *   // سپس بر اساس $current محتوای تب را رندر کنید.
 *
 * @package FarazSMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * کلیدِ تبِ فعالِ فعلی را از روی پارامترِ URL تعیین می‌کند (با اعتبارسنجی).
 *
 * @param array  $tabs    آرایه‌ی تب‌ها (key => label|spec).
 * @param string $param   نامِ پارامترِ URL (پیش‌فرض 'tab').
 * @param string $default کلیدِ پیش‌فرض اگر چیزی در URL نبود.
 * @return string کلیدِ تبِ معتبر.
 */
function farazsms_tabs_current( $tabs, $param = 'tab', $default = '' ) {
	$keys = array_keys( (array) $tabs );
	if ( $default === '' && $keys ) {
		$default = $keys[0];
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- فقط انتخابِ تب (read-only).
	$req = isset( $_GET[ $param ] ) ? sanitize_key( wp_unslash( $_GET[ $param ] ) ) : '';
	return in_array( $req, $keys, true ) ? $req : $default;
}

/**
 * رندرِ نوارِ تب‌ها (ناوبریِ مبتنی بر لینک — بدونِ نیاز به JS).
 *
 * @param array  $tabs        key => label یا key => array{label, icon?, badge?, url?}.
 * @param string $current_key کلیدِ تبِ فعال.
 * @param array  $args {
 *     @type string $param    نامِ پارامترِ URL (پیش‌فرض 'tab').
 *     @type string $base_url URL پایه (پیش‌فرض: صفحه‌ی ادمینِ فعلی با page فعلی).
 *     @type array  $extra    پارامترهای اضافیِ query که باید روی هر لینک حفظ شوند.
 * }
 * @return void خروجی را echo می‌کند.
 */
function farazsms_render_tabs( $tabs, $current_key, $args = array() ) {
	if ( empty( $tabs ) ) {
		return;
	}
	$param = isset( $args['param'] ) ? $args['param'] : 'tab';

	// URL پایه: صفحه‌ی فعلیِ ادمین با همان page.
	if ( ! empty( $args['base_url'] ) ) {
		$base_url = $args['base_url'];
	} else {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$page     = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		$base_url = admin_url( 'admin.php?page=' . $page );
	}
	$extra = isset( $args['extra'] ) && is_array( $args['extra'] ) ? $args['extra'] : array();

	farazsms_tabs_print_styles();

	echo '<nav class="farazsms-tabs" role="tablist">';
	foreach ( $tabs as $key => $spec ) {
		$label = is_array( $spec ) ? ( isset( $spec['label'] ) ? $spec['label'] : $key ) : $spec;
		$icon  = is_array( $spec ) && ! empty( $spec['icon'] ) ? $spec['icon'] : '';
		$badge = is_array( $spec ) && isset( $spec['badge'] ) && $spec['badge'] !== '' ? $spec['badge'] : null;
		$url   = is_array( $spec ) && ! empty( $spec['url'] )
			? $spec['url']
			: add_query_arg( array_merge( $extra, array( $param => $key ) ), $base_url );

		$is_active = ( (string) $key === (string) $current_key );
		$cls       = 'farazsms-tab' . ( $is_active ? ' is-active' : '' );

		printf(
			'<a class="%s" href="%s" role="tab" aria-selected="%s">',
			esc_attr( $cls ),
			esc_url( $url ),
			$is_active ? 'true' : 'false'
		);
		if ( $icon ) {
			printf( '<span class="dashicons %s"></span>', esc_attr( $icon ) );
		}
		echo '<span class="farazsms-tab-label">' . esc_html( $label ) . '</span>';
		if ( $badge !== null ) {
			echo '<span class="farazsms-tab-badge">' . esc_html( $badge ) . '</span>';
		}
		echo '</a>';
	}
	echo '</nav>';
}

/**
 * استایلِ تب‌ها — یک‌بار در هر بارگذاریِ صفحه چاپ می‌شود.
 *
 * @return void
 */
function farazsms_tabs_print_styles() {
	static $printed = false;
	if ( $printed ) {
		return;
	}
	$printed = true;
	?>
<style id="farazsms-ui-tabs">
.farazsms-tabs{display:flex;flex-wrap:wrap;gap:4px;border-bottom:2px solid #e1e1e1;margin:0 0 20px;padding:0}
.farazsms-tabs .farazsms-tab{display:inline-flex;align-items:center;gap:6px;padding:10px 16px;margin-bottom:-2px;
	border-bottom:2px solid transparent;color:#4d4d4d;text-decoration:none;font-weight:600;font-size:13px;
	transition:color .15s,border-color .15s;border-radius:6px 6px 0 0}
.farazsms-tabs .farazsms-tab:hover{color:#1e293b;background:#f5f8fe}
.farazsms-tabs .farazsms-tab.is-active{color:#365891;border-bottom-color:#365891}
.farazsms-tabs .farazsms-tab .dashicons{width:18px;height:18px;font-size:18px;line-height:1}
.farazsms-tabs .farazsms-tab-badge{display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;
	padding:0 5px;border-radius:9px;background:#d52a16;color:#fff;font-size:11px;font-weight:700}
.farazsms-tabs .farazsms-tab.is-active .farazsms-tab-badge{background:#365891}
@media(max-width:600px){.farazsms-tabs{gap:0}.farazsms-tabs .farazsms-tab{padding:9px 11px;font-size:12px}}
</style>
	<?php
}
