<?php
/**
 * یکپارچه‌سازی با افزونه‌های تیکتِ پشتیبانی — فعلاً «Awesome Support».
 *
 * ⚠️ چرا فقط Awesome Support و نه «افزونه تیکت پشتیبانی پیشرفته»ی ایرانی:
 * آن افزونه از قبل یک فهرستِ درونیِ سرویس‌دهنده‌های پیامکی دارد و **فراز اس‌ام‌اس
 * همین حالا در آن فهرست هست** — یعنی اتصالش «پیکربندی» است نه «کد»، و راهنمایش
 * روی سایتِ فراز منتشر شده. نوشتنِ کد برایش هم بی‌فایده است و هم شدنی نیست (تجاری
 * و بخشی از فایل‌هایش ionCube-encoded است، پس هوکی هم قابلِ تأیید نیست).
 *
 * هوک‌های زیر همگی از منبعِ Awesome Support 6.3.9 استخراج و تأیید شده‌اند — نه از
 * وبلاگ. (درسِ بوکلی: هوکِ نقل‌شده در وبلاگ‌ها ممکن است اصلاً وجود نداشته باشد.)
 *
 * wpas_open_ticket_after      ( $ticket_id, $data )
 * wpas_add_reply_complete     ( $reply_id, $data )
 * wpas_ticket_status_updated  ( $post_id, $status, $updated )
 * wpas_after_close_ticket     ( $ticket_id, $update, $user_id )
 *
 * دو تلهٔ شناخته‌شده که رعایت شده‌اند:
 *   ۱) wpas_open_ticket_after در تابعی زندگی می‌کند که مسیرِ «به‌روزرسانی» را هم
 *      اداره می‌کند، پس create-only نیست → با متایِ یک‌بارمصرف idempotent شده.
 *   ۲) تشخیصِ «پشتیبان یا مشتری» با is_admin() اشتباه است (پشتیبان ممکن است از
 *      فرانت پاسخ دهد). معیارِ خودِ افزونه هم همین است: قابلیتِ edit_ticket.
 *
 * کارایی: ارسال هرگز مسیرِ ذخیره‌ی تیکت را بلاک نمی‌کند — صف روی shutdown و پس از
 * اجراکننده‌ی صفِ مشترک خالی می‌شود (v3.22.202: دیگر به finish_request گره نیست).
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_TICKETS_OPTION = 'farazsms_tickets_settings';

// صف و سقف و باقی‌مانده، همه در لایه‌ی مشترک است:
//
// inc/farazsms-send-queue.php

// ============================================================================
// تشخیص و تنظیمات
// ============================================================================

/**
 * آیا Awesome Support فعال است؟ معیار، وجودِ تابعِ خودِ افزونه است.
 *
 * @return bool
 */
function farazsms_tickets_as_active() {
	return function_exists( 'wpas_insert_reply' ) || class_exists( 'Awesome_Support' );
}

/**
 * رویدادهای پشتیبانی‌شده → برچسب + گیرنده.
 *
 * @return array
 */
function farazsms_tickets_events() {
	return array(
		'created'        => array( 'label' => 'ثبتِ تیکتِ جدید', 'to' => 'agent' ),
		'created_client' => array( 'label' => 'تأییدِ ثبت برای مشتری', 'to' => 'client' ),
		'agent_reply'    => array( 'label' => 'پاسخِ پشتیبانی → به مشتری', 'to' => 'client' ),
		'client_reply'   => array( 'label' => 'پاسخِ مشتری → به پشتیبان', 'to' => 'agent' ),
		'status'         => array( 'label' => 'تغییرِ وضعیتِ تیکت → به مشتری', 'to' => 'client' ),
		'closed'         => array( 'label' => 'بستنِ تیکت → به مشتری', 'to' => 'client' ),
	);
}

/**
 * @return array
 */
function farazsms_tickets_settings() {
	$defaults = array(
		'enabled'     => '0',
		'admin_phone' => '',
		'events'      => array(),
	);
	foreach ( farazsms_tickets_default_messages() as $key => $msg ) {
		$defaults['events'][ $key ] = array( 'enabled' => '0', 'pattern_code' => '', 'message' => $msg );
	}
	$saved = get_option( FARAZSMS_TICKETS_OPTION, array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}
	$out    = array_merge( $defaults, $saved );
	$events = is_array( $out['events'] ?? null ) ? $out['events'] : array();
	// ادغامِ هر رویداد جداگانه تا متنِ پیش‌فرض با ذخیره‌ی فرم گم نشود.
	foreach ( $defaults['events'] as $key => $default_event ) {
		$out['events'][ $key ] = array_merge( $default_event, is_array( $events[ $key ] ?? null ) ? $events[ $key ] : array() );
	}
	return $out;
}

/**
 * کدِ پترنِ یک رویداد، یا رشته‌ی خالی اگر خاموش است.
 *
 * @param string $event
 * @return string
 */
function farazsms_tickets_pattern( $event ) {
	$s = farazsms_tickets_settings();
	if ( ( $s['enabled'] ?? '0' ) !== '1' ) {
		return '';
	}
	$cfg = $s['events'][ $event ] ?? array();
	if ( ( $cfg['enabled'] ?? '0' ) !== '1' ) {
		return '';
	}
	return trim( (string) ( $cfg['pattern_code'] ?? '' ) );
}

/**
 * متغیرهای قابلِ استفاده در پترنِ تیکت.
 *
 * @return array
 */
function farazsms_tickets_pattern_vars() {
	return array( '%ticket_id%', '%ticket_title%', '%client_name%', '%agent_name%', '%sitename%' );
}

/**
 * متنِ پیش‌فرضِ هر رویداد — ورودیِ «ساختِ خودکارِ پترن».
 *
 * @return array
 */
function farazsms_tickets_default_messages() {
	return array(
		'created'        => 'تیکتِ جدید ثبت شد.' . "\n" . 'شماره: %ticket_id%' . "\n" . 'موضوع: %ticket_title%' . "\n" . 'از: %client_name%' . "\n" . '%sitename%',
		'created_client' => '%client_name% عزیز، تیکتِ شما با شمارهٔ %ticket_id% ثبت شد و به‌زودی بررسی می‌شود.' . "\n" . '%sitename%',
		'agent_reply'    => '%client_name% عزیز، به تیکتِ شماره %ticket_id% پاسخ داده شد.' . "\n" . 'موضوع: %ticket_title%' . "\n" . '%sitename%',
		'client_reply'   => 'پاسخِ جدید از %client_name% روی تیکتِ شماره %ticket_id%' . "\n" . 'موضوع: %ticket_title%' . "\n" . '%sitename%',
		'status'         => 'وضعیتِ تیکتِ شماره %ticket_id% تغییر کرد.' . "\n" . 'موضوع: %ticket_title%' . "\n" . '%sitename%',
		'closed'         => '%client_name% عزیز، تیکتِ شماره %ticket_id% بسته شد.' . "\n" . 'در صورتِ نیاز می‌توانید دوباره باز کنید.' . "\n" . '%sitename%',
	);
}

add_filter( 'farazsms_feature_pattern_map', 'farazsms_tickets_register_pattern_features' );
/**
 * ثبتِ رویدادهای تیکت در سامانه‌ی «ساختِ خودکارِ پترن».
 *
 * @param array $map
 * @return array
 */
function farazsms_tickets_register_pattern_features( $map ) {
	foreach ( array_keys( farazsms_tickets_default_messages() ) as $event ) {
		$map[ 'tickets_' . $event ] = array(
			'opt'     => FARAZSMS_TICKETS_OPTION,
			'section' => 'tickets',
			'path'    => array( 'events', $event ),
		);
	}
	return $map;
}

// ============================================================================
// شماره‌ی موبایلِ کاربر — همان ترتیبی که بقیه‌ی ماژول‌ها استفاده می‌کنند
// ============================================================================

/**
 * @param int $user_id
 * @return string
 */
function farazsms_tickets_user_phone( $user_id ) {
	$user_id = (int) $user_id;
	if ( $user_id <= 0 ) {
		return '';
	}
	$phone = (string) get_user_meta( $user_id, 'mobile_number', true );
	if ( trim( $phone ) === '' ) {
		$phone = (string) get_user_meta( $user_id, 'billing_phone', true );
	}
	$phone = trim( $phone );
	return (string) farazsms_normalize_phone( $phone );
}

/**
 * پشتیبانِ تخصیص‌داده‌شده‌ی یک تیکت.
 *
 * @param int $ticket_id
 * @return int
 */
function farazsms_tickets_assignee( $ticket_id ) {
	return (int) get_post_meta( (int) $ticket_id, '_wpas_assignee', true );
}

/**
 * متغیرهای پترن برای یک تیکت.
 *
 * @param int $ticket_id
 * @return array
 */
function farazsms_tickets_vars( $ticket_id ) {
	$ticket_id = (int) $ticket_id;
	$ticket    = get_post( $ticket_id );
	$client    = $ticket ? (int) $ticket->post_author : 0;
	$agent     = farazsms_tickets_assignee( $ticket_id );

	$client_user = $client > 0 ? get_userdata( $client ) : false;
	$agent_user  = $agent > 0 ? get_userdata( $agent ) : false;

	return array(
		'ticket_id'    => (string) $ticket_id,
		'ticket_title' => $ticket ? (string) $ticket->post_title : '',
		'client_name'  => $client_user ? (string) $client_user->display_name : '',
		'agent_name'   => $agent_user ? (string) $agent_user->display_name : '',
		'sitename'     => get_bloginfo( 'name' ),
	);
}

/**
 * ارسالِ یک رویداد به گیرنده‌ی مناسب.
 *
 * @param string $event
 * @param int    $ticket_id
 */
/**
 * ادعای یک‌بارمصرفِ (تیکت، رویداد) — با add_post_meta که روی همان ردیف اتمیک است.
 *
 * پیش‌تر فقط رویدادِ «ثبتِ تیکت» گاردِ یک‌بارمصرف داشت و «پاسخ»/«تغییرِ وضعیت»
 * هیچ‌کدام؛ هر بار شلیکِ دوباره‌ی هوک یک پیامکِ تکراری برای مشتری می‌فرستاد.
 *
 * @param int    $ticket_id
 * @param string $event
 * @param string $suffix شناسه‌ی یکتای همین رخداد (مثلاً شناسه‌ی پاسخ یا وضعیتِ تازه)
 * @return bool
 */
function farazsms_tickets_claim( $ticket_id, $event, $suffix = '' ) {
	$key = '_farazsms_tkt_' . $event . ( $suffix !== '' ? '_' . $suffix : '' );
	// add_post_meta با unique=true فقط وقتی موفق می‌شود که از قبل نباشد.
	return (bool) add_post_meta( (int) $ticket_id, $key, 1, true );
}

function farazsms_tickets_dispatch( $event, $ticket_id, $suffix = '' ) {
	$pattern = farazsms_tickets_pattern( $event );
	if ( $pattern === '' ) {
		return;
	}

	$events = farazsms_tickets_events();
	$to     = $events[ $event ]['to'] ?? 'client';
	$ticket = get_post( (int) $ticket_id );
	if ( ! $ticket ) {
		return;
	}

	if ( $to === 'client' ) {
		$phone = farazsms_tickets_user_phone( (int) $ticket->post_author );
	} else {
		$phone = farazsms_tickets_user_phone( farazsms_tickets_assignee( $ticket_id ) );
		if ( $phone === '' ) {
			// پشتیبانی تخصیص داده نشده؟ شماره‌ی مدیرِ تنظیمات جایگزین می‌شود.
			$s     = farazsms_tickets_settings();
			$phone = trim( (string) $s['admin_phone'] );
		}
	}
	if ( $phone === '' ) {
		// ⚠️ ادعا فقط وقتی ثبت می‌شود که واقعاً شماره‌ای برای ارسال هست — وگرنه
		// مشتریِ بدونِ شماره آن رویداد را برای همیشه از دست می‌داد.
		return;
	}
	if ( ! farazsms_tickets_claim( $ticket_id, $event, $suffix ) ) {
		return; // این رخداد قبلاً پیامک شده
	}
	// صفِ مشترک: ارسال بعد از بسته‌شدنِ پاسخ انجام می‌شود تا ذخیره‌ی تیکت کند نشود.
	farazsms_queue_send( 'tickets', $phone, $pattern, farazsms_tickets_vars( $ticket_id ), array( 'event' => $event ) );
}

// ============================================================================
// هوک‌های Awesome Support
// ============================================================================

add_action( 'wpas_open_ticket_after', 'farazsms_tickets_on_open', 20, 2 );
/**
 * ثبتِ تیکتِ جدید.
 *
 * این هوک create-only نیست (همان تابع مسیرِ به‌روزرسانی را هم اداره می‌کند)، پس با
 * متایِ یک‌بارمصرف idempotent می‌شود — وگرنه هر ویرایشِ تیکت یک پیامکِ «تیکتِ جدید»
 * می‌فرستاد.
 *
 * @param int   $ticket_id
 * @param array $data
 */
function farazsms_tickets_on_open( $ticket_id, $data = array() ) {
	$ticket_id = (int) $ticket_id;
	if ( $ticket_id <= 0 ) {
		return;
	}
	// idempotency حالا داخلِ dispatch است (برای همه‌ی رویدادها، نه فقط این یکی).
	farazsms_tickets_dispatch( 'created', $ticket_id );
	farazsms_tickets_dispatch( 'created_client', $ticket_id );
}

add_action( 'wpas_add_reply_complete', 'farazsms_tickets_on_reply', 20, 2 );
/**
 * پاسخِ جدید — تشخیصِ پشتیبان از مشتری با قابلیتِ edit_ticket (همان معیارِ خودِ
 * Awesome Support). is_admin() اشتباه است چون پشتیبان ممکن است از فرانت پاسخ دهد.
 *
 * @param int   $reply_id
 * @param array $data
 */
function farazsms_tickets_on_reply( $reply_id, $data = array() ) {
	$ticket_id = (int) ( $data['post_parent'] ?? 0 );
	if ( $ticket_id <= 0 ) {
		$reply     = get_post( (int) $reply_id );
		$ticket_id = $reply ? (int) $reply->post_parent : 0;
	}
	if ( $ticket_id <= 0 ) {
		return;
	}
	$reply_post = get_post( (int) $reply_id );
	$author     = (int) ( $data['post_author'] ?? 0 );
	if ( $author <= 0 ) {
		$author = $reply_post ? (int) $reply_post->post_author : 0;
	}

	// یادداشتِ خصوصیِ پشتیبان «پاسخ» نیست و نباید به مشتری اطلاع داده شود.
	$status = (string) ( $data['post_status'] ?? ( $reply_post ? $reply_post->post_status : '' ) );
	if ( $status === 'private' || ! empty( $data['is_note'] ) ) {
		return;
	}

	$is_agent = $author > 0 && user_can( $author, 'edit_ticket' );

	// شناسه‌ی پاسخ به‌عنوانِ پسوند: هر پاسخ یک‌بار، ولی پاسخ‌های بعدی آزادند.
	farazsms_tickets_dispatch( $is_agent ? 'agent_reply' : 'client_reply', $ticket_id, (string) (int) $reply_id );
}

add_action( 'wpas_ticket_status_updated', 'farazsms_tickets_on_status', 20, 3 );
/**
 * @param int   $post_id
 * @param mixed $status
 * @param mixed $updated نتیجه‌ی wp_update_post — اگر falsy باشد چیزی تغییر نکرده
 */
function farazsms_tickets_on_status( $post_id, $status = '', $updated = null ) {
	if ( empty( $updated ) || is_wp_error( $updated ) ) {
		return;
	}
	// docblockِ خودِ هوک نوعِ این آرگومان را mixed اعلام کرده؛ castِ بی‌گاردِ آرایه
	// یا آبجکت، وسطِ ذخیره‌ی تیکت خطای مرگبار می‌داد.
	if ( ! is_scalar( $status ) ) {
		$status = '';
	}
	$status = (string) $status;
	// بستنِ تیکت هم «تغییرِ وضعیت» است و هم رویدادِ «بسته شد». اگر هر دو بروند،
	// مشتری برای یک اتفاق دو پیامک می‌گیرد.
	// ⚠️ متایِ وضعیت فقط وقتی مشورت می‌شود که خودِ هوک وضعیتی نداده باشد. اگر
	// به‌صورتِ OR سنجیده شود، «بازکردنِ دوباره‌ی تیکتِ بسته» هم خفه می‌شد: آرگومان
	// open است ولی متا هنوز closed را نشان می‌دهد، و رویدادِ «بسته شد» هم برای
	// بازشدن شلیک نمی‌شود — یعنی مشتری هیچ پیامکی نمی‌گرفت.
	$closed = ( $status !== '' )
		? ( $status === 'closed' )
		: ( (string) get_post_meta( (int) $post_id, '_wpas_status', true ) === 'closed' );
	if ( $closed && farazsms_tickets_pattern( 'closed' ) !== '' ) {
		return;
	}
	// پسوندِ وضعیت: هر وضعیتِ تازه یک‌بار پیامک می‌شود، ولی تغییرِ بعدی آزاد است.
	// وضعیتِ خالی نباید همه‌ی تغییرها را به یک کلیدِ ادعا فرو بکاهد.
	// پسوندِ ثابت برای وضعیتِ ناشناخته — با timestamp، هر رخداد کلیدِ تازه می‌گرفت
	// و گاردِ ضدِتکرار عملاً بی‌اثر می‌شد (به‌علاوه‌ی یک ردیفِ متایِ دائمی در هر بار).
	$suffix = sanitize_key( $status );
	if ( $suffix === '' ) {
		$suffix = 'unknown';
	}
	farazsms_tickets_dispatch( 'status', (int) $post_id, $suffix );
}

add_action( 'wpas_after_close_ticket', 'farazsms_tickets_on_close', 20, 1 );
/**
 * @param int $ticket_id
 */
function farazsms_tickets_on_close( $ticket_id ) {
	// پسوندِ شمارنده: تیکتی که بسته، دوباره باز و دوباره بسته شود باید بارِ دوم هم
	// پیامک بگیرد. بدونِ پسوند، کلیدِ ادعا ثابت می‌ماند و بارِ دوم ساکت می‌شد.
	$ticket_id = (int) $ticket_id;
	$round     = (int) get_post_meta( $ticket_id, '_farazsms_tkt_close_round', true );
	$round++;
	update_post_meta( $ticket_id, '_farazsms_tkt_close_round', $round );
	farazsms_tickets_dispatch( 'closed', $ticket_id, (string) $round );
}

// ============================================================================
// صفحه‌ی تنظیمات
// ============================================================================

add_action( 'admin_menu', 'farazsms_tickets_menu', 20 );
function farazsms_tickets_menu() {
	add_submenu_page(
		'farazsms',
		__( 'پیامک تیکت مشتریان', 'farazsms' ),
		__( 'پیامک تیکت مشتریان', 'farazsms' ),
		'manage_options',
		'farazsms-tickets',
		'farazsms_tickets_render_page'
	);
}

add_action( 'admin_init', 'farazsms_tickets_handle_save' );
function farazsms_tickets_handle_save() {
	if ( ! isset( $_POST['farazsms_tickets_nonce'] ) ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['farazsms_tickets_nonce'] ) ), 'farazsms_tickets_save' ) ) {
		return;
	}
	$settings                = farazsms_tickets_settings();
	$settings['enabled']     = isset( $_POST['farazsms_tickets_enabled'] ) ? '1' : '0';
	$settings['admin_phone'] = sanitize_text_field( wp_unslash( $_POST['farazsms_tickets_admin_phone'] ?? '' ) );

	foreach ( array_keys( farazsms_tickets_default_messages() ) as $key ) {
		// متنِ پیامک را «سازنده‌ی پترن» می‌نویسد، نه این فرم.
		$settings['events'][ $key ]['enabled']      = isset( $_POST[ 'farazsms_tickets_ev_' . $key ] ) ? '1' : '0';
		$settings['events'][ $key ]['pattern_code'] = sanitize_text_field( wp_unslash( $_POST[ 'farazsms_tickets_pat_' . $key ] ?? '' ) );
	}
	update_option( FARAZSMS_TICKETS_OPTION, $settings, false );

	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-success is-dismissible"><p>تنظیماتِ پیامکِ تیکت ذخیره شد.</p></div>';
	} );
}

function farazsms_tickets_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$settings = farazsms_tickets_settings();
	$events   = farazsms_tickets_events();
	$active   = farazsms_tickets_as_active();
	$vars     = farazsms_tickets_pattern_vars();
	$has_ui   = function_exists( 'farazsms_feature_pattern_builder_ui' );
	?>
	<div class="wrap" dir="rtl">
		<h1>🎫 پیامک تیکت مشتریان</h1>

		

		<?php if ( ! $active ) : ?>
			<div class="notice notice-warning"><p>
				افزونهٔ <strong>Awesome Support</strong> روی این سایت پیدا نشد. تنظیماتِ زیر ذخیره می‌شود ولی تا نصبِ آن اثری ندارد.
			</p></div>
		<?php endif; ?>

		<div class="farazsms-int-intro">
			<strong>راه‌اندازی در ۳ قدم:</strong>
			<ol>
				<li>کلیدِ «پیامکِ تیکت فعال باشد» را روشن کنید.</li>
				<li>برای هر رویداد، تیکش را بزنید، متن را ویرایش کنید و دکمهٔ <strong>ساخت/ویرایشِ پترن</strong> را بزنید.</li>
				<li>«ذخیره تنظیمات».</li>
			</ol>
			پیامک‌ها پس از بسته‌شدنِ صفحه ارسال می‌شوند، پس ثبتِ تیکت برای کاربر کند نمی‌شود.
		</div>

		<form method="post" action="">
			<?php wp_nonce_field( 'farazsms_tickets_save', 'farazsms_tickets_nonce' ); ?>

			<div class="farazsms-int-card">
				<div class="farazsms-int-card__head">
					<h2 class="farazsms-int-card__title">وضعیتِ کلی</h2>
					<label class="farazsms-int-toggle">
						<input type="checkbox" name="farazsms_tickets_enabled" value="1" <?php checked( $settings['enabled'], '1' ); ?>>
						پیامکِ تیکت فعال باشد
					</label>
				</div>
				<div class="farazsms-int-card__body">
					<div class="farazsms-int-field">
						<label for="farazsms-tickets-adminphone">شمارهٔ مدیر (وقتی تیکت هنوز به پشتیبانی تخصیص نیافته)</label>
						<input id="farazsms-tickets-adminphone" type="text" dir="ltr" name="farazsms_tickets_admin_phone" value="<?php echo esc_attr( $settings['admin_phone'] ); ?>" placeholder="09xxxxxxxxx">
						<p class="farazsms-int-hint">
							موبایلِ مشتری و پشتیبان از پروفایلِ کاربریِ وردپرس خوانده می‌شود (اول فیلدِ موبایل، بعد موبایلِ صورتحسابِ ووکامرس).
							خودِ Awesome Support فیلدِ موبایل ندارد.
						</p>
					</div>
				</div>
			</div>

			<?php foreach ( $events as $key => $meta ) :
				$cfg = $settings['events'][ $key ] ?? array(); ?>
				<div class="farazsms-int-card">
					<div class="farazsms-int-card__head">
						<h2 class="farazsms-int-card__title"><?php echo esc_html( $meta['label'] ); ?></h2>
						<label class="farazsms-int-toggle">
							<input type="checkbox" name="<?php echo esc_attr( 'farazsms_tickets_ev_' . $key ); ?>" value="1" <?php checked( $cfg['enabled'] ?? '0', '1' ); ?>>
							فعال
						</label>
					</div>
					<div class="farazsms-int-card__body">
						<div class="farazsms-int-field">
							<label for="<?php echo esc_attr( 'farazsms-tickets-pat-' . $key ); ?>">کدپترن</label>
							<input id="<?php echo esc_attr( 'farazsms-tickets-pat-' . $key ); ?>" type="text" dir="ltr" name="<?php echo esc_attr( 'farazsms_tickets_pat_' . $key ); ?>" value="<?php echo esc_attr( $cfg['pattern_code'] ?? '' ); ?>" placeholder="با دکمهٔ زیر خودکار پر می‌شود">
						</div>
						<?php if ( $has_ui ) {
							farazsms_feature_pattern_builder_ui( 'tickets_' . $key, (string) ( $cfg['message'] ?? '' ), $vars, 'farazsms_tickets_pat_' . $key );
						} else { ?>
							<div class="farazsms-int-vars"><?php foreach ( $vars as $v ) : ?><code><?php echo esc_html( $v ); ?></code><?php endforeach; ?></div>
						<?php } ?>
					</div>
				</div>
			<?php endforeach; ?>

			<p><button type="submit" class="button button-primary">💾 ذخیره تنظیمات</button></p>
		</form>

		<?php do_action( 'farazsms_tickets_after_settings' ); ?>

		<div class="farazsms-int-intro">
			<strong>سؤال‌های پرتکرار</strong>
			<ul>
				<li><strong>پیامک نمی‌رود؟</strong> کاربرِ مقصد باید در پروفایلش شمارهٔ موبایل داشته باشد؛ Awesome Support خودش فیلدِ موبایل ندارد.</li>
				<li><strong>پاسخِ پشتیبان با پاسخِ مشتری اشتباه گرفته می‌شود؟</strong> ملاکِ ما دسترسیِ کاربر است نه محلِ پاسخ، پس پاسخِ پشتیبان از بخشِ کاربری هم درست تشخیص داده می‌شود.</li>
				<li><strong>هنگام بستنِ تیکت دو پیامک می‌آید؟</strong> نمی‌آید — اگر رویدادِ «بستنِ تیکت» روشن باشد، رویدادِ «تغییرِ وضعیت» برای همان لحظه ساکت می‌ماند.</li>
			</ul>
		</div>
	</div>
	<?php
}

add_filter( 'farazsms_compatibility_registry', 'farazsms_tickets_register_compat' );
/**
 * @param array $registry
 * @return array
 */
function farazsms_tickets_register_compat( $registry ) {
	$registry['awesome_support'] = array(
		'name'   => 'Awesome Support',
		'what'   => 'پیامکِ ثبتِ تیکت، پاسخِ پشتیبانی، پاسخِ مشتری، تغییرِ وضعیت و بستنِ تیکت',
		'group'  => 'core',
		'detect' => 'farazsms_tickets_as_active',
	);
	return $registry;
}

add_filter( 'farazsms_nav_extra', 'farazsms_tickets_register_nav' );
/**
 * @param array $nav
 * @return array
 */
function farazsms_tickets_register_nav( $nav ) {
	$nav['farazsms-tickets'] = array(
		// نامِ متمایز: «بازخورد» تیکتِ پشتیبانیِ خودِ ماست؛ این یکی تیکتِ مشتریانِ
		// فروشگاه در Awesome Support است و نباید با آن اشتباه شود.
		'title' => 'تیکت مشتریان (Awesome Support)',
		'icon'  => 'dashicons-tickets',
		'desc'  => 'پیامکِ تیکت‌هایی که مشتریانِ شما ثبت می‌کنند',
		'group' => 'wp',
		'when'  => 'farazsms_tickets_as_active',
	);
	return $nav;
}
