<?php
/**
 * طبقه‌بندیِ نتیجه‌ی ارسال — تنها تعریفِ «این نتیجه چه وضعیتی دارد».
 *
 * ⚠️ چرا فایلِ جدا (بازبینیِ ۱۴۰۵/۰۶/۱۶): این تصمیم داخلِ بدنه‌ی لاگر بود و
 * لاگر در تست‌ها با یک دوبل جایگزین می‌شود که نتیجه را خام ذخیره می‌کند. یعنی
 * حذفِ یک شاخه‌ی کاملِ طبقه‌بندی هیچ تستی را قرمز نمی‌کرد — و پیامدش این بود
 * که پیشوندِ خام به متنِ فارسیِ جدول می‌چسبید و ردیف بینِ خطاهای واقعیِ سرویس
 * گم می‌شد. حالا تصمیم خالص و آزمودنی است و دوبل نمی‌تواند پنهانش کند.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * وضعیت و متنِ خطای یک نتیجه‌ی ارسال.
 *
 * @param mixed $result نتیجه‌ی لایه‌ی ارسال.
 * @return array{status:string,error:string}
 */
function farazsms_diag_classify_result( $result ) {
	if ( $result === 'success' || $result === true ) {
		return array( 'status' => 'success', 'error' => '' );
	}

	// پیشوندهای شناخته‌شده: وضعیت از پیشوند می‌آید و متن بدونِ آن ذخیره می‌شود،
	// چون همان متن به فروشنده نشان داده می‌شود.
	foreach ( array( 'api_error', 'curl_error', 'not_sent' ) as $prefix ) {
		if ( is_string( $result ) && strpos( $result, $prefix . ':' ) === 0 ) {
			return array(
				'status' => $prefix,
				'error'  => substr( $result, strlen( $prefix ) + 1 ),
			);
		}
	}

	if ( $result === 'invalid_mobile' ) {
		// گیرنده پیش از مصرفِ اعتبار رد شد — خطای پیکربندی است، نه خطای سرویس.
		return array( 'status' => 'invalid_mobile', 'error' => '' );
	}
	if ( $result === 'queued' ) {
		return array( 'status' => 'queued', 'error' => '' );
	}

	return array(
		'status' => 'failed',
		'error'  => is_string( $result ) ? $result : wp_json_encode( $result, JSON_UNESCAPED_UNICODE ),
	);
}
