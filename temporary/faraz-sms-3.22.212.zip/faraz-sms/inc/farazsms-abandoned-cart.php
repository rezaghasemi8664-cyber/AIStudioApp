<?php
/**
 * سبد خرید رها‌شده (Abandoned Cart Recovery) — Phase 4
 *
 * جریان کار:
 *   1. کاربر محصول به سبد اضافه می‌کند → ردیفی در DB با session_id ساخته می‌شود.
 *   2. در هر تغییر سبد (add / remove / qty / coupon)، ردیف به‌روز می‌شود.
 *   3. شماره موبایل از این منابع تشخیص داده می‌شود:
 *       - meta `billing_phone` کاربر لاگین
 *       - فیلد phone در فرم checkout (با JS که هنگام تایپ، AJAX می‌زند)
 *       - اگر OTP/Newsletter شناسایی شده باشد
 *   4. wp-cron هر ۳۰ دقیقه: سبدهای active که X ساعت قدیمی‌اند و شماره دارند →
 *      پیامک با الگو ارسال + status='sent'.
 *   5. روی `woocommerce_thankyou`: ردیف active/sent با session/user/mobile مطابق
 *      یافت می‌شود و status='recovered' + recovered_order_id ست می‌شود.
 *   6. سبدهای قدیمی‌تر از expiry → 'expired'.
 *
 * صفحه ادمین:
 *   - داشبورد آماری: تعداد رهاشده، ارسال‌شده، بازیافته، نرخ بازیافت، ارزش بازیافته
 *   - لیست سبدها با فیلتر وضعیت/تاریخ/جستجو
 *   - تنظیمات: فعال‌سازی، تأخیر ارسال، الگو، تاریخ انقضاء
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

// v3.20.6 ESCAPE HATCH
if ( defined( 'FARAZSMS_DISABLE_ABANDONED' ) && FARAZSMS_DISABLE_ABANDONED ) {
	return;
}
if ( defined( 'FARAZSMS_DISABLE_CHECKOUT_HOOKS' ) && FARAZSMS_DISABLE_CHECKOUT_HOOKS ) {
	return;
}

// ============================================================================
// Schema
// ============================================================================

const FARAZSMS_ABANDONED_DB_VERSION        = '1.3.0'; // v3.22.197: ایندکسِ user_id / created_at / recovered_at
const FARAZSMS_ABANDONED_DB_VERSION_OPTION = 'farazsms_abandoned_db_version';
const FARAZSMS_ABANDONED_CRON_HOOK         = 'farazsms_abandoned_dispatch';

function farazsms_abandoned_table() {
	global $wpdb;
	return $wpdb->prefix . 'farazsms_abandoned_carts';
}

function farazsms_abandoned_maybe_setup_table() {
	if ( get_option( FARAZSMS_ABANDONED_DB_VERSION_OPTION ) === FARAZSMS_ABANDONED_DB_VERSION ) {
		return;
	}
	if ( ! function_exists( 'dbDelta' ) ) {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	}
	global $wpdb;
	$table           = farazsms_abandoned_table();
	$charset_collate = $wpdb->get_charset_collate();
	$sql = "CREATE TABLE $table (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		session_id VARCHAR(64) NOT NULL,
		user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
		mobile VARCHAR(20) NOT NULL DEFAULT '',
		email VARCHAR(190) NOT NULL DEFAULT '',
		first_name VARCHAR(120) NOT NULL DEFAULT '',
		last_name VARCHAR(120) NOT NULL DEFAULT '',
		cart_data LONGTEXT,
		total_value DECIMAL(15,2) NOT NULL DEFAULT 0,
		items_count INT(10) UNSIGNED NOT NULL DEFAULT 0,
		token VARCHAR(64) NOT NULL DEFAULT '',
		status VARCHAR(20) NOT NULL DEFAULT 'active',
		sent_at DATETIME NULL,
		recovered_order_id BIGINT(20) UNSIGNED NULL,
		recovered_at DATETIME NULL,
		created_at DATETIME NOT NULL,
		updated_at DATETIME NOT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY session_id (session_id),
		KEY status (status),
		KEY mobile (mobile),
		KEY updated_at (updated_at),
		KEY token (token),
		KEY status_recovered_at (status, recovered_at),
		KEY status_updated_at (status, updated_at),
		KEY user_id (user_id),
		KEY created_at (created_at),
		KEY recovered_at (recovered_at)
	) $charset_collate;";
	dbDelta( $sql );
	// v3.21.7: فقط وقتی جدول واقعاً ساخته شد latch کن (شکستِ dbDelta = مرگِ بی‌صدا).
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
		update_option( FARAZSMS_ABANDONED_DB_VERSION_OPTION, FARAZSMS_ABANDONED_DB_VERSION, false );
	}
}
add_action( 'admin_init', 'farazsms_abandoned_maybe_setup_table' );

// ============================================================================
// Settings
// ============================================================================

function farazsms_abandoned_settings() {
	$defaults = array(
		'enabled'         => '1',
		'delay_hours'     => '1',     // ساعت پس از آخرین تغییر سبد تا ارسال
		'expiry_days'     => '7',     // پس از این مدت، سبد expire می‌شود
		'pattern_code'    => '',
		'message'         => '',      // متنِ پترن (قابلِ ویرایش؛ پیش‌فرض هنگامِ ساختِ خودکار پر می‌شود)
		'batch_size'      => '50',    // سقف ارسال در هر cron run
		'capture_checkout'=> '1',     // JS برای ضبط موبایل در checkout
		'link_mode'       => 'magic', // magic | login
		'magic_ttl_hours' => '48',
		'magic_show_name' => '1',
	);
	$saved = get_option( 'farazsms_abandoned_settings', array() );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
}

// ============================================================================
// Submenu (priority 988 — بین Notify Me و Reports)
// ============================================================================

add_action( 'admin_menu', 'farazsms_abandoned_register_submenu', 988 );
function farazsms_abandoned_register_submenu() {
	add_submenu_page(
		'farazsms',
		__( 'سبد خرید رها‌شده', 'farazsms' ),
		__( 'سبد خرید رها‌شده', 'farazsms' ),
		'manage_options',
		'farazsms-abandoned',
		'farazsms_render_abandoned_page'
	);
}

// ============================================================================
// WP-Cron schedule
// ============================================================================

add_filter( 'cron_schedules', 'farazsms_abandoned_cron_schedules' );
function farazsms_abandoned_cron_schedules( $schedules ) {
	if ( ! isset( $schedules['farazsms_thirty_minutes'] ) ) {
		$schedules['farazsms_thirty_minutes'] = array(
			'interval' => 30 * MINUTE_IN_SECONDS,
			'display'  => __( 'هر ۳۰ دقیقه (فراز اس‌ام‌اس)', 'farazsms' ),
		);
	}
	return $schedules;
}

add_action( 'init', 'farazsms_abandoned_register_cron' );
function farazsms_abandoned_register_cron() {
	if ( ! wp_next_scheduled( FARAZSMS_ABANDONED_CRON_HOOK ) ) {
		wp_schedule_event( time() + 60, 'farazsms_thirty_minutes', FARAZSMS_ABANDONED_CRON_HOOK );
	}
}

/**
 * v3.22.139 (تیکت «پیامکِ سبد رهاشده طبقِ زمان‌بندی ارسال نمی‌شود»): جبرانِ wp-cronِ خاموش/لنگ.
 *
 * روی سایت‌های کم‌بازدید (یا با DISABLE_WP_CRON و بدونِ کرانِ سیستمی) رویدادِ زمان‌بندی‌شده دیر یا
 * هرگز fire نمی‌شود و پیامکِ سبد رهاشده عقب می‌افتد. این تابع روی «بازدیدِ ادمین» بررسی می‌کند که آیا
 * اجرای زمان‌بندی‌شده عقب افتاده؛ اگر بله، کار را به **صفِ مشترک** می‌سپارد (از v3.22.202؛ پیش از آن
 * هوکِ shutdownِ خودش را داشت). با قفلِ transient حداکثر هر ۱۵ دقیقه یک‌بار بررسی می‌شود؛ و
 * run_dispatch خودش قفلِ ضدِ هم‌زمانی دارد، پس با wp-cronِ واقعی هم double-send نمی‌شود.
 * فقط ادمین — صفرِ اثر روی فرانت.
 */
add_action( 'admin_init', 'farazsms_abandoned_maybe_catchup_dispatch', 99 );
function farazsms_abandoned_maybe_catchup_dispatch() {
	if ( function_exists( 'wp_doing_ajax' ) && wp_doing_ajax() ) {
		return;
	}
	if ( get_transient( 'farazsms_abandoned_catchup_lock' ) ) {
		return; // اخیراً بررسی شده — دوباره نه.
	}
	$next = wp_next_scheduled( FARAZSMS_ABANDONED_CRON_HOOK );
	if ( $next && $next > time() ) {
		return; // زمانِ اجرای بعدی هنوز نرسیده — کاری لازم نیست.
	}
	// حداکثر هر ۱۵ دقیقه یک جبران (هم‌راستا با «هیچ‌وقت کند نشدنِ سایت»).
	set_transient( 'farazsms_abandoned_catchup_lock', '1', 15 * MINUTE_IN_SECONDS );
	// v3.22.202: نردبانِ تعویقِ خصوصی حذف شد و کار به صفِ مشترک رفت.
	// (دو کامنتِ قبلی درباره‌ی هوکِ shutdown و رفعِ v3.22.152 برداشته شدند؛
	// هر دو رفتاری را توصیف می‌کردند که دیگر وجود ندارد.)
	// آن نردبان روی mod_php تضمینی نداشت (پاسخ بسته نمی‌شد) و نه ذخیره‌ی
	// باقی‌مانده داشت، نه اجراکننده، نه کچ‌آپ.
	// ⚠️ این مسیر پیامکِ **مشتری** می‌فرستد و روی mod_php پیش از بسته‌شدنِ
	// پاسخ اجرا می‌شد — همان نقصی که فازِ ۲ در صف رفعش کرد.
	farazsms_queue_task( 'abandoned-catchup', 'farazsms_abandoned_run_dispatch' );
}


// تعداد فعال‌سازی‌ها / غیرفعال‌سازی پلاگین به ما اعتماد نیست — pre-clean در غیرفعال شدن
// v3.13.16: استفاده از constant مرجع به‌جای string هاردکدشده. این کار باعث می‌شود
// نام فولدر/فایل افزونه قابل تغییر باشد بدون شکستن register_deactivation_hook.
register_deactivation_hook( defined( 'FARAZSMS_PLUGIN_FILE' ) ? FARAZSMS_PLUGIN_FILE : __FILE__, 'farazsms_abandoned_clear_cron' );
function farazsms_abandoned_clear_cron() {
	$ts = wp_next_scheduled( FARAZSMS_ABANDONED_CRON_HOOK );
	if ( $ts ) {
		wp_unschedule_event( $ts, FARAZSMS_ABANDONED_CRON_HOOK );
	}
}

// ============================================================================
// Core: capture cart on every change
// ============================================================================

add_action( 'woocommerce_add_to_cart',        'farazsms_abandoned_track_cart', 10, 0 );
add_action( 'woocommerce_cart_item_removed',  'farazsms_abandoned_track_cart', 10, 0 );
add_action( 'woocommerce_cart_item_restored', 'farazsms_abandoned_track_cart', 10, 0 );
add_action( 'woocommerce_after_cart_item_quantity_update', 'farazsms_abandoned_track_cart', 10, 0 );
add_action( 'woocommerce_applied_coupon',     'farazsms_abandoned_track_cart', 10, 0 );
add_action( 'woocommerce_removed_coupon',     'farazsms_abandoned_track_cart', 10, 0 );

function farazsms_abandoned_track_cart() {
	// v3.13.13 PERF: Debounce در سطح request. شش hook ووکامرس این تابع را
	// در یک request به‌طور پشت سر هم صدا می‌زنند (مثلاً add_to_cart + applied_coupon).
	// با static flag، فقط یک بار در هر request اجرا می‌شود — DB writes را تا
	// ۶ برابر کاهش می‌دهد روی صفحاتی که چندین cart event رخ می‌دهد.
	static $done_this_request = false;
	if ( $done_this_request ) {
		return;
	}
	$done_this_request = true;

	$settings = farazsms_abandoned_settings();
	if ( $settings['enabled'] !== '1' ) {
		return;
	}
	if ( ! function_exists( 'WC' ) || ! WC()->cart || ! WC()->session ) {
		return;
	}
	$session_id = farazsms_abandoned_get_session_id();
	if ( $session_id === '' ) {
		return;
	}
	if ( WC()->cart->is_empty() ) {
		// Cart cleared — drop our row.
		farazsms_abandoned_delete_by_session( $session_id );
		return;
	}

	$cart_items = array();
	foreach ( WC()->cart->get_cart() as $key => $item ) {
		$pid    = isset( $item['product_id'] )   ? (int) $item['product_id']   : 0;
		$vid    = isset( $item['variation_id'] ) ? (int) $item['variation_id'] : 0;
		$qty    = isset( $item['quantity'] )     ? (int) $item['quantity']     : 0;
		$line   = isset( $item['line_total'] )   ? (float) $item['line_total'] : 0;
		$cart_items[] = array(
			'product_id'   => $pid,
			'variation_id' => $vid,
			'quantity'     => $qty,
			'line_total'   => $line,
			'name'         => $pid ? get_the_title( $pid ) : '',
		);
	}
	// v3.21.22: مبلغِ مقاوم. روی هوکِ woocommerce_add_to_cart معمولاً totals هنوز محاسبه
	// نشده‌اند و get_total('edit') صفر برمی‌گرداند (باگِ «مبلغ: 0» در پیامک).
	// v3.21.26 (P4): اگر صفر بود، مستقیم از جمعِ قیمتِ اقلام (ارزان) استفاده می‌کنیم و
	// calculate_totals() را روی مسیرِ داغِ add_to_cart اجرا نمی‌کنیم (هزینه‌ی CPU در مقیاسِ ۱۰۰k).
	$total = (float) WC()->cart->get_total( 'edit' );
	if ( $total <= 0 ) {
		$sum = 0.0;
		foreach ( WC()->cart->get_cart() as $ci ) {
			$line = isset( $ci['line_total'] ) ? (float) $ci['line_total'] : 0;
			if ( $line <= 0 && ! empty( $ci['data'] ) && is_object( $ci['data'] ) && method_exists( $ci['data'], 'get_price' ) ) {
				$qty  = isset( $ci['quantity'] ) ? (int) $ci['quantity'] : 1;
				$line = (float) wc_get_price_to_display( $ci['data'], array( 'price' => $ci['data']->get_price(), 'qty' => $qty ) );
				if ( $line <= 0 ) {
					$line = (float) $ci['data']->get_price() * max( 1, $qty );
				}
			}
			$sum += $line;
		}
		$total = $sum;
	}
	$count = (int) WC()->cart->get_cart_contents_count();

	$mobile = '';
	$email  = '';
	$first  = '';
	$last   = '';
	$uid    = get_current_user_id();
	if ( $uid > 0 ) {
		$mobile = (string) get_user_meta( $uid, 'billing_phone', true );
		$email  = (string) get_user_meta( $uid, 'billing_email', true );
		$first  = (string) get_user_meta( $uid, 'billing_first_name', true );
		$last   = (string) get_user_meta( $uid, 'billing_last_name', true );
		if ( $email === '' ) {
			$user_obj = get_userdata( $uid );
			if ( $user_obj ) {
				$email = (string) $user_obj->user_email;
				if ( $first === '' ) {
					$first = (string) ( $user_obj->display_name ?: $user_obj->user_login );
				}
			}
		}
	}
	if ( $mobile !== '' && function_exists( 'farazsms_newsletter_normalize_mobile' ) ) {
		$mobile = farazsms_newsletter_normalize_mobile( $mobile );
	}

	farazsms_abandoned_upsert_row( $session_id, array(
		'user_id'     => $uid,
		'mobile'      => $mobile,
		'email'       => $email,
		'first_name'  => $first,
		'last_name'   => $last,
		'cart_data'   => wp_json_encode( $cart_items, JSON_UNESCAPED_UNICODE ),
		'total_value' => $total,
		'items_count' => $count,
	) );
}

/**
 * Get a stable session ID for tracking. Uses WC's customer session.
 *
 * @return string
 */
function farazsms_abandoned_get_session_id() {
	if ( ! function_exists( 'WC' ) || ! WC()->session ) {
		return '';
	}
	$id = WC()->session->get_customer_id();
	return is_string( $id ) ? $id : '';
}

/**
 * v3.22.138 (تیکت سبد رهاشده — «چالشِ اصلی»): اتصالِ سبدِ مهمان به کاربر پس از ورود/ثبت‌نام.
 *
 * سناریو: مهمان محصول به سبد می‌افزاید → ردیفی با session_idِ مهمان، user_id=0 و موبایلِ خالی ساخته
 * می‌شود. سپس در صفحهٔ تسویه با فرمِ ورودِ فراز ثبت‌نام/وارد می‌شود؛ session تغییر می‌کند و ردیفِ قدیمی
 * یتیم و بدونِ موبایل می‌ماند (نه در لیست می‌آید، نه پیامک می‌گیرد). چون WC مقدارِ customer_id را از
 * ابتدای همین ریکوئست (زمانِ مهمان‌بودن) کش کرده، در لحظهٔ wp_login هنوز همان session_idِ مهمان در
 * دسترس است؛ پس همان ردیف را به کاربر متصل می‌کنیم و session را به idِ کاربر مهاجرت می‌دهیم تا
 * track_cartِ بعدی همین ردیف را آپدیت کند (نه ردیفِ دومِ تکراری). لاگینِ فراز (wp_signon و مسیرِ OTP)
 * هوکِ wp_login را fire می‌کند.
 *
 * @param string       $user_login
 * @param WP_User|null $user
 */
add_action( 'wp_login', 'farazsms_abandoned_link_guest_cart_on_login', 20, 2 );
function farazsms_abandoned_link_guest_cart_on_login( $user_login, $user = null ) {
	// کدریویو v3.22.152: اگر ماژول خاموش است، روی هر ورودِ سایت کوئری نزن.
	$settings = farazsms_abandoned_settings();
	if ( ( $settings['enabled'] ?? '1' ) !== '1' ) {
		return;
	}
	if ( ! ( $user instanceof WP_User ) ) {
		$user = function_exists( 'get_user_by' ) ? get_user_by( 'login', $user_login ) : null;
	}
	if ( ! $user ) {
		return;
	}
	$session_id = farazsms_abandoned_get_session_id();
	if ( $session_id === '' ) {
		return;
	}
	$uid = (int) $user->ID;
	if ( (string) $session_id === (string) $uid ) {
		return; // از قبل سشنِ کاربر است (نه مهمان) — کاری لازم نیست.
	}

	// موبایلِ کاربر: اول billing_phone، بعد نامِ کاربری اگر خودش موبایل باشد (لاگینِ فراز اغلب username=mobile).
	$mobile = (string) get_user_meta( $uid, 'billing_phone', true );
	if ( $mobile === '' ) {
		$digits = preg_replace( '/\D/', '', (string) $user->user_login );
		if ( preg_match( '/^0?9\d{9}$/', $digits ) ) {
			$mobile = $user->user_login;
		}
	}
	if ( $mobile !== '' && function_exists( 'farazsms_newsletter_normalize_mobile' ) ) {
		$mobile = farazsms_newsletter_normalize_mobile( $mobile );
	}

	global $wpdb;
	$table = farazsms_abandoned_table();
	$row   = $wpdb->get_row(
		$wpdb->prepare( "SELECT id, status, mobile FROM $table WHERE session_id = %s LIMIT 1", $session_id ),
		ARRAY_A
	);
	if ( ! $row || $row['status'] === 'recovered' ) {
		return; // ردیفی نیست یا قبلاً بازیابی شده.
	}
	$data = array(
		'user_id'    => $uid,
		'updated_at' => current_time( 'mysql' ),
	);
	// موبایل را فقط اگر ردیف نداشت پر کن (اگر مهمان در فرمِ تسویه موبایلِ دیگری وارد کرده، حفظش کن).
	if ( (string) ( $row['mobile'] ?? '' ) === '' && $mobile !== '' ) {
		$data['mobile'] = $mobile;
	}
	// مهاجرتِ session به idِ کاربر. اگر ردیفِ user-session از قبل باشد (سبدِ قدیمیِ همان کاربر)،
	// کدریویو v3.22.152: صرفِ رد کردنِ مهاجرت کافی نیست — آن ردیفِ قدیمی هم «فعال» و دارای موبایل
	// می‌ماند و دیسپچر که هیچ دی‌دوپلیکیتی بر اساسِ کاربر/شماره ندارد، برای یک نفر دو پیامک
	// می‌فرستاد. سبدِ تازه معتبرتر است، پس ردیفِ قدیمیِ همان کاربر (اگر بازیابی‌شده نباشد) حذف و
	// مهاجرت انجام می‌شود؛ نتیجه: دقیقاً یک سبدِ فعال به‌ازای هر کاربر.
	$user_sid  = (string) $uid;
	$collision = $wpdb->get_row(
		$wpdb->prepare( "SELECT id, status FROM $table WHERE session_id = %s AND id <> %d LIMIT 1", $user_sid, (int) $row['id'] ),
		ARRAY_A
	);
	if ( ! $collision ) {
		$data['session_id'] = $user_sid;
	} elseif ( ( $collision['status'] ?? '' ) !== 'recovered' ) {
		$wpdb->delete( $table, array( 'id' => (int) $collision['id'] ), array( '%d' ) );
		$data['session_id'] = $user_sid;
	}
	$wpdb->update( $table, $data, array( 'id' => (int) $row['id'] ) );
}

/**
 * Insert or update an abandoned-cart row. Also generates a recovery token
 * the first time a row is created.
 *
 * @param string $session_id
 * @param array  $data
 */
function farazsms_abandoned_upsert_row( $session_id, $data ) {
	global $wpdb;
	$table = farazsms_abandoned_table();
	$now   = current_time( 'mysql' );
	$existing = $wpdb->get_row(
		$wpdb->prepare( "SELECT id, status FROM $table WHERE session_id = %s LIMIT 1", $session_id ),
		ARRAY_A
	);
	if ( $existing ) {
		// Do NOT touch rows already marked recovered.
		if ( $existing['status'] === 'recovered' ) {
			return;
		}
		// Reset 'sent' or 'expired' back to active when the user comes back and
		// edits the cart — they're engaged again.
		//
		// ⚠️ `sent_at` عمداً **پاک نمی‌شود** (بازبینیِ ۱۴۰۵/۰۶/۱۶).
		//
		// دروازه‌ی یادآوری روی `status = 'active'` است، نه روی sent_at؛ پس صفرکردنش
		// هیچ اثری روی «دوباره یادآوری کن» ندارد. تنها کاری که می‌کرد نابودکردنِ
		// شواهدِ انتساب بود: مشتری روی لینکِ پیامک کلیک می‌کند، برمی‌گردد، سبدش را
		// می‌بیند (و همین تابع دوباره صدا زده می‌شود)، بعد خرید می‌کند — یعنی
		// موفق‌ترین حالتِ ممکن، که با پاک‌شدنِ sent_at از آمار حذف می‌شد.
		$update = array_merge( $data, array(
			'status'     => 'active',
			'updated_at' => $now,
		) );
		// Build placeholder list for $wpdb->update — but PHP doesn't enforce types here.
		$wpdb->update( $table, $update, array( 'id' => (int) $existing['id'] ) );
		return;
	}
	$token = farazsms_abandoned_generate_token();
	$wpdb->insert( $table, array_merge( $data, array(
		'session_id' => $session_id,
		'token'      => $token,
		'status'     => 'active',
		'created_at' => $now,
		'updated_at' => $now,
	) ) );
}

function farazsms_abandoned_delete_by_session( $session_id ) {
	global $wpdb;
	$table = farazsms_abandoned_table();
	// Only delete rows that are still active (not sent/recovered) so we don't
	// lose history when the cart is cleared after a successful purchase.
	$wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE session_id = %s AND status = %s", $session_id, 'active' ) );
}

function farazsms_abandoned_generate_token() {
	// v3.21.17: توکنِ کوتاه‌تر (۱۶ هگز = ۶۴ بیت) برای کوتاه‌شدنِ لینکِ پیامک؛ برای یک
	// لینکِ بازیابیِ سبدِ کوتاه‌عمر کاملاً امن است. خروجی همیشه هگز است تا با regexِ
	// readerِ بازیابی (^[a-f0-9]{16,64}$) سازگار بماند (fallbackِ قبلی غیرِهگز بود و رد می‌شد).
	if ( function_exists( 'random_bytes' ) ) {
		return bin2hex( random_bytes( 8 ) );
	}
	return substr( md5( wp_generate_password( 32, true, true ) . microtime() ), 0, 16 );
}

function farazsms_abandoned_magic_url( $token ) {
	return add_query_arg( 'fzr', rawurlencode( (string) $token ), home_url( '/' ) );
}

function farazsms_abandoned_magic_is_enabled() {
	$s = farazsms_abandoned_settings();
	return isset( $s['link_mode'] ) && $s['link_mode'] === 'magic';
}

function farazsms_abandoned_magic_ttl_seconds() {
	$s = farazsms_abandoned_settings();
	return max( 1, (int) ( $s['magic_ttl_hours'] ?? 48 ) ) * HOUR_IN_SECONDS;
}

/**
 * آیا ردیف از سقفِ روزهای انقضا کهنه‌تر است؟ (منطقِ خالص و آزمودنی)
 *
 * updated_at با ساعتِ محلیِ سایت نوشته می‌شود؛ خواندنش باید از هلپرِ مشترک رد شود وگرنه
 * روی سایتِ غیرِ UTC به اندازه‌ی اختلافِ منطقه اشتباه می‌شود.
 *
 * @param string $updated_at  رشته‌ی زمانِ محلیِ ردیف.
 * @param int    $expiry_days سقفِ روزها.
 * @return bool
 */
function farazsms_abandoned_row_is_stale( $updated_at, $expiry_days ) {
	$updated_at = trim( (string) $updated_at );
	if ( $updated_at === '' ) {
		return false;
	}
	return farazsms_local_mysql_to_ts( $updated_at ) < ( time() - max( 1, (int) $expiry_days ) * DAY_IN_SECONDS );
}

function farazsms_abandoned_magic_row_is_expired( $row ) {
	if ( empty( $row['updated_at'] ) ) {
		return true;
	}
	// updated_at با current_time('mysql') نوشته می‌شود (ساعتِ محلی، بدونِ نشانه‌ی منطقه)؛
	// خواندنش با strtotime آن را UTC می‌گرفت و لینک به اندازه‌ی اختلافِ منطقه بیشتر عمر می‌کرد.
	return farazsms_local_mysql_to_ts( $row['updated_at'] ) < ( time() - farazsms_abandoned_magic_ttl_seconds() );
}

function farazsms_abandoned_mask_mobile( $mobile ) {
	$digits = preg_replace( '/\D+/', '', (string) $mobile );
	if ( strlen( $digits ) < 8 ) {
		return '';
	}
	return substr( $digits, 0, 4 ) . '***' . substr( $digits, -4 );
}

// ============================================================================
// Mobile capture from checkout (AJAX)
// ============================================================================

add_action( 'wp_ajax_farazsms_abandoned_capture_phone',        'farazsms_abandoned_ajax_capture_phone' );
add_action( 'wp_ajax_nopriv_farazsms_abandoned_capture_phone', 'farazsms_abandoned_ajax_capture_phone' );
function farazsms_abandoned_ajax_capture_phone() {
	check_ajax_referer( 'farazsms_abandoned_capture', 'nonce' );
	$mobile = isset( $_POST['mobile'] ) ? sanitize_text_field( wp_unslash( $_POST['mobile'] ) ) : '';
	$email  = isset( $_POST['email'] )  ? sanitize_email( wp_unslash( $_POST['email'] ) )  : '';
	$first  = isset( $_POST['first_name'] ) ? sanitize_text_field( wp_unslash( $_POST['first_name'] ) ) : '';
	$last   = isset( $_POST['last_name'] ) ? sanitize_text_field( wp_unslash( $_POST['last_name'] ) ) : '';
	if ( function_exists( 'farazsms_newsletter_normalize_mobile' ) ) {
		$mobile = farazsms_newsletter_normalize_mobile( $mobile );
	}
	// v3.21.26 امنیتی (P3): فقط موبایلِ معتبرِ ایران پذیرفته شود — وگرنه مهاجم می‌تواند موبایلِ
	// سبدِ خود را به شماره‌ی دلخواه عوض کند و cron پیامکِ پولی به آن بفرستد (سوءاستفاده از اعتبار).
	if ( ! preg_match( '/^(?:0|98|\+98)?9\d{9}$/', (string) $mobile ) ) {
		wp_send_json_error();
	}
	$session_id = farazsms_abandoned_get_session_id();
	if ( $session_id === '' ) {
		wp_send_json_error();
	}
	// v3.21.26 امنیتی (P3): محدودیتِ نرخِ سبک per-session (حداکثر ۱۰ بار در ساعت).
	$rl_key   = 'farazsms_abc_cap_' . md5( $session_id );
	$rl_count = (int) get_transient( $rl_key );
	if ( $rl_count >= 10 ) {
		wp_send_json_error();
	}
	set_transient( $rl_key, $rl_count + 1, HOUR_IN_SECONDS );
	global $wpdb;
	$table = farazsms_abandoned_table();
	$row   = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM $table WHERE session_id = %s LIMIT 1", $session_id ), ARRAY_A );
	if ( ! $row ) {
		wp_send_json_success(); // No cart row yet — nothing to update, but not an error.
	}
	$wpdb->update(
		$table,
		array(
			'mobile'     => $mobile,
			'email'      => $email,
			'first_name' => $first,
			'last_name'  => $last,
			'updated_at' => current_time( 'mysql' ),
		),
		array( 'id' => (int) $row['id'] )
	);
	wp_send_json_success();
}

// Inject minimal capture JS on the WC checkout page.
add_action( 'wp_enqueue_scripts', 'farazsms_abandoned_maybe_enqueue_capture_js' );
function farazsms_abandoned_maybe_enqueue_capture_js() {
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
		return;
	}
	$settings = farazsms_abandoned_settings();
	if ( $settings['enabled'] !== '1' || $settings['capture_checkout'] !== '1' ) {
		return;
	}
	add_action( 'wp_footer', 'farazsms_abandoned_render_capture_js', 99 );
}
function farazsms_abandoned_render_capture_js() {
	$nonce    = wp_create_nonce( 'farazsms_abandoned_capture' );
	$ajax_url = admin_url( 'admin-ajax.php' );
	?>
	<script>
	(function(){
		var ajaxUrl = <?php echo wp_json_encode( $ajax_url ); ?>;
		var nonce   = <?php echo wp_json_encode( $nonce ); ?>;
		var debounce = null;
		function push() {
			var phone = (document.getElementById('billing_phone') || {}).value || '';
			var email = (document.getElementById('billing_email') || {}).value || '';
			var first = (document.getElementById('billing_first_name') || {}).value || '';
			var last  = (document.getElementById('billing_last_name') || {}).value || '';
			if (!phone) return;
			var fd = new FormData();
			fd.append('action', 'farazsms_abandoned_capture_phone');
			fd.append('nonce', nonce);
			fd.append('mobile', phone);
			fd.append('email', email);
			fd.append('first_name', first);
			fd.append('last_name', last);
			fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd }).catch(function(){});
		}
		function bind(){
			['billing_phone', 'billing_email', 'billing_first_name', 'billing_last_name'].forEach(function(id){
				var el = document.getElementById(id);
				if (!el || el._wtoBound) return;
				el._wtoBound = true;
				el.addEventListener('blur', function(){
					clearTimeout(debounce);
					debounce = setTimeout(push, 200);
				});
				el.addEventListener('change', function(){
					clearTimeout(debounce);
					debounce = setTimeout(push, 200);
				});
			});
		}
		bind();
		// Re-bind whenever WC updates the checkout fragment (AJAX shipping etc.).
		if (window.jQuery) {
			jQuery(document.body).on('updated_checkout updated_wc_div', bind);
		}
	})();
	</script>
	<?php
}

// ============================================================================
// Recovery: mark as recovered + restore cart from token
// ============================================================================

// v3.22.91: علامتِ «بازیابی‌شده» فقط روی thankyou شکننده بود (بعضی درگاه‌ها thankyou را بالا
// نمی‌آورند، پرداختِ async/IPN، یا بستنِ تب) → خریدِ کامل‌شده recovered نمی‌شد و بعداً پیامکِ
// «سبدت را تکمیل کن» می‌گرفت (گزارشِ کاربر: پیامک به کسی که خرید کرده). حالا علاوه بر thankyou،
// روی تغییرِ وضعیت به processing/completed/on-hold هم علامت می‌خورد (تطبیق با user_id + موبایلِ
// نرمال‌شده؛ session در این مسیرها معمولاً موجود نیست و بی‌خطر رد می‌شود).
// v3.22.149: سفارشِ ثبت‌شده ولی پرداخت‌نشده، مشخصاتِ خریدار را دارد؛ ولی ردیفِ سبد اغلب
// بدونِ موبایل می‌ماند (بازدیدکننده شماره‌اش را فقط در فرمِ تسویه نوشته است). نتیجه: در فهرستِ
// سبدِ رهاشده «—» دیده می‌شد و داغ‌ترین سرنخِ ممکن هم بی‌پیامک می‌ماند. این‌جا در لحظه‌ی ساختِ
// سفارش، شماره/نام از خودِ سفارش به ردیفِ سبد منتقل می‌شود — بدونِ علامت‌زدنِ «بازیافت‌شده»،
// چون هنوز پرداختی انجام نشده.
add_action( 'woocommerce_checkout_order_processed', 'farazsms_abandoned_attach_order_identity', 20, 1 );
add_action( 'woocommerce_store_api_checkout_order_processed', 'farazsms_abandoned_attach_order_identity', 20, 1 );
/**
 * @param int|WC_Order $order_or_id شناسه (مسیرِ کلاسیک) یا شیءِ سفارش (Store API).
 * @return void
 */
function farazsms_abandoned_attach_order_identity( $order_or_id ) {
	// این هوک روی مسیرِ تسویه اجرا می‌شود؛ هیچ خطایی نباید از این‌جا بالا برود. کدریویو
	// v3.22.152: قولِ همین جمله در کد پیاده نشده بود — حالا کلِ بدنه داخلِ try است (سابقه:
	// یک interceptorِ پرتاب‌کننده روی همین هوکِ Store API صفحه‌ی تسویه را شکسته بود).
	if ( ! function_exists( 'wc_get_order' ) ) {
		return;
	}
	// اگر ماژول خاموش است، هیچ کوئری‌ای روی مسیرِ داغِ تسویه زده نشود.
	$settings = farazsms_abandoned_settings();
	if ( ( $settings['enabled'] ?? '1' ) !== '1' ) {
		return;
	}
	try {
		farazsms_abandoned_attach_order_identity_run( $order_or_id );
	} catch ( \Throwable $e ) {
		// بلعیدنِ خطا عمدی است (مسیرِ تسویه)، ولی بی‌صدا نه: در لاگِ خطای سایت ثبت می‌شود.
		error_log( 'farazsms abandoned attach_order_identity: ' . $e->getMessage() );
	}
}

/**
 * بدنه‌ی واقعیِ انتقالِ هویتِ سفارش به ردیفِ سبد (داخلِ try فراخوانی می‌شود).
 *
 * @param int|WC_Order $order_or_id
 * @return void
 */
function farazsms_abandoned_attach_order_identity_run( $order_or_id ) {
	$order = is_object( $order_or_id ) ? $order_or_id : wc_get_order( (int) $order_or_id );
	if ( ! $order || ! method_exists( $order, 'get_billing_phone' ) ) {
		return;
	}

	$mobile = (string) $order->get_billing_phone();
	if ( $mobile !== '' && function_exists( 'farazsms_newsletter_normalize_mobile' ) ) {
		$mobile = (string) farazsms_newsletter_normalize_mobile( $mobile );
	}
	$first = (string) $order->get_billing_first_name();
	$last  = (string) $order->get_billing_last_name();
	$uid   = (int) $order->get_user_id();
	if ( $mobile === '' && $first === '' && $last === '' ) {
		return;
	}

	global $wpdb;
	$table      = farazsms_abandoned_table();
	$session_id = farazsms_abandoned_get_session_id();
	$row        = null;
	if ( $session_id !== '' ) {
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, mobile, first_name, last_name, user_id FROM $table WHERE session_id = %s AND status != %s ORDER BY id DESC LIMIT 1", $session_id, 'recovered' ), ARRAY_A );
	}
	if ( ! $row && $uid > 0 ) {
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, mobile, first_name, last_name, user_id FROM $table WHERE user_id = %d AND status != %s ORDER BY id DESC LIMIT 1", $uid, 'recovered' ), ARRAY_A );
	}
	if ( ! $row ) {
		return;
	}

	// فقط جاهای خالی پر می‌شوند؛ داده‌ی ثبت‌شده‌ی قبلی بازنویسی نمی‌شود.
	$data    = array();
	$formats = array();
	if ( $mobile !== '' && (string) ( $row['mobile'] ?? '' ) === '' ) {
		$data['mobile'] = $mobile;
		$formats[]      = '%s';
	}
	if ( $first !== '' && (string) ( $row['first_name'] ?? '' ) === '' ) {
		$data['first_name'] = $first;
		$formats[]          = '%s';
	}
	if ( $last !== '' && (string) ( $row['last_name'] ?? '' ) === '' ) {
		$data['last_name'] = $last;
		$formats[]         = '%s';
	}
	if ( $uid > 0 && (int) ( $row['user_id'] ?? 0 ) === 0 ) {
		$data['user_id'] = $uid;
		$formats[]       = '%d';
	}
	if ( empty( $data ) ) {
		return;
	}
	// ثبتِ سفارش خودش «فعالیت» است: شمارنده‌ی تأخیرِ یادآوری از همین لحظه شروع شود تا
	// بلافاصله بعد از تسویه‌ی ناتمام پیامک نرود.
	$data['updated_at'] = current_time( 'mysql' );
	$formats[]          = '%s';

	$wpdb->update( $table, $data, array( 'id' => (int) $row['id'] ), $formats, array( '%d' ) );
}

add_action( 'woocommerce_thankyou', 'farazsms_abandoned_mark_recovered_on_thankyou', 10, 1 );
add_action( 'woocommerce_order_status_processing', 'farazsms_abandoned_mark_recovered_on_thankyou', 10, 1 );
add_action( 'woocommerce_order_status_completed', 'farazsms_abandoned_mark_recovered_on_thankyou', 10, 1 );
// v3.22.94: on-hold عمداً حذف شد — «در انتظارِ پرداختِ آفلاین» یعنی هنوز خرید تکمیل نشده؛ اگر
// پرداخت نشود و سبد را recovered علامت بزنیم، یادآوریِ به‌حقِ او دیگر نمی‌رود. فقط پرداختِ واقعی
// (processing/completed) سبد را بازیابی‌شده می‌کند.
function farazsms_abandoned_mark_recovered_on_thankyou( $order_id ) {
	if ( ! $order_id || ! function_exists( 'wc_get_order' ) ) {
		return;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	$session_id = farazsms_abandoned_get_session_id();
	$uid        = (int) $order->get_user_id();
	$mobile     = $order->get_billing_phone();
	if ( $mobile !== '' && function_exists( 'farazsms_newsletter_normalize_mobile' ) ) {
		$mobile = farazsms_newsletter_normalize_mobile( $mobile );
	}

	global $wpdb;
	$table = farazsms_abandoned_table();
	$now   = current_time( 'mysql' );
	$row   = null;
	if ( $session_id !== '' ) {
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, status FROM $table WHERE session_id = %s AND status != %s ORDER BY id DESC LIMIT 1", $session_id, 'recovered' ), ARRAY_A );
	}
	if ( ! $row && $uid > 0 ) {
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, status FROM $table WHERE user_id = %d AND status != %s ORDER BY id DESC LIMIT 1", $uid, 'recovered' ), ARRAY_A );
	}
	if ( ! $row && $mobile !== '' ) {
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, status FROM $table WHERE mobile = %s AND status != %s ORDER BY id DESC LIMIT 1", $mobile, 'recovered' ), ARRAY_A );
	}
	if ( ! $row ) {
		return;
	}
	$wpdb->update(
		$table,
		array(
			'status'             => 'recovered',
			'recovered_order_id' => (int) $order_id,
			'recovered_at'       => $now,
			'updated_at'         => $now,
		),
		array( 'id' => (int) $row['id'] )
	);
}

// Recovery URL — `?fzr=<token>` (یا کلیدِ قدیمیِ `farazsms_recover_cart`) سبد را بازمی‌گرداند.
// v3.21.22: روی template_redirect (نه init) تا WC()->cart کاملاً آماده باشد — وگرنه برای
// مهمان سبد خالی بازیابی می‌شد. به‌علاوه، مهمان اول به صفحه‌ی ورود هدایت می‌شود.
add_action( 'template_redirect', 'farazsms_abandoned_maybe_recover_cart' );
function farazsms_abandoned_maybe_recover_cart() {
	if ( ! function_exists( 'WC' ) ) {
		return;
	}
	// v3.21.17: کلیدِ کوتاهِ جدید `fzr` و کلیدِ قدیمیِ `farazsms_recover_cart` هر دو پذیرفته
	// می‌شوند تا لینک‌های پیامکیِ قبلاً‌ارسال‌شده (با کلیدِ بلند) هم همچنان کار کنند.
	$raw = '';
	if ( ! empty( $_GET['fzr'] ) ) {
		$raw = $_GET['fzr'];
	} elseif ( ! empty( $_GET['farazsms_recover_cart'] ) ) {
		$raw = $_GET['farazsms_recover_cart'];
	}
	if ( $raw === '' ) {
		return;
	}
	$token = sanitize_text_field( wp_unslash( $raw ) );
	if ( ! preg_match( '/^[a-f0-9]{16,64}$/i', $token ) ) {
		return;
	}
	global $wpdb;
	$table = farazsms_abandoned_table();
	// v3.21.24: سبدِ منقضی (expired) هم نباید بازیابی شود (اقلام/قیمتِ کهنه)، نه فقط recovered.
	$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE token = %s AND status NOT IN ('recovered','expired') LIMIT 1", $token ), ARRAY_A );
	if ( ! $row ) {
		return;
	}

	// v3.21.26 (P6): TTLِ مستقل از cron — اگر wp-cron اجرا نشده باشد، ردیفِ قدیمی هنوز 'active'
	// است؛ سبدِ قدیمی‌تر از expiry_days (اقلام/قیمتِ کهنه) را بازیابی نکن.
	$abc_settings = farazsms_abandoned_settings();
	$abc_expiry   = max( 1, (int) $abc_settings['expiry_days'] );
	if ( farazsms_abandoned_row_is_stale( $row['updated_at'] ?? '', $abc_expiry ) ) {
		return;
	}

	if ( farazsms_abandoned_magic_is_enabled() ) {
		if ( farazsms_abandoned_magic_row_is_expired( $row ) ) {
			farazsms_abandoned_render_magic_expired();
			exit;
		}
		if ( isset( $_POST['farazsms_abandoned_magic_checkout'] ) ) {
			check_admin_referer( 'farazsms_abandoned_magic_checkout_' . (int) $row['id'], 'farazsms_abandoned_magic_nonce' );
			$restored = farazsms_abandoned_restore_cart_from_row( $row );
			// هیچ قلمی واقعاً به سبد اضافه نشد (ناموجود/حذف‌شده/غیرقابلِ‌خرید) → مشتری را به
			// تسویه‌ی خالی نفرست؛ سبد دستِ‌کم صادقانه می‌گوید چیزی نمانده و راهِ ادامه می‌دهد.
			if ( $restored < 1 ) {
				$cart_url = wc_get_cart_url();
				wp_safe_redirect( $cart_url !== '' ? $cart_url : home_url( '/' ) );
				exit;
			}
			// مجوزِ کوتاه‌عمرِ عبور از گیتِ «ورودِ اجباری در تسویه» برای همین جلسه. صفحه‌ی واسط
			// به مشتری قول داده این لینک حساب کاربری نمی‌سازد؛ بدونِ این مجوز، همان مشتری در
			// گامِ بعد به صفحه‌ی ورود می‌خورد و سبدِ مهمانش را از دست می‌دهد.
			farazsms_abandoned_grant_guest_pass();
			wp_safe_redirect( wc_get_checkout_url() );
			exit;
		}
		farazsms_abandoned_render_magic_page( $row );
		exit;
	}

	// v3.21.22: اگر کاربر لاگین نیست، اول به صفحه‌ی ورود/ثبت‌نام می‌فرستیم و با back_url به همین
	// لینکِ بازیابی برمی‌گردانیم. دلیل: بازیابیِ سبد برای مهمان به‌خاطرِ سشنِ ناپایدار خالی
	// می‌شد؛ پس از ورود، سشن پایدار است و بازیابی درست انجام می‌شود (خواسته‌ی کاربر).
	if ( ! is_user_logged_in() ) {
		$back = add_query_arg( 'fzr', $token, home_url( '/' ) );
		$login_url = function_exists( 'farazsms_survey_login_url_with_return' )
			? farazsms_survey_login_url_with_return( $back )
			: wp_login_url( $back );
		wp_safe_redirect( $login_url );
		exit;
	}

	farazsms_abandoned_restore_cart_from_row( $row );
	// Redirect to the cart page after restore (clean URL).
	wp_safe_redirect( wc_get_cart_url() );
	exit;
}

/**
 * بازیابیِ سبد از ردیف.
 *
 * تعدادِ اقلامی که **واقعاً** به سبد اضافه شدند برمی‌گردد (نه صرفِ تلاش). پیش از این بولی بود و
 * «همه‌ی محصولات ناموجود شده‌اند» از «انجام شد» قابلِ تفکیک نبود، پس مشتری به تسویه‌ی خالی
 * فرستاده می‌شد. صفر یعنی هیچ.
 *
 * @param array $row ردیفِ سبدِ رهاشده.
 * @return int تعدادِ اقلامِ اضافه‌شده.
 */
function farazsms_abandoned_restore_cart_from_row( $row ) {
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return 0;
	}
	$items = json_decode( (string) $row['cart_data'], true );
	if ( ! is_array( $items ) || empty( $items ) ) {
		return 0;
	}
	// عکسِ سبدِ فعلی پیش از خالی‌کردن: اگر هیچ‌کدام از اقلامِ ذخیره‌شده دیگر قابلِ افزودن نباشند،
	// نباید سبدِ زنده‌ی مشتری را هم نابود کرده باشیم.
	$backup = (array) WC()->cart->get_cart();
	WC()->cart->empty_cart();
	$added = 0;
	foreach ( $items as $item ) {
		$pid = isset( $item['product_id'] )   ? (int) $item['product_id']   : 0;
		$vid = isset( $item['variation_id'] ) ? (int) $item['variation_id'] : 0;
		$qty = isset( $item['quantity'] )     ? max( 1, (int) $item['quantity'] ) : 1;
		if ( $pid > 0 && WC()->cart->add_to_cart( $pid, $qty, $vid ) ) {
			$added++;
		}
	}
	if ( $added < 1 && ! empty( $backup ) ) {
		foreach ( $backup as $line ) {
			$pid = isset( $line['product_id'] )   ? (int) $line['product_id']   : 0;
			$vid = isset( $line['variation_id'] ) ? (int) $line['variation_id'] : 0;
			$qty = isset( $line['quantity'] )     ? max( 1, (int) $line['quantity'] ) : 1;
			if ( $pid <= 0 ) {
				continue;
			}
			// ویژگی‌های تنوع و دیتای اقلامِ افزونه‌های دیگر (اشتراک، افزودنی، رزرو) هم باید
			// برگردند؛ بدونِ آن‌ها سبدِ «دست‌نخورده» عملاً سبدِ دیگری است.
			$variation = isset( $line['variation'] ) && is_array( $line['variation'] ) ? $line['variation'] : array();
			$extra     = array_diff_key( (array) $line, array_flip( array(
				'key', 'product_id', 'variation_id', 'variation', 'quantity',
				'data', 'data_hash', 'line_tax_data', 'line_subtotal', 'line_subtotal_tax',
				'line_total', 'line_tax',
			) ) );
			WC()->cart->add_to_cart( $pid, $qty, $vid, $variation, $extra );
		}
	}
	return $added;
}

// ============================================================================
// مجوزِ عبورِ مهمان از گیتِ تسویه
// ============================================================================
// مسیرِ لینکِ پیامکیِ سبد عمداً مهمان‌محور است و صفحه‌ی واسط هم صریحاً می‌گوید حساب کاربری
// نمی‌سازد. ولی اگر مدیر «ورودِ اجباری در تسویه» را روشن کرده باشد، ریدایرکتِ پس از بازیابی
// به صفحه‌ی ورود می‌خورد و سبدِ مهمان از بین می‌رود. این مجوزِ کوتاه‌عمر همان یک خرید را باز
// می‌کند و به هیچ چیزِ دیگری دست نمی‌زند (گیتِ صفحه‌ایِ «ورودِ اجباری» دست‌نخورده می‌ماند).

const FARAZSMS_ABANDONED_GUEST_PASS_KEY = 'farazsms_abandoned_guest_pass';

/** عمرِ مجوز به ثانیه — یک ساعت برای تمام‌کردنِ همان خرید. */
function farazsms_abandoned_guest_pass_ttl() {
	// کران: مقدارِ صفر/منفی مجوز را مرده به دنیا می‌آورد (باگ برمی‌گردد) و مقدارِ عظیم
	// عملاً گیتِ فروشنده را برای همیشه باز می‌گذارد.
	return max( 60, min( DAY_IN_SECONDS, (int) apply_filters( 'farazsms_abandoned_guest_pass_ttl', HOUR_IN_SECONDS ) ) );
}

/**
 * منطقِ خالصِ اعتبار — جدا از ووکامرس تا آزمودنی باشد.
 *
 * @param mixed $stored مهرِ زمانیِ انقضای ذخیره‌شده (یا هر چیزِ نامعتبر).
 * @param int   $now    زمانِ حال.
 * @return bool
 */
function farazsms_abandoned_guest_pass_is_active( $stored, $now ) {
	return is_scalar( $stored ) && (int) $stored > (int) $now;
}

/** صدورِ مجوز برای جلسه‌ی جاری. */
function farazsms_abandoned_grant_guest_pass() {
	if ( ! function_exists( 'WC' ) || ! WC()->session ) {
		return;
	}
	WC()->session->set( FARAZSMS_ABANDONED_GUEST_PASS_KEY, time() + farazsms_abandoned_guest_pass_ttl() );
}

/** آیا جلسه‌ی جاری مجوزِ معتبر دارد؟ */
function farazsms_abandoned_guest_pass_is_valid() {
	if ( ! function_exists( 'WC' ) || ! WC()->session ) {
		return false;
	}
	return farazsms_abandoned_guest_pass_is_active( WC()->session->get( FARAZSMS_ABANDONED_GUEST_PASS_KEY ), time() );
}

/**
 * باطل‌کردنِ مجوز. مجوز برای «تمام‌کردنِ همان یک خرید» است؛ اگر تا پایانِ عمرش باز بماند،
 * هر تسویه‌ی دیگری در همان جلسه هم از گیتِ فروشنده رد می‌شود.
 */
function farazsms_abandoned_revoke_guest_pass() {
	if ( ! function_exists( 'WC' ) || ! WC()->session ) {
		return;
	}
	WC()->session->set( FARAZSMS_ABANDONED_GUEST_PASS_KEY, null );
}
// عمداً روی «سفارش ثبت شد» نیست: بینِ ثبتِ سفارش و رسیدنِ مشتری به صفحه‌ی تأییدیه چند
// ریدایرکت فاصله است و اگر مجوز همان‌جا باطل شود، مهمان وسطِ راه به صفحه‌ی ورود می‌خورد.
// روی صفحه‌ی تشکر باطل می‌شود: خرید تمام شده و مجوز دیگر کاری ندارد.
add_action( 'woocommerce_thankyou', 'farazsms_abandoned_revoke_guest_pass', 99 );

// گیتِ ورود این فیلتر را می‌دهد؛ اگر این فایل بار نشده باشد (لودرِ محافظت‌شده) شنونده‌ای نیست
// و گیت دقیقاً مثلِ قبل رفتار می‌کند.
add_filter( 'farazsms_login_gate_checkout_bypass', 'farazsms_abandoned_maybe_bypass_checkout_gate' );
function farazsms_abandoned_maybe_bypass_checkout_gate( $bypass ) {
	return $bypass || farazsms_abandoned_guest_pass_is_valid();
}

function farazsms_abandoned_render_magic_expired() {
	status_header( 410 );
	nocache_headers();
	echo '<!doctype html><html ' . get_language_attributes() . '><head><meta charset="' . esc_attr( get_bloginfo( 'charset' ) ) . '"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' . esc_html__( 'لینک منقضی شده', 'farazsms' ) . '</title></head><body style="font-family:-apple-system,BlinkMacSystemFont,system-ui,Vazirmatn,Vazir,IRANSans,IRANYekan,Tahoma,sans-serif;direction:rtl;background:#f8fafc;margin:0;padding:32px;"><main style="max-width:560px;margin:40px auto;background:#fff;border:1px solid #e5e7eb;border-radius:16px;padding:28px;text-align:center;"><h1 style="font-size:20px;margin:0 0 12px;">' . esc_html__( 'این لینک دیگر معتبر نیست', 'farazsms' ) . '</h1><p style="color:#64748b;line-height:2;">' . esc_html__( 'برای حفظ امنیت و تازگی قیمت/موجودی، لینک سبد خرید رهاشده منقضی شده است.', 'farazsms' ) . '</p><a href="' . esc_url( wc_get_cart_url() ) . '" style="display:inline-block;background:#365891;color:#fff;padding:11px 20px;border-radius:8px;text-decoration:none;font-weight:700;">' . esc_html__( 'رفتن به فروشگاه', 'farazsms' ) . '</a></main></body></html>';
}

function farazsms_abandoned_render_magic_page( $row ) {
	nocache_headers();
	$items = json_decode( (string) $row['cart_data'], true );
	$settings = farazsms_abandoned_settings();
	$first = trim( (string) ( $row['first_name'] ?? '' ) );
	$show_name = ( $settings['magic_show_name'] ?? '1' ) === '1' && $first !== '';
	$masked_mobile = farazsms_abandoned_mask_mobile( $row['mobile'] ?? '' );
	echo '<!doctype html><html ' . get_language_attributes() . '><head><meta charset="' . esc_attr( get_bloginfo( 'charset' ) ) . '"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' . esc_html__( 'سبد خرید شما آماده است', 'farazsms' ) . '</title>';
	echo '<style>body{font-family:-apple-system,BlinkMacSystemFont,system-ui,Vazirmatn,Vazir,IRANSans,IRANYekan,Tahoma,sans-serif;direction:rtl;background:#f8fafc;margin:0;color:#334155}.fzabc{max-width:760px;margin:32px auto;padding:0 16px}.fzabc-card{background:#fff;border:1px solid #e5e7eb;border-radius:18px;box-shadow:0 8px 24px rgba(15,23,42,.06);padding:24px}.fzabc h1{font-size:22px;margin:0 0 8px;color:#0f172a}.fzabc p{line-height:2;color:#64748b}.fzabc-items{display:grid;gap:12px;margin:20px 0}.fzabc-item{display:flex;gap:12px;align-items:center;border:1px solid #eef2f7;border-radius:12px;padding:10px;background:#fff}.fzabc-thumb{width:64px;height:64px;border-radius:10px;object-fit:cover;background:#f1f5f9}.fzabc-name{font-weight:700;color:#0f172a}.fzabc-meta{font-size:12px;color:#64748b;margin-top:4px}.fzabc-total{display:flex;justify-content:space-between;border-top:1px solid #e5e7eb;padding-top:14px;margin-top:12px;font-weight:700}.fzabc-btn{width:100%;border:0;background:#365891;color:#fff;padding:13px 18px;border-radius:10px;font-size:15px;font-weight:800;cursor:pointer;margin-top:18px}.fzabc-note{font-size:11.5px;color:#94a3b8;text-align:center;margin-top:12px}</style></head><body><main class="fzabc"><section class="fzabc-card">';
	echo '<h1>' . esc_html( $show_name ? sprintf( __( 'سلام %s، سبد خریدت آماده است', 'farazsms' ), $first ) : __( 'سبد خرید شما آماده است', 'farazsms' ) ) . '</h1>';
	echo '<p>' . esc_html__( 'این محصولات هنوز منتظر شما هستند. برای ادامه، سبد را بازیابی می‌کنیم و مستقیم به پرداخت می‌بریم.', 'farazsms' ) . '</p>';
	if ( $masked_mobile !== '' ) {
		echo '<p style="font-size:12px;margin-top:-4px;">' . esc_html__( 'شماره شناسایی‌شده:', 'farazsms' ) . ' <span dir="ltr">' . esc_html( $masked_mobile ) . '</span></p>';
	}
	echo '<div class="fzabc-items">';
	foreach ( (array) $items as $item ) {
		$pid = isset( $item['product_id'] ) ? (int) $item['product_id'] : 0;
		$vid = isset( $item['variation_id'] ) ? (int) $item['variation_id'] : 0;
		$product = $vid ? wc_get_product( $vid ) : ( $pid ? wc_get_product( $pid ) : false );
		$name = $product ? $product->get_name() : (string) ( $item['name'] ?? '' );
		$qty = isset( $item['quantity'] ) ? max( 1, (int) $item['quantity'] ) : 1;
		$image = $product ? wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' ) : '';
		if ( $image === '' && function_exists( 'wc_placeholder_img_src' ) ) {
			$image = wc_placeholder_img_src( 'thumbnail' );
		}
		echo '<div class="fzabc-item">';
		if ( $image !== '' ) {
			echo '<img class="fzabc-thumb" src="' . esc_url( $image ) . '" alt="' . esc_attr( $name ) . '">';
		}
		echo '<div><div class="fzabc-name">' . esc_html( $name ) . '</div><div class="fzabc-meta">' . esc_html__( 'تعداد:', 'farazsms' ) . ' ' . esc_html( number_format_i18n( $qty ) ) . '</div></div></div>';
	}
	echo '</div><div class="fzabc-total"><span>' . esc_html__( 'جمع تقریبی سبد', 'farazsms' ) . '</span><span>' . esc_html( farazsms_abandoned_format_price( (float) $row['total_value'] ) ) . '</span></div>';
	echo '<form method="post">' . wp_nonce_field( 'farazsms_abandoned_magic_checkout_' . (int) $row['id'], 'farazsms_abandoned_magic_nonce', true, false ) . '<input type="hidden" name="farazsms_abandoned_magic_checkout" value="1"><button class="fzabc-btn" type="submit">' . esc_html__( 'تکمیل خرید و پرداخت', 'farazsms' ) . '</button></form>';
	echo '<div class="fzabc-note">' . esc_html__( 'این لینک فقط برای تکمیل همین خرید است و دسترسی به حساب کاربری ایجاد نمی‌کند.', 'farazsms' ) . '</div>';
	echo '</section></main></body></html>';
}

// ============================================================================
// Cron dispatcher
// ============================================================================

add_action( FARAZSMS_ABANDONED_CRON_HOOK, 'farazsms_abandoned_run_dispatch' );
/**
 * ستون‌هایی که پس از یک تلاشِ یادآوری به‌روز می‌شوند.
 *
 * ⚠️ چرا تابعِ جدا: `sent_at` **شواهدِ انتساب** است، نه وضعیتِ آخرین تلاش. تا
 * بازبینیِ ۱۴۰۵/۰۶/۱۶ روی شکست null نوشته می‌شد، یعنی یک یادآوریِ ناموفقِ دوم
 * شواهدِ یادآوریِ موفقِ اول را می‌سوزاند و آن بازگشت از آمار حذف می‌شد. حالا
 * این ستون یک نویسنده بیشتر ندارد و فقط روی موفقیت نوشته می‌شود.
 *
 * @param string $result نتیجه‌ی لایه‌ی ارسال.
 * @param string $now
 * @return array
 */
function farazsms_abandoned_dispatch_update( $result, $now ) {
	$update = array(
		'status'     => $result === 'success' ? 'sent' : 'active',
		'updated_at' => $now,
	);
	if ( $result === 'success' ) {
		$update['sent_at'] = $now;
	}
	return $update;
}

function farazsms_abandoned_run_dispatch() {
	// v3.22.94: مهاجرتِ جدول (idempotent، version-gated) در ابتدای cron هم اجرا شود. قبلاً فقط روی
	// admin_init بود؛ ولی SELECTِ ارسال حالا ستونِ last_name را می‌خواند و wp-cron روی admin_init
	// اجرا نمی‌شود → اگر cron قبل از ورودِ ادمین به پیشخوان اجرا می‌شد، «Unknown column» می‌داد و کلِ
	// ارسال بی‌صدا متوقف می‌شد تا وقتی ادمین وارد شود.
	farazsms_abandoned_maybe_setup_table();

	// v3.21.26 (P5): قفلِ سبک ضدِ هم‌زمانی — wp-cron تک‌نخی نیست؛ دو اجرای هم‌زمان می‌توانند
	// همان ردیف‌ها را قبل از علامت‌خوردن انتخاب کنند → پیامکِ دوتایی/هدررفتِ اعتبار.
	if ( get_transient( 'farazsms_abandoned_dispatch_lock' ) ) {
		return;
	}
	set_transient( 'farazsms_abandoned_dispatch_lock', '1', 5 * MINUTE_IN_SECONDS );

	$settings = farazsms_abandoned_settings();
	if ( $settings['enabled'] !== '1' ) {
		delete_transient( 'farazsms_abandoned_dispatch_lock' );
		return;
	}
	$pattern = trim( (string) $settings['pattern_code'] );
	if ( $pattern === '' || ! function_exists( 'farazsms_send_pattern_sms_raw' ) ) {
		delete_transient( 'farazsms_abandoned_dispatch_lock' );
		return;
	}
	// متنِ پترن (برای تصمیمِ اینکه کدام متغیرِ نامِ کامل تزریق شود — گاردِ v3.22.94).
	$ab_message = (string) ( $settings['message'] ?? '' );

	$delay_hours = max( 1, (int) $settings['delay_hours'] );
	$expiry_days = max( 1, (int) $settings['expiry_days'] );
	$batch_size  = max( 1, (int) $settings['batch_size'] );

	global $wpdb;
	$table  = farazsms_abandoned_table();
	$now    = current_time( 'mysql' );
	// v3.21.88 رفعِ باگِ تأخیر: updated_at با current_time('mysql') به‌صورتِ محلی ذخیره می‌شود،
	// ولی cutoffها قبلاً با gmdate/UTC حساب می‌شدند → اختلافِ +۳:۳۰ ایران، یعنی «۱ ساعت» عملاً
	// ~۴.۵ ساعت می‌شد. حالا cutoff را از تایم‌استمپِ محلی (current_time('timestamp')) می‌سازیم تا
	// هر دو طرفِ مقایسه هم‌مبنا (محلی) باشند.
	$now_ts        = current_time( 'timestamp' );
	$cutoff_send   = gmdate( 'Y-m-d H:i:s', $now_ts - $delay_hours * HOUR_IN_SECONDS );
	$cutoff_expire = gmdate( 'Y-m-d H:i:s', $now_ts - $expiry_days * DAY_IN_SECONDS );

	// 1) Mark too-old carts as expired (no SMS — they're not worth recovering).
	$wpdb->query( $wpdb->prepare(
		"UPDATE $table SET status = %s, updated_at = %s WHERE status IN ('active','sent') AND updated_at < %s",
		'expired',
		$now,
		$cutoff_expire
	) );

	// 2) Find candidates: active, has mobile, last updated ≥ delay_hours ago.
	// v3.13.13 PERF: ستون‌های دقیق به‌جای SELECT * — ستون cart_data از نوع LONGTEXT
	// است و در ارسال پیامک به آن نیاز نداریم. این تغییر برای فروشگاه‌هایی با ۱۰k+
	// سبد معلق، حافظه و زمان query را به‌طور قابل‌توجهی کاهش می‌دهد.
	$rows = $wpdb->get_results( $wpdb->prepare(
		"SELECT id, mobile, first_name, last_name, total_value, items_count, token
		 FROM $table
		 WHERE status = %s AND mobile != '' AND updated_at <= %s
		 ORDER BY updated_at ASC
		 LIMIT %d",
		'active',
		$cutoff_send,
		$batch_size
	), ARRAY_A );

	if ( empty( $rows ) ) {
		delete_transient( 'farazsms_abandoned_dispatch_lock' );
		return;
	}

	// v3.13.13 PERF: site name و sender را خارج از حلقه می‌خوانیم — قبل از این
	// در هر iteration یک get_option اضافه اجرا می‌شد.
	// v3.21.44: خطِ تبلیغاتیِ PRO پترن را هم می‌فرستد؛ این اعلانِ تبلیغاتی از خطِ تبلیغات (پیش‌فرض PRO) می‌رود.
	$sender    = farazsms_get_ad_sender();
	$site_name = get_bloginfo( 'name' );
	foreach ( $rows as $row ) {
		$mobile = (string) $row['mobile'];
		if ( $mobile === '' ) {
			continue;
		}
		// v3.21.17: کلیدِ کوتاه `fzr` به‌جای `farazsms_recover_cart` برای کوتاه‌شدنِ لینکِ پیامک.
		// readerِ بازیابی هر دو کلید را می‌پذیرد، پس پیامک‌های قبلاً‌ارسال‌شده هم کار می‌کنند.
		$recover_url = farazsms_abandoned_magic_url( $row['token'] );
		// v3.21.56: کوتاه‌کردنِ لینکِ بازگشت با کوتاه‌کننده (در صورتِ فعال‌بودن) — لینکِ کوتاه‌تر،
		// خارج از صفِ مانیتورینگ. در صورتِ خطا، همان لینکِ اصلی استفاده می‌شود.
		$resume_for_sms = farazsms_shorten_link( $recover_url, 'abandoned', 'ماژول سبد خرید رها شده / کاربری ' . ( $row['first_name'] !== '' ? $row['first_name'] : $mobile ) );
		// v3.22.91: نامِ کامل — %full_name%/%customer_name% (اگر نام‌خانوادگی هست) علاوه بر %first_name%.
		$fn        = trim( (string) $row['first_name'] );
		$ln        = trim( (string) ( $row['last_name'] ?? '' ) );
		$full_name = trim( $fn . ' ' . $ln );
		if ( $full_name === '' ) {
			$full_name = 'مشتری گرامی';
		}
		$attrs = array(
			'first_name'    => $fn !== '' ? $fn : 'مشتری گرامی',
			'sitename'      => $site_name,
			// نامِ امن: cart_total با «ca» (دو کاراکترِ هگز) توسطِ پنل خراب می‌شد → total_price.
			'total_price'   => farazsms_abandoned_format_price( (float) $row['total_value'] ),
			'items_count'   => (int) $row['items_count'],
			'resume_url'    => $resume_for_sms,
		);
		// v3.22.94: متغیرهای نامِ کامل فقط وقتی متنِ پترن به آن‌ها اشاره دارد تزریق شوند — متغیرِ اعلام‌نشده
		// می‌تواند باعثِ ردِ کلِ پیامک توسطِ فراز شود (مثلِ گاردِ %items% در پیامکِ سفارش). + برش به طولِ
		// اعلام‌شده (۴۰ برای نامِ کامل، ۲۵ برای نامِ خانوادگی).
		$cut = function ( $v, $n ) { return function_exists( 'mb_substr' ) ? mb_substr( (string) $v, 0, $n, 'UTF-8' ) : substr( (string) $v, 0, $n ); };
		if ( strpos( $ab_message, 'full_name' ) !== false ) {
			$attrs['full_name'] = $cut( $full_name, 40 );
		}
		if ( strpos( $ab_message, 'customer_name' ) !== false ) {
			$attrs['customer_name'] = $cut( $full_name, 40 );
		}
		if ( strpos( $ab_message, 'last_name' ) !== false ) {
			$attrs['last_name'] = $ln !== '' ? $cut( $ln, 25 ) : '-';
		}
		$result = farazsms_send_pattern_sms_raw( $mobile, $pattern, $attrs, $sender );

		// کانالِ بله (MVP): پس از ارسالِ موفق، متنِ حل‌شده‌ی محلی (template + attrs، شاملِ لینکِ
		// کوتاه‌شده‌ی بازگشت) در بله هم برود. maybe_send خود-گِیت + async + هرگز-بلاک است.
		if ( $result === 'success' ) {
			$bale_text = farazsms_bale_resolve_local_text( $ab_message, $attrs );
			farazsms_bale_maybe_send( 'abandoned', $mobile, $bale_text );
		}

		// ⚠️ `sent_at` فقط روی **موفقیت** نوشته می‌شود و هرگز پاک نمی‌شود.
		//
		// نسخه‌ی قبلی روی شکست null می‌گذاشت. یعنی یک یادآوریِ ناموفقِ دوم،
		// شواهدِ یادآوریِ موفقِ اول را می‌سوزاند و آن بازگشت از انتساب حذف
		// می‌شد. این ستون «آخرین پیامکی که واقعاً رفت» را نگه می‌دارد، نه
		// وضعیتِ آخرین تلاش را — وضعیت در `status` است.
		$wpdb->update( $table, farazsms_abandoned_dispatch_update( $result, $now ), array( 'id' => (int) $row['id'] ) );
	}

	// v3.21.26 (P5): آزادسازیِ قفل پس از پایانِ اجرا (auto-expire هم به‌عنوانِ شبکه‌ی ایمنی).
	delete_transient( 'farazsms_abandoned_dispatch_lock' );
}

function farazsms_abandoned_format_price( $value ) {
	// v3.21.32: استفاده از helperِ مشترک که &nbsp;/markupِ wc_price را پاک می‌کند
	// (باگِ «&nbsp; داخلِ متنِ پیامک»).
	return farazsms_price_plain( $value );
}

// ============================================================================
// Stats
// ============================================================================

function farazsms_abandoned_get_stats( $days = 30 ) {
	global $wpdb;
	$table  = farazsms_abandoned_table();
	$cutoff = gmdate( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );

	$total        = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE created_at >= %s", $cutoff ) );
	$active       = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE created_at >= %s AND status = %s", $cutoff, 'active' ) );
	$sent         = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE sent_at IS NOT NULL AND sent_at >= %s", $cutoff ) );
	// ⚠️ «بازیافت‌شده» = فقط سبدی که پیامکِ ما رفته و بعدش برگشته.
	//
	// شمارشِ خامِ recovered_at هر خریدِ عادی را هم دربر می‌گرفت (وضعیت روی هر
	// سفارشِ پرداخت‌شده نوشته می‌شود تا یادآوریِ بعدی نرود)، پس این صفحه و
	// صفحه‌ی سودآوری دو عددِ متفاوت می‌گفتند و هیچ‌کدام هم درست نبود.
	// ⚠️ صورت و مخرج روی **یک** پایه‌ی زمانی: هر دو «پیامکی که در این پنجره رفت».
	//
	// تا این بازبینی مخرج روی sent_at و صورت روی recovered_at بود؛ پیامکی که
	// ۴۰ روز پیش رفته و ۵ روز پیش نتیجه داده، در صورت می‌آمد ولی در مخرج نه —
	// یعنی نرخ می‌توانست از ۱۰۰٪ رد کند. همان نقصی که در داشبوردِ مارکتینگ
	// رفع شد و این‌جا جا مانده بود.
	$attributed   = farazsms_abandoned_attributed_where( array( 'sent_at >= %s' ) );
	$recovered    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE $attributed", $cutoff ) );
	$recov_value  = (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(total_value), 0) FROM $table WHERE $attributed", $cutoff ) );
	$total_value  = (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(total_value), 0) FROM $table WHERE created_at >= %s", $cutoff ) );
	$expired      = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE status = %s AND updated_at >= %s", 'expired', $cutoff ) );
	// کوئریِ جداگانه‌ی «بازیافت پس از پیامک» حذف شد: حالا دقیقاً همان چیزی است
	// که $recovered می‌شمارد. دو پرسشِ موازی از یک حقیقت، همان دوگانگی‌ای بود
	// که این باگ را ساخت.
	// ⚠️ «نرخِ کلی» حذف شد: مخرجش هر سبدِ رصدشده بود — که شاملِ هر خریدِ کاملاً
	// عادی هم هست. عددی نزدیکِ صفر می‌داد و چیزی درباره‌ی کارآمدیِ یادآوری
	// نمی‌گفت. تنها نرخِ معنادار «از پیامک‌هایی که فرستادیم، چند تا برگشت» است.
	$post_sms_rate  = $sent > 0 ? round( ( $recovered / $sent ) * 100, 1 ) : 0;

	return array(
		'total'           => $total,
		'active'          => $active,
		'sent'            => $sent,
		'recovered'       => $recovered,
		'expired'         => $expired,
		'total_value'     => $total_value,
		'recov_value'     => $recov_value,
		'post_sms_rate'   => $post_sms_rate,
	);
}

// ============================================================================
// Settings save
// ============================================================================

add_action( 'admin_post_farazsms_abandoned_save_settings', 'farazsms_abandoned_handle_save_settings' );
function farazsms_abandoned_handle_save_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( __( 'دسترسی غیرمجاز.', 'farazsms' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'farazsms_abandoned_settings' );

	$new = farazsms_abandoned_settings();
	$new['enabled']          = isset( $_POST['enabled'] )          && $_POST['enabled'] === '1' ? '1' : '0';
	$new['capture_checkout'] = isset( $_POST['capture_checkout'] ) && $_POST['capture_checkout'] === '1' ? '1' : '0';
	$new['delay_hours']      = isset( $_POST['delay_hours'] )  ? max( 1, (int) $_POST['delay_hours'] )  : 1;
	$new['expiry_days']      = isset( $_POST['expiry_days'] )  ? max( 1, (int) $_POST['expiry_days'] )  : 7;
	$new['batch_size']       = isset( $_POST['batch_size'] )   ? max( 1, min( 500, (int) $_POST['batch_size'] ) ) : 50;
	$link_mode              = isset( $_POST['link_mode'] ) ? sanitize_key( wp_unslash( $_POST['link_mode'] ) ) : 'magic';
	$new['link_mode']        = in_array( $link_mode, array( 'magic', 'login' ), true ) ? $link_mode : 'magic';
	$new['magic_ttl_hours']  = isset( $_POST['magic_ttl_hours'] ) ? max( 1, min( 168, (int) $_POST['magic_ttl_hours'] ) ) : 48;
	$new['magic_show_name']  = isset( $_POST['magic_show_name'] ) && $_POST['magic_show_name'] === '1' ? '1' : '0';
	$new['pattern_code']     = isset( $_POST['pattern_code'] ) ? sanitize_text_field( wp_unslash( $_POST['pattern_code'] ) ) : '';
	if ( isset( $_POST['message'] ) ) {
		$new['message'] = farazsms_sanitize_pattern_text( $_POST['message'] );
	}
	update_option( 'farazsms_abandoned_settings', $new, false );
	wp_safe_redirect( add_query_arg( array( 'page' => 'farazsms-abandoned', 'tab' => 'settings', 'updated' => '1' ), admin_url( 'admin.php' ) ) );
	exit;
}

add_action( 'wp_ajax_farazsms_abandoned_delete', 'farazsms_abandoned_ajax_delete' );
function farazsms_abandoned_ajax_delete() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز.', 'farazsms' ) ), 403 );
	}
	check_ajax_referer( 'farazsms_abandoned_admin', 'nonce' );
	global $wpdb;
	$ids = isset( $_POST['ids'] ) ? (array) $_POST['ids'] : array();
	$ids = array_filter( array_map( 'absint', $ids ) );
	if ( empty( $ids ) ) {
		wp_send_json_error( array( 'message' => __( 'هیچ ردیفی انتخاب نشده.', 'farazsms' ) ) );
	}
	$ids   = array_slice( $ids, 0, 500 );
	$table = farazsms_abandoned_table();
	$ph    = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
	$count = (int) $wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE id IN ($ph)", $ids ) );
	wp_send_json_success( array(
		'message' => sprintf( __( '%s ردیف حذف شد.', 'farazsms' ), number_format_i18n( $count ) ),
		'deleted' => $count,
	) );
}

// Manual "run dispatch now" button for testing.
add_action( 'admin_post_farazsms_abandoned_run_now', 'farazsms_abandoned_handle_run_now' );
function farazsms_abandoned_handle_run_now() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( __( 'دسترسی غیرمجاز.', 'farazsms' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'farazsms_abandoned_run_now' );
	farazsms_abandoned_run_dispatch();
	wp_safe_redirect( add_query_arg( array( 'page' => 'farazsms-abandoned', 'ran' => '1' ), admin_url( 'admin.php' ) ) );
	exit;
}

// ============================================================================
// Admin page render
// ============================================================================

function farazsms_render_abandoned_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	farazsms_abandoned_maybe_setup_table();

	$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';
	$tab = in_array( $tab, array( 'dashboard', 'list', 'settings' ), true ) ? $tab : 'dashboard';

	echo '<section class="wrapper farazsms-abandoned-wrapper">';
	farazsms_abandoned_render_header();
	farazsms_abandoned_render_tabs( $tab );
	switch ( $tab ) {
		case 'list':
			farazsms_abandoned_render_list_tab();
			break;
		case 'settings':
			farazsms_abandoned_render_settings_tab();
			break;
		default:
			farazsms_abandoned_render_dashboard_tab();
	}
	farazsms_abandoned_render_inline();
	echo '</section>';
}

function farazsms_abandoned_render_header() {
	$apikey = farazsms_get_apikey();
	?>
	<div id="farazsms_header">
		<div>
			<a href="https://farazsms.com" target="_blank" rel="noopener">
				<img src="<?php echo esc_url( FARAZSMS_CORE_IMG . 'logo-1.png' ); ?>" alt="<?php esc_attr_e( 'فراز اس‌ام‌اس', 'farazsms' ); ?>">
			</a>
		</div>
		<?php if ( ! empty( $apikey ) ) : ?>
			<div id="farazsms_account_info">
				<div class="farazsms_credit_amount">
					<span><?php esc_html_e( 'میزان اعتبار: ', 'farazsms' ); ?></span>
					<?php echo esc_html( (string) farazsms_get_credit() ); ?>
					<span> <?php esc_html_e( 'تومان', 'farazsms' ); ?></span>
				</div>
				<?php if ( function_exists( 'farazsms_render_profile_block' ) ) { farazsms_render_profile_block(); } ?>
			</div>
		<?php endif; ?>
	</div>
	<h1 class="farazsms-abandoned-title-main"><?php esc_html_e( 'سبد خرید رها‌شده', 'farazsms' ); ?></h1>
	<?php if ( ! class_exists( 'WooCommerce' ) ) : ?>
		<div class="notice notice-warning"><p><?php esc_html_e( 'این قابلیت نیازمند ووکامرس است.', 'farazsms' ); ?></p></div>
	<?php endif; ?>
	<?php
}

function farazsms_abandoned_render_tabs( $active ) {
	$tabs = array(
		'dashboard' => __( 'داشبورد آماری', 'farazsms' ),
		'list'      => __( 'لیست سبدها', 'farazsms' ),
		'settings'  => __( 'تنظیمات', 'farazsms' ),
	);
	?>
	<nav class="farazsms-abandoned-tabs">
		<?php foreach ( $tabs as $key => $label ) :
			$url = add_query_arg( array( 'page' => 'farazsms-abandoned', 'tab' => $key ), admin_url( 'admin.php' ) );
		?>
			<a class="farazsms-abandoned-tab <?php echo $active === $key ? 'is-active' : ''; ?>" href="<?php echo esc_url( $url ); ?>">
				<?php echo esc_html( $label ); ?>
			</a>
		<?php endforeach; ?>
	</nav>
	<?php
}

function farazsms_abandoned_render_dashboard_tab() {
	$days = isset( $_GET['days'] ) ? max( 1, (int) $_GET['days'] ) : 30;
	$days = in_array( $days, array( 7, 30, 90, 365 ), true ) ? $days : 30;
	$s    = farazsms_abandoned_get_stats( $days );
	$next_cron = wp_next_scheduled( FARAZSMS_ABANDONED_CRON_HOOK );
	$ran  = isset( $_GET['ran'] ) ? sanitize_key( $_GET['ran'] ) : '';
	?>
	<?php if ( $ran === '1' ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'اجرای دستی dispatch انجام شد.', 'farazsms' ); ?></p></div>
	<?php endif; ?>

	<div class="farazsms-abandoned-range-bar">
		<?php
		$ranges = array( 7 => '۷ روز', 30 => '۳۰ روز', 90 => '۹۰ روز', 365 => '۱ سال' );
		foreach ( $ranges as $d => $lbl ) :
			$url = add_query_arg( array( 'page' => 'farazsms-abandoned', 'days' => $d ), admin_url( 'admin.php' ) );
			?>
			<a href="<?php echo esc_url( $url ); ?>" class="farazsms-abandoned-range <?php echo $days === $d ? 'is-active' : ''; ?>"><?php echo esc_html( $lbl ); ?></a>
		<?php endforeach; ?>
	</div>

	<div class="farazsms-abandoned-stats">
		<div class="farazsms-abandoned-stat">
			<div class="num"><?php echo esc_html( number_format_i18n( $s['total'] ) ); ?></div>
			<div class="lbl"><?php esc_html_e( 'کل سبدهای رها‌شده', 'farazsms' ); ?></div>
		</div>
		<div class="farazsms-abandoned-stat">
			<div class="num farazsms-num-info"><?php echo esc_html( number_format_i18n( $s['sent'] ) ); ?></div>
			<div class="lbl"><?php esc_html_e( 'پیامک یادآوری ارسال شده', 'farazsms' ); ?></div>
		</div>
		<div class="farazsms-abandoned-stat">
			<div class="num farazsms-num-success"><?php echo esc_html( number_format_i18n( $s['recovered'] ) ); ?></div>
			<div class="lbl"><?php esc_html_e( 'سبد بازیافت‌شده', 'farazsms' ); ?></div>
		</div>
		<div class="farazsms-abandoned-stat">
			<div class="num farazsms-num-success"><?php echo esc_html( $s['post_sms_rate'] ); ?>٪</div>
			<div class="lbl"><?php esc_html_e( 'نرخ بازیافت پس از پیامک', 'farazsms' ); ?></div>
		</div>
	</div>

	<div class="farazsms-abandoned-stats">
		<div class="farazsms-abandoned-stat">
			<div class="num farazsms-num-muted"><?php echo esc_html( number_format_i18n( $s['expired'] ) ); ?></div>
			<div class="lbl"><?php esc_html_e( 'منقضی‌شده', 'farazsms' ); ?></div>
		</div>
		<div class="farazsms-abandoned-stat">
			<div class="num farazsms-num-warning"><?php echo esc_html( number_format_i18n( $s['active'] ) ); ?></div>
			<div class="lbl"><?php esc_html_e( 'هنوز فعال (در انتظار)', 'farazsms' ); ?></div>
		</div>
	</div>

	<div class="farazsms-abandoned-value-card">
		<h3><?php esc_html_e( 'ارزش بازیافت‌شده', 'farazsms' ); ?></h3>
		<div class="farazsms-abandoned-value-row">
			<div>
				<div class="farazsms-value-num"><?php echo esc_html( farazsms_abandoned_format_price( $s['recov_value'] ) ); ?></div>
				<div class="farazsms-value-lbl"><?php esc_html_e( 'مجموع ارزش سفارش‌های بازیافت‌شده', 'farazsms' ); ?></div>
			</div>
			<div>
				<div class="farazsms-value-num farazsms-value-num-muted"><?php echo esc_html( farazsms_abandoned_format_price( $s['total_value'] ) ); ?></div>
				<div class="farazsms-value-lbl"><?php esc_html_e( 'مجموع ارزش همه سبدهای رها‌شده', 'farazsms' ); ?></div>
			</div>
		</div>
	</div>

	<div class="farazsms-abandoned-cron-card">
		<div>
			<strong><?php esc_html_e( 'زمان‌بندی wp-cron:', 'farazsms' ); ?></strong>
			<?php
			if ( $next_cron ) {
				$jdate = farazsms_send_reports_to_jalali( gmdate( 'Y-m-d H:i:s', $next_cron ) );
				printf(
					/* translators: %s next run datetime */
					esc_html__( 'اجرای بعدی: %s', 'farazsms' ),
					'<code>' . esc_html( $jdate ) . '</code>'
				);
			} else {
				esc_html_e( 'cron زمان‌بندی نشده!', 'farazsms' );
			}
			?>
		</div>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:inline">
			<input type="hidden" name="action" value="farazsms_abandoned_run_now">
			<?php wp_nonce_field( 'farazsms_abandoned_run_now' ); ?>
			<button type="submit" class="button"><?php esc_html_e( 'اجرای فوری dispatch (برای تست)', 'farazsms' ); ?></button>
		</form>
	</div>
	<?php
}

function farazsms_abandoned_render_list_tab() {
	global $wpdb;
	$table  = farazsms_abandoned_table();

	$page   = isset( $_GET['paged'] )  ? max( 1, (int) $_GET['paged'] )  : 1;
	$limit  = isset( $_GET['limit'] )  ? max( 10, min( 200, (int) $_GET['limit'] ) ) : 25;
	$status = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
	$search = isset( $_GET['search'] ) ? sanitize_text_field( wp_unslash( $_GET['search'] ) ) : '';
	$where  = ' WHERE 1=1 ';
	$params = array();
	if ( in_array( $status, array( 'active', 'sent', 'recovered', 'expired' ), true ) ) {
		$where   .= ' AND status = %s';
		$params[] = $status;
	}
	if ( $search !== '' ) {
		$like     = '%' . $wpdb->esc_like( $search ) . '%';
		$where   .= ' AND (mobile LIKE %s OR email LIKE %s OR first_name LIKE %s)';
		$params[] = $like;
		$params[] = $like;
		$params[] = $like;
	}
	$total = (int) ( $params
		? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table $where", $params ) )
		: $wpdb->get_var( "SELECT COUNT(*) FROM $table $where" ) );
	$total_pages = max( 1, (int) ceil( $total / $limit ) );
	$offset      = ( $page - 1 ) * $limit;
	$query       = "SELECT * FROM $table $where ORDER BY id DESC LIMIT %d OFFSET %d";
	$all_params  = array_merge( $params, array( $limit, $offset ) );
	$rows        = $wpdb->get_results( $wpdb->prepare( $query, $all_params ), ARRAY_A );

	$status_labels = array(
		'active'    => __( 'فعال', 'farazsms' ),
		'sent'      => __( 'پیامک ارسال شده', 'farazsms' ),
		'recovered' => __( 'بازیافت‌شده', 'farazsms' ),
		'expired'   => __( 'منقضی', 'farazsms' ),
	);
	$status_classes = array(
		'active'    => 'warning',
		'sent'      => 'info',
		'recovered' => 'success',
		'expired'   => 'muted',
	);
	?>
	<form method="get" class="farazsms-abandoned-filters">
		<input type="hidden" name="page" value="farazsms-abandoned">
		<input type="hidden" name="tab" value="list">
		<label>
			<span><?php esc_html_e( 'جستجو:', 'farazsms' ); ?></span>
			<input type="text" name="search" value="<?php echo esc_attr( $search ); ?>" placeholder="<?php esc_attr_e( 'موبایل، ایمیل، نام', 'farazsms' ); ?>">
		</label>
		<label>
			<span><?php esc_html_e( 'وضعیت:', 'farazsms' ); ?></span>
			<select name="status">
				<option value=""<?php selected( $status, '' ); ?>><?php esc_html_e( 'همه', 'farazsms' ); ?></option>
				<?php foreach ( $status_labels as $k => $lbl ) : ?>
					<option value="<?php echo esc_attr( $k ); ?>"<?php selected( $status, $k ); ?>><?php echo esc_html( $lbl ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>
		<label>
			<span><?php esc_html_e( 'تعداد در صفحه:', 'farazsms' ); ?></span>
			<select name="limit">
				<?php foreach ( array( 25, 50, 100, 200 ) as $opt ) : ?>
					<option value="<?php echo esc_attr( $opt ); ?>"<?php selected( $limit, $opt ); ?>><?php echo esc_html( (string) $opt ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>
		<button type="submit" class="button button-primary"><?php esc_html_e( 'اعمال', 'farazsms' ); ?></button>
	</form>

	<form id="farazsms-abandoned-bulk-form">
		<?php wp_nonce_field( 'farazsms_abandoned_admin', 'farazsms_abandoned_admin_nonce' ); ?>
		<div class="farazsms-abandoned-bulk-bar">
			<button type="button" class="button farazsms-abandoned-bulk-delete" disabled><?php esc_html_e( 'حذف انتخاب‌شده‌ها', 'farazsms' ); ?></button>
			<span class="farazsms-abandoned-bulk-info"></span>
		</div>
		<table class="widefat striped farazsms-abandoned-table">
			<thead>
				<tr>
					<th class="check-column"><input type="checkbox" id="farazsms-abandoned-select-all"></th>
					<th><?php esc_html_e( 'شناسه', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'تاریخ', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'مشتری', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'موبایل', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'اقلام', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'مبلغ', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'وضعیت', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'بازیافت', 'farazsms' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $rows ) ) : ?>
					<tr><td colspan="9"><?php esc_html_e( 'هیچ سبد رهاشده‌ای ثبت نشده.', 'farazsms' ); ?></td></tr>
				<?php else : foreach ( $rows as $r ) :
					$jdate     = farazsms_send_reports_to_jalali( $r['updated_at'] );
					$status_t  = isset( $status_labels[ $r['status'] ] )  ? $status_labels[ $r['status'] ]  : $r['status'];
					$status_c  = isset( $status_classes[ $r['status'] ] ) ? $status_classes[ $r['status'] ] : 'muted';
					$customer  = '';
					if ( $r['first_name'] !== '' ) $customer = $r['first_name'];
					if ( (int) $r['user_id'] > 0 )  $customer .= ' #' . (int) $r['user_id'];
					if ( $customer === '' ) $customer = '—';
					$order_html = '—';
					if ( $r['recovered_order_id'] && function_exists( 'wc_get_order' ) ) {
						$order = wc_get_order( (int) $r['recovered_order_id'] );
						if ( $order ) {
							$order_html = '<a href="' . esc_url( $order->get_edit_order_url() ) . '" target="_blank">#' . (int) $r['recovered_order_id'] . '</a>';
						}
					}
				?>
					<tr>
						<td><input type="checkbox" class="farazsms-abandoned-row" value="<?php echo esc_attr( $r['id'] ); ?>"></td>
						<td><?php echo esc_html( $r['id'] ); ?></td>
						<td class="farazsms-abandoned-date-cell"><?php echo esc_html( $jdate ); ?></td>
						<td><?php echo esc_html( $customer ); ?></td>
						<td dir="ltr"><?php echo esc_html( $r['mobile'] !== '' ? $r['mobile'] : '—' ); ?></td>
						<td><?php echo esc_html( number_format_i18n( (int) $r['items_count'] ) ); ?></td>
						<td><?php echo esc_html( farazsms_abandoned_format_price( (float) $r['total_value'] ) ); ?></td>
						<td><span class="farazsms-status farazsms-status-<?php echo esc_attr( $status_c ); ?>"><?php echo esc_html( $status_t ); ?></span></td>
						<td><?php echo wp_kses_post( $order_html ); ?></td>
					</tr>
				<?php endforeach; endif; ?>
			</tbody>
		</table>
	</form>

	<?php if ( $total_pages > 1 ) :
		$base = add_query_arg( array(
			'page' => 'farazsms-abandoned', 'tab' => 'list',
			'status' => $status, 'search' => $search, 'limit' => $limit,
		), admin_url( 'admin.php' ) );
		?>
		<div class="farazsms-abandoned-pagination">
			<?php if ( $page > 1 ) : ?>
				<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $page - 1, $base ) ); ?>">« <?php esc_html_e( 'قبل', 'farazsms' ); ?></a>
			<?php endif; ?>
			<span><?php printf( esc_html__( 'صفحه %1$s از %2$s', 'farazsms' ), esc_html( number_format_i18n( $page ) ), esc_html( number_format_i18n( $total_pages ) ) ); ?></span>
			<?php if ( $page < $total_pages ) : ?>
				<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $page + 1, $base ) ); ?>"><?php esc_html_e( 'بعد', 'farazsms' ); ?> »</a>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<?php
}

function farazsms_abandoned_render_settings_tab() {
	$s = farazsms_abandoned_settings();
	$updated = isset( $_GET['updated'] ) ? sanitize_key( $_GET['updated'] ) : '';
	?>
	<?php if ( $updated === '1' ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'تنظیمات ذخیره شد.', 'farazsms' ); ?></p></div>
	<?php endif; ?>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="farazsms-abandoned-card">
		<input type="hidden" name="action" value="farazsms_abandoned_save_settings">
		<?php wp_nonce_field( 'farazsms_abandoned_settings' ); ?>

		<h2><?php esc_html_e( 'تنظیمات سبد رها‌شده', 'farazsms' ); ?></h2>

		<div class="farazsms-abandoned-settings-grid">
			<label class="farazsms-abandoned-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'فعال‌سازی', 'farazsms' ); ?></span>
				<label class="farazsms-abandoned-switch">
					<input type="checkbox" class="farazsms-toggle" name="enabled" value="1" <?php checked( $s['enabled'], '1' ); ?>>
					<span><?php esc_html_e( 'ردیابی سبد رها‌شده و ارسال پیامک یادآوری فعال است.', 'farazsms' ); ?></span>
				</label>
			</label>

			<label class="farazsms-abandoned-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'ضبط موبایل از فرم checkout', 'farazsms' ); ?></span>
				<label class="farazsms-abandoned-switch">
					<input type="checkbox" class="farazsms-toggle" name="capture_checkout" value="1" <?php checked( $s['capture_checkout'], '1' ); ?>>
					<span><?php esc_html_e( 'اگر کاربر شماره موبایل را در checkout وارد کند ولی پرداخت را تکمیل نکند، آن شماره برای ارسال یادآوری استفاده می‌شود.', 'farazsms' ); ?></span>
				</label>
			</label>

			<label class="farazsms-abandoned-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'روش باز شدن لینک پیامک', 'farazsms' ); ?></span>
				<select name="link_mode">
					<option value="magic" <?php selected( $s['link_mode'], 'magic' ); ?>><?php esc_html_e( 'Magic Link پرداخت سریع — پیشنهادی', 'farazsms' ); ?></option>
					<option value="login" <?php selected( $s['link_mode'], 'login' ); ?>><?php esc_html_e( 'ورود/OTP الزامی قبل از بازیابی سبد', 'farazsms' ); ?></option>
				</select>
				<small><?php esc_html_e( 'Magic Link فقط همین سبد را بازیابی می‌کند و دسترسی به حساب کاربری ایجاد نمی‌کند.', 'farazsms' ); ?></small>
			</label>

			<label class="farazsms-abandoned-setting">
				<span><?php esc_html_e( 'اعتبار Magic Link (ساعت)', 'farazsms' ); ?></span>
				<input type="number" name="magic_ttl_hours" value="<?php echo esc_attr( $s['magic_ttl_hours'] ); ?>" min="1" max="168" dir="ltr">
				<small><?php esc_html_e( 'پیش‌فرض ۴۸ ساعت؛ بعد از پرداخت یا انقضا دیگر جزئیات نمایش داده نمی‌شود.', 'farazsms' ); ?></small>
			</label>

			<label class="farazsms-abandoned-setting">
				<span><?php esc_html_e( 'نمایش نام کوچک مشتری', 'farazsms' ); ?></span>
				<label class="farazsms-abandoned-switch">
					<input type="checkbox" class="farazsms-toggle" name="magic_show_name" value="1" <?php checked( $s['magic_show_name'], '1' ); ?>>
					<span><?php esc_html_e( 'اگر نام مشتری را می‌دانیم، در صفحه Magic Link نمایش داده شود.', 'farazsms' ); ?></span>
				</label>
			</label>

			<label class="farazsms-abandoned-setting">
				<span><?php esc_html_e( 'تأخیر ارسال (ساعت)', 'farazsms' ); ?></span>
				<input type="number" name="delay_hours" value="<?php echo esc_attr( $s['delay_hours'] ); ?>" min="1" max="168" dir="ltr">
				<small><?php esc_html_e( 'پس از این مدت از آخرین تغییر سبد، پیامک یادآوری ارسال می‌شود.', 'farazsms' ); ?></small>
			</label>

			<label class="farazsms-abandoned-setting">
				<span><?php esc_html_e( 'انقضاء (روز)', 'farazsms' ); ?></span>
				<input type="number" name="expiry_days" value="<?php echo esc_attr( $s['expiry_days'] ); ?>" min="1" max="365" dir="ltr">
				<small><?php esc_html_e( 'سبدهای قدیمی‌تر از این مدت دیگر پیامک نخواهند گرفت.', 'farazsms' ); ?></small>
			</label>

			<label class="farazsms-abandoned-setting">
				<span><?php esc_html_e( 'سقف ارسال در هر اجرای cron', 'farazsms' ); ?></span>
				<input type="number" name="batch_size" value="<?php echo esc_attr( $s['batch_size'] ); ?>" min="1" max="500" dir="ltr">
				<small><?php esc_html_e( 'cron هر ۳۰ دقیقه اجرا می‌شود.', 'farazsms' ); ?></small>
			</label>

			<div class="farazsms-setting-wide" style="grid-column:1/-1;">
				<?php
				$ab_msg = trim( (string) ( $s['message'] ?? '' ) ) !== '' ? $s['message'] : ( farazsms_autobuild_default_messages()['abandoned']);
				farazsms_feature_pattern_builder_ui( 'abandoned', $ab_msg, array( '%first_name%', '%full_name%', '%total_price%', '%items_count%', '%resume_url%' ) );
				?>
			</div>

			<label class="farazsms-abandoned-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'کد الگوی پیامک یادآوری *', 'farazsms' ); ?></span>
				<input type="text" name="pattern_code" value="<?php echo esc_attr( $s['pattern_code'] ); ?>" dir="ltr">
				<small class="farazsms-abandoned-help">
					<?php esc_html_e( 'با دکمه‌ی «ساخت پترن» بالا خودکار پر می‌شود. متغیرها:', 'farazsms' ); ?>
					<code dir="ltr">%first_name%</code>
					<code dir="ltr">%full_name%</code>
					<code dir="ltr">%total_price%</code>
					<code dir="ltr">%items_count%</code>
					<code dir="ltr">%resume_url%</code>
				</small>
			</label>
		</div>

		<div class="farazsms-abandoned-save-row">
			<button type="submit" class="button button-primary"><?php esc_html_e( 'ذخیره تنظیمات', 'farazsms' ); ?></button>
		</div>
	</form>
	<?php
	// v3.21.58: انتخابِ روشِ ارسالِ لینک (کوتاه‌کننده/سایتِ اصلی) — بیرونِ فرمِ بالا.
	farazsms_shortener_render_choice( 'abandoned', 'سبد خرید رهاشده' );
}

function farazsms_abandoned_render_inline() {
	$nonce = wp_create_nonce( 'farazsms_abandoned_admin' );
	?>
	<style>
	.farazsms-abandoned-wrapper .farazsms-abandoned-title-main { margin: 16px 0 8px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-tabs { display: flex; gap: 6px; border-bottom: 2px solid #e5e7eb; margin: 16px 0 22px; flex-wrap: wrap; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-tab { padding: 10px 18px; text-decoration: none; color: #64748b; background: none; border: none; border-bottom: 2px solid transparent; margin-bottom: -2px; font-size: 13.5px; font-weight: 600; transition: color .15s, border-color .15s; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-tab:hover { color: #365891; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-tab.is-active { color: #365891; font-weight: 700; border-bottom-color: #365891; background: none; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-range-bar { display: flex; gap: 6px; margin-bottom: 16px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-range { padding: 6px 14px; background: #fff; border: 1px solid #d1d5db; border-radius: 6px; color: #4b5563; text-decoration: none; font-size: 13px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-range.is-active { background: #4571ba; color: #fff; border-color: #4571ba; font-weight: 600; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin: 0 0 16px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-stat { background: #fff; padding: 16px; border: 1px solid #e5e7eb; border-radius: 8px; text-align: center; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-stat .num { font-size: 26px; font-weight: 700; line-height: 1; color: #1f2937; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-stat .num.farazsms-num-success { color: #047857; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-stat .num.farazsms-num-info { color: #1d4ed8; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-stat .num.farazsms-num-warning { color: #b45309; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-stat .num.farazsms-num-muted { color: #6b7280; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-stat .lbl { color: #6b7280; font-size: 12px; margin-top: 6px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-value-card { background: #fff; padding: 18px 22px; border: 1px solid #e5e7eb; border-radius: 10px; margin: 16px 0; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-value-card h3 { margin: 0 0 12px; font-size: 14px; color: #1f2937; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-value-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
	.farazsms-abandoned-wrapper .farazsms-value-num { font-size: 22px; font-weight: 700; color: #047857; }
	.farazsms-abandoned-wrapper .farazsms-value-num-muted { color: #6b7280; }
	.farazsms-abandoned-wrapper .farazsms-value-lbl { color: #6b7280; font-size: 12px; margin-top: 4px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-cron-card { background: #f9fafb; padding: 12px 16px; border: 1px solid #e5e7eb; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; gap: 12px; flex-wrap: wrap; margin: 16px 0; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-cron-card code { background: #fff; padding: 2px 6px; border-radius: 4px; direction: ltr; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-filters { background: #fff; padding: 14px 16px; border: 1px solid #dcdcde; border-radius: 8px; margin: 0 0 14px; display: flex; flex-wrap: wrap; gap: 12px; align-items: end; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-filters label { display: flex; flex-direction: column; gap: 4px; font-size: 12px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-bulk-bar { margin: 0 0 10px; display: flex; align-items: center; gap: 10px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-table th,
	.farazsms-abandoned-wrapper .farazsms-abandoned-table td { padding: 10px 12px; vertical-align: middle; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-date-cell { direction: ltr; font-variant-numeric: tabular-nums; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-pagination { display: flex; gap: 8px; align-items: center; }
	.farazsms-abandoned-wrapper .farazsms-status { display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: 12px; }
	.farazsms-abandoned-wrapper .farazsms-status-success { background: #d1f5e0; color: #006d28; }
	.farazsms-abandoned-wrapper .farazsms-status-warning { background: #fef3c7; color: #92400e; }
	.farazsms-abandoned-wrapper .farazsms-status-info { background: #dbe9ff; color: #134a99; }
	.farazsms-abandoned-wrapper .farazsms-status-muted { background: #e0e0e0; color: #50575e; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-card { background: #fff; padding: 20px 24px; border: 1px solid #e5e7eb; border-radius: 10px; max-width: 760px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-card h2 { margin: 0 0 12px; font-size: 16px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-settings-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px 18px; margin: 12px 0 20px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-setting { display: flex; flex-direction: column; gap: 4px; font-size: 13px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-setting.farazsms-setting-wide { grid-column: 1 / -1; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-setting input { padding: 8px 10px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-setting small { color: #6b7280; font-size: 11px; margin-top: 4px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-help code { background: #f3f4f6; padding: 1px 5px; border-radius: 3px; margin: 0 2px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-switch { display: inline-flex; align-items: center; gap: 8px; font-size: 13px; }
	.farazsms-abandoned-wrapper .farazsms-abandoned-save-row { margin-top: 10px; }
	@media (max-width: 720px) {
		.farazsms-abandoned-wrapper .farazsms-abandoned-stats { grid-template-columns: repeat(2, 1fr); }
		.farazsms-abandoned-wrapper .farazsms-abandoned-settings-grid { grid-template-columns: 1fr; }
		.farazsms-abandoned-wrapper .farazsms-abandoned-value-row { grid-template-columns: 1fr; }
	}
	</style>
	<script>
	(function(){
		var ajaxUrl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
		var nonce   = <?php echo wp_json_encode( $nonce ); ?>;
		var selAll  = document.getElementById('farazsms-abandoned-select-all');
		var rows    = document.querySelectorAll('.farazsms-abandoned-row');
		var delBtn  = document.querySelector('.farazsms-abandoned-bulk-delete');
		var info    = document.querySelector('.farazsms-abandoned-bulk-info');
		function upd(){
			var c = Array.prototype.filter.call(rows, function(x){ return x.checked; });
			if (delBtn) {
				delBtn.disabled = c.length === 0;
				if (info) info.textContent = c.length ? (c.length + ' ردیف انتخاب شده') : '';
			}
		}
		if (selAll) selAll.addEventListener('change', function(){
			Array.prototype.forEach.call(rows, function(x){ x.checked = selAll.checked; });
			upd();
		});
		Array.prototype.forEach.call(rows, function(x){ x.addEventListener('change', upd); });
		if (delBtn) delBtn.addEventListener('click', function(){
			var c = Array.prototype.filter.call(rows, function(x){ return x.checked; });
			if (c.length === 0) return;
			if (!confirm('حذف ' + c.length + ' ردیف — مطمئن هستید؟')) return;
			var fd = new FormData();
			fd.append('action', 'farazsms_abandoned_delete');
			fd.append('nonce', nonce);
			c.forEach(function(x){ fd.append('ids[]', x.value); });
			delBtn.disabled = true;
			fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
				.then(function(r){ return r.json(); })
				.then(function(json){
					if (json.success) window.location.reload();
					else { alert((json.data && json.data.message) || 'خطا.'); delBtn.disabled = false; }
				})
				.catch(function(){ alert('خطا.'); delBtn.disabled = false; });
		});
	})();
	</script>
	<?php
}
