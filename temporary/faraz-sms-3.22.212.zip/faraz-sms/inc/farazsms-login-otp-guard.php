<?php
/**
 * گاردِ ضدِ رباتِ کدِ ورود (OTP) — دفاعِ نامرئیِ صفر-اصطکاک + تورِ ایمنیِ خاموش.
 *
 * مسیرِ ارسالِ کدِ ورود/ثبت‌نام محافظتِ ضعیفی داشت؛ رباتی که شماره را عوض می‌کند شارژِ
 * پیامکیِ سایت را خالی می‌کرد. این گارد پیش از ارسالِ SMS اجرا می‌شود: هانی‌پات، توکنِ
 * HMACِ زمان‌دار (+ time-gate)، هیوریستیکِ شماره، و سقف‌های per-number/per-IP/سراسری.
 *
 * اصلِ طراحی: هرگز ورودِ کاربرِ واقعی را نشکن. پیش‌فرض‌ها fail-open و سخاوتمندند؛
 * per-IP پیش‌فرض خاموش است (روی هاست‌های پشتِ پروکسی، REMOTE_ADDR همه‌ی کاربران را
 * در یک سطل می‌ریزد → قفلِ سراسری). ثابتِ FARAZSMS_DISABLE_LOGIN_LIMITS کلِ گارد را
 * خاموش می‌کند (راهِ فرارِ همیشه‌دردسترس). همه داخلی/آفلاین — بدونِ تماسِ خارجی/کپچا.
 *
 * @package FarazSMS
 * @since 3.22.68
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * تنظیمات + پیش‌فرض‌های سخاوتمند (فقط در هجومِ واقعی فعال می‌شوند).
 *
 * @return array
 */
function farazsms_login_limits_settings() {
	$defaults = array(
		'enabled'          => '1',  // کلِ گارد (پیش‌فرض روشن).
		'require_token'    => '1',  // هانی‌پات + توکنِ HMAC + time-gate.
		'token_strict'     => '0',  // اگر '1': نبود/نامعتبریِ توکن هم بلاک شود (opt-in، پس از تأیید).
		'min_seconds'      => 0,    // time-gate. پیش‌فرض ۰ = خاموش (ورودِ سریع/autofill نشکند).
		'number_heuristic' => '1',  // ردِ شماره‌های آشکارا جعلی (فقط «۰۹ + ۹ رقمِ یکسان»).
		'per_number_max'   => 5,    // حداکثر کد در پنجره، برای هر شماره.
		'per_number_win'   => 900,  // پنجره‌ی per-number (۱۵ دقیقه) — بلاک زود آزاد می‌شود.
		'per_ip_max'       => 0,    // per-IP روزانه. پیش‌فرض ۰ = خاموش (خطرِ پروکسی). opt-in.
		'global_max'       => 500,  // سقفِ سراسریِ سایت در ساعت — backstopِ کیفِ پول (بالا تا پیکِ فروش را نبندد).
		'admin_alert'      => '1',  // پیامک/لاگِ آنومالی به ادمین.
	);
	$saved = get_option( 'farazsms_login_limits', array() );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
}

/**
 * @return bool
 */
function farazsms_login_limits_enabled() {
	if ( defined( 'FARAZSMS_DISABLE_LOGIN_LIMITS' ) && FARAZSMS_DISABLE_LOGIN_LIMITS ) {
		return false; // راهِ فرارِ همیشه‌دردسترس (wp-config) اگر UI در دسترس نبود.
	}
	$s = farazsms_login_limits_settings();
	return $s['enabled'] === '1';
}

// ============================================================================
// توکنِ HMACِ زمان‌دار (بدونِ تماسِ خارجی)
// ============================================================================

/**
 * توکنِ تازه برای درجِ در فرم. رباتی که فرم را رندر نکرده این را ندارد.
 *
 * @return string "<ts>.<sig32>"
 */
function farazsms_login_otp_token_new() {
	$ts  = time();
	$sig = substr( hash_hmac( 'sha256', $ts . '|farazsms-otp', wp_salt( 'auth' ) ), 0, 32 );
	return $ts . '.' . $sig;
}

/**
 * سنِ توکن (ثانیه، ممکن است به‌خاطرِ اختلافِ ساعتِ نودها منفی شود) اگر HMAC معتبر باشد؛
 * وگرنه false. سقفِ عمر عمداً نمی‌گذاریم تا فرمِ کش‌شده کاربرِ واقعی را نشکند.
 *
 * @param string $tok
 * @return int|false
 */
function farazsms_login_otp_token_age( $tok ) {
	if ( ! is_string( $tok ) || strpos( $tok, '.' ) === false ) {
		return false;
	}
	list( $ts, $sig ) = explode( '.', $tok, 2 );
	if ( ! ctype_digit( (string) $ts ) ) {
		return false;
	}
	$expect = substr( hash_hmac( 'sha256', $ts . '|farazsms-otp', wp_salt( 'auth' ) ), 0, 32 );
	if ( ! hash_equals( $expect, (string) $sig ) ) {
		return false;
	}
	return time() - (int) $ts;
}

/**
 * هیوریستیکِ محافظه‌کارانه — فقط «۰۹ + ۹ رقمِ کاملاً یکسان» (09111111111). عمداً الگوی
 * «۸ صفرِ پشت‌سرهم» را برداشتیم چون شماره‌های VIP واقعی (09100000000) را رد می‌کرد.
 *
 * @param string $mobile شماره‌ی نرمالِ 09xxxxxxxxx.
 * @return bool
 */
function farazsms_login_number_looks_fake( $mobile ) {
	$d = preg_replace( '/\D/', '', (string) $mobile );
	if ( strlen( $d ) !== 11 ) {
		return false;
	}
	$rest = substr( $d, 2 ); // ۹ رقمِ بعد از «09».
	return (bool) preg_match( '/^(\d)\1{8}$/', $rest );
}

// ============================================================================
// کلیدهای سطلِ زمانی (window انکرشده — TTL هر بار refresh نمی‌شود)
// ============================================================================

/**
 * کلیدِ سطلِ ثابت‌پنجره: هر پنجره یک کلیدِ جدا که خودش منقضی می‌شود → شمارنده واقعاً می‌چرخد.
 *
 * @param string $prefix
 * @param string $id
 * @param int    $win ثانیه.
 * @return string
 */
function farazsms_login_limits_bucket_key( $prefix, $id, $win ) {
	$win    = max( 1, (int) $win );
	$bucket = (int) floor( time() / $win );
	return $prefix . md5( (string) $id ) . '_' . $bucket;
}

// ============================================================================
// گاردِ اصلی
// ============================================================================

/**
 * همه‌ی گاردها را پیش از ارسالِ کدِ ورود اجرا می‌کند. با شماره‌ی نرمالِ 09xxxxxxxxx.
 *
 * @param string $identifier
 * @param string $context 'login' | 'forget' — مسیرِ فراموشیِ رمز فیلدِ توکن/هانی‌پات ندارد، پس آن لایه skip می‌شود.
 * @return array {allowed:bool, message:string, reason:string}
 */
function farazsms_login_otp_guard( $identifier, $context = 'login' ) {
	if ( ! farazsms_login_limits_enabled() ) {
		return array( 'allowed' => true, 'message' => '', 'reason' => 'disabled' );
	}
	$s = farazsms_login_limits_settings();

	$generic = __( 'در حال حاضر امکان ارسالِ کد نیست. لطفاً کمی بعد دوباره تلاش کنید.', 'farazsms' );
	$wait    = __( 'برای این شماره چند کد ارسال شده؛ لطفاً چند دقیقه صبر کنید و دوباره تلاش کنید.', 'farazsms' );

	// داده‌های فرم (login.js با serialize می‌فرستد).
	$p = array();
	if ( isset( $_POST['data'] ) ) {
		parse_str( (string) wp_unslash( $_POST['data'] ), $p ); // phpcs:ignore WordPress.Security.NonceVerification.Missing — nonce در هندلر چک شده.
	}

	// per-number را زود حساب می‌کنیم تا برای «resendِ امن در حالتِ strict» هم لازم شود.
	$nwin   = (int) $s['per_number_win'];
	$nkey   = farazsms_login_limits_bucket_key( 'farazsms_lg_num_', $identifier, $nwin );
	$ncount = (int) get_transient( $nkey );

	// لایه‌ی نامرئی (هانی‌پات + توکن) فقط وقتی require_token روشن است → قابلِ خاموش‌کردن.
	// مسیرِ فراموشیِ رمز فیلدهای توکن/هانی‌پات را ندارد؛ در حالتِ strict نباید کاربرِ واقعی را ببندد.
	if ( '1' === $s['require_token'] && 'forget' !== $context ) {
		// ۱) هانی‌پات — کاربرِ واقعی خالی می‌گذارد.
		if ( isset( $p['farazsms_hp'] ) && trim( (string) $p['farazsms_hp'] ) !== '' ) {
			return array( 'allowed' => false, 'message' => $generic, 'reason' => 'honeypot' );
		}

		// ۲) توکن + time-gate (fail-safe).
		$tok = isset( $p['farazsms_tok'] ) ? (string) $p['farazsms_tok'] : '';
		if ( '' === $tok ) {
			// نبودِ توکن: در حالتِ strict بلاک — مگر ادامه‌ی همان جریان باشد (قبلاً پاس شده).
			if ( '1' === $s['token_strict'] && $ncount <= 0 ) {
				return array( 'allowed' => false, 'message' => $generic, 'reason' => 'token_missing' );
			}
		} else {
			$age = farazsms_login_otp_token_age( $tok );
			if ( false === $age ) {
				// توکنِ نامعتبر/دستکاری‌شده: فقط در strict بلاک (وگرنه چرخشِ saltِ فرمِ کش‌شده را نشکن).
				if ( '1' === $s['token_strict'] ) {
					return array( 'allowed' => false, 'message' => $generic, 'reason' => 'token' );
				}
			} elseif ( (int) $s['min_seconds'] > 0 && $age >= 0 && $age < (int) $s['min_seconds'] ) {
				return array( 'allowed' => false, 'message' => $generic, 'reason' => 'too_fast' );
			}
		}
	}

	// ۳) هیوریستیکِ شماره‌ی جعلی.
	if ( '1' === $s['number_heuristic'] && farazsms_login_number_looks_fake( $identifier ) ) {
		return array( 'allowed' => false, 'message' => $generic, 'reason' => 'fake_number' );
	}

	// ۴) per-number.
	if ( $ncount >= (int) $s['per_number_max'] ) {
		return array( 'allowed' => false, 'message' => $wait, 'reason' => 'per_number' );
	}

	// ۵) per-IP روزانه — فقط اگر روشن (>0) و IP قابلِ‌اعتماد باشد (پیش‌فرض خاموش به‌خاطرِ پروکسی).
	$ipkey = '';
	if ( (int) $s['per_ip_max'] > 0 ) {
		$ip = farazsms_rate_limit_client_ip();
		if ( $ip !== '' && $ip !== '0.0.0.0' ) {
			$ipkey   = farazsms_login_limits_bucket_key( 'farazsms_lg_ip_', $ip, DAY_IN_SECONDS );
			$ipcount = (int) get_transient( $ipkey );
			if ( $ipcount >= (int) $s['per_ip_max'] ) {
				return array( 'allowed' => false, 'message' => $generic, 'reason' => 'per_ip' );
			}
		}
	}

	// ۶) سقفِ سراسریِ ساعتی — backstopِ کیفِ پول.
	$gkey   = farazsms_login_limits_bucket_key( 'farazsms_lg_global_', 'site', HOUR_IN_SECONDS );
	$gcount = (int) get_transient( $gkey );
	if ( $gcount >= (int) $s['global_max'] ) {
		farazsms_login_limits_maybe_alert_admin( $gcount );
		return array( 'allowed' => false, 'message' => $generic, 'reason' => 'global' );
	}

	// همه پاس شد → شمارنده‌ها را زیاد کن (TTL = طولِ پنجره؛ کلیدِ سطلی خودش می‌چرخد).
	set_transient( $nkey, $ncount + 1, $nwin );
	if ( $ipkey !== '' ) {
		set_transient( $ipkey, (int) get_transient( $ipkey ) + 1, DAY_IN_SECONDS );
	}
	set_transient( $gkey, $gcount + 1, HOUR_IN_SECONDS );

	return array( 'allowed' => true, 'message' => '', 'reason' => 'ok' );
}

/**
 * برگرداندنِ شمارنده‌ها وقتی ارسالِ پیامک «قطعاً» شکست خورد (نه timeout) — تا خطاهای ارسال،
 * بودجه/سقفِ کاربرانِ مجاز را نسوزانند و قطعیِ فراز سایت را قفل نکند.
 *
 * @param string $identifier
 * @return void
 */
function farazsms_login_otp_guard_refund( $identifier ) {
	if ( ! farazsms_login_limits_enabled() ) {
		return;
	}
	$s   = farazsms_login_limits_settings();
	$dec = function ( $key, $ttl ) {
		$c = (int) get_transient( $key );
		if ( $c > 0 ) {
			set_transient( $key, $c - 1, $ttl );
		}
	};
	$nwin = (int) $s['per_number_win'];
	$dec( farazsms_login_limits_bucket_key( 'farazsms_lg_num_', $identifier, $nwin ), $nwin );
	$dec( farazsms_login_limits_bucket_key( 'farazsms_lg_global_', 'site', HOUR_IN_SECONDS ), HOUR_IN_SECONDS );
	if ( (int) $s['per_ip_max'] > 0 ) {
		$ip = farazsms_rate_limit_client_ip();
		if ( $ip !== '' && $ip !== '0.0.0.0' ) {
			$dec( farazsms_login_limits_bucket_key( 'farazsms_lg_ip_', $ip, DAY_IN_SECONDS ), DAY_IN_SECONDS );
		}
	}
}

/**
 * آنومالی → یک‌بار در هر ساعت به ادمین اطلاع بده (لاگِ تشخیص + پیامکِ ساده‌ی best-effort).
 *
 * @param int $count
 * @return void
 */
function farazsms_login_limits_maybe_alert_admin( $count ) {
	$s = farazsms_login_limits_settings();
	if ( '1' !== $s['admin_alert'] ) {
		return;
	}
	if ( get_transient( 'farazsms_lg_alerted' ) ) {
		return; // یک‌بار در پنجره.
	}
	set_transient( 'farazsms_lg_alerted', 1, HOUR_IN_SECONDS );

	$msg = 'هشدارِ فراز: نرخِ درخواستِ کدِ ورود غیرعادی شد (سقفِ ساعتی پر شد). ارسالِ کد موقتاً محدود شد تا شارژ حفظ شود.';
	farazsms_send_diag_log( '-', 'login_otp_flood', 'blocked', array( 'msg' => $msg, 'count' => (int) $count ) );

	try {
		$phones = farazsms_updates_admin_phones();
		foreach ( (array) $phones as $phone ) {
			if ( $phone ) {
				farazsms_sms_send_simple( $phone, $msg );
			}
		}
	} catch ( \Throwable $e ) {
		farazsms_send_diag_log( '-', 'login_otp_flood_alert', 'error', array( 'err' => $e->getMessage() ) );
	}
}
