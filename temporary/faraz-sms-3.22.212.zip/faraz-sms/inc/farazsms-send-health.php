<?php
/**
 * سلامتِ ارسال — یک پاسخِ واحد به «آیا پیامک‌ها دارند می‌روند؟»
 *
 * ⚠️ چرا این فایل هست (ریشه‌یابیِ ۱۴۰۵/۰۶/۱۶):
 *
 * افزونه نتیجه‌ی هر ارسال را در جدولِ تشخیص می‌نویسد، ولی تجمیعِ آن **داخلِ
 * تابعِ رندرِ همان صفحه** بود. یعنی دانشِ خرابی وجود داشت و پشتِ یک بازدیدِ
 * صفحه حبس بود؛ و کسی آن صفحه را باز نمی‌کند. نتیجه در عمل:
 *
 *   • پیامکِ اطلاعِ به‌روزرسانی یازده بار در روز با ۴۰۰ رد شد — ماه‌ها.
 *   • واردسازیِ دفترچه «۲۰۰/موفق» می‌گرفت و صفر مخاطب وارد می‌کرد.
 *
 * هر دو در لاگ بودند. هیچ‌کدام به آدمی نرسید. این ماژول همان مسیرِ نبوده را
 * می‌سازد: از دادهٔ موجود یک حکم می‌گیرد، بدونِ اینکه کسی جایی را باز کند
 * نشانش می‌دهد، و اگر ادامه داشت **ایمیل** می‌زند — چون وقتی پیامک خراب است،
 * پیامک کانالِ خبردادن نیست.
 *
 * منبعِ داده تازه ساخته نمی‌شود: همان جدولِ تشخیص. حکم هم یکی است، نه یکی
 * برای هر قابلیت.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/** کمینه‌ی تلاش در پنجره تا حکم معنا داشته باشد (یک شکستِ تنها، خرابی نیست). */
const FARAZSMS_HEALTH_MIN_ATTEMPTS = 5;

/** از این نسبتِ شکست به بالا: خراب. */
const FARAZSMS_HEALTH_DOWN_RATIO = 0.5;

/** از این نسبت به بالا: نیمه‌خراب. */
const FARAZSMS_HEALTH_DEGRADED_RATIO = 0.2;

/**
 * وضعیت‌هایی که «تلاش کردیم و شکست خورد» یعنی — و فقط همین‌ها زنگ می‌زنند.
 *
 * ⚠️ `invalid_mobile` شماره‌ی بدِ مشتری است نه خرابیِ ما، و `queued` اصلاً
 * شکست نیست. شمردنشان یعنی هشدارِ قرمز برای چیزی که فروشنده کاری‌اش ندارد —
 * و هشدارِ کاذب همان چیزی است که آدم‌ها را عادت می‌دهد نادیده بگیرند.
 */
const FARAZSMS_HEALTH_FAILURE_STATUSES = "'api_error','curl_error','failed','not_sent'";

/** هوکِ کرونِ دیده‌بان — تا وابسته به ورودِ مدیر نباشد. */
const FARAZSMS_HEALTH_CRON_HOOK = 'farazsms_send_health_check';

/** هوکِ ارسالِ ایمیل — خارج از درخواستِ کاربر. */
const FARAZSMS_HEALTH_MAIL_HOOK = 'farazsms_send_health_mail';

/** آپشنِ حادثه‌ی باز (تا وقتی سلامت برنگردد). */
const FARAZSMS_HEALTH_INCIDENT_OPTION = 'farazsms_send_health_incident';

/**
 * تجمیعِ نتیجه‌ی ارسال‌ها در پنجره‌ی گذشته.
 *
 * ⚠️ «در صف» شکست نیست و در عددِ ناموفق نمی‌آید — همان قاعده‌ای که صفحه‌ی
 * تشخیص از ابتدا داشت. این تابع تنها تعریفِ آن تجمیع است؛ صفحه هم از همین
 * می‌خوانَد تا دو عدد برای یک حقیقت وجود نداشته باشد.
 *
 * @param int $hours پنجره‌ی زمانی.
 * @return array{total:int,ok:int,bad:int,queued:int,since:string}
 */
function farazsms_send_health_totals( $hours = 24 ) {
	global $wpdb;
	// ⚠️ کلیدِ `known` تفاوتِ «هیچ شکستی نبود» با «نتوانستیم بفهمیم» را نگه
	// می‌دارد. بدونِ آن، جدولِ ساخته‌نشده «سالم» خوانده می‌شد و دیده‌بان برای
	// همیشه بی‌صدا می‌مانْد — یعنی همان خرابیِ خاموشی که برایش ساخته شده.
	$empty = array( 'total' => 0, 'ok' => 0, 'bad' => 0, 'queued' => 0, 'since' => '', 'known' => false );

	if ( ! function_exists( 'farazsms_send_diag_table' ) ) {
		return $empty;
	}
	$table = farazsms_send_diag_table();
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
		return $empty;
	}

	$since = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - ( (int) $hours * HOUR_IN_SECONDS ) );
	$row   = $wpdb->get_row( $wpdb->prepare(
		"SELECT COUNT(*) total,
		        SUM(status='success') ok,
		        SUM(status IN (" . FARAZSMS_HEALTH_FAILURE_STATUSES . ")) bad,
		        SUM(status='queued') queued
		 FROM $table WHERE created_at >= %s",
		$since
	), ARRAY_A );

	return array(
		'total'  => (int) ( $row['total'] ?? 0 ),
		'ok'     => (int) ( $row['ok'] ?? 0 ),
		'bad'    => (int) ( $row['bad'] ?? 0 ),
		'queued' => (int) ( $row['queued'] ?? 0 ),
		'since'  => $since,
		'known'  => true,
	);
}

/**
 * پرتکرارترین علتِ شکست در پنجره — چیزی که باید به آدم گفته شود.
 *
 * @param int $hours
 * @return array{status:string,source:string,error:string,count:int}|null
 */
function farazsms_send_health_top_failure( $hours = 24 ) {
	global $wpdb;
	if ( ! function_exists( 'farazsms_send_diag_table' ) ) {
		return null;
	}
	$table = farazsms_send_diag_table();
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
		return null;
	}
	$since = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - ( (int) $hours * HOUR_IN_SECONDS ) );
	$row   = $wpdb->get_row( $wpdb->prepare(
		"SELECT status, source, error, COUNT(*) c
		 FROM $table
		 WHERE created_at >= %s AND status IN (" . FARAZSMS_HEALTH_FAILURE_STATUSES . ")
		 GROUP BY status, source, error
		 ORDER BY c DESC LIMIT 1",
		$since
	), ARRAY_A );

	return $row ? array(
		'status' => (string) ( $row['status'] ?? '' ),
		'source' => (string) ( $row['source'] ?? '' ),
		'error'  => (string) ( $row['error'] ?? '' ),
		'count'  => (int) ( $row['c'] ?? 0 ),
	) : null;
}

/**
 * تجمیع به تفکیکِ **منبع** — قابلیتی که خراب است، نه کلِ سایت.
 *
 * ⚠️ چرا این لازم است (بازبینیِ ۱۴۰۵/۰۶/۱۶): نسبتِ کلِ سایت دقیقاً همان
 * موردی را که این ماژول برایش ساخته شد نمی‌گیرد. پیامکِ اطلاعِ به‌روزرسانی
 * روزی یازده بار شکست می‌خورد، ولی همان سایت صدها پیامکِ سفارشِ موفق داشت؛
 * نسبتِ کلی حدودِ چند درصد می‌ماند و حکم «سالم» می‌شد. یک قابلیتِ کاملاً مرده
 * باید دیده شود حتی وقتی بقیه سالم‌اند.
 *
 * @param int $hours
 * @return array<int,array{source:string,ok:int,bad:int}>
 */
function farazsms_send_health_by_source( $hours = 24 ) {
	global $wpdb;
	if ( ! function_exists( 'farazsms_send_diag_table' ) ) {
		return array();
	}
	$table = farazsms_send_diag_table();
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) !== $table ) {
		return array();
	}
	$since = gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) - ( (int) $hours * HOUR_IN_SECONDS ) );
	$rows  = $wpdb->get_results( $wpdb->prepare(
		"SELECT source,
		        SUM(status='success') ok,
		        SUM(status IN (" . FARAZSMS_HEALTH_FAILURE_STATUSES . ")) bad
		 FROM $table WHERE created_at >= %s
		 GROUP BY source",
		$since
	), ARRAY_A );

	$out = array();
	foreach ( (array) $rows as $r ) {
		$out[] = array(
			'source' => (string) ( $r['source'] ?? '' ),
			'ok'     => (int) ( $r['ok'] ?? 0 ),
			'bad'    => (int) ( $r['bad'] ?? 0 ),
		);
	}
	return $out;
}

/**
 * قابلیتی که به‌تنهایی خراب است (اگر باشد).
 *
 * @param array $sources
 * @return array{source:string,ok:int,bad:int}|null
 */
function farazsms_send_health_broken_source( array $sources ) {
	$worst = null;
	foreach ( $sources as $row ) {
		$attempts = $row['ok'] + $row['bad'];
		if ( $attempts < FARAZSMS_HEALTH_MIN_ATTEMPTS || $row['bad'] < FARAZSMS_HEALTH_MIN_ATTEMPTS ) {
			continue;
		}
		if ( ( $row['bad'] / $attempts ) < FARAZSMS_HEALTH_DOWN_RATIO ) {
			continue;
		}
		if ( $worst === null || $row['bad'] > $worst['bad'] ) {
			$worst = $row;
		}
	}
	return $worst;
}

/**
 * حکمِ واحد: ارسال سالم است، نیمه‌خراب، یا خراب.
 *
 * ⚠️ نگهبانِ اتصال **بلعیده** می‌شود، نه موازی‌سازی: اگر درخواست‌های خروجی
 * مسدود باشند، تشخیصِ درست همان است و نباید دو پاسخِ متفاوت به یک پرسش وجود
 * داشته باشد.
 *
 * @param int $hours
 * @return array{state:string,reason:string,detail:string,totals:array,top:array|null}
 */
function farazsms_send_health_verdict( $hours = 24 ) {
	$totals = farazsms_send_health_totals( $hours );
	$top    = farazsms_send_health_top_failure( $hours );

	// نگهبانِ اتصال ممکن است اصلاً بار نشده باشد (فایلِ محافظت‌شده)؛ فیلتر هم
	// اجازه می‌دهد این تصمیم بدونِ آن ماژول آزموده شود.
	$blocked = function_exists( 'farazsms_connectivity_is_blocked' ) ? (bool) farazsms_connectivity_is_blocked() : false;
	if ( apply_filters( 'farazsms_test_connectivity_blocked', $blocked ) ) {
		return array(
			'state'  => 'down',
			'reason' => 'connectivity',
			'detail' => __( 'درخواست‌های خروجی به سرویسِ پیامک مسدود شده‌اند.', 'farazsms' ),
			'totals' => $totals,
			'top'    => $top,
		);
	}

	// ⚠️ یک قابلیتِ مرده باید دیده شود حتی وقتی کلِ سایت شلوغ و سالم است.
	$broken = farazsms_send_health_broken_source( farazsms_send_health_by_source( $hours ) );
	if ( $broken !== null ) {
		return array(
			'state'  => 'down',
			'reason' => $top ? $top['status'] : 'failed',
			'detail' => $top ? trim( $top['error'] ) : '',
			'totals' => $totals,
			'top'    => $top,
			'source' => $broken['source'],
		);
	}

	$attempts = $totals['ok'] + $totals['bad'];
	if ( ! $totals['known'] || $attempts < FARAZSMS_HEALTH_MIN_ATTEMPTS ) {
		// ⚠️ «نامعلوم» است، نه «سالم». تفاوتشان این است که نامعلوم حق ندارد
		// حادثه‌ی بازِ یک خرابیِ واقعی را ببندد — سایتی که خراب است ترافیکش
		// هم می‌افتد، و با «سالم»خواندنِ آن، هشدار وسطِ خرابی پاک می‌شد.
		return array( 'state' => 'unknown', 'reason' => 'insufficient_data', 'detail' => '', 'totals' => $totals, 'top' => $top );
	}

	$ratio = $totals['bad'] / $attempts;
	if ( $ratio >= FARAZSMS_HEALTH_DOWN_RATIO ) {
		$state = 'down';
	} elseif ( $ratio >= FARAZSMS_HEALTH_DEGRADED_RATIO ) {
		$state = 'degraded';
	} else {
		return array( 'state' => 'ok', 'reason' => '', 'detail' => '', 'totals' => $totals, 'top' => $top );
	}

	return array(
		'state'  => $state,
		'reason' => $top ? $top['status'] : 'failed',
		'detail' => $top ? trim( $top['error'] ) : '',
		'totals' => $totals,
		'top'    => $top,
	);
}

/**
 * متنِ کوتاهِ قابلِ‌فهم برای یک حکم — همان جمله‌ای که به آدم گفته می‌شود.
 *
 * @param array $verdict
 * @return string
 */
function farazsms_send_health_message( $verdict ) {
	$totals = $verdict['totals'];
	$top    = $verdict['top'];

	if ( $verdict['reason'] === 'connectivity' ) {
		return __( 'ارسالِ پیامک متوقف است: درخواست‌های خروجیِ سایت به سرویسِ فراز مسدود شده‌اند.', 'farazsms' );
	}

	$base = sprintf(
		/* translators: 1: تعداد ناموفق 2: کل تلاش */
		__( 'از %2$s ارسالِ اخیر، %1$s تا ناموفق بوده است.', 'farazsms' ),
		number_format_i18n( $totals['bad'] ),
		number_format_i18n( $totals['ok'] + $totals['bad'] )
	);

	if ( $top && $top['error'] !== '' ) {
		$base .= ' ' . sprintf(
			/* translators: 1: علتِ پرتکرار */
			__( 'پرتکرارترین علت: «%s».', 'farazsms' ),
			wp_strip_all_tags( $top['error'] )
		);
	}
	return $base;
}

/**
 * حکمِ کش‌شده — تا هر بازدیدِ پیشخوان یک کوئریِ تجمیعی نزند.
 *
 * @return array
 */
function farazsms_send_health_cached() {
	// ⚠️ شکلِ کش سنجیده می‌شود: پس از یک به‌روزرسانی ممکن است ردیفِ قدیمی با
	// کلیدهای دیگری در کش مانده باشد و مصرف‌کننده روی اندیسِ نبوده اخطار بدهد.
	$cached = get_transient( 'farazsms_send_health' );
	if ( is_array( $cached ) && isset( $cached['state'], $cached['totals'] ) ) {
		return $cached;
	}
	$verdict = farazsms_send_health_verdict();
	set_transient( 'farazsms_send_health', $verdict, 15 * MINUTE_IN_SECONDS );
	return $verdict;
}

add_action( 'admin_init', 'farazsms_send_health_watch', 30 );
add_action( FARAZSMS_HEALTH_CRON_HOOK, 'farazsms_send_health_watch' );
/**
 * دیده‌بان: حکم را می‌گیرد، حادثه را باز/بسته می‌کند و یک‌بار ایمیل می‌زند.
 *
 * ⚠️ روی کرون هم بسته است، نه فقط بازدیدِ پیشخوان. وگرنه دانش از «پشتِ یک
 * بازدیدِ صفحه» به «پشتِ ورودِ مدیر» منتقل می‌شد — همان مشکل با نامِ دیگر.
 *
 * @return void
 */
function farazsms_send_health_watch() {
	// روی کرون کاربری وجود ندارد؛ گاردِ دسترسی فقط برای مسیرِ پیشخوان است.
	if ( ! wp_doing_cron() && ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$verdict  = farazsms_send_health_cached();
	$incident = get_option( FARAZSMS_HEALTH_INCIDENT_OPTION, array() );
	if ( ! is_array( $incident ) || empty( $incident['started_at'] ) ) {
		$incident = array();
	}

	if ( $verdict['state'] === 'ok' ) {
		// سلامت برگشت: حادثه بی‌سروصدا بسته می‌شود. «درست شد» خبرِ فوری نیست.
		if ( ! empty( $incident ) ) {
			delete_option( FARAZSMS_HEALTH_INCIDENT_OPTION );
			delete_transient( 'farazsms_send_health' );
		}
		return;
	}

	// ⚠️ «نامعلوم» نه حادثه می‌سازد نه حادثه‌ی باز را می‌بندد. سایتِ خراب
	// ترافیکش هم می‌افتد؛ بستنِ هشدار وسطِ خرابی بدترین کارِ ممکن است.
	if ( $verdict['state'] === 'unknown' ) {
		return;
	}

	$now = time();
	if ( empty( $incident ) ) {
		$incident = array( 'started_at' => $now, 'notified_at' => 0 );
	}
	// وضعیت و متن در هر تیک تازه می‌شوند (نیمه‌خراب می‌تواند خراب شود)؛ فقط
	// زمانِ شروع ثابت می‌مانَد تا شرطِ «ادامه‌دار بودن» معنا داشته باشد.
	$incident['state']   = $verdict['state'];
	$incident['reason']  = $verdict['reason'];
	$incident['message'] = farazsms_send_health_message( $verdict );
	update_option( FARAZSMS_HEALTH_INCIDENT_OPTION, $incident, false );

	// ایمیل: یک‌بار در هر حادثه، و فقط وقتی خرابی ادامه‌دار باشد — تا نوسانِ
	// گذرا سرِ صبح ایمیل نسازد. پرچم داخلِ خودِ حادثه است نه یک ترنزینتِ
	// جداگانه، وگرنه حادثه‌ی طولانی هفته‌ای یک‌بار دوباره ایمیل می‌زد.
	if ( $verdict['state'] === 'down'
		&& empty( $incident['notified_at'] )
		&& ( $now - (int) $incident['started_at'] ) >= HOUR_IN_SECONDS ) {

		// ⚠️ ارسالِ ایمیل روی درخواستِ پیشخوان انجام نمی‌شود: SMTPِ کند یا مرده
		// هر بارگذاریِ صفحه را معلق می‌کند — همان اشتباهی که پیامکِ گرویتی
		// می‌کرد و به ۵۰۳ رسید.
		//
		// ⚠️ و به کرونِ وردپرس هم سپرده نمی‌شود: تاریخِ همین افزونه می‌گوید روی
		// این هاست‌ها کرون قابل‌اتکا نیست (سه کچ‌آپِ جداگانه برای همین هست).
		// صفِ مشترک هم اجراکننده دارد، هم باقی‌مانده، هم کچ‌آپِ بازدیدِ پیشخوان.
		//
		// و «اطلاع داده شد» فقط پس از ارسالِ **واقعی** ثبت می‌شود؛ اگر این‌جا
		// ثبتش کنیم، سایتی که ایمیلش نمی‌رود هشدارِ نرفته را «رفته» می‌شمارد و
		// دیگر هرگز تلاش نمی‌کند.
		if ( empty( $incident['mail_queued_at'] ) || ( $now - (int) $incident['mail_queued_at'] ) > HOUR_IN_SECONDS ) {
			if ( function_exists( 'farazsms_queue_task' )
				&& farazsms_queue_task( 'health-alert', 'farazsms_send_health_send_mail' ) ) {
				$incident['mail_queued_at'] = $now;
				update_option( FARAZSMS_HEALTH_INCIDENT_OPTION, $incident, false );
			}
		}
	}
}

add_action( FARAZSMS_HEALTH_MAIL_HOOK, 'farazsms_send_health_send_mail' );
/**
 * ارسالِ ایمیلِ هشدار — خارج از درخواستِ کاربر.
 *
 * ⚠️ اگر ایمیل نرود، پرچمِ «اطلاع داده شد» پس گرفته می‌شود تا تلاشِ بعدی
 * ممکن بماند؛ وگرنه هشدارِ نرفته به‌عنوانِ رفته ثبت می‌شد.
 *
 * @return void
 */
function farazsms_send_health_send_mail() {
	$incident = get_option( FARAZSMS_HEALTH_INCIDENT_OPTION, array() );
	if ( ! is_array( $incident ) || empty( $incident['message'] ) ) {
		return;
	}
	$to = get_option( 'admin_email' );
	if ( ! $to ) {
		return;
	}
	if ( ! empty( $incident['notified_at'] ) ) {
		return; // این حادثه اطلاع‌رسانی شده؛ کارِ تکراریِ صف نباید دوباره بفرستد.
	}

	$sent = wp_mail(
		$to,
		sprintf( '[%s] پیامک‌های سایت ارسال نمی‌شوند', wp_specialchars_decode( get_bloginfo( 'name' ) ) ),
		(string) $incident['message'] . "\n\n"
		. 'جزئیات: ' . admin_url( 'admin.php?page=farazsms-diagnostics' ) . "\n"
		. 'این پیام یک‌بار در هر رویداد فرستاده می‌شود و با برطرف‌شدن مشکل، خودکار متوقف می‌گردد.'
	);

	// ⚠️ فقط ارسالِ موفق «اطلاع‌داده‌شده» می‌شود. شکست، پرچمِ صف را هم پس
	// می‌گیرد تا تیکِ بعدیِ دیده‌بان دوباره تلاش کند.
	if ( $sent ) {
		$incident['notified_at'] = time();
	} else {
		$incident['mail_queued_at'] = 0;
	}
	update_option( FARAZSMS_HEALTH_INCIDENT_OPTION, $incident, false );
}

add_action( 'admin_notices', 'farazsms_send_health_notice' );
/**
 * هشدار روی **همه‌ی** صفحه‌های پیشخوان، نه فقط صفحه‌های افزونه.
 *
 * ⚠️ عمداً سراسری: فروشنده در صفحه‌ی سفارش‌ها و محصولات زندگی می‌کند، نه در
 * صفحه‌ی تشخیصِ ما. گذاشتنِ هشدار فقط روی صفحه‌های خودمان یعنی همان حبسِ
 * دانش پشتِ یک بازدید، که کلِ این ماژول برای شکستنش نوشته شد.
 *
 * @return void
 */
function farazsms_send_health_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$incident = get_option( FARAZSMS_HEALTH_INCIDENT_OPTION, array() );
	if ( ! is_array( $incident ) || empty( $incident['message'] ) ) {
		return;
	}
	// ⚠️ قابلِ بستن، با خوابِ یک‌روزه: بنرِ قرمزِ همیشگی که نمی‌شود بستش،
	// دقیقاً همان چیزی است که فروشنده را عادت می‌دهد هشدارها را نبیند. حادثه
	// بسته نمی‌شود، فقط تا فردا نشان داده نمی‌شود.
	if ( (int) get_user_meta( get_current_user_id(), 'farazsms_health_snooze_until', true ) > time() ) {
		return;
	}
	$class = ( ( $incident['state'] ?? '' ) === 'down' ) ? 'notice-error' : 'notice-warning';
	$snooze = wp_nonce_url( add_query_arg( 'farazsms_health_snooze', '1' ), 'farazsms_health_snooze' );
	?>
	<div class="notice <?php echo esc_attr( $class ); ?> is-dismissible" style="direction:rtl;">
		<p>
			<strong>فراز اس ام اس:</strong>
			<?php echo esc_html( (string) $incident['message'] ); ?>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=farazsms-diagnostics' ) ); ?>">مشاهده‌ی جزئیات</a>
			<a href="<?php echo esc_url( $snooze ); ?>" style="margin-inline-start:10px;">تا فردا نشان نده</a>
		</p>
	</div>
	<?php
}

add_action( 'admin_init', 'farazsms_send_health_snooze', 31 );
/**
 * خواباندنِ یک‌روزه‌ی هشدار برای همین کاربر.
 *
 * ⚠️ حادثه بسته نمی‌شود و ایمیل هم لغو نمی‌گردد؛ فقط بنر تا فردا پنهان است.
 *
 * @return void
 */
function farazsms_send_health_snooze() {
	if ( empty( $_GET['farazsms_health_snooze'] ) || ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! isset( $_GET['_wpnonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'farazsms_health_snooze' ) ) {
		return;
	}
	update_user_meta( get_current_user_id(), 'farazsms_health_snooze_until', time() + DAY_IN_SECONDS );
}

add_action( 'init', 'farazsms_send_health_schedule' );
/**
 * زمان‌بندیِ دیده‌بان — تا خرابی وابسته به ورودِ مدیر نباشد.
 *
 * @return void
 */
function farazsms_send_health_schedule() {
	if ( ! wp_next_scheduled( FARAZSMS_HEALTH_CRON_HOOK ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', FARAZSMS_HEALTH_CRON_HOOK );
	}
}
