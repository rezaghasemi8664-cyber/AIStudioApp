<?php
/**
 * آمار با Matomo — دو هدف:
 *   ۱) آمار بازدید سایت (بازدید، صفحات پربازدید و…) با تزریقِ ردیابِ async مَتومو.
 *   ۲) آمار استفاده از قابلیت‌های افزونه با رویدادهای custom (سمتِ سرور، non-blocking).
 *
 * تنظیمات (آدرس مَتومو + Site ID) سطحِ شرکت است و یکی برای همه‌ی نصب‌ها:
 *   - اولویت با ثابت‌های FARAZSMS_MATOMO_URL و FARAZSMS_MATOMO_SITE_ID (برای bake توسطِ فراز)
 *   - سپس آپشن‌های farazsms_matomo_url / farazsms_matomo_site_id (برای تست توسطِ مدیر)
 *   - سپس فیلترهای farazsms_matomo_url / farazsms_matomo_site_id
 *
 * ردیابیِ بازدید پیش‌فرض روشن است؛ مدیرِ هر سایت می‌تواند خاموش کند
 * (آپشن farazsms_matomo_optout یا ثابتِ FARAZSMS_MATOMO_FORCE_OFF).
 *
 * معماری برای آینده: الان همه‌ی سایت‌ها در یک Site مشترک‌اند و با دامنه تفکیک
 * می‌شوند؛ با فیلترِ farazsms_matomo_site_id می‌توان در آینده با Matomo API برای هر
 * دامنه یک Site ID جدا برگرداند.
 *
 * کارایی: ردیابِ بازدید async است و رویدادهای سرور با blocking=false ارسال
 * می‌شوند تا سرعتِ سایت تحتِ تأثیر قرار نگیرد.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * آدرسِ پایه‌ی مَتومو (با اسلشِ پایانی).
 *
 * @return string
 */
function farazsms_matomo_url() {
	$url = '';
	if ( defined( 'FARAZSMS_MATOMO_URL' ) && FARAZSMS_MATOMO_URL ) {
		$url = FARAZSMS_MATOMO_URL;
	} else {
		$url = (string) get_option( 'farazsms_matomo_url', '' );
	}
	$url = (string) apply_filters( 'farazsms_matomo_url', $url );
	$url = trim( $url );
	return $url !== '' ? trailingslashit( $url ) : '';
}

/**
 * شناسه‌ی Site در مَتومو. (فیلتر برای تفکیکِ هر دامنه در آینده.)
 *
 * @return string
 */
function farazsms_matomo_site_id() {
	$id = '';
	if ( defined( 'FARAZSMS_MATOMO_SITE_ID' ) && FARAZSMS_MATOMO_SITE_ID ) {
		$id = FARAZSMS_MATOMO_SITE_ID;
	} else {
		$id = (string) get_option( 'farazsms_matomo_site_id', '' );
	}
	return trim( (string) apply_filters( 'farazsms_matomo_site_id', $id ) );
}

/**
 * آیا ردیابی فعال است؟ (پیکربندی موجود + خاموش‌نشده)
 *
 * @return bool
 */
function farazsms_matomo_is_enabled() {
	if ( defined( 'FARAZSMS_MATOMO_FORCE_OFF' ) && FARAZSMS_MATOMO_FORCE_OFF ) {
		return false;
	}
	if ( get_option( 'farazsms_matomo_optout', '0' ) === '1' ) {
		return false;
	}
	return farazsms_matomo_url() !== '' && farazsms_matomo_site_id() !== '';
}

/**
 * URLِ نقطه‌ی ردیابیِ HTTPِ مَتومو.
 *
 * @return string
 */
function farazsms_matomo_tracker_endpoint() {
	$file = (string) apply_filters( 'farazsms_matomo_tracker_file', 'matomo.php' );
	return farazsms_matomo_url() . ltrim( $file, '/' );
}

// ============================================================================
// ۱) آمار بازدید سایت — تزریقِ ردیابِ async در فرانت‌اند
// ============================================================================

add_action( 'wp_footer', 'farazsms_matomo_render_tracker', 99 );
function farazsms_matomo_render_tracker() {
	if ( ! farazsms_matomo_is_enabled() ) {
		return;
	}
	if ( ! (bool) apply_filters( 'farazsms_matomo_track_visitors', true ) ) {
		return;
	}
	if ( is_admin() ) {
		return;
	}
	$url     = farazsms_matomo_url();
	$site_id = farazsms_matomo_site_id();
	?>
	<!-- Faraz SMS · Matomo analytics (async) -->
	<script>
	var _paq = window._paq = window._paq || [];
	_paq.push(['trackPageView']);
	_paq.push(['enableLinkTracking']);
	(function() {
		var u = <?php echo wp_json_encode( $url ); ?>;
		_paq.push(['setTrackerUrl', u + 'matomo.php']);
		_paq.push(['setSiteId', <?php echo wp_json_encode( $site_id ); ?>]);
		// تزریقِ ردیاب فقط پس از کاملِ بارگذاریِ صفحه تا هیچ تأثیری روی سرعتِ
		// نمایشِ سایت برای بازدیدکننده نگذارد.
		function farazLoadMatomo() {
			var d = document, g = d.createElement('script'), s = d.getElementsByTagName('script')[0];
			// async + onerror بی‌اثر: اگر سرورِ متمو قطع/کند بود، فقط بی‌صدا لود نمی‌شود و
			// هیچ تأثیری روی سایتِ کاربر (سرعت یا خطا) ندارد.
			g.async = true; g.onerror = function(){}; g.src = u + 'matomo.js'; s.parentNode.insertBefore(g, s);
		}
		if (document.readyState === 'complete') { farazLoadMatomo(); }
		else { window.addEventListener('load', farazLoadMatomo); }
	})();
	</script>
	<?php
}

// ============================================================================
// ۲) آمار استفاده از قابلیت‌ها — رویدادهای custom سمتِ سرور
// ============================================================================

/**
 * (غیرفعال) رویدادِ سمتِ‌سرور.
 *
 * v3.20.56: تمامِ درخواست‌های HTTPِ سمتِ‌سرورِ مَتومو حذف شدند. این تماس‌ها روی
 * هر بارگذاریِ صفحه‌ی ادمین (و مسیرِ ارسالِ پیامک) اجرا می‌شدند و وقتی سرورِ آمار
 * کند/در دسترس نبود (مثلاً هنگامِ قطعیِ اینترنتِ بین‌الملل/اینترنتِ ملی)، باعثِ
 * کندیِ شدیدِ پیشخوان می‌شدند. حالا فقط ردیابِ JSِ async در فرانت باقی می‌ماند که
 * هیچ‌گاه چیزی را بلاک نمی‌کند و در صورتِ در دسترس نبودن، بی‌صدا نادیده گرفته می‌شود.
 *
 * این تابع برای سازگاریِ صدازننده‌ها نگه داشته شده اما کاری انجام نمی‌دهد.
 *
 * @param string   $category
 * @param string   $action
 * @param string   $name
 * @param int|null $value
 * @return void
 */
function farazsms_matomo_track_event( $category, $action, $name = '', $value = null ) {
	// به‌عمد خالی — هیچ درخواستِ خارجیِ سمتِ‌سرور زده نمی‌شود.
	// ⚠️ هشدار به توسعه‌دهنده‌ی آینده: این تابع را «بلاک‌کننده» نکنید. اگر روزی رویدادِ سمتِ‌سرور
	// لازم شد، حتماً غیرمسدودکننده باشد:
	//   wp_remote_post( ..., array( 'blocking' => false, 'timeout' => 2 ) )
	// یا انتقال به cron/Action-Scheduler + circuit-breaker — وگرنه باگِ کندیِ v3.20.56 برمی‌گردد.
}

// ============================================================================
// کارتِ تنظیمات — در صفحه‌ی تنظیماتِ اصلیِ افزونه (هوکِ extra sections)
// ============================================================================

/**
 * پاک‌کردنِ کشِ افزونه‌های رایج — تا با خاموش/روشن‌کردنِ آمار، صفحاتِ کش‌شده
 * بازسازی شوند و اسکریپتِ ردیاب فوراً اضافه/حذف شود (وگرنه روی صفحاتِ کش‌شده
 * تغییر اعمال نمی‌شود و کاربر فکر می‌کند خاموش‌سازی کار نکرده است).
 */
function farazsms_matomo_clear_caches() {
	if ( function_exists( 'wp_cache_flush' ) ) {
		wp_cache_flush();
	}
	// WP Rocket
	if ( function_exists( 'rocket_clean_domain' ) ) {
		rocket_clean_domain();
	}
	// LiteSpeed Cache
	do_action( 'litespeed_purge_all' );
	// W3 Total Cache
	if ( function_exists( 'w3tc_flush_all' ) ) {
		w3tc_flush_all();
	}
	// WP Fastest Cache
	if ( function_exists( 'wpfc_clear_all_cache' ) ) {
		wpfc_clear_all_cache( true );
	}
	// WP Super Cache
	if ( function_exists( 'wp_cache_clear_cache' ) ) {
		wp_cache_clear_cache();
	}
	// SG Optimizer (SiteGround)
	if ( function_exists( 'sg_cachepress_purge_cache' ) ) {
		sg_cachepress_purge_cache();
	}
	// Cachify / Autoptimize / others via هوک عمومی
	do_action( 'cachify_flush_cache' );
	do_action( 'autoptimize_action_cachepurged' );
}

// مدیریتِ ذخیره‌ی فرمِ مستقلِ این کارت.
add_action( 'admin_init', 'farazsms_matomo_handle_save' );
function farazsms_matomo_handle_save() {
	if ( ! isset( $_POST['farazsms_matomo_nonce'] ) ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['farazsms_matomo_nonce'] ) ), 'farazsms_matomo_save' ) ) {
		return;
	}
	$old_optout = get_option( 'farazsms_matomo_optout', '0' );
	$new_optout = isset( $_POST['farazsms_matomo_enable'] ) ? '0' : '1';
	update_option( 'farazsms_matomo_optout', $new_optout );
	if ( $old_optout !== $new_optout ) {
		farazsms_matomo_clear_caches(); // تا تغییرِ خاموش/روشن روی صفحاتِ کش‌شده هم اعمال شود.
	}
	// فیلدهای آدرس/Site فقط وقتی با ثابت bake نشده‌اند قابلِ ویرایش‌اند (برای تست).
	if ( ! defined( 'FARAZSMS_MATOMO_URL' ) && isset( $_POST['farazsms_matomo_url'] ) ) {
		update_option( 'farazsms_matomo_url', esc_url_raw( wp_unslash( $_POST['farazsms_matomo_url'] ) ) );
	}
	if ( ! defined( 'FARAZSMS_MATOMO_SITE_ID' ) && isset( $_POST['farazsms_matomo_site_id'] ) ) {
		update_option( 'farazsms_matomo_site_id', sanitize_text_field( wp_unslash( $_POST['farazsms_matomo_site_id'] ) ) );
	}
	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-success is-dismissible"><p>تنظیماتِ آمار ذخیره شد.</p></div>';
	} );
}

// ذخیره‌ی فوریِ توگل با AJAX — تا کاربر لازم نباشد دکمه‌ی ذخیره را بزند و
// خاموش‌کردنِ آمار بلافاصله اعمال شود.
add_action( 'wp_ajax_farazsms_matomo_toggle', 'farazsms_matomo_ajax_toggle' );
function farazsms_matomo_ajax_toggle() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => 'forbidden' ), 403 );
	}
	check_ajax_referer( 'farazsms_matomo_save', 'nonce' );
	$enable = isset( $_POST['enable'] ) && $_POST['enable'] === '1';
	update_option( 'farazsms_matomo_optout', $enable ? '0' : '1' );
	farazsms_matomo_clear_caches(); // بازسازیِ صفحاتِ کش‌شده تا تغییر فوراً اعمال شود.
	wp_send_json_success( array( 'optout' => $enable ? '0' : '1' ) );
}

add_action( 'farazsms_settings_page_extra_sections', 'farazsms_matomo_render_settings_card' );
function farazsms_matomo_render_settings_card() {
	$optout    = get_option( 'farazsms_matomo_optout', '0' ) === '1';
	$configured = farazsms_matomo_url() !== '' && farazsms_matomo_site_id() !== '';
	$baked      = defined( 'FARAZSMS_MATOMO_URL' );
	$url        = $baked ? FARAZSMS_MATOMO_URL : get_option( 'farazsms_matomo_url', '' );
	$site_id    = defined( 'FARAZSMS_MATOMO_SITE_ID' ) ? FARAZSMS_MATOMO_SITE_ID : get_option( 'farazsms_matomo_site_id', '' );
	?>
	<details style="background:#fff;border:1px solid #e1e1e1;border-radius:8px;margin-top:18px;direction:rtl">
		<summary style="padding:12px 18px;cursor:pointer;font-size:12.5px;color:#9b9b9b;font-weight:600;list-style:none;outline:none;">⚙️ آمار و حریم خصوصی (پیشرفته)</summary>
		<div style="padding:4px 18px 18px;">
		<p style="color:#555;font-size:13px;line-height:2;margin:0 0 12px">
			برای بهبودِ افزونه، آمارِ بازدیدِ سایت جمع‌آوری می‌شود. هر زمان می‌توانید خاموش کنید.
		</p>
		<form method="post" action="">
			<?php wp_nonce_field( 'farazsms_matomo_save', 'farazsms_matomo_nonce' ); ?>
			<p>
				<label style="display:inline-flex;align-items:center;gap:10px;font-weight:600;font-size:14px">
					<input type="checkbox" class="farazsms-toggle" id="farazsms-matomo-toggle" name="farazsms_matomo_enable" value="1" <?php checked( ! $optout ); ?> data-nonce="<?php echo esc_attr( wp_create_nonce( 'farazsms_matomo_save' ) ); ?>">
						<span id="farazsms-matomo-toggle-status" style="font-size:12px;color:#0c9765;margin-right:6px;"></span>
					جمع‌آوریِ آمار فعال باشد
				</label>
			</p>
			<?php if ( ! $baked ) : ?>
				<p style="margin:10px 0 0">
					<label style="font-size:13px;font-weight:600">آدرس سرور آمار:</label><br>
					<input type="url" name="farazsms_matomo_url" value="<?php echo esc_attr( $url ); ?>" placeholder="https://matomo.faraz.club/" class="regular-text" style="direction:ltr">
				</p>
				<p style="margin:10px 0 0">
					<label style="font-size:13px;font-weight:600">Site ID:</label><br>
					<input type="text" name="farazsms_matomo_site_id" value="<?php echo esc_attr( $site_id ); ?>" placeholder="1" class="small-text" style="direction:ltr">
				</p>
			<?php else : ?>
				<p style="color:#888;font-size:12px">آدرس و Site ID توسطِ فراز پیکربندی شده است.</p>
			<?php endif; ?>
			<p style="font-size:12px;color:<?php echo $configured ? '#1a7f37' : '#b32d2e'; ?>;margin:10px 0 0">
				وضعیت: <?php echo $configured ? '✓ پیکربندی‌شده' . ( $optout ? ' (خاموش توسطِ مدیر)' : ' و فعال' ) : '— هنوز آدرس/Site ID وارد نشده'; ?>
			</p>
			<div style="background:#faf1da;border:1px solid #e2a916;color:#83620d;border-radius:8px;padding:9px 13px;margin:8px 0;font-size:11.5px;line-height:1.8;">
				💡 پس از خاموش‌کردن، اگر افزونه‌ی <strong>کش</strong> یا CDN دارید، <strong>کشِ صفحات را پاک کنید</strong>؛ وگرنه اسکریپتِ آمار در صفحاتِ کش‌شده باقی می‌ماند و تا پاک‌شدنِ کش ارسال ادامه دارد.
			</div>
			<?php
			/**
			 * جای تزریقِ گزینه‌های آماریِ دیگر (مثلِ سرشماریِ افزونه‌ها) — تا همه‌ی
			 * تنظیماتِ آمار در یک کارت و با یک دکمه‌ی ذخیره باشند.
			 */
			do_action( 'farazsms_analytics_card_fields' );
			?>
			<p style="margin-top:14px"><button type="submit" class="button button-primary">💾 ذخیره</button></p>
			<script>
			(function(){
				var t=document.getElementById('farazsms-matomo-toggle'), st=document.getElementById('farazsms-matomo-toggle-status');
				if(!t)return;
				t.addEventListener('change',function(){
					st.textContent='در حال ذخیره…'; st.style.color='#9b9b9b';
					var fd=new FormData(); fd.append('action','farazsms_matomo_toggle'); fd.append('nonce',t.dataset.nonce); fd.append('enable', t.checked?'1':'0');
					fetch(ajaxurl,{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json();}).then(function(res){
						if(res&&res.success){ st.style.color=t.checked?'#0c9765':'#b32d2e'; st.textContent=t.checked?'✓ آمار فعال شد':'✓ آمار خاموش شد (کش را پاک کنید)'; }
						else{ st.style.color='#b32d2e'; st.textContent='خطا در ذخیره'; }
					}).catch(function(){ st.style.color='#b32d2e'; st.textContent='خطا در ارتباط'; });
				});
			})();
			</script>
		</form>
		</div>
	</details>
	<?php
}
