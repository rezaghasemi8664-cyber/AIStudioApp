<?php
/**
 * Data Archival / Cleanup — v3.18.0
 *
 * چرا این فایل؟
 *  جدول‌های log افزونه روی سایت‌های پرترافیک بدون cleanup می‌توانند به میلیون‌ها
 *  رکورد برسند. این:
 *    - DB سایت کاربر را sluggish می‌کند
 *    - backup را سنگین می‌کند
 *    - گزارش‌گیری ROI/DLR را کند می‌کند
 *
 *  این فایل cron هفتگی اجرا می‌کند که رکوردهای قدیمی‌تر از retention period را
 *  DELETE می‌کند. برای پیشگیری از اشتباه:
 *    - retention پیش‌فرض ۶ ماه است (نه ۱ ماه)
 *    - فقط رکوردهای «نهایی‌شده» (recovered/expired/sent) پاک می‌شوند، نه active
 *    - LIMIT روی هر run تا مسبب timeout نشود
 *
 *  کاربر می‌تواند با constant این رفتار را override کند:
 *    define( 'FARAZSMS_DATA_RETENTION_DAYS', 365 ); // در wp-config.php
 *    define( 'FARAZSMS_DATA_ARCHIVAL_DISABLED', true );
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_ARCHIVAL_CRON_HOOK = 'farazsms_data_archival_cron';

/**
 * تعداد روزهای نگهداری — پیش‌فرض ۱۸۰ روز (۶ ماه). قابل override در wp-config.php.
 */
function farazsms_archival_retention_days() {
	if ( defined( 'FARAZSMS_DATA_RETENTION_DAYS' ) ) {
		return max( 30, (int) FARAZSMS_DATA_RETENTION_DAYS );
	}
	return 180;
}

/**
 * آیا cron archival فعال است؟ کاربر می‌تواند با constant خاموش کند.
 */
function farazsms_archival_is_enabled() {
	if ( defined( 'FARAZSMS_DATA_ARCHIVAL_DISABLED' ) && FARAZSMS_DATA_ARCHIVAL_DISABLED ) {
		return false;
	}
	return true;
}

// Schedule cron — weekly
add_action( 'init', 'farazsms_archival_schedule_cron' );
function farazsms_archival_schedule_cron() {
	if ( ! farazsms_archival_is_enabled() ) {
		// اگر disabled شد، event موجود را remove کن
		$ts = wp_next_scheduled( FARAZSMS_ARCHIVAL_CRON_HOOK );
		if ( $ts ) wp_unschedule_event( $ts, FARAZSMS_ARCHIVAL_CRON_HOOK );
		return;
	}
	if ( ! wp_next_scheduled( FARAZSMS_ARCHIVAL_CRON_HOOK ) ) {
		// شروع از یک هفته بعد تا با نصب اولیه conflict نکند
		wp_schedule_event( time() + WEEK_IN_SECONDS, 'weekly', FARAZSMS_ARCHIVAL_CRON_HOOK );
	}
}

register_deactivation_hook(
	defined( 'FARAZSMS_PLUGIN_FILE' ) ? FARAZSMS_PLUGIN_FILE : __FILE__,
	'farazsms_archival_clear_cron'
);
function farazsms_archival_clear_cron() {
	$ts = wp_next_scheduled( FARAZSMS_ARCHIVAL_CRON_HOOK );
	if ( $ts ) wp_unschedule_event( $ts, FARAZSMS_ARCHIVAL_CRON_HOOK );
}

add_action( FARAZSMS_ARCHIVAL_CRON_HOOK, 'farazsms_archival_run' );

/**
 * اجرای cleanup روی همه‌ی جدول‌های قابل آرشیو.
 * هر یک با LIMIT 5000 تا حداکثر زمان اجرا را محدود کنیم.
 */
function farazsms_archival_run() {
	if ( ! farazsms_archival_is_enabled() ) {
		return;
	}

	$days   = farazsms_archival_retention_days();
	$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
	$stats  = array(
		'tracking_log'        => 0,
		'sms_send_log'        => 0,
		'abandoned_recovered' => 0,
		'abandoned_expired'   => 0,
		'newsletter_unsubs'   => 0,
		'started_at'          => current_time( 'mysql' ),
		'cutoff'              => $cutoff,
		'retention_days'      => $days,
	);

	global $wpdb;
	$lim = 5000;

	// ---- ۱) tracking_log: همه‌ی رکوردهای قدیمی‌تر از retention ----
	$t = $wpdb->prefix . 'farazsms_tracking_log';
	if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $t ) ) === $t ) {
		$stats['tracking_log'] = (int) $wpdb->query( $wpdb->prepare(
			"DELETE FROM $t WHERE sent_at < %s LIMIT %d",
			$cutoff, $lim
		) );
	}

	// ---- ۱.۵) sms_send_log: لاگِ ارسال — پرحجم‌ترین جدولِ یک افزونه‌ی پیامکی.
	//      v3.21.8: قبلاً در archival نبود → رشدِ بی‌کنترل تا ده‌ها میلیون ردیف.
	$t = $wpdb->prefix . 'farazsms_sms_send_log';
	if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $t ) ) === $t ) {
		$stats['sms_send_log'] = (int) $wpdb->query( $wpdb->prepare(
			"DELETE FROM $t WHERE created_at < %s LIMIT %d",
			$cutoff, $lim
		) );
	}

	// ---- ۲) abandoned_carts: status=recovered یا expired ----
	$t = $wpdb->prefix . 'farazsms_abandoned_carts';
	if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $t ) ) === $t ) {
		// recovered: بر اساس recovered_at
		$stats['abandoned_recovered'] = (int) $wpdb->query( $wpdb->prepare(
			"DELETE FROM $t WHERE status = 'recovered' AND recovered_at < %s LIMIT %d",
			$cutoff, $lim
		) );
		// expired/cancelled: بر اساس updated_at
		$stats['abandoned_expired'] = (int) $wpdb->query( $wpdb->prepare(
			"DELETE FROM $t WHERE status IN ('expired','cancelled') AND updated_at < %s LIMIT %d",
			$cutoff, $lim
		) );
	}

	// ---- ۳) لاگِ نظرسنجی: عمداً هرس نمی‌شود ----
	//
	// این‌جا کدی بود که جدولی به نامِ farazsms_survey_targets را هرس می‌کرد. چنین جدولی در
	// افزونه وجود ندارد — نامِ واقعی farazsms_survey_log است — پس گاردِ SHOW TABLES بی‌صدا
	// ردش می‌کرد و این بلوک از روزِ نوشته‌شدنش مرده بود.
	//
	// نامش را «درست» نکردیم، چون هرسِ لاگِ نظرسنجی باگ می‌ساخت: همان ردیف، خودش گاردِ
	// «قبلاً فرستاده شده» است (farazsms-survey.php:667-671 روی status = scheduled|sent).
	// با حذفِ ردیف‌های قدیمی، هر سفارشِ قدیمی که دوباره وضعیتش عوض شود — مسترد به تکمیل،
	// ویرایشِ دستیِ مدیر — پیامکِ نظرسنجیِ تکراری برای مشتری می‌فرستاد.
	//
	// رشدِ این جدول هم نگران‌کننده نیست: یک ردیف به ازای هر سفارش، یعنی کسری از خودِ
	// جدول‌های سفارشِ ووکامرس. تصمیم: نگه‌داشتنِ کامل، ثبت‌شده در ممیزیِ ۲۰۲۶-۰۸-۲۹.

	// ---- ۴) newsletter unsubscribed خیلی قدیمی (>۱ سال) ----
	//      گذاشتیم مدت طولانی‌تر چون فاصله از آخرین interaction مهم است.
	$t = $wpdb->prefix . 'farazsms_newsletter_subscribers';
	if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $t ) ) === $t ) {
		$year_cutoff = gmdate( 'Y-m-d H:i:s', time() - YEAR_IN_SECONDS );
		$stats['newsletter_unsubs'] = (int) $wpdb->query( $wpdb->prepare(
			"DELETE FROM $t WHERE status = 'unsubscribed' AND unsubscribed_at < %s LIMIT %d",
			$year_cutoff, $lim
		) );
	}

	$stats['finished_at'] = current_time( 'mysql' );
	$stats['total_purged'] = array_sum( array(
		$stats['tracking_log'],
		$stats['sms_send_log'],
		$stats['abandoned_recovered'],
		$stats['abandoned_expired'],
		$stats['newsletter_unsubs'],
	) );

	update_option( 'farazsms_archival_last_run', $stats, false );
}
