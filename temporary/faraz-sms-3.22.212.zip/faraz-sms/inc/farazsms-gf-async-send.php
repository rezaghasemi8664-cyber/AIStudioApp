<?php
/**
 * ارسالِ پیامکِ گرویتی‌فرم در پس‌زمینه — کارگرِ صفِ مشترک.
 *
 * ⚠️ چرا این فایل هست (تیکتِ «خطای ۵۰۳ پس از ثبتِ فرم»، ۱۴۰۵/۰۶/۱۶):
 *
 * تا v3.22.209 پیامکِ گرویتی روی هوکِ `gform_confirmation` و **درجا** ارسال
 * می‌شد: به ازای هر گیرنده یک درخواستِ HTTP، روی همان درخواستی که بازدیدکننده
 * منتظرش بود. هر کندیِ سرویس مستقیم به کاربر می‌رسید و روی LiteSpeed به‌شکلِ
 * ۵۰۳ دیده می‌شد — کاربر فکر می‌کرد فرم ثبت نشده، در حالی که شده بود.
 *
 * کارگر عمداً شناسه می‌گیرد نه خودِ رکورد: باقی‌مانده‌ی صف در یک آپشن سریال
 * می‌شود و entryِ گرویتی می‌تواند بزرگ و حاوی دادهٔ شخصی باشد.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * اجرای ارسالِ پیامکِ یک entry گرویتی (از صفِ مشترک صدا زده می‌شود).
 *
 * @param int    $entry_id
 * @param int    $form_id
 * @param string $status
 * @param string $function_time
 * @return void
 */
function farazsms_gf_send_sms_worker( $entry_id, $form_id, $status = '-', $function_time = 'immediately' ) {
	$entry_id = (int) $entry_id;
	$form_id  = (int) $form_id;
	if ( $entry_id <= 0 || $form_id <= 0 ) {
		return;
	}
	// ⚠️ سکوت این‌جا هم مجاز نیست. کلاسِ ارسالِ گرویتی فقط وقتی بار می‌شود که
	// GFForms در همان درخواست موجود باشد؛ اگر باقی‌مانده‌ی صف در درخواستی
	// تخلیه شود که این شرط برقرار نبوده، پیامک بی‌هیچ ردی گم می‌شد — دقیقاً
	// همان چیزی که شاخه‌ی پایین‌تر برای جلوگیری‌اش نوشته شده.
	if ( ! class_exists( 'GFAPI' ) || ! class_exists( 'FarazSMS_Next_Gravity_Forms_SMS_Send' ) ) {
		farazsms_send_diag_log( '', '', 'not_sent:گرویتی‌فرم در این درخواست بار نشده بود', array(
			'source'    => 'gravity-forms',
			'http_code' => 0,
			'detail'    => 'entry=' . $entry_id . ' form=' . $form_id,
		) );
		return;
	}

	$entry = GFAPI::get_entry( $entry_id );
	$form  = GFAPI::get_form( $form_id );

	// entry یا فرمِ حذف‌شده: کارِ صف‌شده دیگر موضوعی ندارد. سکوت نمی‌کنیم چون
	// این تنها ردِ «پیامکی که هرگز نرفت» است.
	if ( ! is_array( $entry ) || ! is_array( $form ) ) {
		// ⚠️ پیشوندِ api_error نیست: هیچ تماسی با سرویس انجام نشده. برچسب‌زدنش
		// به‌عنوانِ خطای سرویس، فیلترِ «خطاهای سرویس» را با وضعیتِ محلی آلوده می‌کند.
		farazsms_send_diag_log( '', '', 'not_sent:ارسالِ گرویتی انجام نشد — entry یا فرم یافت نشد', array(
			'source'    => 'gravity-forms',
			'http_code' => 0,
			'detail'    => 'entry=' . $entry_id . ' form=' . $form_id,
		) );
		return;
	}

	FarazSMS_Next_Gravity_Forms_SMS_Send::send_sms_form( $entry, $form, (string) $status, (string) $function_time );
}
