<?php
/**
 * یکپارچه‌سازی با «بوکلی» (Bookly) — پیامکِ نوبت‌دهی.
 *
 * ⚠️ چرا این ماژول با هوک کار نمی‌کند (تصمیمِ معماریِ اصلی — تغییرش ندهید بدونِ خواندنِ این):
 *
 * منبعِ بوکلی نسخهٔ ۲۸٫۰ بررسی شد. کلِ هوک‌های اکشنی که این افزونه دارد سه تاست:
 *
 * bookly_plugin_activate
 * bookly_plugin_deactivate
 * bookly_plugin_uninstall
 *
 * یعنی **هیچ هوکی برای ثبتِ نوبت، تأیید، لغو یا تغییرِ وضعیت وجود ندارد.** آن
 * hookهایی که در چند وبلاگِ انگلیسی به نامِ
 *
 * bookly_appointment_created
 *
 * معرفی شده‌اند، در کدِ بوکلی **وجود خارجی ندارند** و ساختن رویشان یعنی قابلیتی که
 * بی‌صدا هرگز اجرا نمی‌شود. سیستمِ افزونه‌ی بوکلی هم یک Proxyِ خصوصیِ Pro-gated است
 * که برای اشخاصِ ثالث باز نیست، و درگاهِ پیامکش قفلِ ابرِ خودشان است (هیچ فیلتری
 * برای جایگزینی ندارد).
 *
 * پس تنها راهِ اصولی: **خواندنِ مستقیمِ جدول‌های بوکلی با کرانِ خودمان.** این روش
 * علاوه بر اینکه روی نسخهٔ **رایگان** کار می‌کند، «یادآورِ نوبت» را هم ممکن می‌کند —
 * چیزی که نسخهٔ رایگانِ بوکلی اصلاً ندارد.
 *
 * ستون‌ها همگی از منبعِ بوکلی ۲۸٫۰ تأیید شده‌اند:
 *
 * bookly_customer_appointments → id, customer_id, appointment_id, status, status_changed_at, created_at, number_of_persons
 * bookly_appointments          → id, staff_id, service_id, start_date, custom_service_name
 * bookly_customers             → id, full_name, phone
 * bookly_services              → id, title, price
 * bookly_staff                 → id, full_name
 *
 * ⚠️ زمان: بوکلی start_date را در **تایم‌زونِ سایت** ذخیره می‌کند (نه UTC) — در
 * Lib\Utils\DateTime::applyTimeZone از getWPTimeZone تبدیل می‌گیرد. پس مقایسه‌ها
 * با current_time('mysql') انجام می‌شود و برای نمایش، timestamp با wp_timezone
 * ساخته می‌شود. اگر این را UTC فرض کنید، یادآورها ۳:۳۰ ساعت خطا می‌گیرند.
 *
 * کارایی: هیچ‌چیز روی مسیرِ فرانت‌اند اجرا نمی‌شود. کرانِ ۵ دقیقه‌ای + جبرانِ
 * بازدیدِ ادمین روی shutdown پس از بستنِ پاسخ.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_BOOKLY_DB_VERSION        = '1.0.0';
const FARAZSMS_BOOKLY_DB_VERSION_OPTION = 'farazsms_bookly_db_version';
const FARAZSMS_BOOKLY_OPTION            = 'farazsms_bookly_settings';
const FARAZSMS_BOOKLY_CRON              = 'farazsms_bookly_scan';
const FARAZSMS_BOOKLY_LAST_OPT          = 'farazsms_bookly_last_scan';

/**
 * پنجره‌ی عقب‌نگری. رویدادی که بیش از این قدیمی باشد دیگر پیامک نمی‌شود — تا اگر
 * افزونه بعد از مدتی روشن شد، انبوهی پیامکِ کهنه برای نوبت‌های گذشته نرود.
 */
const FARAZSMS_BOOKLY_LOOKBACK_HOURS = 24;

/** سقفِ ارسال در هر اجرا — تا یک ایمپورت یا ویرایشِ گروهی اعتبارِ فروشنده را نسوزاند. */
const FARAZSMS_BOOKLY_MAX_PER_RUN = 40;

/** حداقلِ فاصله تا موعد برای فرستادنِ یادآور (دقیقه). */
const FARAZSMS_BOOKLY_REMINDER_FLOOR_MIN = 30;

/** نقطه‌ی مبنا: هیچ رویدادی پیش از روشن‌شدنِ ماژول پیامک نمی‌شود. */
const FARAZSMS_BOOKLY_BASELINE_OPT = 'farazsms_bookly_baseline';

// ============================================================================
// تشخیصِ حضورِ بوکلی
// ============================================================================

/**
 * آیا بوکلی فعال است؟
 *
 * هم افزونهٔ رایگان و هم مسیرهای نصبِ غیرمعمول پوشش داده می‌شود؛ معیارِ نهایی
 * وجودِ جدولِ اصلی است، چون همین جدول است که می‌خوانیم.
 *
 * @return bool
 */
function farazsms_bookly_is_active() {
	static $cached = null;
	if ( $cached !== null ) {
		return $cached;
	}
	// معیارِ نهایی «وجودِ جدول» است، نه فعال‌بودنِ افزونه: روی نصبِ تازه بوکلی
	// می‌تواند فعال باشد ولی جدول‌هایش هنوز ساخته نشده باشند — در آن حالت کوئریِ
	// پنج‌جدولیِ ما هر ۵ دقیقه خطای MySQL می‌داد.
	// نتیجه ۱۲ ساعت کش می‌شود تا SHOW TABLES روی هر درخواست اجرا نشود.
	$cached = get_transient( 'farazsms_bookly_present' );
	if ( $cached === '1' ) {
		$cached = true;
		return $cached;
	}
	if ( $cached === '0' ) {
		$cached = false;
		return $cached;
	}
	global $wpdb;
	$table  = $wpdb->prefix . 'bookly_customer_appointments';
	$like   = method_exists( $wpdb, 'esc_like' ) ? $wpdb->esc_like( $table ) : $table;
	$cached = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) ) === $table );
	set_transient( 'farazsms_bookly_present', $cached ? '1' : '0', 12 * HOUR_IN_SECONDS );
	return $cached;
}

// ============================================================================
// تنظیمات
// ============================================================================

/**
 * رویدادهای پشتیبانی‌شده. کلید = event_key که در جدولِ ضدِتکرار ذخیره می‌شود.
 *
 * @return array
 */
function farazsms_bookly_events() {
	// منبعِ واحدِ حقیقت — کلیدهای این آرایه باید دقیقاً با
	// farazsms_bookly_default_messages() یکی باشند، وگرنه رویدادی بی‌متن یا
	// متنی بی‌کارت به‌وجود می‌آید. (پیش‌تر دو فهرستِ جدا بودند و صفحه‌ی تنظیمات
	// اختلاف را دستی وصله می‌کرد.)
	return array(
		'booked'       => 'ثبتِ نوبت (رزرو جدید)',
		'approved'     => 'تأییدِ نوبت',
		'cancelled'    => 'لغوِ نوبت',
		'rejected'     => 'ردِ نوبت',
		'reminder'     => 'یادآورِ نوبت (پیش از موعد)',
		'booked_admin' => 'اطلاع به مدیر هنگام ثبتِ نوبتِ جدید',
	);
}

/**
 * وضعیت‌های بوکلی که به رویدادِ ما نگاشت می‌شوند. مقادیر عیناً از
 * CustomerAppointment::STATUS_* گرفته شده‌اند.
 *
 * @return array
 */
function farazsms_bookly_status_map() {
	return array(
		'approved'  => 'approved',
		'cancelled' => 'cancelled',
		'rejected'  => 'rejected',
	);
}

/**
 * تنظیمات با پیش‌فرضِ امن (همه خاموش — افزونه بدونِ پیکربندی هیچ پیامکی نمی‌فرستد).
 *
 * @return array
 */
function farazsms_bookly_settings() {
	$defaults = array(
		'enabled'        => '0',
		'reminder_hours' => '24',
		'admin_phone'    => '',
		'events'         => array(),
	);
	// کلیدها از فهرستِ متن‌های پیش‌فرض می‌آیند تا رویدادِ مدیر (booked_admin) هم —
	// که در UI جدا نمایش داده می‌شود — همان ساختارِ پترن و «ساختِ خودکار» را داشته باشد.
	foreach ( farazsms_bookly_default_messages() as $key => $msg ) {
		$defaults['events'][ $key ] = array( 'enabled' => '0', 'pattern_code' => '', 'message' => $msg );
	}

	$saved = get_option( FARAZSMS_BOOKLY_OPTION, array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}
	// ادغامِ «ذخیره‌شده برنده» تا افزودنِ کلیدِ جدید در نسخه‌های بعدی تنظیماتِ
	// کاربر را صفر نکند (همان درسِ گزارشِ فروشِ روزانه).
	$out    = array_merge( $defaults, $saved );
	$events = is_array( $out['events'] ?? null ) ? $out['events'] : array();
	// ادغامِ *هر رویداد* جداگانه — نه array_merge سطح‌بالا. اگر کلِ زیرآرایه را جایگزین
	// کنیم، رویدادی که کاربر ذخیره کرده ولی هنوز از سازنده‌ی پترن استفاده نکرده،
	// متنِ پیش‌فرضش را از دست می‌دهد و تکست‌اریا خالی بالا می‌آید.
	foreach ( $defaults['events'] as $key => $default_event ) {
		$out['events'][ $key ] = array_merge( $default_event, is_array( $events[ $key ] ?? null ) ? $events[ $key ] : array() );
	}
	return $out;
}

/**
 * آیا این رویداد فعال و دارای پترن است؟
 *
 * @param array  $settings
 * @param string $event
 * @return string کدِ پترن یا رشته‌ی خالی
 */
function farazsms_bookly_event_pattern( $settings, $event ) {
	if ( ( $settings['enabled'] ?? '0' ) !== '1' ) {
		return '';
	}
	$cfg = $settings['events'][ $event ] ?? array();
	if ( ( $cfg['enabled'] ?? '0' ) !== '1' ) {
		return '';
	}
	return trim( (string) ( $cfg['pattern_code'] ?? '' ) );
}

/**
 * متغیرهایی که در پترنِ هر رویداد قابلِ استفاده‌اند (برای نمایش در UI).
 *
 * @return array
 */
function farazsms_bookly_pattern_vars() {
	return array( '%client_name%', '%service_name%', '%staff_name%', '%appointment_date%', '%appointment_time%', '%persons%', '%sitename%' );
}

/**
 * متنِ پیش‌فرضِ پیامکِ هر رویداد — ورودیِ «ساختِ خودکارِ پترن».
 *
 * @return array
 */
function farazsms_bookly_default_messages() {
	return array(
		'booked'       => '%client_name% عزیز، نوبتِ شما ثبت شد.' . "\n" . 'خدمت: %service_name%' . "\n" . 'تاریخ: %appointment_date% ساعت %appointment_time%' . "\n" . '%sitename%',
		'approved'     => '%client_name% عزیز، نوبتِ شما تأیید شد.' . "\n" . 'خدمت: %service_name%' . "\n" . 'تاریخ: %appointment_date% ساعت %appointment_time%' . "\n" . '%sitename%',
		'cancelled'    => '%client_name% عزیز، نوبتِ شما در تاریخ %appointment_date% ساعت %appointment_time% لغو شد.' . "\n" . '%sitename%',
		'rejected'     => '%client_name% عزیز، متأسفانه نوبتِ شما در تاریخ %appointment_date% تأیید نشد.' . "\n" . '%sitename%',
		'reminder'     => 'یادآوری نوبت' . "\n" . '%client_name% عزیز، نوبتِ شما %appointment_date% ساعت %appointment_time% است.' . "\n" . 'خدمت: %service_name%' . "\n" . '%sitename%',
		'booked_admin' => 'نوبتِ جدید ثبت شد.' . "\n" . 'مراجع: %client_name%' . "\n" . 'خدمت: %service_name%' . "\n" . 'تاریخ: %appointment_date% ساعت %appointment_time%' . "\n" . '%sitename%',
	);
}

add_filter( 'farazsms_feature_pattern_map', 'farazsms_bookly_register_pattern_features' );
/**
 * ثبتِ رویدادهای بوکلی در سامانه‌ی «ساختِ خودکارِ پترن».
 *
 * هر رویداد پترنِ خودش را دارد، پس از قابلیتِ مسیرِ تودرتو استفاده می‌کنیم تا همه
 * در همان یک آپشنِ تنظیمات بمانند.
 *
 * @param array $map
 * @return array
 */
function farazsms_bookly_register_pattern_features( $map ) {
	foreach ( array_keys( farazsms_bookly_default_messages() ) as $event ) {
		$map[ 'bookly_' . $event ] = array(
			'opt'     => FARAZSMS_BOOKLY_OPTION,
			'section' => 'bookly',
			'path'    => array( 'events', $event ),
		);
	}
	return $map;
}

// ============================================================================
// جدولِ ضدِتکرار
// ============================================================================

function farazsms_bookly_sent_table() {
	global $wpdb;
	return $wpdb->prefix . 'farazsms_bookly_sent';
}

/**
 * ساختِ جدول. مثل درسِ v3.22.152، در ابتدای مسیرِ نوشتن هم صدا زده می‌شود تا بینِ
 * به‌روزرسانی و اولین بازدیدِ ادمین چیزی گم نشود.
 */
function farazsms_bookly_maybe_setup_table() {
	if ( get_option( FARAZSMS_BOOKLY_DB_VERSION_OPTION ) === FARAZSMS_BOOKLY_DB_VERSION ) {
		return;
	}
	if ( ! function_exists( 'dbDelta' ) ) {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	}
	global $wpdb;
	$table           = farazsms_bookly_sent_table();
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE $table (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		ca_id BIGINT(20) UNSIGNED NOT NULL,
		event_key VARCHAR(32) NOT NULL,
		result VARCHAR(20) NOT NULL DEFAULT '',
		sent_at DATETIME NOT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY ca_event (ca_id, event_key),
		KEY sent_at (sent_at)
	) $charset_collate;";

	dbDelta( $sql );
	// فقط وقتی جدول واقعاً ساخته شد latch کن — شکستِ dbDelta نباید بی‌صدا بماند.
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
		update_option( FARAZSMS_BOOKLY_DB_VERSION_OPTION, FARAZSMS_BOOKLY_DB_VERSION, false );
	}
}

/**
 * «ادعای» یک رویداد پیش از ارسال — هسته‌ی ضدِتکرار.
 *
 * INSERT IGNORE روی کلیدِ یکتا اتمیک است، پس حتی اگر دو کران هم‌زمان اجرا شوند
 * (کرانِ عادی + جبرانِ بازدیدِ ادمین) فقط یکی موفق می‌شود و پیامک یک‌بار می‌رود.
 * این همان الگویی است که برای جدولِ تأییدِ OTP جواب داد.
 *
 * @param int    $ca_id
 * @param string $event
 * @return bool آیا این فراخوانی مالکِ ارسال شد
 */
function farazsms_bookly_claim( $ca_id, $event ) {
	global $wpdb;
	$table = farazsms_bookly_sent_table();
	$done  = $wpdb->query( $wpdb->prepare(
		"INSERT IGNORE INTO $table (ca_id, event_key, result, sent_at) VALUES (%d, %s, %s, %s)",
		(int) $ca_id,
		$event,
		'sending',
		current_time( 'mysql' )
	) );
	if ( (int) $done === 1 ) {
		return 'claimed';
	}
	// ⚠️ INSERT IGNORE هر خطایی را به اخطار تبدیل می‌کند — نه فقط کلیدِ تکراری.
	// اگر جدول نباشد (بازگردانیِ بکاپ، مهاجرتِ هاست) نتیجه هم صفر است، و اگر آن
	// را «قبلاً فرستاده شده» بخوانیم، همه‌ی پیامک‌ها بی‌صدا قطع می‌شوند. پس
	// دو حالت را با یک کوئریِ ارزان تفکیک می‌کنیم.
	$exists = (int) $wpdb->get_var( $wpdb->prepare(
		"SELECT COUNT(*) FROM $table WHERE ca_id = %d AND event_key = %s",
		(int) $ca_id,
		$event
	) );
	if ( $exists > 0 ) {
		return 'duplicate';
	}
	// جدول خراب/غایب است: لَچِ نسخه را برمی‌داریم تا دفعه‌ی بعد بازساخته شود.
	delete_option( FARAZSMS_BOOKLY_DB_VERSION_OPTION );
	farazsms_send_diag_log( '', '', 'bookly_claim_failed', array( 'source' => 'bookly', 'error' => (string) $wpdb->last_error ) );
	return 'error';
}

/**
 * ثبتِ نتیجه‌ی ارسال روی همان ردیفِ ادعا‌شده (برای دیده‌شدن در گزارش).
 *
 * @param int    $ca_id
 * @param string $event
 * @param string $result
 */
function farazsms_bookly_mark( $ca_id, $event, $result ) {
	global $wpdb;
	$wpdb->update(
		farazsms_bookly_sent_table(),
		array( 'result' => substr( (string) $result, 0, 20 ) ),
		array( 'ca_id' => (int) $ca_id, 'event_key' => $event ),
		array( '%s' ),
		array( '%d', '%s' )
	);
}

// ============================================================================
// خواندنِ نوبت‌ها
// ============================================================================

/**
 * پرس‌وجوی مشترکِ اتصالِ پنج جدولِ بوکلی.
 *
 * ⚠️ نکته‌ی مهمِ درستی: ردیف‌هایی که رویدادشان قبلاً ارسال شده، **در خودِ SQL** کنار
 * گذاشته می‌شوند. اگر این کار را نمی‌کردیم و فقط بعد از خواندن فیلتر می‌کردیم،
 * روی سایتِ پرترافیک ردیف‌های ارسال‌شده تمامِ سهمیه‌ی LIMIT را می‌گرفتند و
 * نوبت‌های قدیمی‌تر برای همیشه قحطی‌زده می‌شدند (پیامکشان هرگز نمی‌رفت).
 *
 * $exclude_event یکی از این دو حالت است:
 *   - رشته‌ی ثابت مثل 'booked' یا 'reminder'
 *   - مقدارِ ویژه‌ی 'STATUS' یعنی «کلیدِ رویداد برابرِ وضعیتِ فعلیِ نوبت» — چون
 *     کلیدهای وضعیتیِ ما عیناً همان رشته‌های بوکلی‌اند (approved/cancelled/rejected).
 *
 * @param string $where         شرطِ SQL (ثابتِ کد، نه ورودیِ کاربر)
 * @param array  $args          مقادیرِ prepare به‌ترتیبِ placeholderها
 * @param string $exclude_event
 * @param int    $limit
 * @return array
 */
function farazsms_bookly_query( $where, $args, $exclude_event, $limit = 200 ) {
	global $wpdb;
	$ca   = $wpdb->prefix . 'bookly_customer_appointments';
	$ap   = $wpdb->prefix . 'bookly_appointments';
	$cu   = $wpdb->prefix . 'bookly_customers';
	$sv   = $wpdb->prefix . 'bookly_services';
	$sf   = $wpdb->prefix . 'bookly_staff';
	$sent = farazsms_bookly_sent_table();

	if ( $exclude_event === 'STATUS' ) {
		$not_sent = "NOT EXISTS ( SELECT 1 FROM $sent s2 WHERE s2.ca_id = ca.id AND s2.event_key = ca.status )";
	} else {
		$not_sent = "NOT EXISTS ( SELECT 1 FROM $sent s2 WHERE s2.ca_id = ca.id AND s2.event_key = %s )";
		$args[]   = $exclude_event;
	}

	$sql = "SELECT ca.id AS ca_id, ca.status, ca.created_at, ca.status_changed_at,
			ca.number_of_persons,
			a.start_date, a.custom_service_name,
			c.full_name AS client_name, c.phone AS phone,
			s.title AS service_title,
			st.full_name AS staff_name
		FROM $ca ca
		INNER JOIN $ap a ON a.id = ca.appointment_id
		INNER JOIN $cu c ON c.id = ca.customer_id
		LEFT JOIN $sv s ON s.id = a.service_id
		LEFT JOIN $sf st ON st.id = a.staff_id
		WHERE $where AND $not_sent
		ORDER BY ca.id ASC
		LIMIT %d";

	$args[] = (int) $limit;
	// phpcs:ignore WordPress.DB.PreparedSQL -- نام‌های جدول از $wpdb->prefix ساخته شده‌اند و $where/$not_sent ثابتِ کدند؛ همه‌ی مقادیر از طریقِ prepare می‌روند.
	$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
	return is_array( $rows ) ? $rows : array();
}

/**
 * متغیرهای پترن از یک ردیفِ نوبت.
 *
 * @param array $row
 * @return array
 */
function farazsms_bookly_vars( $row ) {
	$service = trim( (string) ( $row['custom_service_name'] ?? '' ) );
	if ( $service === '' ) {
		$service = trim( (string) ( $row['service_title'] ?? '' ) );
	}

	$date = '';
	$time = '';
	$start = (string) ( $row['start_date'] ?? '' );
	if ( $start !== '' ) {
		try {
			// بوکلی زمان را در تایم‌زونِ سایت ذخیره می‌کند — با همان تایم‌زون تفسیرش
			// می‌کنیم، وگرنه strtotime آن را UTC می‌گیرد و ساعت جابه‌جا می‌شود.
			$tz = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'Asia/Tehran' );
			$dt = new DateTimeImmutable( $start, $tz );
			$time = $dt->format( 'H:i' );
			$date = farazsms_send_reports_to_jalali( $dt->getTimestamp(), false );
		} catch ( \Exception $e ) {
			$date = '';
			$time = '';
		}
	}

	return array(
		'client_name'      => trim( (string) ( $row['client_name'] ?? '' ) ),
		'service_name'     => $service,
		'staff_name'       => trim( (string) ( $row['staff_name'] ?? '' ) ),
		'appointment_date' => $date,
		'appointment_time' => $time,
		'persons'          => (string) ( (int) ( $row['number_of_persons'] ?? 1 ) ),
		'sitename'         => get_bloginfo( 'name' ),
	);
}

/**
 * ارسالِ یک رویداد برای یک ردیف (با ادعای ضدِتکرار).
 *
 * @param array  $row
 * @param string $event
 * @param string $pattern
 * @param string $phone   اگر خالی باشد، شماره‌ی مشتری استفاده می‌شود
 * @return bool
 */
function farazsms_bookly_send_event( $row, $event, $pattern, $phone = '' ) {
	if ( $pattern === '' || ! function_exists( 'farazsms_send_pattern_sms_raw' ) ) {
		return false;
	}
	$ca_id = (int) $row['ca_id'];
	$to    = $phone !== '' ? $phone : trim( (string) ( $row['phone'] ?? '' ) );
	// بوکلی شماره را خام ذخیره می‌کند (+98، فاصله، ارقامِ فارسی) — همان نرمال‌سازیِ
	// مشترکِ افزونه اعمال می‌شود.
	if ( $to !== '' ) {
		$to = (string) farazsms_normalize_phone( $to );
	}
	if ( $to === '' ) {
		// ردیفِ بی‌شماره باید علامت بخورد، وگرنه تا ابد سهمیه‌ی LIMIT را می‌گیرد و
		// نوبت‌های تازه را قحطی‌زده می‌کند — همان چیزی که فیلترِ SQL می‌خواست ببندد.
		if ( farazsms_bookly_claim( $ca_id, $event ) === 'claimed' ) {
			farazsms_bookly_mark( $ca_id, $event, 'no_phone' );
		}
		return false;
	}

	$vars = farazsms_bookly_vars( $row );
	if ( $event !== 'booked_admin' && ( $vars['appointment_date'] ?? '' ) === '' ) {
		// تاریخِ نامعتبر → پیامکی با تاریخِ خالی نفرست.
		if ( farazsms_bookly_claim( $ca_id, $event ) === 'claimed' ) {
			farazsms_bookly_mark( $ca_id, $event, 'bad_date' );
		}
		return false;
	}

	if ( farazsms_bookly_claim( $ca_id, $event ) !== 'claimed' ) {
		return false; // قبلاً فرستاده شده، یا جدول خراب است (در claim لاگ شد)
	}

	$sender = get_option( 'farazsms_sender', '' );
	$res    = farazsms_send_pattern_sms_raw( $to, $pattern, $vars, $sender );
	$ok     = ( $res === 'success' );
	farazsms_bookly_mark( $ca_id, $event, $ok ? 'success' : 'failed' );

	if ( ! $ok ) {
		// امضای واقعی: ( گیرنده، کدپترن، نتیجه، context ) — تا ردیف در صفحه‌ی
		// «تشخیص ارسال» با شماره‌ی مشتری قابلِ جست‌وجو باشد.
		farazsms_send_diag_log( $to, $pattern, is_string( $res ) && $res !== '' ? $res : 'failed', array( 'source' => 'bookly', 'event' => $event ) );
	}
	return $ok;
}

// ============================================================================
// پویش — رویدادها و یادآورها
// ============================================================================

/**
 * مرزِ عقب‌نگری: هرچه دیرتر باشد بینِ «۲۴ ساعتِ گذشته» و «لحظه‌ی روشن‌شدنِ ماژول».
 *
 * بدونِ نقطه‌ی مبنا، روشن‌کردنِ ماژول بلافاصله برای همه‌ی نوبت‌های یک شبانه‌روزِ
 * گذشته پیامک می‌فرستاد — رفتاری که هیچ فروشنده‌ای انتظارش را ندارد.
 *
 * @return string زمانِ محلی به فرمتِ MySQL
 */
function farazsms_bookly_cutoff() {
	// current_time('mysql') زمانِ محلیِ سایت است و strtotime آن را با تایم‌زونِ
	// پیش‌فرضِ PHP می‌خواند؛ gmdate هم دوباره همان‌طور برمی‌گرداند، پس دو اثر
	// خنثی می‌شوند و خروجی زمانِ *محلی* است — همان چیزی که ستون‌های بوکلی دارند.
	$cutoff   = gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) ) - ( FARAZSMS_BOOKLY_LOOKBACK_HOURS * HOUR_IN_SECONDS ) );
	$baseline = (string) get_option( FARAZSMS_BOOKLY_BASELINE_OPT, '' );
	return ( $baseline !== '' && $baseline > $cutoff ) ? $baseline : $cutoff;
}

/**
 * ردیف‌هایی که در وضعیتِ «در حالِ ارسال» گیر کرده‌اند (مرگِ پروسه بینِ ادعا و
 * ثبتِ نتیجه) پس از ۱۵ دقیقه آزاد می‌شوند تا دوباره تلاش شود — وگرنه آن نوبت
 * برای همیشه گم می‌شد بدونِ هیچ نشانه‌ای.
 */
function farazsms_bookly_release_stale() {
	global $wpdb;
	$table = farazsms_bookly_sent_table();
	$limit = gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) ) - ( 15 * MINUTE_IN_SECONDS ) );
	$wpdb->query( $wpdb->prepare(
		"DELETE FROM $table WHERE result = %s AND sent_at < %s",
		'sending',
		$limit
	) );
}

/**
 * پویشِ رویدادهای ثبت/تأیید/لغو/رد.
 *
 * @param array $settings
 * @return int تعدادِ پیامکِ ارسال‌شده
 */
function farazsms_bookly_scan_events( $settings ) {
	// current_time('mysql') زمانِ محلیِ سایت است و strtotime آن را با تایم‌زونِ
	// پیش‌فرضِ PHP (که وردپرس روی UTC می‌گذارد) می‌خواند؛ gmdate هم دوباره همان‌طور
	// برمی‌گرداند. این دو اثر یکدیگر را خنثی می‌کنند و نتیجه یک رشته‌ی زمانِ *محلی*
	// است — دقیقاً همان چیزی که ستون‌های بوکلی در آن ذخیره شده‌اند.
	$cutoff = farazsms_bookly_cutoff();

	$status_map    = farazsms_bookly_status_map();
	$admin_phone   = trim( (string) $settings['admin_phone'] );
	$admin_pattern = farazsms_bookly_event_pattern( $settings, 'booked_admin' );
	$booked_pat    = farazsms_bookly_event_pattern( $settings, 'booked' );
	$admin_on      = $admin_phone !== '' && $admin_pattern !== '';
	$sent          = 0;

	// ۱) رزروِ جدید — و در همان گذر، نسخه‌ی مدیر.
	if ( $booked_pat !== '' || $admin_on ) {
		$rows = farazsms_bookly_query( 'ca.created_at >= %s', array( $cutoff ), 'booked' );
		foreach ( $rows as $row ) {
			if ( $admin_on && farazsms_bookly_send_event( $row, 'booked_admin', $admin_pattern, $admin_phone ) ) {
				$sent++;
			}
			if ( $booked_pat !== '' ) {
				if ( farazsms_bookly_send_event( $row, 'booked', $booked_pat ) ) {
					$sent++;
				}
			} else {
				// پیامکِ مشتری خاموش است ولی مدیر روشن — ردیف را «دیده‌شده» علامت
				// می‌زنیم تا در پویش‌های بعدی دوباره در نتیجه‌ی کوئری نماند.
				if ( farazsms_bookly_claim( (int) $row['ca_id'], 'booked' ) === 'claimed' ) {
					farazsms_bookly_mark( (int) $row['ca_id'], 'booked', 'skipped' );
				}
			}
			if ( $sent >= FARAZSMS_BOOKLY_MAX_PER_RUN ) {
				return $sent;
			}
		}
	}

	// ۲) تغییرِ وضعیت — فقط وقتی واقعاً «تغییر» رخ داده باشد، نه مقدارِ اولیه.
	$rows = farazsms_bookly_query(
		"ca.status_changed_at >= %s AND ca.status_changed_at > ca.created_at AND ca.status IN ( 'approved', 'cancelled', 'rejected' )",
		array( $cutoff ),
		'STATUS'
	);
	foreach ( $rows as $row ) {
		$status = (string) $row['status'];
		if ( ! isset( $status_map[ $status ] ) ) {
			continue;
		}
		$event   = $status_map[ $status ];
		$pattern = farazsms_bookly_event_pattern( $settings, $event );
		if ( $pattern === '' ) {
			// رویدادِ خاموش هم باید علامت بخورد، وگرنه تا پایانِ پنجره در هر پویش
			// برمی‌گردد و سهمیه‌ی LIMIT را از رویدادهای واقعی می‌گیرد.
			if ( farazsms_bookly_claim( (int) $row['ca_id'], $event ) === 'claimed' ) {
				farazsms_bookly_mark( (int) $row['ca_id'], $event, 'skipped' );
			}
			continue;
		}
		if ( farazsms_bookly_send_event( $row, $event, $pattern ) ) {
			$sent++;
		}
		if ( $sent >= FARAZSMS_BOOKLY_MAX_PER_RUN ) {
			return $sent;
		}
	}

	return $sent;
}

/**
 * پویشِ یادآورها — نوبت‌هایی که تا N ساعتِ آینده شروع می‌شوند.
 *
 * @param array $settings
 * @return int
 */
function farazsms_bookly_scan_reminders( $settings ) {
	$pattern = farazsms_bookly_event_pattern( $settings, 'reminder' );
	if ( $pattern === '' ) {
		return 0;
	}
	$hours = (int) $settings['reminder_hours'];
	if ( $hours <= 0 ) {
		return 0;
	}

	// مقایسه در تایم‌زونِ سایت، چون start_date هم محلی ذخیره شده است.
	$now = current_time( 'mysql' );
	// کفِ زمانی: بدونِ آن، نوبتی که خودش داخلِ پنجره رزرو شود در همان پویش هم
	// پیامکِ «ثبت شد» می‌گرفت و هم «یادآوری» — با چند ثانیه فاصله.
	$from = gmdate( 'Y-m-d H:i:s', strtotime( $now ) + ( FARAZSMS_BOOKLY_REMINDER_FLOOR_MIN * MINUTE_IN_SECONDS ) );
	$till = gmdate( 'Y-m-d H:i:s', strtotime( $now ) + ( $hours * HOUR_IN_SECONDS ) );

	$rows = farazsms_bookly_query(
		"a.start_date >= %s AND a.start_date <= %s AND ca.status IN ( 'approved', 'pending' )",
		array( $from, $till ),
		'reminder'
	);

	$sent = 0;
	foreach ( $rows as $row ) {
		if ( farazsms_bookly_send_event( $row, 'reminder', $pattern ) ) {
			$sent++;
		}
		if ( $sent >= FARAZSMS_BOOKLY_MAX_PER_RUN ) {
			break;
		}
	}
	return $sent;
}

/**
 * اجرای کاملِ پویش.
 *
 * @return int
 */
function farazsms_bookly_scan() {
	if ( ! farazsms_bookly_is_active() ) {
		return 0;
	}
	$settings = farazsms_bookly_settings();
	if ( ( $settings['enabled'] ?? '0' ) !== '1' ) {
		return 0;
	}
	farazsms_bookly_maybe_setup_table();

	// ⚠️ زمانِ اجرا **پیش از** حلقه ثبت می‌شود: اگر پروسه وسطِ ارسال با
	// max_execution_time کشته شود (روی هاستِ اشتراکی محتمل است و try/catch هم
	// نمی‌گیردش)، مقدارِ آخرین اجرا هرگز جلو نمی‌رفت و debounceِ ۱۵ دقیقه‌ای فعال
	// نمی‌شد — یعنی هر بازدیدِ ادمین یک پویشِ کامل راه می‌انداخت.
	update_option( FARAZSMS_BOOKLY_LAST_OPT, time(), false );

	$sent = 0;
	try {
		farazsms_bookly_release_stale();
		$sent += farazsms_bookly_scan_events( $settings );
		$sent += farazsms_bookly_scan_reminders( $settings );
	} catch ( \Throwable $e ) {
		farazsms_send_diag_log( '', '', 'bookly_scan_error', array( 'source' => 'bookly', 'error' => $e->getMessage() ) );
	}
	return $sent;
}

add_action( FARAZSMS_BOOKLY_CRON, 'farazsms_bookly_scan' );

// ============================================================================
// زمان‌بندی
// ============================================================================

add_filter( 'cron_schedules', 'farazsms_bookly_cron_schedules' );
function farazsms_bookly_cron_schedules( $schedules ) {
	if ( ! is_array( $schedules ) ) {
		$schedules = array();
	}
	if ( ! isset( $schedules['farazsms_five_minutes'] ) ) {
		$schedules['farazsms_five_minutes'] = array(
			'interval' => 5 * MINUTE_IN_SECONDS,
			'display'  => 'هر ۵ دقیقه (فراز اس‌ام‌اس)',
		);
	}
	return $schedules;
}

add_action( 'init', 'farazsms_bookly_maybe_schedule' );
function farazsms_bookly_maybe_schedule() {
	// زمان‌بندی کارِ فرانت‌اند نیست: روی صفحاتِ فروشگاه نه آپشن می‌خوانیم نه
	// تشخیصِ حضورِ بوکلی را اجرا می‌کنیم.
	if ( ! is_admin() && ! wp_doing_cron() ) {
		return;
	}
	$settings = farazsms_bookly_settings();
	$on       = ( $settings['enabled'] ?? '0' ) === '1' && farazsms_bookly_is_active();
	$ts       = wp_next_scheduled( FARAZSMS_BOOKLY_CRON );

	if ( ! $on ) {
		if ( $ts ) {
			wp_unschedule_event( $ts, FARAZSMS_BOOKLY_CRON );
		}
		return;
	}
	if ( ! $ts ) {
		wp_schedule_event( time() + 60, 'farazsms_five_minutes', FARAZSMS_BOOKLY_CRON );
	}
}

register_deactivation_hook(
	defined( 'FARAZSMS_PLUGIN_FILE' ) ? FARAZSMS_PLUGIN_FILE : __FILE__,
	'farazsms_bookly_clear_cron'
);
function farazsms_bookly_clear_cron() {
	$ts = wp_next_scheduled( FARAZSMS_BOOKLY_CRON );
	if ( $ts ) {
		wp_unschedule_event( $ts, FARAZSMS_BOOKLY_CRON );
	}
}

// ============================================================================
// جبرانِ کرانِ لنگ — روی هاست‌هایی که wp-cron خاموش است
// ============================================================================

add_action( 'admin_init', 'farazsms_bookly_maybe_catchup' );
function farazsms_bookly_maybe_catchup() {
	if ( wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}
	$settings = farazsms_bookly_settings();
	if ( ( $settings['enabled'] ?? '0' ) !== '1' || ! farazsms_bookly_is_active() ) {
		return;
	}
	if ( get_transient( 'farazsms_bookly_catchup_lock' ) ) {
		return; // اخیراً صف شده — دوباره نه.
	}
	$last = (int) get_option( FARAZSMS_BOOKLY_LAST_OPT, 0 );
	// ۱۵ دقیقه debounce تا هر بازدیدِ ادمین پویش راه نیندازد.
	if ( $last > 0 && ( time() - $last ) < ( 15 * MINUTE_IN_SECONDS ) ) {
		return;
	}
	// v3.22.202: نردبانِ تعویقِ خصوصی حذف شد و کار به صفِ مشترک رفت.
	// آن نردبان روی mod_php تضمینی نداشت (پاسخ بسته نمی‌شد) و نه ذخیره‌ی
	// باقی‌مانده داشت، نه اجراکننده، نه کچ‌آپ.
	//
	// ⚠️ قفلِ debounce را **تولیدکننده** می‌گذارد، نه کارگر.
	// شرطِ بالا روی همان آپشنی است که farazsms_bookly_scan در پایانِ کارش
	// می‌نویسد. تا وقتی کار روی shutdownِ همان درخواست اجرا می‌شد این کافی
	// بود؛ حالا که کار در صف می‌ماند، شرط باز می‌مانْد و هر بازدیدِ پیشخوان
	// یک پویشِ کاملِ دیگر صف می‌کرد. روی هاستِ بدونِ کرون ده‌ها ردیف.
	// ⚠️ نتیجه‌ی نوشتن گیت نمی‌شود: اگر کشِ سایت پر باشد و نوشتن شکست بخورد،
	// گیت‌کردن یعنی این قابلیت برای همیشه خاموش می‌ماند. شکستِ debounce
	// حداکثر یک ردیفِ تکراری هزینه دارد؛ شکستِ قابلیت خیلی گران‌تر است.
	set_transient( 'farazsms_bookly_catchup_lock', 1, 15 * MINUTE_IN_SECONDS );
	farazsms_queue_task( 'bookly', 'farazsms_bookly_scan' );
}


// ============================================================================
// صفحه‌ی تنظیمات
// ============================================================================

add_action( 'admin_menu', 'farazsms_bookly_menu', 20 );
function farazsms_bookly_menu() {
	add_submenu_page(
		'farazsms',
		__( 'پیامک نوبت‌دهی (بوکلی)', 'farazsms' ),
		__( 'پیامک نوبت‌دهی (بوکلی)', 'farazsms' ),
		'manage_options',
		'farazsms-bookly',
		'farazsms_bookly_render_page'
	);
}

add_action( 'admin_init', 'farazsms_bookly_handle_save' );
function farazsms_bookly_handle_save() {
	if ( ! isset( $_POST['farazsms_bookly_nonce'] ) ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['farazsms_bookly_nonce'] ) ), 'farazsms_bookly_save' ) ) {
		return;
	}

	$settings                   = farazsms_bookly_settings();
	$settings['enabled']        = isset( $_POST['farazsms_bookly_enabled'] ) ? '1' : '0';
	$settings['reminder_hours'] = min( 720, max( 0, (int) ( $_POST['farazsms_bookly_reminder_hours'] ?? 24 ) ) );
	$settings['admin_phone']    = sanitize_text_field( wp_unslash( $_POST['farazsms_bookly_admin_phone'] ?? '' ) );

	foreach ( array_keys( farazsms_bookly_default_messages() ) as $key ) {
		// متنِ پیامک عمداً از این فرم نوشته نمی‌شود — آن را «سازنده‌ی پترن» (AJAX)
		// می‌نویسد. اگر اینجا هم می‌نوشتیم، ذخیره‌ی فرم متنِ ساخته‌شده را برمی‌گرداند.
		$settings['events'][ $key ]['enabled']      = isset( $_POST[ 'farazsms_bookly_ev_' . $key ] ) ? '1' : '0';
		$settings['events'][ $key ]['pattern_code'] = sanitize_text_field( wp_unslash( $_POST[ 'farazsms_bookly_pat_' . $key ] ?? '' ) );
	}

	// نقطه‌ی مبنا فقط در لحظه‌ی روشن‌شدن ثبت می‌شود تا تاریخچه پیامک نشود.
	if ( $settings['enabled'] === '1' && get_option( FARAZSMS_BOOKLY_BASELINE_OPT, '' ) === '' ) {
		update_option( FARAZSMS_BOOKLY_BASELINE_OPT, current_time( 'mysql' ), false );
	} elseif ( $settings['enabled'] !== '1' ) {
		delete_option( FARAZSMS_BOOKLY_BASELINE_OPT );
	}
	update_option( FARAZSMS_BOOKLY_OPTION, $settings, false );
	farazsms_bookly_maybe_setup_table();

	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-success is-dismissible"><p>تنظیماتِ پیامکِ نوبت‌دهی ذخیره شد.</p></div>';
	} );
}

function farazsms_bookly_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$settings = farazsms_bookly_settings();
	$active   = farazsms_bookly_is_active();
	$events   = farazsms_bookly_events();
	$last     = (int) get_option( FARAZSMS_BOOKLY_LAST_OPT, 0 );
	$vars     = farazsms_bookly_pattern_vars();
	$has_ui   = function_exists( 'farazsms_feature_pattern_builder_ui' );
	?>
	<div class="wrap" dir="rtl">
		<h1>📅 پیامک نوبت‌دهی — بوکلی</h1>

		<?php if ( ! $active ) : ?>
			<div class="notice notice-warning"><p>
				افزونهٔ <strong>بوکلی</strong> روی این سایت پیدا نشد. تنظیماتِ زیر ذخیره می‌شود ولی تا نصبِ بوکلی اثری ندارد.
			</p></div>
		<?php endif; ?>

		<div class="farazsms-int-intro">
			<strong>این صفحه چه می‌کند؟</strong> هر نوبتی که در بوکلی ثبت، تأیید، لغو یا رد شود، برای مراجع پیامک می‌فرستد —
			و پیش از موعدِ نوبت، پیامکِ یادآوری. روی <strong>نسخهٔ رایگانِ بوکلی</strong> هم کار می‌کند و به سرویسِ پیامکِ ابریِ بوکلی نیازی ندارد.
			<br><strong>راه‌اندازی در ۳ قدم:</strong>
			<ol>
				<li>کلیدِ «پیامکِ نوبت‌دهی فعال باشد» را روشن کنید.</li>
				<li>برای هر رویدادی که می‌خواهید، تیکش را بزنید، متنِ پیامک را در همان کارت ویرایش کنید و دکمهٔ <strong>ساخت/ویرایشِ پترن</strong> را بزنید — کدپترن خودکار پر می‌شود.</li>
				<li>دکمهٔ «ذخیره تنظیمات» را بزنید.</li>
			</ol>
			پترنِ تازه‌ساخته‌شده پس از تأییدِ پنلِ فراز (۱ تا ۲۴ ساعت) فعال می‌شود. نوبت‌ها هر ۵ دقیقه بررسی می‌شوند و
			هر رویداد برای هر نوبت فقط <strong>یک‌بار</strong> پیامک می‌شود.
		</div>

		<form method="post" action="">
			<?php wp_nonce_field( 'farazsms_bookly_save', 'farazsms_bookly_nonce' ); ?>

			<div class="farazsms-int-card">
				<div class="farazsms-int-card__head">
					<h2 class="farazsms-int-card__title">وضعیتِ کلی</h2>
					<label class="farazsms-int-toggle">
						<input type="checkbox" name="farazsms_bookly_enabled" value="1" <?php checked( $settings['enabled'], '1' ); ?>>
						پیامکِ نوبت‌دهی فعال باشد
					</label>
				</div>
				<div class="farazsms-int-card__body">
					<div class="farazsms-int-field">
						<label for="farazsms-bookly-hours">یادآور، چند ساعت پیش از نوبت فرستاده شود؟</label>
						<input id="farazsms-bookly-hours" type="number" min="0" max="720" name="farazsms_bookly_reminder_hours" value="<?php echo esc_attr( $settings['reminder_hours'] ); ?>" class="small-text">
						<span class="farazsms-int-hint">۰ یعنی یادآور فرستاده نشود.</span>
					</div>
					<div class="farazsms-int-field">
						<label for="farazsms-bookly-adminphone">شمارهٔ موبایلِ مدیر (برای اطلاع از نوبتِ جدید)</label>
						<input id="farazsms-bookly-adminphone" type="text" dir="ltr" name="farazsms_bookly_admin_phone" value="<?php echo esc_attr( $settings['admin_phone'] ); ?>" placeholder="09xxxxxxxxx">
					</div>
					<p class="farazsms-int-hint">
						آخرین بررسیِ نوبت‌ها: <?php echo $last > 0 ? esc_html( human_time_diff( $last ) ) . ' پیش' : 'هنوز انجام نشده'; ?>
					</p>
				</div>
			</div>

			<?php
			foreach ( $events as $key => $label ) :
				$cfg = $settings['events'][ $key ] ?? array();
				?>
				<div class="farazsms-int-card">
					<div class="farazsms-int-card__head">
						<h2 class="farazsms-int-card__title"><?php echo esc_html( $label ); ?></h2>
						<label class="farazsms-int-toggle">
							<input type="checkbox" name="<?php echo esc_attr( 'farazsms_bookly_ev_' . $key ); ?>" value="1" <?php checked( $cfg['enabled'] ?? '0', '1' ); ?>>
							فعال
						</label>
					</div>
					<div class="farazsms-int-card__body">
						<div class="farazsms-int-field">
							<label for="<?php echo esc_attr( 'farazsms-bookly-pat-' . $key ); ?>">کدپترن</label>
							<input id="<?php echo esc_attr( 'farazsms-bookly-pat-' . $key ); ?>" type="text" dir="ltr" name="<?php echo esc_attr( 'farazsms_bookly_pat_' . $key ); ?>" value="<?php echo esc_attr( $cfg['pattern_code'] ?? '' ); ?>" placeholder="با دکمهٔ زیر خودکار پر می‌شود">
						</div>
						<?php if ( $has_ui ) {
							farazsms_feature_pattern_builder_ui(
								'bookly_' . $key,
								(string) ( $cfg['message'] ?? '' ),
								$vars,
								'farazsms_bookly_pat_' . $key
							);
						} else { ?>
							<div class="farazsms-int-vars"><?php foreach ( $vars as $v ) : ?><code><?php echo esc_html( $v ); ?></code><?php endforeach; ?></div>
						<?php } ?>
					</div>
				</div>
			<?php endforeach; ?>

			<p><button type="submit" class="button button-primary">💾 ذخیره تنظیمات</button></p>
		</form>

		<div class="farazsms-int-intro">
			<strong>سؤال‌های پرتکرار</strong>
			<ul>
				<li><strong>پیامک نرفت؟</strong> اول مطمئن شوید کدپترن پر شده و در پنلِ فراز <em>تأیید</em> شده است؛ پترنِ تأییدنشده ارسال نمی‌شود.</li>
				<li><strong>شمارهٔ مراجع از کجا خوانده می‌شود؟</strong> از فیلدِ تلفنِ خودِ بوکلی در فرمِ رزرو. اگر آن فیلد را غیرفعال کرده‌اید، پیامکی ارسال نمی‌شود.</li>
				<li><strong>ساعتِ یادآور اشتباه است؟</strong> منطقهٔ زمانیِ وردپرس (تنظیمات ← عمومی) را روی تهران بگذارید؛ بوکلی و ما هر دو از همان می‌خوانیم.</li>
				<li><strong>روی سرعتِ سایت اثر دارد؟</strong> خیر. هیچ‌چیزِ این بخش روی صفحاتِ فروشگاه اجرا نمی‌شود و ارسال‌ها پس از بسته‌شدنِ صفحه انجام می‌شوند.</li>
			</ul>
		</div>
	</div>
	<?php
}

add_filter( 'farazsms_compatibility_registry', 'farazsms_bookly_register_compat' );
/**
 * خودثبتی در فهرستِ سازگاری‌ها — قاعدهٔ پروژه: هر یکپارچگی خودش را معرفی می‌کند.
 *
 * @param array $registry
 * @return array
 */
function farazsms_bookly_register_compat( $registry ) {
	$registry['bookly'] = array(
		'name'   => 'Bookly',
		'what'   => 'پیامکِ ثبت، تأیید، لغو و ردِ نوبت + یادآورِ نوبت پیش از موعد (روی نسخهٔ رایگان هم کار می‌کند)',
		'group'  => 'booking',
		'detect' => 'farazsms_bookly_is_active',
	);
	return $registry;
}

add_filter( 'farazsms_nav_extra', 'farazsms_bookly_register_nav' );
/**
 * @param array $nav
 * @return array
 */
function farazsms_bookly_register_nav( $nav ) {
	$nav['farazsms-bookly'] = array(
		'title' => 'نوبت‌دهی (بوکلی)',
		'icon'  => 'dashicons-calendar-alt',
		'desc'  => 'پیامکِ ثبت، تأیید، لغو و یادآورِ نوبت',
		'group' => 'wp',
		'when'  => 'farazsms_bookly_is_active',
	);
	return $nav;
}
