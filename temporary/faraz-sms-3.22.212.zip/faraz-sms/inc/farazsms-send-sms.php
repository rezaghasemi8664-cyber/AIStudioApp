<?php
/**
 * ارسال پیامک از داخل سایت — Phase 3
 *
 * این ماژول یک صفحه ادمین ساده می‌سازد که مدیر سایت بتواند بدون رفتن به
 * پنل فراز اس‌ام‌اس، یک پیامک گروهی (متن آزاد یا الگو) به گیرندگان زیر
 * بفرستد:
 *
 *   - شماره‌های وارد شده دستی (paste)
 *   - مشترکین فعال خبرنامه (farazsms_newsletter_subscribers)
 *   - مشترکین «موجود شد خبرم کن» (farazsms_notify_subscribers)
 *   - یک باشگاه مشتریان از پنل فراز اس‌ام‌اس (با API)
 *
 * هر ارسال در جدول لاگ ذخیره می‌شود و در تب «تاریخچه» قابل مشاهده است.
 *
 * Submenu: farazsms-send-sms (priority 11 — درست بعد از تنظیمات)
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

// ============================================================================
// Schema (جدول لاگ ارسال‌ها)
// ============================================================================

const FARAZSMS_SEND_LOG_DB_VERSION        = '1.0.0';
const FARAZSMS_SEND_LOG_DB_VERSION_OPTION = 'farazsms_send_log_db_version';

function farazsms_send_log_table() {
	global $wpdb;
	return $wpdb->prefix . 'farazsms_sms_send_log';
}

function farazsms_send_sms_maybe_setup_table() {
	if ( get_option( FARAZSMS_SEND_LOG_DB_VERSION_OPTION ) === FARAZSMS_SEND_LOG_DB_VERSION ) {
		return;
	}
	if ( ! function_exists( 'dbDelta' ) ) {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	}
	global $wpdb;
	$table           = farazsms_send_log_table();
	$charset_collate = $wpdb->get_charset_collate();
	$sql = "CREATE TABLE $table (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		source VARCHAR(50) NOT NULL DEFAULT '',
		mode VARCHAR(20) NOT NULL DEFAULT '',
		pattern_code VARCHAR(80) NOT NULL DEFAULT '',
		message_text TEXT NOT NULL,
		recipients_count INT UNSIGNED NOT NULL DEFAULT 0,
		sent_count INT UNSIGNED NOT NULL DEFAULT 0,
		failed_count INT UNSIGNED NOT NULL DEFAULT 0,
		user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
		created_at DATETIME NOT NULL,
		PRIMARY KEY  (id),
		KEY created_at (created_at)
	) $charset_collate;";
	dbDelta( $sql );
	// v3.21.7: فقط وقتی جدول واقعاً ساخته شد latch کن (شکستِ dbDelta = مرگِ بی‌صدا).
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
		update_option( FARAZSMS_SEND_LOG_DB_VERSION_OPTION, FARAZSMS_SEND_LOG_DB_VERSION, false );
	}
}
add_action( 'admin_init', 'farazsms_send_sms_maybe_setup_table' );

// ============================================================================
// Submenu (priority 11 — درست بعد از تنظیمات priority 10)
// ============================================================================

add_action( 'admin_menu', 'farazsms_send_sms_register_submenu', 11 );
function farazsms_send_sms_register_submenu() {
	add_submenu_page(
		'farazsms',
		__( 'ارسال پیامک', 'farazsms' ),
		__( 'ارسال پیامک', 'farazsms' ),
		'manage_options',
		'farazsms-send-sms',
		'farazsms_render_send_sms_page'
	);
}

// ============================================================================
// AJAX — Fetch accessible sender lines from FarazSMS panel
// ============================================================================

add_action( 'wp_ajax_farazsms_send_fetch_lines', 'farazsms_send_sms_ajax_fetch_lines' );
function farazsms_send_sms_ajax_fetch_lines() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز.', 'farazsms' ) ), 403 );
	}
	check_ajax_referer( 'farazsms_send_sms_admin', 'nonce' );

	$apikey = farazsms_get_apikey();
	if ( $apikey === '' ) {
		wp_send_json_error( array( 'message' => __( 'کلید دسترسی (Api-Key) در تنظیمات افزونه وارد نشده است.', 'farazsms' ) ) );
	}

	// Short transient cache — lines rarely change but admin may refresh.
	$cache_key = 'farazsms_send_lines_' . md5( $apikey );
	$cached    = get_transient( $cache_key );
	if ( $cached !== false && is_array( $cached ) ) {
		wp_send_json_success( array( 'lines' => $cached ) );
	}

	$response = farazsms_remote_get_with_fallback( farazsms_sms_api_url( 'lines/accessible' ), array(
			'headers' => array(
				'Accept'  => 'application/json',
				'Api-Key' => $apikey,
			),
			'timeout' => 15,
		) );

	$lines = array();
	if ( ! is_wp_error( $response ) && is_array( $response ) ) {
		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( is_array( $decoded ) && ( ! isset( $decoded['status'] ) || $decoded['status'] === 'success' ) ) {
			$data  = isset( $decoded['data'] ) ? $decoded['data'] : array();
			$items = array();
			if ( is_array( $data ) ) {
				if ( isset( $data['items'] ) && is_array( $data['items'] ) ) {
					$items = $data['items'];
				} elseif ( $data && array_values( $data ) === $data ) {
					$items = $data;
				}
			}
			foreach ( $items as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				$number = '';
				foreach ( array( 'line_number', 'lineNumber', 'number', 'line', 'value' ) as $k ) {
					if ( isset( $row[ $k ] ) && is_scalar( $row[ $k ] ) ) {
						$number = (string) $row[ $k ];
						break;
					}
				}
				if ( $number === '' ) {
					continue;
				}
				$title = '';
				foreach ( array( 'title', 'name', 'label', 'description' ) as $k ) {
					if ( isset( $row[ $k ] ) && is_scalar( $row[ $k ] ) ) {
						$title = (string) $row[ $k ];
						break;
					}
				}
				$is_dedicated = false;
				foreach ( array( 'is_dedicated', 'isDedicated', 'dedicated' ) as $k ) {
					if ( isset( $row[ $k ] ) ) {
						$is_dedicated = (bool) $row[ $k ];
						break;
					}
				}
				$lines[] = array(
					'number'       => $number,
					'title'        => $title !== '' ? $title : $number,
					'is_dedicated' => $is_dedicated,
				);
			}
		}
	}

	// خطِ اشتراکیِ PRO به‌عنوانِ گزینه‌ی پیش‌فرض بالای فهرست.
	// ⚠️ فقط وقتی پنل خودش آن را برنگردانده باشد؛ وگرنه کاربر دو ردیفِ «پرو» می‌بیند
	// (یکی این ردیفِ دستی با مقدارِ رشته‌ایِ PRO، یکی خطِ واقعیِ پنل با شماره‌ی خودش)
	// و نمی‌داند کدام را انتخاب کند.
	$has_pro = false;
	foreach ( $lines as $l ) {
		$num = strtoupper( trim( (string) ( $l['number'] ?? '' ) ) );
		if ( $num === 'PRO' || strpos( strtoupper( (string) ( $l['title'] ?? '' ) ), 'PRO' ) !== false ) {
			$has_pro = true;
			break;
		}
	}
	if ( ! $has_pro ) {
		$lines = array_merge( array(
			array(
				'number'       => 'PRO',
				'title'        => __( 'خط PRO (پیش‌فرض)', 'farazsms' ),
				'is_dedicated' => false,
			),
		), $lines );
	}

	// Cache for 1 hour.
	set_transient( $cache_key, $lines, HOUR_IN_SECONDS );

	wp_send_json_success( array( 'lines' => $lines ) );
}

// ============================================================================
// AJAX — Fetch phonebooks from FarazSMS panel
// ============================================================================

add_action( 'wp_ajax_farazsms_send_fetch_phonebooks', 'farazsms_send_sms_ajax_fetch_phonebooks' );
function farazsms_send_sms_ajax_fetch_phonebooks() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز.', 'farazsms' ) ), 403 );
	}
	check_ajax_referer( 'farazsms_send_sms_admin', 'nonce' );

	$apikey = farazsms_get_apikey();
	if ( $apikey === '' ) {
		wp_send_json_error( array( 'message' => __( 'کلید دسترسی (Api-Key) در تنظیمات افزونه وارد نشده است.', 'farazsms' ) ) );
	}

	// Cache result for 5 minutes to avoid hitting the API + counting endpoints on every page-load.
	$cache_key = 'farazsms_send_pbs_' . md5( $apikey );
	$cached    = get_transient( $cache_key );
	if ( $cached !== false && is_array( $cached ) ) {
		wp_send_json_success( array( 'phonebooks' => $cached ) );
	}

	// FarazSMS uses `/ws/v1/phone_book` (underscore), NOT `/phonebook`.
	$response = farazsms_remote_get_with_fallback( farazsms_sms_api_url( 'phone_book?limit=100' ), array(
			'headers' => array(
				'Accept'  => 'application/json',
				'Api-Key' => $apikey,
			),
			'timeout' => 15,
		) );

	if ( is_wp_error( $response ) || ! is_array( $response ) ) {
		wp_send_json_error( array( 'message' => __( 'خطا در ارتباط با سرور فراز.', 'farazsms' ) ) );
	}
	$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( ! is_array( $decoded ) ) {
		wp_send_json_error( array( 'message' => __( 'پاسخ سرور قابل پردازش نیست.', 'farazsms' ) ) );
	}
	if ( isset( $decoded['status'] ) && $decoded['status'] === 'error' ) {
		$msg = '';
		if ( isset( $decoded['messages'] ) ) {
			$msg = is_string( $decoded['messages'] ) ? $decoded['messages'] : ( is_array( $decoded['messages'] ) ? implode( '، ', array_filter( $decoded['messages'], 'is_string' ) ) : '' );
		}
		wp_send_json_error( array( 'message' => $msg !== '' ? $msg : __( 'خطای API.', 'farazsms' ) ) );
	}

	// Extract the items array — FarazSMS uses *multiple* shapes for the same endpoint:
	//   {data: {items: [...]}}      (docs)
	//   {data: {data: [...]}}       (actual)
	//   {data: [...]}               (occasional)
	//   {data: {phone_book: {data: [...]}}}  (some pagination wrappers)
	$data  = isset( $decoded['data'] ) ? $decoded['data'] : array();
	$items = array();
	if ( is_array( $data ) ) {
		if ( isset( $data['items'] ) && is_array( $data['items'] ) ) {
			$items = $data['items'];
		} elseif ( isset( $data['data'] ) && is_array( $data['data'] ) ) {
			$items = $data['data'];
		} elseif ( isset( $data['phone_book']['data'] ) && is_array( $data['phone_book']['data'] ) ) {
			$items = $data['phone_book']['data'];
		} elseif ( $data && array_values( $data ) === $data ) {
			$items = $data;
		}
	}

	// Normalize each phonebook row to {id, title, count}.
	$normalized = array();
	foreach ( $items as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$id = '';
		foreach ( array( 'id', 'phone_book_id', 'phonebook_id' ) as $k ) {
			if ( isset( $row[ $k ] ) ) { $id = (string) $row[ $k ]; break; }
		}
		$title = '';
		foreach ( array( 'title', 'name', 'label' ) as $k ) {
			if ( isset( $row[ $k ] ) && is_scalar( $row[ $k ] ) ) { $title = (string) $row[ $k ]; break; }
		}
		$count = null;
		// Direct count field — many possible names.
		foreach ( array( 'phone_book_data_count', 'phoneBookDataCount', 'data_count', 'contacts_count', 'contactsCount', 'members_count', 'count', 'total' ) as $k ) {
			if ( isset( $row[ $k ] ) && is_numeric( $row[ $k ] ) ) {
				$count = (int) $row[ $k ];
				break;
			}
		}
		if ( $id !== '' && $title !== '' ) {
			$normalized[] = array(
				'id'    => $id,
				'title' => $title,
				'count' => $count,
			);
		}
	}

	// If the list endpoint didn't include counts, fetch them in a second pass.
	// We cap to the first 50 phonebooks to keep things fast.
	$need_count = false;
	foreach ( $normalized as $pb ) {
		if ( $pb['count'] === null ) { $need_count = true; break; }
	}
	if ( $need_count ) {
		$max = min( 50, count( $normalized ) );
		for ( $i = 0; $i < $max; $i++ ) {
			if ( $normalized[ $i ]['count'] !== null ) {
				continue;
			}
			$normalized[ $i ]['count'] = farazsms_send_sms_fetch_phonebook_count( $normalized[ $i ]['id'], $apikey );
		}
	}

	set_transient( $cache_key, $normalized, 5 * MINUTE_IN_SECONDS );
	wp_send_json_success( array( 'phonebooks' => $normalized ) );
}

/**
 * Fetch the total contact count for a given phonebook by reading pagination
 * meta from `/phone_book_data?page=1&limit=1`. Returns null on failure.
 *
 * @param string $phonebook_id
 * @param string $apikey
 * @return int|null
 */
function farazsms_send_sms_fetch_phonebook_count( $phonebook_id, $apikey ) {
	$url = add_query_arg(
		array(
			'phone_book_id' => (int) $phonebook_id,
			'page'          => 1,
			'limit'         => 1,
		),
		farazsms_sms_api_url( 'phone_book_data' )
	);
	$response = farazsms_remote_get_with_fallback( $url, array(
			'headers' => array(
				'Accept'  => 'application/json',
				'Api-Key' => $apikey,
			),
			'timeout' => 10,
		) );
	if ( is_wp_error( $response ) || ! is_array( $response ) ) {
		return null;
	}
	$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( ! is_array( $decoded ) ) {
		return null;
	}
	$data = isset( $decoded['data'] ) ? $decoded['data'] : array();
	if ( ! is_array( $data ) ) {
		return null;
	}
	// Try the common pagination meta keys at various depths.
	$candidates = array();
	if ( isset( $data['phone_book_data'] ) && is_array( $data['phone_book_data'] ) ) {
		$candidates[] = $data['phone_book_data'];
	}
	$candidates[] = $data;
	foreach ( $candidates as $node ) {
		foreach ( array( 'total', 'totalItems', 'total_items', 'count', 'last_page' ) as $k ) {
			if ( isset( $node[ $k ] ) && is_numeric( $node[ $k ] ) ) {
				// `last_page` × limit isn't accurate (limit was 1) — actually it equals total when limit=1.
				return (int) $node[ $k ];
			}
		}
	}
	return null;
}

// ============================================================================
// AJAX — Recipient counts (for the "روش گیرنده" selector)
// ============================================================================

add_action( 'wp_ajax_farazsms_send_recipient_counts', 'farazsms_send_sms_ajax_recipient_counts' );
function farazsms_send_sms_ajax_recipient_counts() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز.', 'farazsms' ) ), 403 );
	}
	check_ajax_referer( 'farazsms_send_sms_admin', 'nonce' );

	global $wpdb;
	$newsletter = 0;
	$notify     = 0;
	if ( function_exists( 'farazsms_newsletter_table' ) ) {
		$t = farazsms_newsletter_table();
		$newsletter = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE status = %s", 'active' ) );
	}
	if ( function_exists( 'farazsms_notify_table' ) ) {
		$t = farazsms_notify_table();
		$notify = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE status = %s", 'pending' ) );
	}

	wp_send_json_success( array(
		'newsletter' => $newsletter,
		'notify'     => $notify,
	) );
}

// ============================================================================
// AJAX — Send SMS
// ============================================================================

add_action( 'wp_ajax_farazsms_send_sms_dispatch', 'farazsms_send_sms_ajax_dispatch' );
function farazsms_send_sms_ajax_dispatch() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز.', 'farazsms' ) ), 403 );
	}
	check_ajax_referer( 'farazsms_send_sms_admin', 'nonce' );

	$apikey = farazsms_get_apikey();
	if ( $apikey === '' ) {
		wp_send_json_error( array( 'message' => __( 'کلید دسترسی (Api-Key) در تنظیمات افزونه وارد نشده است.', 'farazsms' ) ) );
	}

	$source  = isset( $_POST['source'] )      ? sanitize_key( $_POST['source'] )                         : '';
	$message = isset( $_POST['message'] )     ? farazsms_sanitize_pattern_text( $_POST['message'] ) : '';
	$line    = isset( $_POST['line_number'] ) ? sanitize_text_field( wp_unslash( $_POST['line_number'] ) ) : 'PRO';

	// Bulk send is always free-text/simple — pattern SMS is per-recipient and not
	// supported for mass dispatch by the FarazSMS API.
	if ( $message === '' ) {
		wp_send_json_error( array( 'message' => __( 'متن پیامک خالی است.', 'farazsms' ) ) );
	}
	if ( $line === '' ) {
		$line = 'PRO';
	}

	// Collect recipients per source.
	$recipients = farazsms_send_sms_collect_recipients( $source, $apikey );
	if ( is_wp_error( $recipients ) ) {
		wp_send_json_error( array( 'message' => $recipients->get_error_message() ) );
	}
	if ( empty( $recipients ) ) {
		wp_send_json_error( array( 'message' => __( 'هیچ گیرنده‌ای یافت نشد.', 'farazsms' ) ) );
	}
	// Dedupe + cap to 10k per single dispatch to avoid runaway requests.
	$recipients = array_values( array_unique( $recipients ) );
	if ( count( $recipients ) > 10000 ) {
		$recipients = array_slice( $recipients, 0, 10000 );
	}

	$sent   = 0;
	$failed = 0;

	// Bulk simple SMS: chunked POSTs to /sms/simple of 100 recipients each.
	$chunks     = array_chunk( $recipients, 100 );
	$last_error = '';
	foreach ( $chunks as $chunk ) {
		$body = array(
			'line_number'   => $line,
			'recipients'    => $chunk,
			'text'          => $message,
			'number_format' => 'english',
			// طبقِ سندِ اندپوینت، schedule جزوِ فیلدهای required است (هرچند nullable).
			// نبودنش می‌تواند کلِ درخواست را رد کند.
			'schedule'      => null,
		);

		// ⚠️ از تنها نقطه‌ی خروجِ افزونه می‌رود (قانونِ پروژه): timeout اجباری،
		// fallback و نگهبانِ اتصال. نسخه‌ی قبلی درخواست را دستی می‌ساخت و از این
		// لایه دور می‌زد.
		$response = farazsms_sms_request( 'POST', 'sms/simple', array(
			'body'    => $body,
			'apikey'  => $apikey,
			'timeout' => 30,
		) );

		$err = '';
		if ( is_wp_error( $response ) ) {
			$err = $response->get_error_message();
		} else {
			$decoded = farazsms_sms_decode( $response );
			if ( is_array( $decoded ) && isset( $decoded['status'] ) && $decoded['status'] === 'success' ) {
				$sent += count( $chunk );
				// کانالِ بله (MVP): همان متنِ آزادِ گروهی در بله هم برود (متنِ حل‌شده موجود است).
				farazsms_bale_maybe_send( 'bulk', $chunk, $message );
				continue;
			}
			$msg = is_array( $decoded ) && isset( $decoded['message'] ) ? $decoded['message'] : '';
			if ( $msg === '' ) {
				$msg = (string) wp_remote_retrieve_body( $response );
			}
			$err = farazsms_flatten_api_message( $msg );
		}

		$failed    += count( $chunk );
		$last_error = $err !== '' ? $err : __( 'پاسخِ نامعتبر از سرویس', 'farazsms' );

		// ⚠️ بدونِ این لاگ، شکستِ ارسالِ گروهی هیچ ردی نمی‌گذاشت و کاربر فقط
		// «ناموفق: N» می‌دید بدونِ اینکه بداند چرا (خط، اعتبار، یا متن).
		farazsms_send_diag_log( 'bulk', $line, 'api_error:' . $last_error, array(
			'source'    => 'send-sms-bulk',
			'http_code' => is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response ),
			'detail'    => 'line=' . $line . ' recipients=' . count( $chunk ),
		) );
	}

	// Log the dispatch.
	global $wpdb;
	$wpdb->insert(
		farazsms_send_log_table(),
		array(
			'source'           => $source,
			'mode'             => 'simple',
			'pattern_code'     => $line,
			'message_text'     => $message,
			'recipients_count' => count( $recipients ),
			'sent_count'       => $sent,
			'failed_count'     => $failed,
			'user_id'          => get_current_user_id(),
			'created_at'       => current_time( 'mysql' ),
		),
		array( '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s' )
	);

	$summary = sprintf(
		/* translators: 1 sent count, 2 failed count, 3 total */
		__( 'ارسال انجام شد — موفق: %1$s، ناموفق: %2$s، کل گیرندگان: %3$s', 'farazsms' ),
		number_format_i18n( $sent ),
		number_format_i18n( $failed ),
		number_format_i18n( count( $recipients ) )
	);
	// علتِ شکست باید دیده شود، وگرنه کاربر فقط «ناموفق» می‌بیند و راهی برای رفع ندارد.
	if ( $failed > 0 && $last_error !== '' ) {
		$summary .= ' — ' . sprintf(
			/* translators: %s: service error text */
			__( 'خطای سرویس: %s', 'farazsms' ),
			$last_error
		);
	}

	wp_send_json_success( array(
		'message' => $summary,
		'error'   => $last_error,
		'sent'         => $sent,
		'failed'       => $failed,
		'total'        => count( $recipients ),
	) );
}

/**
 * Collect mobile recipients for the given source. Returns array of
 * normalized 11-digit `09xxxxxxxxx` strings or WP_Error.
 *
 * @param string $source
 * @param string $apikey
 * @return array|WP_Error
 */
function farazsms_send_sms_collect_recipients( $source, $apikey ) {
	switch ( $source ) {
		case 'manual':
			$raw = isset( $_POST['manual_mobiles'] ) ? wp_unslash( $_POST['manual_mobiles'] ) : '';
			return farazsms_send_sms_parse_manual_mobiles( $raw );

		case 'newsletter':
			if ( ! function_exists( 'farazsms_newsletter_table' ) ) {
				return new WP_Error( 'unavailable', __( 'ماژول خبرنامه فعال نیست.', 'farazsms' ) );
			}
			global $wpdb;
			$t    = farazsms_newsletter_table();
			$rows = $wpdb->get_col( $wpdb->prepare( "SELECT mobile FROM $t WHERE status = %s", 'active' ) );
			return is_array( $rows ) ? array_values( array_filter( $rows ) ) : array();

		case 'notify':
			if ( ! function_exists( 'farazsms_notify_table' ) ) {
				return new WP_Error( 'unavailable', __( 'ماژول موجود شد خبرم کن فعال نیست.', 'farazsms' ) );
			}
			global $wpdb;
			$t    = farazsms_notify_table();
			$rows = $wpdb->get_col( $wpdb->prepare( "SELECT mobile FROM $t WHERE status = %s", 'pending' ) );
			return is_array( $rows ) ? array_values( array_filter( $rows ) ) : array();

		case 'phonebook':
			$pb_id = isset( $_POST['phonebook_id'] ) ? sanitize_text_field( wp_unslash( $_POST['phonebook_id'] ) ) : '';
			if ( $pb_id === '' ) {
				return new WP_Error( 'no_phonebook', __( 'باشگاه مشتریان انتخاب نشده.', 'farazsms' ) );
			}
			return farazsms_send_sms_fetch_phonebook_recipients( $pb_id, $apikey );

		default:
			return new WP_Error( 'invalid_source', __( 'منبع گیرنده نامعتبر است.', 'farazsms' ) );
	}
}

/**
 * Parse manually-entered mobile list (paste). Accepts newline, comma, semicolon,
 * or space separated. Normalizes each, drops invalid ones.
 *
 * @param string $raw
 * @return array
 */
function farazsms_send_sms_parse_manual_mobiles( $raw ) {
	$raw = (string) $raw;
	$raw = farazsms_tr_num( $raw );
	$tokens = preg_split( '/[\s,;]+/', $raw );
	$out    = array();
	$normalizer = function_exists( 'farazsms_newsletter_normalize_mobile' )
		? 'farazsms_newsletter_normalize_mobile'
		: null;
	foreach ( (array) $tokens as $t ) {
		$t = trim( (string) $t );
		if ( $t === '' ) continue;
		$norm = $normalizer ? call_user_func( $normalizer, $t ) : $t;
		if ( $norm !== '' ) {
			$out[] = $norm;
		}
	}
	return array_values( array_unique( $out ) );
}

/**
 * Fetch all contact mobiles from a phonebook in the FarazSMS panel.
 * Paginates through the API up to a soft cap of 10,000 mobiles.
 *
 * @param string $phonebook_id
 * @param string $apikey
 * @return array|WP_Error
 */
function farazsms_send_sms_fetch_phonebook_recipients( $phonebook_id, $apikey ) {
	$mobiles   = array();
	$page      = 1;
	$per_page  = 200;
	$hard_cap  = 10000;
	$last_page = 0;

	while ( true ) {
		// FarazSMS uses `/ws/v1/phone_book_data?phone_book_id={id}` (NOT a `/phonebook/{id}/contacts` path).
		$url = add_query_arg(
			array(
				'phone_book_id' => (int) $phonebook_id,
				'page'          => $page,
				'limit'         => $per_page,
			),
			farazsms_sms_api_url( 'phone_book_data' )
		);
		$response = farazsms_remote_get_with_fallback( $url, array(
				'headers' => array(
					'Accept'  => 'application/json',
					'Api-Key' => $apikey,
				),
				'timeout' => 15,
			) );
		if ( is_wp_error( $response ) || ! is_array( $response ) ) {
			return new WP_Error( 'http', __( 'خطا در ارتباط با سرور فراز.', 'farazsms' ) );
		}
		$decoded = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $decoded ) ) {
			return new WP_Error( 'parse', __( 'پاسخ سرور قابل پردازش نیست.', 'farazsms' ) );
		}
		if ( isset( $decoded['status'] ) && $decoded['status'] === 'error' ) {
			$msg = isset( $decoded['messages'] ) && is_string( $decoded['messages'] ) ? $decoded['messages'] : __( 'خطای API.', 'farazsms' );
			return new WP_Error( 'api', $msg );
		}

		$data  = isset( $decoded['data'] ) ? $decoded['data'] : array();
		// `phone_book_data` endpoint nests items inside `data.phone_book_data.data[]`,
		// and pagination meta at the same level (`last_page`, `total`).
		$items = array();
		if ( is_array( $data ) ) {
			if ( isset( $data['phone_book_data']['data'] ) && is_array( $data['phone_book_data']['data'] ) ) {
				$items = $data['phone_book_data']['data'];
				if ( isset( $data['phone_book_data']['last_page'] ) ) {
					$last_page = (int) $data['phone_book_data']['last_page'];
				}
			} elseif ( isset( $data['data'] ) && is_array( $data['data'] ) ) {
				$items = $data['data'];
				if ( isset( $data['last_page'] ) ) {
					$last_page = (int) $data['last_page'];
				}
			} elseif ( isset( $data['items'] ) && is_array( $data['items'] ) ) {
				$items = $data['items'];
			} elseif ( $data && array_values( $data ) === $data ) {
				$items = $data;
			}
		}
		if ( empty( $items ) ) {
			break;
		}
		foreach ( $items as $row ) {
			if ( ! is_array( $row ) ) continue;
			$mobile = '';
			foreach ( array( 'mobile', 'mobile_number', 'mobileNumber', 'phone', 'phone_number', 'msisdn', 'number' ) as $k ) {
				if ( isset( $row[ $k ] ) && is_scalar( $row[ $k ] ) ) {
					$mobile = (string) $row[ $k ];
					break;
				}
			}
			if ( $mobile === '' ) continue;
			$norm = function_exists( 'farazsms_newsletter_normalize_mobile' )
				? farazsms_newsletter_normalize_mobile( $mobile )
				: $mobile;
			if ( $norm !== '' ) {
				$mobiles[] = $norm;
			}
			if ( count( $mobiles ) >= $hard_cap ) break 2;
		}
		// Pagination — prefer the API-reported last_page when available.
		if ( $last_page > 0 ) {
			if ( $page >= $last_page ) {
				break;
			}
		} elseif ( count( $items ) < $per_page ) {
			break;
		}
		$page++;
		if ( $page > 60 ) {
			break; // safety net
		}
	}
	return array_values( array_unique( $mobiles ) );
}

// ============================================================================
// Admin page render
// ============================================================================

function farazsms_render_send_sms_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	farazsms_send_sms_maybe_setup_table();

	$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'compose';
	$tab = in_array( $tab, array( 'compose', 'history' ), true ) ? $tab : 'compose';

	echo '<section class="wrapper farazsms-send-sms-wrapper">';
	farazsms_send_sms_render_header();
	farazsms_send_sms_render_tabs( $tab );
	if ( $tab === 'history' ) {
		farazsms_send_sms_render_history_tab();
	} else {
		farazsms_send_sms_render_compose_tab();
	}
	farazsms_send_sms_render_inline();
	echo '</section>';
}

function farazsms_send_sms_render_header() {
	$apikey = farazsms_get_apikey();
	?>
	<div id="farazsms_header">
		<div>
			<a href="https://farazsms.com" target="_blank" rel="noopener">
				<img src="<?php echo esc_url( FARAZSMS_CORE_IMG . 'logo-1.png' ); ?>" alt="<?php esc_attr_e( 'فراز اس‌ام‌اس', 'farazsms' ); ?>">
			</a>
		</div>
		<?php if ( ! empty( $apikey ) ) : ?>
			<div id="farazsms_account_info">
				<div class="farazsms_credit_amount">
					<span><?php esc_html_e( 'میزان اعتبار: ', 'farazsms' ); ?></span>
					<?php echo esc_html( (string) farazsms_get_credit() ); ?>
					<span> <?php esc_html_e( 'تومان', 'farazsms' ); ?></span>
				</div>
				<?php if ( function_exists( 'farazsms_render_profile_block' ) ) { farazsms_render_profile_block(); } ?>
			</div>
		<?php endif; ?>
	</div>
	<h1 class="farazsms-send-sms-title-main"><?php esc_html_e( 'ارسال پیامک', 'farazsms' ); ?></h1>
	<?php if ( empty( $apikey ) ) : ?>
		<div class="notice notice-warning">
			<p>
				<?php
				printf(
					/* translators: %s settings page link */
					esc_html__( 'برای ارسال پیامک باید ابتدا کلید دسترسی (Api-Key) را در %s وارد کنید.', 'farazsms' ),
					'<a href="' . esc_url( admin_url( 'admin.php?page=farazsms-settings' ) ) . '">' . esc_html__( 'تنظیمات افزونه', 'farazsms' ) . '</a>'
				);
				?>
			</p>
		</div>
	<?php endif; ?>
	<?php
}

function farazsms_send_sms_render_tabs( $active ) {
	$tabs = array(
		'compose' => __( 'ارسال جدید', 'farazsms' ),
		'history' => __( 'تاریخچه ارسال‌ها', 'farazsms' ),
	);
	?>
	<nav class="farazsms-send-sms-tabs">
		<?php foreach ( $tabs as $key => $label ) :
			$url = add_query_arg( array( 'page' => 'farazsms-send-sms', 'tab' => $key ), admin_url( 'admin.php' ) );
		?>
			<a class="farazsms-send-sms-tab <?php echo $active === $key ? 'is-active' : ''; ?>" href="<?php echo esc_url( $url ); ?>">
				<?php echo esc_html( $label ); ?>
			</a>
		<?php endforeach; ?>
	</nav>
	<?php
}

function farazsms_send_sms_render_compose_tab() {
	?>
	<form id="farazsms-send-sms-form" class="farazsms-send-sms-card">
		<?php wp_nonce_field( 'farazsms_send_sms_admin', 'farazsms_send_sms_admin_nonce' ); ?>

		<!-- Step 1: Recipients -->
		<section class="farazsms-send-sms-step">
			<h2 class="farazsms-send-sms-step-title"><span class="step-num">۱</span> <?php esc_html_e( 'انتخاب گیرندگان', 'farazsms' ); ?></h2>

			<div class="farazsms-send-sms-source-grid">
				<label class="farazsms-send-sms-source-card">
					<input type="radio" name="source" value="manual" checked>
					<div class="farazsms-source-body">
						<div class="farazsms-source-title"><?php esc_html_e( 'وارد کردن دستی', 'farazsms' ); ?></div>
						<div class="farazsms-source-help"><?php esc_html_e( 'کپی شماره‌ها — جدا با ویرگول، فاصله یا خط جدید', 'farazsms' ); ?></div>
					</div>
				</label>
				<label class="farazsms-send-sms-source-card">
					<input type="radio" name="source" value="newsletter">
					<div class="farazsms-source-body">
						<div class="farazsms-source-title"><?php esc_html_e( 'مشترکین خبرنامه', 'farazsms' ); ?></div>
						<div class="farazsms-source-help farazsms-count-newsletter"><?php esc_html_e( 'در حال محاسبه...', 'farazsms' ); ?></div>
					</div>
				</label>
				<label class="farazsms-send-sms-source-card">
					<input type="radio" name="source" value="notify">
					<div class="farazsms-source-body">
						<div class="farazsms-source-title"><?php esc_html_e( 'موجود شد خبرم کن', 'farazsms' ); ?></div>
						<div class="farazsms-source-help farazsms-count-notify"><?php esc_html_e( 'در حال محاسبه...', 'farazsms' ); ?></div>
					</div>
				</label>
				<label class="farazsms-send-sms-source-card">
					<input type="radio" name="source" value="phonebook">
					<div class="farazsms-source-body">
						<div class="farazsms-source-title"><?php esc_html_e( 'دفترچه تلفن پنل پیامکی', 'farazsms' ); ?></div>
						<div class="farazsms-source-help"><?php esc_html_e( 'انتخاب از دفترچه‌های ذخیره‌شده در پنل فراز', 'farazsms' ); ?></div>
					</div>
				</label>
			</div>

			<div class="farazsms-source-panel farazsms-source-manual">
				<label class="farazsms-send-sms-field">
					<span><?php esc_html_e( 'شماره موبایل‌ها:', 'farazsms' ); ?></span>
					<textarea name="manual_mobiles" rows="6" placeholder="<?php esc_attr_e( '09121234567&#10;09127654321&#10;...', 'farazsms' ); ?>"></textarea>
				</label>
				<p class="farazsms-send-sms-help-small farazsms-manual-counter"></p>
			</div>

			<div class="farazsms-source-panel farazsms-source-phonebook" hidden>
				<label class="farazsms-send-sms-field">
					<span><?php esc_html_e( 'انتخاب دفترچه تلفن:', 'farazsms' ); ?></span>
					<select name="phonebook_id">
						<option value=""><?php esc_html_e( 'در حال بارگذاری...', 'farazsms' ); ?></option>
					</select>
				</label>
				<p class="farazsms-send-sms-help-small farazsms-phonebook-info">
					<?php esc_html_e( 'لیست دفترچه‌ها به همراه تعداد اعضای هر کدام از پنل فراز خوانده می‌شود. پیامک به همه اعضای دفترچه‌ی انتخاب‌شده ارسال خواهد شد.', 'farazsms' ); ?>
				</p>
			</div>
		</section>

		<!-- Step 2: Sender line -->
		<section class="farazsms-send-sms-step">
			<h2 class="farazsms-send-sms-step-title"><span class="step-num">۲</span> <?php esc_html_e( 'خط ارسال‌کننده', 'farazsms' ); ?></h2>

			<label class="farazsms-send-sms-field farazsms-send-sms-line-field">
				<span><?php esc_html_e( 'خط:', 'farazsms' ); ?></span>
				<select name="line_number" dir="ltr">
					<option value="PRO"><?php esc_html_e( 'خط PRO (پیش‌فرض)', 'farazsms' ); ?></option>
				</select>
			</label>
			<p class="farazsms-send-sms-help-small"><?php esc_html_e( 'لیست خطوط در دسترس شما از پنل فراز اس‌ام‌اس خوانده می‌شود. اگر خط اختصاصی ندارید، خط PRO پیش‌فرض است.', 'farazsms' ); ?></p>
		</section>

		<!-- Step 3: Message -->
		<section class="farazsms-send-sms-step">
			<h2 class="farazsms-send-sms-step-title"><span class="step-num">۳</span> <?php esc_html_e( 'متن پیامک', 'farazsms' ); ?></h2>

			<label class="farazsms-send-sms-field">
				<span><?php esc_html_e( 'متن پیامک:', 'farazsms' ); ?></span>
				<textarea name="message" rows="5" maxlength="500" placeholder="<?php esc_attr_e( 'متن پیامک را اینجا بنویسید...', 'farazsms' ); ?>"></textarea>
			</label>
			<p class="farazsms-send-sms-help-small">
				<span class="farazsms-text-counter">۰</span> / ۵۰۰ <?php esc_html_e( 'کاراکتر', 'farazsms' ); ?>
				— <?php esc_html_e( 'ارسال انبوه فقط با متن آزاد امکان‌پذیر است (متن نیاز به تأیید ناظر در پنل فراز دارد).', 'farazsms' ); ?>
			</p>
		</section>

		<!-- Step 4: Send -->
		<section class="farazsms-send-sms-step">
			<h2 class="farazsms-send-sms-step-title"><span class="step-num">۴</span> <?php esc_html_e( 'ارسال', 'farazsms' ); ?></h2>

			<div class="farazsms-send-sms-actions">
				<button type="submit" class="button button-primary button-hero farazsms-send-submit"><?php esc_html_e( 'ارسال پیامک', 'farazsms' ); ?></button>
				<span class="farazsms-send-sms-result" role="status" aria-live="polite"></span>
			</div>
		</section>
	</form>
	<?php
}

function farazsms_send_sms_render_history_tab() {
	global $wpdb;
	$table = farazsms_send_log_table();

	$page  = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;
	$limit = 25;
	$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
	$total_pages = max( 1, (int) ceil( $total / $limit ) );
	$offset = ( $page - 1 ) * $limit;

	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table ORDER BY id DESC LIMIT %d OFFSET %d", $limit, $offset ), ARRAY_A );

	$source_labels = array(
		'manual'     => __( 'وارد شده دستی', 'farazsms' ),
		'newsletter' => __( 'خبرنامه', 'farazsms' ),
		'notify'     => __( 'موجود شد خبرم کن', 'farazsms' ),
		'phonebook'  => __( 'باشگاه مشتریان', 'farazsms' ),
	);
	?>
	<div class="farazsms-send-sms-card">
		<h2><?php esc_html_e( 'تاریخچه ارسال‌ها', 'farazsms' ); ?></h2>

		<table class="widefat striped farazsms-send-sms-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'شناسه', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'تاریخ', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'منبع', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'خط ارسال', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'متن پیامک', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'گیرندگان', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'موفق', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'ناموفق', 'farazsms' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $rows ) ) : ?>
					<tr><td colspan="8"><?php esc_html_e( 'هنوز هیچ ارسالی انجام نشده.', 'farazsms' ); ?></td></tr>
				<?php else : foreach ( $rows as $r ) :
					$jdate  = farazsms_send_reports_to_jalali( $r['created_at'] );
					$source = isset( $source_labels[ $r['source'] ] ) ? $source_labels[ $r['source'] ] : $r['source'];
					// `pattern_code` column is reused to store the line number for simple SMS.
					$line   = $r['pattern_code'] !== '' ? $r['pattern_code'] : '—';
					$content = $r['message_text'];
					$content_short = mb_substr( (string) $content, 0, 80 );
					if ( mb_strlen( (string) $content ) > 80 ) {
						$content_short .= '…';
					}
				?>
					<tr>
						<td><?php echo esc_html( $r['id'] ); ?></td>
						<td class="farazsms-send-sms-date-cell"><?php echo esc_html( $jdate ); ?></td>
						<td><?php echo esc_html( $source ); ?></td>
						<td dir="ltr"><?php echo esc_html( $line ); ?></td>
						<td class="farazsms-send-sms-content-cell" title="<?php echo esc_attr( $content ); ?>"><?php echo esc_html( $content_short ); ?></td>
						<td><?php echo esc_html( number_format_i18n( (int) $r['recipients_count'] ) ); ?></td>
						<td><span class="farazsms-status farazsms-status-success"><?php echo esc_html( number_format_i18n( (int) $r['sent_count'] ) ); ?></span></td>
						<td><span class="farazsms-status farazsms-status-<?php echo (int) $r['failed_count'] > 0 ? 'danger' : 'muted'; ?>"><?php echo esc_html( number_format_i18n( (int) $r['failed_count'] ) ); ?></span></td>
					</tr>
				<?php endforeach; endif; ?>
			</tbody>
		</table>

		<?php if ( $total_pages > 1 ) :
			$base = add_query_arg( array( 'page' => 'farazsms-send-sms', 'tab' => 'history' ), admin_url( 'admin.php' ) );
			?>
			<div class="farazsms-send-sms-pagination">
				<?php if ( $page > 1 ) : ?>
					<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $page - 1, $base ) ); ?>">« <?php esc_html_e( 'صفحه قبل', 'farazsms' ); ?></a>
				<?php endif; ?>
				<span><?php printf( esc_html__( 'صفحه %1$s از %2$s', 'farazsms' ), esc_html( number_format_i18n( $page ) ), esc_html( number_format_i18n( $total_pages ) ) ); ?></span>
				<?php if ( $page < $total_pages ) : ?>
					<a class="button" href="<?php echo esc_url( add_query_arg( 'paged', $page + 1, $base ) ); ?>"><?php esc_html_e( 'صفحه بعد', 'farazsms' ); ?> »</a>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</div>
	<?php
}

function farazsms_send_sms_render_inline() {
	$nonce   = wp_create_nonce( 'farazsms_send_sms_admin' );
	$ajaxUrl = admin_url( 'admin-ajax.php' );
	?>
	<style>
	.farazsms-send-sms-wrapper .farazsms-send-sms-title-main { margin: 16px 0 8px; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-tabs { display: flex; gap: 4px; border-bottom: 1px solid #c3c4c7; margin: 16px 0 20px; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-tab { padding: 10px 18px; text-decoration: none; color: #4d4d4d; background: #f1f1f1; border: 1px solid #c3c4c7; border-bottom: 0; border-radius: 6px 6px 0 0; margin-bottom: -1px; font-size: 13px; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-tab.is-active { background: #fff; color: #1d2327; font-weight: 600; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-card { background: #fff; padding: 24px 28px; border: 1px solid #e1e1e1; border-radius: 10px; max-width: 880px; box-shadow: 0 1px 2px rgba(0,0,0,0.03); }
	.farazsms-send-sms-wrapper .farazsms-send-sms-card h2 { margin: 0 0 12px; font-size: 16px; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-step { padding: 18px 0; border-bottom: 1px dashed #e1e1e1; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-step:last-child { border-bottom: 0; padding-bottom: 0; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-step-title { margin: 0 0 14px; font-size: 15px; font-weight: 600; color: #263f67; display: flex; align-items: center; gap: 10px; }
	.farazsms-send-sms-wrapper .step-num { display: inline-flex; width: 26px; height: 26px; align-items: center; justify-content: center; background: #4571ba; color: #fff; border-radius: 50%; font-size: 13px; font-weight: 700; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-source-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; margin-bottom: 14px; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-source-card { display: flex; align-items: start; gap: 10px; padding: 12px 14px; border: 1px solid #d1d5db; border-radius: 8px; cursor: pointer; transition: border-color .15s, background .15s; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-source-card:hover { border-color: #4571ba; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-source-card input[type="radio"] { margin-top: 4px; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-source-card:has(input:checked) { border-color: #4571ba; background: #eaeff7; }
	.farazsms-send-sms-wrapper .farazsms-source-title { font-weight: 600; font-size: 13px; color: #263f67; }
	.farazsms-send-sms-wrapper .farazsms-source-help { font-size: 12px; color: #9b9b9b; margin-top: 2px; }
	.farazsms-send-sms-wrapper .farazsms-source-panel { padding: 12px 0 0; }
	.farazsms-send-sms-wrapper .farazsms-source-panel[hidden] { display: none !important; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-field { display: flex; flex-direction: column; gap: 5px; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-field span { font-size: 12px; color: #4d4d4d; font-weight: 500; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-field input,
	.farazsms-send-sms-wrapper .farazsms-send-sms-field select,
	.farazsms-send-sms-wrapper .farazsms-send-sms-field textarea { width: 100%; max-width: 600px; padding: 9px 12px; border: 1px solid #d1d5db; border-radius: 6px; font-size: 14px; box-sizing: border-box; font-family: inherit; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-field textarea { resize: vertical; min-height: 90px; line-height: 1.7; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-fieldset { border: 1px solid #e1e1e1; border-radius: 6px; padding: 8px 14px; margin: 0 0 14px; max-width: 400px; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-fieldset legend { font-weight: 600; font-size: 13px; padding: 0 6px; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-fieldset label { margin-left: 16px; font-size: 13px; }
	.farazsms-send-sms-wrapper .farazsms-mode-panel[hidden] { display: none !important; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-help-small { color: #9b9b9b; font-size: 12px; margin: 4px 0 0; }
	.farazsms-send-sms-wrapper .farazsms-text-counter { font-weight: 600; color: #263f67; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-actions { display: flex; align-items: center; gap: 14px; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-result { font-size: 13px; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-result.success { color: #0c9765; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-result.error { color: #b32817; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-table th,
	.farazsms-send-sms-wrapper .farazsms-send-sms-table td { padding: 10px 12px; vertical-align: middle; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-date-cell { direction: ltr; font-variant-numeric: tabular-nums; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-content-cell { max-width: 320px; }
	.farazsms-send-sms-wrapper .farazsms-send-sms-pagination { display: flex; gap: 8px; align-items: center; margin-top: 14px; }
	.farazsms-send-sms-wrapper .farazsms-status { display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: 12px; }
	.farazsms-send-sms-wrapper .farazsms-status-success { background: #e2f8f0; color: #096d49; }
	.farazsms-send-sms-wrapper .farazsms-status-danger  { background: #ffd7d7; color: #8a0a0a; }
	.farazsms-send-sms-wrapper .farazsms-status-muted   { background: #e0e0e0; color: #4d4d4d; }
	@media (max-width: 720px) {
		.farazsms-send-sms-wrapper .farazsms-send-sms-source-grid { grid-template-columns: 1fr; }
	}
	</style>
	<script>
	(function(){
		var ajaxUrl = <?php echo wp_json_encode( $ajaxUrl ); ?>;
		var nonce   = <?php echo wp_json_encode( $nonce ); ?>;
		var form    = document.getElementById('farazsms-send-sms-form');
		if (!form) return;

		var sources  = form.querySelectorAll('input[name="source"]');
		var panels   = {
			manual:     form.querySelector('.farazsms-source-manual'),
			phonebook:  form.querySelector('.farazsms-source-phonebook')
		};

		// Toggle source-panel visibility based on the selected source.
		function refreshSourcePanels() {
			var picked = (form.querySelector('input[name="source"]:checked') || {}).value || 'manual';
			Object.keys(panels).forEach(function(k){
				if (panels[k]) {
					if (k === picked) panels[k].removeAttribute('hidden');
					else panels[k].setAttribute('hidden','');
				}
			});
			if (picked === 'phonebook') loadPhonebooks();
		}
		sources.forEach(function(r){ r.addEventListener('change', refreshSourcePanels); });
		refreshSourcePanels();

		// Character counter for the message textarea.
		var msgArea = form.querySelector('textarea[name="message"]');
		var msgCounter = form.querySelector('.farazsms-text-counter');
		if (msgArea && msgCounter) {
			msgArea.addEventListener('input', function(){
				msgCounter.textContent = String(msgArea.value.length);
			});
		}

		// Manual mobiles — live count of valid lines.
		var manualArea = form.querySelector('textarea[name="manual_mobiles"]');
		var manualCounter = form.querySelector('.farazsms-manual-counter');
		function countManualMobiles(){
			if (!manualArea || !manualCounter) return;
			var raw = manualArea.value
				.replace(/[۰-۹]/g, function(d){ return String.fromCharCode(d.charCodeAt(0)-0x06C0); }); // Persian → ASCII digits
			var tokens = raw.split(/[\s,;]+/);
			var ok = 0;
			tokens.forEach(function(t){
				t = t.replace(/\D+/g, '');
				if (/^0?9\d{9}$/.test(t)) ok++;
			});
			manualCounter.textContent = ok > 0 ? (ok + ' شماره معتبر شناسایی شد') : '';
		}
		if (manualArea) manualArea.addEventListener('input', countManualMobiles);

		// Source counts (newsletter, notify) — fetch once on load.
		fetch(ajaxUrl + '?action=farazsms_send_recipient_counts&nonce=' + encodeURIComponent(nonce), { credentials: 'same-origin' })
			.then(function(r){ return r.json(); })
			.then(function(json){
				if (!json.success) return;
				var nl = form.querySelector('.farazsms-count-newsletter');
				var nf = form.querySelector('.farazsms-count-notify');
				if (nl) nl.textContent = (json.data.newsletter || 0) + ' مشترک فعال';
				if (nf) nf.textContent = (json.data.notify || 0) + ' درخواست در انتظار';
			});

		// Sender lines — fetch the user's accessible lines from the FarazSMS panel.
		var lineSelect = form.querySelector('select[name="line_number"]');
		if (lineSelect) {
			var fd = new FormData();
			fd.append('action', 'farazsms_send_fetch_lines');
			fd.append('nonce', nonce);
			fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
				.then(function(r){ return r.json(); })
				.then(function(json){
					if (!json.success || !json.data || !Array.isArray(json.data.lines)) return;
					var current = lineSelect.value;
					var html = '';
					json.data.lines.forEach(function(line){
						var label = line.title || line.number;
						if (line.is_dedicated && line.number !== 'PRO') label += ' • اختصاصی';
						html += '<option value="' + String(line.number).replace(/"/g, '&quot;') + '">' + label + '</option>';
					});
					if (html) {
						lineSelect.innerHTML = html;
						// Default to PRO unless the user already changed it.
						if (current === 'PRO' || current === '') {
							lineSelect.value = 'PRO';
						}
					}
				});
		}

		// Phonebooks loader + selected-count display.
		var phonebooksLoaded = false;
		var phonebookData = {}; // id -> count map
		function loadPhonebooks() {
			if (phonebooksLoaded) return;
			phonebooksLoaded = true;
			var select = form.querySelector('select[name="phonebook_id"]');
			var info   = form.querySelector('.farazsms-phonebook-info');
			if (!select) return;
			var fd = new FormData();
			fd.append('action', 'farazsms_send_fetch_phonebooks');
			fd.append('nonce', nonce);
			fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
				.then(function(r){ return r.json(); })
				.then(function(json){
					if (!json.success) {
						select.innerHTML = '<option value="">' + ((json.data && json.data.message) || 'خطا در بارگذاری') + '</option>';
						return;
					}
					var pbs = (json.data && json.data.phonebooks) || [];
					if (pbs.length === 0) {
						select.innerHTML = '<option value="">هیچ دفترچه‌ای یافت نشد</option>';
						return;
					}
					var html = '<option value="">— یک دفترچه انتخاب کنید —</option>';
					pbs.forEach(function(pb){
						phonebookData[String(pb.id)] = pb;
						var label = pb.title + (pb.count !== null && pb.count !== undefined ? ' — ' + pb.count + ' نفر' : '');
						html += '<option value="' + pb.id + '">' + label + '</option>';
					});
					select.innerHTML = html;
				})
				.catch(function(){
					select.innerHTML = '<option value="">خطا در ارتباط با سرور</option>';
					phonebooksLoaded = false;
				});

			// When user selects a phonebook, show the count below.
			select.addEventListener('change', function(){
				if (!info) return;
				var pb = phonebookData[select.value];
				if (pb && pb.count !== null && pb.count !== undefined) {
					info.innerHTML = '<strong>' + pb.count + '</strong> نفر در این دفترچه عضو هستند. پیامک به همه آن‌ها ارسال خواهد شد.';
				} else if (pb) {
					info.textContent = 'پیامک به همه اعضای این دفترچه ارسال می‌شود.';
				} else {
					info.textContent = 'لیست دفترچه‌ها به همراه تعداد اعضای هر کدام از پنل فراز خوانده می‌شود. پیامک به همه اعضای دفترچه‌ی انتخاب‌شده ارسال خواهد شد.';
				}
			});
		}

		// Submit handler.
		form.addEventListener('submit', function(ev){
			ev.preventDefault();
			if (!confirm('ارسال پیامک به همه گیرندگان انتخاب‌شده — مطمئن هستید؟')) return;
			var btn = form.querySelector('.farazsms-send-submit');
			var result = form.querySelector('.farazsms-send-sms-result');
			var fd = new FormData(form);
			fd.append('action', 'farazsms_send_sms_dispatch');
			fd.append('nonce', nonce);
			btn.disabled = true;
			result.className = 'farazsms-send-sms-result';
			result.textContent = 'در حال ارسال...';
			fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
				.then(function(r){ return r.json(); })
				.then(function(json){
					result.className = 'farazsms-send-sms-result ' + (json.success ? 'success' : 'error');
					result.textContent = (json.data && json.data.message) || 'انجام شد.';
				})
				.catch(function(){
					result.className = 'farazsms-send-sms-result error';
					result.textContent = 'خطا در ارتباط با سرور.';
				})
				.then(function(){ btn.disabled = false; });
		});
	})();
	</script>
	<?php
}
