<?php
/**
 * ویزاردِ شروع (Onboarding) — کارتِ چک‌لیستِ context-aware روی داشبورد.
 *
 * طبقِ اسپاین‌های UX (DESIGN.md + EXPERIENCE.md، ۲۰۲۶-۰۶-۱۶):
 *  - هدف: کاربرِ کم‌تکنیکال در اولین دیدار حس کند «از پسش برمی‌آیم».
 *  - چک‌لیستِ «X از N» با تشخیصِ خودکارِ انجام‌شدن از دادهٔ واقعی (نه «دیدم»).
 *  - قدم‌ها وابسته به استکِ نصب‌شده‌اند (قدمِ بی‌معنی نمی‌آید).
 *  - خطِ ارسال: کشوییِ تنبل از وب‌سرویس (lines/accessible) با پیش‌فرضِ 90008361.
 *  - قابلِ‌رد + همیشه قابلِ‌بازگشت.
 *
 * نسخه ۱ (این فایل): کارت + خطِ inline + تشخیصِ خودکار. اسپات‌لایتِ بین‌صفحه‌ای = فاز بعد.
 *
 * @package FarazSMS
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! defined( 'FARAZSMS_ONBOARDING_DEFAULT_LINE' ) ) {
	define( 'FARAZSMS_ONBOARDING_DEFAULT_LINE', '90008361' );
}

/**
 * آیا استکِ ووکامرس + افزونه‌ی پیامکِ حرفه‌ای (PWSMS) فعال است؟
 * (شرطِ نمایشِ قدمِ «تب وب‌سرویس».)
 *
 * @return bool
 */
function farazsms_onboarding_has_pwsms_stack() {
	$wc = farazsms_is_wc_active();
	return $wc && function_exists( 'PWSMS' );
}

/**
 * محاسبه‌ی قدم‌های ویزارد + حالتِ هرکدام، از دادهٔ واقعی.
 *
 * هر قدم: id, label, hint, done(bool), pending(bool), type(link|sender|info), url?, tag?
 *
 * @return array
 */
function farazsms_onboarding_steps() {
	$apikey = farazsms_cfg_apikey();
	$sender = farazsms_cfg_sender();

	$patterns      = get_option( 'farazsms_patterns', array() );
	$patterns_done = is_array( $patterns ) && ! empty( $patterns );

	$steps = array();

	$steps[] = array(
		'id'    => 'key',
		'label' => __( 'کلید دسترسی (Api-Key)', 'farazsms' ),
		'hint'  => __( 'از پنلِ فراز کپی کن و در تنظیمات بگذار.', 'farazsms' ),
		'done'  => ( $apikey !== '' ),
		'type'  => 'link',
		'url'   => admin_url( 'admin.php?page=farazsms-settings' ),
	);

	$steps[] = array(
		'id'    => 'sender',
		'label' => __( 'خط ارسالت را انتخاب کن', 'farazsms' ),
		'hint'  => __( 'از لیستِ خطوطِ حسابت — لازم نیست تایپ کنی.', 'farazsms' ),
		'done'  => ( $sender !== '' ),
		'type'  => 'sender',
	);

	if ( farazsms_onboarding_has_pwsms_stack() ) {
		$pwsms_key = farazsms_get_pwsms_apikey();
		$steps[]   = array(
			'id'    => 'webservice',
			'label' => __( 'تب وب‌سرویس را پر کن', 'farazsms' ),
			'hint'  => __( 'برو: ووکامرس فارسی › پیامک › تب وب‌سرویس', 'farazsms' ),
			'done'  => ( $pwsms_key !== '' ),
			'type'  => 'info',
			'tag'   => __( 'افزونه‌ی پیامکِ حرفه‌ای ووکامرس', 'farazsms' ),
		);
	}

	// v3.21.39: قدمِ «پترن مدیر و مشتری» مخصوصِ پیامکِ سفارشِ ووکامرس است. در سایتی که
	// ووکامرس/پیامکِ حرفه‌ای ندارد، این قدم بی‌معناست و باعث می‌شد ویزارد هرگز کامل نشود و
	// همیشه «بیا راه بندازیم» نمایش داده شود. حالا فقط با وجودِ استکِ ووکامرس اضافه می‌شود؛
	// برای سایتِ بدونِ فروشگاه، کلید + خط کافی است و ویزارد کامل می‌شود.
	if ( farazsms_onboarding_has_pwsms_stack() ) {
		$steps[] = array(
			'id'      => 'patterns',
			'label'   => __( 'پترنِ مدیر و مشتری', 'farazsms' ),
			'hint'    => __( 'برای مدیر و مشتری پترن بساز.', 'farazsms' ),
			'done'    => $patterns_done,
			// تأییدِ پترن وابسته به پنلِ فراز است؛ بدونِ تماسِ بلاک‌کننده نمی‌توان live چک کرد،
			// پس وقتی ساخته شد، حالتِ «در انتظار» را به‌صورتِ اطلاع‌رسانی نشان می‌دهیم.
			'pending' => $patterns_done,
			'type'    => 'info',
		);
	}

	return $steps;
}

/**
 * آیا ویزارد تکمیل شده؟ (همه‌ی قدم‌های actionable انجام شده‌اند)
 *
 * @return bool
 */
function farazsms_onboarding_is_complete() {
	foreach ( farazsms_onboarding_steps() as $s ) {
		if ( empty( $s['done'] ) ) {
			return false;
		}
	}
	return true;
}

/**
 * آیا کاربرِ فعلی کارت را رد کرده؟
 *
 * @return bool
 */
function farazsms_onboarding_is_dismissed() {
	return get_user_meta( get_current_user_id(), 'farazsms_onboarding_dismissed', true ) === '1';
}

// ---------------------------------------------------------------------------
//  Enqueue (فقط روی صفحه‌ی داشبورد)
// ---------------------------------------------------------------------------

add_action( 'admin_enqueue_scripts', 'farazsms_onboarding_enqueue' );
function farazsms_onboarding_enqueue( $hook ) {
	$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
	if ( $page !== 'farazsms-dashboard' ) {
		return;
	}
	$ver = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '1.0.0';
	wp_enqueue_style( 'farazsms-onboarding', FARAZSMS_CORE_CSS . 'farazsms-onboarding.css', array(), $ver );
	wp_enqueue_script( 'farazsms-onboarding', FARAZSMS_CORE_JS . 'farazsms-onboarding.js', array( 'jquery' ), $ver, true );
	wp_localize_script( 'farazsms-onboarding', 'farazsmsOnboard', array(
		'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
		'linesAction'   => 'farazsms_send_fetch_lines',
		'linesNonce'    => wp_create_nonce( 'farazsms_send_sms_admin' ),
		'saveAction'    => 'farazsms_onboarding_save_sender',
		'saveNonce'     => wp_create_nonce( 'farazsms_onboarding' ),
		'dismissAction' => 'farazsms_onboarding_dismiss',
		'defaultLine'   => FARAZSMS_ONBOARDING_DEFAULT_LINE,
		'i18n'          => array(
			'loading' => __( 'در حال دریافتِ خطوط…', 'farazsms' ),
			'saved'   => __( 'ذخیره شد ✓', 'farazsms' ),
			'error'   => __( 'خطا — دوباره تلاش کن.', 'farazsms' ),
		),
	) );
}

// ---------------------------------------------------------------------------
//  تزریق روی داشبورد
// ---------------------------------------------------------------------------

add_action( 'farazsms_dashboard_top', 'farazsms_onboarding_render_card' );

/**
 * رندرِ کارتِ ویزارد (یا pillِ بازگشت اگر رد/تکمیل شده).
 *
 * @return void
 */
function farazsms_onboarding_render_card() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$steps    = farazsms_onboarding_steps();
	$complete = farazsms_onboarding_is_complete();
	$dismissed = farazsms_onboarding_is_dismissed();

	// اگر تکمیل یا رد شده → فقط pillِ «راهنمای شروع» (همیشه قابلِ‌بازگشت).
	if ( $complete || $dismissed ) {
		echo '<div class="farazsms-onb-relaunch"><button type="button" class="farazsms-onb-pill" id="farazsms-onb-relaunch">💡 ' . esc_html__( 'راهنمای شروع', 'farazsms' ) . '</button></div>';
		// کارت پنهان ولی در DOM (برای بازکردنِ دوباره بدونِ reload).
		echo '<div id="farazsms-onb-card-host" hidden>';
		farazsms_onboarding_render_card_inner( $steps );
		echo '</div>';
		return;
	}

	echo '<div id="farazsms-onb-card-host">';
	farazsms_onboarding_render_card_inner( $steps );
	echo '</div>';
}

/**
 * بدنه‌ی کارت.
 *
 * @param array $steps
 * @return void
 */
function farazsms_onboarding_render_card_inner( $steps ) {
	$actionable = $steps; // همه actionable‌اند
	$total      = count( $actionable );
	$done_count = 0;
	foreach ( $actionable as $s ) {
		if ( ! empty( $s['done'] ) ) {
			$done_count++;
		}
	}
	$pct = $total > 0 ? round( $done_count / $total * 100 ) : 0;
	?>
	<div class="farazsms-onb" role="region" aria-label="<?php esc_attr_e( 'راه‌اندازی فراز اس ام اس', 'farazsms' ); ?>">
		<button type="button" class="farazsms-onb__close" id="farazsms-onb-dismiss" aria-label="<?php esc_attr_e( 'بستن', 'farazsms' ); ?>">×</button>
		<div class="farazsms-onb__top">
			<h2>🚀 <?php esc_html_e( 'بیا فراز اس ام اس را راه بیندازیم', 'farazsms' ); ?></h2>
			<span class="farazsms-onb__count"><?php echo esc_html( $done_count . ' ' . __( 'از', 'farazsms' ) . ' ' . $total ); ?></span>
		</div>
		<div class="farazsms-onb__bar"><i style="width:<?php echo (int) $pct; ?>%"></i></div>

		<?php
		$active_found = false;
		foreach ( $actionable as $s ) :
			$done    = ! empty( $s['done'] );
			$pending = ! empty( $s['pending'] );
			$is_active = ( ! $done && ! $active_found ); // اولین قدمِ ناتمام = فعال
			if ( $is_active ) {
				$active_found = true;
			}
			$cls = $done ? 'is-done' : ( $is_active ? 'is-active' : 'is-todo' );
			if ( $pending && $done ) {
				$cls = 'is-wait';
			}
			?>
			<div class="farazsms-onb-step <?php echo esc_attr( $cls ); ?>" data-step="<?php echo esc_attr( $s['id'] ); ?>">
				<span class="farazsms-onb-step__ic">
					<?php
					if ( $done && $pending ) {
						echo '⏳';
					} elseif ( $done ) {
						echo '✓';
					} else {
						echo esc_html( farazsms_onboarding_step_num( $actionable, $s['id'] ) );
					}
					?>
				</span>
				<span class="farazsms-onb-step__label">
					<?php echo esc_html( $s['label'] ); ?>
					<?php if ( ! empty( $s['tag'] ) ) : ?>
						<span class="farazsms-onb-step__tag"><?php echo esc_html( $s['tag'] ); ?></span>
					<?php endif; ?>
					<?php if ( ! empty( $s['hint'] ) && ! $done ) : ?>
						<span class="farazsms-onb-step__hint"><?php echo esc_html( $s['hint'] ); ?></span>
					<?php endif; ?>
				</span>

				<?php if ( $done && $pending ) : ?>
					<span class="farazsms-onb-badge is-wait"><?php esc_html_e( 'در انتظار تأیید · تا ۱ ساعت', 'farazsms' ); ?></span>
				<?php elseif ( ! $done && $s['type'] === 'sender' ) : ?>
					<button type="button" class="farazsms-onb-btn" id="farazsms-onb-sender-btn"><?php esc_html_e( 'انتخاب', 'farazsms' ); ?></button>
				<?php elseif ( ! $done && $s['type'] === 'link' && ! empty( $s['url'] ) ) : ?>
					<a class="farazsms-onb-btn" href="<?php echo esc_url( $s['url'] ); ?>"><?php esc_html_e( 'بزن', 'farazsms' ); ?> ←</a>
				<?php endif; ?>
			</div>

			<?php if ( ! $done && $s['type'] === 'sender' ) : ?>
				<div class="farazsms-onb-sender" id="farazsms-onb-sender-box" hidden>
					<select id="farazsms-onb-sender-select" class="farazsms-onb-select">
						<option value=""><?php esc_html_e( 'در حال دریافتِ خطوط…', 'farazsms' ); ?></option>
					</select>
					<button type="button" class="farazsms-onb-btn" id="farazsms-onb-sender-save"><?php esc_html_e( 'تأیید', 'farazsms' ); ?> ←</button>
					<span class="farazsms-onb-sender__msg" id="farazsms-onb-sender-msg"></span>
				</div>
			<?php endif; ?>
		<?php endforeach; ?>

		<p class="farazsms-onb__foot">
			<?php esc_html_e( 'بعد از تأیید پترن توسطِ پنلِ فراز (تا حدودِ ۱ ساعت)، کارِ راه‌اندازی تمام است.', 'farazsms' ); ?>
		</p>
	</div>
	<?php
}

/**
 * شماره‌ی نمایشیِ قدم (۱-based) بر اساسِ ترتیب.
 *
 * @param array  $steps
 * @param string $id
 * @return string
 */
function farazsms_onboarding_step_num( $steps, $id ) {
	$i = 0;
	foreach ( $steps as $s ) {
		$i++;
		if ( $s['id'] === $id ) {
			return (string) $i;
		}
	}
	return '•';
}

// ---------------------------------------------------------------------------
//  AJAX — ذخیره‌ی خطِ ارسال
// ---------------------------------------------------------------------------

add_action( 'wp_ajax_farazsms_onboarding_save_sender', 'farazsms_onboarding_ajax_save_sender' );
function farazsms_onboarding_ajax_save_sender() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز.', 'farazsms' ) ), 403 );
	}
	check_ajax_referer( 'farazsms_onboarding', 'nonce' );
	$line = isset( $_POST['line'] ) ? sanitize_text_field( wp_unslash( $_POST['line'] ) ) : '';
	if ( $line === '' ) {
		wp_send_json_error( array( 'message' => __( 'خط انتخاب نشده.', 'farazsms' ) ) );
	}
	update_option( 'farazsms_sender', $line, false );
	wp_send_json_success( array( 'message' => __( 'ذخیره شد ✓', 'farazsms' ), 'line' => $line ) );
}

// ---------------------------------------------------------------------------
//  AJAX — رد/بازکردنِ دوباره‌ی کارت
// ---------------------------------------------------------------------------

add_action( 'wp_ajax_farazsms_onboarding_dismiss', 'farazsms_onboarding_ajax_dismiss' );
function farazsms_onboarding_ajax_dismiss() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array(), 403 );
	}
	check_ajax_referer( 'farazsms_onboarding', 'nonce' );
	$state = isset( $_POST['state'] ) ? sanitize_key( wp_unslash( $_POST['state'] ) ) : 'dismiss';
	if ( $state === 'reopen' ) {
		delete_user_meta( get_current_user_id(), 'farazsms_onboarding_dismissed' );
	} else {
		update_user_meta( get_current_user_id(), 'farazsms_onboarding_dismissed', '1' );
	}
	wp_send_json_success();
}
