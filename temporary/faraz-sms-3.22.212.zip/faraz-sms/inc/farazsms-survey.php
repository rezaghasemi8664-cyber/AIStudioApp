<?php
/**
 * نظرسنجی پس از خرید — Phase 5
 *
 * این ماژول جایگزین تنظیمات قدیمی «نظرسنجی» می‌شود و قابلیت‌های زیر را اضافه می‌کند:
 *
 *   - رابط سه‌تب جدید (داشبورد، تنظیمات، آخرین نظرات)
 *   - راهنمای کامل + لیست متغیرهای الگو
 *   - دکمه «ساخت الگو از روی متن» (POST به /sms/pattern)
 *   - دکمه «ارسال پیامک تست» به موبایل مدیر
 *   - جدول DB برای ردیابی پیامک‌های ارسال‌شده + نظرات ثبت‌شده
 *   - آمار: تعداد پیامک، تعداد نظر، در انتظار تأیید، نرخ تبدیل
 *
 * این فایل از تابع‌های موجود استفاده می‌کند:
 *   - farazsms_send_scheduled_sms()       — در farazsms-sms-api.php (ارسال پیامک scheduled به API)
 *   - farazsms_create_pattern()           — در farazsms-sms-api.php
 *   - farazsms_send_pattern_sms_raw()     — در farazsms-sms-api.php (برای تست)
 *
 * Submenu: همان `farazsms-poll` (در farazsms-settings.php ثبت شده) — تابع `farazsms_admin_poll_page`
 *           اگر این فایل بارگذاری شود، dispatch به farazsms_render_survey_page می‌شود.
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

// ============================================================================
// Schema — جدول لاگ نظرسنجی
// ============================================================================

const FARAZSMS_SURVEY_DB_VERSION        = '1.1.0';
const FARAZSMS_SURVEY_DB_VERSION_OPTION = 'farazsms_survey_db_version';

function farazsms_survey_table() {
	global $wpdb;
	return $wpdb->prefix . 'farazsms_survey_log';
}

function farazsms_survey_maybe_setup_table() {
	global $wpdb;
	$table = farazsms_survey_table();
	// v3.22.41: پرچمِ نسخه به‌تنهایی کافی نیست — اگر جدول به هر دلیلی حذف شده باشد (بکاپِ ناقص،
	// پاک‌سازیِ دستی، مهاجرتِ هاست)، پرچم همچنان ست است و قبلاً هرگز بازساخته نمی‌شد؛ در نتیجه
	// کوئری‌های نظرسنجی «Table doesn't exist» می‌دادند. حالا اگر پرچم ست ولی جدول نیست، بازمی‌سازیم.
	if ( get_option( FARAZSMS_SURVEY_DB_VERSION_OPTION ) === FARAZSMS_SURVEY_DB_VERSION
	     && $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
		return;
	}
	if ( ! function_exists( 'dbDelta' ) ) {
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	}
	$charset_collate = $wpdb->get_charset_collate();
	$sql = "CREATE TABLE $table (
		id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
		order_id BIGINT(20) UNSIGNED NOT NULL,
		mobile VARCHAR(20) NOT NULL DEFAULT '',
		first_name VARCHAR(120) NOT NULL DEFAULT '',
		last_name VARCHAR(120) NOT NULL DEFAULT '',
		scheduled_for DATETIME NULL,
		dispatched_at DATETIME NOT NULL,
		status VARCHAR(20) NOT NULL DEFAULT 'scheduled',
		review_url TEXT NULL,
		reviews_count INT UNSIGNED NOT NULL DEFAULT 0,
		first_review_at DATETIME NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY order_id (order_id),
		KEY status (status),
		KEY dispatched_at (dispatched_at)
	) $charset_collate;";
	dbDelta( $sql );
	// v3.21.7: فقط وقتی جدول واقعاً ساخته شد latch کن — وگرنه شکستِ dbDelta (دسترسی/کولیشن/دیسک)
	// پرچم را قفل می‌کند و جدول هرگز بازساخته نمی‌شود (مرگِ بی‌صدای قابلیت).
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
		update_option( FARAZSMS_SURVEY_DB_VERSION_OPTION, FARAZSMS_SURVEY_DB_VERSION, false );
	}
}
add_action( 'admin_init', 'farazsms_survey_maybe_setup_table' );

/**
 * v3.22.50 (باگ گزارش‌شده «لینکِ نظرسنجی → not found»): صفحه‌ی orderreview فقط روی
 * register_activation_hook ساخته می‌شد؛ آپدیتِ افزونه (self-update با folder-rename یا آپدیتِ
 * خودکارِ وردپرس) آن هوک را fire نمی‌کند — پس سایتی که قبل از فیچرِ نظرسنجی نصب کرده و بعد آپدیت
 * شده هرگز صفحه را نداشت و لینکِ %review_url% به ۴۰۴ می‌خورد. اینجا self-heal می‌کنیم: هر ۱۲ ساعت
 * یک‌بار (نه هر بارگذاری) وجودِ صفحه را بررسی و در صورتِ نبود می‌سازیم. idempotent و کم‌هزینه.
 */
add_action( 'admin_init', 'farazsms_survey_ensure_review_page' );
function farazsms_survey_ensure_review_page() {
	if ( get_transient( 'farazsms_review_page_ok' ) ) {
		return;
	}
	set_transient( 'farazsms_review_page_ok', 1, 12 * HOUR_IN_SECONDS );

	$existing_id = farazsms_survey_locate_page_id();
	if ( $existing_id > 0 ) {
		// مهاجرتِ یک‌بار: صفحه‌های orderreviewِ قبلاً‌ساخته‌شده کامنت‌شان باز بود؛ ببند تا
		// باکسِ «دیدگاه»ِ تم دیگر ظاهر نشود و نظرها به «نقد و بررسی»ِ محصول بروند.
		if ( get_option( 'farazsms_survey_page_comments_closed' ) !== '1' ) {
			$content   = (string) get_post_field( 'post_content', $existing_id );
			$is_review = function_exists( 'has_shortcode' ) ? has_shortcode( $content, 'order_review' ) : ( strpos( $content, '[order_review' ) !== false );
			if ( ! $is_review ) {
				// شناسه‌ی ذخیره‌شده به برگه‌ای بدونِ [order_review] اشاره دارد (repurposed) — دست نزن،
				// ولی latch کن تا هر بار بی‌خود چک نشود.
				update_option( 'farazsms_survey_page_comments_closed', '1', false );
			} else {
				$closed = get_post_field( 'comment_status', $existing_id ) === 'closed';
				if ( ! $closed ) {
					wp_update_post( array(
						'ID'             => $existing_id,
						'comment_status' => 'closed',
						'ping_status'    => 'closed',
					) );
					$closed = get_post_field( 'comment_status', $existing_id ) === 'closed';
				}
				// فقط وقتی واقعاً بسته شد latch کن؛ اگر update شکست خورد، دفعه‌ی بعد دوباره تلاش شود
				// (مرگِ بی‌صدا نشود و کامنت برای همیشه باز نماند).
				if ( $closed ) {
					update_option( 'farazsms_survey_page_comments_closed', '1', false );
				}
			}
		}
		return; // برگه هست (و شناسه‌اش در option ذخیره شد).
	}
	// صفحه نیست (سایت بدونِ re-activation به فیچرِ نظرسنجی آپدیت شده) → بساز، با اسلاگِ صریحِ
	// orderreview (پایداریِ لینک) و ذخیره‌ی شناسه تا شناساییِ بعدی قطعی باشد.
	$new_id = wp_insert_post( array(
		'post_title'   => 'orderreview',
		'post_name'    => 'orderreview',
		'post_content' => '[order_review]',
		'post_status'  => 'publish',
		'post_author'  => 1,
		'post_type'    => 'page',
		// کامنت بسته: این صفحه فقط فرمِ ستاره‌ایِ [order_review] است. اگر کامنت باز بماند، تمِ
		// سایت باکسِ «دیدگاه»ِ بومیِ وردپرس را هم زیرِ فرم نشان می‌دهد و نظرِ مشتری به‌جای
		// «نقد و بررسی»ِ محصول (comment_type=review) به دیدگاهِ عمومیِ همین برگه می‌رود.
		'comment_status' => 'closed',
		'ping_status'    => 'closed',
	) );
	if ( $new_id && ! is_wp_error( $new_id ) ) {
		update_option( 'farazsms_survey_page_id', (int) $new_id, false );
	}
	delete_transient( 'farazsms_survey_review_page_url' ); // کشِ URL را باطل کن تا permalinkِ تازه خوانده شود.
}

/**
 * v3.22.41: آیا جدولِ لاگِ نظرسنجی واقعاً وجود دارد؟ (کش‌شده per-request)
 * هر کوئریِ survey_log — چه در ادمین چه در فرانت (checkout) — باید اول این را چک کند تا اگر
 * جدول ساخته نشده/حذف شده، به‌جای «Table doesn't exist»، بی‌صدا رد شود.
 *
 * @return bool
 */
function farazsms_survey_table_exists() {
	static $exists = null;
	if ( $exists !== null ) {
		return $exists;
	}
	global $wpdb;
	$table  = farazsms_survey_table();
	$exists = ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );
	return $exists;
}

// ============================================================================
// v3.22.37 — نگهبانِ کرون: روی هاست‌هایی که WP-Cron/Action Scheduler اجرا نمی‌شود، درخواستِ
// زمان‌بندیِ نظرسنجی (POST به فراز) هرگز از صف خارج نمی‌شد و پیامک ارسال نمی‌شد. اینجا دو کار
// می‌کنیم: (۱) صفِ عقب‌مانده را روی هر بازدیدِ ادمین خودمان پردازش می‌کنیم (مستقل از کرون)،
// (۲) اگر مجبور شدیم، پرچمی می‌گذاریم تا به فروشنده بگوییم مشکل از کرونِ هاستِ اوست نه فراز.
// ============================================================================

/**
 * تعدادِ نظرسنجی‌های «گیرکرده در صف» (بیش از ۱۵ دقیقه queued مانده = async اجرا نشده).
 *
 * @return int
 */
function farazsms_survey_stuck_queued_count() {
	if ( ! farazsms_survey_table_exists() ) {
		return 0;
	}
	global $wpdb;
	$table = farazsms_survey_table();
	// v3.22.39 (بازبینی T3): dispatched_at با current_time('mysql') (وقتِ محلیِ سایت) نوشته می‌شود،
	// پس cutoff هم باید وقتِ محلی باشد؛ قبلاً gmdate (UTC) بود و روی ایران (+۳:۳۰) آستانهٔ ۱۵دقیقه
	// عملاً ~۳ساعت‌ونیم می‌شد. اکنون هر دو هم‌ساعت‌اند.
	$cutoff = date( 'Y-m-d H:i:s', current_time( 'timestamp' ) - 15 * MINUTE_IN_SECONDS );
	return (int) $wpdb->get_var( $wpdb->prepare(
		"SELECT COUNT(*) FROM $table WHERE status = 'queued' AND dispatched_at <= %s",
		$cutoff
	) );
}

/**
 * پردازشِ صفِ عقب‌ماندهٔ نظرسنجی روی بازدیدِ ادمین — مستقل از WP-Cron.
 * throttle‌شده (هر ۳ دقیقه) و محدود به چند ردیف تا صفحهٔ ادمین کند نشود.
 */
add_action( 'admin_init', 'farazsms_survey_catchup_stuck', 20 );
function farazsms_survey_catchup_stuck() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	// «خاموش = هیچ ارسالِ نظرسنجی»: اگر مدیر نظرسنجی را غیرفعال کرده، ردیف‌های queuedِ قدیمی هم نباید
	// dispatch شوند (رفعِ تیکت: «حتی با غیرفعال‌کردن هم پیامکِ نظرسنجی می‌رود»). گیتِ زمان‌بندی از قبل
	// در farazsms_order_status_change هست؛ این، مسیرِ catch-up را هم می‌بندد.
	if ( (string) get_option( 'farazsms_send_poll_sms', '0' ) !== '1' ) {
		return;
	}
	if ( get_transient( 'farazsms_survey_catchup_lock' ) ) {
		return;
	}
	set_transient( 'farazsms_survey_catchup_lock', 1, 3 * MINUTE_IN_SECONDS );

	if ( ! farazsms_survey_table_exists() ) {
		return;
	}

	global $wpdb;
	$table  = farazsms_survey_table();
	// v3.22.39 (بازبینی T3): cutoff هم‌ساعتِ dispatched_at (وقتِ محلی).
	$cutoff = date( 'Y-m-d H:i:s', current_time( 'timestamp' ) - 15 * MINUTE_IN_SECONDS );
	$rows   = $wpdb->get_results( $wpdb->prepare(
		"SELECT order_id, scheduled_for FROM $table WHERE status = 'queued' AND dispatched_at <= %s ORDER BY id ASC LIMIT 3",
		$cutoff
	), ARRAY_A );
	if ( empty( $rows ) ) {
		return;
	}

	$processed = 0;
	foreach ( $rows as $r ) {
		$order_id = (int) $r['order_id'];
		$sched    = (string) $r['scheduled_for'];
		$sched_ts = $sched !== '' ? strtotime( $sched . ' UTC' ) : 0; // scheduled_for به UTC ذخیره شده.

		// پنجرهٔ زمان‌بندی بیش از ۱ روز گذشته → دیگر ارزشِ ارسال ندارد؛ failed علامت بزن تا نلولد.
		if ( $sched_ts && $sched_ts < ( time() - DAY_IN_SECONDS ) ) {
			$wpdb->update( $table, array( 'status' => 'failed' ), array( 'order_id' => $order_id ) );
			continue;
		}

		// v3.22.39 (بازبینی T7): اگر زمانِ زمان‌بندی گذشته (ولی < ۱روز) است، schedule را «همین حالا»
		// بفرست تا فراز یک تاریخِ گذشته دریافت نکند؛ وگرنه همان تاریخِ آینده.
		$date_to_send = ( $sched_ts && $sched_ts > time() ) ? str_replace( ' ', 'T', $sched ) : gmdate( 'Y-m-d\TH:i:s' );

		// v3.22.39 (بازبینی T1): از dispatcherِ غیرمسدود عبور بده — نه POSTِ همزمانِ inline روی admin_init
		// (که پیشخوان را تا ~۴۵ثانیه هنگ می‌کرد). idempotency در farazsms_send_scheduled_sms است.
		if ( function_exists( 'farazsms_survey_dispatch_scheduled_now' ) ) {
			farazsms_survey_dispatch_scheduled_now( $order_id, $date_to_send );
		} else {
			farazsms_send_scheduled_sms( $order_id, $date_to_send );
		}
		$processed++;
	}

	// اگر مجبور شدیم صف را دستی پردازش کنیم یعنی کرونِ سایت اجرا نشده → پرچمِ ۷روزه برای بنر.
	if ( $processed > 0 ) {
		update_option( 'farazsms_survey_cron_unreliable_at', time(), false );
	}
}

/**
 * آیا اخیراً مجبور شدیم صف را دستی پردازش کنیم؟ (نشانهٔ خراب‌بودنِ کرونِ هاست)
 *
 * @return bool
 */
function farazsms_survey_cron_looks_unreliable() {
	$at = (int) get_option( 'farazsms_survey_cron_unreliable_at', 0 );
	return $at > 0 && ( time() - $at ) < 7 * DAY_IN_SECONDS;
}

/**
 * HTMLِ بنرِ هشدارِ کرون — روی صفحهٔ تنظیماتِ نظرسنجی نمایش داده می‌شود.
 *
 * @return string
 */
function farazsms_survey_cron_warning_html() {
	$stuck      = farazsms_survey_stuck_queued_count();
	$unreliable = farazsms_survey_cron_looks_unreliable();
	if ( $stuck <= 0 && ! $unreliable ) {
		return '';
	}
	$msg  = '<div style="background:#fffbeb; border:1px solid #fde68a; border-right:4px solid #f59e0b; color:#78350f; border-radius:10px; padding:14px 18px; margin:0 0 18px; font-size:13px; line-height:2;">';
	$msg .= '<strong style="font-size:14px;">⚠️ زمان‌بندیِ سایت (Cron) روی هاستِ شما درست اجرا نمی‌شود.</strong><br>';
	if ( $stuck > 0 ) {
		$msg .= 'در حالِ حاضر <strong>' . (int) $stuck . '</strong> پیامکِ نظرسنجی در صف مانده و هنوز به فراز فرستاده نشده. ';
	}
	$msg .= 'پیامکِ نظرسنجی چند روز پس از سفارش و به‌صورتِ زمان‌بندی‌شده ارسال می‌شود؛ برای همین ابتدا باید درخواستِ آن از طریقِ زمان‌بندیِ وردپرس (WP-Cron / Action Scheduler) به فراز برود. اگر هاستِ شما این زمان‌بندی را غیرفعال کرده باشد، این درخواست ارسال نمی‌شود.<br>';
	$msg .= '<strong style="color:#b45309;">این مشکل از سمتِ فراز نیست</strong> — لطفاً به‌جای ثبتِ تیکت، یکی از این‌ها را انجام دهید:';
	$msg .= '<ul style="margin:6px 0 0; padding-right:20px;">';
	$msg .= '<li>از هاست بخواهید <code style="direction:ltr; background:#fef3c7; padding:1px 5px; border-radius:4px;">WP-Cron</code> یا یک cron واقعی (system cron) را فعال کند.</li>';
	$msg .= '<li>یا کافی است هر از گاهی وارد پیشخوانِ وردپرس شوید — افزونه صفِ عقب‌مانده را خودش پردازش می‌کند (اگر پنجرهٔ زمانی رد نشده باشد).</li>';
	$msg .= '</ul>';
	$msg .= '</div>';
	return $msg;
}

// ============================================================================
// Helpers
// ============================================================================

/**
 * Persian labels for the supported pattern variables. Shown both in the
 * settings UI guide and used as documentation for the user.
 *
 * @return array<string,string>
 */
function farazsms_survey_variables() {
	return array(
		'full_name'   => __( 'نام و نام خانوادگی کامل', 'farazsms' ),
		'name'        => __( 'نام', 'farazsms' ),
		'family'      => __( 'نام خانوادگی', 'farazsms' ),
		'order_id'    => __( 'شماره سفارش', 'farazsms' ),
		'review_url'  => __( 'لینک ثبت نظرسنجی (با شناسه سفارش)', 'farazsms' ),
	);
}

function farazsms_survey_default_options() {
	return array(
		'access_mode'         => 'magic',
		'magic_ttl_days'      => '14',
		'reward_enabled'      => '1',
		'reward_type'         => 'coupon', // v3.21.90: coupon | wallet
		'reward_amount'       => '50000',
		'reward_expiry_days'  => '7',
		'reward_timing'       => 'submitted',
		'reward_pattern_code' => (string) get_option( 'farazsms_survey_reward_pattern', '' ),
		'reward_message'      => farazsms_survey_default_reward_template(),
	);
}

function farazsms_survey_options() {
	$saved = get_option( 'farazsms_survey_options', array() );
	return wp_parse_args( is_array( $saved ) ? $saved : array(), farazsms_survey_default_options() );
}

function farazsms_survey_default_reward_template() {
	return "ممنون که نظرت رو ثبت کردی.\n" .
		"کد تخفیف خرید بعدی شما: %code%\n" .
		"اعتبار تا: %expire%\n" .
		get_site_url();
}

/**
 * Default pattern template — used in the "ساخت الگو" wizard so the admin
 * doesn't start from a blank textarea.
 *
 * @return string
 */
function farazsms_survey_default_template() {
	// نکته مهم برای تأیید الگو: نام برند فروشگاه باید به‌صورت ثابت در متن نوشته
	// شود (نه به‌صورت متغیر) — در غیر این صورت پنل فراز الگو را تأیید نمی‌کند.
	// خط آخر «نام فروشگاه شما» را با نام واقعی برند خود جایگزین کنید.
	return "%full_name% گرامی\n" .
		"از خریدتان ممنون هستیم.\n" .
		"لطفاً نظرتان درباره محصولات این سفارش را با ما در میان بگذارید:\n" .
		"%review_url%\n\n" .
		"نام فروشگاه شما";
}

/**
 * Return the permalink of the order-review page (the one created on plugin activation).
 *
 * @return string
 */
/**
 * شناسه‌ی «برگه‌ی نظرسنجی» را قطعی پیدا کن — مستقل از عنوان/اسلاگ/ساختارِ پیوندِ یکتا.
 *
 * ریشه‌ی باگِ «۴۰۴»: قبلاً فقط با عنوانِ «orderreview» جست‌وجو می‌شد و در صورتِ نبود به مسیرِ
 * hardcodeِ /orderreview/ فالبک می‌کرد؛ روی permalinkِ Plain، تعارضِ اسلاگ (orderreview-2)، یا
 * برگه‌ای با عنوانِ متفاوت، لینک به صفحهٔ واقعی نمی‌رسید و مشتری ۴۰۴ می‌دید. اکنون:
 *   ۱) IDِ ذخیره‌شده در option (اگر برگه‌ی منتشرشده باشد)،
 *   ۲) برگه‌ای با عنوانِ orderreview،
 *   ۳) «هر» برگه‌ی منتشرشده‌ای که شورت‌کدِ [order_review] دارد (مطمئن‌ترین — هرجا شورت‌کد باشد).
 * نتیجه در option کش می‌شود تا دفعه‌ی بعد مستقیم بیاید.
 *
 * @return int 0 اگر برگه‌ای نبود.
 */
function farazsms_survey_locate_page_id() {
	// ۱) IDِ ذخیره‌شده.
	$stored = (int) get_option( 'farazsms_survey_page_id', 0 );
	if ( $stored > 0 && get_post_status( $stored ) === 'publish' ) {
		return $stored;
	}
	// ۲) عنوانِ orderreview.
	$q = new WP_Query( array(
		'post_type'      => 'page',
		'post_status'    => 'publish',
		'title'          => 'orderreview',
		'posts_per_page' => 1,
		'no_found_rows'  => true,
		'fields'         => 'ids',
	) );
	if ( ! empty( $q->posts ) ) {
		$id = (int) $q->posts[0];
		// فقط اگر واقعاً شورت‌کد را دارد بپذیر و کش کن؛ برگه‌ای که صرفاً «عنوانش» orderreview است ولی
		// شورت‌کد ندارد نباید انتخاب شود (کدریویو) — وگرنه لینک به صفحه‌ی بی‌فرم می‌رسد. اگر نه، به گامِ ۳ برو.
		if ( has_shortcode( (string) get_post_field( 'post_content', $id ), 'order_review' ) ) {
			update_option( 'farazsms_survey_page_id', $id, false );
			return $id;
		}
	}
	// ۳) هر برگه‌ی منتشرشده‌ای که شورت‌کدِ [order_review] دارد.
	$q = new WP_Query( array(
		'post_type'      => 'page',
		'post_status'    => 'publish',
		's'              => '[order_review]',
		'posts_per_page' => 20,
		'no_found_rows'  => true,
		'fields'         => 'ids',
	) );
	if ( ! empty( $q->posts ) ) {
		foreach ( $q->posts as $pid ) {
			if ( has_shortcode( (string) get_post_field( 'post_content', (int) $pid ), 'order_review' ) ) {
				update_option( 'farazsms_survey_page_id', (int) $pid, false );
				return (int) $pid;
			}
		}
	}
	return 0;
}

function farazsms_survey_review_page_url() {
	$cached = get_transient( 'farazsms_survey_review_page_url' );
	if ( $cached !== false ) {
		return (string) $cached;
	}
	$url = '';
	$pid = farazsms_survey_locate_page_id();
	if ( $pid > 0 ) {
		// get_permalink ساختارِ واقعیِ سایت (pretty یا ?page_id=X) را می‌دهد و همیشه resolve می‌شود.
		// v3.22.143: اگر نامکِ برگه فارسی باشد، پیوندِ یکتا در URL درصد-کد و در پیامک ناخوانا
		// می‌شود؛ در آن حالت لینکِ page_id (کوتاه و هم‌مقصد) استفاده می‌شود.
		$url = farazsms_sms_readable_post_link( $pid );
	}
	if ( $url === '' ) {
		// آخرین فالبک — فقط وقتی هیچ برگه‌ای نبود (ensure_review_page باید تا الان ساخته باشد).
		$url = home_url( '/orderreview/' );
	}
	set_transient( 'farazsms_survey_review_page_url', $url, HOUR_IN_SECONDS );
	return $url;
}

/**
 * Build the per-order review URL (used as %review_url% in the pattern).
 *
 * @param int $order_id
 * @return string
 */
function farazsms_survey_build_review_url( $order_id ) {
	$base = farazsms_survey_review_page_url();
	$args = array( 'order_id' => (int) $order_id );
	$order = function_exists( 'wc_get_order' ) ? wc_get_order( (int) $order_id ) : false;
	if ( $order && farazsms_survey_magic_is_enabled() ) {
		$args['frv'] = farazsms_survey_magic_token_for_order( $order );
	}
	return add_query_arg( $args, $base );
}

function farazsms_survey_magic_is_enabled() {
	$options = farazsms_survey_options();
	return ( $options['access_mode'] ?? 'magic' ) === 'magic';
}

function farazsms_survey_magic_ttl_seconds() {
	$options = farazsms_survey_options();
	return max( 1, (int) ( $options['magic_ttl_days'] ?? 14 ) ) * DAY_IN_SECONDS;
}

function farazsms_survey_magic_token_for_order( $order ) {
	if ( ! $order instanceof WC_Order ) {
		return '';
	}
	$token   = (string) $order->get_meta( '_farazsms_review_magic_token', true );
	$expires = (int) $order->get_meta( '_farazsms_review_magic_expires', true );
	if ( $token === '' || $expires < time() ) {
		$token   = bin2hex( random_bytes( 16 ) );
		$expires = time() + farazsms_survey_magic_ttl_seconds();
		$order->update_meta_data( '_farazsms_review_magic_token', $token );
		$order->update_meta_data( '_farazsms_review_magic_expires', $expires );
		$order->save();
	}
	return $token;
}

function farazsms_survey_current_magic_token() {
	if ( empty( $_GET['frv'] ) && empty( $_POST['frv'] ) ) {
		return '';
	}
	$raw = ! empty( $_POST['frv'] ) ? $_POST['frv'] : $_GET['frv'];
	$token = sanitize_text_field( wp_unslash( $raw ) );
	return preg_match( '/^[a-f0-9]{32,64}$/i', $token ) ? $token : '';
}

function farazsms_survey_magic_token_valid( $order, $token = '' ) {
	if ( ! $order instanceof WC_Order ) {
		return false;
	}
	$token = $token !== '' ? $token : farazsms_survey_current_magic_token();
	if ( $token === '' ) {
		return false;
	}
	$saved   = (string) $order->get_meta( '_farazsms_review_magic_token', true );
	$expires = (int) $order->get_meta( '_farazsms_review_magic_expires', true );
	return $saved !== '' && hash_equals( $saved, $token ) && $expires >= time();
}

function farazsms_survey_order_contains_product( $order, $product_id ) {
	if ( ! $order instanceof WC_Order || $product_id <= 0 ) {
		return false;
	}
	foreach ( $order->get_items() as $item ) {
		$product = $item->get_product();
		if ( ! $product ) {
			continue;
		}
		if ( (int) $product->get_id() === (int) $product_id || (int) $product->get_parent_id() === (int) $product_id ) {
			return true;
		}
	}
	return false;
}

/**
 * نشانیِ صفحه‌ی ورودِ فراز (قالبِ farazsms-login-page.php) برای هدایتِ مهمان.
 * اگر صفحه‌ی اختصاصیِ ورود نباشد، به ورودِ پیش‌فرضِ وردپرس برمی‌گردیم.
 *
 * @param string $back_url نشانیِ بازگشت بعد از ورود.
 * @return string
 */
function farazsms_survey_login_url_with_return( $back_url ) {
	// v3.21.24: صفحه‌ی فرازِ ورود فقط وقتی کار می‌کند که ماژولِ ورود فعال باشد (شورت‌کدِ فرم
	// ثبت شده باشد). اگر ماژول خاموش است، آن صفحه فقط متنِ خامِ [farazsms_login_form] را نشان
	// می‌دهد → بن‌بست برای مهمان. پس فقط در حالتِ فعال از آن استفاده می‌کنیم، وگرنه ورودِ وردپرس.
	$module_on = defined( 'FARAZSMS_LOGIN_FRONTEND_ENABLED' )
		? (bool) FARAZSMS_LOGIN_FRONTEND_ENABLED
		: ( farazsms_login_module_is_enabled());

	if ( $module_on ) {
		$pages = get_posts( array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => 1,
			'meta_key'       => '_wp_page_template',
			'meta_value'     => 'farazsms-login-page.php',
			'fields'         => 'ids',
			'no_found_rows'  => true,
		) );
		if ( ! empty( $pages ) ) {
			// ماژولِ ورودِ فراز بعد از لاگین با اولویتِ back_url ریدایرکت می‌کند.
			return add_query_arg( 'back_url', rawurlencode( $back_url ), get_permalink( (int) $pages[0] ) );
		}
	}
	// v3.21.88: پیش از ورودِ wp-admin، صفحه‌ی «حساب کاربری»ِ ووکامرس را ترجیح بده — برای مهمان
	// فرمِ ورود/ثبت‌نامِ عمومی دارد و بسیار دوستانه‌تر از wp-login.php است. (رفعِ شکایتِ سبد رها:
	// مهمان با کلیکِ لینکِ بازیابی به وردِ ادمین می‌رفت.)
	if ( function_exists( 'wc_get_page_permalink' ) ) {
		$myaccount = wc_get_page_permalink( 'myaccount' );
		if ( $myaccount && ! is_wp_error( $myaccount ) ) {
			return add_query_arg( 'redirect_to', rawurlencode( $back_url ), $myaccount );
		}
	}
	// فالبکِ نهایی: ورودِ پیش‌فرضِ وردپرس با redirect_to.
	return wp_login_url( $back_url );
}

/**
 * گیتِ ورود برای صفحه‌ی نظرسنجی (orderreview):
 * اگر کاربر لاگین نیست، به‌جای نمایشِ پیامِ بن‌بست (یا شورت‌کدِ خام)، او را به صفحه‌ی
 * ورود می‌فرستیم و بعد از ورود به همان نظرسنجی بازمی‌گردانیم. روی template_redirect
 * اجرا می‌شود تا قبل از ارسالِ هدرها ریدایرکت ممکن باشد.
 */
add_action( 'template_redirect', 'farazsms_survey_guest_login_gate' );
function farazsms_survey_guest_login_gate() {
	if ( is_admin() || is_user_logged_in() ) {
		return;
	}
	if ( empty( $_GET['order_id'] ) ) {
		return; // لینک‌های نظرسنجی همیشه order_id دارند.
	}

	// فقط روی صفحه‌ی نظرسنجی عمل کن: یا محتوای صفحه شورت‌کدِ [order_review] دارد،
	// یا مسیرِ صفحه با صفحه‌ی orderreview یکی است (برای صفحاتی که با صفحه‌ساز ساخته شده‌اند).
	$is_survey = false;
	$post      = get_post();
	if ( $post instanceof WP_Post && has_shortcode( (string) $post->post_content, 'order_review' ) ) {
		$is_survey = true;
	}
	if ( ! $is_survey ) {
		$review_path = trim( (string) wp_parse_url( farazsms_survey_review_page_url(), PHP_URL_PATH ), '/' );
		$cur_path    = isset( $_SERVER['REQUEST_URI'] )
			? trim( (string) wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ), PHP_URL_PATH ), '/' )
			: '';
		if ( $review_path !== '' && $cur_path === $review_path ) {
			$is_survey = true;
		}
	}
	if ( ! $is_survey ) {
		return;
	}

	$order = function_exists( 'wc_get_order' ) ? wc_get_order( (int) $_GET['order_id'] ) : false;
	if ( $order && farazsms_survey_magic_is_enabled() && farazsms_survey_magic_token_valid( $order ) ) {
		return;
	}

	$survey_url = add_query_arg( 'order_id', (int) $_GET['order_id'], farazsms_survey_review_page_url() );
	wp_safe_redirect( farazsms_survey_login_url_with_return( $survey_url ) );
	exit;
}

/**
 * Record a scheduled survey SMS in the log table. Called from
 * farazsms_send_scheduled_sms() right after we POST to the FarazSMS API.
 *
 * @param int    $order_id
 * @param string $mobile
 * @param string $first_name
 * @param string $last_name
 * @param string $scheduled_for  e.g. '2026-06-10T15:00:00' (the API schedule field)
 * @param bool   $api_success
 * @param string $review_url     the exact link that was texted (incl. shortened); shown on the order page
 */
function farazsms_survey_log_dispatch( $order_id, $mobile, $first_name, $last_name, $scheduled_for, $api_success, $review_url = '' ) {
	if ( ! farazsms_survey_table_exists() ) {
		return;
	}
	global $wpdb;
	$table = farazsms_survey_table();
	$now   = current_time( 'mysql' );
	$row   = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM $table WHERE order_id = %d LIMIT 1", $order_id ), ARRAY_A );
	$data  = array(
		'mobile'         => (string) $mobile,
		'first_name'     => (string) $first_name,
		'last_name'      => (string) $last_name,
		'scheduled_for'  => $scheduled_for !== '' ? gmdate( 'Y-m-d H:i:s', strtotime( $scheduled_for ) ) : null,
		'dispatched_at'  => $now,
		'status'         => $api_success ? 'scheduled' : 'failed',
	);
	if ( (string) $review_url !== '' ) {
		$data['review_url'] = (string) $review_url;
	}
	if ( $row ) {
		$wpdb->update( $table, $data, array( 'id' => (int) $row['id'] ) );
	} else {
		$data['order_id'] = (int) $order_id;
		$wpdb->insert( $table, $data );
	}
}

/**
 * v3.21.88: ثبتِ ردیفِ «queued» درست هنگامِ زمان‌بندی (قبل از سپردن به صفِ async). اگر
 * Action Scheduler اجرا نشود، ردیف روی «queued» می‌ماند و در لاگ دیده می‌شود — به‌جای اینکه
 * ارسالِ ناموفق کاملاً نامرئی بماند (تیکت: «نظرسنجی هیچ‌وقت ساخته نشد»).
 *
 * @param int    $order_id
 * @param string $scheduled_for  the API schedule datetime
 */
function farazsms_survey_log_queued( $order_id, $scheduled_for ) {
	if ( ! function_exists( 'wc_get_order' ) || ! farazsms_survey_table_exists() ) {
		return;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	global $wpdb;
	$table = farazsms_survey_table();
	$now   = current_time( 'mysql' );
	$phone = farazsms_normalize_phone( $order->get_billing_phone() );
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT id, status FROM $table WHERE order_id = %d LIMIT 1", $order_id ), ARRAY_A );
	// اگر قبلاً واقعاً زمان‌بندی/ارسال شده، دست نزن.
	if ( $row && in_array( $row['status'], array( 'scheduled', 'sent' ), true ) ) {
		return;
	}
	$data = array(
		'mobile'        => (string) $phone,
		'first_name'    => (string) $order->get_billing_first_name(),
		'last_name'     => (string) $order->get_billing_last_name(),
		'scheduled_for' => $scheduled_for !== '' ? gmdate( 'Y-m-d H:i:s', strtotime( $scheduled_for ) ) : null,
		'dispatched_at' => $now,
		'status'        => 'queued',
	);
	if ( $row ) {
		$wpdb->update( $table, $data, array( 'id' => (int) $row['id'] ) );
	} else {
		$data['order_id'] = (int) $order_id;
		$wpdb->insert( $table, $data );
	}
}

/**
 * v3.21.88: ثبتِ علتِ «skip» وقتی ارسالِ زمان‌بندی‌شده زودهنگام return می‌کند (شماره/پترن/کلید
 * خالی). به‌جای بازگشتِ خاموش، ردیف با status = skipped_<reason> علامت می‌خورد تا در لاگ پیدا باشد.
 *
 * @param int    $order_id
 * @param string $mobile
 * @param string $reason  e.g. no_phone | no_pattern | no_apikey
 */
function farazsms_survey_log_skipped( $order_id, $mobile, $reason ) {
	if ( ! farazsms_survey_table_exists() ) {
		return;
	}
	global $wpdb;
	$table  = farazsms_survey_table();
	$now    = current_time( 'mysql' );
	$status = substr( 'skipped_' . preg_replace( '/[^a-z_]/', '', (string) $reason ), 0, 20 );
	$row    = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM $table WHERE order_id = %d LIMIT 1", $order_id ), ARRAY_A );
	$data   = array( 'mobile' => (string) $mobile, 'dispatched_at' => $now, 'status' => $status );
	if ( $row ) {
		$wpdb->update( $table, $data, array( 'id' => (int) $row['id'] ) );
	} else {
		$data['order_id'] = (int) $order_id;
		$wpdb->insert( $table, $data );
	}
}

/**
 * Bump review counter when a review is submitted via the [order_review] shortcode.
 * Hooked on comment_post.
 *
 * @param int   $comment_id
 * @param int   $approved
 * @param array $commentdata
 */
function farazsms_survey_count_review_submission( $comment_id, $approved, $commentdata ) {
	$order_id = (int) get_comment_meta( $comment_id, 'order_id', true );
	if ( $order_id <= 0 ) {
		return;
	}
	// v3.22.44 (بازبینی T3): این هوک روی comment_post (فرانت) اجرا می‌شود که admin_init/self-heal
	// اجرا نمی‌شود؛ اگر جدول نباشد، بدونِ این گارد «Table doesn't exist» می‌داد (همان خطای هدف).
	if ( ! farazsms_survey_table_exists() ) {
		return;
	}
	global $wpdb;
	$table = farazsms_survey_table();
	$row   = $wpdb->get_row( $wpdb->prepare( "SELECT id, reviews_count, first_review_at FROM $table WHERE order_id = %d LIMIT 1", $order_id ), ARRAY_A );
	$now   = current_time( 'mysql' );
	if ( $row ) {
		$wpdb->update(
			$table,
			array(
				'reviews_count'   => (int) $row['reviews_count'] + 1,
				'first_review_at' => $row['first_review_at'] ? $row['first_review_at'] : $now,
			),
			array( 'id' => (int) $row['id'] )
		);
	}
}
add_action( 'comment_post', 'farazsms_survey_count_review_submission', 30, 3 );

/**
 * یادداشتِ وضعیتِ پیامکِ نظرسنجی روی صفحه‌ی تکِ سفارش (سازگار با HPOS — WC_Order را می‌گیرد).
 * نشان می‌دهد: پیامک با چه لینکی و در چه تاریخی ارسال «شد»، یا در چه تاریخی ارسال «خواهد شد».
 *
 * @param WC_Order $order
 */
function farazsms_survey_order_admin_note( $order ) {
	if ( ! $order instanceof WC_Order ) {
		return;
	}
	if ( (string) get_option( 'farazsms_send_poll_sms', '0' ) !== '1' ) {
		return; // قابلیتِ نظرسنجی غیرفعال است.
	}
	if ( ! farazsms_survey_table_exists() ) {
		return; // v3.22.44 (بازبینی T3): بدونِ جدول، کوئری نکن.
	}

	$order_id = $order->get_id();
	global $wpdb;
	$table = farazsms_survey_table();
	$row   = $wpdb->get_row( $wpdb->prepare( "SELECT scheduled_for, dispatched_at, status, review_url FROM $table WHERE order_id = %d LIMIT 1", $order_id ), ARRAY_A );

	// UTC mysql → نمایشِ محلی (جلالی اگر helper موجود باشد).
	$fmt = static function ( $mysql_utc ) {
		if ( empty( $mysql_utc ) ) {
			return '';
		}
		return farazsms_send_reports_to_jalali( get_date_from_gmt( $mysql_utc ) );
	};

	echo '<div class="farazsms-survey-order-note" style="clear:both;margin-top:12px;padding:10px 12px;border:1px solid #e2e8f0;border-right:4px solid #4571ba;border-radius:8px;background:#f8fafc;direction:rtl;font-size:12.5px;line-height:1.9;color:#334155;">';
	echo '<strong>📋 پیامکِ نظرسنجی</strong><br>';

	if ( ! $row ) {
		$send_status = (string) get_option( 'farazsms_send_status', 'completed' );
		$send_days   = (int) get_option( 'farazsms_send_time', 7 );
		$statuses    = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();
		$label       = isset( $statuses[ 'wc-' . $send_status ] ) ? $statuses[ 'wc-' . $send_status ] : $send_status;
		printf(
			esc_html__( 'هنوز ارسال/زمان‌بندی نشده — پس از رسیدنِ سفارش به وضعیتِ «%1$s» و گذشتِ %2$d روز ارسال می‌شود.', 'farazsms' ),
			esc_html( $label ),
			(int) $send_days
		);
	} elseif ( $row['status'] === 'failed' ) {
		echo '<span style="color:#b91c1c;">ارسالِ پیامکِ نظرسنجی ناموفق بود (تاریخِ تلاش: ' . esc_html( $fmt( $row['dispatched_at'] ) ) . ').</span>';
	} else {
		$scheduled_ts = ! empty( $row['scheduled_for'] ) ? strtotime( $row['scheduled_for'] . ' UTC' ) : 0;
		$when         = $fmt( ! empty( $row['scheduled_for'] ) ? $row['scheduled_for'] : $row['dispatched_at'] );
		// لینکِ دقیقِ ارسال‌شده (شاملِ کوتاه‌شده) اگر ذخیره شده باشد؛ وگرنه بازتولیدِ لینکِ کاملِ نظرسنجی.
		$url          = ! empty( $row['review_url'] ) ? (string) $row['review_url'] : farazsms_survey_build_review_url( $order_id );
		if ( $scheduled_ts > time() ) {
			echo 'در تاریخ <b>' . esc_html( $when ) . '</b> ارسال می‌شود.';
		} else {
			echo 'در تاریخ <b>' . esc_html( $when ) . '</b> ارسال شد.';
		}
		echo '<br>لینکِ نظرسنجی: <a href="' . esc_url( $url ) . '" target="_blank" rel="noopener" style="word-break:break-all;">' . esc_html( $url ) . '</a>';
	}

	echo '</div>';
}
add_action( 'woocommerce_admin_order_data_after_order_details', 'farazsms_survey_order_admin_note' );

function farazsms_survey_coupon_exists_for_order( $order ) {
	// گاردِ یکپارچه‌ی «قبلاً پاداش گرفته» — هم کوپن هم کیف پول، تا با تغییرِ حالت دوبار پاداش داده نشود.
	if ( ! $order instanceof WC_Order ) {
		return false;
	}
	return (int) $order->get_meta( '_farazsms_review_reward_coupon_id', true ) > 0
		|| (float) $order->get_meta( '_farazsms_review_reward_wallet_credited', true ) > 0;
}

/**
 * v3.21.90: حالتِ دومِ پاداشِ نظر — واریزِ مبلغ به کیف پولِ فروشگاهِ کاربر (به‌جای کوپن).
 * برای مهمان (بدونِ user_id) به کوپن برمی‌گردیم چون کیف پول کاربر می‌خواهد.
 *
 * @return array|false payload برای پیامک، یا false.
 */
function farazsms_survey_credit_reward_wallet( $order ) {
	if ( ! $order instanceof WC_Order || ! function_exists( 'farazsms_wallet_add_credit' ) ) {
		return false;
	}
	if ( farazsms_survey_coupon_exists_for_order( $order ) ) {
		return false;
	}
	$options = farazsms_survey_options();
	if ( ( $options['reward_enabled'] ?? '1' ) !== '1' ) {
		return false;
	}
	$user_id = (int) $order->get_user_id();
	if ( $user_id <= 0 ) {
		// مهمان: کیف پول کاربر ندارد → fallback به کوپن.
		$coupon = farazsms_survey_create_reward_coupon( $order );
		return $coupon ? array_merge( $coupon, array( 'type' => 'coupon' ) ) : false;
	}
	$amount      = max( 1, (int) ( $options['reward_amount'] ?? 50000 ) );
	$expiry_days = max( 0, (int) ( $options['reward_expiry_days'] ?? 7 ) );

	$credit_id = farazsms_wallet_add_credit( $user_id, $amount, array(
		'source'      => 'review_reward',
		'order_id'    => (int) $order->get_id(),
		'expiry_days' => $expiry_days,
		'description' => 'هدیه‌ی ثبتِ نظر',
	) );
	if ( ! $credit_id ) {
		return false;
	}
	$order->update_meta_data( '_farazsms_review_reward_wallet_credited', $amount );
	$order->update_meta_data( '_farazsms_review_reward_sent_at', current_time( 'mysql' ) );
	$order->save();

	$balance = (float) farazsms_wallet_balance( $user_id );
	return array(
		'type'    => 'wallet',
		'amount'  => $amount,
		'balance' => $balance,
	);
}

function farazsms_survey_format_coupon_expiry( $timestamp ) {
	if ( function_exists( 'wp_date' ) ) {
		return wp_date( 'Y-m-d', $timestamp );
	}
	return date_i18n( 'Y-m-d', $timestamp );
}

function farazsms_survey_reward_pattern_variables( $pattern_code ) {
	$msg = (string) get_option( 'farazsms_survey_reward_message', '' );
	if ( $msg !== '' ) {
		$vars = farazsms_tracking_pattern_var_keys_from_message( $msg );
		if ( ! empty( $vars ) ) {
			return $vars;
		}
	}
	$pattern_code = trim( (string) $pattern_code );
	if ( $pattern_code === '' || ! function_exists( 'farazsms_get_pattern_details' ) ) {
		return null;
	}
	$cache_key = 'farazsms_survey_reward_vars_' . md5( $pattern_code );
	$cached    = get_transient( $cache_key );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	$json = farazsms_get_pattern_details( $pattern_code );
	$data = is_string( $json ) ? json_decode( $json, true ) : null;
	if ( ! is_array( $data ) ) {
		return null;
	}
	$found = array();
	array_walk_recursive( $data, function ( $value ) use ( &$found ) {
		if ( is_string( $value ) && preg_match_all( '/[%{]([a-zA-Z0-9_]+)[%}]/', $value, $matches ) ) {
			foreach ( $matches[1] as $key ) {
				$found[ $key ] = true;
			}
		}
	} );
	$list = array_keys( $found );
	if ( ! empty( $list ) ) {
		set_transient( $cache_key, $list, HOUR_IN_SECONDS );
		return $list;
	}
	return null;
}

function farazsms_survey_create_reward_coupon( $order ) {
	if ( ! $order instanceof WC_Order || ! class_exists( 'WC_Coupon' ) ) {
		return false;
	}
	if ( farazsms_survey_coupon_exists_for_order( $order ) ) {
		return false;
	}
	$options = farazsms_survey_options();
	if ( ( $options['reward_enabled'] ?? '1' ) !== '1' ) {
		return false;
	}
	$amount      = max( 1, (int) ( $options['reward_amount'] ?? 50000 ) );
	$expiry_days = max( 1, (int) ( $options['reward_expiry_days'] ?? 7 ) );
	$code        = 'FZREVIEW-' . (int) $order->get_id() . '-' . strtoupper( wp_generate_password( 6, false, false ) );
	$expires_at  = time() + ( $expiry_days * DAY_IN_SECONDS );

	$coupon = new WC_Coupon();
	$coupon->set_code( $code );
	$coupon->set_amount( $amount );
	$coupon->set_discount_type( 'fixed_cart' );
	$coupon->set_usage_limit( 1 );
	$coupon->set_individual_use( false );
	$coupon->set_date_expires( $expires_at );
	$billing_email = (string) $order->get_billing_email();
	if ( $billing_email !== '' ) {
		$coupon->set_email_restrictions( array( $billing_email ) );
	}
	$coupon_id = $coupon->save();
	if ( ! $coupon_id ) {
		return false;
	}

	$order->update_meta_data( '_farazsms_review_reward_coupon_id', (int) $coupon_id );
	$order->update_meta_data( '_farazsms_review_reward_coupon_code', $code );
	$order->update_meta_data( '_farazsms_review_reward_sent_at', current_time( 'mysql' ) );
	$order->save();

	return array(
		'id'         => (int) $coupon_id,
		'code'       => $code,
		'expires_at' => $expires_at,
	);
}

/**
 * ارسالِ پیامکِ پاداشِ نظرسنجی.
 *
 * v3.22.198: ورودی شناسه‌ی سفارش است نه آبجکت، چون این تابع از صف اجرا می‌شود
 * و باقی‌مانده‌ی صف در یک آپشن ذخیره می‌گردد — آبجکتِ سفارش از آن جان به‌در
 * نمی‌برد. تنها فراخواننده‌اش هم شناسه را در دست دارد.
 *
 * @param int   $order_id
 * @param array $coupon
 * @return bool
 */
function farazsms_survey_send_reward_sms( $order_id, $coupon ) {
	if ( ! is_array( $coupon ) || ! function_exists( 'wc_get_order' ) ) {
		return false;
	}
	$order = wc_get_order( (int) $order_id );
	if ( ! $order instanceof WC_Order ) {
		return false;
	}
	$is_wallet = ( ( $coupon['type'] ?? 'coupon' ) === 'wallet' );
	if ( ! $is_wallet && empty( $coupon['code'] ) ) {
		return false;
	}
	$options = farazsms_survey_options();
	$pattern = trim( (string) ( $options['reward_pattern_code'] ?? '' ) );
	if ( $pattern === '' ) {
		$pattern = trim( (string) get_option( 'farazsms_survey_reward_pattern', '' ) );
	}
	$mobile = (string) $order->get_billing_phone();
	if ( function_exists( 'farazsms_newsletter_normalize_mobile' ) ) {
		$mobile = farazsms_newsletter_normalize_mobile( $mobile );
	} elseif ( function_exists( 'farazsms_normalize_phone' ) ) {
		$mobile = farazsms_normalize_phone( $mobile );
	}
	if ( $pattern === '' || $mobile === '' ) {
		return false;
	}
	// حالتِ کیف پول: %amount% و %balance%؛ حالتِ کوپن: %code% و %expire%. مجموعه‌ی کاملِ متغیرها
	// را می‌سازیم و در ادامه با متغیرهای واقعیِ پترن تلاقی می‌گیریم، پس هر پترن هرچه لازم دارد می‌گیرد.
	if ( $is_wallet ) {
		// v3.21.94: متغیرِ %site% (دامنه) حذف شد؛ دامنه به‌صورتِ ثابت به انتهای پترن افزوده می‌شود.
		$attrs = array(
			'amount'   => number_format( (float) ( $coupon['amount'] ?? 0 ) ),
			'balance'  => number_format( (float) ( $coupon['balance'] ?? 0 ) ),
			'sitename' => get_bloginfo( 'name' ),
		);
	} else {
		$attrs = array(
			'code'     => (string) $coupon['code'],
			'expire'   => farazsms_survey_format_coupon_expiry( (int) $coupon['expires_at'] ),
			'sitename' => get_bloginfo( 'name' ),
		);
	}
	$pattern_vars = farazsms_survey_reward_pattern_variables( $pattern );
	if ( is_array( $pattern_vars ) && ! empty( $pattern_vars ) ) {
		$attrs = array_intersect_key( $attrs, array_flip( $pattern_vars ) );
	}
	$sender = farazsms_get_ad_sender();
	$result = farazsms_send_pattern_sms_raw( $mobile, $pattern, $attrs, $sender );
	return $result === 'success';
}

function farazsms_survey_maybe_reward_for_comment( $comment_id, $approved = null ) {
	$order_id = (int) get_comment_meta( $comment_id, 'order_id', true );
	if ( $order_id <= 0 || ! function_exists( 'wc_get_order' ) ) {
		return;
	}
	$order = wc_get_order( $order_id );
	if ( ! $order || farazsms_survey_coupon_exists_for_order( $order ) ) {
		return;
	}
	$options = farazsms_survey_options();
	if ( ( $options['reward_enabled'] ?? '1' ) !== '1' ) {
		return;
	}
	$timing = ( $options['reward_timing'] ?? 'submitted' ) === 'approved' ? 'approved' : 'submitted';
	if ( $timing === 'approved' && (string) $approved !== '1' ) {
		return;
	}
	// v3.21.90: بسته به نوعِ پاداش، کوپن بساز یا به کیف پول واریز کن.
	if ( ( $options['reward_type'] ?? 'coupon' ) === 'wallet' ) {
		$reward = farazsms_survey_credit_reward_wallet( $order );
	} else {
		$coupon = farazsms_survey_create_reward_coupon( $order );
		$reward = $coupon ? array_merge( $coupon, array( 'type' => 'coupon' ) ) : false;
	}
	if ( $reward ) {
		// ⚠️ این تابع روی comment_post (اولویت ۳۵) اجرا می‌شود — یعنی روی همان
		// درخواستی که ماژولِ دیدگاه هم رویش است. دو مسیرِ ارسالِ همگام روی یک
		// درخواستِ بازدیدکننده. ساختِ کوپن/واریز همین‌جا می‌ماند (کارِ دیتابیس)،
		// ولی ارسال از درخواست خارج می‌شود.
		farazsms_queue_task( 'survey', 'farazsms_survey_send_reward_sms', array( (int) $order->get_id(), $reward ) );
	}
}

function farazsms_survey_reward_on_comment_post( $comment_id, $approved, $commentdata ) {
	$options = farazsms_survey_options();
	if ( ( $options['reward_timing'] ?? 'submitted' ) !== 'submitted' ) {
		return;
	}
	farazsms_survey_maybe_reward_for_comment( $comment_id, $approved );
}
add_action( 'comment_post', 'farazsms_survey_reward_on_comment_post', 35, 3 );

function farazsms_survey_reward_on_comment_approval( $new_status, $old_status, $comment ) {
	if ( $new_status !== 'approved' || ! $comment instanceof WP_Comment ) {
		return;
	}
	$options = farazsms_survey_options();
	if ( ( $options['reward_timing'] ?? 'submitted' ) !== 'approved' ) {
		return;
	}
	farazsms_survey_maybe_reward_for_comment( (int) $comment->comment_ID, '1' );
}
add_action( 'transition_comment_status', 'farazsms_survey_reward_on_comment_approval', 10, 3 );

/**
 * Stats for the dashboard. Returns aggregates over the last $days.
 *
 * @param int $days
 * @return array
 */
function farazsms_survey_get_stats( $days = 30 ) {
	if ( ! farazsms_survey_table_exists() ) {
		// v3.22.44 (بازبینی T3): بدونِ جدول، ساختارِ صفرِ کامل برگردان (نه آرایه‌ی خالی) تا callerها
		// که به کلیدها دسترسی مستقیم دارند warning ندهند.
		return array( 'sms_sent' => 0, 'sms_failed' => 0, 'with_review' => 0, 'total_reviews' => 0, 'pending' => 0, 'rate' => 0 );
	}
	global $wpdb;
	$table  = farazsms_survey_table();
	$cutoff = gmdate( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );

	$sms_sent     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE dispatched_at >= %s AND status IN ('scheduled','sent')", $cutoff ) );
	$sms_failed   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE dispatched_at >= %s AND status = %s", $cutoff, 'failed' ) );
	$with_review  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE dispatched_at >= %s AND reviews_count > 0", $cutoff ) );
	$total_reviews= (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(reviews_count),0) FROM $table WHERE dispatched_at >= %s", $cutoff ) );

	// Reviews in moderation: count comments with status 0 that have an `order_id` meta.
	$pending = (int) $wpdb->get_var(
		"SELECT COUNT(c.comment_ID)
		 FROM {$wpdb->comments} c
		 INNER JOIN {$wpdb->commentmeta} m ON m.comment_id = c.comment_ID
		 WHERE c.comment_approved = '0' AND m.meta_key = 'order_id'"
	);

	$rate = $sms_sent > 0 ? round( ( $with_review / $sms_sent ) * 100, 1 ) : 0;

	return array(
		'sms_sent'      => $sms_sent,
		'sms_failed'    => $sms_failed,
		'with_review'   => $with_review,
		'total_reviews' => $total_reviews,
		'pending'       => $pending,
		'rate'          => $rate,
	);
}

// ============================================================================
// AJAX — Create pattern + send test SMS
// ============================================================================

add_action( 'wp_ajax_farazsms_survey_create_pattern', 'farazsms_survey_ajax_create_pattern' );
function farazsms_survey_ajax_create_pattern() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز.', 'farazsms' ) ), 403 );
	}
	check_ajax_referer( 'farazsms_survey_admin', 'nonce' );

	$message = isset( $_POST['message'] ) ? wp_unslash( $_POST['message'] ) : '';
	$message = trim( (string) $message );
	if ( $message === '' ) {
		wp_send_json_error( array( 'message' => __( 'متن الگو خالی است.', 'farazsms' ) ) );
	}


	$purpose = isset( $_POST['purpose'] ) ? sanitize_key( wp_unslash( $_POST['purpose'] ) ) : 'survey';
	$purpose = in_array( $purpose, array( 'survey', 'reward' ), true ) ? $purpose : 'survey';

	// `farazsms_create_pattern` returns a JSON string per its existing contract.
	$description = $purpose === 'reward' ? 'افزونه فراز اس ام اس / کد تخفیف پس از ثبت نظر' : 'افزونه فراز اس ام اس / نظرسنجی پس از خرید';
	$json     = farazsms_create_pattern( $message, 255, $description ); // 255 = "others"
	$response = is_string( $json ) ? json_decode( $json, true ) : ( is_array( $json ) ? $json : null );
	if ( ! is_array( $response ) ) {
		wp_send_json_error( array( 'message' => __( 'پاسخ API قابل پردازش نیست.', 'farazsms' ) ) );
	}

	if ( isset( $response['status'] ) && $response['status'] === 'error' ) {
		$msg = isset( $response['message'] ) ? (string) $response['message'] : __( 'خطای API در ساخت الگو.', 'farazsms' );
		wp_send_json_error( array( 'message' => $msg ) );
	}

	// Try to extract the new pattern code from various response shapes.
	$pattern_code = '';
	$candidates = array();
	if ( isset( $response['data'] ) && is_array( $response['data'] ) ) {
		$candidates[] = $response['data'];
		if ( isset( $response['data']['pattern'] ) && is_array( $response['data']['pattern'] ) ) {
			$candidates[] = $response['data']['pattern'];
		}
	}
	$candidates[] = $response;
	foreach ( $candidates as $node ) {
		foreach ( array( 'code', 'pattern_code', 'pattern', 'id' ) as $k ) {
			if ( isset( $node[ $k ] ) && is_scalar( $node[ $k ] ) && (string) $node[ $k ] !== '' ) {
				$pattern_code = (string) $node[ $k ];
				break 2;
			}
		}
	}

	if ( $pattern_code === '' ) {
		wp_send_json_error( array( 'message' => __( 'الگو ساخته شد ولی کد آن از پاسخ API یافت نشد.', 'farazsms' ) ) );
	}

	if ( $purpose === 'reward' ) {
		$options = farazsms_survey_options();
		$options['reward_pattern_code'] = $pattern_code;
		$options['reward_message']      = (string) $message;
		update_option( 'farazsms_survey_options', $options, false );
		update_option( 'farazsms_survey_reward_pattern', $pattern_code, false );
		update_option( 'farazsms_survey_reward_message', (string) $message, false );
		delete_transient( 'farazsms_survey_reward_vars_' . md5( $pattern_code ) );
	} else {
		update_option( 'farazsms_poll_pattern', $pattern_code, false );
		// v3.21.47: متنِ پترن را ذخیره می‌کنیم تا هنگامِ ارسال فقط متغیرهای واقعیِ همین پترن
		// فرستاده شوند (Faraz متغیرِ اضافه را رد می‌کند → علتِ api_error:Array در تست).
		update_option( 'farazsms_poll_message', (string) $message, false );
		delete_transient( 'farazsms_poll_vars_' . md5( $pattern_code ) );
	}
	wp_send_json_success( array(
		'message'      => __( 'الگو با موفقیت ساخته و در تنظیمات ذخیره شد.', 'farazsms' ),
		'pattern_code' => $pattern_code,
		'purpose'      => $purpose,
	) );
}

/**
 * v3.21.47: متغیرهای واقعیِ پترنِ نظرسنجی — برای فیلترِ attrs.
 *  ۱) از متنِ ذخیره‌شده هنگامِ ساختِ پترن (farazsms_poll_message).
 *  ۲) درغیراین‌صورت از API (با کشِ یک‌ساعته): اسکنِ همه‌ی رشته‌های پاسخ برای %var%/{var}.
 * بازگشت: آرایه‌ی نام‌متغیرها، یا null اگر نامشخص بود (آن‌وقت همه‌ی attrs فرستاده می‌شود).
 *
 * @param string $pattern_code
 * @return array|null
 */
function farazsms_survey_pattern_variables( $pattern_code ) {
	$msg = (string) get_option( 'farazsms_poll_message', '' );
	if ( $msg !== '' ) {
		$vars = farazsms_tracking_pattern_var_keys_from_message( $msg );
		if ( ! empty( $vars ) ) {
			return $vars;
		}
	}
	$pattern_code = trim( (string) $pattern_code );
	if ( $pattern_code === '' || ! function_exists( 'farazsms_get_pattern_details' ) ) {
		return null;
	}
	$cache_key = 'farazsms_poll_vars_' . md5( $pattern_code );
	$cached    = get_transient( $cache_key );
	if ( is_array( $cached ) ) {
		return $cached;
	}
	$json = farazsms_get_pattern_details( $pattern_code );
	$data = is_string( $json ) ? json_decode( $json, true ) : null;
	if ( ! is_array( $data ) ) {
		return null;
	}
	$found = array();
	array_walk_recursive( $data, function ( $v ) use ( &$found ) {
		if ( is_string( $v ) && preg_match_all( '/[%{]([a-zA-Z0-9_]+)[%}]/', $v, $m ) ) {
			foreach ( $m[1] as $k ) {
				$found[ $k ] = true;
			}
		}
	} );
	$list = array_keys( $found );
	if ( ! empty( $list ) ) {
		set_transient( $cache_key, $list, HOUR_IN_SECONDS );
		return $list;
	}
	return null;
}

add_action( 'wp_ajax_farazsms_survey_send_test', 'farazsms_survey_ajax_send_test' );
function farazsms_survey_ajax_send_test() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_send_json_error( array( 'message' => __( 'دسترسی غیرمجاز.', 'farazsms' ) ), 403 );
	}
	check_ajax_referer( 'farazsms_survey_admin', 'nonce' );

	$mobile = isset( $_POST['mobile'] ) ? wp_unslash( $_POST['mobile'] ) : '';
	if ( function_exists( 'farazsms_newsletter_normalize_mobile' ) ) {
		$mobile = farazsms_newsletter_normalize_mobile( $mobile );
	}
	if ( $mobile === '' ) {
		wp_send_json_error( array( 'message' => __( 'شماره موبایل معتبر نیست.', 'farazsms' ) ) );
	}

	$pattern = trim( (string) get_option( 'farazsms_poll_pattern', '' ) );
	if ( $pattern === '' ) {
		wp_send_json_error( array( 'message' => __( 'ابتدا کد الگو را تنظیم کنید.', 'farazsms' ) ) );
	}

	$sender = get_option( 'farazsms_sender', '' );
	$attrs  = array(
		'name'       => 'تست',
		'family'     => 'فراز',
		'full_name'  => 'تست فراز',
		'order_id'   => '0',
		'review_url' => farazsms_survey_build_review_url( 0 ),
		'sitename'   => get_bloginfo( 'name' ),
	);
	// v3.21.47: فقط متغیرهای واقعیِ پترن را بفرست — Faraz متغیرِ اضافه را رد می‌کند
	// (علتِ api_error:Array وقتی پترن مثلاً فقط full_name/review_url دارد ولی ۶ متغیر می‌رفت).
	$pattern_vars = farazsms_survey_pattern_variables( $pattern );
	if ( is_array( $pattern_vars ) && ! empty( $pattern_vars ) ) {
		$attrs = array_intersect_key( $attrs, array_flip( $pattern_vars ) );
	}
	$result = farazsms_send_pattern_sms_raw( $mobile, $pattern, $attrs, $sender );
	if ( $result === 'success' ) {
		wp_send_json_success( array( 'message' => __( 'پیامک تست ارسال شد.', 'farazsms' ) ) );
	}
	$msg = is_string( $result ) && $result !== '' ? $result : __( 'ارسال ناموفق.', 'farazsms' );
	wp_send_json_error( array( 'message' => $msg ) );
}

add_action( 'admin_post_farazsms_survey_save_settings', 'farazsms_survey_handle_save_settings' );
function farazsms_survey_handle_save_settings() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( __( 'دسترسی غیرمجاز.', 'farazsms' ), '', array( 'response' => 403 ) );
	}
	check_admin_referer( 'farazsms_survey_settings' );
	$enabled = isset( $_POST['send_poll_sms'] ) && $_POST['send_poll_sms'] === '1' ? '1' : '0';
	update_option( 'farazsms_send_poll_sms', $enabled, false );
	update_option( 'farazsms_poll_pattern', isset( $_POST['farazsms_poll_pattern'] ) ? sanitize_text_field( wp_unslash( $_POST['farazsms_poll_pattern'] ) ) : '', false );
	update_option( 'farazsms_send_time',    isset( $_POST['send_time'] )       ? max( 0, (int) $_POST['send_time'] ) : 0, false );
	update_option( 'farazsms_send_status',  isset( $_POST['send_status'] )     ? sanitize_text_field( wp_unslash( $_POST['send_status'] ) ) : '', false );
	$options = farazsms_survey_options();
	$access_mode = isset( $_POST['survey_access_mode'] ) ? sanitize_key( wp_unslash( $_POST['survey_access_mode'] ) ) : 'magic';
	$options['access_mode']         = in_array( $access_mode, array( 'magic', 'login' ), true ) ? $access_mode : 'magic';
	$options['magic_ttl_days']      = isset( $_POST['survey_magic_ttl_days'] ) ? max( 1, min( 90, (int) $_POST['survey_magic_ttl_days'] ) ) : 14;
	$options['reward_enabled']      = isset( $_POST['reward_enabled'] ) && $_POST['reward_enabled'] === '1' ? '1' : '0';
	$reward_type                    = isset( $_POST['reward_type'] ) ? sanitize_key( wp_unslash( $_POST['reward_type'] ) ) : 'coupon';
	$options['reward_type']         = in_array( $reward_type, array( 'coupon', 'wallet' ), true ) ? $reward_type : 'coupon';
	$options['reward_amount']       = isset( $_POST['reward_amount'] ) ? max( 1, (int) $_POST['reward_amount'] ) : 50000;
	$options['reward_expiry_days']  = isset( $_POST['reward_expiry_days'] ) ? max( 1, min( 365, (int) $_POST['reward_expiry_days'] ) ) : 7;
	$reward_timing = isset( $_POST['reward_timing'] ) ? sanitize_key( wp_unslash( $_POST['reward_timing'] ) ) : 'submitted';
	$options['reward_timing']       = in_array( $reward_timing, array( 'submitted', 'approved' ), true ) ? $reward_timing : 'submitted';
	$options['reward_pattern_code'] = isset( $_POST['reward_pattern_code'] ) ? sanitize_text_field( wp_unslash( $_POST['reward_pattern_code'] ) ) : '';
	$options['reward_message']      = isset( $_POST['reward_message'] ) ? trim( (string) wp_unslash( $_POST['reward_message'] ) ) : farazsms_survey_default_reward_template();
	update_option( 'farazsms_survey_options', $options, false );
	update_option( 'farazsms_survey_reward_pattern', $options['reward_pattern_code'], false );
	update_option( 'farazsms_survey_reward_message', $options['reward_message'], false );
	wp_safe_redirect( add_query_arg( array(
		'page'    => 'farazsms-poll',
		'tab'     => 'settings',
		'updated' => '1',
	), admin_url( 'admin.php' ) ) );
	exit;
}

// ============================================================================
// Admin page render — replaces the legacy farazsms_admin_poll_page
// ============================================================================

function farazsms_render_survey_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'دسترسی غیرمجاز.', 'farazsms' ) );
	}
	farazsms_survey_maybe_setup_table();

	$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';
	$tab = in_array( $tab, array( 'dashboard', 'settings', 'reviews' ), true ) ? $tab : 'dashboard';

	echo '<section class="wrapper farazsms-survey-wrapper">';
	farazsms_survey_render_header();
	farazsms_survey_render_tabs( $tab );
	// v3.22.37: هشدارِ کرون — اگر زمان‌بندیِ سایت اجرا نمی‌شود و نظرسنجی‌ها در صف مانده‌اند،
	// به فروشنده بگو مشکل از کرونِ هاست است نه فراز (کاهشِ تیکت).
	echo farazsms_survey_cron_warning_html(); // phpcs:ignore WordPress.Security.EscapeOutput — HTMLِ ثابتِ داخلی
	switch ( $tab ) {
		case 'settings':
			farazsms_survey_render_settings_tab();
			break;
		case 'reviews':
			farazsms_survey_render_reviews_tab();
			break;
		default:
			farazsms_survey_render_dashboard_tab();
	}
	farazsms_survey_render_inline();
	echo '</section>';
}

function farazsms_survey_render_header() {
	$apikey = farazsms_get_apikey();
	?>
	<div id="farazsms_header">
		<div>
			<a href="https://farazsms.com" target="_blank" rel="noopener">
				<img src="<?php echo esc_url( FARAZSMS_CORE_IMG . 'logo-1.png' ); ?>" alt="<?php esc_attr_e( 'فراز اس‌ام‌اس', 'farazsms' ); ?>">
			</a>
		</div>
		<?php if ( ! empty( $apikey ) ) : ?>
			<div id="farazsms_account_info">
				<div class="farazsms_credit_amount">
					<span><?php esc_html_e( 'میزان اعتبار: ', 'farazsms' ); ?></span>
					<?php echo esc_html( (string) farazsms_get_credit() ); ?>
					<span> <?php esc_html_e( 'تومان', 'farazsms' ); ?></span>
				</div>
				<?php if ( function_exists( 'farazsms_render_profile_block' ) ) { farazsms_render_profile_block(); } ?>
			</div>
		<?php endif; ?>
	</div>
	<h1 class="farazsms-survey-title-main"><?php esc_html_e( 'نظرسنجی پس از خرید', 'farazsms' ); ?></h1>
	<?php if ( ! class_exists( 'WooCommerce' ) ) : ?>
		<div class="notice notice-warning"><p><?php esc_html_e( 'این قابلیت نیازمند ووکامرس است.', 'farazsms' ); ?></p></div>
	<?php endif; ?>
	<?php
}

function farazsms_survey_render_tabs( $active ) {
	$tabs = array(
		'dashboard' => __( 'داشبورد آماری', 'farazsms' ),
		'settings'  => __( 'تنظیمات', 'farazsms' ),
		'reviews'   => __( 'آخرین نظرات', 'farazsms' ),
	);
	?>
	<nav class="farazsms-survey-tabs">
		<?php foreach ( $tabs as $key => $label ) :
			$url = add_query_arg( array( 'page' => 'farazsms-poll', 'tab' => $key ), admin_url( 'admin.php' ) );
		?>
			<a class="farazsms-survey-tab <?php echo $active === $key ? 'is-active' : ''; ?>" href="<?php echo esc_url( $url ); ?>">
				<?php echo esc_html( $label ); ?>
			</a>
		<?php endforeach; ?>
	</nav>
	<?php
}

function farazsms_survey_render_dashboard_tab() {
	$days = isset( $_GET['days'] ) ? max( 1, (int) $_GET['days'] ) : 30;
	$days = in_array( $days, array( 7, 30, 90, 365 ), true ) ? $days : 30;
	$s    = farazsms_survey_get_stats( $days );
	?>
	<div class="farazsms-survey-range-bar">
		<?php
		$ranges = array( 7 => '۷ روز', 30 => '۳۰ روز', 90 => '۹۰ روز', 365 => '۱ سال' );
		foreach ( $ranges as $d => $lbl ) :
			$url = add_query_arg( array( 'page' => 'farazsms-poll', 'days' => $d ), admin_url( 'admin.php' ) );
		?>
			<a href="<?php echo esc_url( $url ); ?>" class="farazsms-survey-range <?php echo $days === $d ? 'is-active' : ''; ?>"><?php echo esc_html( $lbl ); ?></a>
		<?php endforeach; ?>
	</div>

	<div class="farazsms-survey-stats">
		<div class="farazsms-survey-stat">
			<div class="num farazsms-num-info"><?php echo esc_html( number_format_i18n( $s['sms_sent'] ) ); ?></div>
			<div class="lbl"><?php esc_html_e( 'پیامک نظرسنجی ارسال شده', 'farazsms' ); ?></div>
		</div>
		<div class="farazsms-survey-stat">
			<div class="num farazsms-num-success"><?php echo esc_html( number_format_i18n( $s['with_review'] ) ); ?></div>
			<div class="lbl"><?php esc_html_e( 'سفارش‌هایی که نظر ثبت کردند', 'farazsms' ); ?></div>
		</div>
		<div class="farazsms-survey-stat">
			<div class="num farazsms-num-success"><?php echo esc_html( $s['rate'] ); ?>٪</div>
			<div class="lbl"><?php esc_html_e( 'نرخ تبدیل', 'farazsms' ); ?></div>
		</div>
		<div class="farazsms-survey-stat">
			<div class="num farazsms-num-warning"><?php echo esc_html( number_format_i18n( $s['pending'] ) ); ?></div>
			<div class="lbl"><?php esc_html_e( 'نظرات در انتظار تأیید', 'farazsms' ); ?></div>
		</div>
	</div>

	<div class="farazsms-survey-stats">
		<div class="farazsms-survey-stat">
			<div class="num"><?php echo esc_html( number_format_i18n( $s['total_reviews'] ) ); ?></div>
			<div class="lbl"><?php esc_html_e( 'کل نظرات ثبت‌شده (همه محصولات)', 'farazsms' ); ?></div>
		</div>
		<div class="farazsms-survey-stat">
			<div class="num farazsms-num-muted"><?php echo esc_html( number_format_i18n( $s['sms_failed'] ) ); ?></div>
			<div class="lbl"><?php esc_html_e( 'پیامک ناموفق', 'farazsms' ); ?></div>
		</div>
		<div class="farazsms-survey-stat farazsms-survey-stat-link">
			<a href="<?php echo esc_url( admin_url( 'edit-comments.php?comment_status=moderated' ) ); ?>">
				<?php esc_html_e( 'مرور نظرات در انتظار تأیید →', 'farazsms' ); ?>
			</a>
		</div>
		<div class="farazsms-survey-stat farazsms-survey-stat-link">
			<a href="<?php echo esc_url( farazsms_survey_review_page_url() ); ?>" target="_blank" rel="noopener">
				<?php esc_html_e( 'مشاهده صفحه نظرسنجی →', 'farazsms' ); ?>
			</a>
		</div>
	</div>
	<?php
}

function farazsms_survey_render_settings_tab() {
	$enabled       = (string) get_option( 'farazsms_send_poll_sms', '0' );
	$pattern_code  = (string) get_option( 'farazsms_poll_pattern', '' );
	$send_time     = (int) get_option( 'farazsms_send_time', 7 );
	$send_status   = (string) get_option( 'farazsms_send_status', 'completed' );
	$updated       = isset( $_GET['updated'] ) ? sanitize_key( $_GET['updated'] ) : '';
	$options       = farazsms_survey_options();

	$default_tpl   = farazsms_survey_default_template();
	$review_page   = farazsms_survey_review_page_url();
	$variables     = farazsms_survey_variables();
	$reward_message = trim( (string) ( $options['reward_message'] ?? '' ) );
	if ( $reward_message === '' ) {
		$reward_message = farazsms_survey_default_reward_template();
	}
	?>
	<?php if ( $updated === '1' ) : ?>
		<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'تنظیمات ذخیره شد.', 'farazsms' ); ?></p></div>
	<?php endif; ?>

	<div class="farazsms-survey-grid">
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="farazsms-survey-card farazsms-survey-card-main">
			<input type="hidden" name="action" value="farazsms_survey_save_settings">
			<?php wp_nonce_field( 'farazsms_survey_settings' ); ?>

			<h2><?php esc_html_e( 'تنظیمات اصلی', 'farazsms' ); ?></h2>

			<label class="farazsms-survey-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'فعال‌سازی', 'farazsms' ); ?></span>
				<label class="farazsms-survey-switch">
					<input type="checkbox" class="farazsms-toggle" name="send_poll_sms" value="1" <?php checked( $enabled, '1' ); ?>>
					<span><?php esc_html_e( 'با تغییر وضعیت سفارش، پیامک نظرسنجی برنامه‌ریزی می‌شود.', 'farazsms' ); ?></span>
				</label>
			</label>

			<label class="farazsms-survey-setting">
				<span><?php esc_html_e( 'وضعیت سفارش برای ارسال', 'farazsms' ); ?></span>
				<select name="send_status">
					<?php
					$statuses = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();
					foreach ( $statuses as $key => $label ) {
						$clean = preg_replace( '/^wc-/', '', $key );
						printf(
							'<option value="%s" %s>%s</option>',
							esc_attr( $clean ),
							selected( $send_status, $clean, false ),
							esc_html( $label )
						);
					}
					?>
				</select>
				<small><?php esc_html_e( 'پس از رسیدن سفارش به این وضعیت، پیامک scheduled می‌شود.', 'farazsms' ); ?></small>
			</label>

			<label class="farazsms-survey-setting">
				<span><?php esc_html_e( 'تأخیر ارسال (روز)', 'farazsms' ); ?></span>
				<input type="number" name="send_time" value="<?php echo esc_attr( (string) $send_time ); ?>" min="0" max="60" dir="ltr">
				<small><?php esc_html_e( 'چند روز پس از تغییر وضعیت، پیامک ارسال شود. (پیشنهاد: ۳ تا ۷ روز)', 'farazsms' ); ?></small>
			</label>

			<label class="farazsms-survey-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'کد الگوی پیامک نظرسنجی', 'farazsms' ); ?></span>
				<input type="text" name="farazsms_poll_pattern" value="<?php echo esc_attr( $pattern_code ); ?>" dir="ltr" id="farazsms-survey-pattern-code">
				<small><?php esc_html_e( 'اگر هنوز الگو نساخته‌اید، در بخش روبرو متن را وارد کرده و دکمه «ساخت الگو» را بزنید.', 'farazsms' ); ?></small>
			</label>

			<h2 class="farazsms-setting-wide"><?php esc_html_e( 'دسترسی با Magic Link', 'farazsms' ); ?></h2>

			<label class="farazsms-survey-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'روش باز شدن لینک نظردهی', 'farazsms' ); ?></span>
				<select name="survey_access_mode">
					<option value="magic" <?php selected( $options['access_mode'], 'magic' ); ?>><?php esc_html_e( 'Magic Link بدون ورود — پیشنهادی', 'farazsms' ); ?></option>
					<option value="login" <?php selected( $options['access_mode'], 'login' ); ?>><?php esc_html_e( 'ورود/OTP الزامی قبل از ثبت نظر', 'farazsms' ); ?></option>
				</select>
				<small><?php esc_html_e( 'Magic Link فقط فرم محصولات همان سفارش را نشان می‌دهد و دسترسی به حساب یا جزئیات محرمانه سفارش نمی‌دهد.', 'farazsms' ); ?></small>
			</label>

			<label class="farazsms-survey-setting">
				<span><?php esc_html_e( 'اعتبار Magic Link (روز)', 'farazsms' ); ?></span>
				<input type="number" name="survey_magic_ttl_days" value="<?php echo esc_attr( $options['magic_ttl_days'] ); ?>" min="1" max="90" dir="ltr">
			</label>

			<h2 class="farazsms-setting-wide"><?php esc_html_e( 'پاداش بعد از ثبت نظر', 'farazsms' ); ?></h2>

			<label class="farazsms-survey-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'فعال‌سازی پاداش نظر', 'farazsms' ); ?></span>
				<label class="farazsms-survey-switch">
					<input type="checkbox" class="farazsms-toggle" name="reward_enabled" value="1" <?php checked( $options['reward_enabled'], '1' ); ?>>
					<span><?php esc_html_e( 'برای اولین نظر معتبر هر سفارش، فقط یک‌بار پاداش داده و پیامک شود.', 'farazsms' ); ?></span>
				</label>
			</label>

			<label class="farazsms-survey-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'نوع پاداش', 'farazsms' ); ?></span>
				<select name="reward_type">
					<option value="coupon" <?php selected( $options['reward_type'] ?? 'coupon', 'coupon' ); ?>><?php esc_html_e( 'کد تخفیف اختصاصی', 'farazsms' ); ?></option>
					<option value="wallet" <?php selected( $options['reward_type'] ?? 'coupon', 'wallet' ); ?>><?php esc_html_e( 'واریز مبلغ به کیف پول کاربر', 'farazsms' ); ?></option>
				</select>
				<small><?php esc_html_e( 'حالت «کیف پول» مبلغ را مستقیم به کیف پول کاربر واریز می‌کند (برای کاربرِ مهمان که حساب ندارد، خودکار به کد تخفیف برمی‌گردد). در پیامکِ حالت کیف پول از متغیرهای %amount% و %balance% استفاده کنید.', 'farazsms' ); ?></small>
			</label>

			<label class="farazsms-survey-setting">
				<span><?php esc_html_e( 'مبلغ پاداش (تومان)', 'farazsms' ); ?></span>
				<input type="number" name="reward_amount" value="<?php echo esc_attr( $options['reward_amount'] ); ?>" min="1" dir="ltr">
			</label>

			<label class="farazsms-survey-setting">
				<span><?php esc_html_e( 'اعتبار کد تخفیف (روز)', 'farazsms' ); ?></span>
				<input type="number" name="reward_expiry_days" value="<?php echo esc_attr( $options['reward_expiry_days'] ); ?>" min="1" max="365" dir="ltr">
			</label>

			<label class="farazsms-survey-setting">
				<span><?php esc_html_e( 'زمان اعطای تخفیف', 'farazsms' ); ?></span>
				<select name="reward_timing">
					<option value="submitted" <?php selected( $options['reward_timing'], 'submitted' ); ?>><?php esc_html_e( 'بلافاصله پس از ثبت نظر', 'farazsms' ); ?></option>
					<option value="approved" <?php selected( $options['reward_timing'], 'approved' ); ?>><?php esc_html_e( 'پس از تأیید نظر در سایت', 'farazsms' ); ?></option>
				</select>
			</label>

			<label class="farazsms-survey-setting">
				<span><?php esc_html_e( 'کد الگوی پیامک تخفیف', 'farazsms' ); ?></span>
				<input type="text" name="reward_pattern_code" value="<?php echo esc_attr( $options['reward_pattern_code'] ); ?>" dir="ltr" id="farazsms-survey-reward-pattern-code">
			</label>

			<label class="farazsms-survey-setting farazsms-setting-wide">
				<span><?php esc_html_e( 'متن الگوی پیامک تخفیف', 'farazsms' ); ?></span>
				<textarea name="reward_message" id="farazsms-survey-reward-pattern-text" rows="5" class="farazsms-survey-pattern-text"><?php echo esc_textarea( $reward_message ); ?></textarea>
				<small><?php esc_html_e( 'متغیرها: %code%، %expire%. آدرس سایت به‌صورتِ خودکار (ثابت) به انتهای پترن افزوده می‌شود.', 'farazsms' ); ?></small>
			</label>

			<div class="farazsms-survey-save-row">
				<button type="submit" class="button button-primary"><?php esc_html_e( 'ذخیره تنظیمات', 'farazsms' ); ?></button>
				<button type="button" class="button" id="farazsms-survey-test-btn"><?php esc_html_e( 'ارسال پیامک تست به موبایل من', 'farazsms' ); ?></button>
				<input type="text" id="farazsms-survey-test-mobile" placeholder="<?php esc_attr_e( '09xxxxxxxxx', 'farazsms' ); ?>" dir="ltr" class="farazsms-survey-test-input">
				<span class="farazsms-survey-test-result"></span>
			</div>
		</form>

		<?php
		// v3.21.58: انتخابِ روشِ ارسالِ لینک (کوتاه‌کننده/سایتِ اصلی) — بیرونِ فرمِ بالا.
		farazsms_shortener_render_choice( 'survey', 'پیامک نظرسنجی' );
		?>

		<div class="farazsms-survey-card farazsms-survey-card-side">
			<h2><?php esc_html_e( 'ساخت الگو از روی متن', 'farazsms' ); ?></h2>
			<p class="farazsms-survey-help">
				<?php esc_html_e( 'متن الگو را در پایین بنویسید (می‌توانید از متغیرهای فهرست‌شده استفاده کنید) و دکمه «ساخت الگو» را بزنید. کد الگو خودکار در فیلد سمت چپ نوشته می‌شود.', 'farazsms' ); ?>
			</p>
			<textarea id="farazsms-survey-pattern-text" rows="6" class="farazsms-survey-pattern-text"><?php echo esc_textarea( $default_tpl ); ?></textarea>
			<div class="farazsms-survey-pattern-actions">
				<button type="button" class="button button-primary" id="farazsms-survey-create-pattern-btn"><?php esc_html_e( 'ساخت الگو', 'farazsms' ); ?></button>
				<span class="farazsms-survey-create-result"></span>
			</div>

			<h2><?php esc_html_e( 'ساخت الگوی پیامک تخفیف', 'farazsms' ); ?></h2>
			<p class="farazsms-survey-help">
				<?php esc_html_e( 'این الگو با خط PRO برای ارسال کد تخفیف پس از ثبت نظر استفاده می‌شود. متن باید آدرس سایت را در انتها داشته باشد.', 'farazsms' ); ?>
			</p>
			<div class="farazsms-survey-pattern-actions">
				<button type="button" class="button button-primary" id="farazsms-survey-create-reward-pattern-btn"><?php esc_html_e( 'ساخت الگوی تخفیف', 'farazsms' ); ?></button>
				<span class="farazsms-survey-reward-create-result"></span>
			</div>

			<h3 class="farazsms-survey-variables-title"><?php esc_html_e( 'متغیرهای قابل استفاده در متن الگو', 'farazsms' ); ?></h3>
			<div class="farazsms-survey-variables">
				<?php foreach ( $variables as $key => $label ) : ?>
					<div class="farazsms-survey-variable">
						<code dir="ltr">%<?php echo esc_html( $key ); ?>%</code>
						<span><?php echo esc_html( $label ); ?></span>
					</div>
				<?php endforeach; ?>
			</div>

			<div class="farazsms-survey-info-box">
				<strong><?php esc_html_e( 'صفحه نظرسنجی:', 'farazsms' ); ?></strong>
				<a href="<?php echo esc_url( $review_page ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $review_page ); ?></a>
				<p class="farazsms-survey-help-small">
					<?php esc_html_e( 'این صفحه به‌صورت خودکار هنگام فعال‌سازی افزونه ساخته شد. شورت‌کد آن', 'farazsms' ); ?>
					<code dir="ltr">[order_review]</code>
					<?php esc_html_e( 'است و در پیامک، با لینک', 'farazsms' ); ?>
					<code dir="ltr">%review_url%</code>
					<?php esc_html_e( 'به مشتری ارسال می‌شود.', 'farazsms' ); ?>
				</p>
			</div>

			<div class="farazsms-survey-info-box" style="margin-top:10px; background:#f0fdf4; border-color:#bbf7d0;">
				<strong><?php esc_html_e( 'نظرها کجا ثبت می‌شوند؟', 'farazsms' ); ?></strong>
				<p class="farazsms-survey-help-small" style="margin-top:4px;">
					<?php esc_html_e( 'نظرِ ثبت‌شده به‌عنوان «نقد و بررسیِ محصول» روی همان محصولِ سفارش ذخیره می‌شود (تبِ نقد و بررسیِ همان محصول)، با نوعِ', 'farazsms' ); ?>
					<code dir="ltr">review</code>
					<?php esc_html_e( 'و نشانِ «خریدارِ محصول». این نظرها برای موتورهای جستجو (UGC/سئو) دیده می‌شوند. نظرها در «دیدگاه‌های عمومی» ثبت نمی‌شوند و پیش از نمایش، نیازمندِ تأییدِ شما هستند.', 'farazsms' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="farazsms-survey-card">
		<h2><?php esc_html_e( 'راهنمای گام‌به‌گام', 'farazsms' ); ?></h2>
		<ol class="farazsms-survey-guide">
			<li><?php esc_html_e( 'مطمئن شوید کلید دسترسی (Api-Key) در «تنظیمات» افزونه وارد شده.', 'farazsms' ); ?></li>
			<li><?php esc_html_e( 'در پنل کنار، متن الگو را بنویسید (نمونه از قبل پر شده). از متغیرها استفاده کنید.', 'farazsms' ); ?></li>
			<li><?php esc_html_e( 'روی «ساخت الگو» کلیک کنید — درخواست تأیید الگو در پنل فراز اس‌ام‌اس ثبت می‌شود.', 'farazsms' ); ?></li>
			<li><?php esc_html_e( 'پس از تأیید الگو توسط ناظر فراز، فعال‌سازی بالا را روشن کنید.', 'farazsms' ); ?></li>
			<li><?php esc_html_e( 'وضعیت سفارش و تأخیر روز را انتخاب و ذخیره کنید.', 'farazsms' ); ?></li>
			<li><?php esc_html_e( 'با ارسال «پیامک تست» مطمئن شوید همه‌چیز درست کار می‌کند.', 'farazsms' ); ?></li>
		</ol>

		<div class="farazsms-survey-warning-box">
			<strong>⚠ نکته مهم برای تأیید الگو:</strong>
			<p>
				نام برند فروشگاه شما باید به‌صورت <strong>ثابت</strong> در متن الگو نوشته شود (مثلاً «فروشگاه پارسا»)، نه به‌صورت متغیر. پنل فراز اس‌ام‌اس الگوهایی را که نام برند را به‌صورت ثابت ندارند تأیید نمی‌کند، چون گیرنده پیامک باید بداند پیامک از سمت چه برند یا شرکتی ارسال شده است.
			</p>
		</div>
	</div>
	<?php
}

function farazsms_survey_render_reviews_tab() {
	$args = array(
		'number'  => 25,
		'orderby' => 'comment_date',
		'order'   => 'DESC',
		'meta_query' => array(
			array(
				'key'     => 'order_id',
				'compare' => 'EXISTS',
			),
		),
		'status'  => 'all',
	);
	$comments = get_comments( $args );
	?>
	<div class="farazsms-survey-card">
		<h2><?php esc_html_e( 'آخرین نظرات ثبت‌شده از طریق نظرسنجی', 'farazsms' ); ?></h2>
		<p class="farazsms-survey-help">
			<?php
			printf(
				/* translators: %s link to comments admin page */
				esc_html__( 'برای مدیریت کامل (تأیید/حذف) به %s بروید.', 'farazsms' ),
				'<a href="' . esc_url( admin_url( 'edit-comments.php' ) ) . '">' . esc_html__( 'مدیریت دیدگاه‌های وردپرس', 'farazsms' ) . '</a>'
			);
			?>
		</p>
		<table class="widefat striped farazsms-survey-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'شناسه', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'تاریخ', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'سفارش', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'محصول', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'مشتری', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'امتیاز', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'متن', 'farazsms' ); ?></th>
					<th><?php esc_html_e( 'وضعیت', 'farazsms' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $comments ) ) : ?>
					<tr><td colspan="8"><?php esc_html_e( 'هنوز نظری از طریق نظرسنجی ثبت نشده.', 'farazsms' ); ?></td></tr>
				<?php else : foreach ( $comments as $c ) :
					$order_id = (int) get_comment_meta( $c->comment_ID, 'order_id', true );
					$rating   = (int) get_comment_meta( $c->comment_ID, 'rating', true );
					$jdate    = farazsms_send_reports_to_jalali( $c->comment_date );
					$product_id = (int) $c->comment_post_ID;
					$product_title = $product_id ? get_the_title( $product_id ) : '';
					$status   = $c->comment_approved === '1' ? 'success' : ( $c->comment_approved === 'spam' ? 'danger' : 'warning' );
					$status_t = $c->comment_approved === '1' ? __( 'تأیید شده', 'farazsms' ) : ( $c->comment_approved === 'spam' ? __( 'هرزنامه', 'farazsms' ) : __( 'در انتظار', 'farazsms' ) );
					$edit_url = admin_url( 'comment.php?action=editcomment&c=' . $c->comment_ID );
				?>
					<tr>
						<td><?php echo esc_html( $c->comment_ID ); ?></td>
						<td class="farazsms-survey-date-cell"><?php echo esc_html( $jdate ); ?></td>
						<td>
							<?php if ( $order_id ) : ?>
								<a href="<?php echo esc_url( admin_url( 'post.php?post=' . $order_id . '&action=edit' ) ); ?>" target="_blank">#<?php echo esc_html( (string) $order_id ); ?></a>
							<?php else : ?> — <?php endif; ?>
						</td>
						<td><?php echo esc_html( $product_title !== '' ? $product_title : '—' ); ?></td>
						<td><?php echo esc_html( $c->comment_author !== '' ? $c->comment_author : '—' ); ?></td>
						<td><?php echo $rating > 0 ? str_repeat( '⭐', min( 5, $rating ) ) : '—'; ?></td>
						<td class="farazsms-survey-comment-cell"><?php echo esc_html( wp_trim_words( $c->comment_content, 12, '…' ) ); ?></td>
						<td>
							<span class="farazsms-status farazsms-status-<?php echo esc_attr( $status ); ?>"><?php echo esc_html( $status_t ); ?></span>
							<a href="<?php echo esc_url( $edit_url ); ?>" class="button button-small farazsms-survey-edit-btn" target="_blank"><?php esc_html_e( 'مرور', 'farazsms' ); ?></a>
						</td>
					</tr>
				<?php endforeach; endif; ?>
			</tbody>
		</table>
	</div>
	<?php
}

function farazsms_survey_render_inline() {
	$nonce = wp_create_nonce( 'farazsms_survey_admin' );
	?>
	<style>
	.farazsms-survey-wrapper .farazsms-survey-title-main { margin: 16px 0 8px; }
	.farazsms-survey-wrapper .farazsms-survey-tabs { display: flex; gap: 6px; border-bottom: 2px solid #e5e7eb; margin: 16px 0 22px; flex-wrap: wrap; }
	.farazsms-survey-wrapper .farazsms-survey-tab { padding: 10px 18px; text-decoration: none; color: #64748b; background: none; border: none; border-bottom: 2px solid transparent; margin-bottom: -2px; font-size: 13.5px; font-weight: 600; transition: color .15s, border-color .15s; }
	.farazsms-survey-wrapper .farazsms-survey-tab:hover { color: #365891; }
	.farazsms-survey-wrapper .farazsms-survey-tab.is-active { color: #365891; font-weight: 700; border-bottom-color: #365891; background: none; }
	.farazsms-survey-wrapper .farazsms-survey-range-bar { display: flex; gap: 6px; margin-bottom: 16px; }
	.farazsms-survey-wrapper .farazsms-survey-range { padding: 6px 14px; background: #fff; border: 1px solid #d1d5db; border-radius: 6px; color: #4b5563; text-decoration: none; font-size: 13px; }
	.farazsms-survey-wrapper .farazsms-survey-range.is-active { background: #4571ba; color: #fff; border-color: #4571ba; font-weight: 600; }
	.farazsms-survey-wrapper .farazsms-survey-stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin: 0 0 16px; }
	.farazsms-survey-wrapper .farazsms-survey-stat { background: #fff; padding: 16px; border: 1px solid #e5e7eb; border-radius: 8px; text-align: center; }
	.farazsms-survey-wrapper .farazsms-survey-stat .num { font-size: 26px; font-weight: 700; line-height: 1; color: #1f2937; }
	.farazsms-survey-wrapper .farazsms-survey-stat .num.farazsms-num-success { color: #047857; }
	.farazsms-survey-wrapper .farazsms-survey-stat .num.farazsms-num-info { color: #1d4ed8; }
	.farazsms-survey-wrapper .farazsms-survey-stat .num.farazsms-num-warning { color: #b45309; }
	.farazsms-survey-wrapper .farazsms-survey-stat .num.farazsms-num-muted { color: #6b7280; }
	.farazsms-survey-wrapper .farazsms-survey-stat .lbl { color: #6b7280; font-size: 12px; margin-top: 6px; }
	.farazsms-survey-wrapper .farazsms-survey-stat-link { display: flex; align-items: center; justify-content: center; }
	.farazsms-survey-wrapper .farazsms-survey-stat-link a { color: #4571ba; font-weight: 600; text-decoration: none; }
	.farazsms-survey-wrapper .farazsms-survey-stat-link a:hover { text-decoration: underline; }
	.farazsms-survey-wrapper .farazsms-survey-grid { display: grid; grid-template-columns: 1.4fr 1fr; gap: 16px; margin-bottom: 16px; }
	.farazsms-survey-wrapper .farazsms-survey-card { background: #fff; padding: 20px 24px; border: 1px solid #e5e7eb; border-radius: 10px; }
	.farazsms-survey-wrapper .farazsms-survey-card h2 { margin: 0 0 12px; font-size: 16px; }
	.farazsms-survey-wrapper .farazsms-survey-card h3 { margin: 16px 0 8px; font-size: 14px; }
	.farazsms-survey-wrapper .farazsms-survey-help { color: #50575e; margin: 0 0 12px; font-size: 13px; line-height: 1.7; }
	.farazsms-survey-wrapper .farazsms-survey-help-small { color: #6b7280; font-size: 12px; }
	.farazsms-survey-wrapper .farazsms-survey-setting { display: flex; flex-direction: column; gap: 5px; margin-bottom: 14px; font-size: 13px; }
	.farazsms-survey-wrapper .farazsms-setting-wide { grid-column: 1 / -1; }
	.farazsms-survey-wrapper .farazsms-survey-setting input,
	.farazsms-survey-wrapper .farazsms-survey-setting select { padding: 8px 10px; }
	.farazsms-survey-wrapper .farazsms-survey-setting small { color: #6b7280; font-size: 11px; margin-top: 4px; }
	.farazsms-survey-wrapper .farazsms-survey-switch { display: inline-flex; align-items: center; gap: 8px; font-size: 13px; }
	.farazsms-survey-wrapper .farazsms-survey-save-row { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; margin-top: 14px; padding-top: 14px; border-top: 1px dashed #e5e7eb; }
	.farazsms-survey-wrapper .farazsms-survey-test-input { padding: 7px 10px; min-width: 160px; }
	.farazsms-survey-wrapper .farazsms-survey-test-result { font-size: 13px; }
	.farazsms-survey-wrapper .farazsms-survey-test-result.success { color: #047857; }
	.farazsms-survey-wrapper .farazsms-survey-test-result.error { color: #b91c1c; }
	.farazsms-survey-wrapper .farazsms-survey-pattern-text { width: 100%; padding: 10px 12px; font-family: inherit; line-height: 1.7; border: 1px solid #d1d5db; border-radius: 6px; box-sizing: border-box; }
	.farazsms-survey-wrapper .farazsms-survey-pattern-actions { display: flex; align-items: center; gap: 10px; margin: 10px 0 14px; }
	.farazsms-survey-wrapper .farazsms-survey-create-result { font-size: 13px; }
	.farazsms-survey-wrapper .farazsms-survey-create-result.success { color: #047857; }
	.farazsms-survey-wrapper .farazsms-survey-create-result.error { color: #b91c1c; }
	.farazsms-survey-wrapper .farazsms-survey-reward-create-result { font-size: 13px; }
	.farazsms-survey-wrapper .farazsms-survey-reward-create-result.success { color: #047857; }
	.farazsms-survey-wrapper .farazsms-survey-reward-create-result.error { color: #b91c1c; }
	.farazsms-survey-wrapper .farazsms-survey-variables-title { margin: 10px 0 8px; font-size: 13px; color: #1f2937; }
	.farazsms-survey-wrapper .farazsms-survey-variables { display: grid; grid-template-columns: 1fr; gap: 6px; margin-bottom: 12px; }
	.farazsms-survey-wrapper .farazsms-survey-variable { display: flex; align-items: center; justify-content: space-between; padding: 6px 10px; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 6px; font-size: 12px; }
	.farazsms-survey-wrapper .farazsms-survey-variable code { background: #fff; padding: 2px 8px; border-radius: 4px; color: #365891; font-weight: 600; }
	.farazsms-survey-wrapper .farazsms-survey-variable code:hover { background: #eef2ff; cursor: pointer; }
	.farazsms-survey-wrapper .farazsms-survey-info-box { background: #f0f9ff; padding: 12px 14px; border: 1px solid #bae6fd; border-radius: 6px; font-size: 13px; }
	.farazsms-survey-wrapper .farazsms-survey-info-box a { color: #0369a1; word-break: break-all; }
	.farazsms-survey-wrapper .farazsms-survey-info-box code { background: #fff; padding: 1px 6px; border-radius: 3px; margin: 0 2px; }
	.farazsms-survey-wrapper .farazsms-survey-warning-box { background: #fef3c7; padding: 14px 18px; border: 1px solid #fbbf24; border-right: 4px solid #d97706; border-radius: 6px; margin-top: 18px; font-size: 13px; line-height: 1.8; }
	.farazsms-survey-wrapper .farazsms-survey-warning-box strong { color: #92400e; display: block; margin-bottom: 6px; }
	.farazsms-survey-wrapper .farazsms-survey-warning-box p { margin: 0; color: #78350f; }
	.farazsms-survey-wrapper .farazsms-survey-guide { padding-right: 22px; line-height: 2.1; font-size: 14px; }
	.farazsms-survey-wrapper .farazsms-survey-guide li { color: #374151; }
	.farazsms-survey-wrapper .farazsms-survey-table th,
	.farazsms-survey-wrapper .farazsms-survey-table td { padding: 10px 12px; vertical-align: middle; }
	.farazsms-survey-wrapper .farazsms-survey-date-cell { direction: ltr; font-variant-numeric: tabular-nums; }
	.farazsms-survey-wrapper .farazsms-survey-comment-cell { max-width: 320px; }
	.farazsms-survey-wrapper .farazsms-survey-edit-btn { margin-right: 6px; }
	.farazsms-survey-wrapper .farazsms-status { display: inline-block; padding: 2px 10px; border-radius: 999px; font-size: 12px; }
	.farazsms-survey-wrapper .farazsms-status-success { background: #d1f5e0; color: #006d28; }
	.farazsms-survey-wrapper .farazsms-status-warning { background: #fef3c7; color: #92400e; }
	.farazsms-survey-wrapper .farazsms-status-danger { background: #ffd7d7; color: #8a0a0a; }
	@media (max-width: 900px) {
		.farazsms-survey-wrapper .farazsms-survey-grid { grid-template-columns: 1fr; }
		.farazsms-survey-wrapper .farazsms-survey-stats { grid-template-columns: repeat(2, 1fr); }
	}
	</style>
	<script>
	(function(){
		var ajaxUrl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
		var nonce   = <?php echo wp_json_encode( $nonce ); ?>;

		// Click on a variable code → insert into the pattern textarea.
		var ta = document.getElementById('farazsms-survey-pattern-text');
		document.querySelectorAll('.farazsms-survey-variable code').forEach(function(el){
			el.addEventListener('click', function(){
				if (!ta) return;
				var val = el.textContent;
				var start = ta.selectionStart || ta.value.length;
				var end   = ta.selectionEnd || ta.value.length;
				ta.value = ta.value.slice(0, start) + val + ta.value.slice(end);
				ta.focus();
				ta.selectionStart = ta.selectionEnd = start + val.length;
			});
		});

		function bindPatternBuilder(buttonId, textareaId, codeInputId, resultSelector, purpose) {
			var btn = document.getElementById(buttonId);
			var textarea = document.getElementById(textareaId);
			var codeInput = document.getElementById(codeInputId);
			var result = document.querySelector(resultSelector);
			if (!btn || !textarea || !result) return;
			btn.addEventListener('click', function(){
				var msg = textarea.value.trim();
				if (!msg) { result.className = resultSelector.replace('.', '') + ' error'; result.textContent = 'متن الگو خالی است.'; return; }
				btn.disabled = true;
				result.className = resultSelector.replace('.', '');
				result.textContent = 'در حال ساخت...';
				var fd = new FormData();
				fd.append('action', 'farazsms_survey_create_pattern');
				fd.append('nonce', nonce);
				fd.append('message', msg);
				fd.append('purpose', purpose);
				fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
					.then(function(r){ return r.json(); })
					.then(function(json){
						if (json.success) {
							result.className = resultSelector.replace('.', '') + ' success';
							result.textContent = (json.data && json.data.message) || 'انجام شد.';
							if (codeInput && json.data && json.data.pattern_code) {
								codeInput.value = json.data.pattern_code;
							}
						} else {
							result.className = resultSelector.replace('.', '') + ' error';
							result.textContent = (json.data && json.data.message) || 'خطا در ساخت.';
						}
					})
					.catch(function(){ result.className = resultSelector.replace('.', '') + ' error'; result.textContent = 'خطا در ارتباط با سرور.'; })
					.then(function(){ btn.disabled = false; });
			});
		}
		bindPatternBuilder('farazsms-survey-create-pattern-btn', 'farazsms-survey-pattern-text', 'farazsms-survey-pattern-code', '.farazsms-survey-create-result', 'survey');
		bindPatternBuilder('farazsms-survey-create-reward-pattern-btn', 'farazsms-survey-reward-pattern-text', 'farazsms-survey-reward-pattern-code', '.farazsms-survey-reward-create-result', 'reward');

		// Send test SMS.
		var testBtn = document.getElementById('farazsms-survey-test-btn');
		var testIn  = document.getElementById('farazsms-survey-test-mobile');
		var testRes = document.querySelector('.farazsms-survey-test-result');
		if (testBtn && testIn) {
			testBtn.addEventListener('click', function(){
				var mob = testIn.value.trim();
				if (!mob) { testRes.className = 'farazsms-survey-test-result error'; testRes.textContent = 'شماره موبایل را وارد کنید.'; return; }
				testBtn.disabled = true;
				testRes.className = 'farazsms-survey-test-result';
				testRes.textContent = 'در حال ارسال...';
				var fd = new FormData();
				fd.append('action', 'farazsms_survey_send_test');
				fd.append('nonce', nonce);
				fd.append('mobile', mob);
				fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: fd })
					.then(function(r){ return r.json(); })
					.then(function(json){
						testRes.className = 'farazsms-survey-test-result ' + (json.success ? 'success' : 'error');
						testRes.textContent = (json.data && json.data.message) || 'انجام شد.';
					})
					.catch(function(){ testRes.className = 'farazsms-survey-test-result error'; testRes.textContent = 'خطا.'; })
					.then(function(){ testBtn.disabled = false; });
			});
		}
	})();
	</script>
	<?php
}
