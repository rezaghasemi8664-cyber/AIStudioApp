<?php
/**
 * مهاجرتِ نام‌گذاری: wto_ → farazsms_  (شبکه‌ی ایمنیِ یکدست‌سازیِ کامل).
 *
 * این ماژول تضمین می‌کند هیچ سایتِ نصب‌شده‌ای هنگامِ یکدست‌سازیِ نام به farazsms
 * داده از دست ندهد. یک‌بار اجرا می‌شود (version-gated)، idempotent، و **غیرمخرب**:
 *   - optionها: کپی می‌شوند (wto_* باقی می‌ماند به‌عنوانِ پشتیبان؛ بعدها حذف).
 *   - جداول: با گاردِ وجود، RENAME می‌شوند (اتمیک).
 *   - metaها: کلیدها به‌روزرسانیِ نام می‌شوند.
 *   - cronها: هوک‌های قدیمیِ wto_ پاک می‌شوند؛ کدِ جدید با همان گاردهای زمان‌بندی،
 *     خودش هوک‌های farazsms_ را دوباره ثبت می‌کند.
 *
 * مبتنی بر پیشوند است (هر کلید/جدولِ wto_) تا هیچ‌چیز جا نیفتد.
 *
 * اجرا روی plugins_loaded اولویتِ ۱ (قبل از هر کدِ قابلیت) تا حتی در درخواستِ
 * فرانت‌اندِ پس از ارتقا هم داده آماده باشد. بررسیِ گیتِ نسخه ارزان است.
 *
 * @package FarazSMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** نسخه‌ی schema مهاجرت — با هر تغییرِ منطق بالا می‌رود. */
if ( ! defined( 'FARAZSMS_MIGRATION_VERSION' ) ) {
	// نسخه ۲: رفعِ برخوردِ جدولِ والت (wto_wallet → farazsms_store_wallet).
	// نسخه ۳: پاک‌سازیِ backupهای wto_* (فقط جایی که farazsms_* وجود دارد) — حذفِ
	//         انباشتِ دائمیِ ردیف‌های تکراری در wp_options.
	// نسخه ۵: پاک‌کردنِ کلیدِ دسترسی از کارهای **از قبل پارک‌شده** (v3.22.202
	//         تولیدکننده را بست، ولی ردیف‌های موجود روی دیسک دست‌نخورده ماندند).
	define( 'FARAZSMS_MIGRATION_VERSION', '5' );
}

add_action( 'plugins_loaded', 'farazsms_migration_maybe_run', 1 );

/**
 * گیتِ نسخه: اگر مهاجرت قبلاً انجام شده، فوری برگرد (هزینه: یک get_option).
 *
 * @return void
 */
function farazsms_migration_maybe_run() {
	if ( get_option( 'farazsms_migration_naming_done' ) === FARAZSMS_MIGRATION_VERSION ) {
		return;
	}
	// قفلِ کوتاه‌مدت تا دو درخواستِ هم‌زمان، مهاجرت را دوبار نزنند.
	if ( get_transient( 'farazsms_migration_lock' ) ) {
		return;
	}
	set_transient( 'farazsms_migration_lock', 1, 5 * MINUTE_IN_SECONDS );

	farazsms_migration_run_options();
	farazsms_migration_run_meta();
	farazsms_migration_run_wallet(); // قبل از rename عمومی — برخوردِ نام را حل می‌کند
	farazsms_migration_run_tables();
	farazsms_migration_run_crons();
	farazsms_migration_cleanup_wto_backups(); // نسخه ۳ — حذفِ امنِ backupهای wto_*
	farazsms_migration_strip_parked_api_keys(); // نسخه ۵ — کلید از کارهای پارک‌شده

	farazsms_migration_autoload_schema_flags();
	update_option( 'farazsms_migration_naming_done', FARAZSMS_MIGRATION_VERSION, true );
	delete_transient( 'farazsms_migration_lock' );
}

/**
 * کپیِ همه‌ی optionهای wto_* به farazsms_* (غیرمخرب — قدیمی باقی می‌ماند).
 *
 * @return void
 */
function farazsms_migration_run_options() {
	global $wpdb;
	// خودِ کلیدِ مهاجرت را migrate نکن.
	$rows = $wpdb->get_col(
		"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'wto\\_%'"
	);
	if ( empty( $rows ) ) {
		return;
	}
	foreach ( $rows as $old_name ) {
		$new_name = 'farazsms_' . substr( $old_name, 4 ); // حذفِ 'wto_'
		// اگر مقصد از قبل هست (اجرای قبلی)، دست نزن.
		if ( $wpdb->get_var( $wpdb->prepare( "SELECT option_id FROM {$wpdb->options} WHERE option_name = %s", $new_name ) ) ) {
			continue;
		}
		// با API هسته کپی کن تا autoload و serialize درست مدیریت شود.
		$value = get_option( $old_name, null );
		if ( $value !== null ) {
			add_option( $new_name, $value );
		}
	}
}

/**
 * پاک‌سازیِ امنِ backupهای wto_* (نسخه ۳).
 *
 * در نسخه ۱، optionهای wto_* به farazsms_* کپی شدند و عمداً به‌عنوان پشتیبان ماندند.
 * حالا که چند نسخه گذشته و farazsms_* پایدار است، نسخه‌ی wto_ را حذف می‌کنیم تا
 * انباشتِ دائمیِ ردیف‌های تکراری در wp_options از بین برود. **فقط** وقتی نسخه‌ی
 * farazsms_ آن کلید وجود دارد حذف می‌شود تا هیچ داده‌ای گم نشود.
 *
 * @return void
 */
function farazsms_migration_cleanup_wto_backups() {
	global $wpdb;
	$rows = $wpdb->get_col(
		"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE 'wto\\_%'"
	);
	if ( empty( $rows ) ) {
		return;
	}
	foreach ( $rows as $old_name ) {
		$new_name = 'farazsms_' . substr( $old_name, 4 );
		// فقط اگر نسخه‌ی farazsms_ وجود دارد، backup را حذف کن (وگرنه داده گم می‌شود).
		if ( $wpdb->get_var( $wpdb->prepare( "SELECT option_id FROM {$wpdb->options} WHERE option_name = %s", $new_name ) ) ) {
			delete_option( $old_name );
		}
	}
}

/**
 * تغییرِ نامِ کلیدهای user_meta و post_meta از wto_ به farazsms_.
 *
 * @return void
 */
/**
 * حذفِ کلیدِ دسترسی از کارهای پس‌زمینه‌ی **از قبل صف‌شده**.
 *
 * ⚠️ چرا لازم است: تا v3.22.201 کارِ ثبتِ مخاطب کلید را در آرگومان‌هایش حمل
 * می‌کرد و کارِ اجرانشده در آپشن سریال می‌شود. v3.22.202 تولیدکننده را بست،
 * ولی ردیف‌هایی که همان لحظه روی دیسک بودند دست‌نخورده ماندند — یعنی روی
 * سایتِ در حالِ ارتقا، کلیدِ خام تا زمانِ تخلیه (روی هاستِ بدونِ کرون: نامعلوم)
 * باقی می‌ماند. رمزگذاریِ کلید در ۳٫۲۲٫۱۰۹ دقیقاً برای جلوگیری از همین بود.
 *
 * دو محلِ ذخیره‌سازی پاک می‌شوند: باقی‌مانده‌ی صف، و رویدادهای کرونِ مسیرِ
 * قدیمی. کارها **حذف نمی‌شوند** — فقط کلید از بارشان برداشته می‌شود؛ کارگر
 * از v3.22.202 خودش کلید را می‌خوانَد.
 *
 * @return void
 */
function farazsms_migration_strip_parked_api_keys() {
	$spill = get_option( 'farazsms_send_queue_spill', array() );
	if ( is_array( $spill ) && ! empty( $spill ) ) {
		$changed = false;
		foreach ( $spill as $i => $job ) {
			if ( ! is_array( $job ) || empty( $job['args'] ) || ! is_array( $job['args'] ) ) {
				continue;
			}
			foreach ( $job['args'] as $j => $arg ) {
				if ( is_array( $arg ) && array_key_exists( 'api_key', $arg ) ) {
					unset( $spill[ $i ]['args'][ $j ]['api_key'] );
					$changed = true;
				}
			}
			// شکلِ موقعیتیِ کلید (بالا را ببینید).
			$cb = isset( $job['callback'] ) ? (string) $job['callback'] : '';
			if ( $cb === 'farazsms_gf_pb_push_chunk' && isset( $job['args'][2] ) && is_string( $job['args'][2] ) && $job['args'][2] !== '' ) {
				$spill[ $i ]['args'][2] = '';
				$changed                = true;
			}
		}
		if ( $changed ) {
			update_option( 'farazsms_send_queue_spill', $spill, false );
		}
	}

	// رویدادهای کرونِ مسیرِ قدیمی: با API عمومی دوباره زمان‌بندی می‌شوند تا
	// کلیدِ رویداد (که وردپرس از آرگومان‌ها می‌سازد) خودش درست بیفتد.
	$cron = function_exists( '_get_cron_array' ) ? _get_cron_array() : array();
	if ( ! is_array( $cron ) ) {
		return;
	}
	foreach ( $cron as $timestamp => $hooks ) {
		if ( ! isset( $hooks['farazsms_async_run'] ) || ! is_array( $hooks['farazsms_async_run'] ) ) {
			continue;
		}
		foreach ( $hooks['farazsms_async_run'] as $event ) {
			$args    = isset( $event['args'] ) && is_array( $event['args'] ) ? $event['args'] : array();
			$payload = isset( $args[0] ) && is_array( $args[0] ) ? $args[0] : null;
			if ( $payload === null || empty( $payload['args'] ) || ! is_array( $payload['args'] ) ) {
				continue;
			}
			$dirty = false;
			foreach ( $payload['args'] as $j => $arg ) {
				if ( is_array( $arg ) && array_key_exists( 'api_key', $arg ) ) {
					unset( $payload['args'][ $j ]['api_key'] );
					$dirty = true;
				}
			}
			// ⚠️ شکلِ دومِ کلید: نسخه‌های تا ۳٫۲۲٫۲۰۰ کلید را به‌صورتِ
			// آرگومانِ **موقعیتی** می‌فرستادند (سومین آرگومانِ تکه‌ی گرویتی)،
			// نه داخلِ آرایه. با نگاه‌کردنِ فقط به آرایه‌ها، سایتی که از آن
			// نسخه‌ها ارتقا می‌دهد کلیدِ خامش را نگه می‌داشت.
			$cb = isset( $payload['callback'] ) ? (string) $payload['callback'] : '';
			if ( $cb === 'farazsms_gf_pb_push_chunk' && isset( $payload['args'][2] ) && is_string( $payload['args'][2] ) && $payload['args'][2] !== '' ) {
				$payload['args'][2] = '';
				$dirty              = true;
			}
			if ( ! $dirty ) {
				continue;
			}
			// ⚠️ هر دو مقدارِ بازگشتی خوانده می‌شوند.
			//
			// وردپرس رویداد را با md5(serialize(args)) کلید می‌زند و برای زمانِ
			// **گذشته** — که کارِ جامانده تقریباً همیشه دارد — کلِ گذشته را
			// برای کلیدِ تکراری می‌گردد. یعنی اگر دو رویدادِ آلوده پس از
			// پاک‌شدنِ کلید بارِ یکسانی پیدا کنند، زمان‌بندیِ دومی رد می‌شود و
			// آن کار **گم** می‌شود. و اگر برداشتنِ رویداد شکست بخورد (افزونه‌ای
			// که کرون را جایگزین کرده)، افزودنِ نسخه‌ی تمیز یعنی اجرای دوتایی.
			if ( false === wp_unschedule_event( (int) $timestamp, 'farazsms_async_run', $args ) ) {
				continue; // دست‌نخورده می‌ماند؛ گم‌شدن بدتر از ماندنِ کلید است.
			}
			if ( false === wp_schedule_single_event( (int) $timestamp, 'farazsms_async_run', array( $payload ) ) ) {
				// نسخه‌ی تمیز پذیرفته نشد (کلیدِ تکراری). اصل را برگردان تا کار
				// از دست نرود، و ردش را بگذار.
				wp_schedule_single_event( (int) $timestamp, 'farazsms_async_run', $args );
				if ( function_exists( 'farazsms_send_diag_log' ) ) {
					farazsms_send_diag_log( '', '', 'migration:key_strip_declined', array(
						'source' => 'migration',
						'detail' => 'ts=' . (int) $timestamp,
					) );
				}
			}
		}
	}
}

function farazsms_migration_run_meta() {
	global $wpdb;
	// کلیدهای metaی wto_ معدود و مختصِ همین افزونه‌اند؛ تغییرِ نامِ ساده کافی است.
	// idempotent: پس از تغییر، دیگر کلیدِ wto_ نمی‌ماند پس اجرای دوباره no-op است.
	$wpdb->query(
		"UPDATE {$wpdb->usermeta} SET meta_key = CONCAT('farazsms_', SUBSTRING(meta_key, 5)) WHERE meta_key LIKE 'wto\\_%'"
	);
	$wpdb->query(
		"UPDATE {$wpdb->postmeta} SET meta_key = CONCAT('farazsms_', SUBSTRING(meta_key, 5)) WHERE meta_key LIKE 'wto\\_%'"
	);
}

/**
 * تغییرِ نامِ جداولِ سفارشیِ wp_wto_* به wp_farazsms_* (با گاردِ وجود).
 *
 * @return void
 */
function farazsms_migration_run_tables() {
	global $wpdb;
	$like   = $wpdb->esc_like( $wpdb->prefix . 'wto_' ) . '%';
	$tables = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );
	if ( empty( $tables ) ) {
		return;
	}
	$plen = strlen( $wpdb->prefix );
	foreach ( $tables as $old_table ) {
		$suffix    = substr( $old_table, $plen ); // 'wto_xxx'
		// wto_wallet جداگانه در farazsms_migration_run_wallet مدیریت می‌شود (برخوردِ نام).
		if ( $suffix === 'wto_wallet' ) {
			continue;
		}
		$new_table = $wpdb->prefix . 'farazsms_' . substr( $suffix, 4 );
		// اگر مقصد از قبل هست، RENAME نکن (idempotent).
		$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $new_table ) );
		if ( $exists ) {
			continue;
		}
		// نام جداول از ساختار داخلی می‌آید (نه ورودیِ کاربر) → امن برای RENAME.
		$wpdb->query( "RENAME TABLE `{$old_table}` TO `{$new_table}`" );
	}
}

/**
 * رفعِ برخوردِ جدولِ والت.
 *
 * والتِ هسته (قبلاً wp_wto_wallet، schema با used_amount) با والتِ ماژولِ ورود
 * (wp_farazsms_wallet، schema متفاوت) هم‌نام می‌شد. والتِ هسته به نامِ مجزای
 * wp_farazsms_store_wallet منتقل می‌شود تا هر دو سالم بمانند. تمامِ حالت‌های ممکنِ
 * سایت‌ها پوشش داده می‌شود (idempotent).
 *
 * @return void
 */
function farazsms_migration_run_wallet() {
	global $wpdb;
	$old   = $wpdb->prefix . 'wto_wallet';
	$store = $wpdb->prefix . 'farazsms_store_wallet';
	$fsms  = $wpdb->prefix . 'farazsms_wallet';

	$exists = function ( $t ) use ( $wpdb ) {
		return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $t ) ) === $t;
	};

	if ( $exists( $store ) ) {
		// قبلاً منتقل شده — فقط تأییدِ کش را بازنشانی کن.
		delete_transient( 'farazsms_wallet_db_verified' );
		return;
	}

	if ( $exists( $old ) ) {
		// حالتِ رایج: rename عمومی به‌خاطرِ وجودِ farazsms_wallet (ماژولِ ورود) رد شده بود.
		$wpdb->query( "RENAME TABLE `{$old}` TO `{$store}`" );
		delete_transient( 'farazsms_wallet_db_verified' );
		return;
	}

	// حالتِ مرزی: rename عمومیِ نسخه ۱ روی سایتی که ماژولِ ورود نداشت، wto_wallet را
	// به farazsms_wallet برده. اگر farazsms_wallet ستونِ used_amount دارد، یعنی همان
	// schema هسته است → به نامِ مجزا منتقلش کن (ماژولِ ورود جدولِ خودش را دوباره می‌سازد).
	if ( $exists( $fsms ) ) {
		// نامِ جدول از ساختار داخلی است (نه ورودیِ کاربر) → امن برای درون‌گذاری.
		$has_used = $wpdb->get_var( "SHOW COLUMNS FROM `{$fsms}` LIKE 'used_amount'" );
		if ( $has_used ) {
			$wpdb->query( "RENAME TABLE `{$fsms}` TO `{$store}`" );
			delete_transient( 'farazsms_wallet_db_verified' );
		}
	}
	// اگر هیچ‌کدام نبود: سایتِ تازه است؛ کدِ هسته خودش store_wallet را می‌سازد.
}

/**
 * پاک‌سازیِ هوک‌های cronِ قدیمیِ wto_. کدِ جدید (farazsms_) خودش با گاردهای
 * زمان‌بندیِ موجود، رویدادها را دوباره ثبت می‌کند.
 *
 * @return void
 */
function farazsms_migration_run_crons() {
	$crons = _get_cron_array();
	if ( ! is_array( $crons ) ) {
		return;
	}
	$old_hooks = array();
	foreach ( $crons as $events ) {
		if ( ! is_array( $events ) ) {
			continue;
		}
		foreach ( array_keys( $events ) as $hook ) {
			if ( strpos( $hook, 'wto_' ) === 0 ) {
				$old_hooks[ $hook ] = true;
			}
		}
	}
	foreach ( array_keys( $old_hooks ) as $hook ) {
		wp_clear_scheduled_hook( $hook );
	}
}

/**
 * پرچم‌های «نسخه‌ی اسکیما» را autoload می‌کند.
 *
 * این شش آپشن مقدارِ اسکالرِ کوچکی دارند و روی هوکِ بی‌قیدِ init/plugins_loaded در **هر**
 * درخواستِ فرانت خوانده می‌شوند تا معلوم شود اسکیما به‌روز است یا نه. چون با autoload=false
 * نوشته شده بودند، هر خواندن یک کوئریِ جدا بود — روی سایتی با ووکامرس و المنتور و ماژولِ
 * ورود، ۹ کوئریِ اضافه روی هر بازدیدِ کش‌نشده.
 *
 * چرا این تابع لازم است و عوض‌کردنِ آرگومانِ سوم کافی نیست: update_option وقتی مقدار تغییر
 * نکند زودهنگام برمی‌گردد و ستونِ autoload را دست نمی‌زند. پس سایت‌هایی که این پرچم‌ها را
 * از قبل دارند — یعنی همه‌ی نصب‌های موجود — بدونِ این تابع هیچ بهبودی نمی‌بینند.
 *
 * چرا با wp_set_option_autoload و نه SQLِ مستقیم: از وردپرس ۶٫۶ مقدارهای ستونِ autoload
 * دیگر فقط yes/no نیستند («on»، «off»، «auto»، «auto-on»، «auto-off»). نسخه‌ی اولِ همین
 * تابع `WHERE autoload = 'no'` می‌زد و روی هر سایتِ به‌روزی صفر ردیف می‌گرفت — یعنی کاری
 * که ادعا می‌کرد را انجام نمی‌داد. یافته‌ی بازبینیِ ۳٫۲۲٫۱۹۷.
 *
 * @return void
 */
function farazsms_migration_autoload_schema_flags() {
	$flags = array(
		'farazsms_wallet_db_installed',
		'farazsms_login_module_db_ready',
		'farazsms_login_gate_checkout_migrated',
		'farazsms_send_diag_db',
		'farazsms_next_gf_db_version',
		'farazsms_next_elementor_db_version',
	);

	if ( function_exists( 'wp_set_option_autoload' ) ) {
		foreach ( $flags as $name ) {
			wp_set_option_autoload( $name, true );
		}
		return;
	}

	// وردپرسِ پیش از ۶٫۴ (هدرِ افزونه حداقل ۵٫۸ را پشتیبانی می‌کند): آن‌جا ستون فقط
	// yes/no می‌گیرد و تابعِ بالا وجود ندارد.
	global $wpdb;
	$changed = 0;
	foreach ( $flags as $name ) {
		$changed += (int) $wpdb->update(
			$wpdb->options,
			array( 'autoload' => 'yes' ),
			array( 'option_name' => $name, 'autoload' => 'no' ),
			array( '%s' ),
			array( '%s', '%s' )
		);
	}
	if ( $changed > 0 ) {
		wp_cache_delete( 'alloptions', 'options' );
	}
}
