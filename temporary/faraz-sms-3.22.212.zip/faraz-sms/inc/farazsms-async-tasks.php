<?php
/**
 * Async Task Helper — v3.18.0
 *
 * چرا این فایل؟
 *  عملیات سنگین (مثلاً import ۵۰۰۰ مخاطب در GF Phonebook، یا dispatch ارسال
 *  انبوه پیامک) اگر sync اجرا شوند:
 *    - PHP timeout (max_execution_time) می‌خورند
 *    - Memory exhaust می‌شوند
 *    - User experience: «صفحه قفل کرد...»
 *
 *  راه‌حل: Action Scheduler — کتابخانه‌ای که WooCommerce هم استفاده می‌کند و
 *  در همه‌ی سایت‌های WC از قبل لود است.
 *
 *  این wrapper:
 *    - اگر AS در دسترس بود → کار را در background queue می‌اندازد
 *    - اگر نبود → رویدادِ تک‌بارِ کرون (وردپرس اجراکننده را با درخواستِ
 *      لوپ‌بکِ غیرمنتظر صدا می‌زند، پس درخواستِ فعلی معطل نمی‌ماند)
 *
 *  v3.22.198: پله‌ی «اگر هیچ‌کدام نبود، همان‌جا اجرا کن» حذف شد. آن پله روی
 *  mod_php — یعنی هاستِ اشتراکیِ ارزان، بازارِ هدفِ افزونه — هر فراخوانی را به
 *  اجرای همگام روی درخواستِ کاربر تبدیل می‌کرد، در حالی که نامِ تابع خلافش را
 *  می‌گفت و فراخواننده‌ها رویش حساب باز کرده بودند.
 *
 *  ⚠️ v3.22.202 — این فایل دیگر «راهِ دومِ صف‌گذاری» نیست.
 *  farazsms_async_dispatch() و farazsms_async_schedule_via_cron() حذف شدند: دو
 *  مسیرِ موازیِ به‌تعویق‌انداختن (این‌یکی و صفِ مشترک) یعنی هر قابلیتی که به صف
 *  اضافه می‌شد — باقی‌مانده‌ی روی دیسک، کچ‌آپِ پیشخوان، سقفِ حالتِ اجراکننده —
 *  فقط نصفِ ارسال‌ها را می‌گرفت. تنها راهِ صف‌گذاری اکنون این است:
 *
 *    farazsms_queue_task( 'my-channel', 'my_callback', array( $arg1, $arg2 ) );
 *
 *  آنچه این‌جا مانده فقط **مصرف‌کننده** است، نه تولیدکننده:
 *  هوکِ farazsms_async_run و handlerش تخلیه‌ی کارهایی‌اند که نسخه‌های پیش از
 *  ۳٫۲۲٫۲۰۲ زمان‌بندی کرده‌اند و در لحظه‌ی ارتقا هنوز اجرا نشده بودند (کرون یا
 *  Action Scheduler). با حذفِ handler آن کارها بی‌صدا می‌مردند — یعنی پیامکِ
 *  سفارشی که درست پیش از آپدیت صف شده بود، هرگز نمی‌رفت.
 *  شرطِ حذفِ نهایی: وقتی هیچ سایتی از نسخه‌ی پیش از ۳٫۲۲٫۲۰۲ ارتقا نمی‌دهد.
 *
 *  callback باید function نام‌دار باشد (نه closure — AS closures را serialize نمی‌کند).
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/*
 * farazsms_async_available() در v3.22.202 حذف شد.
 *
 * ⚠️ تنها دلیلِ وجودش انتخابِ پله‌ی نردبانِ همین فایل بود. با رفتنِ نردبان،
 * آخرین دو فراخواننده‌اش هم رفتند و چیزی جز یک درزِ تزریقِ بی‌مصرف نماند —
 * که در تست هم همان را «شاخه‌ی سایتِ بدونِ ووکامرس» جا می‌زد و تستی می‌ساخت
 * که هیچ کدِ زنده‌ای را نمی‌سنجید. تصمیمِ «چطور به تعویق بیندازیم» اکنون
 * فقط در صفِ مشترک است.
 */

/**
 * v3.22.53: فراخوانیِ callback با مدیریتِ درستِ آرگومان‌ها روی همه‌ی نسخه‌های PHP.
 *
 * قرارداد این است که $args یا «لیستِ positionalِ آرگومان‌ها» است
 * (spread می‌شود) یا یک آرایه‌ی associativeِ واحد که خودِ worker به‌عنوانِ یک آرگومان می‌خواهد.
 * روی PHP 8 پاس‌دادنِ آرایه‌ی associative به call_user_func_array خطای «Unknown named parameter»
 * می‌داد و worker بی‌صدا اجرا نمی‌شد (باگِ همگام‌سازیِ دفترچه روی PHP 8). این‌جا تفکیک می‌کنیم:
 * آرایه‌ی لیستی → spread؛ آرایه‌ی associative → یک آرگومانِ واحد.
 *
 * @param callable $cb
 * @param mixed    $args
 * @return mixed
 */
function farazsms_async_call( $cb, $args ) {
	if ( ! is_callable( $cb ) ) {
		return false;
	}
	$args = is_array( $args ) ? $args : array();
	$is_list = ( $args === array() ) || ( array_keys( $args ) === range( 0, count( $args ) - 1 ) );
	if ( $is_list ) {
		return call_user_func_array( $cb, $args );
	}
	return call_user_func( $cb, $args );
}

/*
 * سه تابعِ صف‌گذارِ این فایل در v3.22.202 حذف شدند:
 *   farazsms_async_dispatch()          — فراخواننده‌ی تولیدی نداشت؛ همه به صفِ مشترک رفتند.
 *   farazsms_async_schedule_via_cron() — فقط پله‌ی داخلیِ همان دیسپچر بود.
 *   farazsms_async_dispatch_delayed()  — هرگز فراخواننده‌ی تولیدی نداشت.
 * تأخیر و باقی‌مانده و کچ‌آپ را اکنون صفِ مشترک انجام می‌دهد.
 */


// تخلیه‌ی کارهای زمان‌بندی‌شده‌ی نسخه‌های پیشین (بالا را ببینید).
add_action( 'farazsms_async_run', 'farazsms_async_run_handler', 10, 1 );
function farazsms_async_run_handler( $payload ) {
	if ( ! is_array( $payload ) ) return;
	$cb   = isset( $payload['callback'] ) ? (string) $payload['callback'] : '';
	$args = isset( $payload['args'] ) && is_array( $payload['args'] ) ? $payload['args'] : array();
	// ⚠️ همان اجازه‌نامه‌ی صف، این‌جا هم. این payload از آپشنِ cron خوانده
	// می‌شود — دقیقاً همان محلِ ذخیره‌سازی و همان تهدیدی که گاردِ صف برایش
	// نوشته شد. بدونِ این، مسیرِ قدیمی یک درِ باز کنارِ درِ قفل‌شده بود.
	if ( $cb !== '' && ! farazsms_queue_callback_is_ours( $cb ) ) {
		farazsms_send_diag_log( '', '', 'foreign_task: ' . $cb, array( 'source' => 'async-tasks' ) );
		return;
	}
	if ( $cb !== '' && is_callable( $cb ) ) {
		farazsms_async_call( $cb, $args );
		return;
	}
	// کارِ تعویق‌افتاده می‌تواند در درخواستی اجرا شود که فایلِ تعریفِ callback
	// در آن بار نشده. رد کردنِ بی‌صدا یعنی گم‌شدنِ نامرئی.
	if ( function_exists( 'farazsms_send_diag_log' ) ) {
		farazsms_send_diag_log( '', '', 'uncallable_task: ' . $cb, array( 'source' => 'async-tasks' ) );
	}
}
