<?php
/*
*
*	***** Faraz woo Scheduled sms *****
*
*	Core Functions
*	
*/
if ( ! defined( 'WPINC' ) ) {
	die;
}
// HPOS detection uses WooCommerce's public OrderUtil API (WC 7.1+).
// Importing Internal\* is unsafe — WooCommerce reserves the right to break that namespace.

/**
 * مبلغ را برای «متنِ پیامک» به متنِ ساده تبدیل می‌کند.
 *
 * wc_price بینِ عدد و واحد یک &nbsp; (فاصله‌ی سختِ HTML) می‌گذارد و markup دارد.
 * wp_strip_all_tags فقط تگ را حذف می‌کند نه entity را؛ پس &nbsp; به‌صورتِ متن داخلِ
 * پیامک می‌ماند. این helper تگ‌ها را حذف، entityها را decode و فاصله‌ی سخت/صفرعرض را
 * به فاصله‌ی معمولی تبدیل و فاصله‌های اضافی را جمع می‌کند.
 *
 * ورودی می‌تواند عددِ خام باشد (که خودش wc_price می‌شود) یا خروجیِ آماده‌ی wc_price (HTML).
 *
 * @param float|string $amount
 * @return string
 */
function farazsms_price_plain( $amount ) {
	if ( is_numeric( $amount ) ) {
		if ( function_exists( 'wc_price' ) ) {
			$amount = wc_price( (float) $amount );
		} else {
			return function_exists( 'number_format_i18n' ) ? number_format_i18n( (float) $amount ) : number_format( (float) $amount );
		}
	}
	$text = wp_strip_all_tags( (string) $amount );
	$text = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );
	// U+00A0 (nbsp)، U+200B (zero-width space)، U+200C (نیم‌فاصله‌ی نامرئی) → فاصله‌ی معمولی.
	$text = str_replace( array( "\xC2\xA0", "\xE2\x80\x8B", "\xE2\x80\x8C" ), ' ', $text );
	$text = preg_replace( '/\s+/u', ' ', $text );
	return trim( (string) $text );
}

/**
 * چک نسخه جدید افزونه از سایت فراز اس ام اس
 * این تابع خودش از wp-cron استفاده نمی‌کند و فقط زمانی که در پیشخوان اجرا شود
 * (حداکثر هر ۲۴ ساعت یک‌بار) نسخه را از endpoint JSON می‌خواند.
 */
function farazsms_check_for_updates() {
	$local_version = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '0.0.0';
	$version_endpoint = 'https://frzs.ir/plugin-version';
	$download_url = 'https://farazsms.com/farazsms-wordpress-plugin/';

	$response = wp_remote_get(
		$version_endpoint,
		array(
			'timeout'     => 15,
			'redirection' => 5,
			'headers'     => array(
				'Accept' => 'application/json',
			),
		)
	);

	if ( is_wp_error( $response ) ) {
		update_option( 'farazsms_last_check_time', time(), false );
		return;
	}

	$code = wp_remote_retrieve_response_code( $response );
	if ( 200 !== $code ) {
		update_option( 'farazsms_last_check_time', time(), false );
		return;
	}

	$body = wp_remote_retrieve_body( $response );
	if ( empty( $body ) ) {
		update_option( 'farazsms_last_check_time', time(), false );
		return;
	}

	$remote_version = '';

	// حالت اصلی: JSON با کلید version
	$data = json_decode( $body, true );
	if ( is_array( $data ) && ! empty( $data['version'] ) ) {
		$remote_version = trim( (string) $data['version'] );
	}

	// fallback: اگر پاسخ JSON نبود، نسخه semantic را از متن استخراج کن
	if ( empty( $remote_version ) && preg_match( '/\b\d+\.\d+\.\d+(?:\.\d+)?\b/', $body, $matches ) ) {
		$remote_version = trim( (string) $matches[0] );
	}

	if ( empty( $remote_version ) ) {
		update_option( 'farazsms_last_check_time', time(), false );
		return;
	}

	$has_update = version_compare( $remote_version, $local_version, '>' );

	update_option( 'farazsms_last_checked_version', $remote_version, false );
	update_option( 'farazsms_update_available', $has_update ? 1 : 0, false );
	update_option( 'farazsms_update_url', $download_url, false );
	update_option( 'farazsms_last_check_time', time(), false );
}

/**
 * وقتی مدیر وارد پیشخوان می‌شود، حداکثر روزی یک‌بار نسخه جدید را چک کن
 */
add_action( 'admin_init', 'farazsms_maybe_check_updates' );
function farazsms_maybe_check_updates() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$last_check = (int) get_option( 'farazsms_last_check_time', 0 );
	if ( $last_check > ( time() - DAY_IN_SECONDS ) ) {
		return;
	}
	farazsms_check_for_updates();
}

/**
 * نمایش نوتیس «آپدیت در دسترس است» فقط در صفحات افزونه فراز اس ام اس
 */
add_action( 'admin_notices', 'farazsms_show_update_notice' );
function farazsms_show_update_notice() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	// فقط در صفحات افزونه (page=farazsms یا page=farazsms-*)
	$current_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : '';
	if ( $current_page !== 'farazsms' && 0 !== strpos( $current_page, 'farazsms-' ) ) {
		return;
	}

	$remote        = get_option( 'farazsms_last_checked_version', '' );
	$update_url    = get_option( 'farazsms_update_url', 'https://farazsms.com/farazsms-wordpress-plugin/' );
	$local_version = defined( 'FARAZSMS_PLUGIN_VERSION' ) ? FARAZSMS_PLUGIN_VERSION : '0.0.0';

	if ( empty( $remote ) ) {
		return;
	}

	// برای اطمینان دوباره مقایسه کن
	if ( version_compare( $remote, $local_version, '<=' ) ) {
		update_option( 'farazsms_update_available', 0, false );
		return;
	}
	?>
	<div class="notice notice-info is-dismissible">
		<p>
			نسخه جدید افزونه <strong>فراز اس ام اس</strong> در دسترس است.
			نسخه فعلی شما <code><?php echo esc_html( $local_version ); ?></code> و
			آخرین نسخه <code><?php echo esc_html( $remote ); ?></code> است.
			<a href="<?php echo esc_url( $update_url ); ?>" target="_blank" rel="noopener noreferrer">دانلود نسخه جدید</a>
		</p>
	</div>
	<?php
}
function farazsms_frontend_ajax_form_scripts() {
	?>
    <script type="text/javascript">
        jQuery(document).ready(function ($) {
            "use strict";
            $('#farazsms_custom_plugin_form').submit(function (event) {
                event.preventDefault();
                var myInputFieldValue = $('#myInputField').val();
                var data = {
                    'action': 'farazsms_custom_plugin_frontend_ajax',
                    'myInputFieldValue': myInputFieldValue,
                };
                var ajaxurl = "<?php echo admin_url( 'admin-ajax.php' );?>";
                $.post(ajaxurl, data, function (response) {
                    console.log(response);
                    if (response.Status == true) {
                        console.log(response.message);
                        $('#farazsms_custom_plugin_form_wrap').html(response);

                    } else {
                        console.log(response.message);
                        $('#farazsms_custom_plugin_form_wrap').html(response);
                    }
                });
            });
        }(jQuery));
    </script>
	<?php
}

// v3.21.27 (P7) امنیتی/پاکسازی — اسکریپتِ فرمِ نمونه (دموِ اسکفولد) و endpointِ nopriv‌اش که
// ورودی را echo می‌کرد و روی هیچ فرمِ واقعی‌ای کار نمی‌کرد، حذف شد (کاهشِ سطحِ حمله + بارِ بی‌مورد در فوتر).

add_action( 'wp_ajax_farazsms_custom_plugin_admin_ajax', 'farazsms_custom_plugin_admin_ajax_handler' );
function farazsms_custom_plugin_admin_ajax_handler() {
	check_ajax_referer( 'farazsms_custom_plugin_admin_ajax' );
	$myInputFieldValue = sanitize_text_field( $_POST['myInputFieldValue'] );
	$response = [
		'Status'  => true,
		'message' => 'Success! Your value was: ' . $myInputFieldValue,
	];

	wp_send_json( $response );
}
add_action( 'add_meta_boxes', 'farazsms_admin_order_custom_metabox' );
function farazsms_admin_order_custom_metabox() {
	$use_cot = class_exists( '\Automattic\WooCommerce\Utilities\OrderUtil' )
		&& \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled();
	$screen = $use_cot ? wc_get_page_screen_id( 'shop-order' ) : 'shop_order';

	add_meta_box(
		'custom',
		'کد رهگیری مرسولات (فراز اس ام اس)',
		'farazsms_custom_metabox_content',
		$screen,
		'side',
		'high'
	);
}

function farazsms_custom_metabox_content( $object ) {
	if ( $object instanceof \WC_Order ) {
		$order    = $object;
		$order_id = $order->get_id();
	} else {
		$order_id = isset( $object->ID ) ? $object->ID : ( isset( $object->id ) ? $object->id : 0 );
		$order    = wc_get_order( $order_id );
	}
	
	if ( ! $order ) {
		echo '<p>سفارش یافت نشد.</p>';
		return;
	}
	
	$saved_tracking_code = $order->get_meta( 'farazsms_tracking_code' );
	$saved_carrier       = $order->get_meta( 'farazsms_carrier' );
	if ( ! in_array( $saved_carrier, array( 'post', 'tipax', 'other' ), true ) ) {
		$saved_carrier = 'post'; // پیش‌فرض
	}
	$carriers = array(
		'post'  => 'پست',
		'tipax' => 'تیپاکس',
		'other' => 'سایر',
	);
	$farazsms_tracking_settings_url = admin_url( 'admin.php?page=farazsms&tt=settings' );
	?>
	<p style="margin:0 0 10px; padding:8px 10px; background:#f0f6fc; border:1px solid #c3d9ed; border-radius:6px; font-size:12px; line-height:1.7; color:#1d2327;">
		این باکس مربوط به <strong>کد رهگیری مرسولات (فراز اس ام اس)</strong> است.<br>
		ساخت پترن و تنظیمات از مسیر:
		فراز اس ام اس &gt; <a href="<?php echo esc_url( $farazsms_tracking_settings_url ); ?>">کد رهگیری</a>
	</p>
	<p><strong>شماره سفارش: </strong><?php echo esc_html( $order ? $order->get_order_number() : $order_id ); ?></p>
	<p>
		<label for="tracking_carrier_<?php echo esc_attr( $order_id ); ?>">نوع پست:</label>
		<select id="tracking_carrier_<?php echo esc_attr( $order_id ); ?>" name="tracking_carrier" style="width: 100%;">
			<?php foreach ( $carriers as $val => $label ) : ?>
				<option value="<?php echo esc_attr( $val ); ?>" <?php selected( $saved_carrier, $val ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?>
		</select>
	</p>
	<p>
		<label for="tracking_code_input_<?php echo esc_attr( $order_id ); ?>">کد رهگیری:</label>
		<input type="text" id="tracking_code_input_<?php echo esc_attr( $order_id ); ?>" name="tracking_code_input" value="" style="width: 100%;" />
	</p>
	<p>
		<button type="button" id="save_tracking_code_btn_<?php echo esc_attr( $order_id ); ?>" class="button button-primary">ارسال</button>
	</p>
	<div id="saved_tracking_code_<?php echo esc_attr( $order_id ); ?>" style="<?php echo empty( $saved_tracking_code ) ? 'display: none; ' : ''; ?>margin-top: 15px; padding: 10px; background-color: #f0f0f0; border-left: 4px solid #2271b1;">
		<p style="margin: 0;"><strong>کد رهگیری ذخیره شده:</strong></p>
		<p style="margin: 5px 0 0 0; font-size: 14px; color: #2271b1;" id="tracking_code_display_<?php echo esc_attr( $order_id ); ?>"><?php echo esc_html( $saved_tracking_code ); ?></p>
		<?php if ( $saved_carrier ) : ?>
			<p style="margin: 5px 0 0 0; font-size: 12px; color: #555;">نوع پست: <?php echo esc_html( $carriers[ $saved_carrier ] ?? 'پست' ); ?></p>
		<?php endif; ?>
	</div>
	<script>
		jQuery(document).ready(function($){
			$('#save_tracking_code_btn_<?php echo esc_js( $order_id ); ?>').on('click', function(){
				var trackingCode = $('#tracking_code_input_<?php echo esc_js( $order_id ); ?>').val();
				var carrier = $('#tracking_carrier_<?php echo esc_js( $order_id ); ?>').val() || 'post';
				var orderId = <?php echo intval( $order_id ); ?>;
				if (trackingCode === '') {
					alert('لطفا کد رهگیری را وارد کنید.');
					return;
				}

				// ذخیره متن اصلی دکمه
				var $btn = $(this);
				var originalText = $btn.text();
				var originalDisabled = $btn.prop('disabled');

				// غیرفعال کردن دکمه و نمایش loading
				$btn.prop('disabled', true).text('در حال ارسال...');

				$.ajax({
					url: ajaxurl,
					method: 'POST',
					data: {
						action: 'save_tracking_code',
						order_id: orderId,
						tracking_code: trackingCode,
						carrier: carrier,
						security: '<?php echo wp_create_nonce( 'save_tracking_code_nonce' ); ?>'
					},
					success: function(response){
						// بازگرداندن دکمه به حالت اولیه
						$btn.prop('disabled', false).text(originalText);
						
						if (response.success) {
							$('#tracking_code_input_<?php echo esc_js( $order_id ); ?>').val('');
							$('#saved_tracking_code_<?php echo esc_js( $order_id ); ?>').show();
							$('#tracking_code_display_<?php echo esc_js( $order_id ); ?>').text(trackingCode);
							
							alert(response.data);
						} else {
							alert('خطا: ' + response.data);
						}
					},
					error: function(){
						// بازگرداندن دکمه به حالت اولیه
						$btn.prop('disabled', false).text(originalText);
						
						alert('خطا در ذخیره کد رهگیری');
					}
				});
			});
		});
	</script>
	<?php
}

add_action( 'wp_ajax_save_tracking_code', 'farazsms_handle_save_tracking_code' );
function farazsms_handle_save_tracking_code() {
	check_ajax_referer( 'save_tracking_code_nonce', 'security' );

	// v3.13.12 SECURITY FIX (CRITICAL): قبل از این فقط nonce چک می‌شد. هر کاربر
	// logged-in (حتی subscriber) می‌توانست با یک fetch جعلی کد رهگیری هر سفارشی
	// را تغییر دهد و باعث ارسال پیامک بی‌مورد شود. حالا cap واقعی WooCommerce
	// را چک می‌کنیم: edit_shop_orders (به‌صورت کلی) + edit_shop_order (به‌صورت
	// per-order که WC از HPOS هم پشتیبانی می‌کند).
	if ( ! current_user_can( 'edit_shop_orders' ) ) {
		wp_send_json_error( 'دسترسی غیرمجاز.', 403 );
	}

	$order_id      = isset( $_POST['order_id'] ) ? intval( $_POST['order_id'] ) : 0;
	$tracking_code = isset( $_POST['tracking_code'] ) ? sanitize_text_field( wp_unslash( $_POST['tracking_code'] ) ) : '';
	$carrier       = isset( $_POST['carrier'] ) ? sanitize_text_field( wp_unslash( $_POST['carrier'] ) ) : 'post';
	if ( ! in_array( $carrier, array( 'post', 'tipax', 'other' ), true ) ) {
		$carrier = 'post';
	}

	if ( empty( $order_id ) || empty( $tracking_code ) ) {
		wp_send_json_error( 'اطلاعات ناقص است.' );
	}

	$order = wc_get_order( $order_id );

	if ( ! $order ) {
		wp_send_json_error( 'سفارش یافت نشد.' );
	}

	// v3.13.12 SECURITY FIX: per-order cap check برای پشتیبانی از Shop Manager و
	// نقش‌های custom که فقط روی subset سفارش‌ها edit حق دارند.
	if ( ! current_user_can( 'edit_shop_order', $order_id ) ) {
		wp_send_json_error( 'دسترسی برای ویرایش این سفارش وجود ندارد.', 403 );
	}

	$order->update_meta_data( 'farazsms_tracking_code', $tracking_code );
	$order->update_meta_data( 'farazsms_carrier', $carrier );
	$order->save();

	// انتخاب پترن بر اساس carrier — برای بررسی وضعیت تأیید پترن قبل از ارسال
	if ( $carrier === 'post' ) {
		$pattern_option_key = 'farazsms_pattern_post';
		$fallback_legacy    = 'farazsms_pattern';
	} else {
		$pattern_option_key = 'farazsms_pattern_' . $carrier;
		$fallback_legacy    = '';
	}

	// همیشه یک response معتبر ارسال کن
	try {
	if ( function_exists( 'farazsms_send_pattern_sms' ) ) {
			// بررسی تأیید پترن قبل از ارسال پیامک (طبق مستندات API)
			$pattern_code = get_option( $pattern_option_key, '' );
			if ( $pattern_code === '' && $fallback_legacy !== '' ) {
				$pattern_code = get_option( $fallback_legacy, '' );
			}
			
			// بررسی تأیید پترن با استفاده از API دریافت جزئیات پترن
			if (!empty($pattern_code)) {
				$pattern_response = farazsms_get_pattern_details($pattern_code);
				$pattern_data = json_decode($pattern_response, true);
				
				// بررسی اینکه response معتبر است یا نه
				if (!$pattern_data || !isset($pattern_data['status']) || $pattern_data['status'] !== 'success') {
					$error_message = isset($pattern_data['message']) ? $pattern_data['message'] : 'پترن یافت نشد یا تأیید نشده است.';
					wp_send_json_error('کد رهگیری ذخیره شد اما پیامک ارسال نشد؛ پترن هنوز تأیید نشده است. (' . $error_message . ')');
					return;
				}
				
				// بررسی وضعیت پترن در data.status
				if (isset($pattern_data['data']['status'])) {
					$pattern_status = $pattern_data['data']['status'];
					
					// اگر پترن در وضعیت pending باشد
					if ($pattern_status === 'pending') {
						wp_send_json_error('کد رهگیری ذخیره شد اما پیامک ارسال نشد؛ پترن در انتظار تأیید است. لطفا صبر کنید تا پترن توسط ادمین تأیید شود.');
						return;
					}
					
					// اگر پترن رد شده باشد
					if ($pattern_status === 'rejected' || $pattern_status === 'reject') {
						$admin_message = isset($pattern_data['data']['admin_message']) ? $pattern_data['data']['admin_message'] : '';
						$error_msg = 'کد رهگیری ذخیره شد اما پیامک ارسال نشد؛ پترن رد شده است.';
						if (!empty($admin_message)) {
							$error_msg .= ' (' . $admin_message . ')';
						}
						wp_send_json_error($error_msg);
						return;
					}
					
					// اگر پترن تأیید شده باشد (approved یا active)
					if ($pattern_status === 'approved' || $pattern_status === 'active') {
						// پترن تأیید شده است، ادامه بده
					} else {
						// وضعیت نامشخص
						wp_send_json_error('کد رهگیری ذخیره شد اما پیامک ارسال نشد؛ وضعیت پترن نامشخص است. (وضعیت: ' . $pattern_status . ')');
						return;
					}
				}
			}
			
			$sms_result = farazsms_send_pattern_sms( $order_id, $tracking_code, $carrier );

			if ( $sms_result === 'success' ) {
				// v3.14.10: ثبت رکورد در tracking log (فقط بعد از ارسال موفق)
				// hook بصورت غیربلوکه — اگر کسی listener نداشته باشد، تاثیری روی پاسخ نمی‌گذارد.
				do_action( 'farazsms_tracking_code_sent', $order_id, $tracking_code, $carrier );
				// v3.22.128: همان متایِ dedupِ یکپارچگیِ تاپین را این‌جا هم بنویس تا اگر تاپین بعداً
				// همین بارکد را شلیک کرد، دوباره برای مشتری پیامک نرود (ارسالِ دستی و خودکار هم‌سو شوند).
				$fz_order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
				if ( $fz_order instanceof WC_Order ) {
					$fz_order->update_meta_data( '_farazsms_pws_barcode_sent', trim( (string) $tracking_code ) );
					$fz_order->save();
				}
				wp_send_json_success( 'کد رهگیری ذخیره شد و پیامک با موفقیت ارسال شد.' );
			} elseif ( $sms_result === 'pattern_not_approved' ) {
				wp_send_json_error( 'کد رهگیری ذخیره شد اما پیامک ارسال نشد؛ پترن هنوز تأیید نشده است.' );
			} elseif ( is_string( $sms_result ) && strpos( $sms_result, 'api_error:' ) === 0 ) {
				$error_msg = substr( $sms_result, strlen( 'api_error:' ) );
				wp_send_json_error( 'کد رهگیری ذخیره شد اما خطا در وب‌سرویس: ' . $error_msg );
			} elseif ( is_string( $sms_result ) && strpos( $sms_result, 'curl_error:' ) === 0 ) {
				$error_msg = substr( $sms_result, strlen( 'curl_error:' ) );
				wp_send_json_error( 'کد رهگیری ذخیره شد اما خطا در ارتباط با وب‌سرویس: ' . $error_msg );
			} else {
				// هر پاسخ نامشخص دیگر — برای عیب‌یابیِ مدیر، پاسخِ خام را هم نشان بده.
				$raw = is_scalar( $sms_result ) ? (string) $sms_result : wp_json_encode( $sms_result );
				wp_send_json_error( 'کد رهگیری ذخیره شد اما وضعیت ارسال پیامک نامشخص است.' . ( $raw !== '' && $raw !== 'null' ? ' (پاسخ: ' . $raw . ')' : ' (احتمالاً پترن یا متنِ این نوع پست تنظیم نشده است).' ) );
			}
		} else {
			// تابع ارسال پیامک در دسترس نیست
			wp_send_json_success( 'کد رهگیری ذخیره شد.' );
		}
	} catch ( \Throwable $e ) {
		// v3.21.39: \Throwable (نه فقط Exception) — یک Error/fatal (مثلِ تماسِ متدِ نبوده
		// روی API یا ووکامرسِ ناقص) قبلاً گرفته نمی‌شد و پاسخ ۵۰۰ می‌داد؛ JS هم آن را
		// «خطا در ذخیره کد رهگیری» نشان می‌داد. حالا پاسخِ معتبر برمی‌گردد و کد ذخیره می‌مانَد.
		error_log( 'خطا در farazsms_handle_save_tracking_code: ' . $e->getMessage() );
		// این اکشن فقط برای مدیر (edit_shop_orders) است؛ نمایشِ علتِ واقعی امن و کمک‌کننده است.
		wp_send_json_error( 'کد رهگیری ذخیره شد اما در ارسالِ پیامک خطا رخ داد: ' . $e->getMessage() );
	}
}


/**
 * v3.21.46: نمایشِ کدِ رهگیریِ مرسوله به مشتری در صفحه‌ی «مشاهده‌ی سفارش» (پنل کاربری).
 * کد در متای سفارش (farazsms_tracking_code) ذخیره می‌شود؛ اینجا با لینکِ پیگیریِ متناسب
 * با نوعِ پست به مشتری نشان داده می‌شود.
 */
add_action( 'woocommerce_order_details_after_order_table', 'farazsms_show_tracking_code_to_customer', 15 );
function farazsms_show_tracking_code_to_customer( $order ) {
	if ( ! is_a( $order, 'WC_Order' ) ) {
		return;
	}
	$code = trim( (string) $order->get_meta( 'farazsms_tracking_code' ) );
	if ( $code === '' ) {
		return;
	}
	$carrier = (string) $order->get_meta( 'farazsms_carrier' );

	$carrier_labels = array(
		'post'  => 'پست',
		'tipax' => 'تیپاکس',
		'other' => 'سایر',
	);
	$carrier_label = isset( $carrier_labels[ $carrier ] ) ? $carrier_labels[ $carrier ] : 'پست';

	// لینکِ پیگیری بر اساسِ نوعِ پست (فقط post.ir لینکِ مستقیمِ کد دارد).
	$track_url = '';
	if ( $carrier === 'post' ) {
		$track_url = 'https://tracking.post.ir/?id=' . rawurlencode( $code );
	} elseif ( $carrier === 'tipax' ) {
		$track_url = 'https://tipax.ir/customer-tracking';
	}
	?>
	<section class="farazsms-customer-tracking" style="margin:18px 0; padding:16px 18px; border:1px solid #e1e1e1; border-radius:10px; background:#f9fafb;">
		<h2 style="font-size:15px; margin:0 0 10px;">📦 <?php esc_html_e( 'رهگیری مرسوله', 'farazsms' ); ?></h2>
		<p style="margin:0 0 6px; font-size:13.5px;">
			<?php esc_html_e( 'نوع ارسال:', 'farazsms' ); ?> <strong><?php echo esc_html( $carrier_label ); ?></strong>
		</p>
		<p style="margin:0; font-size:13.5px;">
			<?php esc_html_e( 'کد رهگیری:', 'farazsms' ); ?>
			<strong style="direction:ltr; display:inline-block; letter-spacing:1px; background:#fff; border:1px solid #ddd; padding:2px 8px; border-radius:5px;"><?php echo esc_html( $code ); ?></strong>
			<?php if ( $track_url !== '' ) : ?>
				<a href="<?php echo esc_url( $track_url ); ?>" target="_blank" rel="noopener" style="margin-right:8px; font-weight:600;">🔎 <?php esc_html_e( 'پیگیری مرسوله', 'farazsms' ); ?></a>
			<?php endif; ?>
		</p>
	</section>
	<?php
}

add_action( 'woocommerce_order_status_changed', 'farazsms_order_status_change', 10, 3 );
function farazsms_order_status_change($order_id, $status_changed_from, $status_changed_to ) {
    // v3.22.50 (باگ گزارش‌شده): اگر نظرسنجی غیرفعال است، اصلاً زمان‌بندی نکن. قبلاً این تابع فلگِ
    // farazsms_send_poll_sms را نادیده می‌گرفت و فقط به وضعیتِ سفارش نگاه می‌کرد — پس برداشتنِ تیکِ
    // «فعال‌سازی» در تنظیمات هیچ اثری نداشت و نظرسنجی همچنان با رسیدن به وضعیتِ تنظیم‌شده می‌رفت
    // («نمی‌شود نظرسنجی را غیرفعال کرد»).
    if ( (string) get_option( 'farazsms_send_poll_sms', '0' ) !== '1' ) {
        return;
    }
    $send_status = get_option('farazsms_send_status', '');
    $send_time_days = intval(get_option('farazsms_send_time', 0));

    if ( $status_changed_to !== $send_status ) {
        return;
    }

    $order = wc_get_order($order_id);
    if ( ! $order ) {
        return;
    }

$date_changed = current_time('Y-m-d H:i:s');
$date_obj = new DateTime($date_changed);
if ($send_time_days > 0) {
    $date_obj->modify("+{$send_time_days} days");
}
$date_obj->setTimezone(new DateTimeZone('UTC'));
$date_to_send = $date_obj->format('Y-m-d\TH:i:s');

    // v3.21.88: ردیفِ «queued» را همین‌جا (به‌صورتِ همگام) ثبت کن تا اگر صفِ async اجرا نشد،
    // ارسالِ نظرسنجی در لاگ نامرئی نماند (تیکت: «نظرسنجی هیچ‌وقت ساخته نشد»).
    if ( function_exists( 'farazsms_survey_log_queued' ) ) {
        farazsms_survey_log_queued( (int) $order_id, $date_to_send );
    }

    // درخواستِ زمان‌بندیِ نظرسنجی از صفِ مشترک رد می‌شود (v3.22.198). هوکِ تغییرِ
    // وضعیت می‌تواند روی مسیرِ تسویه باشد، پس هیچ تماسِ HTTPی روی این درخواست
    // انجام نمی‌شود. اجراکننده‌ی صف (Action Scheduler یا رویدادِ تک‌بارِ کرون) و
    // کچ‌آپِ پیشخوان پوششِ هاستِ بدونِ کرون را می‌دهند — همان چیزی که نسخه‌ی
    // v3.22.38 نداشت و برای همین آن موقع درجا فرستاده می‌شد.
    farazsms_survey_dispatch_scheduled_now( (int) $order_id, $date_to_send );
}

/**
 * v3.22.38: ارسالِ «همان‌لحظه‌ایِ» درخواستِ زمان‌بندیِ نظرسنجی به فراز، بدونِ وابستگی به کرون.
 *
 * v3.22.198: کار به صفِ مشترک سپرده می‌شود و روی هیچ درخواستی که کاربر منتظرش
 * است اجرا نمی‌گردد. گاردِ idempotency در farazsms_send_scheduled_sms از ارسالِ
 * دوباره (اگر کچ‌آپِ پیشخوان هم اجرا شود) جلوگیری می‌کند.
 *
 * @param int    $order_id
 * @param string $date_to_send فرمتِ ISO برای فیلدِ schedule.
 * @return void
 */
function farazsms_survey_dispatch_scheduled_now( $order_id, $date_to_send ) {
    $order_id     = (int) $order_id;
    $date_to_send = (string) $date_to_send;

    // v3.22.198: این تابع سومین پیاده‌سازیِ موازیِ «بعداً اجرا کن» بود — هوکِ
    // shutdownِ خودش روی FPM، و روی mod_php سقوط به مسیری که در نهایت همان‌جا
    // اجرا می‌کرد. حالا از همان صفِ مشترکِ بقیه‌ی افزونه رد می‌شود، پس ذخیره‌ی
    // باقی‌مانده، اجراکننده و کچ‌آپِ پیشخوان را رایگان می‌گیرد.
    // گاردِ idempotency در farazsms_send_scheduled_sms جلوی ارسالِ دوباره را می‌گیرد.
    farazsms_queue_task(
        'survey-scheduled',
        'farazsms_send_scheduled_sms',
        array( $order_id, $date_to_send ),
        array( 'order_id' => $order_id )
    );
}

/**
 * Hook برای intercept کردن ارسال پیامک فقط برای gateway FarazSMSNext
 * اولویت 98 — قبل از send_order_sms افزونه پیامک (99).
 */
add_action( 'woocommerce_order_status_changed', 'farazsms_intercept_sms_for_farazsmsnext', 98, 3 );
add_action( 'woocommerce_checkout_order_processed', 'farazsms_intercept_sms_on_checkout', 98, 1 );

/**
 * @param int $order_id
 * @return void
 */
function farazsms_intercept_sms_on_checkout( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	farazsms_intercept_sms_for_farazsmsnext( $order_id, '', $order->get_status() );
}

/**
 * v3.21.35 CRITICAL — fault-isolation برای جلوگیری از شکستنِ تسویه‌حساب.
 *
 * این تابع روی woocommerce_checkout_order_processed اجرا می‌شود که Store API
 * (Checkout Block) هم آن را صدا می‌زند. هر throw/fatalِ داخلِ ارسالِ پیامک (مثلاً
 * تغییرِ امضای یک متدِ PWSMS پس از آپدیت، یا خطای gateway) کلِ چک‌اوت را با «خطای
 * عمومیِ پردازشِ سفارش» می‌شکست — در حالی‌که order-pay سالم بود چون این هوک را اجرا
 * نمی‌کند. ارسالِ پیامک یک side-effect است و هرگز نباید سفارش را شکست بدهد؛ پس خطا
 * فقط در debug.log ثبت می‌شود و سفارش ادامه می‌یابد.
 *
 * @param int    $order_id
 * @param string $old_status
 * @param string $new_status
 * @return void
 */
function farazsms_intercept_sms_for_farazsmsnext( $order_id, $old_status = '', $new_status = 'created' ) {
	try {
		farazsms_intercept_sms_for_farazsmsnext_inner( $order_id, $old_status, $new_status );
	} catch ( \Throwable $e ) {
		error_log( 'FarazSMS: order-SMS interceptor failed for order ' . (int) $order_id . ' — ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine() );
	}
}

/**
 * v3.22.35: آیا ارسالِ پیامکِ سفارش (مسیرِ PWSMS/checkout) باید async شود؟
 *
 * پیش‌فرض «خاموش» — رفتارِ فعلی (همزمان) دست‌نخورده می‌ماند. برای تست روی staging یکی از این‌ها:
 *   define( 'FARAZSMS_CHECKOUT_ASYNC', true );   // در wp-config.php
 *   update_option( 'farazsms_checkout_async', '1' );
 * وقتی روشن است، فقط خودِ فراخوانیِ HTTPِ ارسال (که کند است) به Action Scheduler منتقل می‌شود؛
 * تصمیمِ «چه کسی پیامک بگیرد» همچنان همزمان و در contextِ درخواست گرفته می‌شود (که $_POST/is_admin
 * دارد) تا منطقِ رضایت عوض نشود.
 *
 * @return bool
 */
function farazsms_checkout_async_enabled() {
	if ( defined( 'FARAZSMS_CHECKOUT_ASYNC' ) ) {
		return (bool) FARAZSMS_CHECKOUT_ASYNC;
	}
	return get_option( 'farazsms_checkout_async', '0' ) === '1';
}

/**
 * v3.22.35: ارسالِ واقعی (بازسازیِ gateway از primitiveها) + یادداشتِ سفارش.
 * هم مسیرِ همزمان و هم workerِ async از همین عبور می‌کنند تا رفتار یکسان باشد.
 *
 * @param int    $order_id
 * @param array  $mobile_list  آرایه‌ی شماره‌ها.
 * @param string $message      متنِ آماده‌ی gateway (patterncode:.. \n key:value).
 * @param array  $data         post_id/type/order_status/section_type.
 * @param string $ok_note      یادداشتِ موفقیت (کامل).
 * @param string $fail_prefix  پیشوندِ یادداشتِ خطا؛ پاسخِ سرویس به انتهایش می‌چسبد.
 * @return void
 */
function farazsms_intercept_perform_send( $order_id, $mobile_list, $message, $data, $ok_note, $fail_prefix ) {
	if ( ! function_exists( 'PWSMS' ) ) {
		return;
	}
	farazsms_ensure_farazsmsnext_gateway_loaded();
	if ( ! class_exists( 'PW\PWSMS\Gateways\FarazSMSNext', false ) ) {
		return;
	}
	$gateway          = new \PW\PWSMS\Gateways\FarazSMSNext();
	$gateway->mobile  = $mobile_list;
	$gateway->message = $message;
	$result           = $gateway->send( $data );

	$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
	if ( ! $order ) {
		return;
	}
	if ( $result === true ) {
		$order->add_order_note( $ok_note );
	} else {
		$order->add_order_note( $fail_prefix . ( is_scalar( $result ) ? (string) $result : wp_json_encode( $result, JSON_UNESCAPED_UNICODE ) ) );
	}
}

/**
 * v3.22.35: مسیرِ ارسال — یا همزمان (پیش‌فرض) یا async (پشتِ flag).
 *
 * ⚠️ بدهیِ باز (ثبت‌شده در اپیکِ ۱۷٫۱): شاخه‌ی پیش‌فرض هنوز روی خودِ درخواستِ
 * تسویه می‌فرستد، و چون پیش‌فرضِ گزینه خاموش است روی سایتِ دست‌نخورده فعال است.
 *
 * ادعای «تنها مسیرِ باقی‌مانده» که اینجا نوشته شده بود غلط بود: شمارشِ فازِ ۲
 * فقط چهار تابعِ ارسالِ نام‌بُرده را دنبال کرده و دو ماژولِ دارای فرستنده‌ی
 * curlِ خودشان را جا انداخته بود. آن نُه نقطه در v3.22.201 منتقل شدند.
 * از v3.22.198 مسیرِ async دیگر «به sync برنمی‌گردد» — نبودِ Action Scheduler
 * به رویدادِ تک‌بارِ کرون می‌رسد، نه به اجرای درجا.
 *
 * @return void
 */
function farazsms_intercept_dispatch_send( $order_id, $mobile_list, $message, $data, $ok_note, $fail_prefix ) {
	if ( farazsms_checkout_async_enabled() ) {
		farazsms_queue_task( 'checkout-intercept', 'farazsms_intercept_perform_send', array( $order_id, $mobile_list, $message, $data, $ok_note, $fail_prefix ) );
		return;
	}
	farazsms_intercept_perform_send( $order_id, $mobile_list, $message, $data, $ok_note, $fail_prefix );
}

/**
 * @param int    $order_id
 * @param string $old_status
 * @param string $new_status
 * @return void
 */
function farazsms_intercept_sms_for_farazsmsnext_inner( $order_id, $old_status = '', $new_status = 'created' ) {
	if ( ! function_exists( 'PWSMS' ) || ! function_exists( 'farazsms_is_farazsmsnext_active_gateway' ) ) {
		return;
	}
	if ( ! farazsms_is_farazsmsnext_active_gateway() ) {
		return;
	}

	farazsms_ensure_farazsmsnext_gateway_loaded();
	if ( ! class_exists( 'PW\PWSMS\Gateways\FarazSMSNext', false ) ) {
		return;
	}

	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}

	farazsms_pwsms_detach_order_sms_hooks();

	$modified_status = PWSMS()->modify_status( $new_status );

	static $handled = array();
	$run_key = (int) $order_id . '|' . $modified_status;
	if ( isset( $handled[ $run_key ] ) ) {
		return;
	}
	$handled[ $run_key ] = true;
	$enable_buyer = PWSMS()->get_option( 'enable_buyer' );
	

		$buyer_allowed_statuses = array_keys(PWSMS()->get_buyer_allowed_statuses());

		// BUGFIX: احترام به تیکِ «ارسال پیامک به مشتری» — دقیقاً مثلِ منطقِ خودِ
		// persian-woocommerce-sms (Orders::send_order_sms خط ۳۱۳):
		//   - در صفحه‌ی ویرایش سفارش (is_shop_order=true): فقط اگر تیکِ sms_order_send خورده باشد.
		//   - در غیرِ آن (چک‌اوت/تغییرِ وضعیتِ خودکار): طبقِ buyer_can_get_sms (انتخابِ مشتری/تنظیمات).
		// قبلاً این intercept فقط allowed_statuses را چک می‌کرد و تیک را نادیده می‌گرفت؛
		// برای همین حتی با برداشتنِ تیک، پیامک ارسال می‌شد.
		$farazsms_order_page = ( isset( $_POST['is_shop_order'] ) && $_POST['is_shop_order'] === 'true' );
		if ( $farazsms_order_page ) {
			// صفحه‌ی ویرایشِ تکِ سفارش: طبقِ تیکِ باکسِ «ارسال پیامک به مشتری».
			$farazsms_buyer_consent = ! empty( $_POST['sms_order_send'] );
		} elseif ( is_admin() ) {
			// تغییرِ وضعیتِ مدیریتی از صفحه‌ی لیستِ سفارش‌ها (HPOS) یا اکشنِ انبوه: در این مسیر
			// هیچ باکسِ POSTی وجود ندارد، پس قبلاً buyer_can_get_sms برای سفارشی که opt-inِ خریدار
			// رویش ثبت نشده بود false می‌داد و هوکِ پیامک اجرا نمی‌شد (باگِ «از تک کار می‌کند، از
			// لیست نه»). حالا مثلِ باکسِ پیش‌فرض‌روشنِ صفحه‌ی تک، اگر وضعیتِ جدید مجاز باشد ارسال کن.
			$farazsms_buyer_consent = in_array( $modified_status, $buyer_allowed_statuses, true );
		} else {
			// چک‌اوت یا تغییرِ خودکار (فرانت/کرون/Store API): احترام به انتخابِ خودِ مشتری.
			$farazsms_buyer_consent = method_exists( PWSMS(), 'buyer_can_get_sms' )
				? (bool) PWSMS()->buyer_can_get_sms( $order_id, $modified_status )
				: in_array( $modified_status, $buyer_allowed_statuses, true );
		}

		if ( $farazsms_buyer_consent ) {
			$mobile = PWSMS()->buyer_mobile( $order_id );
			$message_template = PWSMS()->get_option( 'sms_body_' . $modified_status );
			
			if ( ! empty( $mobile ) && ! empty( $message_template ) ) {
				// دریافت پترن ذخیره شده
				$patterns = get_option( 'farazsms_patterns', [] );
				$pattern_code = null;
				$section_type = 'buyer';
				
				if ( ! empty( $patterns ) && is_array( $patterns ) ) {
					if ( isset( $patterns[ $section_type ] ) && is_array( $patterns[ $section_type ] ) ) {
						if ( isset( $patterns[ $section_type ][ $modified_status ] ) ) {
							$pattern_code = $patterns[ $section_type ][ $modified_status ];
						}
					}
				}
				
				// اگر پترن پیدا شد، از gateway استفاده کن
				if ( ! empty( $pattern_code ) ) {
					$gateway = new \PW\PWSMS\Gateways\FarazSMSNext();
					
				// استخراج attributes از template
				$pattern_data = [];
				preg_match_all( '/\{([a-zA-Z0-9_]+)\}/', $message_template, $shortcode_matches );
				$shortcodes = ! empty( $shortcode_matches[1] ) ? array_unique( $shortcode_matches[1] ) : [];
				
			if ( ! empty( $shortcodes ) ) {
					foreach ( $shortcodes as $shortcode ) {
						$attr_value = PWSMS()->replace_short_codes( '{' . $shortcode . '}', $modified_status, $order );
						if ( empty( $attr_value ) ) {
							$pattern_data[ $shortcode ] = null;
						} else {
							$current_encoding = mb_detect_encoding( $attr_value, 'UTF-8, ISO-8859-1, Windows-1252', true );
							if ( $current_encoding && $current_encoding !== 'UTF-8' ) {
								$attr_value = mb_convert_encoding( $attr_value, 'UTF-8', $current_encoding );
							} elseif ( ! $current_encoding ) {
								$attr_value = mb_convert_encoding( $attr_value, 'UTF-8', 'auto' );
							}
							
							$pattern_data[ $shortcode ] = $attr_value;
						}
					}
				}
					
					if ( ! empty( $pattern_data ) && farazsms_order_sms_should_send_once( $order_id, 2, $modified_status, $mobile ) ) {
						$gateway->mobile = [ $mobile ];
						$message_parts = [ 'patterncode:' . $pattern_code ];
						foreach ( $pattern_data as $key => $value ) {
							if ( ! mb_check_encoding( $value, 'UTF-8' ) ) {
								$value = mb_convert_encoding( $value, 'UTF-8', 'auto' );
							}
							$message_parts[] = $key . ':' . $value;
						}
						$gateway->message = implode( "\n", $message_parts );

						$data = array(
							'post_id'        => $order_id,
							'type'           => 2,
							'order_status'   => $modified_status,
							'section_type'   => $section_type,
						);

						farazsms_intercept_dispatch_send(
							$order_id,
							$gateway->mobile,
							$gateway->message,
							$data,
							sprintf( 'پیامک با موفقیت به مشتری با شماره %s ارسال گردید.', $mobile ),
							sprintf( 'پیامک بخاطر خطا به مشتری با شماره %s ارسال نشد.<br>پاسخ وبسرویس: ', $mobile )
						);
					}
				}
			}
		}
	
	
	$enable_super_admin_sms = PWSMS()->get_option( 'enable_super_admin_sms' );
	
	
		$super_admin_order_status = PWSMS()->get_option( 'super_admin_order_status' );
		$super_admin_statuses = (array) $super_admin_order_status;
		if ( is_object( $super_admin_order_status ) ) {
			$super_admin_statuses = array_keys( (array) $super_admin_order_status );
		} elseif ( is_array( $super_admin_order_status ) && ! empty( $super_admin_order_status ) ) {
			$first_key = key( $super_admin_order_status );
			if ( is_numeric( $first_key ) ) {
				$super_admin_statuses = array_values( $super_admin_order_status );
			} else {
				$super_admin_statuses = array_keys( $super_admin_order_status );
			}
		}
		
		if ( in_array( $modified_status, $super_admin_statuses ) ) {
			$mobile = PWSMS()->get_option( 'super_admin_phone' );
			$message_template = PWSMS()->get_option( 'super_admin_sms_body_' . $modified_status );
			
			if ( ! empty( $mobile ) && ! empty( $message_template ) ) {
				// دریافت پترن ذخیره شده
				$patterns = get_option( 'farazsms_patterns', [] );
				$pattern_code = null;
				$section_type = 'super_admin';
				
				if ( ! empty( $patterns ) && is_array( $patterns ) ) {
					if ( isset( $patterns[ $section_type ] ) && is_array( $patterns[ $section_type ] ) ) {
						if ( isset( $patterns[ $section_type ][ $modified_status ] ) ) {
							$pattern_code = $patterns[ $section_type ][ $modified_status ];
						}
					}
				}
				
				// اگر پترن پیدا شد، از gateway استفاده کن
				if ( ! empty( $pattern_code ) ) {
					$gateway = new \PW\PWSMS\Gateways\FarazSMSNext();
					
					// استخراج attributes از template
					$pattern_data = [];
					preg_match_all( '/\{([a-zA-Z0-9_]+)\}/', $message_template, $shortcode_matches );
					$shortcodes = ! empty( $shortcode_matches[1] ) ? array_unique( $shortcode_matches[1] ) : [];
					
				if ( ! empty( $shortcodes ) ) {
					foreach ( $shortcodes as $shortcode ) {
						$attr_value = PWSMS()->replace_short_codes( '{' . $shortcode . '}', $modified_status, $order );
						if ( empty( $attr_value ) ) {
							$pattern_data[ $shortcode ] = null;
						} else {
							$pattern_data[ $shortcode ] = $attr_value;
						}
					}
				}
					
					$mobile_numbers = farazsms_split_mobile_list( $mobile );
					$mobile_numbers = array_values( array_filter( $mobile_numbers ) );
					$dedupe_phones  = $mobile_numbers;
					sort( $dedupe_phones );
					$dedupe_key     = implode( ',', $dedupe_phones );

					if ( ! empty( $pattern_data ) && ! empty( $mobile_numbers ) && farazsms_order_sms_should_send_once( $order_id, 4, $modified_status, $dedupe_key ) ) {
						$gateway->mobile = $mobile_numbers;
						$mobile_label    = implode( '، ', $mobile_numbers );

						$message_parts = array( 'patterncode:' . $pattern_code );
						foreach ( $pattern_data as $key => $value ) {
							$message_parts[] = $key . ':' . $value;
						}
						$gateway->message = implode( "\n", $message_parts );

						$data = array(
							'post_id'      => $order_id,
							'type'         => 4,
							'order_status' => $modified_status,
							'section_type' => $section_type,
						);

						farazsms_intercept_dispatch_send(
							$order_id,
							$gateway->mobile,
							$gateway->message,
							$data,
							sprintf( 'پیامک با موفقیت به مدیر کل با شماره %s ارسال گردید.', $mobile_label ),
							sprintf( 'پیامک بخاطر خطا به مدیر کل با شماره %s ارسال نشد.<br>پاسخ وبسرویس: ', $mobile_label )
						);
					}
				}
			}
		}

	
	$enable_product_admin_sms = PWSMS()->get_option( 'enable_product_admin_sms' );
	if ( $enable_product_admin_sms ) {
		$order_products = PWSMS()->get_prodcut_lists( $order, 'product_id' );
		$mobiles = PWSMS()->product_admin_mobiles( $order_products['product_id'], $modified_status );
		
		// ⚠️ سفارشِ چندفروشنده: هر فروشنده «اسلاتِ» خودش را دارد. پیش از این، قفلِ
		// ضدِتکرار فقط از (نوع + وضعیت) ساخته می‌شد و فروشنده‌ی اول آن را مصرف
		// می‌کرد؛ بقیه‌ی فروشنده‌ها هیچ‌وقت پیامک نمی‌گرفتند — همان ریشه‌ای که
		// چندشماره‌بودنِ مدیر را هم می‌شکست.
		$vendor_slots = array();
		foreach ( (array) $mobiles as $vendor_mobile => $vendor_ignored ) {
			$vendor_slots[ $vendor_mobile ] = function_exists( 'farazsms_order_sms_recipient_slot' ) ? farazsms_order_sms_recipient_slot( $vendor_mobile ) : '';
		}
		// مهاجرتِ سفارش‌های قدیمی — مستقل از ترتیبِ کلیدهای بازگشتی (که قراردادی ندارد).
		$vendors_migrated = function_exists( 'farazsms_order_sms_group_migrated' )
			&& farazsms_order_sms_group_migrated( $order_id, 5, $modified_status, $vendor_slots );

		// گاردِ گروه پیش از حلقه — مقدارش در طولِ حلقه تغییر نمی‌کند.
		foreach ( $vendors_migrated ? array() : (array) $mobiles as $mobile => $product_ids ) {
			$vendor_slot  = isset( $vendor_slots[ $mobile ] ) ? $vendor_slots[ $mobile ] : '';
			$vendor_items = PWSMS()->product_admin_items( $order_products, $product_ids );
			$message_template = PWSMS()->get_option( 'product_admin_sms_body_' . $modified_status );
			
			if ( ! empty( $mobile ) && ! empty( $message_template ) ) {
				// دریافت پترن ذخیره شده
				$patterns = get_option( 'farazsms_patterns', [] );
				$pattern_code = null;
				$section_type = 'product_admin';
				
				if ( ! empty( $patterns ) && is_array( $patterns ) ) {
					if ( isset( $patterns[ $section_type ] ) && is_array( $patterns[ $section_type ] ) ) {
						if ( isset( $patterns[ $section_type ][ $modified_status ] ) ) {
							$pattern_code = $patterns[ $section_type ][ $modified_status ];
						}
					}
				}
				
				// اگر پترن پیدا شد، از gateway استفاده کن
				if ( ! empty( $pattern_code ) ) {
					$gateway = new \PW\PWSMS\Gateways\FarazSMSNext();
					
					// استخراج attributes از template
					$pattern_data = [];
					preg_match_all( '/\{([a-zA-Z0-9_]+)\}/', $message_template, $shortcode_matches );
					$shortcodes = ! empty( $shortcode_matches[1] ) ? array_unique( $shortcode_matches[1] ) : [];
					
				if ( ! empty( $shortcodes ) ) {
					foreach ( $shortcodes as $shortcode ) {
						$attr_value = PWSMS()->replace_short_codes( '{' . $shortcode . '}', $modified_status, $order, $vendor_items );
						if ( empty( $attr_value ) ) {
							$pattern_data[ $shortcode ] = null;
						} else {
							$pattern_data[ $shortcode ] = $attr_value;
						}
					}
				}
					
					if ( ! empty( $pattern_data ) && farazsms_order_sms_should_send_once( $order_id, 5, $modified_status, $mobile, $vendor_slot ) ) {
						$gateway->mobile = array( $mobile );

						$message_parts = array( 'patterncode:' . $pattern_code );
						foreach ( $pattern_data as $key => $value ) {
							$message_parts[] = $key . ':' . $value;
						}
						$gateway->message = implode( "\n", $message_parts );

						$data = array(
							'post_id'      => $order_id,
							'type'         => 5,
							'order_status' => $modified_status,
							'section_type' => $section_type,
						);

						farazsms_intercept_dispatch_send(
							$order_id,
							$gateway->mobile,
							$gateway->message,
							$data,
							sprintf( 'پیامک با موفقیت به مدیر محصول با شماره %s ارسال گردید.', $mobile ),
							sprintf( 'پیامک بخاطر خطا به مدیر محصول با شماره %s ارسال نشد.<br>پاسخ وبسرویس: ', $mobile )
						);
					}
				}
			}
		}
	}
}