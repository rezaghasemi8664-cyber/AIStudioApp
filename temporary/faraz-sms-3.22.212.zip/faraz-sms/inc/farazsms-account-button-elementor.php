<?php
/**
 * ویجتِ Elementor برای دکمه‌ی هوشمندِ حساب.
 * فقط وقتی Elementor فعال باشد بارگذاری می‌شود (require از داخلِ hookِ register).
 *
 * @package FarazSMS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
	return;
}

if ( ! class_exists( 'FarazSMS_Account_Button_Elementor_Widget' ) ) {

	class FarazSMS_Account_Button_Elementor_Widget extends \Elementor\Widget_Base {

		public function get_name() {
			return 'farazsms_account_button';
		}

		public function get_title() {
			return 'دکمه‌ی حساب فراز';
		}

		public function get_icon() {
			return 'eicon-lock-user';
		}

		public function get_categories() {
			return array( 'general' );
		}

		public function get_keywords() {
			return array( 'account', 'login', 'حساب', 'ورود', 'faraz', 'فراز' );
		}

		protected function register_controls() {
			$this->start_controls_section( 'section_content', array(
				'label' => 'دکمه‌ی حساب',
			) );

			$this->add_control( 'guest_label', array(
				'label'       => 'متنِ حالتِ خروج',
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => 'ورود و ثبت‌نام',
			) );

			$this->add_control( 'preset', array(
				'label'   => 'استایل',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''        => 'پیش‌فرضِ تنظیمات',
					'default' => 'پُر',
					'outline' => 'خط‌دار',
					'pill'    => 'قرصی',
					'minimal' => 'ساده',
				),
			) );

			$this->add_control( 'show_icon', array(
				'label'        => 'آیکون',
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => 'بله',
				'label_off'    => 'خیر',
				'return_value' => '1',
				'default'      => '1',
			) );

			$this->end_controls_section();
		}

		protected function render() {
			$settings = $this->get_settings_for_display();

			// در ویرایشگرِ Elementor حتی اگر فیچر خاموش باشد یک پیش‌نمایش نشان بده.
			// null-safe: در برخی مسیرهای lifecycle، ->editor ممکن است هنوز نباشد.
			$is_editor = false;
			if ( class_exists( '\Elementor\Plugin' )
				&& isset( \Elementor\Plugin::$instance )
				&& isset( \Elementor\Plugin::$instance->editor )
				&& method_exists( \Elementor\Plugin::$instance->editor, 'is_edit_mode' ) ) {
				$is_editor = (bool) \Elementor\Plugin::$instance->editor->is_edit_mode();
			}
			if ( ! farazsms_account_button_is_enabled() && ! $is_editor ) {
				return;
			}
			farazsms_account_button_enqueue_now();

			$args = array();
			if ( ! empty( $settings['guest_label'] ) ) {
				$args['guest_label'] = $settings['guest_label'];
			}
			if ( ! empty( $settings['preset'] ) ) {
				$args['preset'] = $settings['preset'];
			}
			$args['show_icon'] = ( isset( $settings['show_icon'] ) && $settings['show_icon'] === '1' ) ? '1' : '0';

			echo farazsms_account_button_render( $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped — خروجی در render امن‌سازی شده.

			if ( ! farazsms_account_button_is_enabled() && $is_editor ) {
				echo '<p style="margin-top:8px;color:#b26a00;font-size:12px">توجه: فیچرِ «دکمه‌ی حساب» هنوز در تنظیماتِ فراز فعال نشده؛ در سایتِ واقعی نمایش داده نمی‌شود.</p>';
			}
		}
	}
}
