<?php
if ( ! defined( 'WPINC' ) ) {
	die;
}

 

/**
 * تبدیل ارقام فارسی + عربی به لاتین.
 * v3.17.6: ارقام عربی (Eastern Arabic) هم اضافه شد — قبلاً فقط فارسی پشتیبانی می‌شد.
 *
 *   فارسی:  ۰۱۲۳۴۵۶۷۸۹  (U+06F0–U+06F9)
 *   عربی:   ٠١٢٣٤٥٦٧٨٩  (U+0660–U+0669)
 *   لاتین:  0123456789
 */
function farazsms_tr_num( $str ) {
	if ( $str === null ) return '';
	$persian = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );
	$arabic  = array( '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' );
	$latin   = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );
	$str = str_replace( $persian, $latin, (string) $str );
	$str = str_replace( $arabic, $latin, $str );
	return $str;
}

// تابعِ اعتبارسنجیِ نام‌کاربری/رمز حذف شد (v3.22.159): به وب‌سرویسِ نسلِ قبل وصل بود
// و اعتبارِ ورودِ مشتری را به سرورِ آن سرویس می‌فرستاد. هیچ صداکننده‌ای نداشت؛
// اعتبارسنجیِ فعلی با Api-Key و از طریقِ سرویسِ خودِ فراز انجام می‌شود.

/**
 * دریافت Api-Key از تنظیمات افزونه رهگیری
 * فقط از farazsms_apikey می‌خواند تا بخش رهگیری مستقل از افزونه پیامک فارسی باشد
 */
function farazsms_get_apikey() {
	// فقط از تنظیمات خود افزونه رهگیری بخوان
	$v = get_option( 'farazsms_apikey', '' );
	// fallbackِ امن تا مهاجرتِ نام‌گذاری (wto_ → farazsms_) اجرا شود.
	if ( $v === '' ) {
		$v = get_option( 'wto_apikey', '' );
	}
	return $v;
}

/**
 * Unique placeholder names from a tracking SMS template (%name% and {name}).
 *
 * @param string $message Template text.
 * @return string[]
 */
function farazsms_tracking_pattern_var_keys_from_message( $message ) {
	$message = (string) $message;
	$keys    = array();
	if ( preg_match_all( '/%([a-zA-Z0-9_]+)%/', $message, $m1 ) ) {
		foreach ( $m1[1] as $k ) {
			$keys[ $k ] = true;
		}
	}
	if ( preg_match_all( '/\{([a-zA-Z0-9_]+)\}/', $message, $m2 ) ) {
		foreach ( $m2[1] as $k ) {
			$keys[ $k ] = true;
		}
	}
	return array_keys( $keys );
}

/**
 * v3.21.47: تبدیلِ پیامِ خطای API به رشته‌ی خوانا.
 * گاهی Faraz پیامِ خطا را به‌صورتِ آرایه/آبجکت (خطاهای اعتبارسنجیِ فیلدها) برمی‌گرداند؛
 * الحاقِ مستقیمِ آن به رشته «Array» می‌داد و علتِ واقعی پنهان می‌شد (مثلِ api_error:Array).
 *
 * @param mixed $msg
 * @return string
 */
function farazsms_flatten_api_message( $msg ) {
	if ( is_string( $msg ) ) {
		return $msg;
	}
	if ( is_array( $msg ) || is_object( $msg ) ) {
		$parts = array();
		foreach ( (array) $msg as $k => $v ) {
			$vv = ( is_array( $v ) || is_object( $v ) ) ? farazsms_flatten_api_message( $v ) : (string) $v;
			$parts[] = ( is_string( $k ) && ! is_numeric( $k ) ) ? ( $k . ': ' . $vv ) : $vv;
		}
		$out = implode( ' | ', array_filter( $parts, function ( $p ) { return trim( (string) $p ) !== ''; } ) );
		return $out !== '' ? $out : 'خطای نامشخص';
	}
	return (string) $msg;
}

/**
 * Parse %var% and {var} together for pattern create/update (duplicate names across both styles are an error).
 *
 * @param string $message Raw template.
 * @param string $error_message Filled when invalid.
 * @return array{0: string[], 1: string} variables list and API pattern text (braces normalized to %).
 */
function farazsms_parse_pattern_message_placeholders_merged( $message, &$error_message ) {
	$error_message = '';
	$message       = (string) $message;
	$names         = array();
	if ( preg_match_all( '/%([a-zA-Z0-9_]+)%/', $message, $m1 ) ) {
		foreach ( $m1[1] as $n ) {
			$names[] = $n;
		}
	}
	if ( preg_match_all( '/\{([a-zA-Z0-9_]+)\}/', $message, $m2 ) ) {
		foreach ( $m2[1] as $n ) {
			$names[] = $n;
		}
	}
	if ( empty( $names ) ) {
		return array( array(), $message );
	}
	$counts = array_count_values( $names );
	$dups   = array();
	foreach ( $counts as $n => $c ) {
		if ( $c > 1 ) {
			$dups[] = $n;
		}
	}
	if ( ! empty( $dups ) ) {
		$error_message = 'خطا: متغیر(های) زیر بیش از یک بار در متن استفاده شده‌اند: ' . implode( ', ', $dups ) . '. از هر متغیر فقط یک بار می‌توان استفاده کرد.';
		return array( array(), $message );
	}
	$variables    = array_values( array_unique( $names ) );
	$pattern_text = $message;
	foreach ( $variables as $var ) {
		$pattern_text = str_replace( '{' . $var . '}', '%' . $var . '%', $pattern_text );
	}
	return array( $variables, $pattern_text );
}

/**
 * Pattern API var entry type/length for known tracking placeholders.
 *
 * @param string $var Variable name.
 * @param bool   $pwsms_long_name Use length 100 for customer_fullname only (pwsms module); b_first/last_name always 25.
 * @return array{type: string, length: int}
 */
function farazsms_tracking_pattern_var_type_length( $var, $pwsms_long_name = false ) {
	$type   = 'str';
	$length = 25;
	// v3.22.116: اگر نام با پیشوندِ hex-safe آمده (v + نامی که با دو رقمِ hex شروع می‌شود)،
	// برای تشخیصِ نوع/طول به نامِ اصلی برگردان. hexsafe فقط چنین نام‌هایی را پیشوند می‌زند،
	// پس این بازگردانی قطعی و بی‌خطر است (مثلِ vdate→date، vaddress_1→address_1).
	if ( strlen( (string) $var ) > 1 && $var[0] === 'v' && preg_match( '/^[0-9a-fA-F]{2}/', substr( $var, 1 ) ) ) {
		$var = substr( $var, 1 );
	}
	// v3.22.116: متغیرهای متنیِ بلندِ سفارش (آدرس/یادداشت/روشِ ارسال/شرکت/شهر/استان/…) — طولِ
	// اعلام‌شده باید به‌اندازهٔ کافی بزرگ باشد وگرنه فراز مقدارِ بلند را رد می‌کند.
	$farazsms_long_order_vars = array(
		'address', 'address_1', 'address_2', 'customer_note', 'company', 'shipping_method',
		'shipping_address', 'shipping_address_1', 'shipping_address_2', 'shipping_company',
		'transaction_id',
	);
	if ( in_array( $var, $farazsms_long_order_vars, true ) ) {
		return array( 'type' => 'str', 'length' => 100 );
	}
	// متغیرهای متوسطِ سفارش (نام/شهر/استان/کشور/ایمیل/تلفن/تاریخ/کدپستی).
	$farazsms_medium_order_vars = array(
		'email', 'phone', 'mobile', 'city', 'state', 'country', 'postcode', 'date',
		'shipping_first_name', 'shipping_last_name', 'shipping_city', 'shipping_state',
		'shipping_country', 'shipping_postcode',
	);
	if ( in_array( $var, $farazsms_medium_order_vars, true ) ) {
		return array( 'type' => 'str', 'length' => 50 );
	}
	// لینکِ پرداخت: اگر کوتاه‌کننده در دسترس نباشد، URLِ کامل (~۱۳۰) می‌رود؛ طولِ بزرگ‌تر تا بریده/ردنشود.
	if ( $var === 'payment_url' ) {
		return array( 'type' => 'str', 'length' => 200 );
	}
	if ( $var === 'code' || $var === 'otp' ) {
		// v3.21.33: کدِ تأییدِ OTP عددیِ ۶ رقمی است؛ طولِ متغیر باید ۶ اعلام شود
		// (پیش‌فرضِ ۲۵ نادرست بود). درخواستِ کاربر برای پترنِ «احراز هویت OTP».
		$type   = 'int';
		$length = 6;
	} elseif ( $var === 'b_first_name' || $var === 'b_last_name' ) {
		$type   = 'str';
		$length = 25;
	} elseif ( $var === 'customer_fullname' ) {
		$type   = 'str';
		$length = $pwsms_long_name ? 100 : 25;
	} elseif ( $var === 'order_id' ) {
		$type   = 'int';
		$length = 20;
	} elseif ( $var === 'tracking_code' ) {
		$type   = 'int';
		$length = 25;
	} elseif ( $var === 'all_items' || strpos( $var, 'all_items_' ) === 0 ) {
		$type   = 'str';
		$length = 120;
	} elseif ( $var === 'payment_method' ) {
		// عنوانِ روشِ پرداخت (مثلِ «پرداخت اینترنتی از طریق درگاه بانک ملت») می‌تواند بلند باشد.
		$type   = 'str';
		$length = 50;
	} elseif ( $var === 'full_name' || $var === 'customer_name' ) {
		// نامِ کامل (نام + نام‌خانوادگی) می‌تواند بلندتر از ۲۵ باشد.
		$type   = 'str';
		$length = 40;
	} elseif ( farazsms_pattern_var_is_url( $var ) ) {
		// v3.22.71: متغیرِ لینک/URL (مثلِ resume_url، product_link، comment_link، invoice_url،
		// review_url، p_link). لینکِ سایتِ اصلی می‌تواند بلند باشد؛ طولِ ۸۰ اعلام می‌شود تا پنلِ فراز
		// لینک را کوتاه نکند/رد نکند. (با انتخابِ «لینکِ سایتِ اصلی» در تنظیماتِ ماژول همراه است.)
		$type   = 'str';
		$length = 80;
	}
	return array( 'type' => $type, 'length' => $length );
}

/**
 * آیا نامِ متغیرِ پترن یک لینک/URL است؟ (به‌پایانِ _url / _link ختم می‌شود یا دقیقاً url/link است.)
 *
 * @param string $var
 * @return bool
 */
function farazsms_pattern_var_is_url( $var ) {
	$var = strtolower( (string) $var );
	return $var === 'url' || $var === 'link'
		|| substr( $var, -4 ) === '_url' || substr( $var, -5 ) === '_link';
}

/**
 * v3.17.3: ساخت description برندشده برای ارسال به API پترن فراز اس‌ام‌اس.
 *
 * این description را admin پنل فراز هنگام بررسی پترن می‌بیند، و فوراً می‌فهمد
 * این پترن از کدام ماژول افزونه فراز اس ام اس آمده — کمک به تأیید سریع‌تر.
 *
 * فرمت ثابت: «افزونه فراز اس ام اس / [بخش]»
 *
 * @param string $section_type کلید بخش (مثلاً 'cashback', 'comment', 'tracking', 'birthday', 'survey', 'otp', 'buyer', ...)
 * @param string $status_key   کلید فرعی (مثلاً 'admin', 'user_approve', ...)
 * @param string $carrier      برای tracking: 'post' | 'tipax' | 'other'
 * @return string description نهایی
 */
function farazsms_pattern_brand_description( $section_type, $status_key = '', $carrier = '' ) {
	$brand = 'افزونه فراز اس ام اس';

	$labels = array(
		'tracking'      => 'کد رهگیری سفارش',
		'cashback'      => 'کش بک',
		'birthday'      => 'تبریک تولد',
		'comment'       => 'دیدگاه سایت',
		'survey'        => 'نظرسنجی پس از خرید',
		'otp'           => 'احراز هویت OTP',
		'notify'        => 'موجود شد خبرم کن',
		'abandoned'     => 'سبد خرید رهاشده',
		'newsletter'    => 'خبرنامه پیامکی',
		'login'         => 'ورود و ثبت‌نام',
		'security'      => 'هشدار ورود ادمین',
		'lead_magnet'   => 'لید مگنت',
		'buyer'         => 'پیامک حرفه‌ای ووکامرس — خریدار',
		'super_admin'   => 'پیامک حرفه‌ای ووکامرس — مدیر',
		'product_admin' => 'پیامک حرفه‌ای ووکامرس — مدیر محصول',
		'gravity'       => 'فرم‌های Gravity',
		'elementor'     => 'فرم‌های Elementor',
	);

	$carrier_labels = array(
		'post'  => 'پست',
		'tipax' => 'تیپاکس',
		'other' => 'سایر',
	);

	$status_labels = array(
		'admin'         => 'اطلاع به مدیر',
		'user_approve'  => 'تایید/رد دیدگاه',
		'user_reply'    => 'پاسخ به دیدگاه',
	);

	$section_label = isset( $labels[ $section_type ] ) ? $labels[ $section_type ] : ( $section_type !== '' ? $section_type : 'متفرقه' );

	// tracking با carrier جزئیات بیشتر می‌گیرد
	if ( $section_type === 'tracking' && $carrier !== '' && isset( $carrier_labels[ $carrier ] ) ) {
		$section_label .= ' / ' . $carrier_labels[ $carrier ];
	}
	// comment با status (admin/user_approve/user_reply) جزئیات بیشتر
	if ( strpos( $section_type, 'comment' ) === 0 && $status_key !== '' ) {
		$status_label   = isset( $status_labels[ $status_key ] ) ? $status_labels[ $status_key ] : $status_key;
		$section_label .= ' / ' . $status_label;
	}

	return $brand . ' / ' . $section_label;
}

/**
 * آدرسِ سایت (امضای برند) را به انتهای متنِ پترن اضافه می‌کند — الزامیِ تأییدِ پنلِ فراز.
 * فقط اگر هاستِ سایت هنوز در متن نباشد (جلوگیری از تکرار).
 *
 * @param string $text
 * @return string
 */
function farazsms_pattern_append_site_url( $text ) {
	$text = (string) $text;
	// v3.21.94: دامنه به‌صورتِ «خام» (بدونِ https:// و بدونِ www) در انتهای پترن هاردکد می‌شود.
	// پنلِ فراز پترنی که آدرسِ سایت در آن به‌صورتِ ثابت نباشد را رد می‌کند؛ پس نباید متغیرِ %site%
	// داشته باشیم و آدرس باید متنِ ثابت باشد.
	$host = (string) wp_parse_url( get_site_url(), PHP_URL_HOST );
	$host = preg_replace( '/^www\./i', '', (string) $host ); // حذفِ www
	if ( $host === '' ) {
		return $text;
	}
	// v3.21.95: تطبیقِ «کلمه‌ایِ مرزدار» به‌جای زیررشته. قبلاً stripos ساده بود؛ اگر متن دامنه‌ای
	// شبیه (مثلاً myshop.com وقتی هاست shop.com است) داشت، اشتباهاً «موجود» تلقی می‌شد و دامنه
	// اضافه نمی‌شد → پنلِ فراز کلِ پترن را رد می‌کرد. مرزها کاراکترهای غیرِدامنه‌اند ([^0-9a-z.-]).
	$already = preg_match( '/(^|[^0-9a-z.\-])' . preg_quote( $host, '/' ) . '([^0-9a-z.\-]|$)/i', $text );
	if ( ! $already ) {
		$text = rtrim( $text ) . "\n" . $host;
	}
	return $text;
}

/**
 * تبدیل شماره تلفن از فرمت بین‌المللی به فرمت داخلی ایران
 * تبدیل +989... به 09...
 *
 * @param string $phone شماره تلفن
 * @return string شماره تلفن تبدیل شده
 */
function farazsms_normalize_phone($phone) {
	if (empty($phone)) {
		return $phone;
	}

	$phone = farazsms_tr_num( (string) $phone );
	$phone = trim( $phone );
	// نگه داشتن فقط رقم و علامت + برای نرمال‌سازی قابل‌اعتماد.
	$phone = preg_replace( '/[^\d\+]+/u', '', $phone );
	$phone = preg_replace( '/^\++/', '+', $phone );

	// قبلاً فرمت داخلی درست است.
	if ( preg_match( '/^09\d{9}$/', $phone ) ) {
		return $phone;
	}

	// +98912... => 0912... — اگر بعد از +98 دوباره 0 آمده (+980912...) صفر اضافه نزن.
	if ( strpos( $phone, '+98' ) === 0 ) {
		$rest  = substr( $phone, 3 );
		$phone = ( $rest !== '' && $rest[0] === '0' ) ? $rest : ( '0' . $rest );
	}

	if ( preg_match( '/^09\d{9}$/', $phone ) ) {
		return $phone;
	}

	// 0098912... => 0912... — همان منطق برای جلوگیری از 0090912...
	if ( strpos( $phone, '0098' ) === 0 ) {
		$rest  = substr( $phone, 4 );
		$phone = ( $rest !== '' && $rest[0] === '0' ) ? $rest : ( '0' . $rest );
	}

	if ( preg_match( '/^09\d{9}$/', $phone ) ) {
		return $phone;
	}

	// 009395302366 => 09395302366 (پیشوند 00 اضافی بدون 98)
	if ( preg_match( '/^0{2,}(9\d{9})$/', $phone, $matches ) ) {
		$phone = '0' . $matches[1];
	}

	if ( preg_match( '/^09\d{9}$/', $phone ) ) {
		return $phone;
	}

	// 98912... => 0912...
	if ( preg_match( '/^98(9\d{9})$/', $phone, $matches ) ) {
		$phone = '0' . $matches[1];
	}

	// 912... => 0912...
	if ( preg_match( '/^9\d{9}$/', $phone ) ) {
		$phone = '0' . $phone;
	}

	return $phone;
}

/**
 * آیا این ورودی یک موبایلِ ایرانِ معتبر است؟
 *
 * تابعِ نرمال‌سازی عمداً «هرچه بود» را برمی‌گرداند تا مسیرهای قدیمی نشکنند؛ پس
 * خروجیِ خالی‌نبودنِ آن به‌تنهایی معنیِ «معتبر» نمی‌دهد (مثلاً ۱۲۳ دست‌نخورده
 * برمی‌گردد). هرجا قرار است اعتبار مصرف شود، اعتبارسنجی باید از این تابع بیاید.
 *
 * @param mixed $phone شماره‌ی خام یا نرمال‌شده (هر ورودیِ کاربر)
 * @return bool
 */
function farazsms_is_mobile( $phone ) {
	if ( ! is_scalar( $phone ) ) {
		return false;
	}
	$phone = (string) farazsms_normalize_phone( (string) $phone );
	return (bool) preg_match( '/^09\d{9}$/', $phone );
}

/**
 * جدا کردن چند شماره موبایل (کامای انگلیسی/فارسی/عربی، ; و خط جدید).
 *
 * @param string|array $raw
 * @return string[] شماره‌های نرمال 09xxxxxxxxx
 */
function farazsms_split_mobile_list( $raw ) {
	$parts = array();
	if ( is_array( $raw ) ) {
		foreach ( $raw as $item ) {
			$parts = array_merge( $parts, farazsms_split_mobile_list( $item ) );
		}
		return array_values( array_unique( array_filter( $parts ) ) );
	}

	$raw = farazsms_tr_num( trim( (string) $raw ) );
	if ( $raw === '' ) {
		return array();
	}

	$chunks = preg_split( '/[\s,،٬;]+/u', $raw, -1, PREG_SPLIT_NO_EMPTY );
	if ( ! is_array( $chunks ) ) {
		$chunks = array( $raw );
	}

	$out = array();
	foreach ( $chunks as $chunk ) {
		$chunk = trim( $chunk );
		if ( $chunk === '' ) {
			continue;
		}
		$normalized = farazsms_normalize_phone( $chunk );
		if ( $normalized === '' ) {
			continue;
		}
		if ( preg_match( '/^09\d{9}$/', $normalized ) ) {
			$out[] = $normalized;
		}
	}

	return array_values( array_unique( $out ) );
}

/**
 * تشخیص خطای بلاک شدن WordPress HTTP API.
 *
 * @param mixed $error
 * @return bool
 */
function farazsms_is_http_blocked_error( $error ) {
	if ( ! is_wp_error( $error ) ) {
		return false;
	}
	$code = $error->get_error_code();
	if ( $code === 'http_request_not_executed' || $code === 'http_request_failed' ) {
		return true;
	}
	$message = strtolower( (string) $error->get_error_message() );
	return (
		strpos( $message, 'blocked' ) !== false ||
		strpos( $message, 'http requests are blocked' ) !== false ||
		strpos( $message, 'بلاک' ) !== false
	);
}

/**
 * اجرای cURL به عنوان fallback برای زمانی که wp_remote بلاک می‌شود.
 *
 * @param string $method
 * @param string $url
 * @param array  $args
 * @return array|WP_Error
 */
function farazsms_curl_fallback_request( $method, $url, $args = array() ) {
	if ( ! function_exists( 'curl_init' ) ) {
		return new WP_Error( 'curl_unavailable', 'cURL fallback is unavailable.' );
	}
	$method = strtoupper( (string) $method );
	$headers = isset( $args['headers'] ) && is_array( $args['headers'] ) ? $args['headers'] : array();
	$header_lines = array();
	foreach ( $headers as $key => $value ) {
		$header_lines[] = $key . ': ' . $value;
	}
	$timeout = isset( $args['timeout'] ) ? max( 1, (int) $args['timeout'] ) : 30;
	$body = isset( $args['body'] ) ? (string) $args['body'] : '';

	$curl = curl_init();
	curl_setopt_array( $curl, array(
		CURLOPT_URL            => $url,
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING       => '',
		CURLOPT_MAXREDIRS      => 5,
		CURLOPT_CONNECTTIMEOUT => 5,
		CURLOPT_TIMEOUT        => $timeout,
		CURLOPT_FOLLOWLOCATION => true,
		CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST  => $method,
		// Explicit TLS verification — relying on libcurl defaults is unsafe in shared hosting
		// environments where some images ship with verification disabled.
		CURLOPT_SSL_VERIFYPEER => true,
		CURLOPT_SSL_VERIFYHOST => 2,
		CURLOPT_HTTPHEADER     => $header_lines,
	) );
	if ( $method !== 'GET' && $body !== '' ) {
		curl_setopt( $curl, CURLOPT_POSTFIELDS, $body );
	}
	$response_body = curl_exec( $curl );
	if ( curl_errno( $curl ) ) {
		$error = curl_error( $curl );
		curl_close( $curl );
		return new WP_Error( 'curl_fallback_error', $error );
	}
	$status = (int) curl_getinfo( $curl, CURLINFO_HTTP_CODE );
	curl_close( $curl );

	return array(
		'response' => array(
			'code'    => $status,
			'message' => '',
		),
		'body'     => (string) $response_body,
	);
}

/**
 * POST request with fallback to cURL on blocked wp_remote.
 *
 * @param string $url
 * @param array  $args
 * @return array|WP_Error
 */
function farazsms_remote_post_with_fallback( $url, $args = array() ) {
	// v3.21.15 BUG FIX: متد را از $args بخوان و عیناً منتقل کن. پیش از این، متدِ cURL
	// fallback به‌صورتِ 'POST' هاردکد بود؛ در نتیجه درخواست‌های PUT/DELETE (مثلِ
	// آپدیتِ پترن: PUT /ws/v1/patterns/{code}) روی هاست‌هایی که wp_remote را مسدود
	// می‌کنند به POST تبدیل می‌شدند و با خطای «The POST method is not supported for
	// route patterns/{code}» (۴۰۵) رد می‌شدند — که چون ۴۰۴ نبود، fallbackِ «ساختِ
	// پترنِ نو در صورتِ حذف‌شدن» هم فعال نمی‌شد. حالا متد در هر دو مسیر حفظ می‌شود.
	$method = isset( $args['method'] ) ? strtoupper( (string) $args['method'] ) : 'POST';

	$response = ( $method === 'POST' )
		? wp_remote_post( $url, $args )
		: wp_remote_request( $url, $args );

	if ( ! farazsms_is_http_blocked_error( $response ) ) {
		return $response;
	}
	return farazsms_curl_fallback_request( $method, $url, $args );
}

/**
 * GET request with fallback to cURL on blocked wp_remote.
 *
 * @param string $url
 * @param array  $args
 * @return array|WP_Error
 */
function farazsms_remote_get_with_fallback( $url, $args = array() ) {
	$response = wp_remote_get( $url, $args );
	if ( ! farazsms_is_http_blocked_error( $response ) ) {
		return $response;
	}
	return farazsms_curl_fallback_request( 'GET', $url, $args );
}

/**
 * دریافت Api-Key از تنظیمات افزونه پیامک فارسی
 * برای استفاده در بخش‌های مربوط به پیامک فارسی (buyer, super_admin, product_admin)
 */
function farazsms_get_pwsms_apikey() {
	$apikey = '';
	if (function_exists('PWSMS')) {
		$apikey = PWSMS()->get_option('sms_gateway_apikey');
		if (empty($apikey)) {
			$apikey = PWSMS()->get_option('sms_gateway_username');
		}
	}
	return $apikey;
}

function farazsms_get_credit() {
	// دریافت Api-Key از تنظیمات
	$api_key = farazsms_get_apikey();

	if (empty($api_key)) {
		return false;
	}

	// Cache for 5 minutes — admin bar & dashboard widgets call this on every page
	// render, which previously meant one external HTTP per page on 10,000 stores.
	$cache_key = 'farazsms_credit_' . md5( $api_key );
	$cached    = get_transient( $cache_key );
	if ( $cached !== false ) {
		return $cached;
	}

	$response = farazsms_remote_get_with_fallback( farazsms_sms_api_url( 'account/balance' ), array(
		'headers' => array(
			'Accept'  => 'application/json',
			'Api-Key' => $api_key,
		),
		'timeout' => 10,
	) );

	if ( ! is_array( $response ) || is_wp_error( $response ) ) {
		// اتصال برقرار نشد (مسدودسازی توسط افزونه/سرور یا قطعی) — این «کلیدِ نامعتبر» نیست.
		// برای نگهبانِ اتصال ثبت کن تا اعلانِ صحیح (نامِ افزونه‌ی مسدودکننده) نمایش داده شود.
		farazsms_connectivity_note_failure( is_wp_error( $response ) ? $response->get_error_message() : 'no response from balance endpoint' );
		return false;
	}
	// پاسخِ HTTP دریافت شد → اتصال سالم است (حتی اگر کلید نامعتبر باشد).
	farazsms_connectivity_note_success();

	$body = wp_remote_retrieve_body( $response );
	$data = json_decode( $body, true );

	// بررسی صحت و وجود داده‌های مورد انتظار
	if ( ! isset( $data['status'] ) || $data['status'] !== 'success' ) {
		return false;
	}

	if ( ! isset( $data['data']['balance_amount'] ) ) {
		return false;
	}

	// تبدیل به عدد صحیح و فرمت مناسب برای نمایش
	$credit    = intval( $data['data']['balance_amount'] );
	$formatted = number_format( $credit );
	// v3.13.12: TTL از ۵ دقیقه به ۱۵ دقیقه افزایش یافت — برای ۱۰۰k سایت، این یعنی
	// ۳ برابر کاهش در فراخوانی API برای credit (که روی هر admin page load انجام
	// می‌شد). 15 دقیقه هنوز fresh است و دکمه «تازه‌سازی» در پنل، cache را
	// صریح حذف می‌کند برای refresh دستی.
	set_transient( $cache_key, $formatted, 15 * MINUTE_IN_SECONDS );
	return $formatted;
}

/**
 * دریافت پروفایل حساب از API (نام و شماره موبایل)
 * از API Profile استفاده می‌کند: GET /ws/v1/account/profile
 *
 * @return array|false آرایه با کلیدهای display_name و mobile، یا false در صورت خطا
 */
function farazsms_get_profile() {
	$api_key = farazsms_get_apikey();
	if ( empty( $api_key ) ) {
		return false;
	}
	$cache_key = 'farazsms_profile_' . md5( $api_key );
	$cached = get_transient( $cache_key );
	if ( $cached !== false && is_array( $cached ) ) {
		return $cached;
	}
	$response = farazsms_remote_get_with_fallback( farazsms_sms_api_url( 'account/profile' ), array(
		'headers' => array(
			'Accept'   => 'application/json',
			'Api-Key'  => $api_key,
		),
		'timeout'  => 15,
	) );
	if ( ! is_array( $response ) || is_wp_error( $response ) ) {
		farazsms_connectivity_note_failure( is_wp_error( $response ) ? $response->get_error_message() : 'no response from profile endpoint' );
		return false;
	}
	farazsms_connectivity_note_success();
	$body = wp_remote_retrieve_body( $response );
	$data = json_decode( $body, true );
	if ( empty( $data['status'] ) || $data['status'] !== 'success' || empty( $data['data'] ) ) {
		return false;
	}
	$d = $data['data'];
	$profile = array(
		'display_name' => isset( $d['displayName'] ) ? $d['displayName'] : '',
		'mobile'       => isset( $d['mobile'] ) ? $d['mobile'] : '',
	);
	if ( $profile['display_name'] === '' && $profile['mobile'] === '' ) {
		return false;
	}
	set_transient( $cache_key, $profile, 10 * MINUTE_IN_SECONDS );
	return $profile;
}

/**
 * چاپ بلوک نام و شماره پروفایل برای استفاده در صفحات افزونه (کنار اعتبار)
 * اگر پروفایل موجود نباشد چیزی چاپ نمی‌کند.
 */
function farazsms_render_profile_block() {
	$profile = farazsms_get_profile();
	if ( ! $profile || ( empty( $profile['display_name'] ) && empty( $profile['mobile'] ) ) ) {
		return;
	}
	?>
	<div class="farazsms_account_profile">
		<?php if ( ! empty( $profile['display_name'] ) ) : ?>
			<div class="farazsms_profile_row farazsms_profile_name">
				<span class="dashicons dashicons-admin-users" aria-hidden="true"></span>
				<span class="farazsms_profile_text"><?php echo esc_html( $profile['display_name'] ); ?></span>
			</div>
		<?php endif; ?>
		<?php if ( ! empty( $profile['mobile'] ) ) : ?>
			<div class="farazsms_profile_row farazsms_profile_mobile">
				<span class="dashicons dashicons-phone" aria-hidden="true"></span>
				<span class="farazsms_profile_text"><?php echo esc_html( $profile['mobile'] ); ?></span>
			</div>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * نام option کد پترن برای بخش دیدگاه سایت.
 *
 * @param string $status_key admin|user_approve|user_reply
 * @return string
 */
function farazsms_comment_pattern_option_name( $status_key ) {
	$map = array(
		'admin'         => 'farazsms_comment_admin_pattern',
		'user_approve'  => 'farazsms_comment_user_approve_pattern',
		'user_reply'    => 'farazsms_comment_user_reply_pattern',
	);
	$status_key = sanitize_key( (string) $status_key );
	return isset( $map[ $status_key ] ) ? $map[ $status_key ] : '';
}

/**
 * کد پترن ذخیره‌شده برای دیدگاه (option اختصاصی یا farazsms_patterns).
 *
 * @param string $status_key
 * @return string
 */
function farazsms_get_comment_pattern_code( $status_key ) {
	$option = farazsms_comment_pattern_option_name( $status_key );
	if ( $option !== '' ) {
		$code = trim( (string) get_option( $option, '' ) );
		if ( $code !== '' ) {
			return $code;
		}
	}
	$patterns = get_option( 'farazsms_patterns', array() );
	if ( is_array( $patterns ) && isset( $patterns['comment'][ $status_key ] ) ) {
		return trim( (string) $patterns['comment'][ $status_key ] );
	}
	return '';
}

/**
 * ساخت پترن در سامانه پیامکی (تابع اصلی)
 * این تابع برای استفاده در بخش‌های دیگر افزونه رهگیری استفاده می‌شود
 *
 * @param string $message     متن پیام
 * @param int    $category    دسته پترن: 1=otp, 2=club, 3=order, 255=others (پیش‌فرض 255)
 * @param string $description توضیح برندشده پترن. v3.17.3: الزامی — همیشه برای admin فراز
 *                            مشخص می‌کند که این پترن از کدام بخش افزونه فراز اس ام اس آمده.
 *                            مثال: "افزونه فراز اس ام اس / کش بک"
 * @return string JSON response
 */
/**
 * نامِ متغیرِ «hex-امن» برای پترنِ فراز.
 *
 * سرورِ فراز متنِ پترن را percent-decode می‌کند. پس اگر نامِ متغیر با «دو رقمِ hex» شروع شود
 * — مثلِ %balance% («ba» = 0xBA)، %date% / %days_left% («da» = 0xDA)، %address% («ad» = 0xAD) —
 * آن دو کاراکتر به‌عنوانِ یک بایتِ percent-encoded خوانده و از نام حذف می‌شوند و پترن خراب
 * می‌شود (در پنل، متنِ فارسیِ کنارش داخلِ کادرِ متغیر می‌افتد). با یک پیشوندِ غیرِhex («v») امن
 * می‌شود. نام‌های امن (customer_name، order_id، var1، code، …) بدونِ تغییر برمی‌گردند.
 *
 * این تبدیل «قطعی» است و باید هم موقعِ ساختِ پترن و هم موقعِ ارسال یک‌سان اعمال شود تا کلیدها بخوانند.
 *
 * @param string $name
 * @return string
 */
function farazsms_pattern_hexsafe_name( $name ) {
	$name = (string) $name;
	if ( preg_match( '/^[0-9a-fA-F]{2}/', $name ) ) {
		return 'v' . $name;
	}
	return $name;
}

/**
 * نام‌های hex-ناامن را در متنِ پترن و لیستِ متغیرها امن می‌کند (اعمال یک‌جا موقعِ ساخت/آپدیت).
 *
 * @param string   $pattern_text  متنِ پترن (با %var%).
 * @param string[] $variables     لیستِ نامِ متغیرها (با ارجاع اصلاح می‌شود).
 * @return string متنِ پترنِ امن‌شده.
 */
function farazsms_pattern_hexsafe_apply( $pattern_text, array &$variables ) {
	$map = array();
	foreach ( $variables as $i => $var ) {
		$safe = farazsms_pattern_hexsafe_name( $var );
		if ( $safe !== $var ) {
			$map[ '%' . $var . '%' ] = '%' . $safe . '%';
			$variables[ $i ]         = $safe;
		}
	}
	if ( ! empty( $map ) ) {
		$pattern_text = strtr( $pattern_text, $map );
	}
	return $pattern_text;
}

function farazsms_create_pattern( $message, $category = 255, $description = '', $extra_append = '' ) {
    // دریافت Api-Key از تنظیمات
    $apikey = farazsms_get_apikey();

    if (empty($apikey)) {
        return json_encode([
            'status' => 'error',
            'message' => 'کلید دسترسی (Api-Key) را ابتدا در تنظیمات پیامک وارد کنید.'
        ]);
    }

    // اطمینان از اینکه متن به صورت string است
    $message = (string) $message;

	$parse_err    = '';
	$parsed       = farazsms_parse_pattern_message_placeholders_merged( $message, $parse_err );
	$variables    = $parsed[0];
	$pattern_text = $parsed[1];
	if ( $parse_err !== '' ) {
		return json_encode(
			array(
				'status'  => 'error',
				'message' => $parse_err,
			)
		);
	}

	// v3.22.115: نام‌های hex-ناامن (balance، date، days_left، address، …) را امن کن تا
	// percent-decodeِ سرورِ فراز پترن را خراب نکند. (نام‌های امن دست‌نخورده می‌مانند.)
	$pattern_text = farazsms_pattern_hexsafe_apply( $pattern_text, $variables );

    // ساخت vars بر اساس متغیرهای موجود (طبق مستندات: vars با فیلد var)

    $vars = [];

    foreach ( $variables as $var ) {
		$tl   = farazsms_tracking_pattern_var_type_length( $var );
		$vars[] = array(
			'var'    => $var,
			'type'   => $tl['type'],
			'length' => $tl['length'],
		);
    }

    // v3.22.52: خطِ اضافیِ اختیاری (مثلِ خطِ WebOTPِ OTP) بعد از parse چسبانده می‌شود تا اگر
    // شاملِ %code%ِ تکراری باشد، پارسرِ ضدِ‌تکرار ردش نکند (vars از متنِ اصلی و بدونِ تکرار استخراج
    // شده). فراز متنِ دو-%code%ای را می‌پذیرد (عیناً مثلِ پترنِ لاگین).
    if ( $extra_append !== '' ) {
        $pattern_text = rtrim( $pattern_text ) . $extra_append;
    }

    $pattern_text = farazsms_pattern_append_site_url( $pattern_text );
    $body = array(
        'text' => $pattern_text,      // متن پیام با جای‌گذاری‌ها
        'share' => 0,            // required: boolean (1/0) - 0 برای اختصاصی
        'website' => get_site_url(), // آدرس سایت
    );
    $valid_categories = array( 1, 2, 3, 255 );
    if ( in_array( (int) $category, $valid_categories, true ) ) {
        $body['category'] = (int) $category;
    }

    // اضافه کردن vars فقط اگر متغیری وجود داشته باشد
    if (!empty($vars)) {
        $body['vars'] = $vars;
    }

    // v3.17.3: همیشه description برندشده ارسال می‌کنیم — تا admin فراز بداند
    // این پترن از کدام بخش افزونه فراز اس ام اس آمده.
    $body['description'] = $description !== ''
        ? sanitize_text_field( $description )
        : 'افزونه فراز اس ام اس';

    // v3.20.89: transportِ واحد (با fallbackِ cURL برای هاست‌های مسدودکننده).
    $r = farazsms_sms_pattern_request( 'POST', 'patterns', $body, $apikey );
    return $r['body'];
}

/**
 * آپدیت پترن موجود در سامانه پیامکی (PUT)
 *
 * @param string $pattern_code کد پترن موجود
 * @param string $message متن جدید پیام
 * @param int|null   $category    دسته پترن: 1=otp, 2=club, 3=order, 255=others (اختیاری)
 * @param string     $description توضیح پترن (اختیاری، PUT /ws/v1/patterns/{code})
 * @return string JSON response
 */
function farazsms_update_pattern( $pattern_code, $message, $category = null, $description = '', $extra_append = '' ) {
	$apikey = farazsms_get_apikey();
	if ( empty( $apikey ) ) {
		return json_encode( array( 'status' => 'error', 'message' => 'کلید دسترسی (Api-Key) را ابتدا در تنظیمات پیامک وارد کنید.' ) );
	}
	if ( empty( trim( $pattern_code ) ) ) {
		return json_encode( array( 'status' => 'error', 'message' => 'کد پترن برای آپدیت مشخص نیست.' ) );
	}
	$message = (string) $message;
	$parse_err    = '';
	$parsed       = farazsms_parse_pattern_message_placeholders_merged( $message, $parse_err );
	$variables    = $parsed[0];
	$pattern_text = $parsed[1];
	if ( $parse_err !== '' ) {
		return json_encode( array( 'status' => 'error', 'message' => $parse_err ) );
	}

	// v3.22.115: نام‌های hex-ناامن را امن کن (مثلِ create_pattern) تا آپدیت هم پترنِ سالم بسازد.
	$pattern_text = farazsms_pattern_hexsafe_apply( $pattern_text, $variables );

	$vars = array();
	foreach ( $variables as $var ) {
		$tl     = farazsms_tracking_pattern_var_type_length( $var );
		$vars[] = array( 'var' => $var, 'type' => $tl['type'], 'length' => $tl['length'] );
	}
	$website = wp_parse_url( get_site_url(), PHP_URL_HOST );
	if ( empty( $website ) ) {
		$website = get_site_url();
	}
	// v3.22.52: خطِ اضافیِ اختیاری (خطِ WebOTP) بعد از parse — تا %code%ِ تکراری پارسر را رد نکند.
	if ( $extra_append !== '' ) {
		$pattern_text = rtrim( $pattern_text ) . $extra_append;
	}
	$pattern_text = farazsms_pattern_append_site_url( $pattern_text );
	$body = array(
		'text'    => $pattern_text,
		'share'   => 0,
		'website' => $website,
	);
	if ( $description !== '' ) {
		$body['description'] = sanitize_text_field( $description );
	}
	$valid_categories = array( 1, 2, 3, 255 );
	if ( $category !== null && in_array( (int) $category, $valid_categories, true ) ) {
		$body['category'] = (int) $category;
	}
	if ( ! empty( $vars ) ) {
		$body['vars'] = $vars;
	}
	// v3.20.89: transportِ واحد (با fallbackِ cURL).
	$r         = farazsms_sms_pattern_request( 'PUT', 'patterns/' . rawurlencode( $pattern_code ), $body, $apikey );
	$response  = $r['body'];
	$http_code = $r['code'];
	if ( $http_code !== 200 && $http_code !== 201 ) {
		$data = json_decode( $response, true );
		$msg = is_array( $data ) && isset( $data['message'] ) ? $data['message'] : 'خطا در آپدیت پترن (کد ' . $http_code . ')';
		$error_code = farazsms_is_pattern_not_found_message( $msg ) ? 'pattern_not_found' : 'update_failed';
		return json_encode( array( 'status' => 'error', 'message' => $msg, 'error_code' => $error_code, 'http_code' => (int) $http_code ) );
	}
	return $response;
}

/**
 * ساخت پترن برای افزونه پیامک فارسی
 * استخراج خودکار متغیرها از متن و تبدیل به فرمت API
 *
 * @param string $message متن پیام با متغیرهای {variable}
 * @param int $category دسته پترن: 1=otp, 2=club, 3=order, 255=others (پیش‌فرض 3)
 * @return string JSON response
 */
function farazsms_create_pattern_for_pwsms( $message, $category = 3, $description = '' ) {
    // دریافت Api-Key از تنظیمات افزونه پیامک فارسی
    $apikey = farazsms_get_pwsms_apikey();
    
    if (empty($apikey)) {
        return json_encode([
            'status' => 'error',
            'message' => 'کلید دسترسی (Api-Key) را ابتدا در تنظیمات پیامک فارسی وارد کنید.'
        ]);
    }

    // اطمینان از اینکه متن به صورت string است و خطوط جدید حفظ می‌شوند
    $message = (string) $message;

	$parse_err    = '';
	$parsed       = farazsms_parse_pattern_message_placeholders_merged( $message, $parse_err );
	$variables    = $parsed[0];
	$pattern_text = $parsed[1];
	if ( $parse_err !== '' ) {
		return json_encode(
			array(
				'status'  => 'error',
				'message' => $parse_err,
			)
		);
	}

	// v3.22.115: نام‌های hex-ناامن (balance، date، days_left، address، …) را امن کن تا
	// percent-decodeِ سرورِ فراز پترن را خراب نکند. (نام‌های امن دست‌نخورده می‌مانند.)
	$pattern_text = farazsms_pattern_hexsafe_apply( $pattern_text, $variables );

    // ساخت vars بر اساس متغیرهای موجود (طبق مستندات: vars با فیلد var)

    $vars = [];

    foreach ( $variables as $var ) {
		$tl   = farazsms_tracking_pattern_var_type_length( $var, true );
		$vars[] = array(
			'var'    => $var,
			'type'   => $tl['type'],
			'length' => $tl['length'],
		);
    }

    $website_url = get_site_url();
    
    $pattern_text = farazsms_pattern_append_site_url( $pattern_text );
    $body = array(
        'text' => $pattern_text,
        'share' => 0,  // تغییر از 1 به 0 (اختصاصی)
        'website' => $website_url,
    );
    $valid_categories = array( 1, 2, 3, 255 );
    if ( in_array( (int) $category, $valid_categories, true ) ) {
        $body['category'] = (int) $category;
    }
    
    if (!empty($vars)) {
        $body['vars'] = $vars;
    }
    
    // v3.17.3: description برندشده — به جای متن انگلیسی قبلی
    $body['description'] = $description !== ''
        ? sanitize_text_field( $description )
        : 'افزونه فراز اس ام اس / پیامک حرفه‌ای ووکامرس';

    // v3.20.89: transportِ واحد (با fallbackِ cURL برای هاست‌های مسدودکننده).
    $r = farazsms_sms_pattern_request( 'POST', 'patterns', $body, $apikey );
    return $r['body'];
}

/**
 * آپدیت پترن موجود برای افزونه پیامک فارسی (PUT)
 *
 * @param string $pattern_code کد پترن موجود
 * @param string $message متن جدید پیام
 * @param int|null $category دسته پترن: 1=otp, 2=club, 3=order, 255=others (اختیاری)
 * @return string JSON response
 */
function farazsms_update_pattern_for_pwsms( $pattern_code, $message, $category = null ) {
	$apikey = farazsms_get_pwsms_apikey();
	if ( empty( $apikey ) ) {
		return json_encode( array( 'status' => 'error', 'message' => 'کلید دسترسی را در تنظیمات پیامک فارسی وارد کنید.' ) );
	}
	if ( empty( trim( $pattern_code ) ) ) {
		return json_encode( array( 'status' => 'error', 'message' => 'کد پترن برای آپدیت مشخص نیست.' ) );
	}
	$message = (string) $message;
	$parse_err    = '';
	$parsed       = farazsms_parse_pattern_message_placeholders_merged( $message, $parse_err );
	$variables    = $parsed[0];
	$pattern_text = $parsed[1];
	if ( $parse_err !== '' ) {
		return json_encode( array( 'status' => 'error', 'message' => $parse_err ) );
	}
	$vars = array();
	foreach ( $variables as $var ) {
		$tl     = farazsms_tracking_pattern_var_type_length( $var, true );
		$vars[] = array( 'var' => $var, 'type' => $tl['type'], 'length' => $tl['length'] );
	}
	$pattern_text = farazsms_pattern_append_site_url( $pattern_text );
	$body = array( 'text' => $pattern_text, 'share' => 0, 'website' => get_site_url() );
	$valid_categories = array( 1, 2, 3, 255 );
	if ( $category !== null && in_array( (int) $category, $valid_categories, true ) ) {
		$body['category'] = (int) $category;
	}
	if ( ! empty( $vars ) ) { $body['vars'] = $vars; }
	$body['description'] = 'Pattern created automatically from SMS template';
	// v3.20.89: transportِ واحد (با fallbackِ cURL).
	$r         = farazsms_sms_pattern_request( 'PUT', 'patterns/' . rawurlencode( $pattern_code ), $body, $apikey );
	$response  = $r['body'];
	$http_code = $r['code'];
	if ( $http_code !== 200 && $http_code !== 201 ) {
		$data = json_decode( $response, true );
		$msg = is_array( $data ) && isset( $data['message'] ) ? $data['message'] : 'خطا در آپدیت پترن (کد ' . $http_code . ')';
		$error_code = farazsms_is_pattern_not_found_message( $msg ) ? 'pattern_not_found' : 'update_failed';
		return json_encode( array( 'status' => 'error', 'message' => $msg, 'error_code' => $error_code, 'http_code' => (int) $http_code ) );
	}
	return $response;
}

/**
 * بررسی اینکه متن خطا نشان‌دهنده حذف/عدم وجود پترن است.
 *
 * @param mixed $message
 * @return bool
 */
function farazsms_is_pattern_not_found_message( $message ) {
	if ( is_array( $message ) ) {
		$message = wp_json_encode( $message, JSON_UNESCAPED_UNICODE );
	}
	$message = is_string( $message ) ? strtolower( trim( $message ) ) : '';
	if ( $message === '' ) {
		return false;
	}
	$needles = array(
		'pattern not found',
		'not found',
		'404',
		'کد پترن یافت نشد',
		'پترن یافت نشد',
		'پترن وجود ندارد',
		'الگو یافت نشد',
	);
	foreach ( $needles as $needle ) {
		if ( strpos( $message, strtolower( $needle ) ) !== false ) {
			return true;
		}
	}
	return false;
}

/**
 * بررسی اینکه پاسخ API نشان‌دهنده حذف/عدم وجود پترن است.
 *
 * @param mixed $decoded_response
 * @return bool
 */
function farazsms_is_pattern_not_found_response( $decoded_response ) {
	if ( ! is_array( $decoded_response ) ) {
		return false;
	}
	if ( isset( $decoded_response['error_code'] ) && $decoded_response['error_code'] === 'pattern_not_found' ) {
		return true;
	}
	if ( isset( $decoded_response['http_code'] ) && (int) $decoded_response['http_code'] === 404 ) {
		return true;
	}
	$message = '';
	if ( isset( $decoded_response['message'] ) ) {
		$message = $decoded_response['message'];
	} elseif ( isset( $decoded_response['messages'] ) ) {
		$message = $decoded_response['messages'];
	}
	return farazsms_is_pattern_not_found_message( $message );
}

/**
 * دریافت جزئیات پترن از API برای بخش رهگیری
 * 
 * @param string $pattern_code کد پترن
 * @return string JSON response
 */
function farazsms_get_pattern_details($pattern_code) {
	// دریافت Api-Key از تنظیمات افزونه رهگیری
	$apikey = farazsms_get_apikey();
	
	if (empty($apikey) || empty($pattern_code)) {
		return json_encode([
			'status' => 'error',
			'message' => 'کلید API یا کد پترن خالی است.'
		]);
	}
	
	return farazsms_get_pattern_details_with_apikey($apikey, $pattern_code);
}

/**
 * دریافت جزئیات پترن از API برای بخش پیامک فارسی
 * 
 * @param string $pattern_code کد پترن
 * @return string JSON response
 */
function farazsms_get_pattern_details_for_pwsms($pattern_code) {
	// دریافت Api-Key از تنظیمات افزونه پیامک فارسی
	$apikey = farazsms_get_pwsms_apikey();
	
	if (empty($apikey) || empty($pattern_code)) {
		return json_encode([
			'status' => 'error',
			'message' => 'کلید API یا کد پترن خالی است.'
		]);
	}
	
	return farazsms_get_pattern_details_with_apikey($apikey, $pattern_code);
}

/**
 * دریافت جزئیات پترن از API با استفاده از apikey مشخص
 * 
 * @param string $apikey کلید API
 * @param string $pattern_code کد پترن
 * @return string JSON response
 */
function farazsms_get_pattern_details_with_apikey($apikey, $pattern_code) {
	if (empty($apikey) || empty($pattern_code)) {
		return json_encode([
			'status' => 'error',
			'message' => 'کلید API یا کد پترن خالی است.'
		]);
	}

	// v3.21.9 (P4): عبور از سرویسِ واحد — base-URL/هدر/timeout/fallbackِ cURL/نگهبانِ اتصال یک‌جا.
	$response = farazsms_sms_request( 'GET', 'patterns/' . urlencode( $pattern_code ), array(
		'apikey'  => $apikey,
		'timeout' => 15,
	) );
	if ( is_wp_error( $response ) ) {
		return json_encode( array( 'status' => 'error', 'message' => 'خطا در ارسال درخواست: ' . $response->get_error_message() ) );
	}
	return (string) wp_remote_retrieve_body( $response );
}


function farazsms_send_scheduled_sms($order_id , $date_to_send ) {
 
    $apikey = get_option( 'farazsms_apikey', '' );
	$sender  = get_option( 'farazsms_sender', '' );
    $poll_pattern  = get_option( 'farazsms_poll_pattern', '' );
    $order = wc_get_order($order_id);
    if (!$order) {
        // v3.22.39 (بازبینی T4): سفارش حذف/ناموجود — ردیفِ نظرسنجی را terminal علامت بزن تا در
        // صفِ catch-up (queued) گیر نکند و ردیف‌های سالمِ بعدی را از سقفِ LIMIT محروم نکند.
        if ( function_exists( 'farazsms_survey_table' ) && ( ! function_exists( 'farazsms_survey_table_exists' ) || farazsms_survey_table_exists() ) ) {
            global $wpdb;
            $wpdb->update( farazsms_survey_table(), array( 'status' => 'skipped_no_order' ), array( 'order_id' => (int) $order_id ) );
        }
        return;
    }

    // v3.22.37: گاردِ idempotency — این تابع هم از صفِ async و هم از catch-upِ مستقلِ کرون
    // (روی هاست‌هایی که WP-Cron/Action Scheduler اجرا نمی‌شود) صدا زده می‌شود. اگر همین سفارش
    // قبلاً «scheduled» یا «sent» شده، دوباره POST نکن تا مشتری دو نظرسنجی نگیرد.
    if ( function_exists( 'farazsms_survey_table' ) && ( ! function_exists( 'farazsms_survey_table_exists' ) || farazsms_survey_table_exists() ) ) {
        global $wpdb;
        $slog_table = farazsms_survey_table();
        $slog_status = $wpdb->get_var( $wpdb->prepare(
            "SELECT status FROM $slog_table WHERE order_id = %d ORDER BY id DESC LIMIT 1",
            (int) $order_id
        ) );
        if ( in_array( $slog_status, array( 'scheduled', 'sent' ), true ) ) {
            return;
        }
    }

    $phone = $order->get_billing_phone();

    // تبدیل شماره تلفن از فرمت بین‌المللی به فرمت داخلی
    $phone = farazsms_normalize_phone($phone);

 
	if (empty( $apikey ) || empty($poll_pattern) || empty($phone) ) {
		// v3.21.88: به‌جای بازگشتِ خاموش، علتِ skip را در لاگِ نظرسنجی ثبت کن تا دیده شود.
		if ( function_exists( 'farazsms_survey_log_skipped' ) ) {
			$reason = empty( $phone ) ? 'no_phone' : ( empty( $poll_pattern ) ? 'no_pattern' : 'no_apikey' );
			farazsms_survey_log_skipped( (int) $order_id, (string) $phone, $reason );
		}
		return;
	}

$order_id_str = (string) $order_id;

// Build the per-order review URL for the %review_url% pattern variable.
$review_url = function_exists( 'farazsms_survey_build_review_url' )
	? farazsms_survey_build_review_url( $order_id )
	: add_query_arg( 'order_id', (int) $order_id, home_url( '/orderreview/' ) );

$first_name = (string) $order->get_billing_first_name();
// v3.21.56: کوتاه‌کردنِ لینکِ نظرسنجی با کوتاه‌کننده (در صورتِ فعال‌بودن).
$review_url = farazsms_shorten_link( $review_url, 'survey', 'ماژول نظرسنجی / کاربری ' . ( $first_name !== '' ? $first_name : $phone ) );
$last_name  = (string) $order->get_billing_last_name();
$full_name  = trim( $first_name . ' ' . $last_name );

$body = array(
    'code'        => $poll_pattern,
    'attributes'  => array(
        'order_id'   => $order_id_str,
        'name'       => $first_name,
        'family'     => $last_name,
        'full_name'  => $full_name !== '' ? $full_name : 'مشتری گرامی',
        'review_url' => $review_url,
        'sitename'   => get_bloginfo( 'name' ),
    ),
    'recipient'     => $phone,
    'line_number'   => $sender,
    'number_format' => 'english',
    'schedule'      => $date_to_send,
);

// v3.22.117: متغیرهای بیشترِ سفارش (فقط توکن‌های ارجاع‌شده در متنِ نظرسنجی) + امن‌سازیِ hexِ
// کلیدها. چون این مسیر curl خام است (schedule دارد)، تبدیلِ hex-safe اینجا دستی اعمال می‌شود
// تا با نامِ متغیرهای پترن (که موقعِ ساخت امن شده‌اند) بخواند.
$fz_poll_msg = (string) get_option( 'farazsms_poll_message', '' );
if ( $fz_poll_msg !== '' ) {
    $body['attributes'] += farazsms_order_extra_pattern_vars( $order, $fz_poll_msg );
}
if ( is_array( $body['attributes'] ) ) {
    $fz_safe_attrs = array();
    foreach ( $body['attributes'] as $fz_ak => $fz_av ) {
        $fz_safe_attrs[ farazsms_pattern_hexsafe_name( $fz_ak ) ] = $fz_av;
    }
    $body['attributes'] = $fz_safe_attrs;
}
// v3.22.118: این مسیر curl خام است و گاردِ مرکزیِ «خالی→-» را ندارد؛ پس دستی اعمال می‌شود
// تا متغیرِ اعلام‌شده‌ی خالی (مثلِ %company% برای مشتریِ بدونِ شرکت) کلِ پیامکِ نظرسنجی را رد نکند.
if ( is_array( $body['attributes'] ) ) {
    $body['attributes'] = array_map( 'farazsms_attr_placeholder_if_empty', $body['attributes'] );
}

$curl = curl_init();

curl_setopt_array($curl, array(
   CURLOPT_URL => farazsms_sms_api_url( 'sms/pattern' ),
   CURLOPT_RETURNTRANSFER => true,
   CURLOPT_ENCODING => '',
   CURLOPT_MAXREDIRS => 5,
   CURLOPT_CONNECTTIMEOUT => 5,
   CURLOPT_TIMEOUT => 15,
   CURLOPT_FOLLOWLOCATION => true,
   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
   CURLOPT_CUSTOMREQUEST => 'POST',
   CURLOPT_SSL_VERIFYPEER => true,
   CURLOPT_SSL_VERIFYHOST => 2,
   CURLOPT_POSTFIELDS => json_encode( $body, JSON_UNESCAPED_UNICODE ),
   CURLOPT_HTTPHEADER => array(
      'Accept: application/json',
      'Content-Type: application/json',
      'Api-Key: ' . $apikey
   ),
));

$response  = curl_exec( $curl );
$http_code = (int) curl_getinfo( $curl, CURLINFO_HTTP_CODE );
curl_close( $curl );

// Log the dispatch in the survey log (used by the stats dashboard).
$decoded = ( $response !== false ) ? json_decode( (string) $response, true ) : null;
// v3.22.29: سخت‌گیرانه فقط status==='success' را موفق بدان (قبلاً هر پاسخِ غیرِ-error هم «موفق» شمرده می‌شد).
$api_success = ( $http_code >= 200 && $http_code < 300 && is_array( $decoded ) && isset( $decoded['status'] ) && $decoded['status'] === 'success' );
// نگهبانِ اتصال: response === false یعنی cURL اصلاً به مقصد نرسید (مسدودسازی/قطعی)؛
// علت را برای اعلانِ پیشخوان ثبت کن. پاسخِ HTTP (هر کدی) یعنی اتصال سالم است.
if ( $response === false ) {
	farazsms_connectivity_note_failure( 'curl: no response from ' . ( defined( 'FARAZSMS_SMS_API_HOST' ) ? FARAZSMS_SMS_API_HOST : 'api.iranpayamak.com' ) );
} elseif ( $response !== false ) {
	farazsms_connectivity_note_success();
}
// v3.22.29: ثبت در لاگِ متمرکزِ «🩺 تشخیص ارسال» (source: survey) — قبلاً فقط در لاگِ نظرسنجی بود.
if ( $api_success ) {
	$diag = 'success';
} elseif ( $response === false ) {
	$diag = 'curl_error: no response';
} elseif ( is_array( $decoded ) && isset( $decoded['status'] ) && $decoded['status'] === 'error' ) {
	$m = isset( $decoded['message'] ) ? $decoded['message'] : 'خطای نامشخص';
	$diag = 'api_error:' . ( farazsms_flatten_api_message( $m ));
} else {
	$diag = 'HTTP ' . $http_code;
}
farazsms_send_diag_log( $phone, (string) $poll_pattern, $diag, array( 'source' => 'survey', 'http_code' => $http_code ) );
if ( function_exists( 'farazsms_survey_log_dispatch' ) ) {
	farazsms_survey_log_dispatch( (int) $order_id, $phone, $first_name, $last_name, (string) $date_to_send, $api_success, (string) $review_url );
}

}


/**
 * ارسال پیامک پترن با آرایه attributes (برای بخش‌های غیرسفارش مثل دیدگاه)
 *
 * @param string $recipient شماره گیرنده
 * @param string $pattern_code کد پترن
 * @param array  $attributes آرایه متغیرهای پترن (کلید => مقدار)
 * @param string $sender خط ارسال‌کننده (خالی = از تنظیمات)
 * @return string|true 'success' یا رشته خطا
 */
function farazsms_send_pattern_sms_raw( $recipient, $pattern_code, $attributes = array(), $sender = '' ) {
	// v3.20.89: به لایه‌ی سرویسِ واحد delegate می‌شود (base-URL/هدر/timeout/fallback یک‌جا).
	// امضا و قراردادِ بازگشتی ('success' | رشته‌ی خطا) دست‌نخورده می‌ماند.
	return farazsms_sms_send_pattern( $recipient, $pattern_code, $attributes, $sender );
}

/**
 * ارسال پیامک پترن کد رهگیری بر اساس نوع پست (پست/تیپاکس/سایر).
 *
 * این تابع از v3.13.7 از multi-pattern پشتیبانی می‌کند. پترن و پیام بر اساس
 * carrier از این option ها خوانده می‌شوند:
 *
 *   post:  farazsms_pattern_post  + farazsms_message_post   (fallback: farazsms_pattern + farazsms_message — legacy)
 *   tipax: farazsms_pattern_tipax + farazsms_message_tipax
 *   other: farazsms_pattern_other + farazsms_message_other
 *
 * @param int    $order_id      شناسه سفارش ووکامرس
 * @param string $tracking_code کد رهگیری وارد شده
 * @param string $carrier       'post' | 'tipax' | 'other' (پیش‌فرض: 'post')
 */
function farazsms_send_pattern_sms($order_id, $tracking_code, $carrier = 'post') {

    $apikey  = get_option('farazsms_apikey', '');
    $sender  = get_option('farazsms_sender', '');

    // انتخاب پترن و پیام بر اساس carrier — با fallback به مقادیر legacy برای post.
    $carrier = in_array( $carrier, array( 'post', 'tipax', 'other' ), true ) ? $carrier : 'post';
    if ( $carrier === 'post' ) {
        $pattern = get_option( 'farazsms_pattern_post', '' );
        $message = get_option( 'farazsms_message_post', '' );
        // Backward compatibility: اگر کاربر فقط option قدیمی farazsms_pattern را تنظیم کرده، استفاده کن.
        if ( $pattern === '' ) { $pattern = get_option( 'farazsms_pattern', '' ); }
        if ( $message === '' ) { $message = get_option( 'farazsms_message', '' ); }
    } else {
        $pattern = get_option( 'farazsms_pattern_' . $carrier, '' );
        $message = get_option( 'farazsms_message_' . $carrier, '' );
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        return;
    }

    $phone    = $order->get_billing_phone();
    
    // تبدیل شماره تلفن از فرمت بین‌المللی به فرمت داخلی
    $phone = farazsms_normalize_phone($phone);
    
    $fullname = $order->get_formatted_billing_full_name();
	$b_first  = (string) $order->get_billing_first_name();
	$b_last   = (string) $order->get_billing_last_name();

    // بررسی وجود موارد ضروری
    if (empty($apikey) || empty($pattern) || empty($phone)) {
        return;
    }

    // لیست تمام مقادیر قابل استفاده
    $all_values = [
        'customer_fullname' => $fullname,
		'b_first_name'      => $b_first,
		'b_last_name'       => $b_last,
        'order_id'          => (string) $order_id,
        'tracking_code'     => $tracking_code,
    ];

	// v3.22.117: متغیرهای بیشترِ سفارش (آدرس/کدپستی/شهر/حمل‌ونقل/…) — مثلِ پیامکِ سفارش.
	// اتحاد؛ متغیرهای پایه حفظ می‌شوند. فقط توکن‌های ارجاع‌شده در $message ساخته می‌شوند.
	$all_values += farazsms_order_extra_pattern_vars( $order, $message );

	$var_keys   = farazsms_tracking_pattern_var_keys_from_message( $message );
    $attributes = [];

	foreach ( $var_keys as $key ) {
		if ( isset( $all_values[ $key ] ) ) {
			$attributes[ $key ] = $all_values[ $key ];
		}
	}

    // D-4 (v3.22.47): به‌جای curl خامِ بدونِ لاگ، به فرستنده‌ی واحد delegate می‌کنیم — همان
    // مسیری که پیامکِ سفارشِ بومی می‌رود. مزیت: 201-handling، نگهبانِ اتصال، fallbackِ cURL و
    // ثبت در لاگِ «🩺 تشخیص ارسال». قبلاً شکستِ پیامکِ کدِ رهگیری در هیچ لاگی دیده نمی‌شد.
    // قراردادِ بازگشتی حفظ می‌شود؛ فقط حالتِ «پترن تأیید نشده» را از api_error بازتشخیص می‌دهیم.
    $result = farazsms_send_pattern_sms_raw( $phone, $pattern, $attributes, $sender );

    // کانالِ بله (MVP): پس از ارسالِ موفقِ پیامکِ رهگیری، متنِ حل‌شده‌ی محلی را در بله هم بفرست.
    // (رهگیری فقط pattern_code می‌فرستد؛ چون endpointِ پترنِ بله غیرفعال است، متن را از روی
    // templateِ محلی + مقادیر بازسازی می‌کنیم — AD-6/Deferred-resolver.)
    if ( $result === 'success' ) {
        $bale_text = farazsms_bale_resolve_local_text( $message, $all_values );
        farazsms_bale_maybe_send( 'tracking', $phone, $bale_text );
    }

    if ( is_string( $result ) && strpos( $result, 'api_error:' ) === 0 &&
        ( strpos( $result, 'داده درخواستی یافت نشد' ) !== false || strpos( $result, 'درخواستی یافت نشد' ) !== false ) ) {
        return 'pattern_not_approved';
    }
    return $result;
}



// تابعِ ارسالِ تیکتِ قدیمی حذف شد (v3.22.159): به وب‌سرویسِ نسلِ قبل زنگ می‌زد که
// دیگر کار نمی‌کند و هیچ صداکننده‌ای هم نداشت. جایگزینِ زنده: ماژولِ «بازخورد»
// روی سرویسِ فعلیِ تیکت.
