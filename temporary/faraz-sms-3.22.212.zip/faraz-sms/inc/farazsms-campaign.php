<?php
/**
 * Targeted Campaigns / Segmentation — v3.21.99 (theme 4)
 *
 * مخاطبِ هدفمند را بر اساسِ رفتارِ خریدِ ووکامرس می‌سازد (RFM: تازگی/تکرار/ارزش + محصول/شهر)،
 * تعداد را پیش‌نمایش می‌دهد، و کمپینِ پیامکیِ پترنی را به‌صورتِ دسته‌ای (بدونِ تایم‌اوت) می‌فرستد.
 * از خطِ تبلیغاتی (PRO) ارسال می‌شود و در پنلِ «تشخیص ارسال» ثبت می‌گردد.
 *
 * متغیرِ پترن: %name% (نامِ مشتری) — امن است (با «na» شروع می‌شود، «n» هگز نیست).
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

function farazsms_campaign_settings() {
	$d = array(
		'pattern_code' => '',
		'message'      => "%name% عزیز، یک پیشنهادِ ویژه برای شما داریم! برای دیدن به فروشگاه سر بزنید.",
	);
	$s = get_option( 'farazsms_campaign_settings', array() );
	return array_merge( $d, is_array( $s ) ? $s : array() );
}

/** کلیدِ transientِ مخاطبِ ساخته‌شده برای کاربرِ جاری. */
function farazsms_campaign_audience_key() {
	return 'farazsms_campaign_aud_' . get_current_user_id();
}

/**
 * ساختِ مخاطب از سفارش‌های ووکامرس طبقِ معیارها.
 * برای محدودکردنِ بار، حداکثر ۵۰۰۰ سفارشِ اخیرِ داخلِ بازه پیمایش می‌شود.
 *
 * @return array فهرستِ ['phone'=>..., 'name'=>...]
 */
function farazsms_campaign_build_audience( $c ) {
	if ( ! function_exists( 'wc_get_orders' ) ) {
		return array();
	}
	$lookback = max( 1, (int) $c['lookback_days'] );
	$since    = ( new DateTime( '-' . $lookback . ' days', function_exists( 'wp_timezone' ) ? wp_timezone() : null ) )->getTimestamp();

	// v3.22.1: به‌جای بارگذاریِ ۵۰۰۰ آبجکتِ سفارش یک‌جا (ریسکِ اتمامِ حافظه)، صفحه‌به‌صفحه (۵۰۰تایی)
	// پیمایش می‌کنیم تا در هر لحظه فقط یک صفحه در حافظه باشد. حداکثر ۱۰ صفحه = ۵۰۰۰ سفارش؛ اگر به
	// این سقف خوردیم، $capped را علامت می‌زنیم تا در پیش‌نمایش هشدار داده شود.
	$agg      = array(); // phone => [spent, count, last_ts, name, city, product_hit]
	$per_page = 500;
	$max_page = 10;
	$page     = 1;
	$capped   = false;
	do {
		$orders = wc_get_orders( array(
			'limit'        => $per_page,
			'paged'        => $page,
			'status'       => array( 'completed', 'processing' ),
			'date_created' => '>=' . $since,
			'orderby'      => 'date',
			'order'        => 'DESC',
			'return'       => 'objects',
		) );
		$got = is_array( $orders ) ? count( $orders ) : 0;
	foreach ( (array) $orders as $order ) {
		if ( ! $order instanceof WC_Order ) {
			continue;
		}
		$phone = farazsms_normalize_phone( $order->get_billing_phone() );
		if ( $phone === '' ) {
			continue;
		}
		$ts = $order->get_date_created() ? $order->get_date_created()->getTimestamp() : 0;
		if ( ! isset( $agg[ $phone ] ) ) {
			$agg[ $phone ] = array(
				'spent'       => 0.0,
				'count'       => 0,
				'last_ts'     => 0,
				'name'        => trim( $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ),
				'city'        => (string) $order->get_billing_city(),
				'product_hit' => false,
			);
		}
		$agg[ $phone ]['spent'] += (float) $order->get_total();
		$agg[ $phone ]['count']++;
		if ( $ts > $agg[ $phone ]['last_ts'] ) {
			$agg[ $phone ]['last_ts'] = $ts;
		}
		// فیلترِ محصول/دسته: اگر تنظیم شده، بررسی کن آیا این سفارش آن را دارد.
		if ( ( (int) $c['product_id'] > 0 || (int) $c['category_id'] > 0 ) && ! $agg[ $phone ]['product_hit'] ) {
			foreach ( $order->get_items() as $item ) {
				$pid = method_exists( $item, 'get_product_id' ) ? (int) $item->get_product_id() : 0;
				if ( (int) $c['product_id'] > 0 && $pid === (int) $c['product_id'] ) {
					$agg[ $phone ]['product_hit'] = true;
					break;
				}
				if ( (int) $c['category_id'] > 0 && $pid > 0 && has_term( (int) $c['category_id'], 'product_cat', $pid ) ) {
					$agg[ $phone ]['product_hit'] = true;
					break;
				}
			}
		}
	}
		$page++;
		if ( $got === $per_page && $page > $max_page ) {
			$capped = true;
			break;
		}
	} while ( $got === $per_page );

	// اعمالِ فیلترها.
	$min_spent   = max( 0, (float) $c['min_spent'] );
	$min_orders  = max( 0, (int) $c['min_orders'] );
	$rec_mode    = in_array( $c['recency_mode'], array( 'any', 'within', 'not_within' ), true ) ? $c['recency_mode'] : 'any';
	$rec_cut     = time() - max( 1, (int) $c['recency_days'] ) * DAY_IN_SECONDS;
	$city_filter = trim( (string) $c['city'] );
	$need_prod   = ( (int) $c['product_id'] > 0 || (int) $c['category_id'] > 0 );

	$out = array();
	foreach ( $agg as $phone => $a ) {
		if ( $a['spent'] < $min_spent ) {
			continue;
		}
		if ( $a['count'] < $min_orders ) {
			continue;
		}
		if ( $rec_mode === 'within' && $a['last_ts'] < $rec_cut ) {
			continue;
		}
		if ( $rec_mode === 'not_within' && $a['last_ts'] >= $rec_cut ) {
			continue;
		}
		if ( $city_filter !== '' && mb_stripos( $a['city'], $city_filter ) === false ) {
			continue;
		}
		if ( $need_prod && ! $a['product_hit'] ) {
			continue;
		}
		$out[] = array( 'phone' => $phone, 'name' => $a['name'] !== '' ? $a['name'] : 'مشتری' );
	}
	return array( 'list' => array_values( $out ), 'capped' => $capped );
}

/** خواندنِ معیارها از POST. */
function farazsms_campaign_criteria_from_post() {
	return array(
		'lookback_days' => isset( $_POST['lookback_days'] ) ? (int) $_POST['lookback_days'] : 365,
		'min_spent'     => isset( $_POST['min_spent'] ) ? (float) $_POST['min_spent'] : 0,
		'min_orders'    => isset( $_POST['min_orders'] ) ? (int) $_POST['min_orders'] : 0,
		'recency_mode'  => isset( $_POST['recency_mode'] ) ? sanitize_key( wp_unslash( $_POST['recency_mode'] ) ) : 'any',
		'recency_days'  => isset( $_POST['recency_days'] ) ? (int) $_POST['recency_days'] : 30,
		'product_id'    => isset( $_POST['product_id'] ) ? (int) $_POST['product_id'] : 0,
		'category_id'   => isset( $_POST['category_id'] ) ? (int) $_POST['category_id'] : 0,
		'city'          => isset( $_POST['city'] ) ? sanitize_text_field( wp_unslash( $_POST['city'] ) ) : '',
	);
}

// ── AJAX: پیش‌نمایشِ مخاطب ─────────────────────────────────────────────────
add_action( 'wp_ajax_farazsms_campaign_preview', 'farazsms_campaign_ajax_preview' );
function farazsms_campaign_ajax_preview() {
	if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'farazsms_campaign', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
	}
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 0 );
	}
	$res      = farazsms_campaign_build_audience( farazsms_campaign_criteria_from_post() );
	$audience = $res['list'];
	set_transient( farazsms_campaign_audience_key(), $audience, HOUR_IN_SECONDS );
	$sample = array();
	foreach ( array_slice( $audience, 0, 5 ) as $a ) {
		$sample[] = ( $a['name'] ?: 'مشتری' ) . ' — ' . $a['phone'];
	}
	wp_send_json_success( array(
		'count'  => count( $audience ),
		'sample' => $sample,
		'capped' => ! empty( $res['capped'] ),
	) );
}

// ── AJAX: ارسالِ یک دسته ───────────────────────────────────────────────────
add_action( 'wp_ajax_farazsms_campaign_send_batch', 'farazsms_campaign_ajax_send_batch' );
function farazsms_campaign_ajax_send_batch() {
	if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'farazsms_campaign', 'nonce', false ) ) {
		wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
	}
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 0 );
	}
	$audience = get_transient( farazsms_campaign_audience_key() );
	if ( ! is_array( $audience ) ) {
		wp_send_json_error( array( 'message' => 'مخاطب منقضی شد. دوباره پیش‌نمایش بگیرید.' ) );
	}
	$pattern = isset( $_POST['pattern_code'] ) ? sanitize_text_field( wp_unslash( $_POST['pattern_code'] ) ) : '';
	if ( $pattern === '' ) {
		wp_send_json_error( array( 'message' => 'ابتدا پترن را بسازید و کدش را وارد کنید.' ) );
	}
	$offset = isset( $_POST['offset'] ) ? max( 0, (int) $_POST['offset'] ) : 0;
	$size   = 30;
	$total  = count( $audience );
	$end    = min( $offset + $size, $total );

	// v3.22.1: هر مخاطب پس از تلاش «sent» علامت می‌خورد؛ اگر مدیر دوباره ارسال بزند (کلیکِ مجدد/تبِ
	// دوم)، مخاطبانِ ارسال‌شده رد می‌شوند و پیامکِ تکراری (و هزینه) ایجاد نمی‌شود.
	$sent      = 0;
	$processed = 0;
	$ad = farazsms_get_ad_sender();
	for ( $i = $offset; $i < $end; $i++ ) {
		if ( ! empty( $audience[ $i ]['sent'] ) ) {
			continue;
		}
		$a   = $audience[ $i ];
		$res = farazsms_send_pattern_sms_raw( $a['phone'], $pattern, array( 'name' => $a['name'] !== '' ? $a['name'] : 'مشتری' ), $ad );
		if ( $res === 'success' ) {
			$sent++;
		}
		$audience[ $i ]['sent'] = 1; // علامتِ «تلاش شد» تا دوباره ارسال/شارژ نشود.
		$processed++;
	}
	// تازه‌سازیِ TTLِ transient با هر دسته تا وسطِ ارسالِ طولانی منقضی نشود.
	set_transient( farazsms_campaign_audience_key(), $audience, HOUR_IN_SECONDS );

	wp_send_json_success( array(
		'sent'        => $sent,
		'processed'   => $processed,
		'next_offset' => $end,
		'done'        => ( $end >= $total ),
		'total'       => $total,
	) );
}

// ── ذخیره‌ی تنظیمات (کد/متنِ پترن) ─────────────────────────────────────────
add_action( 'admin_post_farazsms_campaign_save', 'farazsms_campaign_handle_save' );
function farazsms_campaign_handle_save() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die();
	}
	check_admin_referer( 'farazsms_campaign_save' );
	$s = farazsms_campaign_settings();
	$s['pattern_code'] = sanitize_text_field( wp_unslash( $_POST['campaign_pattern_code'] ?? '' ) );
	update_option( 'farazsms_campaign_settings', $s, false );
	wp_safe_redirect( add_query_arg( 'saved', '1', admin_url( 'admin.php?page=farazsms-campaign' ) ) );
	exit;
}

// ── صفحه‌ی ادمین ───────────────────────────────────────────────────────────
add_action( 'admin_menu', 'farazsms_campaign_menu', 58 );
function farazsms_campaign_menu() {
	add_submenu_page(
		'farazsms',
		'کمپین هدفمند',
		'🎯 کمپین هدفمند',
		'manage_options',
		'farazsms-campaign',
		'farazsms_campaign_render_page'
	);
}

function farazsms_campaign_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'دسترسی غیرمجاز.' );
	}
	if ( ! function_exists( 'wc_get_orders' ) ) {
		echo '<div class="wrap" style="direction:rtl;"><h1>🎯 کمپین هدفمند</h1><div class="notice notice-warning"><p>این قابلیت نیازمندِ ووکامرس است.</p></div></div>';
		return;
	}
	$s     = farazsms_campaign_settings();
	$nonce = wp_create_nonce( 'farazsms_campaign' );
	$in    = 'width:100%;max-width:220px;padding:8px 10px;border:1px solid #e1e1e1;border-radius:7px;';
	?>
	<div class="wrap" style="direction:rtl;max-width:900px;">
		<h1 style="font-size:21px;">🎯 کمپین هدفمند</h1>
		<?php if ( isset( $_GET['saved'] ) ) : ?><div style="background:#e2f8f0;border:1px solid #10c282;color:#096d49;padding:10px 14px;border-radius:8px;margin:10px 0;">✓ ذخیره شد.</div><?php endif; ?>
		<p style="color:#9b9b9b;font-size:13px;">مشتریان را بر اساسِ رفتارِ خرید فیلتر کنید، تعداد را ببینید و کمپینِ پیامکی بفرستید. از خطِ تبلیغاتی (PRO) ارسال می‌شود.</p>

		<div style="background:#fff;border:1px solid #e1e1e1;border-radius:12px;padding:20px;margin-top:12px;">
			<h3 style="margin:0 0 12px;font-size:15px;">۱) معیارهای مخاطب</h3>
			<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px;">
				<label>بازه‌ی بررسی (روزِ اخیر)<br><input type="number" id="c-lookback" value="365" min="1" style="<?php echo $in; ?>"></label>
				<label>حداقل مجموعِ خرید (تومان)<br><input type="number" id="c-min-spent" value="0" min="0" style="<?php echo $in; ?>"></label>
				<label>حداقل تعدادِ سفارش<br><input type="number" id="c-min-orders" value="0" min="0" style="<?php echo $in; ?>"></label>
				<label>تازگیِ خرید<br>
					<select id="c-rec-mode" style="<?php echo $in; ?>">
						<option value="any">مهم نیست</option>
						<option value="within">در N روزِ اخیر خرید کرده</option>
						<option value="not_within">در N روزِ اخیر خرید نکرده (بازگردانی)</option>
					</select>
				</label>
				<label>N (روز)<br><input type="number" id="c-rec-days" value="30" min="1" style="<?php echo $in; ?>"></label>
				<label>فقط خریدارانِ محصولِ خاص (شناسه)<br><input type="number" id="c-product" value="0" min="0" style="<?php echo $in; ?>"></label>
				<label>فقط خریدارانِ دسته‌ی خاص (شناسه)<br><input type="number" id="c-category" value="0" min="0" style="<?php echo $in; ?>"></label>
				<label>فقط شهرِ خاص<br><input type="text" id="c-city" value="" placeholder="مثلاً تهران" style="<?php echo $in; ?>"></label>
			</div>
			<div style="margin-top:14px;">
				<button type="button" id="c-preview" class="button button-secondary">👁 پیش‌نمایشِ تعداد</button>
				<span id="c-preview-result" style="margin-right:10px;font-size:13px;color:#4d4d4d;"></span>
			</div>
			<div id="c-sample" style="margin-top:8px;font-size:12px;color:#9b9b9b;"></div>
			<p style="font-size:11.5px;color:#9b9b9b;margin-top:8px;">توجه: برای کارایی، حداکثر ۵۰۰۰ سفارشِ اخیرِ داخلِ بازه بررسی می‌شود.</p>
		</div>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="background:#fff;border:1px solid #e1e1e1;border-radius:12px;padding:20px;margin-top:16px;">
			<input type="hidden" name="action" value="farazsms_campaign_save">
			<?php wp_nonce_field( 'farazsms_campaign_save' ); ?>
			<h3 style="margin:0 0 12px;font-size:15px;">۲) پترنِ پیامکِ کمپین</h3>
			<input type="hidden" name="campaign_pattern_code" id="c-pattern-code" value="<?php echo esc_attr( $s['pattern_code'] ); ?>">
			<p style="font-size:11.5px;color:#9b9b9b;">متغیر: <code>%name%</code> (نامِ مشتری). آدرسِ سایت خودکار به انتهای پترن افزوده می‌شود.</p>
			<?php
			farazsms_feature_pattern_builder_ui( 'campaign', $s['message'], array( '%name%' ), 'campaign_pattern_code' );
			?>
			<button type="submit" class="button button-primary" style="margin-top:8px;">💾 ذخیره‌ی پترن</button>
		</form>

		<div style="background:#fff;border:1px solid #e1e1e1;border-radius:12px;padding:20px;margin-top:16px;">
			<h3 style="margin:0 0 12px;font-size:15px;">۳) ارسالِ کمپین</h3>
			<p style="font-size:12px;color:#9b9b9b;">اول «پیش‌نمایشِ تعداد» را بزنید تا مخاطب ساخته شود، سپس ارسال.</p>
			<button type="button" id="c-send" class="button button-primary button-hero" disabled>🚀 ارسالِ کمپین به مخاطب</button>
			<div id="c-send-progress" style="margin-top:12px;font-size:13px;color:#4d4d4d;"></div>
		</div>
	</div>

	<script>
	(function(){
		var nonce = <?php echo wp_json_encode( $nonce ); ?>, ajax = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
		function crit(){ return {
			lookback_days:val('c-lookback'), min_spent:val('c-min-spent'), min_orders:val('c-min-orders'),
			recency_mode:val('c-rec-mode'), recency_days:val('c-rec-days'), product_id:val('c-product'),
			category_id:val('c-category'), city:val('c-city')
		}; }
		function val(id){ var e=document.getElementById(id); return e?e.value:''; }
		function post(data, cb){ var fd=new FormData(); fd.append('nonce',nonce); for(var k in data) fd.append(k,data[k]);
			fetch(ajax,{method:'POST',credentials:'same-origin',body:fd}).then(function(r){return r.json();}).then(cb).catch(function(){cb({success:false,data:{message:'خطای ارتباط'}});}); }

		var total = 0;
		document.getElementById('c-preview').addEventListener('click', function(){
			var btn=this, res=document.getElementById('c-preview-result'); btn.disabled=true; res.textContent='در حال محاسبه…';
			var d=crit(); d.action='farazsms_campaign_preview';
			post(d, function(r){ btn.disabled=false;
				if(r.success){ total=r.data.count;
					res.innerHTML='👥 <b>'+total+'</b> مخاطبِ واجدِ شرایط' + (r.data.capped ? ' <span style="color:#83620d;">(⚠ به سقفِ ۵۰۰۰ سفارش خوردیم؛ ممکن است ناقص باشد)</span>' : '');
					document.getElementById('c-sample').textContent = (r.data.sample||[]).join(' · ');
					document.getElementById('c-send').disabled = (total===0);
				} else { res.textContent='✗ '+((r.data&&r.data.message)||'خطا'); }
			});
		});

		document.getElementById('c-send').addEventListener('click', function(){
			var code=document.getElementById('c-pattern-code').value;
			if(!code){ alert('اول پترن را بسازید و ذخیره کنید.'); return; }
			if(!confirm('ارسالِ کمپین به '+total+' مخاطب؟ (هزینه‌ی پیامک)')) return;
			var btn=this, prog=document.getElementById('c-send-progress'); btn.disabled=true;
			var sentTotal=0;
			function batch(offset){
				post({action:'farazsms_campaign_send_batch', pattern_code:code, offset:offset}, function(r){
					if(!r.success){ prog.innerHTML='✗ '+((r.data&&r.data.message)||'خطا'); btn.disabled=false; return; }
					sentTotal+=r.data.sent;
					var pct = r.data.total>0 ? Math.round(r.data.next_offset/r.data.total*100) : 100;
					prog.innerHTML='در حال ارسال… '+pct+'٪ — '+sentTotal+' پیامک ارسال شد';
					if(r.data.done){ prog.innerHTML='✅ کمپین تمام شد — '+sentTotal+' پیامک ارسال شد.'; btn.disabled=false; }
					else { batch(r.data.next_offset); }
				});
			}
			batch(0);
		});
	})();
	</script>
	<?php
}
