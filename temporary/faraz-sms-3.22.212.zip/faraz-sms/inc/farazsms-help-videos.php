<?php
/**
 * ویدیوهای آموزشیِ داخلِ افزونه (کاهشِ بارِ پشتیبانی).
 *
 * یک دکمه/آیکونِ جذاب کنارِ عنوانِ هر بخش نشان می‌دهد؛ با کلیک، ویدیو در یک مودالِ داخلِ همان
 * صفحه باز می‌شود. ویدیو (iframeِ آپارات) فقط پس از کلیک بارگذاری می‌شود (lazy) — پس روی
 * لودِ صفحه‌ی ادمین هیچ تماسِ خارجی‌ای رخ نمی‌دهد (سازگار با قانونِ «بدونِ بلاک‌کننده‌ی خارجی روی
 * رندر» و اینترنتِ ملی). یک لینکِ «در آپارات ببینید» هم به‌عنوانِ جایگزین هست.
 *
 * افزودنِ ویدیوی جدید = فقط یک ردیف در farazsms_help_videos_registry() + یک صدازدنِ
 * farazsms_help_video_button('key') کنارِ عنوانِ آن بخش.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * فهرستِ ویدیوها. کلید = شناسه‌ی بخش. hash = کدِ ویدیوی آپارات (بخشِ آخرِ URL).
 *
 * @return array<string, array{hash: string, url: string, title: string}>
 */
function farazsms_help_videos_registry() {
	$videos = array(
		'orders' => array(
			'hash'  => 'xapw44d',
			'url'   => 'https://www.aparat.com/v/xapw44d',
			'title' => 'آموزش پیامک سفارشات',
		),
		'login'  => array(
			'hash'  => 'cnt5gad',
			'url'   => 'https://www.aparat.com/v/cnt5gad',
			'title' => 'آموزش ورود و ثبت‌نام با پیامک',
		),
		'elementor' => array(
			'hash'  => 'qdvy15t',
			'url'   => 'https://www.aparat.com/v/qdvy15t',
			'title' => 'آموزش پیامکِ فرم‌های المنتور',
		),
	);
	/**
	 * امکانِ افزودن/تغییرِ ویدیوها بدونِ ویرایشِ این فایل.
	 */
	return (array) apply_filters( 'farazsms_help_videos', $videos );
}

/**
 * دکمه/آیکونِ «آموزش ویدیویی» برای یک بخش. (اسکریپت/استایلِ مشترک یک‌بار چاپ می‌شود.)
 *
 * @param string $key   شناسه‌ی بخش در registry.
 * @param string $label متنِ دکمه (اختیاری).
 * @return void
 */
function farazsms_help_video_button( $key, $label = '🎬 آموزش ویدیویی' ) {
	$videos = farazsms_help_videos_registry();
	if ( ! isset( $videos[ $key ] ) ) {
		return;
	}
	$v = $videos[ $key ];
	// گاردِ ردیفِ ناقص (مثلاً از فیلترِ farazsms_help_videos): بدونِ hash معنا ندارد؛ url/title اختیاری با پیش‌فرض.
	if ( ! is_array( $v ) || empty( $v['hash'] ) ) {
		return;
	}
	$hash = preg_replace( '/[^a-zA-Z0-9]/', '', (string) $v['hash'] );
	if ( $hash === '' ) {
		return;
	}
	$url   = isset( $v['url'] ) ? (string) $v['url'] : '';
	$title = isset( $v['title'] ) && $v['title'] !== '' ? (string) $v['title'] : 'ویدیوی آموزشی';
	farazsms_help_video_boot(); // یک‌بار: استایل + مودال + اسکریپت را در admin_footer زمان‌بندی کن.
	printf(
		'<button type="button" class="farazsms-help-video-btn" data-fzhv-hash="%s" data-fzhv-title="%s" data-fzhv-url="%s"><span class="fzhv-play" aria-hidden="true">▶</span> %s</button>',
		esc_attr( $hash ),
		esc_attr( $title ),
		esc_url( $url ),
		esc_html( $label )
	);
}

/**
 * یک‌بار: رندرِ استایل/مودال/اسکریپت را برای admin_footer زمان‌بندی می‌کند تا مودال فرزندِ مستقیمِ
 * body باشد (نه داخلِ h1/hero). اگر admin_footer از قبل اجرا شده باشد (حالتِ نادر)، بی‌درنگ چاپ می‌کند.
 *
 * @return void
 */
function farazsms_help_video_boot() {
	static $booted = false;
	if ( $booted ) {
		return;
	}
	$booted = true;
	if ( function_exists( 'did_action' ) && did_action( 'admin_footer' ) ) {
		farazsms_help_video_render();
		return;
	}
	add_action( 'admin_footer', 'farazsms_help_video_render', 99 );
}

/**
 * استایل + مارک‌آپِ مودال + اسکریپت — یک‌بار در فوترِ ادمین.
 *
 * @return void
 */
function farazsms_help_video_render() {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done = true;
	?>
	<style>
	.farazsms-help-video-btn{display:inline-flex;align-items:center;gap:7px;cursor:pointer;border:0;
		background:linear-gradient(135deg,#d52a16 0%,#d52a16 100%);color:#fff;font-family:inherit;
		font-size:12.5px;font-weight:700;padding:7px 14px;border-radius:999px;line-height:1;
		box-shadow:0 3px 10px rgba(220,38,38,.32);transition:transform .15s,box-shadow .15s;
		animation:fzhvPulse 2.2s ease-in-out infinite;vertical-align:middle;}
	.farazsms-help-video-btn:hover{transform:translateY(-1px) scale(1.03);box-shadow:0 6px 16px rgba(220,38,38,.42);}
	.farazsms-help-video-btn .fzhv-play{display:inline-flex;align-items:center;justify-content:center;
		width:18px;height:18px;background:rgba(255,255,255,.22);border-radius:50%;font-size:9px;padding-right:1px;}
	@keyframes fzhvPulse{0%,100%{box-shadow:0 3px 10px rgba(220,38,38,.32);}50%{box-shadow:0 3px 10px rgba(220,38,38,.32),0 0 0 6px rgba(239,68,68,.14);}}
	@media (prefers-reduced-motion:reduce){.farazsms-help-video-btn{animation:none;}}
	#farazsms-hv-overlay{position:fixed;inset:0;z-index:100050;display:none;background:rgba(15,23,42,.72);
		backdrop-filter:blur(2px);align-items:center;justify-content:center;padding:20px;direction:rtl;}
	#farazsms-hv-overlay.fzhv-open{display:flex;}
	.fzhv-modal{background:#fff;border-radius:14px;overflow:hidden;width:100%;max-width:860px;
		box-shadow:0 20px 60px rgba(0,0,0,.4);}
	.fzhv-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 16px;
		background:#263f67;color:#fff;font-family:inherit;}
	.fzhv-head h3{margin:0;font-size:14px;font-weight:700;}
	.fzhv-close{cursor:pointer;border:0;background:rgba(255,255,255,.14);color:#fff;width:30px;height:30px;
		border-radius:8px;font-size:18px;line-height:1;}
	.fzhv-close:hover{background:rgba(255,255,255,.28);}
	.fzhv-frame{position:relative;width:100%;padding-top:56.25%;background:#000;}
	.fzhv-frame iframe{position:absolute;inset:0;width:100%;height:100%;border:0;}
	.fzhv-foot{padding:9px 16px;font-size:12px;background:#f5f8fe;border-top:1px solid #e1e1e1;color:#4d4d4d;}
	.fzhv-foot a{color:#d52a16;font-weight:700;text-decoration:none;}
	.fzhv-foot a:hover{text-decoration:underline;}
	</style>
	<div id="farazsms-hv-overlay" role="dialog" aria-modal="true" aria-label="ویدیوی آموزشی">
		<div class="fzhv-modal">
			<div class="fzhv-head">
				<h3 id="fzhv-title">ویدیوی آموزشی</h3>
				<button type="button" class="fzhv-close" id="fzhv-close" aria-label="بستن">&times;</button>
			</div>
			<div class="fzhv-frame" id="fzhv-frame"></div>
			<div class="fzhv-foot">اگر ویدیو نمایش داده نشد، <a id="fzhv-fallback" href="#" target="_blank" rel="noopener">در آپارات ببینید</a>.</div>
		</div>
	</div>
	<script>
	(function(){
		var overlay = document.getElementById('farazsms-hv-overlay');
		if(!overlay) return;
		var frame = document.getElementById('fzhv-frame');
		var titleEl = document.getElementById('fzhv-title');
		var fallback = document.getElementById('fzhv-fallback');
		function open(hash, title, url){
			hash = String(hash||'').replace(/[^a-zA-Z0-9]/g,'');
			if(!hash) return;
			// iframe فقط همین‌جا (با کلیک) ساخته می‌شود — نه روی لودِ صفحه.
			var safeTitle = String(title||'ویدیوی آموزشی').replace(/"/g,'');
			frame.innerHTML = '<iframe title="'+safeTitle+'" src="https://www.aparat.com/video/video/embed/videohash/'+hash+'/vt/frame" allowfullscreen webkitallowfullscreen mozallowfullscreen allow="autoplay; fullscreen"></iframe>';
			titleEl.textContent = title || 'ویدیوی آموزشی';
			if(url){ fallback.href = url; }
			overlay.classList.add('fzhv-open');
		}
		function close(){
			overlay.classList.remove('fzhv-open');
			frame.innerHTML = ''; // توقفِ پخش + آزادسازی.
		}
		document.addEventListener('click', function(e){
			var btn = e.target.closest ? e.target.closest('.farazsms-help-video-btn') : null;
			if(btn){ e.preventDefault(); open(btn.getAttribute('data-fzhv-hash'), btn.getAttribute('data-fzhv-title'), btn.getAttribute('data-fzhv-url')); return; }
			if(e.target === overlay){ close(); }
		});
		var closeBtn = document.getElementById('fzhv-close');
		if(closeBtn){ closeBtn.addEventListener('click', close); }
		document.addEventListener('keydown', function(e){ if(e.key === 'Escape' && overlay.classList.contains('fzhv-open')){ close(); } });
	})();
	</script>
	<?php
}
