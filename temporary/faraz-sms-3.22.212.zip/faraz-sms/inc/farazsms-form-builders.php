<?php
/**
 * یکپارچه‌سازی با فرم‌سازها — WPForms و MetForm.
 *
 * هر دو هوکِ زیر از **منبعِ خودِ افزونه** استخراج و تأیید شده‌اند (نه از مستندات
 * یا وبلاگ — درسِ بوکلی):
 *
 * wpforms_process_complete       ( $fields, $entry, $form_data, $entry_id )
 *   includes/class-process.php — $fields آرایه‌ای کلید-به-شناسه‌ی فیلد است و هر
 *   عضوش array( 'name' => برچسب, 'value' => مقدار, 'id' => شناسه, 'type' => نوع ).
 *
 * metform_after_store_form_data  ( $form_id, $form_data, $form_settings, $attributes )
 *   core/entries/action.php — $form_data یک آرایه‌ی تختِ «نامِ فیلد → مقدار» است
 *   (نام‌ها مثلِ mf-telephone). عمداً هوکِ *after* انتخاب شده تا فقط ثبتِ موفق
 *   پیامک بدهد.
 *
 * هر دو به یک «موتورِ قانون» مشترک می‌رسند: (فرم‌ساز، شناسه‌ی فرم) → فیلدِ موبایل،
 * کدپترن، متن، شماره‌ی مدیر. متغیرهای پترن از توکن‌های {field} یا %field%ِ متن
 * خوانده و از دادهٔ همان ارسال پر می‌شوند.
 *
 * کارایی: ثبتِ فرم مسیرِ کاربر است (اغلب AJAX)، پس ارسال هرگز درجا انجام نمی‌شود؛
 * به صفِ shutdown می‌رود و پس از بسته‌شدنِ پاسخ اجرا می‌گردد.
 *
 * @package farazsms
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

const FARAZSMS_FB_OPTION       = 'farazsms_form_builders_rules';
const FARAZSMS_FB_FIELDS_OPT   = 'farazsms_form_builders_seen_fields';

// ارسال از صفِ مشترک می‌گذرد (غیرمسدود + باقی‌ماندهٔ ماندگار):
//
// inc/farazsms-send-queue.php

/**
 * فرم‌سازهای پشتیبانی‌شده.
 *
 * @return array
 */
function farazsms_fb_sources() {
	return array(
		'wpforms' => 'WPForms',
		'metform' => 'MetForm',
	);
}

/**
 * آیا این فرم‌ساز روی سایت فعال است؟
 *
 * @param string $source
 * @return bool
 */
function farazsms_fb_source_active( $source ) {
	if ( $source === 'wpforms' ) {
		return function_exists( 'wpforms' ) || defined( 'WPFORMS_VERSION' );
	}
	if ( $source === 'metform' ) {
		return defined( 'METFORM_VERSION' ) || class_exists( '\MetForm\Plugin' ) || class_exists( 'MetForm\Plugin' );
	}
	return false;
}

// ============================================================================
// قانون‌ها
// ============================================================================

/**
 * شناسه‌ی پایدارِ یک قانون — از (فرم‌ساز + شناسه‌ی فرم)، نه از ایندکسِ آرایه.
 *
 * @param array $rule
 * @return string رشته‌ی خالی اگر قانون ناقص باشد
 */
function farazsms_fb_rule_key( $rule ) {
	$source  = sanitize_key( (string) ( $rule['source'] ?? '' ) );
	$form_id = (int) ( $rule['form_id'] ?? 0 );
	return ( $source !== '' && $form_id > 0 ) ? $source . '_' . $form_id : '';
}

/**
 * @return array
 */
function farazsms_fb_get_rules() {
	$rules = get_option( FARAZSMS_FB_OPTION, array() );
	return is_array( $rules ) ? array_values( $rules ) : array();
}

/**
 * متغیرهای قابلِ استفاده — علاوه بر نامِ فیلدهای خودِ فرم.
 *
 * @return array
 */
function farazsms_fb_builtin_vars() {
	return array( '%form_title%', '%sitename%' );
}

// ============================================================================
// نرمال‌سازیِ دادهٔ ارسال به یک شکلِ واحد
// ============================================================================

/**
 * تبدیلِ نامِ فیلد به کلیدی که «واقعاً» می‌تواند متغیرِ پترن باشد.
 *
 * ⚠️ چرا لازم است: پارسرِ ساختِ پترن فقط [a-zA-Z0-9_] را می‌پذیرد، ولی نامِ
 * فیلدهای مت‌فرم خط‌تیره دارند (mf-telephone) و برچسبِ فارسیِ وی‌پی‌فرمز کلیدِ
 * غیرِ ASCII می‌سازد. بدونِ این تبدیل، مدیر %mf-telephone% می‌نوشت، پارسر هیچ
 * متغیری پیدا نمی‌کرد، و پیامکِ نهایی عینِ همان رشته را نشان می‌داد — بدونِ
 * هیچ خطایی.
 *
 * @param string $key
 * @return string رشته‌ی خالی اگر اصلاً قابلِ استفاده نباشد
 */
function farazsms_fb_var_key( $key ) {
	$key = str_replace( '-', '_', (string) $key );
	$key = preg_replace( '/[^a-zA-Z0-9_]/', '', $key );
	return (string) $key;
}


/**
 * دادهٔ WPForms را به «نام → مقدار» تبدیل می‌کند.
 *
 * هم شناسه‌ی فیلد کلید می‌شود و هم برچسبِ اسلاگ‌شده، تا مدیر بتواند با هرکدام
 * که راحت‌تر است ارجاع بدهد.
 *
 * @param array $fields
 * @return array
 */
function farazsms_fb_normalize_wpforms( $fields ) {
	$out = array();
	foreach ( (array) $fields as $id => $field ) {
		if ( ! is_array( $field ) ) {
			continue;
		}
		$value = isset( $field['value'] ) ? $field['value'] : '';
		$value = is_array( $value ) ? implode( ', ', $value ) : (string) $value;

		$out[ (string) $id ] = $value;

		$label = isset( $field['name'] ) ? (string) $field['name'] : '';
		if ( $label !== '' ) {
			$key = sanitize_title( $label );
			if ( $key !== '' && ! isset( $out[ $key ] ) ) {
				$out[ $key ] = $value;
			}
			// نسخه‌ی سازگار با پارسرِ پترن (برچسبِ فارسی یا خط‌تیره‌دار).
			$safe = farazsms_fb_var_key( $key );
			if ( $safe !== '' && ! isset( $out[ $safe ] ) ) {
				$out[ $safe ] = $value;
			}
		}
	}
	return $out;
}

/**
 * دادهٔ MetForm از قبل تخت است؛ فقط مقادیرِ آرایه‌ای و کلیدهای کنترلی پاک می‌شوند.
 *
 * @param array $form_data
 * @return array
 */
function farazsms_fb_normalize_metform( $form_data ) {
	$skip = array( 'form_nonce', 'hidden-fields', 'g-recaptcha-response', 'g-recaptcha-response-v3', 'mf-captcha-challenge' );
	$out  = array();
	foreach ( (array) $form_data as $key => $value ) {
		if ( in_array( (string) $key, $skip, true ) ) {
			continue;
		}
		$flat = is_array( $value ) ? implode( ', ', $value ) : (string) $value;
		$out[ (string) $key ] = $flat;
		// نامِ فیلدهای مت‌فرم خط‌تیره دارند؛ معادلِ زیرخطی هم اضافه می‌شود تا
		// بتوان در متنِ پترن به آن ارجاع داد.
		$safe = farazsms_fb_var_key( $key );
		if ( $safe !== '' && ! isset( $out[ $safe ] ) ) {
			$out[ $safe ] = $flat;
		}
	}
	return $out;
}

/**
 * نام‌های فیلدِ آخرین ارسالِ هر فرم را نگه می‌دارد.
 *
 * دلیل: مدیر بدونِ این باید نامِ دقیقِ فیلد را حدس بزند. با یک ارسالِ آزمایشی،
 * فهرستِ واقعیِ فیلدها در صفحهٔ تنظیمات ظاهر می‌شود — به‌جای راهنمای حدسی.
 *
 * @param string $source
 * @param int    $form_id
 * @param array  $data
 */
function farazsms_fb_remember_fields( $source, $form_id, $data ) {
	$all = get_option( FARAZSMS_FB_FIELDS_OPT, array() );
	if ( ! is_array( $all ) ) {
		$all = array();
	}
	$key    = $source . ':' . (int) $form_id;
	// فقط نامِ فیلدهای معتبر نگه داشته می‌شود، نه هر کلیدی که در POST آمده.
	$fields = array();
	foreach ( array_keys( $data ) as $k ) {
		if ( preg_match( '/^[a-zA-Z0-9_\-]{1,64}$/', (string) $k ) ) {
			$fields[] = (string) $k;
		}
	}
	$fields = array_slice( $fields, 0, 40 );

	// فقط وقتی چیزی واقعاً عوض شده بنویس — وگرنه هر ارسالِ فرم یک نوشتنِ
	// دیتابیس می‌شد، روی فرمی که روزی صدها بار پر می‌شود.
	if ( isset( $all[ $key ] ) && $all[ $key ] === $fields ) {
		return;
	}
	$all[ $key ] = $fields;
	if ( count( $all ) > 40 ) {
		$all = array_slice( $all, -40, null, true );
	}
	update_option( FARAZSMS_FB_FIELDS_OPT, $all, false );
}

// ============================================================================
// موتورِ قانون
// ============================================================================

/**
 * گیرنده‌ی معتبر، یا رشته‌ی خالی.
 *
 * انتخابِ اشتباهِ فیلد (نام، ایمیل، متنِ آزاد) رایج‌ترین خطای پیکربندیِ این بخش
 * است. بدونِ اعتبارسنجی، هر ثبتِ فرم یک ارسالِ محکوم‌به‌شکست و یک واحد اعتبار
 * هزینه می‌کرد — و چون هیچ لاگی پیش از تماس با سرویس نوشته نمی‌شد، مدیر هم
 * هیچ نشانه‌ای نمی‌دید. حالا شماره‌ی نامعتبر پیش از صف متوقف و در «تشخیصِ
 * ارسال» ثبت می‌شود.
 *
 * @param string $raw
 * @param string $source
 * @param int    $form_id
 * @param string $field نامِ فیلد (برای لاگ)
 * @return string
 */
function farazsms_fb_recipient( $raw, $source, $form_id, $field ) {
	$raw = trim( (string) $raw );
	if ( $raw === '' ) {
		return '';
	}
	$phone = (string) farazsms_normalize_phone( $raw );
	if ( ! farazsms_is_mobile( $phone ) ) {
		// امضای واقعی: ( گیرنده، کدپترن، نتیجه، context )
		farazsms_send_diag_log( $phone, '', 'invalid_mobile', array(
			'source'  => $source,
			'form_id' => (int) $form_id,
			'field'   => (string) $field,
		) );
		return '';
	}
	return $phone;
}

/**
 * اجرای قانون‌های یک ارسال.
 *
 * @param string $source
 * @param int    $form_id
 * @param array  $data       نام → مقدار
 * @param string $form_title
 */
function farazsms_fb_dispatch( $source, $form_id, $data, $form_title = '' ) {
	$form_id = (int) $form_id;
	if ( $form_id <= 0 ) {
		return;
	}
	// ⚠️ عمداً اینجا صدا زده نمی‌شود: ورودیِ این تابع در متفرم همان POSTِ خامِ
	// بازدیدکننده است. اگر پیش از تطبیقِ قانون اجرا شود، یک بازدیدکننده‌ی ناشناس
	// می‌تواند با فرستادنِ کلیدهای متفاوت در هر ارسال، به‌ازای هر بار یک نوشتنِ
	// دیتابیس ایجاد کند و فیلدِ واقعیِ موبایل را از فهرست بیرون براند.
	$matched = false;

	// جلوگیری از پیامکِ تکراری وقتی دو قانونِ فعال روی یک فرم تعریف شده‌اند
	// (رابطِ کاربری مانعش نمی‌شود).
	$already = array();

	foreach ( farazsms_fb_get_rules() as $rule ) {
		if ( ( $rule['enabled'] ?? '0' ) !== '1' ) {
			continue;
		}
		if ( (string) ( $rule['source'] ?? '' ) !== $source ) {
			continue;
		}
		if ( (int) ( $rule['form_id'] ?? 0 ) !== $form_id ) {
			continue;
		}
		$matched = true;
		$pattern = trim( (string) ( $rule['pattern_code'] ?? '' ) );
		if ( $pattern === '' ) {
			continue;
		}

		// متغیرهای پترن از توکن‌های متن استخراج می‌شوند و از دادهٔ همین ارسال پر.
		$message = (string) ( $rule['message'] ?? '' );
		$vars    = array();
		if ( preg_match_all( '/[{%]([a-zA-Z0-9_-]+)[}%]/', $message, $m ) ) {
			foreach ( array_unique( $m[1] ) as $key ) {
				if ( $key === 'form_title' ) {
					$vars[ $key ] = $form_title;
					continue;
				}
				if ( $key === 'sitename' ) {
					$vars[ $key ] = get_bloginfo( 'name' );
					continue;
				}
				// هم نامِ اصلی و هم معادلِ امن بررسی می‌شود.
				$safe         = farazsms_fb_var_key( $key );
				$vars[ $key ] = isset( $data[ $key ] ) ? (string) $data[ $key ]
					: ( ( $safe !== '' && isset( $data[ $safe ] ) ) ? (string) $data[ $safe ] : '' );
			}
		}

		// گیرنده‌ی کاربر
		$phone_field = trim( (string) ( $rule['phone_field'] ?? '' ) );
		$raw_phone   = ( $phone_field !== '' && isset( $data[ $phone_field ] ) ) ? (string) $data[ $phone_field ] : '';
		$phone       = farazsms_fb_recipient( $raw_phone, $source, $form_id, $phone_field );
		if ( $phone !== '' && ! isset( $already[ $phone . '|' . $pattern ] ) ) {
			$already[ $phone . '|' . $pattern ] = true;
			farazsms_queue_send( $source, $phone, $pattern, $vars, array( 'form_id' => $form_id ) );
		}

		// گیرنده‌ی مدیر (پترنِ جدا اگر تعریف شده باشد، وگرنه همان پترن)
		$admin_phone = trim( (string) ( $rule['admin_phone'] ?? '' ) );
		if ( $admin_phone !== '' ) {
			$admin_phone   = farazsms_fb_recipient( $admin_phone, $source, $form_id, 'admin_phone' );
			$admin_pattern = trim( (string) ( $rule['admin_pattern_code'] ?? '' ) );
			$use = $admin_pattern !== '' ? $admin_pattern : $pattern;
			if ( $admin_phone !== '' && ! isset( $already[ $admin_phone . '|' . $use ] ) ) {
				$already[ $admin_phone . '|' . $use ] = true;
				farazsms_queue_send( $source, $admin_phone, $use, $vars, array( 'form_id' => $form_id, 'to' => 'admin' ) );
			}
		}
	}

	// ثبتِ نامِ فیلدها فقط وقتی قانونی با این فرم تطبیق خورده باشد.
	if ( $matched ) {
		farazsms_fb_remember_fields( $source, $form_id, $data );
	}
}

// ============================================================================
// هوک‌ها
// ============================================================================

add_action( 'wpforms_process_complete', 'farazsms_fb_on_wpforms', 20, 4 );
/**
 * @param array $fields
 * @param array $entry
 * @param array $form_data
 * @param int   $entry_id
 */
function farazsms_fb_on_wpforms( $fields, $entry = array(), $form_data = array(), $entry_id = 0 ) {
	try {
		$form_id = (int) ( $form_data['id'] ?? 0 );
		$title   = (string) ( $form_data['settings']['form_title'] ?? '' );
		farazsms_fb_dispatch( 'wpforms', $form_id, farazsms_fb_normalize_wpforms( $fields ), $title );
	} catch ( \Throwable $e ) {
		// ثبتِ فرم هرگز نباید بشکند — ولی خطا هم نباید بی‌ردّ گم شود.
		farazsms_send_diag_log( '', '', 'formbuilder_error', array( 'source' => 'wpforms', 'error' => $e->getMessage() ) );
	}
}

add_action( 'metform_after_store_form_data', 'farazsms_fb_on_metform', 20, 4 );
/**
 * @param int   $form_id
 * @param array $form_data
 * @param array $form_settings
 * @param array $attributes
 */
function farazsms_fb_on_metform( $form_id, $form_data = array(), $form_settings = array(), $attributes = array() ) {
	try {
		$title = (string) ( $form_settings['form_title'] ?? get_the_title( (int) $form_id ) );
		farazsms_fb_dispatch( 'metform', (int) $form_id, farazsms_fb_normalize_metform( $form_data ), $title );
	} catch ( \Throwable $e ) {
		farazsms_send_diag_log( '', '', 'formbuilder_error', array( 'source' => 'metform', 'error' => $e->getMessage() ) );
	}
}

// ============================================================================
// ساختِ خودکارِ پترن — هر قانون پترنِ خودش را دارد
// ============================================================================

add_filter( 'farazsms_feature_pattern_map', 'farazsms_fb_register_pattern_features' );
/**
 * @param array $map
 * @return array
 */
function farazsms_fb_register_pattern_features( $map ) {
	// کلید از (فرم‌ساز + شناسه‌ی فرم) ساخته می‌شود، نه از ایندکسِ آرایه: با حذفِ یک
	// قانونِ میانی ایندکس‌ها می‌لغزیدند و «ویرایشِ پترن» روی قانونِ دیگری می‌نوشت.
	foreach ( farazsms_fb_get_rules() as $i => $rule ) {
		$key = farazsms_fb_rule_key( $rule );
		if ( $key === '' ) {
			continue;
		}
		$map[ 'formbuilder_' . $key ] = array(
			'opt'     => FARAZSMS_FB_OPTION,
			'section' => 'form',
			'path'    => array( (int) $i ),
		);
	}
	return $map;
}

// ============================================================================
// صفحه‌ی تنظیمات
// ============================================================================

add_action( 'admin_menu', 'farazsms_fb_menu', 20 );
function farazsms_fb_menu() {
	add_submenu_page(
		'farazsms',
		__( 'پیامک فرم‌سازها', 'farazsms' ),
		__( 'پیامک فرم‌سازها', 'farazsms' ),
		'manage_options',
		'farazsms-form-builders',
		'farazsms_fb_render_page'
	);
}

add_action( 'admin_init', 'farazsms_fb_handle_save' );
function farazsms_fb_handle_save() {
	if ( ! isset( $_POST['farazsms_fb_nonce'] ) ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['farazsms_fb_nonce'] ) ), 'farazsms_fb_save' ) ) {
		return;
	}

	$existing = farazsms_fb_get_rules();
	$posted   = isset( $_POST['farazsms_fb'] ) && is_array( $_POST['farazsms_fb'] ) ? wp_unslash( $_POST['farazsms_fb'] ) : array();
	$rules    = array();
	$invalid  = array();

	// متنِ ذخیره‌شده را با «کلیدِ قانون» برمی‌داریم نه با ایندکس: ایندکس‌ها با حذفِ
	// یک قانونِ میانی می‌لغزند و متنِ یک فرم روی فرمِ دیگر می‌نشست.
	$saved_messages = array();
	foreach ( $existing as $old ) {
		$old_key = farazsms_fb_rule_key( $old );
		if ( $old_key !== '' ) {
			$saved_messages[ $old_key ] = (string) ( $old['message'] ?? '' );
		}
	}

	foreach ( $posted as $i => $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$raw_form = trim( (string) ( $row['form_id'] ?? '' ) );
		$form_id  = (int) $raw_form;
		$source   = sanitize_key( (string) ( $row['source'] ?? '' ) );
		if ( ! isset( farazsms_fb_sources()[ $source ] ) ) {
			continue;
		}
		if ( $form_id <= 0 ) {
			// خالی = حذفِ عمدی (همان چیزی که راهنمای صفحه می‌گوید).
			// ولی مقدارِ پرشده‌ی نامعتبر (مثلاً عنوانِ فرم به‌جای شناسه) نباید
			// قانون را بی‌صدا نابود کند — قانونِ قبلی حفظ و خطا نشان داده می‌شود.
			if ( $raw_form !== '' && isset( $existing[ (int) $i ] ) ) {
				$rules[]   = $existing[ (int) $i ];
				$invalid[] = $raw_form;
			}
			continue;
		}
		$rule = array(
			'enabled'            => isset( $row['enabled'] ) ? '1' : '0',
			'source'             => $source,
			'form_id'            => $form_id,
			'phone_field'        => sanitize_text_field( (string) ( $row['phone_field'] ?? '' ) ),
			'pattern_code'       => sanitize_text_field( (string) ( $row['pattern_code'] ?? '' ) ),
			'admin_phone'        => sanitize_text_field( (string) ( $row['admin_phone'] ?? '' ) ),
			'admin_pattern_code' => sanitize_text_field( (string) ( $row['admin_pattern_code'] ?? '' ) ),
		);
		// متنِ پیامک را «سازنده‌ی پترن» می‌نویسد؛ اینجا مقدارِ ذخیره‌شده حفظ می‌شود.
		$key             = farazsms_fb_rule_key( $rule );
		$rule['message'] = (string) ( $saved_messages[ $key ] ?? ( $row['message'] ?? '' ) );
		$rules[]         = $rule;
	}

	update_option( FARAZSMS_FB_OPTION, $rules, false );

	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-success is-dismissible"><p>قانون‌های پیامکِ فرم‌سازها ذخیره شد.</p></div>';
	} );

	if ( ! empty( $invalid ) ) {
		$bad = implode( '، ', array_map( 'sanitize_text_field', array_slice( $invalid, 0, 3 ) ) );
		add_action( 'admin_notices', function () use ( $bad ) {
			echo '<div class="notice notice-error is-dismissible"><p>شناسه‌ی فرم باید عدد باشد. مقدارِ واردشده («'
				. esc_html( $bad )
				. '») معتبر نبود، پس قانونِ قبلی دست‌نخورده ماند. از فهرستِ کنارِ همان فیلد، فرم را انتخاب کنید.</p></div>';
		} );
	}
}

/**
 * فهرستِ فرم‌های هر فرم‌ساز (برای انتخابِ آسان به‌جای واردکردنِ دستیِ شناسه).
 *
 * @param string $source
 * @return array شناسه → عنوان
 */
function farazsms_fb_list_forms( $source ) {
	$post_type = $source === 'wpforms' ? 'wpforms' : 'metform-form';
	if ( ! post_type_exists( $post_type ) ) {
		return array();
	}
	$posts = get_posts( array(
		'post_type'        => $post_type,
		'post_status'      => array( 'publish', 'draft' ),
		'numberposts'      => 100,
		'suppress_filters' => false,
	) );
	$out = array();
	foreach ( $posts as $post ) {
		$out[ (int) $post->ID ] = $post->post_title !== '' ? $post->post_title : ( '#' . $post->ID );
	}
	return $out;
}

function farazsms_fb_render_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$rules  = farazsms_fb_get_rules();
	$seen   = get_option( FARAZSMS_FB_FIELDS_OPT, array() );
	$seen   = is_array( $seen ) ? $seen : array();
	$has_ui = function_exists( 'farazsms_feature_pattern_builder_ui' );
	$active = array();
	foreach ( farazsms_fb_sources() as $key => $label ) {
		if ( farazsms_fb_source_active( $key ) ) {
			$active[ $key ] = $label;
		}
	}
	// فهرستِ فرم‌ها **یک‌بار** خوانده می‌شود، نه به‌ازای هر ردیف (قبلاً برای هر
	// قانون دو کوئری اجرا می‌شد).
	$all_forms = array();
	foreach ( array( 'wpforms', 'metform' ) as $src ) {
		foreach ( farazsms_fb_list_forms( $src ) as $id => $title ) {
			$all_forms[ $id ] = $title;
		}
	}

	// یک ردیفِ خالی برای افزودنِ قانونِ تازه.
	$rows = $rules;
	$rows[] = array();
	?>
	<div class="wrap" dir="rtl">
		<h1>📝 پیامک فرم‌سازها</h1>

		<?php if ( empty( $active ) ) : ?>
			<div class="notice notice-warning"><p>
				هیچ‌کدام از <strong>WPForms</strong> و <strong>MetForm</strong> روی این سایت فعال نیست. تنظیماتِ زیر ذخیره می‌شود ولی تا نصبِ یکی از آن‌ها اثری ندارد.
			</p></div>
		<?php endif; ?>

		<div class="farazsms-int-intro">
			<strong>این صفحه چه می‌کند؟</strong> پس از ثبتِ هر فرم، برای پرکنندهٔ فرم (و در صورت تمایل برای مدیر) پیامک می‌فرستد.
			<br><strong>راه‌اندازی در ۴ قدم:</strong>
			<ol>
				<li>یک <strong>ارسالِ آزمایشی</strong> از فرمِ موردنظر انجام دهید — این کار باعث می‌شود نامِ واقعیِ فیلدها همین‌جا فهرست شود.</li>
				<li>فرم‌ساز و فرم را انتخاب کنید و <strong>فیلدِ موبایل</strong> را از فهرستِ ظاهرشده بردارید.</li>
				<li>متنِ پیامک را بنویسید و دکمهٔ ساختِ پترن را بزنید تا کدپترن خودکار پر شود.</li>
				<li>ذخیره کنید.</li>
			</ol>
			در متنِ پیامک می‌توانید نامِ هر فیلدِ فرم را داخلِ <code dir="ltr">%…%</code> بگذارید؛ مقدارش از همان ارسال پر می‌شود.
			متغیرهای آماده: <code dir="ltr">%form_title%</code> و <code dir="ltr">%sitename%</code>.
		</div>

		<!-- یک فهرستِ مشترک به‌جای تکرارِ آن در هر ردیف (با ۱۰ قانون و ۲۰۰ فرم،
		     تکرارش ده‌ها کیلوبایت HTMLِ بی‌فایده می‌شد). -->
		<datalist id="farazsms-fb-forms">
			<?php foreach ( $all_forms as $id => $title ) : ?>
				<option value="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $title ); ?></option>
			<?php endforeach; ?>
		</datalist>

		<form method="post" action="">
			<?php wp_nonce_field( 'farazsms_fb_save', 'farazsms_fb_nonce' ); ?>

			<?php foreach ( $rows as $i => $rule ) :
				$source  = (string) ( $rule['source'] ?? '' );
				$form_id = (int) ( $rule['form_id'] ?? 0 );
				$is_new  = empty( $rule );
				$fields  = $seen[ $source . ':' . $form_id ] ?? array();
				?>
				<div class="farazsms-int-card">
					<div class="farazsms-int-card__head">
						<h2 class="farazsms-int-card__title">
							<?php echo $is_new ? 'افزودنِ قانونِ تازه' : esc_html( ( farazsms_fb_sources()[ $source ] ?? $source ) . ' — فرم #' . $form_id ); ?>
						</h2>
						<label class="farazsms-int-toggle">
							<?php // ردیفِ تازه پیش‌فرض فعال است، وگرنه کاربر قانون می‌ساخت و بی‌صدا هیچ پیامکی نمی‌رفت. ?>
							<input type="checkbox" name="<?php echo esc_attr( "farazsms_fb[$i][enabled]" ); ?>" value="1" <?php checked( $is_new ? '1' : ( $rule['enabled'] ?? '0' ), '1' ); ?>>
							فعال
						</label>
					</div>
					<div class="farazsms-int-card__body">
						<div class="farazsms-int-field">
							<label>فرم‌ساز</label>
							<select name="<?php echo esc_attr( "farazsms_fb[$i][source]" ); ?>">
								<option value="">— انتخاب کنید —</option>
								<?php foreach ( farazsms_fb_sources() as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $source, $key ); ?>>
										<?php echo esc_html( $label . ( farazsms_fb_source_active( $key ) ? '' : ' (نصب نیست)' ) ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</div>

						<div class="farazsms-int-field">
							<label>شناسه یا نامِ فرم</label>
							<input type="text" dir="ltr" name="<?php echo esc_attr( "farazsms_fb[$i][form_id]" ); ?>" value="<?php echo $form_id > 0 ? esc_attr( $form_id ) : ''; ?>" list="farazsms-fb-forms" placeholder="مثلاً 128">

						</div>

						<div class="farazsms-int-field">
							<label>فیلدِ موبایل</label>
							<input type="text" dir="ltr" name="<?php echo esc_attr( "farazsms_fb[$i][phone_field]" ); ?>" value="<?php echo esc_attr( $rule['phone_field'] ?? '' ); ?>" list="<?php echo esc_attr( 'farazsms-fb-fields-' . $i ); ?>" placeholder="mf-telephone">
							<datalist id="<?php echo esc_attr( 'farazsms-fb-fields-' . $i ); ?>">
								<?php foreach ( $fields as $f ) : ?>
									<option value="<?php echo esc_attr( $f ); ?>"></option>
								<?php endforeach; ?>
							</datalist>
							<?php if ( empty( $fields ) && ! $is_new ) : ?>
								<p class="farazsms-int-hint">هنوز ارسالی از این فرم دیده نشده. یک ارسالِ آزمایشی انجام دهید تا نامِ فیلدها اینجا فهرست شود.</p>
							<?php elseif ( ! empty( $fields ) ) : ?>
								<div class="farazsms-int-vars"><?php foreach ( $fields as $f ) : ?><code><?php echo esc_html( $f ); ?></code><?php endforeach; ?></div>
							<?php endif; ?>
						</div>

						<div class="farazsms-int-field">
							<label>کدپترنِ کاربر</label>
							<input type="text" dir="ltr" name="<?php echo esc_attr( "farazsms_fb[$i][pattern_code]" ); ?>" value="<?php echo esc_attr( $rule['pattern_code'] ?? '' ); ?>" placeholder="با دکمهٔ زیر خودکار پر می‌شود">
						</div>

						<?php if ( $has_ui && ! $is_new ) {
							$vars = farazsms_fb_builtin_vars();
							foreach ( array_slice( $fields, 0, 12 ) as $f ) {
								// فقط نامی پیشنهاد می‌شود که پارسرِ پترن آن را می‌فهمد.
								$safe = farazsms_fb_var_key( $f );
								if ( $safe !== '' ) {
									$vars[] = '%' . $safe . '%';
								}
							}
							$vars = array_values( array_unique( $vars ) );
							$rule_key = farazsms_fb_rule_key( $rule );
							if ( $rule_key !== '' ) {
								farazsms_feature_pattern_builder_ui( 'formbuilder_' . $rule_key, (string) ( $rule['message'] ?? '' ), $vars, "farazsms_fb[$i][pattern_code]" );
							}
						} ?>

						<div class="farazsms-int-field">
							<label>شمارهٔ مدیر (اختیاری)</label>
							<input type="text" dir="ltr" name="<?php echo esc_attr( "farazsms_fb[$i][admin_phone]" ); ?>" value="<?php echo esc_attr( $rule['admin_phone'] ?? '' ); ?>" placeholder="09xxxxxxxxx">
						</div>
						<div class="farazsms-int-field">
							<label>کدپترنِ مدیر (اختیاری — خالی یعنی همان پترنِ کاربر)</label>
							<input type="text" dir="ltr" name="<?php echo esc_attr( "farazsms_fb[$i][admin_pattern_code]" ); ?>" value="<?php echo esc_attr( $rule['admin_pattern_code'] ?? '' ); ?>">
						</div>
						<?php if ( ! $is_new ) : ?>
							<p class="farazsms-int-hint">برای حذفِ این قانون، شناسهٔ فرم را خالی کنید و ذخیره بزنید.</p>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>

			<p><button type="submit" class="button button-primary">💾 ذخیره قانون‌ها</button></p>
		</form>

		<div class="farazsms-int-intro">
			<strong>سؤال‌های پرتکرار</strong>
			<ul>
				<li><strong>نامِ فیلد را از کجا بیاورم؟</strong> یک ارسالِ آزمایشی از فرم انجام دهید؛ نامِ واقعیِ فیلدها همین‌جا فهرست می‌شود. حدس نزنید.</li>
				<li><strong>پیامک نرفت؟</strong> مطمئن شوید کدپترن پر شده و در پنلِ فراز تأیید شده است، و فیلدِ موبایل دقیقاً همان نامی است که در فهرست آمده.</li>
				<li><strong>ثبتِ فرم کند می‌شود؟</strong> خیر. پیامک پس از بسته‌شدنِ صفحه ارسال می‌شود.</li>
			</ul>
		</div>
	</div>
	<?php
}

add_filter( 'farazsms_compatibility_registry', 'farazsms_fb_register_compat' );
/**
 * @param array $registry
 * @return array
 */
function farazsms_fb_register_compat( $registry ) {
	$registry['wpforms'] = array(
		'name'   => 'WPForms',
		'what'   => 'پیامک به پرکنندهٔ فرم و مدیر، پس از ثبتِ هر فرم',
		'group'  => 'forms',
		'detect' => 'farazsms_fb_wpforms_active',
	);
	$registry['metform'] = array(
		'name'   => 'MetForm',
		'what'   => 'پیامک به پرکنندهٔ فرم و مدیر، پس از ثبتِ هر فرم',
		'group'  => 'forms',
		'detect' => 'farazsms_fb_metform_active',
	);
	return $registry;
}

/** @return bool */
function farazsms_fb_wpforms_active() {
	return farazsms_fb_source_active( 'wpforms' );
}

/** @return bool */
function farazsms_fb_metform_active() {
	return farazsms_fb_source_active( 'metform' );
}

// عمداً در ناوبری ثبت نمی‌شود: تنظیماتِ این دو فرم‌ساز زیرمجموعه‌ی همان صفحه‌ی
// «فرم ساز ها» است و از کارت‌های همان صفحه باز می‌شود — تا برای یک کار دو منو
// وجود نداشته باشد.

/**
 * آیا دستِ‌کم یکی از فرم‌سازهای پشتیبانی‌شده نصب است؟ (برای نمایش در منو.)
 *
 * @return bool
 */
function farazsms_fb_any_source_active() {
	foreach ( array_keys( farazsms_fb_sources() ) as $src ) {
		if ( farazsms_fb_source_active( $src ) ) {
			return true;
		}
	}
	return false;
}
